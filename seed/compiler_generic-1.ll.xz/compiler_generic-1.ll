; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:fnRow" = type { i64, ptr, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:instance" = type { i64, i32, i32, { i64, ptr }, { i64, ptr }, %"compiler/generic:Origin" }
%"compiler/generic:folded" = type { i64, i64, i32 }
%"compiler/generic:ConstAsk" = type { i64, ptr, i32, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", i64 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1, { i64, ptr } }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Promise" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/generic:genRoots" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:cursor" = type { { i64, ptr }, i64 }
define dso_local i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a0 to i64
  %t5 = mul i64 %t3, 2
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2eFnOwner(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 2
  %t5 = add i64 %t3, 1
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fnames_2eWrittenMut(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Param", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_16dbf6b4ccd94c8c_8f0170059e61e7c0)
  unreachable
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Param", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 8}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 8}
  %t37 = icmp eq i64 %t35, 4
  store i1 %t37, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_b4eb6cf3622f1222_98250c586f701fa6)
  unreachable
bb21:
  %t39 = load i1, ptr %l11, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l54 = alloca %"compiler/generic:fnRow"
  %l62 = alloca i64
  %l72 = alloca { i64, ptr }
  %l78 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %s0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 38
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l22
  br label %bb3
bb3:
  %t14 = load i64, ptr %l22, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb6:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l29, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l29, !tbaa !24
  store i64 %t41, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l26, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 38
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i64, ptr %l50, !tbaa !24
  store i64 %t68, ptr %l10, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 29
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s2, ptr %t71, i64 %t72)
  store %"compiler/generic:fnRow" %t75, ptr %l54
  br label %bb15
bb15:
  %t76 = getelementptr %"compiler/generic:fnRow", ptr %l54, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t84 = icmp ne i32 %t80, %a2
  br i1 %t84, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 39
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t88, i64 %t89)
  store i64 %t92, ptr %l62
  br label %bb19
bb19:
  %t93 = load i64, ptr %l62, !tbaa !24
  %t94 = trunc i64 %t93 to i32
  store i32 %t94, ptr %l11, !tbaa !23
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t104 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t111 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t111, ptr %l72, !tbaa !27
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t112
  %t117 = load i32, ptr %t116, !tbaa !33
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t121, i32 %t117)
  store i32 %t125, ptr %l78
  br label %bb24
bb24:
  %t126 = load i32, ptr %l11, !tbaa !23
  %t127 = load i32, ptr %l78, !tbaa !23
  %t129 = icmp eq i32 %t127, %t126
  br i1 %t129, label %bb25, label %bb26
bb25:
  %t131 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t131, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t133 = load i64, ptr %l13, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l13, !tbaa !24
  br label %bb20
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l8, !tbaa !24
  br label %bb10
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l58 = alloca i1
  %l62 = alloca i1
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l83 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l106 = alloca i64
  %l109 = alloca i64
  %l127 = alloca { i64, ptr }
  %l131 = alloca i1
  %l132 = alloca i1
  %l136 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca ptr
  %l144 = alloca %"compiler/generic:Context"
  %l149 = alloca i32
  %l151 = alloca i64
  %l155 = alloca i32
  %l156 = alloca i32
  %l161 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i32
  %l165 = alloca i64
  %l166 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i32
  %l170 = alloca ptr
  %l174 = alloca i32
  %l176 = alloca i64
  %l179 = alloca i32
  %l180 = alloca i32
  %l181 = alloca %"compiler/generic:AnySlot"
  %l188 = alloca i64
  %l192 = alloca i64
  %l195 = alloca i64
  %l216 = alloca i64
  %l220 = alloca i64
  %l231 = alloca { i64, ptr }
  %l237 = alloca i32
  %l246 = alloca i1
  %l247 = alloca ptr
  %l251 = alloca %"compiler/generic:fnRow"
  %l254 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i64
  %l260 = alloca i32
  %l261 = alloca i32
  %l265 = alloca ptr
  %l269 = alloca %"compiler/generic:fnRow"
  %l273 = alloca ptr
  %l277 = alloca i32
  %l278 = alloca { i64, ptr }
  %l282 = alloca i1
  %l285 = alloca { i64, ptr }
  %l287 = alloca i32
  %l290 = alloca i1
  %l293 = alloca { i64, ptr }
  %l295 = alloca i64
  %l299 = alloca ptr
  %l303 = alloca %"compiler/generic:fnRow"
  %l310 = alloca %"compiler/generic:AnySlot"
  %l314 = alloca i64
  %l317 = alloca %"compiler/generic:AnySlot"
  %l322 = alloca i64
  %l326 = alloca i64
  %l329 = alloca i64
  %l347 = alloca { i64, ptr }
  %l348 = alloca i64
  %l351 = alloca %"compiler/generic:AnySlot"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t200 = alloca %"compiler/generic:Context", align 8
  %t559 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 63
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H5ded0725d411df67b2648301e639bd4e(ptr %v0, ptr %v1, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l51
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l50
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t12, ptr %l46, !tbaa !27
  br label %bb8
bb2:
  br label %bb3
bb3:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = icmp sle i64 0, 288230376151711743
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_c2f0255997df361c_a6c9f390e9e9df68)
  unreachable
bb6:
  %t17 = mul i64 0, 32
  %t18 = insertvalue { i64, ptr } undef, i64 0, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t19, ptr %l46, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c2f0255997df361c_a6c9f390e9e9df68)
  unreachable
bb8:
  %t21 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb12
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 63
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H9e3d6110ebf70523261e6bda2644191a(ptr %v0, ptr %t30, i32 %t31)
  store i1 %t34, ptr %l62
  br label %bb11
bb11:
  %t35 = load i1, ptr %l62, !tbaa !21
  store i1 %t35, ptr %l58, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l58, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t39)
  br label %bb16
bb16:
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l65
  br label %bb17
bb17:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l3
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l66
  br label %bb18
bb18:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l4
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %s0, ptr %t45, i32 %t46)
  store { i64, ptr } %t49, ptr %l69
  br label %bb19
bb19:
  %t50 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t51, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb21, label %bb22
bb21:
  br label %bb78
bb22:
  br label %bb23
bb23:
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t65, ptr %l77, !tbaa !27
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 %t66
  %t71 = load i32, ptr %t70, !tbaa !33
  store i32 %t71, ptr %l9, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l9, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l83
  br label %bb24
bb24:
  %t80 = load i32, ptr %l83, !tbaa !23
  store i32 %t80, ptr %l10, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l10, !tbaa !23
  %t85 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t81, i32 %t82)
  store ptr %t85, ptr %l86
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l86, !tbaa !29
  store ptr %t86, ptr %l11, !tbaa !29
  %t87 = load ptr, ptr %l11, !tbaa !29
  %t89 = icmp eq ptr %t87, null
  br i1 %t89, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb28
bb27:
  %t91 = load ptr, ptr %l11, !tbaa !29
  %t93 = getelementptr %"compiler/ast:TypeDecl", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  store i1 %t96, ptr %l89, !tbaa !21
  br label %bb28
bb28:
  %t98 = load i1, ptr %l89, !tbaa !21
  br i1 %t98, label %bb29, label %bb30
bb29:
  br label %bb77
bb30:
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l11, !tbaa !29
  %t101 = getelementptr %"compiler/ast:TypeDecl", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  store ptr %t102, ptr %l12, !tbaa !29
  %t104 = load ptr, ptr %l12, !tbaa !29
  store ptr %t104, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t105 = load ptr, ptr %l95, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb32, label %bb33
bb32:
  %t108 = load ptr, ptr %l95, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 5}
  %t111 = icmp eq i64 %t109, 2
  store i1 %t111, ptr %l96, !tbaa !21
  br label %bb33
bb33:
  %t112 = load i1, ptr %l96, !tbaa !21
  br i1 %t112, label %bb34, label %bb35
bb34:
  %t113 = load ptr, ptr %l12, !tbaa !29
  %t115 = getelementptr { i64, [6 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t115, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116
  store { i64, ptr } %t117, ptr %l13, !tbaa !27
  br label %bb36
bb35:
  br label %bb71
bb36:
  store i64 0, ptr %l14, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  store i64 %t121, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t123 = load i64, ptr %l15, !tbaa !24
  %t124 = load i64, ptr %l14, !tbaa !24
  %t127 = icmp sgt i64 %t123, %t124
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load i64, ptr %l16, !tbaa !24
  %t131 = icmp sgt i64 %t129, 0
  br i1 %t131, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb42
bb39:
  %t133 = load i64, ptr %l15, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t137 = sub i64 %t133, %t134
  %t138 = load i64, ptr %l16, !tbaa !24
  %t141 = add i64 %t137, %t138
  %t143 = sub i64 %t141, 1
  %t144 = load i64, ptr %l16, !tbaa !24
  %t147 = sdiv i64 %t143, %t144
  store i64 %t147, ptr %l109, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb41
bb41:
  %t149 = load i64, ptr %l109, !tbaa !24
  store i64 %t149, ptr %l106, !tbaa !24
  br label %bb42
bb42:
  %t150 = load i64, ptr %l106, !tbaa !24
  store i64 %t150, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t151 = load i64, ptr %l18, !tbaa !24
  %t152 = load i64, ptr %l17, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb45:
  br label %bb46
bb46:
  %t159 = load i64, ptr %l14, !tbaa !24
  %t160 = load i64, ptr %l18, !tbaa !24
  %t161 = load i64, ptr %l16, !tbaa !24
  %t164 = mul i64 %t160, %t161
  %t167 = add i64 %t159, %t164
  store i64 %t167, ptr %l19, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t169, ptr %l127, !tbaa !27
  %t170 = load i64, ptr %l19, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr ptr, ptr %t173, i64 %t170
  %t175 = load ptr, ptr %t174, !tbaa !39
  store ptr %t175, ptr %l20, !tbaa !29
  %t177 = load ptr, ptr %l20, !tbaa !29
  %t179 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t177)
  store i1 %t179, ptr %l131
  br label %bb47
bb47:
  %t180 = load i1, ptr %l131, !tbaa !21
  br i1 %t180, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb51
bb49:
  %t181 = load ptr, ptr %l20, !tbaa !29
  %t183 = getelementptr %"compiler/ast:Func", ptr %t181, i32 0, i32 2
  %t184 = load i32, ptr %t183, !tbaa !23
  %t187 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l4, i32 %t184)
  store i1 %t187, ptr %l136
  br label %bb50
bb50:
  %t188 = load i1, ptr %l136, !tbaa !21
  store i1 %t188, ptr %l132, !tbaa !21
  br label %bb51
bb51:
  %t189 = load i1, ptr %l132, !tbaa !21
  br i1 %t189, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb53:
  br label %bb54
bb54:
  %t190 = load ptr, ptr %l20, !tbaa !29
  %t192 = getelementptr %"compiler/ast:Func", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %t192, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l4, i32 %t193)
  br label %bb55
bb55:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l140, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l141, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t200, ptr %v0, ptr %s7, ptr %t198, i32 %t199)
  call void @llvm.memmove.p0.p0.i64(ptr %l144, ptr %t200, i64 160, i1 false)
  br label %bb56
bb56:
  %t203 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t203, ptr %l144, i64 160, i1 false)
  %t204 = load ptr, ptr %l20, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Func", ptr %t204, i32 0, i32 3
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t208 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = load ptr, ptr %l141, !tbaa !29
  %t213 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %s7, ptr %v0, ptr %t209, ptr %t203, ptr %t207, i32 %t208, i32 0)
  store i32 %t213, ptr %l149
  br label %bb57
bb57:
  %t214 = load i32, ptr %l10, !tbaa !23
  %t216 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t214)
  store i64 %t216, ptr %l151
  br label %bb58
bb58:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/generic:Program", ptr %t217, i32 0, i32 2
  %t220 = load i32, ptr %l9, !tbaa !23
  %t223 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t219, i32 %t220)
  store i32 %t223, ptr %l155
  br label %bb59
bb59:
  %t224 = load ptr, ptr %l140, !tbaa !29
  %t225 = load i32, ptr %l149, !tbaa !23
  %t226 = load i64, ptr %l151, !tbaa !24
  %t227 = load i32, ptr %l155, !tbaa !23
  %t228 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t224, i32 %t225, i64 %t226, i32 %t227)
  store i32 %t228, ptr %l156
  br label %bb60
bb60:
  %t229 = load i32, ptr %l156, !tbaa !23
  %t230 = load ptr, ptr %l20, !tbaa !29
  %t232 = getelementptr %"compiler/ast:Func", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = icmp eq ptr %t233, null
  %t237 = xor i1 %t235, true
  store i1 %t237, ptr %l22, !tbaa !21
  store ptr %l3, ptr %l161, !tbaa !29
  %t239 = load ptr, ptr %l20, !tbaa !29
  %t241 = getelementptr %"compiler/ast:Func", ptr %t239, i32 0, i32 2
  %t242 = load i32, ptr %t241, !tbaa !23
  store i32 %t242, ptr %l163, !tbaa !23
  %t243 = load i32, ptr %l9, !tbaa !23
  store i32 %t243, ptr %l164, !tbaa !23
  %t244 = load i64, ptr %l19, !tbaa !24
  store i64 %t244, ptr %l165, !tbaa !24
  %t245 = load i1, ptr %l22, !tbaa !21
  store i1 %t245, ptr %l166, !tbaa !21
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l167, !tbaa !29
  store i32 %t229, ptr %l168, !tbaa !23
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  store ptr %t250, ptr %l170, !tbaa !29
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/generic:Program", ptr %t251, i32 0, i32 2
  %t254 = load i32, ptr %l1, !tbaa !23
  %t257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %t253, i32 %t254)
  store i32 %t257, ptr %l174
  br label %bb61
bb61:
  %t258 = load i1, ptr %l22, !tbaa !21
  br i1 %t258, label %bb62, label %bb63
bb62:
  %t260 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t260, ptr %l176, !tbaa !24
  br label %bb64
bb63:
  %t262 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t262, ptr %l176, !tbaa !24
  br label %bb64
bb64:
  %t264 = load ptr, ptr %l170, !tbaa !29
  %t265 = load i32, ptr %l174, !tbaa !23
  %t266 = load i64, ptr %l176, !tbaa !24
  %t267 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t264, i32 %t265, i64 %t266)
  store i32 %t267, ptr %l179
  br label %bb65
bb65:
  %t268 = load ptr, ptr %l167, !tbaa !29
  %t269 = load i32, ptr %l168, !tbaa !23
  %t270 = load i32, ptr %l179, !tbaa !23
  %t271 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWithReceiver(ptr %v0, ptr %t268, i32 %t269, i32 %t270)
  store i32 %t271, ptr %l180
  br label %bb66
bb66:
  %t272 = load i32, ptr %l163, !tbaa !23
  %t273 = load i32, ptr %l164, !tbaa !23
  %t274 = load i64, ptr %l165, !tbaa !24
  %t275 = load i1, ptr %l166, !tbaa !21
  %t276 = load i32, ptr %l180, !tbaa !23
  %t277 = call %"compiler/generic:AnySlot" @compiler_2fgeneric_3aAnySlot_2ector(ptr %s7, i32 %t272, i32 %t273, i64 %t274, i64 -1, i1 %t275, i32 %t276)
  store %"compiler/generic:AnySlot" %t277, ptr %l181
  br label %bb67
bb67:
  %t278 = load ptr, ptr %l161, !tbaa !29
  %t279 = load %"compiler/generic:AnySlot", ptr %l181
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ePush_H53ed042998733b8f648bef68c9e795c2(ptr %s0, ptr %t278, %"compiler/generic:AnySlot" %t279)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb69:
  %t280 = load i64, ptr %l18, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l18, !tbaa !24
  br label %bb43
bb70:
  br label %bb76
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_8bb21cabdbc81f72_d9374099c3cf9016)
  unreachable
bb76:
  br label %bb77
bb77:
  %t284 = load i64, ptr %l7, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l7, !tbaa !24
  br label %bb20
bb78:
  store i64 0, ptr %l23, !tbaa !24
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 38
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t290)
  store i64 %t292, ptr %l188
  br label %bb79
bb79:
  %t293 = load i64, ptr %l188, !tbaa !24
  store i64 %t293, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t294 = load i64, ptr %l24, !tbaa !24
  %t295 = load i64, ptr %l23, !tbaa !24
  %t298 = icmp sgt i64 %t294, %t295
  br i1 %t298, label %bb80, label %bb81
bb80:
  %t300 = load i64, ptr %l25, !tbaa !24
  %t302 = icmp sgt i64 %t300, 0
  br i1 %t302, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l192, !tbaa !24
  br label %bb85
bb82:
  %t304 = load i64, ptr %l24, !tbaa !24
  %t305 = load i64, ptr %l23, !tbaa !24
  %t308 = sub i64 %t304, %t305
  %t309 = load i64, ptr %l25, !tbaa !24
  %t312 = add i64 %t308, %t309
  %t314 = sub i64 %t312, 1
  %t315 = load i64, ptr %l25, !tbaa !24
  %t318 = sdiv i64 %t314, %t315
  store i64 %t318, ptr %l195, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l195, !tbaa !24
  br label %bb84
bb84:
  %t320 = load i64, ptr %l195, !tbaa !24
  store i64 %t320, ptr %l192, !tbaa !24
  br label %bb85
bb85:
  %t321 = load i64, ptr %l192, !tbaa !24
  store i64 %t321, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s13
  %t322 = load i64, ptr %l27, !tbaa !24
  %t323 = load i64, ptr %l26, !tbaa !24
  %t326 = icmp slt i64 %t322, %t323
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s13)
  br label %bb131
bb88:
  br label %bb89
bb89:
  %t330 = load i64, ptr %l23, !tbaa !24
  %t331 = load i64, ptr %l27, !tbaa !24
  %t332 = load i64, ptr %l25, !tbaa !24
  %t335 = mul i64 %t331, %t332
  %t338 = add i64 %t330, %t335
  store i64 %t338, ptr %l28, !tbaa !24
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/generic:Program", ptr %t340, i32 0, i32 38
  %t343 = load i64, ptr %l28, !tbaa !24
  %t346 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t342, i64 %t343)
  store i64 %t346, ptr %l216
  br label %bb90
bb90:
  %t347 = load i64, ptr %l216, !tbaa !24
  store i64 %t347, ptr %l29, !tbaa !24
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/generic:Program", ptr %t348, i32 0, i32 39
  %t351 = load i64, ptr %l28, !tbaa !24
  %t354 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t350, i64 %t351)
  store i64 %t354, ptr %l220
  br label %bb91
bb91:
  %t355 = load i64, ptr %l220, !tbaa !24
  %t356 = trunc i64 %t355 to i32
  store i32 %t356, ptr %l30, !tbaa !23
  %t359 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t359, ptr %l31, !tbaa !23
  %t361 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t361, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t363 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t363, 0
  store i64 %t365, ptr %l34, !tbaa !24
  br label %bb92
bb92:
  %t367 = load i64, ptr %l33, !tbaa !24
  %t368 = load i64, ptr %l34, !tbaa !24
  %t371 = icmp slt i64 %t367, %t368
  %t373 = xor i1 %t371, true
  br i1 %t373, label %bb93, label %bb94
bb93:
  br label %bb101
bb94:
  br label %bb95
bb95:
  %t375 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t375, ptr %l231, !tbaa !27
  %t376 = load i64, ptr %l33, !tbaa !24
  %t378 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !27
  %t380 = getelementptr i32, ptr %t379, i64 %t376
  %t381 = load i32, ptr %t380, !tbaa !33
  store i32 %t381, ptr %l35, !tbaa !23
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/generic:Program", ptr %t383, i32 0, i32 2
  %t386 = load i32, ptr %l35, !tbaa !23
  %t389 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t389, ptr %l237
  br label %bb96
bb96:
  %t390 = load i32, ptr %l30, !tbaa !23
  %t391 = load i32, ptr %l237, !tbaa !23
  %t393 = icmp eq i32 %t391, %t390
  br i1 %t393, label %bb97, label %bb98
bb97:
  %t395 = load i32, ptr %l35, !tbaa !23
  store i32 %t395, ptr %l31, !tbaa !23
  br label %bb99
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t397 = load i64, ptr %l33, !tbaa !24
  %t399 = add i64 %t397, 1
  store i64 %t399, ptr %l33, !tbaa !24
  br label %bb92
bb101:
  %t401 = load i32, ptr %l31, !tbaa !23
  %t402 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t405 = icmp eq i32 %t401, %t402
  br i1 %t405, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb106
bb103:
  store ptr %l4, ptr %l247, !tbaa !29
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/generic:Program", ptr %t407, i32 0, i32 29
  %t410 = load i64, ptr %l29, !tbaa !24
  %t413 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s13, ptr %t409, i64 %t410)
  store %"compiler/generic:fnRow" %t413, ptr %l251
  br label %bb104
bb104:
  %t414 = getelementptr %"compiler/generic:fnRow", ptr %l251, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !29
  %t417 = getelementptr %"compiler/ast:Func", ptr %t415, i32 0, i32 2
  %t418 = load i32, ptr %t417, !tbaa !23
  %t419 = load ptr, ptr %l247, !tbaa !29
  %t421 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t419, i32 %t418)
  store i1 %t421, ptr %l254
  br label %bb105
bb105:
  %t422 = load i1, ptr %l254, !tbaa !21
  store i1 %t422, ptr %l246, !tbaa !21
  br label %bb106
bb106:
  %t423 = load i1, ptr %l246, !tbaa !21
  br i1 %t423, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s13)
  br label %bb130
bb108:
  br label %bb109
bb109:
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l255, !tbaa !29
  %t425 = load i64, ptr %l29, !tbaa !24
  store i64 %t425, ptr %l256, !tbaa !24
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/generic:Program", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %l1, !tbaa !23
  %t432 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %t428, i32 %t429)
  store i32 %t432, ptr %l260
  br label %bb110
bb110:
  %t433 = load ptr, ptr %l255, !tbaa !29
  %t434 = load i64, ptr %l256, !tbaa !24
  %t435 = load i32, ptr %l260, !tbaa !23
  %t436 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %t433, i64 %t434, i32 %t435)
  store i32 %t436, ptr %l261
  br label %bb111
bb111:
  %t437 = load i32, ptr %l261, !tbaa !23
  store i32 %t437, ptr %l36, !tbaa !23
  %t438 = load i32, ptr %l36, !tbaa !23
  %t439 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t442 = icmp eq i32 %t438, %t439
  br i1 %t442, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s13)
  br label %bb130
bb113:
  br label %bb114
bb114:
  store ptr %l4, ptr %l265, !tbaa !29
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/generic:Program", ptr %t444, i32 0, i32 29
  %t447 = load i64, ptr %l29, !tbaa !24
  %t450 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s13, ptr %t446, i64 %t447)
  store %"compiler/generic:fnRow" %t450, ptr %l269
  br label %bb115
bb115:
  %t451 = getelementptr %"compiler/generic:fnRow", ptr %l269, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t454 = getelementptr %"compiler/ast:Func", ptr %t452, i32 0, i32 2
  %t455 = load i32, ptr %t454, !tbaa !23
  %t456 = load ptr, ptr %l265, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t456, i32 %t455)
  br label %bb116
bb116:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Program", ptr %t458, i32 0, i32 2
  store ptr %t460, ptr %l273, !tbaa !29
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/generic:Program", ptr %t461, i32 0, i32 2
  %t464 = load i32, ptr %l36, !tbaa !23
  %t467 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t463, i32 %t464)
  store i32 %t467, ptr %l277
  br label %bb117
bb117:
  %t468 = load ptr, ptr %l273, !tbaa !29
  %t469 = load i32, ptr %l277, !tbaa !23
  %t470 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t468, i32 %t469)
  store { i64, ptr } %t470, ptr %l278
  br label %bb118
bb118:
  %t471 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t471, ptr %l37, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t476 = icmp sgt i64 %t474, 0
  br i1 %t476, label %bb119, label %bb120
bb119:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/generic:Program", ptr %t478, i32 0, i32 2
  %t481 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t481, ptr %l285, !tbaa !27
  %t482 = getelementptr { i64, ptr }, ptr %l285, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i32, ptr %t483, i64 0
  %t485 = load i32, ptr %t484, !tbaa !33
  %t488 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t480, i32 %t485)
  store i32 %t488, ptr %l287
  br label %bb121
bb120:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb122
bb121:
  %t489 = load i32, ptr %l287, !range !{i32 0, i32 33}
  %t491 = trunc i64 20 to i32
  %t492 = icmp eq i32 %t489, %t491
  store i1 %t492, ptr %l282, !tbaa !21
  br label %bb122
bb122:
  %t494 = load i1, ptr %l282, !tbaa !21
  br i1 %t494, label %bb123, label %bb124
bb123:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/generic:Program", ptr %t495, i32 0, i32 2
  %t498 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t498, ptr %l293, !tbaa !27
  %t499 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t500 = load ptr, ptr %t499, !tbaa !27
  %t501 = getelementptr i32, ptr %t500, i64 0
  %t502 = load i32, ptr %t501, !tbaa !33
  %t505 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t497, i32 %t502)
  store i64 %t505, ptr %l295
  br label %bb125
bb124:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb126
bb125:
  %t506 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t507 = load i64, ptr %l295, !tbaa !24
  %t509 = and i64 %t507, %t506
  %t511 = icmp ne i64 %t509, 0
  store i1 %t511, ptr %l290, !tbaa !21
  br label %bb126
bb126:
  %t513 = load i1, ptr %l290, !tbaa !21
  store i1 %t513, ptr %l38, !tbaa !21
  store ptr %l3, ptr %l299, !tbaa !29
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t516 = getelementptr %"compiler/generic:Program", ptr %t514, i32 0, i32 29
  %t517 = load i64, ptr %l29, !tbaa !24
  %t520 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s13, ptr %t516, i64 %t517)
  store %"compiler/generic:fnRow" %t520, ptr %l303
  br label %bb127
bb127:
  %t521 = getelementptr %"compiler/generic:fnRow", ptr %l303, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = getelementptr %"compiler/ast:Func", ptr %t522, i32 0, i32 2
  %t525 = load i32, ptr %t524, !tbaa !23
  %t526 = load i32, ptr %l31, !tbaa !23
  %t527 = load i64, ptr %l29, !tbaa !24
  %t528 = load i1, ptr %l38, !tbaa !21
  %t529 = load i32, ptr %l36, !tbaa !23
  %t535 = call %"compiler/generic:AnySlot" @compiler_2fgeneric_3aAnySlot_2ector(ptr %s13, i32 %t525, i32 %t526, i64 -1, i64 %t527, i1 %t528, i32 %t529)
  store %"compiler/generic:AnySlot" %t535, ptr %l310
  br label %bb128
bb128:
  %t536 = load ptr, ptr %l299, !tbaa !29
  %t537 = load %"compiler/generic:AnySlot", ptr %l310
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ePush_H53ed042998733b8f648bef68c9e795c2(ptr %s0, ptr %t536, %"compiler/generic:AnySlot" %t537)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s13)
  br label %bb130
bb130:
  %t538 = load i64, ptr %l27, !tbaa !24
  %t540 = add i64 %t538, 1
  store i64 %t540, ptr %l27, !tbaa !24
  br label %bb86
bb131:
  %t543 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eLen__H711cec3afad496782566ddd729023773(ptr %s0, ptr %l3)
  store i64 %t543, ptr %l314
  br label %bb132
bb132:
  %t544 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t545 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t548 = call %"compiler/generic:AnySlot" @compiler_2fgeneric_3aAnySlot_2ector(ptr %v1, i32 0, i32 %t544, i64 -1, i64 -1, i1 false, i32 %t545)
  store %"compiler/generic:AnySlot" %t548, ptr %l317
  br label %bb133
bb133:
  %t549 = load i64, ptr %l314, !tbaa !24
  %t550 = icmp sge i64 %t549, 0
  br i1 %t550, label %bb134, label %bb135
bb134:
  %t552 = load i64, ptr %l314, !tbaa !24
  %t553 = icmp sle i64 %t552, 288230376151711743
  br i1 %t553, label %bb136, label %bb137
bb135:
  call void @__olang_check_failed(ptr @olang_loc_98166f45573479aa_46aa63c900b34a36)
  unreachable
bb136:
  %t555 = load i64, ptr %l314, !tbaa !24
  %t556 = mul i64 %t555, 32
  %t557 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t556)
  %t558 = load %"compiler/generic:AnySlot", ptr %l317
  store i64 0, ptr %t559
  br label %fill.560
fill.560:
  %t563 = load i64, ptr %t559
  %t564 = icmp slt i64 %t563, %t555
  br i1 %t564, label %fillb.561, label %filld.562
fillb.561:
  %t565 = getelementptr %"compiler/generic:AnySlot", ptr %t557, i64 %t563
  store %"compiler/generic:AnySlot" %t558, ptr %t565
  %t566 = add i64 %t563, 1
  store i64 %t566, ptr %t559
  br label %fill.560
filld.562:
  %t567 = insertvalue { i64, ptr } undef, i64 %t555, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t557, 1
  store { i64, ptr } %t568, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t571 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eLen__H711cec3afad496782566ddd729023773(ptr %s0, ptr %l3)
  store i64 %t571, ptr %l322
  br label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_98166f45573479aa_46aa63c900b34a36)
  unreachable
bb138:
  %t572 = load i64, ptr %l322, !tbaa !24
  store i64 %t572, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t573 = load i64, ptr %l41, !tbaa !24
  %t574 = load i64, ptr %l40, !tbaa !24
  %t577 = icmp sgt i64 %t573, %t574
  br i1 %t577, label %bb139, label %bb140
bb139:
  %t579 = load i64, ptr %l42, !tbaa !24
  %t581 = icmp sgt i64 %t579, 0
  br i1 %t581, label %bb141, label %bb142
bb140:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb144
bb141:
  %t583 = load i64, ptr %l41, !tbaa !24
  %t584 = load i64, ptr %l40, !tbaa !24
  %t587 = sub i64 %t583, %t584
  %t588 = load i64, ptr %l42, !tbaa !24
  %t591 = add i64 %t587, %t588
  %t593 = sub i64 %t591, 1
  %t594 = load i64, ptr %l42, !tbaa !24
  %t597 = sdiv i64 %t593, %t594
  store i64 %t597, ptr %l329, !tbaa !24
  br label %bb143
bb142:
  store i64 0, ptr %l329, !tbaa !24
  br label %bb143
bb143:
  %t599 = load i64, ptr %l329, !tbaa !24
  store i64 %t599, ptr %l326, !tbaa !24
  br label %bb144
bb144:
  %t600 = load i64, ptr %l326, !tbaa !24
  store i64 %t600, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb145
bb145:
  %t601 = load i64, ptr %l44, !tbaa !24
  %t602 = load i64, ptr %l43, !tbaa !24
  %t605 = icmp slt i64 %t601, %t602
  %t607 = xor i1 %t605, true
  br i1 %t607, label %bb146, label %bb147
bb146:
  br label %bb151
bb147:
  br label %bb148
bb148:
  %t609 = load i64, ptr %l40, !tbaa !24
  %t610 = load i64, ptr %l44, !tbaa !24
  %t611 = load i64, ptr %l42, !tbaa !24
  %t614 = mul i64 %t610, %t611
  %t617 = add i64 %t609, %t614
  store i64 %t617, ptr %l45, !tbaa !24
  %t619 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t619, ptr %l347, !tbaa !27
  %t620 = load i64, ptr %l45, !tbaa !24
  store i64 %t620, ptr %l348, !tbaa !24
  %t621 = load i64, ptr %l45, !tbaa !24
  %t624 = call %"compiler/generic:AnySlot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eAt_3ccompiler_2fgeneric_3aAnySlot_3e(ptr %s0, ptr %l3, i64 %t621)
  store %"compiler/generic:AnySlot" %t624, ptr %l351
  br label %bb149
bb149:
  %t625 = load %"compiler/generic:AnySlot", ptr %l351
  %t626 = load i64, ptr %l348, !tbaa !24
  %t627 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t628 = load ptr, ptr %t627, !tbaa !27
  %t629 = getelementptr %"compiler/generic:AnySlot", ptr %t628, i64 %t626
  store %"compiler/generic:AnySlot" %t625, ptr %t629
  br label %bb150
bb150:
  %t630 = load i64, ptr %l44, !tbaa !24
  %t632 = add i64 %t630, 1
  store i64 %t632, ptr %l44, !tbaa !24
  br label %bb145
bb151:
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = getelementptr %"compiler/generic:Program", ptr %t634, i32 0, i32 63
  %t637 = load i32, ptr %l1, !tbaa !23
  %t638 = load { i64, ptr }, ptr %l39, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H5c1f2db077436d08712784f933dc3852(ptr %v0, ptr %v1, ptr %t636, i32 %t637, { i64, ptr } %t638)
  br label %bb152
bb152:
  %t642 = load { i64, ptr }, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t642, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca i32
  %l13 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i64
  %l15 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 62
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = sext i32 %t11 to i64
  %t15 = sext i32 %a2 to i64
  %t18 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t12, i64 %t15)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t18, ptr %l13
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  %t21 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t19, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t20)
  %t22 = extractvalue { i32, i64 } %t21, 1
  %t23 = extractvalue { i32, i64 } %t21, 0
  store i32 %t23, ptr %l15
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb4, label %ok.25, !prof !99
ok.25:
  store i64 %t22, ptr %l14
  br label %bb3
bb3:
  %t26 = load i64, ptr %l14, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 0)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/generic:Context"
  %t3 = alloca %"compiler/generic:Context", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t3, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t3, i64 160, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"compiler/names:Entry"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l28 = alloca ptr
  %l32 = alloca %"compiler/names:Entry"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l85 = alloca i32
  %l89 = alloca i1
  %l99 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = shl i64 %t1, 32
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = or i64 %t3, %t4
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__Hbe724e949204db7f54e3bca969c5f391(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, i32 } %t15, 1
  %t17 = extractvalue { i32, i32 } %t15, 0
  store i32 %t17, ptr %l19
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb2, label %ok.19, !prof !99
ok.19:
  store i32 %t16, ptr %l18
  br label %bb1
bb1:
  %t20 = load i32, ptr %l18, !tbaa !23
  store i32 %t20, ptr %l14, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i32 -1, ptr %l14, !tbaa !23
  br label %bb4
bb4:
  %t21 = load i32, ptr %l14, !tbaa !23
  store i32 %t21, ptr %l4, !tbaa !23
  %t22 = load i32, ptr %l4, !tbaa !23
  %t24 = icmp sge i32 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load i32, ptr %l4, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eensureModules(ptr %v0, ptr %t28)
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l28
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l28, !tbaa !29
  %t42 = getelementptr %"compiler/names:Table", ptr %t40, i32 0, i32 0
  %t43 = load i64, ptr %l2, !tbaa !24
  %t46 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t42, i64 %t43)
  store %"compiler/names:Entry" %t46, ptr %l32
  br label %bb10
bb10:
  %t47 = load %"compiler/names:Entry", ptr %l32
  store %"compiler/names:Entry" %t47, ptr %l5
  store i32 2, ptr %l6
  store i32 0, ptr %l7, !tbaa !23
  %t49 = getelementptr %"compiler/names:Entry", ptr %l5, i32 0, i32 4
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l8, !tbaa !29
  %t52 = load ptr, ptr %l8, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb11, label %bb12
bb11:
  store i32 0, ptr %l6
  %t59 = load ptr, ptr %l8, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TypeDecl", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb13, label %bb14
bb12:
  br label %bb50
bb13:
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr %"compiler/ast:TypeDecl", ptr %t68, i32 0, i32 3
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l9, !tbaa !29
  %t73 = load ptr, ptr %l9, !tbaa !29
  store ptr %t73, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t74 = load ptr, ptr %l45, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb15, label %bb16
bb14:
  br label %bb46
bb15:
  %t77 = load ptr, ptr %l45, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 5}
  %t80 = icmp eq i64 %t78, 0
  store i1 %t80, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 0, ptr %l6
  br label %bb45
bb20:
  %t83 = load ptr, ptr %l9, !tbaa !29
  store ptr %t83, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t84 = load ptr, ptr %l50, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb21, label %bb22
bb21:
  %t87 = load ptr, ptr %l50, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 5}
  %t90 = icmp eq i64 %t88, 1
  store i1 %t90, ptr %l51, !tbaa !21
  br label %bb22
bb22:
  %t91 = load i1, ptr %l51, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i32 1, ptr %l6
  br label %bb45
bb26:
  %t93 = load ptr, ptr %l9, !tbaa !29
  store ptr %t93, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t94 = load ptr, ptr %l55, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l55, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 5}
  %t100 = icmp eq i64 %t98, 2
  store i1 %t100, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l56, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 3, ptr %l6
  br label %bb45
bb32:
  %t103 = load ptr, ptr %l9, !tbaa !29
  store ptr %t103, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t104 = load ptr, ptr %l60, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb33, label %bb34
bb33:
  %t107 = load ptr, ptr %l60, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 5}
  %t110 = icmp eq i64 %t108, 3
  store i1 %t110, ptr %l61, !tbaa !21
  br label %bb34
bb34:
  %t111 = load i1, ptr %l61, !tbaa !21
  br i1 %t111, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i32 4, ptr %l6
  br label %bb45
bb38:
  %t113 = load ptr, ptr %l9, !tbaa !29
  store ptr %t113, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t114 = load ptr, ptr %l65, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb39, label %bb40
bb39:
  %t117 = load ptr, ptr %l65, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 5}
  %t120 = icmp eq i64 %t118, 4
  store i1 %t120, ptr %l66, !tbaa !21
  br label %bb40
bb40:
  %t121 = load i1, ptr %l66, !tbaa !21
  br i1 %t121, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i32 5, ptr %l6
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_799e213f453ad9fb_869f4f41e63ea5ff)
  unreachable
bb45:
  br label %bb46
bb46:
  %t123 = load ptr, ptr %l8, !tbaa !29
  %t125 = getelementptr %"compiler/ast:TypeDecl", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb47, label %bb48
bb47:
  %t132 = load ptr, ptr %l8, !tbaa !29
  %t134 = getelementptr %"compiler/ast:TypeDecl", ptr %t132, i32 0, i32 1
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t139 = trunc i64 %t137 to i32
  store i32 %t139, ptr %l7, !tbaa !23
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i64, ptr %l1, !tbaa !24
  %t145 = getelementptr %"compiler/names:Entry", ptr %l5, i32 0, i32 0
  %t146 = load i32, ptr %t145, !tbaa !23
  %t147 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t148 = load i32, ptr %l7, !tbaa !23
  %t150 = inttoptr i64 0 to ptr
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %t150, ptr %t143, i64 %t144, i32 %t146, i32 %t147, i32 %t148)
  store i32 %t156, ptr %l85
  br label %bb51
bb51:
  %t157 = load i32, ptr %l85, !tbaa !23
  store i32 %t157, ptr %l4, !tbaa !23
  %t158 = load ptr, ptr %l8, !tbaa !29
  %t160 = icmp eq ptr %t158, null
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb52, label %bb53
bb52:
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/ast:TypeDecl", ptr %t164, i32 0, i32 5
  %t167 = load i32, ptr %t166, !range !{i32 0, i32 3}
  %t169 = trunc i64 2 to i32
  %t170 = icmp eq i32 %t167, %t169
  store i1 %t170, ptr %l89, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb54
bb54:
  %t172 = load i1, ptr %l89, !tbaa !21
  br i1 %t172, label %bb55, label %bb56
bb55:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkUnique(ptr %v0, ptr %t175, i32 %t176)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t179 = load ptr, ptr %l8, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb59, label %bb60
bb59:
  %t185 = load ptr, ptr %l8, !tbaa !29
  %t187 = getelementptr %"compiler/ast:TypeDecl", ptr %t185, i32 0, i32 6
  %t188 = load i1, ptr %t187, !tbaa !21
  store i1 %t188, ptr %l99, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb61
bb61:
  %t190 = load i1, ptr %l99, !tbaa !21
  br i1 %t190, label %bb62, label %bb63
bb62:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/generic:Program", ptr %t191, i32 0, i32 2
  %t194 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkPacked(ptr %v0, ptr %t193, i32 %t194)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t197 = load ptr, ptr %l8, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb66, label %bb67
bb66:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l1, !tbaa !24
  %t205 = load ptr, ptr %l8, !tbaa !29
  %t209 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEndsHeld(ptr %v0, ptr %v0, ptr %t203, i64 %t204, ptr %t205)
  store i1 %t209, ptr %l112
  br label %bb68
bb67:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb69
bb68:
  %t210 = load i1, ptr %l112, !tbaa !21
  store i1 %t210, ptr %l108, !tbaa !21
  br label %bb69
bb69:
  %t211 = load i1, ptr %l108, !tbaa !21
  br i1 %t211, label %bb70, label %bb71
bb70:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkEnds(ptr %v0, ptr %t214, i32 %t215)
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 4
  %t221 = load i64, ptr %l3, !tbaa !24
  %t222 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__H7ddd7dd10a6733ce5265405d8e7c8faa(ptr %v0, ptr %t220, i64 %t221, i32 %t222)
  br label %bb74
bb74:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 12
  %t229 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  br label %bb75
bb75:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/generic:Program", ptr %t232, i32 0, i32 13
  %t235 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t234, i64 %t235)
  br label %bb76
bb76:
  %t238 = load i32, ptr %l4, !tbaa !23
  store i32 %t238, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i32
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i32
  %l87 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l101 = alloca i64
  %l103 = alloca i64
  %l107 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca i64
  %l122 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l131 = alloca i32
  %l132 = alloca i32
  %l136 = alloca i32
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l148 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l155 = alloca i32
  %l156 = alloca i32
  %l165 = alloca i64
  %l168 = alloca ptr
  %l169 = alloca i32
  %l171 = alloca ptr
  %l173 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l176 = alloca i32
  %l177 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l25
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l33, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i32, ptr %t21, i64 %t18
  %t23 = load i32, ptr %t22, !tbaa !33
  store i32 %t23, ptr %l6, !tbaa !23
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp ne i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load i32, ptr %l6, !tbaa !23
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t35 = icmp ne i32 %t31, %t32
  store i1 %t35, ptr %l39, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l39, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l2, i32 %t38)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l47
  br label %bb15
bb15:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l7
  %t47 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %s0, ptr %s0, ptr %t47, ptr %l2, ptr %l7)
  br label %bb16
bb16:
  store i64 0, ptr %l8, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7)
  store i64 %t52, ptr %l52
  br label %bb17
bb17:
  %t53 = load i64, ptr %l52, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb23
bb20:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l10, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l59, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb22
bb22:
  %t80 = load i64, ptr %l59, !tbaa !24
  store i64 %t80, ptr %l56, !tbaa !24
  br label %bb23
bb23:
  %t81 = load i64, ptr %l56, !tbaa !24
  store i64 %t81, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l13, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l78, !tbaa !29
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t103)
  store i32 %t106, ptr %l81
  br label %bb28
bb28:
  %t107 = load ptr, ptr %l78, !tbaa !29
  %t108 = load i32, ptr %l81, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t109, ptr %l82
  br label %bb29
bb29:
  %t110 = load i32, ptr %l82, !range !{i32 0, i32 33}
  %t112 = trunc i64 28 to i32
  %t113 = icmp eq i32 %t110, %t112
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb31:
  br label %bb32
bb32:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  store ptr %t119, ptr %l87, !tbaa !29
  %t120 = load i64, ptr %l13, !tbaa !24
  %t123 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t120)
  store i32 %t123, ptr %l90
  br label %bb33
bb33:
  %t124 = load ptr, ptr %l87, !tbaa !29
  %t125 = load i32, ptr %l90, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l91
  br label %bb34
bb34:
  %t127 = load i32, ptr %l91, !tbaa !23
  store i32 %t127, ptr %l14, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l92, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l14, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l96
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l92, !tbaa !29
  %t137 = load i32, ptr %l96, !tbaa !23
  %t138 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s6, ptr %t136, i32 %t137)
  store { i64, ptr } %t138, ptr %l97
  br label %bb36
bb36:
  %t139 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l15, !tbaa !24
  %t142 = load i64, ptr %l15, !tbaa !24
  %t144 = icmp sge i64 %t142, 64
  br i1 %t144, label %bb37, label %bb38
bb37:
  %t146 = sub i64 0, 1
  store i64 %t146, ptr %l101, !tbaa !65
  br label %bb39
bb38:
  %t148 = load i64, ptr %l15, !tbaa !24
  store i64 %t148, ptr %l103, !tbaa !24
  %t149 = load i64, ptr %l103, !tbaa !24
  %t150 = load i64, ptr %l103, !tbaa !24
  %t151 = shl i64 1, %t150
  %t153 = sub i64 %t151, 1
  store i64 %t153, ptr %l101, !tbaa !65
  br label %bb39
bb39:
  %t155 = load i64, ptr %l101, !tbaa !65
  store i64 %t155, ptr %l16, !tbaa !65
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  store ptr %t158, ptr %l107, !tbaa !29
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t159)
  store i32 %t162, ptr %l110
  br label %bb40
bb40:
  %t163 = load ptr, ptr %l107, !tbaa !29
  %t164 = load i32, ptr %l110, !tbaa !23
  %t165 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t163, i32 %t164)
  store i64 %t165, ptr %l111
  br label %bb41
bb41:
  %t166 = load i64, ptr %l16, !tbaa !65
  %t167 = load i64, ptr %l111, !tbaa !65
  %t169 = and i64 %t167, %t166
  %t170 = load i64, ptr %l16, !tbaa !65
  %t173 = icmp eq i64 %t169, %t170
  br i1 %t173, label %bb42, label %bb43
bb42:
  %t175 = load i64, ptr %l13, !tbaa !24
  %t176 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i64 %t175, i32 %t176)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb46:
  %t180 = load i64, ptr %l12, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l12, !tbaa !24
  br label %bb24
bb47:
  %t185 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t185, ptr %l122
  br label %bb48
bb48:
  %t186 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t186, ptr %l17, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t190 = ptrtoint ptr %t189 to i64
  %t191 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t190, i64 8)
  %t192 = getelementptr { ptr, ptr }, ptr %t191, i32 0, i32 0
  store ptr %t188, ptr %t192, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t194 = getelementptr { ptr, ptr }, ptr %t191, i32 0, i32 1
  store ptr %v0, ptr %t194, !tbaa !28
  %t195 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t196 = insertvalue { ptr, ptr } %t195, ptr %t191, 1
  %t199 = extractvalue { ptr, ptr } %t196, 0
  %t200 = extractvalue { ptr, ptr } %t196, 1
  call void @std_2fprelude_2farray_2eArray_3ccompiler_2ftypes_3aTypeId_3e_2eSort_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %s0, ptr %v0, { i64, ptr } %t187, ptr %t199, ptr %t200)
  br label %bb49
bb49:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 2
  store ptr %t203, ptr %l127, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  %t207 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t206, { i64, ptr } %t207)
  store i32 %t210, ptr %l131
  br label %bb50
bb50:
  %t211 = load ptr, ptr %l127, !tbaa !29
  %t212 = load i32, ptr %l131, !tbaa !23
  %t213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrVal(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t213, ptr %l132
  br label %bb51
bb51:
  %t214 = load i32, ptr %l132, !tbaa !23
  store i32 %t214, ptr %l18, !tbaa !23
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  %t218 = load i32, ptr %l18, !tbaa !23
  %t221 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrRepr(ptr %v0, ptr %t217, i32 %t218)
  store i32 %t221, ptr %l136
  br label %bb52
bb52:
  %t222 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t223 = load i32, ptr %l136, !tbaa !23
  %t225 = icmp eq i32 %t223, %t222
  br i1 %t225, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l139
  br label %bb55
bb54:
  br label %bb77
bb55:
  %t228 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %l19, i32 5)
  br label %bb56
bb56:
  %t230 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t230, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 0
  store i64 %t234, ptr %l22, !tbaa !24
  br label %bb57
bb57:
  %t236 = load i64, ptr %l21, !tbaa !24
  %t237 = load i64, ptr %l22, !tbaa !24
  %t240 = icmp slt i64 %t236, %t237
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb58, label %bb59
bb58:
  br label %bb68
bb59:
  br label %bb60
bb60:
  %t244 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t244, ptr %l148, !tbaa !27
  %t245 = load i64, ptr %l21, !tbaa !24
  %t247 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr i32, ptr %t248, i64 %t245
  %t250 = load i32, ptr %t249, !tbaa !33
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l151, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  %t259 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t255, i32 %t250)
  store i32 %t259, ptr %l155
  br label %bb61
bb61:
  %t260 = load ptr, ptr %l151, !tbaa !29
  %t261 = load i32, ptr %l155, !tbaa !23
  %t262 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t262, ptr %l156
  br label %bb62
bb62:
  %t263 = load i32, ptr %l156, !tbaa !23
  store i32 %t263, ptr %l24, !tbaa !23
  %t264 = load i32, ptr %l24, !tbaa !23
  %t265 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t268 = icmp ne i32 %t264, %t265
  br i1 %t268, label %bb63, label %bb64
bb63:
  %t270 = load i32, ptr %l24, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %l19, i32 %t270)
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t273 = load i64, ptr %l21, !tbaa !24
  %t275 = add i64 %t273, 1
  store i64 %t275, ptr %l21, !tbaa !24
  br label %bb57
bb68:
  %t278 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %l19)
  store i64 %t278, ptr %l165
  br label %bb69
bb69:
  %t279 = load i64, ptr %l165, !tbaa !24
  %t280 = icmp sgt i64 %t279, 1
  br i1 %t280, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s15
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 2
  store ptr %t284, ptr %l168, !tbaa !29
  %t285 = load i32, ptr %l18, !tbaa !23
  store i32 %t285, ptr %l169, !tbaa !23
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/generic:Program", ptr %t286, i32 0, i32 2
  store ptr %t288, ptr %l171, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/generic:Program", ptr %t289, i32 0, i32 2
  store ptr %t291, ptr %l173, !tbaa !29
  %t293 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %s15, ptr %l19)
  store { i64, ptr } %t293, ptr %l175
  br label %bb72
bb71:
  br label %bb76
bb72:
  %t294 = load ptr, ptr %l173, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t296 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s15, ptr %t294, { i64, ptr } %t295)
  store i32 %t296, ptr %l176
  br label %bb73
bb73:
  %t297 = load ptr, ptr %l171, !tbaa !29
  %t298 = load i32, ptr %l176, !tbaa !23
  %t299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t297, i32 %t298)
  store i32 %t299, ptr %l177
  br label %bb74
bb74:
  %t300 = load ptr, ptr %l168, !tbaa !29
  %t301 = load i32, ptr %l169, !tbaa !23
  %t302 = load i32, ptr %l177, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetErrRepr(ptr %v0, ptr %t300, i32 %t301, i32 %t302)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s15)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s10)
  br label %bb77
bb77:
  %t303 = load i32, ptr %l18, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t303, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOfType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l31 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %s0, ptr %t3, i32 %t4, ptr %l2)
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l8, !tbaa !29
  %t10 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } %t12)
  store i32 %t13, ptr %l11
  br label %bb4
bb4:
  %t14 = load i32, ptr %l11, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb8:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i32, ptr %l21, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l22
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t37 = icmp sgt i64 %t35, 1
  store i1 %t37, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l15, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  store i32 %t43, ptr %l27, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l31
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i32, ptr %l27, !tbaa !23
  %t53 = load i32, ptr %l31, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNameErrVal(ptr %v0, ptr %t51, i32 %t52, i32 %t53)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t54 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorTypeHint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/names:Entry"
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/msgs:Nearest"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i1
  %l57 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l97 = alloca ptr
  %l101 = alloca %"compiler/names:Entry"
  %l107 = alloca { i64, ptr }
  %l111 = alloca i1
  %l113 = alloca i1
  %l116 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca i32
  %l131 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v1, ptr %s0, { i64, ptr } %a2)
  store %"compiler/msgs:Nearest" %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load %"compiler/msgs:Nearest", ptr %l19
  %t5 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t4, ptr %t5
  store ptr %t5, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 10
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l24, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l31, !tbaa !24
  store i64 %t42, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb54
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l1, !tbaa !24
  %t66 = icmp ne i64 %t62, %t63
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 10
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l57
  br label %bb15
bb14:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb16
bb15:
  %t78 = load ptr, ptr %l57, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 3
  %t81 = load i1, ptr %t80, !tbaa !21
  %t83 = xor i1 %t81, true
  store i1 %t83, ptr %l52, !tbaa !21
  br label %bb16
bb16:
  %t85 = load i1, ptr %l52, !tbaa !21
  br i1 %t85, label %bb17, label %bb18
bb17:
  br label %bb53
bb18:
  br label %bb19
bb19:
  store i64 0, ptr %l10, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/names:Resolver", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t91, i64 %t92)
  store ptr %t95, ptr %l65
  br label %bb20
bb20:
  %t96 = load ptr, ptr %l65, !tbaa !29
  %t98 = getelementptr %"compiler/names:Table", ptr %t96, i32 0, i32 0
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t98)
  store i64 %t100, ptr %l68
  br label %bb21
bb21:
  %t101 = load i64, ptr %l68, !tbaa !24
  store i64 %t101, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t103 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb22, label %bb23
bb22:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb27
bb24:
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l12, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l75, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb26
bb26:
  %t128 = load i64, ptr %l75, !tbaa !24
  store i64 %t128, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t129 = load i64, ptr %l72, !tbaa !24
  store i64 %t129, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t130 = load i64, ptr %l14, !tbaa !24
  %t131 = load i64, ptr %l13, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb29, label %bb30
bb29:
  br label %bb52
bb30:
  br label %bb31
bb31:
  %t138 = load i64, ptr %l10, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l15, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/names:Resolver", ptr %t151, i32 0, i32 1
  %t154 = load i64, ptr %l9, !tbaa !24
  %t157 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t153, i64 %t154)
  store ptr %t157, ptr %l97
  br label %bb32
bb32:
  %t158 = load ptr, ptr %l97, !tbaa !29
  %t160 = getelementptr %"compiler/names:Table", ptr %t158, i32 0, i32 0
  %t161 = load i64, ptr %l15, !tbaa !24
  %t164 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t161)
  store %"compiler/names:Entry" %t164, ptr %l101
  br label %bb33
bb33:
  %t165 = load %"compiler/names:Entry", ptr %l101
  store %"compiler/names:Entry" %t165, ptr %l16
  %t166 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 2
  %t167 = load i32, ptr %t166, !range !{i32 0, i32 9}
  %t169 = trunc i64 4 to i32
  %t170 = icmp eq i32 %t167, %t169
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb34, label %bb35
bb34:
  br label %bb51
bb35:
  br label %bb36
bb36:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t174, i32 %t176)
  store { i64, ptr } %t179, ptr %l107
  br label %bb37
bb37:
  %t180 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t180, ptr %l17, !tbaa !27
  %t181 = load i64, ptr %l9, !tbaa !24
  %t182 = load i64, ptr %l1, !tbaa !24
  %t185 = icmp ne i64 %t181, %t182
  br i1 %t185, label %bb38, label %bb39
bb38:
  %t187 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t189 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t187)
  store i1 %t189, ptr %l113
  br label %bb40
bb39:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb41
bb40:
  %t190 = load i1, ptr %l113, !tbaa !21
  %t191 = xor i1 %t190, true
  store i1 %t191, ptr %l111, !tbaa !21
  br label %bb41
bb41:
  %t193 = load i1, ptr %l111, !tbaa !21
  br i1 %t193, label %bb42, label %bb43
bb42:
  br label %bb51
bb43:
  br label %bb44
bb44:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l116, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i64, ptr %l9, !tbaa !24
  %t199 = load i64, ptr %l15, !tbaa !24
  %t203 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t197, i64 %t198, i64 %t199)
  store i32 %t203, ptr %l120
  br label %bb45
bb45:
  %t204 = load ptr, ptr %l116, !tbaa !29
  %t205 = load i32, ptr %l120, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t206, ptr %l121
  br label %bb46
bb46:
  %t207 = load i32, ptr %l121, !range !{i32 0, i32 6}
  %t209 = trunc i64 2 to i32
  %t210 = icmp eq i32 %t207, %t209
  br i1 %t210, label %bb47, label %bb48
bb47:
  %t212 = load ptr, ptr %l3, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t212, { i64, ptr } %t213)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t216 = load i64, ptr %l14, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l14, !tbaa !24
  br label %bb28
bb52:
  br label %bb53
bb53:
  %t220 = load i64, ptr %l8, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l8, !tbaa !24
  br label %bb9
bb54:
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t226 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %v2, ptr %t224)
  store { i64, ptr } %t226, ptr %l131
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  %t227 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t227, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorDecl(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t13 = icmp sle i64 0, 2305843009213693951
  br i1 %t13, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_de4c5053baae2eb0_7e20459b6f7605c4)
  unreachable
bb6:
  %t15 = mul i64 0, 4
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_de4c5053baae2eb0_7e20459b6f7605c4)
  unreachable
bb8:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 11}
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t30, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t34, ptr %l12, !tbaa !27
  br label %bb23
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t36 = icmp sge i64 0, 0
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = icmp sle i64 0, 2305843009213693951
  br i1 %t38, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_16d3c7726565025d_3b40f943fadf33d1)
  unreachable
bb20:
  %t40 = mul i64 0, 4
  %t41 = insertvalue { i64, ptr } undef, i64 0, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t42, ptr %l12, !tbaa !27
  br label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_16d3c7726565025d_3b40f943fadf33d1)
  unreachable
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7b14d935e96e16e5_1eebf856974cc301)
  unreachable
bb23:
  %t44 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsHeld(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l50 = alloca i1
  %l54 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l16
  br label %bb4
bb4:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l3
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l20
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l27, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t31
  %t36 = load i32, ptr %t35, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %t36)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l5, !tbaa !24
  br label %bb6
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t47, i32 %t48)
  store { i64, ptr } %t51, ptr %l37
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t52, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb15, label %bb16
bb15:
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t65 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t65, ptr %l44, !tbaa !27
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 %t66
  %t71 = load i32, ptr %t70, !tbaa !33
  store i32 %t71, ptr %l11, !tbaa !23
  %t73 = load i32, ptr %l11, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb21
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l11, !tbaa !23
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentryHeld(ptr %v0, ptr %s0, ptr %t79, i32 %t80, ptr %l3)
  store i1 %t84, ptr %l54
  br label %bb20
bb20:
  %t85 = load i1, ptr %l54, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l50, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l9, !tbaa !24
  br label %bb14
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l27 = alloca i32
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eensureModules(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 24
  %t9 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %a1)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l10
  br label %bb2
bb2:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  %t16 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t16, ptr %rv
  br label %ret
bb5:
  %t17 = load i64, ptr %l6, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l14, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/load:Loader", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t30 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v2, ptr %t26, { i64, ptr } %a2)
  store i32 %t30, ptr %l19
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = load i32, ptr %l19, !tbaa !23
  %t34 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t31, i64 %t32, i32 %t33)
  store i64 %t34, ptr %l20
  br label %bb7
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp slt i64 %t36, 0
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t41 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t41, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t42, i64 %t43, i64 %t44)
  store i32 %t48, ptr %l27
  br label %bb11
bb11:
  %t49 = load i32, ptr %l27, !tbaa !23
  %t50 = insertvalue { i32, i32 } zeroinitializer, i32 %t49, 1
  store { i32, i32 } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i32
  %l20 = alloca %"compiler/generic:fnRow"
  %l23 = alloca %"compiler/generic:Context"
  %l27 = alloca { i64, ptr }
  %l30 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca %"compiler/generic:varRow"
  %l60 = alloca i32
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l74 = alloca i32
  %l77 = alloca %"compiler/generic:Context"
  %s0 = alloca %olang.scope
  %t20 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t1)
  store i64 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t5, i64 %t6)
  store i32 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s0, ptr %t12, i64 %t13)
  store %"compiler/generic:fnRow" %t16, ptr %l20
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/generic:fnRow", ptr %l20, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t20, ptr %v1, i64 %t18, i64 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t20, i64 160, i1 false)
  br label %bb4
bb4:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 160, i64 8)
  store ptr %t23, ptr %lp4
  %t24 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %l23, i64 160, i1 false)
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t27, i32 %a2)
  store { i64, ptr } %t31, ptr %l27
  br label %bb5
bb5:
  %t32 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t33, i64 %t34)
  store i64 %t37, ptr %l30
  br label %bb6
bb6:
  %t38 = load i64, ptr %l30, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l11, !tbaa !24
  %t85 = load ptr, ptr %lp4
  %t86 = getelementptr %"compiler/generic:Context", ptr %t85, i32 0, i32 2
  store ptr %t86, ptr %l55, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t93 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t87, i64 %t88, i64 %t89)
  store %"compiler/generic:varRow" %t93, ptr %l59
  br label %bb17
bb17:
  %t94 = getelementptr %"compiler/generic:varRow", ptr %l59, i32 0, i32 1
  %t95 = load i32, ptr %t94, !tbaa !23
  store i32 %t95, ptr %l60, !tbaa !23
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t104, ptr %l66, !tbaa !27
  %t105 = load i64, ptr %l11, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 %t105
  %t110 = load i32, ptr %t109, !tbaa !33
  store i32 %t110, ptr %l65, !tbaa !23
  br label %bb21
bb19:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i64, ptr %l3, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t114, i64 %t115, i64 %t116, i64 %t117)
  store i32 %t122, ptr %l74
  br label %bb20
bb20:
  %t123 = load i32, ptr %l74, !tbaa !23
  store i32 %t123, ptr %l65, !tbaa !23
  br label %bb21
bb21:
  %t124 = load ptr, ptr %l55, !tbaa !29
  %t125 = load i32, ptr %l60, !tbaa !23
  %t126 = load i32, ptr %l65, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t124, i32 %t125, i32 %t126)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t127 = load i64, ptr %l10, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l10, !tbaa !24
  br label %bb13
bb24:
  %t131 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l77, ptr %t131, i64 160, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l77, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 29
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/generic:fnRow"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l21 = alloca i32
  %l24 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l25 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l35 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i32
  %l42 = alloca i32
  %l46 = alloca %"compiler/generic:fnRow"
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l48 = alloca ptr
  %l53 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l76 = alloca i32
  %l79 = alloca i32
  %l83 = alloca i32
  %l86 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l145 = alloca i64
  %l147 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca i64
  %l152 = alloca i32
  %l153 = alloca i32
  %l154 = alloca i64
  %l157 = alloca { i64, ptr }
  %l162 = alloca %"compiler/generic:instance"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2einstanceArgs(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i32, ptr %l21, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %s0, i64 %t7, i32 %t8)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t11, ptr %l24
  br label %bb2
bb2:
  %t12 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l24
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t12, ptr %l4
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 45
  %t16 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l4
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__Hfc7ca136f786d4bb067f513e5dea5730(ptr %v0, ptr %t15, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l30
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l29
  br label %bb3
bb3:
  %t24 = load i64, ptr %l29, !tbaa !24
  store i64 %t24, ptr %l25, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l25, !tbaa !24
  store i64 %t25, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t32)
  store i64 %t34, ptr %l35
  br label %bb10
bb10:
  %t35 = load i64, ptr %l35, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l36, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t37, i64 %t38)
  store i32 %t41, ptr %l39
  br label %bb11
bb11:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i32, ptr %l3, !tbaa !23
  %t44 = load ptr, ptr %l36, !tbaa !29
  %t45 = load i32, ptr %l39, !tbaa !23
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t44, i32 %t45, i64 %t42, i32 %t43)
  store i32 %t48, ptr %l42
  br label %bb12
bb12:
  %t49 = load i32, ptr %l42, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t52, i64 %t53)
  store %"compiler/generic:fnRow" %t56, ptr %l46
  br label %bb13
bb13:
  %t57 = load %"compiler/generic:fnRow", ptr %l46
  store %"compiler/generic:fnRow" %t57, ptr %l8
  %t58 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t58, ptr %l47
  br label %bb14
bb14:
  %t59 = load %"std/prelude/text:StringBuilder", ptr %l47
  store %"std/prelude/text:StringBuilder" %t59, ptr %l9
  store ptr %l9, ptr %l48, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 10
  %t66 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t65, i64 %t67)
  store ptr %t70, ptr %l53
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l53, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t75, { i64, ptr } %t74)
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 46)
  br label %bb17
bb17:
  %t78 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l62, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l7, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l66
  br label %bb20
bb19:
  br label %bb30
bb20:
  %t98 = load ptr, ptr %l62, !tbaa !29
  %t99 = load i32, ptr %l66, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l67
  br label %bb21
bb21:
  %t101 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t101, ptr %l68, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 0
  %t105 = load i32, ptr %t104, !tbaa !33
  store i32 %t105, ptr %l10, !tbaa !23
  store ptr %l9, ptr %l70, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l72, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l10, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l76
  br label %bb22
bb22:
  %t117 = load i32, ptr %l76, !range !{i32 0, i32 33}
  %t119 = trunc i64 20 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb23, label %bb24
bb23:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l10, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l83
  br label %bb25
bb24:
  %t129 = load i32, ptr %l10, !tbaa !23
  store i32 %t129, ptr %l79, !tbaa !23
  br label %bb26
bb25:
  %t131 = load i32, ptr %l83, !tbaa !23
  store i32 %t131, ptr %l79, !tbaa !23
  br label %bb26
bb26:
  %t133 = inttoptr i64 0 to ptr
  %t134 = load ptr, ptr %l72, !tbaa !29
  %t135 = load i32, ptr %l79, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t133, ptr %t134, i32 %t135)
  store { i64, ptr } %t136, ptr %l86
  br label %bb27
bb27:
  %t137 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t144, { i64, ptr } %t143)
  br label %bb28
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 46)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  store ptr %l9, ptr %l89, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/generic:fnRow", ptr %l8, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/ast:Func", ptr %t149, i32 0, i32 2
  %t152 = load i32, ptr %t151, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t147, i32 %t152)
  store { i64, ptr } %t155, ptr %l93
  br label %bb31
bb31:
  %t156 = load ptr, ptr %l89, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l93, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t156, { i64, ptr } %t157)
  br label %bb32
bb32:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 2
  %t161 = load i32, ptr %l3, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t160, i32 %t161)
  store { i64, ptr } %t164, ptr %l97
  br label %bb33
bb33:
  %t165 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t165, ptr %l11, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = icmp sgt i64 %t168, 0
  br i1 %t170, label %bb34, label %bb35
bb34:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 60)
  br label %bb36
bb35:
  br label %bb56
bb36:
  store i64 0, ptr %l12, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t177 = load i64, ptr %l13, !tbaa !24
  %t178 = load i64, ptr %l12, !tbaa !24
  %t181 = icmp sgt i64 %t177, %t178
  br i1 %t181, label %bb37, label %bb38
bb37:
  %t183 = load i64, ptr %l14, !tbaa !24
  %t185 = icmp sgt i64 %t183, 0
  br i1 %t185, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb42
bb39:
  %t187 = load i64, ptr %l13, !tbaa !24
  %t188 = load i64, ptr %l12, !tbaa !24
  %t191 = sub i64 %t187, %t188
  %t192 = load i64, ptr %l14, !tbaa !24
  %t195 = add i64 %t191, %t192
  %t197 = sub i64 %t195, 1
  %t198 = load i64, ptr %l14, !tbaa !24
  %t201 = sdiv i64 %t197, %t198
  store i64 %t201, ptr %l110, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb41
bb41:
  %t203 = load i64, ptr %l110, !tbaa !24
  store i64 %t203, ptr %l107, !tbaa !24
  br label %bb42
bb42:
  %t204 = load i64, ptr %l107, !tbaa !24
  store i64 %t204, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t205 = load i64, ptr %l16, !tbaa !24
  %t206 = load i64, ptr %l15, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb45:
  br label %bb46
bb46:
  %t213 = load i64, ptr %l12, !tbaa !24
  %t214 = load i64, ptr %l16, !tbaa !24
  %t215 = load i64, ptr %l14, !tbaa !24
  %t218 = mul i64 %t214, %t215
  %t221 = add i64 %t213, %t218
  store i64 %t221, ptr %l17, !tbaa !24
  %t223 = load i64, ptr %l17, !tbaa !24
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  store ptr %l9, ptr %l131, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 2
  %t231 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t231, ptr %l134, !tbaa !27
  %t232 = load i64, ptr %l17, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  %t239 = inttoptr i64 0 to ptr
  %t242 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s5, ptr %t239, ptr %t230, i32 %t237)
  store { i64, ptr } %t242, ptr %l138
  br label %bb51
bb51:
  %t243 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 0
  %t245 = extractvalue { i64, ptr } %t243, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  %t250 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t250, { i64, ptr } %t249)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb53:
  %t252 = load i64, ptr %l16, !tbaa !24
  %t254 = add i64 %t252, 1
  store i64 %t254, ptr %l16, !tbaa !24
  br label %bb43
bb54:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 62)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 44
  %t261 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eLen_Hf1590ba3dea8cd8a914b2a9f5344a2c6(ptr %v0, ptr %t259)
  store i64 %t261, ptr %l145
  br label %bb57
bb57:
  %t262 = load i64, ptr %l145, !tbaa !24
  store i64 %t262, ptr %l5, !tbaa !24
  %t264 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l9)
  store { i64, ptr } %t264, ptr %l147
  br label %bb58
bb58:
  %t265 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  %t267 = extractvalue { i64, ptr } %t265, 1
  %t268 = mul i64 %t266, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t268)
  call void @llvm.memcpy.p0.p0.i64(ptr %t269, ptr %t267, i64 %t268, i1 false)
  %t270 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l18, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 44
  store ptr %t275, ptr %l150, !tbaa !29
  %t276 = load i64, ptr %l1, !tbaa !24
  store i64 %t276, ptr %l151, !tbaa !24
  %t277 = load i32, ptr %l3, !tbaa !23
  store i32 %t277, ptr %l152, !tbaa !23
  %t278 = load i32, ptr %l7, !tbaa !23
  store i32 %t278, ptr %l153, !tbaa !23
  %t279 = ptrtoint ptr %v0 to i64
  store i64 %t279, ptr %l154, !tbaa !24
  %t280 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3ainstance_2e3
  br i1 %t280, label %bb59, label %bb60
bb59:
  %t282 = call ptr @__olang_region_make(ptr %v0)
  %t283 = ptrtoint ptr %t282 to i64
  store i64 %t283, ptr %l154, !tbaa !24
  br label %bb60
bb60:
  %t284 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t285 = load i64, ptr %l154
  %t286 = inttoptr i64 %t285 to ptr
  %t288 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %t286, { i64, ptr } %t284)
  store { i64, ptr } %t288, ptr %l157
  br label %bb61
bb61:
  %t289 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t290 = load i64, ptr %l154
  %t291 = inttoptr i64 %t290 to ptr
  %t292 = extractvalue { i64, ptr } %t289, 0
  %t293 = extractvalue { i64, ptr } %t289, 1
  %t294 = mul i64 %t292, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %t291, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  %t298 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/generic:Program", ptr %t299, i32 0, i32 51
  %t302 = load %"compiler/generic:Origin", ptr %t301
  %t303 = load i64, ptr %l151, !tbaa !24
  %t304 = load i32, ptr %l152, !tbaa !23
  %t305 = load i32, ptr %l153, !tbaa !23
  %t309 = call %"compiler/generic:instance" @compiler_2fgeneric_3ainstance_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t303, i32 %t304, i32 %t305, { i64, ptr } %t297, { i64, ptr } %t298, %"compiler/generic:Origin" %t302)
  store %"compiler/generic:instance" %t309, ptr %l162
  br label %bb62
bb62:
  %t310 = load ptr, ptr %l150, !tbaa !29
  %t311 = load %"compiler/generic:instance", ptr %l162
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2ePus_Hca36cd1c69200a0db62aadeba49cf6ed(ptr %v0, ptr %v0, ptr %t310, %"compiler/generic:instance" %t311)
  br label %bb63
bb63:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/generic:Program", ptr %t312, i32 0, i32 45
  %t315 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l4
  %t316 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5edca056502a242264473f986489341f(ptr %v0, ptr %t314, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t315, i64 %t316)
  br label %bb64
bb64:
  %t320 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t320, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/generic:fnRow"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/generic:fnRow"
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l30 = alloca i32
  %l34 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/generic:fnRow" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:fnRow", ptr %l13
  store %"compiler/generic:fnRow" %t8, ptr %l2
  %t9 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t10, ptr %l3
  store ptr %l3, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 10
  %t17 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t16, i64 %t18)
  store ptr %t21, ptr %l20
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t26 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t26, { i64, ptr } %t25)
  br label %bb4
bb4:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 58)
  br label %bb5
bb5:
  %t29 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Func", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %t39, i64 %t40)
  store i32 %t43, ptr %l30
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t44 = load i32, ptr %l30, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb9
bb9:
  %t52 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb10, label %bb11
bb10:
  store ptr %l3, ptr %l37, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l38, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  store ptr %t60, ptr %l40, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l44
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t68 = load ptr, ptr %l40, !tbaa !29
  %t69 = load i32, ptr %l44, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l45
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = load i32, ptr %l45, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l46
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l46, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t74, { i64, ptr } %t75)
  br label %bb15
bb15:
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 46)
  br label %bb17
bb17:
  br label %bb18
bb18:
  store ptr %l3, ptr %l48, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t77, i32 %t82)
  store { i64, ptr } %t85, ptr %l52
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l52, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t86, { i64, ptr } %t87)
  br label %bb20
bb20:
  store i64 -3750763034362895579, ptr %l5, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s3, ptr %l3)
  store { i64, ptr } %t89, ptr %l54
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = load i64, ptr %l5, !tbaa !24
  %t121 = zext i8 %t116 to i64
  %t124 = xor i64 %t118, %t121
  %t126 = mul i64 %t124, 1099511628211
  store i64 %t126, ptr %l5, !tbaa !24
  br label %bb26
bb26:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb22
bb27:
  call void @__olang_scope_close(ptr %s3)
  %t132 = load i64, ptr %l5, !tbaa !24
  %t134 = and i64 %t132, 4611686018427387903
  call void @__olang_scope_close(ptr %s0)
  store i64 %t134, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/generic:folded"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:ConstAsk"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l15 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l20 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l33 = alloca %"compiler/generic:folded"
  %l37 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l64 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca %"compiler/generic:ConstAsk"
  %l82 = alloca i1
  %l89 = alloca i64
  %l95 = alloca i64
  %l101 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l102 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l104 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l105 = alloca i32
  %l107 = alloca i1
  %l110 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l129 = alloca %"compiler/generic:ConstAsk"
  %l131 = alloca i32
  %l135 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i1
  %l144 = alloca i1
  %l148 = alloca i1
  %l150 = alloca i1
  %l152 = alloca i1
  %l158 = alloca i1
  %l162 = alloca i1
  %l166 = alloca i1
  %l175 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereadsLocal(ptr %v0, ptr %v1, ptr %v2, ptr %t5, ptr %t6, ptr %t7)
  store i1 %t12, ptr %l25
  br label %bb3
bb3:
  %t13 = load i1, ptr %l25, !tbaa !21
  store i1 %t13, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l20, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t20, ptr %l29
  br label %bb8
bb8:
  %t21 = load i32, ptr %l29, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t28 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t22, ptr %t23, ptr %t24)
  store %"compiler/generic:folded" %t28, ptr %l33
  br label %bb9
bb9:
  %t29 = load %"compiler/generic:folded", ptr %l33
  store %"compiler/generic:folded" %t29, ptr %l4
  %t30 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 0
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Context", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb16
bb12:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb15
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2evarsBound(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store i1 %t48, ptr %l44
  br label %bb14
bb14:
  %t49 = load i1, ptr %l44, !tbaa !21
  store i1 %t49, ptr %l41, !tbaa !21
  br label %bb15
bb15:
  %t50 = load i1, ptr %l41, !tbaa !21
  store i1 %t50, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l37, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t58 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t52, ptr %t53, ptr %t54)
  store { i64, ptr } %t58, ptr %l48
  br label %bb19
bb18:
  br label %bb68
bb19:
  %t59 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l5, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 54
  %t70 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t69, { i64, ptr } %t70)
  store i1 %t73, ptr %l53
  br label %bb20
bb20:
  %t74 = load i1, ptr %l53, !tbaa !21
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 54
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t77, { i64, ptr } %t78)
  %t82 = extractvalue { i32, i64 } %t81, 1
  %t83 = extractvalue { i32, i64 } %t81, 0
  store i32 %t83, ptr %l59
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb24, label %ok.85, !prof !99
ok.85:
  store i64 %t82, ptr %l58
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t86 = load i64, ptr %l58, !tbaa !24
  store i64 %t86, ptr %l54, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  %t87 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  store i64 %t87, ptr %l54, !tbaa !24
  br label %bb26
bb26:
  %t89 = load i64, ptr %l54, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  %t94 = icmp eq i64 %t90, %t91
  br i1 %t94, label %bb27, label %bb28
bb27:
  store i32 0, ptr %l64, !tbaa !23
  br label %bb30
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l3, !tbaa !23
  %t100 = load i64, ptr %l6, !tbaa !24
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t98, i32 %t99, i64 %t100)
  store i32 %t104, ptr %l69
  br label %bb29
bb29:
  %t105 = load i32, ptr %l69, !tbaa !23
  store i32 %t105, ptr %l64, !tbaa !23
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t106 = load i32, ptr %l64, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
bb31:
  store i1 false, ptr %l7, !tbaa !21
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 55
  store ptr %t109, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb32
bb32:
  %t111 = load i64, ptr %l9, !tbaa !24
  store i64 %t111, ptr %l72, !tbaa !24
  %t112 = load ptr, ptr %l8, !tbaa !29
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l74
  br label %bb33
bb33:
  %t115 = load i64, ptr %l72, !tbaa !24
  %t116 = load i64, ptr %l74, !tbaa !24
  %t117 = icmp slt i64 %t115, %t116
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb34, label %bb35
bb34:
  br label %bb43
bb35:
  br label %bb36
bb36:
  %t121 = load ptr, ptr %l8, !tbaa !29
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = call %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v0, ptr %v0, ptr %t121, i64 %t122)
  store %"compiler/generic:ConstAsk" %t125, ptr %l79
  br label %bb37
bb37:
  %t126 = load %"compiler/generic:ConstAsk", ptr %l79
  store %"compiler/generic:ConstAsk" %t126, ptr %l10
  %t127 = getelementptr %"compiler/generic:ConstAsk", ptr %l10, i32 0, i32 6
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t128, { i64, ptr } %t129)
  store i1 %t132, ptr %l82
  br label %bb38
bb38:
  %t133 = load i1, ptr %l82, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb32
bb43:
  %t138 = load i1, ptr %l7, !tbaa !21
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb44, label %bb45
bb44:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Context", ptr %t142, i32 0, i32 2
  %t146 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v1, ptr %t144)
  store i64 %t146, ptr %l89
  br label %bb46
bb45:
  br label %bb66
bb46:
  %t147 = load i64, ptr %l89, !tbaa !24
  %t148 = icmp sge i64 %t147, 0
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load i64, ptr %l89, !tbaa !24
  %t151 = icmp sle i64 %t150, 2305843009213693951
  br i1 %t151, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_99cf014ebb3d252c_a323a427e7fb0b10)
  unreachable
bb49:
  %t153 = load i64, ptr %l89, !tbaa !24
  %t154 = mul i64 %t153, 4
  %t155 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t154)
  %t156 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  store { i64, ptr } %t157, ptr %l11, !tbaa !27
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Context", ptr %t159, i32 0, i32 2
  %t163 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v1, ptr %t161)
  store i64 %t163, ptr %l95
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_99cf014ebb3d252c_a323a427e7fb0b10)
  unreachable
bb51:
  %t164 = load i64, ptr %l95, !tbaa !24
  %t165 = icmp sge i64 %t164, 0
  br i1 %t165, label %bb52, label %bb53
bb52:
  %t167 = load i64, ptr %l95, !tbaa !24
  %t168 = icmp sle i64 %t167, 2305843009213693951
  br i1 %t168, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_9c491d6513909eb9_b2019bc0b634333d)
  unreachable
bb54:
  %t170 = load i64, ptr %l95, !tbaa !24
  %t171 = mul i64 %t170, 4
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/generic:Context", ptr %t176, i32 0, i32 2
  %t180 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v1, ptr %v1, ptr %t178)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t180, ptr %l101
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_9c491d6513909eb9_b2019bc0b634333d)
  unreachable
bb56:
  %t181 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l101
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t181, ptr %l14
  br label %bb57
bb57:
  %t183 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v1, ptr %l14)
  %t184 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t183, 1
  %t185 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t183, 0
  store i32 %t185, ptr %l105
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb59, label %ok.187, !prof !99
ok.187:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t184, ptr %l104
  br label %bb58
bb58:
  %t188 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l104
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t188, ptr %l102
  br label %bb61
bb59:
  %t189 = load i32, ptr %l105, !tbaa !23
  %t190 = ashr i32 %t189, 16
  %t192 = icmp eq i32 %t190, 1
  store i1 %t192, ptr %l107, !tbaa !21
  br label %bb60
bb60:
  br label %bb63
bb61:
  %t193 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l102
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t193, ptr %l15
  %t194 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l15, i32 0, i32 0
  %t195 = load i32, ptr %t194, !tbaa !23
  %t197 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l15, i32 0, i32 1
  %t198 = load i32, ptr %t197, !tbaa !23
  %t200 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t200, ptr %l110, !tbaa !27
  %t201 = load i64, ptr %l13, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i32, ptr %t206, i64 %t201
  store i32 %t195, ptr %t207, !tbaa !33
  %t208 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t208, ptr %l113, !tbaa !27
  %t209 = load i64, ptr %l13, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr i32, ptr %t214, i64 %t209
  store i32 %t198, ptr %t215, !tbaa !33
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l13, !tbaa !24
  br label %bb62
bb62:
  br label %bb57
bb63:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 55
  store ptr %t222, ptr %l119, !tbaa !29
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Context", ptr %t223, i32 0, i32 0
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t228 = load i32, ptr %l3, !tbaa !23
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr %"compiler/generic:Context", ptr %t229, i32 0, i32 1
  %t232 = load i64, ptr %t231, !tbaa !24
  %t233 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t243 = call %"compiler/generic:ConstAsk" @compiler_2fgeneric_3aConstAsk_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t226, ptr %t227, i32 %t228, i64 %t232, { i64, ptr } %t233, { i64, ptr } %t234, { i64, ptr } %t235)
  store %"compiler/generic:ConstAsk" %t243, ptr %l129
  br label %bb64
bb64:
  %t244 = load ptr, ptr %l119, !tbaa !29
  %t245 = load %"compiler/generic:ConstAsk", ptr %l129
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ePus_H9314813d35e39659e36ddfdc05758427(ptr %v0, ptr %v0, ptr %t244, %"compiler/generic:ConstAsk" %t245)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnknownConst(ptr %v0, ptr %t246)
  store i32 %t248, ptr %l131
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t249 = load i32, ptr %l131, !tbaa !23
  store i32 %t249, ptr %rv
  br label %ret
bb68:
  %t250 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 0
  %t251 = load i64, ptr %t250, !tbaa !24
  %t252 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t255 = icmp eq i64 %t251, %t252
  br i1 %t255, label %bb69, label %bb70
bb69:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 2
  %t260 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t261 = load i32, ptr %t260, !tbaa !23
  %t264 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t259, i32 %t261)
  store i1 %t264, ptr %l139
  br label %bb71
bb70:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb72
bb71:
  %t265 = load i1, ptr %l139, !tbaa !21
  store i1 %t265, ptr %l135, !tbaa !21
  br label %bb72
bb72:
  %t266 = load i1, ptr %l135, !tbaa !21
  br i1 %t266, label %bb73, label %bb74
bb73:
  %t267 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t268 = load i32, ptr %t267, !tbaa !23
  %t269 = load i32, ptr %l3, !tbaa !23
  %t272 = icmp ne i32 %t268, %t269
  store i1 %t272, ptr %l140, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb75
bb75:
  %t274 = load i1, ptr %l140, !tbaa !21
  br i1 %t274, label %bb76, label %bb77
bb76:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t277 = load i32, ptr %t276, !tbaa !23
  %t278 = load i32, ptr %l3, !tbaa !23
  %t282 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t275, i32 %t277, i32 %t278)
  store i1 %t282, ptr %l148
  br label %bb78
bb77:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb79
bb78:
  %t283 = load i1, ptr %l148, !tbaa !21
  %t284 = xor i1 %t283, true
  store i1 %t284, ptr %l144, !tbaa !21
  br label %bb79
bb79:
  %t286 = load i1, ptr %l144, !tbaa !21
  br i1 %t286, label %bb80, label %bb81
bb80:
  %t287 = load ptr, ptr %l2, !tbaa !29
  %t289 = call i1 @compiler_2fgeneric_2elitOnly(ptr %v2, ptr %t287)
  store i1 %t289, ptr %l152
  br label %bb82
bb81:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb83
bb82:
  %t290 = load i1, ptr %l152, !tbaa !21
  %t291 = xor i1 %t290, true
  store i1 %t291, ptr %l150, !tbaa !21
  br label %bb83
bb83:
  %t293 = load i1, ptr %l150, !tbaa !21
  br i1 %t293, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t295 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 0
  %t296 = load i64, ptr %t295, !tbaa !24
  %t297 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t300 = icmp eq i64 %t296, %t297
  br i1 %t300, label %bb87, label %bb88
bb87:
  %t302 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t303 = load i32, ptr %t302, !tbaa !23
  %t304 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t307 = icmp ne i32 %t303, %t304
  store i1 %t307, ptr %l158, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb89
bb89:
  %t309 = load i1, ptr %l158, !tbaa !21
  br i1 %t309, label %bb90, label %bb91
bb90:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/generic:Program", ptr %t310, i32 0, i32 2
  %t313 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t314 = load i32, ptr %t313, !tbaa !23
  %t317 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t312, i32 %t314)
  store i1 %t317, ptr %l166
  br label %bb92
bb91:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb93
bb92:
  %t318 = load i1, ptr %l166, !tbaa !21
  %t319 = xor i1 %t318, true
  store i1 %t319, ptr %l162, !tbaa !21
  br label %bb93
bb93:
  %t321 = load i1, ptr %l162, !tbaa !21
  br i1 %t321, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb95:
  br label %bb96
bb96:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t325 = load %"compiler/generic:folded", ptr %l4
  %t326 = load i32, ptr %l3, !tbaa !23
  %t327 = load ptr, ptr %l2, !tbaa !29
  %t334 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstOf(ptr %v0, ptr %v1, ptr %v2, ptr %t323, ptr %t324, %"compiler/generic:folded" %t325, i32 %t326, ptr %t327)
  store i32 %t334, ptr %l175
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s0)
  %t335 = load i32, ptr %l175, !tbaa !23
  store i32 %t335, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l9 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i32
  %l30 = alloca i32
  %l37 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edescDecl(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t9 = icmp slt i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t19, i64 %t20)
  store i32 %t23, ptr %l19
  br label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t24, i64 %t25, i32 %t26)
  store i32 %t30, ptr %l23
  br label %bb8
bb7:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l16, !tbaa !23
  br label %bb9
bb8:
  %t32 = load i32, ptr %l23, !tbaa !23
  store i32 %t32, ptr %l16, !tbaa !23
  br label %bb9
bb9:
  %t33 = load i32, ptr %l16, !tbaa !23
  store i32 %t33, ptr %l5, !tbaa !23
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t38 = icmp ne i32 %t34, %t35
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i32, ptr %l3, !tbaa !23
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderSig(ptr %v0, ptr %t40, i64 %t41, i32 %t42)
  store i32 %t46, ptr %l30
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t47 = load i32, ptr %l30, !tbaa !23
  store i32 %t47, ptr %l5, !tbaa !23
  br label %bb13
bb13:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t52 = icmp eq i32 %t48, %t49
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t54, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnKey(ptr %v0, ptr %t56, i64 %t57)
  store i64 %t60, ptr %l37
  br label %bb17
bb17:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 31
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t64, i64 %t65, i64 %t66)
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l42, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  store i32 %t71, ptr %l43, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  store ptr %t74, ptr %l45, !tbaa !29
  %t75 = load i32, ptr %l5, !tbaa !23
  store i32 %t75, ptr %l46, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l48, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t81, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t83, ptr %l51
  br label %bb19
bb19:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load ptr, ptr %l48, !tbaa !29
  %t86 = load i32, ptr %l51, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t85, i32 %t86, i64 %t84)
  store i32 %t88, ptr %l53
  br label %bb20
bb20:
  %t89 = mul i64 2, 4
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 2, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i32, ptr %t95, i64 0
  store i32 %t93, ptr %t96, !tbaa !33
  %t97 = load i32, ptr %l53, !tbaa !23
  %t98 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 1
  store i32 %t97, ptr %t100, !tbaa !33
  %t101 = load ptr, ptr %l45, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t101, { i64, ptr } %t102)
  store i32 %t103, ptr %l55
  br label %bb21
bb21:
  %t104 = load ptr, ptr %l42, !tbaa !29
  %t105 = load i32, ptr %l43, !tbaa !23
  %t106 = load i32, ptr %l55, !tbaa !23
  %t107 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t104, i32 %t105, i32 %t106)
  store i32 %t107, ptr %l56
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i32, ptr %l56, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 5
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = sext i32 %t23 to i64
  %t25 = load ptr, ptr %l10, !tbaa !29
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3993e9d21a27b6abd527556382000d9e(ptr %v0, ptr %t25, i64 %t24)
  store i1 %t27, ptr %l16
  br label %bb5
bb5:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l8, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHeld(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eheld(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l34 = alloca i32
  %l40 = alloca i64
  %l43 = alloca i1
  %l47 = alloca i64
  %l55 = alloca i32
  %l59 = alloca i32
  %l69 = alloca i1
  %l78 = alloca i1
  %l81 = alloca ptr
  %l85 = alloca i32
  %l90 = alloca i1
  %l96 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l117 = alloca i1
  %l125 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca { i64, ptr }
  %l138 = alloca i32
  %l141 = alloca i32
  %l147 = alloca i64
  %l150 = alloca i64
  %l169 = alloca { i64, ptr }
  %l176 = alloca i1
  %l180 = alloca i1
  %l184 = alloca ptr
  %l188 = alloca i32
  %l189 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l200 = alloca i32
  %l202 = alloca i64
  %l206 = alloca i1
  %l211 = alloca ptr
  %l215 = alloca i32
  %l216 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l228 = alloca i1
  %l229 = alloca ptr
  %l230 = alloca i32
  %l232 = alloca i64
  %l236 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l34
  br label %bb4
bb4:
  %t13 = load i32, ptr %l34, !range !{i32 0, i32 33}
  store i32 %t13, ptr %l5
  %t14 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t16 = trunc i64 25 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l40
  br label %bb8
bb8:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l40, !tbaa !24
  %t29 = icmp eq i64 %t27, %t26
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t33, i32 %t34)
  store i64 %t37, ptr %l47
  br label %bb11
bb10:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb12
bb11:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l47, !tbaa !24
  %t41 = icmp eq i64 %t39, %t38
  store i1 %t41, ptr %l43, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l43, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
bb13:
  %t44 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t46 = trunc i64 20 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l1, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l55
  br label %bb17
bb17:
  %t56 = load i32, ptr %l55, !tbaa !23
  store i32 %t56, ptr %l6, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l59
  br label %bb18
bb18:
  %t64 = load i32, ptr %l59, !range !{i32 0, i32 33}
  %t66 = trunc i64 25 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l6, !tbaa !23
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l4, !tbaa !24
  %t76 = add i64 %t74, 1
  %t82 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t70, i32 %t71, i64 %t72, i64 %t73, i64 %t76)
  store i1 %t82, ptr %l69
  br label %bb22
bb22:
  %t83 = load i1, ptr %l69, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb23:
  %t84 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t86 = trunc i64 21 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t91 = load i64, ptr %l2, !tbaa !24
  %t92 = load i64, ptr %l3, !tbaa !24
  %t93 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t93, 1
  %t101 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t89, i32 %t90, i64 %t91, i64 %t92, i64 %t95)
  store i1 %t101, ptr %l78
  br label %bb27
bb27:
  %t102 = load i1, ptr %l78, !tbaa !21
  store i1 %t102, ptr %rv
  br label %ret
bb28:
  %t103 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t105 = trunc i64 19 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l81, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l1, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l85
  br label %bb32
bb32:
  %t116 = load i64, ptr %l2, !tbaa !24
  %t117 = load i64, ptr %l3, !tbaa !24
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = add i64 %t118, 1
  %t121 = load ptr, ptr %l81, !tbaa !29
  %t122 = load i32, ptr %l85, !tbaa !23
  %t126 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t121, i32 %t122, i64 %t116, i64 %t117, i64 %t120)
  store i1 %t126, ptr %l90
  br label %bb33
bb33:
  %t127 = load i1, ptr %l90, !tbaa !21
  store i1 %t127, ptr %rv
  br label %ret
bb34:
  %t128 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t130 = trunc i64 22 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb35, label %bb36
bb35:
  br label %bb39
bb36:
  %t133 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t135 = trunc i64 23 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb52
bb39:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  store ptr %t140, ptr %l96, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l1, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l100
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l96, !tbaa !29
  %t149 = load i32, ptr %l100, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t148, i32 %t149)
  store { i64, ptr } %t150, ptr %l101
  br label %bb41
bb41:
  %t151 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t151, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  store i64 %t154, ptr %l9, !tbaa !24
  br label %bb42
bb42:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t157 = load i64, ptr %l9, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb43, label %bb44
bb43:
  br label %bb51
bb44:
  br label %bb45
bb45:
  %t164 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t164, ptr %l108, !tbaa !27
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i32, ptr %t168, i64 %t165
  %t170 = load i32, ptr %t169, !tbaa !33
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l2, !tbaa !24
  %t175 = load i64, ptr %l3, !tbaa !24
  %t176 = load i64, ptr %l4, !tbaa !24
  %t178 = add i64 %t176, 1
  %t184 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t172, i32 %t170, i64 %t174, i64 %t175, i64 %t178)
  store i1 %t184, ptr %l117
  br label %bb46
bb46:
  %t185 = load i1, ptr %l117, !tbaa !21
  br i1 %t185, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t187 = load i64, ptr %l8, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l8, !tbaa !24
  br label %bb42
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  %t192 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t194 = trunc i64 18 to i32
  %t195 = icmp eq i32 %t192, %t194
  br i1 %t195, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb112
bb55:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 2
  store ptr %t199, ptr %l125, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l1, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l129
  br label %bb56
bb56:
  %t207 = load ptr, ptr %l125, !tbaa !29
  %t208 = load i32, ptr %l129, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l130
  br label %bb57
bb57:
  %t210 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t210, ptr %l11, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t215 = icmp eq i64 %t213, 0
  br i1 %t215, label %bb58, label %bb59
bb58:
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 2
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t220, i32 %t221)
  store i32 %t224, ptr %l138
  br label %bb61
bb61:
  %t225 = load i32, ptr %l138, !tbaa !23
  store i32 %t225, ptr %l12, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i32, ptr %l12, !tbaa !23
  %t230 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t230, ptr %l141
  br label %bb62
bb62:
  %t231 = load i32, ptr %l141, !tbaa !23
  store i32 %t231, ptr %l13, !tbaa !23
  store i64 0, ptr %l14, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 0
  store i64 %t234, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t236 = load i64, ptr %l15, !tbaa !24
  %t237 = load i64, ptr %l14, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb63, label %bb64
bb63:
  %t242 = load i64, ptr %l16, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb68
bb65:
  %t246 = load i64, ptr %l15, !tbaa !24
  %t247 = load i64, ptr %l14, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l16, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l16, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l150, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb67
bb67:
  %t262 = load i64, ptr %l150, !tbaa !24
  store i64 %t262, ptr %l147, !tbaa !24
  br label %bb68
bb68:
  %t263 = load i64, ptr %l147, !tbaa !24
  store i64 %t263, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb69
bb69:
  %t264 = load i64, ptr %l18, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb70, label %bb71
bb70:
  br label %bb111
bb71:
  br label %bb72
bb72:
  %t272 = load i64, ptr %l14, !tbaa !24
  %t273 = load i64, ptr %l18, !tbaa !24
  %t274 = load i64, ptr %l16, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l19, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t283, ptr %l169, !tbaa !27
  %t284 = load i64, ptr %l19, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr i32, ptr %t287, i64 %t284
  %t289 = load i32, ptr %t288, !tbaa !33
  %t290 = load i64, ptr %l2, !tbaa !24
  %t291 = load i64, ptr %l3, !tbaa !24
  %t292 = load i64, ptr %l4, !tbaa !24
  %t294 = add i64 %t292, 1
  %t300 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t282, i32 %t289, i64 %t290, i64 %t291, i64 %t294)
  store i1 %t300, ptr %l176
  br label %bb73
bb73:
  %t301 = load i1, ptr %l176, !tbaa !21
  %t302 = xor i1 %t301, true
  br i1 %t302, label %bb74, label %bb75
bb74:
  br label %bb110
bb75:
  br label %bb76
bb76:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i32, ptr %l13, !tbaa !23
  %t308 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t304, i32 %t305)
  store i1 %t308, ptr %l180
  br label %bb77
bb77:
  %t309 = load i1, ptr %l180, !tbaa !21
  %t310 = xor i1 %t309, true
  br i1 %t310, label %bb78, label %bb79
bb78:
  store i1 true, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/generic:Program", ptr %t313, i32 0, i32 2
  store ptr %t315, ptr %l184, !tbaa !29
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/generic:Program", ptr %t316, i32 0, i32 2
  %t319 = load i32, ptr %l13, !tbaa !23
  %t322 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t318, i32 %t319)
  store i32 %t322, ptr %l188
  br label %bb81
bb81:
  %t323 = load ptr, ptr %l184, !tbaa !29
  %t324 = load i32, ptr %l188, !tbaa !23
  %t325 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t323, i32 %t324)
  store { i64, ptr } %t325, ptr %l189
  br label %bb82
bb82:
  %t326 = load { i64, ptr }, ptr %l189, !tbaa !27
  store { i64, ptr } %t326, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t327 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  store i64 %t329, ptr %l22, !tbaa !24
  br label %bb83
bb83:
  %t331 = load i64, ptr %l21, !tbaa !24
  %t332 = load i64, ptr %l22, !tbaa !24
  %t335 = icmp slt i64 %t331, %t332
  %t337 = xor i1 %t335, true
  br i1 %t337, label %bb84, label %bb85
bb84:
  br label %bb93
bb85:
  br label %bb86
bb86:
  %t339 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t339, ptr %l196, !tbaa !27
  %t340 = load i64, ptr %l21, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr i32, ptr %t343, i64 %t340
  %t345 = load i32, ptr %t344, !tbaa !33
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l199, !tbaa !29
  store i32 %t345, ptr %l200, !tbaa !23
  %t349 = load i32, ptr %l12, !tbaa !23
  %t351 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t349)
  store i64 %t351, ptr %l202
  br label %bb87
bb87:
  %t352 = load i64, ptr %l19, !tbaa !24
  %t353 = load i64, ptr %l4, !tbaa !24
  %t355 = add i64 %t353, 1
  %t356 = load ptr, ptr %l199, !tbaa !29
  %t357 = load i32, ptr %l200, !tbaa !23
  %t358 = load i64, ptr %l202, !tbaa !24
  %t361 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t356, i32 %t357, i64 %t358, i64 %t352, i64 %t355)
  store i1 %t361, ptr %l206
  br label %bb88
bb88:
  %t362 = load i1, ptr %l206, !tbaa !21
  br i1 %t362, label %bb89, label %bb90
bb89:
  store i1 true, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t364 = load i64, ptr %l21, !tbaa !24
  %t366 = add i64 %t364, 1
  store i64 %t366, ptr %l21, !tbaa !24
  br label %bb83
bb93:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/generic:Program", ptr %t368, i32 0, i32 2
  store ptr %t370, ptr %l211, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/generic:Program", ptr %t371, i32 0, i32 2
  %t374 = load i32, ptr %l13, !tbaa !23
  %t377 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t373, i32 %t374)
  store i32 %t377, ptr %l215
  br label %bb94
bb94:
  %t378 = load ptr, ptr %l211, !tbaa !29
  %t379 = load i32, ptr %l215, !tbaa !23
  %t380 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t378, i32 %t379)
  store { i64, ptr } %t380, ptr %l216
  br label %bb95
bb95:
  %t381 = load { i64, ptr }, ptr %l216, !tbaa !27
  store { i64, ptr } %t381, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t382 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t382, 0
  store i64 %t384, ptr %l26, !tbaa !24
  br label %bb96
bb96:
  %t386 = load i64, ptr %l25, !tbaa !24
  %t387 = load i64, ptr %l26, !tbaa !24
  %t390 = icmp slt i64 %t386, %t387
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb97, label %bb98
bb97:
  br label %bb109
bb98:
  br label %bb99
bb99:
  %t394 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t394, ptr %l223, !tbaa !27
  %t395 = load i64, ptr %l25, !tbaa !24
  %t397 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !27
  %t399 = getelementptr i32, ptr %t398, i64 %t395
  %t400 = load i32, ptr %t399, !tbaa !33
  store i32 %t400, ptr %l27, !tbaa !23
  %t402 = load i32, ptr %l27, !tbaa !23
  %t404 = icmp ne i32 %t402, 0
  br i1 %t404, label %bb100, label %bb101
bb100:
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l229, !tbaa !29
  %t407 = load i32, ptr %l27, !tbaa !23
  store i32 %t407, ptr %l230, !tbaa !23
  %t408 = load i32, ptr %l12, !tbaa !23
  %t410 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t408)
  store i64 %t410, ptr %l232
  br label %bb102
bb101:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb104
bb102:
  %t411 = load i64, ptr %l19, !tbaa !24
  %t412 = load i64, ptr %l4, !tbaa !24
  %t414 = add i64 %t412, 1
  %t415 = load ptr, ptr %l229, !tbaa !29
  %t416 = load i32, ptr %l230, !tbaa !23
  %t417 = load i64, ptr %l232, !tbaa !24
  %t420 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t415, i32 %t416, i64 %t417, i64 %t411, i64 %t414)
  store i1 %t420, ptr %l236
  br label %bb103
bb103:
  %t421 = load i1, ptr %l236, !tbaa !21
  store i1 %t421, ptr %l228, !tbaa !21
  br label %bb104
bb104:
  %t422 = load i1, ptr %l228, !tbaa !21
  br i1 %t422, label %bb105, label %bb106
bb105:
  store i1 true, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t424 = load i64, ptr %l25, !tbaa !24
  %t426 = add i64 %t424, 1
  store i64 %t426, ptr %l25, !tbaa !24
  br label %bb96
bb109:
  br label %bb110
bb110:
  %t428 = load i64, ptr %l18, !tbaa !24
  %t430 = add i64 %t428, 1
  store i64 %t430, ptr %l18, !tbaa !24
  br label %bb69
bb111:
  store i1 false, ptr %rv
  br label %ret
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  store i1 false, ptr %rv
  br label %ret
bb116:
  call void @__olang_check_failed(ptr @olang_loc_f85b3d57f52ff5f3_99e1343e21fb4c8f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i64
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t3, i32 %t4, i32 %t5)
  store i32 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDepth(ptr %v0, ptr %t13, i32 %t14)
  store i64 %t17, ptr %l12
  br label %bb2
bb2:
  %t18 = load i64, ptr @G_2ecompiler_2fgeneric_2eMaxDepth, !tbaa !24
  %t20 = add i64 %t18, 1
  %t21 = load i64, ptr %l12, !tbaa !24
  %t23 = icmp sgt i64 %t21, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunbounded(ptr %v0, ptr %t25, i32 %t26)
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
bb6:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = icmp ne i32 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 51
  %t38 = getelementptr %"compiler/generic:Origin", ptr %t37, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 52
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hf7241cd153db7dbb97afc4b39a688af4(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l29
  br label %bb12
bb11:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t54 = load i1, ptr %l25, !tbaa !21
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 52
  %t58 = load i32, ptr %l3, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 51
  %t62 = load %"compiler/generic:Origin", ptr %t61
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H52a70901e2e6ceea4e17edd807bbe24b(ptr %v0, ptr %t57, i32 %t58, %"compiler/generic:Origin" %t62)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t66 = load i32, ptr %l3, !tbaa !23
  store i32 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/generic:instance"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 44
  %t7 = call %"compiler/generic:instance" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eAt__Hf3965267bb92d0ee7aeaa2339e2e46fa(ptr %v0, ptr %s0, ptr %t3, i64 %a1)
  store %"compiler/generic:instance" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/generic:instance", ptr %l5, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeNamed(ptr %v0, ptr %s0, ptr %a0, i32 %a1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l23 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l24 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l26 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l27 = alloca i32
  %l29 = alloca i1
  %l31 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  store ptr %l3, ptr %l7, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 10
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Context", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t8, i64 %t12)
  store ptr %t15, ptr %l13
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 4
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l15, !tbaa !24
  %t22 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %a2)
  store %"compiler/source:Span" %t22, ptr %l17
  br label %bb3
bb3:
  %t23 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t31 = sext i32 %t24 to i64
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t33 = add i64 %t29, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  %t35 = call i64 @__olang_fmt_i64(ptr %t34, i64 %t25)
  %t36 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  %t38 = call i64 @__olang_fmt_i64(ptr %t37, i64 %t31)
  %t39 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t34, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t48 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t48, { i64, ptr } %t47)
  br label %bb4
bb4:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Context", ptr %t50, i32 0, i32 2
  %t54 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v1, ptr %v1, ptr %t52)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t54, ptr %l23
  br label %bb5
bb5:
  %t55 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l23
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t55, ptr %l4
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v1, ptr %l4)
  %t58 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t57, 1
  %t59 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t57, 0
  store i32 %t59, ptr %l27
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb8, label %ok.61, !prof !99
ok.61:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t58, ptr %l26
  br label %bb7
bb7:
  %t62 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l26
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t62, ptr %l24
  br label %bb10
bb8:
  %t63 = load i32, ptr %l27, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  store i1 %t66, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb10:
  %t67 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l24
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t67, ptr %l5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb11
bb11:
  store ptr %l3, ptr %l31, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l5, i32 0, i32 1
  %t73 = load i32, ptr %t72, !tbaa !23
  %t75 = inttoptr i64 0 to ptr
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t75, ptr %t71, i32 %t73)
  store { i64, ptr } %t78, ptr %l36
  br label %bb12
bb12:
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = mul i64 %t80, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t82)
  call void @llvm.memcpy.p0.p0.i64(ptr %t83, ptr %t81, i64 %t82, i1 false)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  %t86 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t86, { i64, ptr } %t85)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  br label %bb6
bb15:
  %t89 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t89, ptr %l39
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i1
  %l12 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i1
  %l32 = alloca ptr
  %l36 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t3, i32 %t4, i32 %t5)
  store i1 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t21 = trunc i64 19 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  %t38 = xor i1 %t36, true
  store i1 %t38, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l16, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l28
  br label %bb13
bb13:
  %t49 = load i32, ptr %l28, !tbaa !23
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l32, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb16
bb15:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb19
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l40
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l32, !tbaa !29
  %t70 = load i32, ptr %l36, !tbaa !23
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t69, i32 %t70, i32 %t71)
  store i1 %t72, ptr %l41
  br label %bb18
bb18:
  %t73 = load i1, ptr %l41, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l30, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l1, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l48
  br label %bb23
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l2, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l52
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = load i32, ptr %l48, !tbaa !23
  %t95 = load i32, ptr %l52, !tbaa !23
  %t96 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t93, i32 %t94, i32 %t95)
  store i1 %t96, ptr %l53
  br label %bb25
bb25:
  %t97 = load i1, ptr %l53, !tbaa !21
  store i1 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t7 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/load:Loader", ptr %t8, i32 0, i32 10
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t14, ptr %l9
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t20, ptr %l12
  br label %bb4
bb4:
  %t21 = load i1, ptr %l12, !tbaa !21
  store i1 %t21, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i1, ptr %l4, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca { i64, ptr }
  %l48 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 20
  %t9 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6743fd6fdd876d533cce32e3c0cd25b6(ptr %v0, ptr %t5, i32 %t1)
  store i1 %t9, ptr %l14
  br label %bb1
bb1:
  %t10 = load i1, ptr %l14, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 20
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hcfc2a2943c600247d4ded3fb914681ab(ptr %v0, ptr %v1, ptr %t13, i32 %t14)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l20
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb5, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l19
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t23 = icmp sge i64 0, 0
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = icmp sle i64 0, 2305843009213693951
  br i1 %t25, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_25bcbd8d25f60d50_252e633c827b5284)
  unreachable
bb9:
  %t27 = mul i64 0, 4
  %t28 = insertvalue { i64, ptr } undef, i64 0, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t29, ptr %l15, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_25bcbd8d25f60d50_252e633c827b5284)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb12:
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l24
  br label %bb13
bb13:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l3
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emembers(ptr %v0, ptr %s0, ptr %t34, i32 %t35, ptr %l3, i64 0)
  br label %bb14
bb14:
  %t40 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t40, ptr %l29
  br label %bb15
bb15:
  %t41 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  %t42 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t42, ptr %l30
  br label %bb16
bb16:
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t43, ptr %lp5
  %t44 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l30
  %t45 = load ptr, ptr %lp5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t44, ptr %t45
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  %t68 = load ptr, ptr %lp5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t68, i32 %t66, i1 true)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l1, !tbaa !23
  %t82 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l48
  br label %bb24
bb24:
  %t83 = load i1, ptr %l48, !tbaa !21
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 20
  %t87 = load i32, ptr %l1, !tbaa !23
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Ha2fdd285cc075e465cab85a1d0fe3f31(ptr %v0, ptr %v1, ptr %t86, i32 %t87, { i64, ptr } %t88)
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 21
  %t95 = load i32, ptr %l1, !tbaa !23
  %t96 = load ptr, ptr %lp5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hc32bd40495535e8a7e7ddcc641d0c371(ptr %v0, ptr %v0, ptr %t94, i32 %t95, ptr %t96)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodNames(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l4 = alloca %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i32
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l15 = alloca %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708"
  %l17 = alloca %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708"
  %l18 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i1
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i64
  %l43 = alloca %"compiler/generic:fnRow"
  %l49 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l10
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l11
  br label %bb3
bb3:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t6, ptr %lp2
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t8 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %t8
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 36
  %t13 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hce1a5ca8c8bc252d00e2ccbd39de0b40(ptr %v0, ptr %v0, ptr %t11)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l14
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t14, ptr %l3
  br label %bb5
bb5:
  %t16 = call { i32, %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fpair_3aPair_3cI64_2c_20I64_3_Hca1409b49ac7e9b021f6a95c9301ae1a(ptr %v0, ptr %l3)
  %t17 = extractvalue { i32, %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" } %t16, 1
  %t18 = extractvalue { i32, %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" } %t16, 0
  store i32 %t18, ptr %l18
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb7, label %ok.20, !prof !99
ok.20:
  store %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" %t17, ptr %l17
  br label %bb6
bb6:
  %t21 = load %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l17
  store %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" %t21, ptr %l15
  br label %bb9
bb7:
  %t22 = load i32, ptr %l18, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  br label %bb17
bb9:
  %t26 = load %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l15
  store %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" %t26, ptr %l4
  %t27 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l4, i32 0, i32 0
  %t28 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t27, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t29)
  store i1 %t32, ptr %l23
  br label %bb10
bb10:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t34 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l4, i32 0, i32 0
  %t35 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t34, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t36, i1 true)
  br label %bb14
bb14:
  %t39 = load ptr, ptr %lp2
  %t40 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l4, i32 0, i32 0
  %t41 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t40, i32 0, i32 1
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = trunc i64 %t42 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t39, i32 %t44)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb5
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 38
  store ptr %t50, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t52 = load i64, ptr %l6, !tbaa !24
  store i64 %t52, ptr %l32, !tbaa !24
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l34
  br label %bb19
bb19:
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = icmp slt i64 %t56, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb21:
  br label %bb22
bb22:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l39
  br label %bb23
bb23:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 29
  %t74 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s5, ptr %t70, i64 %t67)
  store %"compiler/generic:fnRow" %t74, ptr %l43
  br label %bb24
bb24:
  %t75 = getelementptr %"compiler/generic:fnRow", ptr %l43, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Func", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %t78, !tbaa !23
  store i32 %t79, ptr %l8, !tbaa !23
  %t81 = load i32, ptr %l8, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t86 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t83)
  store i1 %t86, ptr %l49
  br label %bb25
bb25:
  %t87 = load i1, ptr %l49, !tbaa !21
  br i1 %t87, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t88 = load i32, ptr %l8, !tbaa !23
  %t90 = sext i32 %t88 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t90, i1 true)
  br label %bb29
bb29:
  %t93 = load ptr, ptr %lp2
  %t94 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t93, i32 %t94)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l6, !tbaa !24
  br label %bb18
bb32:
  %t101 = load ptr, ptr %lp2
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t101
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/generic:fnRow"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"compiler/generic:fnRow"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca { i64, ptr }
  %l64 = alloca i1
  %l79 = alloca { i64, ptr }
  %l86 = alloca i1
  %l96 = alloca i1
  %l101 = alloca i1
  %l106 = alloca i1
  %l110 = alloca i64
  %l112 = alloca i64
  %l118 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 29
  %t7 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/generic:fnRow" %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:fnRow", ptr %l20
  store %"compiler/generic:fnRow" %t8, ptr %l2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l21
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l3
  %t11 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Func", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l26, !tbaa !29
  %t22 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l27, !tbaa !24
  %t24 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Func", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb5, label %bb6
bb4:
  br label %bb9
bb5:
  call void @__olang_check_failed(ptr @olang_loc_91e581c61227d1c4_deb54d58cf8aa350)
  unreachable
bb6:
  br label %bb7
bb7:
  %t32 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Func", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Param", ptr %t36, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %l27, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v0, ptr %s0, ptr %t41, i64 %t42, ptr %t40, ptr %l3, i1 false)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t45 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Func", ptr %t46, i32 0, i32 9
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 9
  %t62 = load ptr, ptr %t61, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v0, ptr %s0, ptr %t55, i64 %t57, ptr %t62, ptr %l3, i1 false)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l45
  br label %bb14
bb14:
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t68, ptr %lp4
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t70 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %t70
  %t71 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 5
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 5
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb17
bb16:
  br label %bb66
bb17:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb18, label %bb19
bb18:
  br label %bb27
bb19:
  br label %bb20
bb20:
  %t99 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t99, ptr %l58, !tbaa !27
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 %t100
  %t105 = load ptr, ptr %t104, !tbaa !39
  store ptr %t105, ptr %l8, !tbaa !29
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t109 = getelementptr %"compiler/ast:TypeParam", ptr %t107, i32 0, i32 1
  %t110 = load i32, ptr %t109, !tbaa !23
  %t113 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l3, i32 %t110)
  store i1 %t113, ptr %l64
  br label %bb21
bb21:
  %t114 = load i1, ptr %l64, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb22, label %bb23
bb22:
  %t117 = load ptr, ptr %l8, !tbaa !29
  %t119 = getelementptr %"compiler/ast:TypeParam", ptr %t117, i32 0, i32 1
  %t120 = load i32, ptr %t119, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l3, i32 %t120)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t123 = load i64, ptr %l6, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l6, !tbaa !24
  br label %bb17
bb27:
  %t127 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/ast:Func", ptr %t128, i32 0, i32 5
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  %t137 = load i64, ptr %l10, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb29, label %bb30
bb29:
  br label %bb65
bb30:
  br label %bb31
bb31:
  %t145 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t145, ptr %l79, !tbaa !27
  %t146 = load i64, ptr %l10, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr ptr, ptr %t149, i64 %t146
  %t151 = load ptr, ptr %t150, !tbaa !39
  store ptr %t151, ptr %l12, !tbaa !29
  %t153 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Func", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb32, label %bb33
bb32:
  %t163 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/ast:Func", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  br i1 %t169, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_632aa6436eca4593_afccf639e057e8af)
  unreachable
bb35:
  br label %bb36
bb36:
  %t171 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/ast:Func", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Param", ptr %t175, i32 0, i32 2
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t180 = load ptr, ptr %l12, !tbaa !29
  %t182 = getelementptr %"compiler/ast:TypeParam", ptr %t180, i32 0, i32 1
  %t183 = load i32, ptr %t182, !tbaa !23
  %t186 = call i1 @compiler_2fgeneric_2ementionsName(ptr %v0, ptr %t179, i32 %t183)
  store i1 %t186, ptr %l96
  br label %bb37
bb37:
  %t187 = load i1, ptr %l96, !tbaa !21
  store i1 %t187, ptr %l86, !tbaa !21
  br label %bb38
bb38:
  %t188 = load i1, ptr %l86, !tbaa !21
  br i1 %t188, label %bb39, label %bb40
bb39:
  br label %bb64
bb40:
  br label %bb41
bb41:
  %t189 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/ast:Func", ptr %t190, i32 0, i32 9
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = icmp eq ptr %t193, null
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb42, label %bb43
bb42:
  %t199 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Func", ptr %t200, i32 0, i32 9
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t204 = load ptr, ptr %l12, !tbaa !29
  %t206 = getelementptr %"compiler/ast:TypeParam", ptr %t204, i32 0, i32 1
  %t207 = load i32, ptr %t206, !tbaa !23
  %t210 = call i1 @compiler_2fgeneric_2ementionsName(ptr %v0, ptr %t203, i32 %t207)
  store i1 %t210, ptr %l106
  br label %bb44
bb43:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb45
bb44:
  %t211 = load i1, ptr %l106, !tbaa !21
  store i1 %t211, ptr %l101, !tbaa !21
  br label %bb45
bb45:
  %t212 = load i1, ptr %l101, !tbaa !21
  br i1 %t212, label %bb46, label %bb47
bb46:
  br label %bb64
bb47:
  br label %bb48
bb48:
  %t213 = load ptr, ptr %l12, !tbaa !29
  %t215 = getelementptr %"compiler/ast:TypeParam", ptr %t213, i32 0, i32 4
  %t216 = load i1, ptr %t215, !tbaa !21
  br i1 %t216, label %bb49, label %bb50
bb49:
  br label %bb64
bb50:
  br label %bb51
bb51:
  store ptr %l3, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb52
bb52:
  %t219 = load i64, ptr %l14, !tbaa !24
  store i64 %t219, ptr %l110, !tbaa !24
  %t220 = load ptr, ptr %l13, !tbaa !29
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t220)
  store i64 %t222, ptr %l112
  br label %bb53
bb53:
  %t223 = load i64, ptr %l110, !tbaa !24
  %t224 = load i64, ptr %l112, !tbaa !24
  %t225 = icmp slt i64 %t223, %t224
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb54, label %bb55
bb54:
  br label %bb63
bb55:
  br label %bb56
bb56:
  %t229 = load i64, ptr %l14, !tbaa !24
  store i64 %t229, ptr %l15, !tbaa !24
  %t231 = load ptr, ptr %l13, !tbaa !29
  %t232 = load i64, ptr %l14, !tbaa !24
  %t235 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t231, i64 %t232)
  store i32 %t235, ptr %l118
  br label %bb57
bb57:
  %t236 = load i32, ptr %l118, !tbaa !23
  %t238 = load ptr, ptr %l12, !tbaa !29
  %t240 = getelementptr %"compiler/ast:TypeParam", ptr %t238, i32 0, i32 1
  %t241 = load i32, ptr %t240, !tbaa !23
  %t244 = icmp eq i32 %t236, %t241
  br i1 %t244, label %bb58, label %bb59
bb58:
  %t246 = load ptr, ptr %lp4
  %t247 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t246, i64 %t247)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t250 = load i64, ptr %l14, !tbaa !24
  %t252 = add i64 %t250, 1
  store i64 %t252, ptr %l14, !tbaa !24
  br label %bb52
bb63:
  br label %bb64
bb64:
  %t254 = load i64, ptr %l10, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l10, !tbaa !24
  br label %bb28
bb65:
  br label %bb66
bb66:
  %t258 = load ptr, ptr %lp4
  %t259 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t258
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t259, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerVarCount(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/generic:fnRow"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"compiler/generic:fnRow"
  %l9 = alloca i1
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 29
  %t7 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/generic:fnRow" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:fnRow", ptr %l7
  store %"compiler/generic:fnRow" %t8, ptr %l2
  %t9 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t10)
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i1, ptr %l9, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l12
  br label %bb6
bb6:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l3
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Func", ptr %t23, i32 0, i32 9
  %t26 = load ptr, ptr %t25, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v0, ptr %s0, ptr %t19, i64 %t21, ptr %t26, ptr %l3, i1 false)
  br label %bb7
bb7:
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l3)
  store i64 %t32, ptr %l19
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca i32
  %l59 = alloca i64
  %l64 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t16 = trunc i64 18 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t22, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l22
  br label %bb8
bb8:
  %t31 = load i32, ptr %l22, !tbaa !23
  store i32 %t31, ptr %l2, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l26
  br label %bb9
bb9:
  %t39 = load i32, ptr %l26, !range !{i32 0, i32 6}
  %t41 = trunc i64 2 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 9
  %t51 = load i32, ptr %l2, !tbaa !23
  %t53 = sext i32 %t51 to i64
  %t56 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__H9861f6f09602cf23d49075e82ac9429b(ptr %v0, ptr %t50, i64 %t53)
  %t57 = extractvalue { i32, i32 } %t56, 1
  %t58 = extractvalue { i32, i32 } %t56, 0
  store i32 %t58, ptr %l37
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb14, label %ok.60, !prof !99
ok.60:
  store i32 %t57, ptr %l36
  br label %bb13
bb13:
  %t61 = load i32, ptr %l36, !tbaa !23
  store i32 %t61, ptr %l31, !tbaa !23
  br label %bb16
bb14:
  br label %bb15
bb15:
  store i32 -1, ptr %l31, !tbaa !23
  br label %bb16
bb16:
  %t62 = load i32, ptr %l31, !tbaa !23
  store i32 %t62, ptr %l3, !tbaa !23
  %t63 = load i32, ptr %l3, !tbaa !23
  %t65 = icmp ne i32 %t63, -1
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t67, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t71, i32 %t72)
  store i64 %t75, ptr %l44
  br label %bb20
bb20:
  %t76 = load i64, ptr %l44, !tbaa !24
  store i64 %t76, ptr %l4, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l45, !tbaa !29
  %t78 = load i64, ptr %l4, !tbaa !24
  store i64 %t78, ptr %l46, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l49, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l2, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l54
  br label %bb21
bb21:
  %t94 = load ptr, ptr %l50, !tbaa !29
  %t95 = load i32, ptr %l54, !tbaa !23
  %t96 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t94, i32 %t95)
  store { i64, ptr } %t96, ptr %l55
  br label %bb22
bb22:
  %t97 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t98 = call { i64, ptr } @compiler_2fnames_2ePayloadName(ptr %v0, ptr %s0, { i64, ptr } %t97)
  store { i64, ptr } %t98, ptr %l56
  br label %bb23
bb23:
  %t99 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = extractvalue { i64, ptr } %t99, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load ptr, ptr %l49, !tbaa !29
  %t108 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t106, { i64, ptr } %t105)
  store i32 %t108, ptr %l58
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l45, !tbaa !29
  %t110 = load i64, ptr %l46, !tbaa !24
  %t111 = load i32, ptr %l58, !tbaa !23
  %t112 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t109, i64 %t110, i32 %t111)
  store i64 %t112, ptr %l59
  br label %bb25
bb25:
  %t113 = load i64, ptr %l59, !tbaa !24
  store i64 %t113, ptr %l5, !tbaa !24
  %t114 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t114, ptr %l6, !tbaa !23
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = icmp sge i64 %t116, 0
  br i1 %t118, label %bb26, label %bb27
bb26:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l64, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l4, !tbaa !24
  %t125 = load i64, ptr %l5, !tbaa !24
  %t129 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t123, i64 %t124, i64 %t125)
  store i32 %t129, ptr %l68
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t130 = load ptr, ptr %l64, !tbaa !29
  %t131 = load i32, ptr %l68, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t130, i32 %t131, i32 0)
  store i32 %t132, ptr %l69
  br label %bb29
bb29:
  %t133 = load i32, ptr %l69, !tbaa !23
  store i32 %t133, ptr %l6, !tbaa !23
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l6, !tbaa !23
  %t138 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l72
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 9
  %t142 = load i32, ptr %l2, !tbaa !23
  %t144 = sext i32 %t142 to i64
  %t145 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__Hbdd7c5068e376aa260a62181a9f99429(ptr %v0, ptr %t141, i64 %t144, i32 %t145)
  br label %bb32
bb32:
  %t149 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t149, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i32
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l27 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l79 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l17, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l21
  br label %bb4
bb3:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load i32, ptr %l21, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i32, ptr %l22, !range !{i32 0, i32 6}
  %t28 = trunc i64 2 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOfType(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l27
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t37 = load i32, ptr %l27, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb10:
  %t38 = load i32, ptr %l1, !tbaa !23
  store i32 %t38, ptr %l2, !tbaa !23
  store i64 0, ptr %l3, !tbaa !24
  store i64 64, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb16
bb13:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l35, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t66 = load i64, ptr %l35, !tbaa !24
  store i64 %t66, ptr %l32, !tbaa !24
  br label %bb16
bb16:
  %t67 = load i64, ptr %l32, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %bb36
bb19:
  br label %bb20
bb20:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l5, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l8, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l2, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l56
  br label %bb21
bb21:
  %t93 = load i32, ptr %l56, !range !{i32 0, i32 33}
  %t95 = trunc i64 18 to i32
  %t96 = icmp eq i32 %t93, %t95
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb25
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l2, !tbaa !23
  %t104 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l63
  br label %bb24
bb24:
  %t105 = load i1, ptr %l63, !tbaa !21
  %t106 = xor i1 %t105, true
  store i1 %t106, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t108 = load i1, ptr %l60, !tbaa !21
  br i1 %t108, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb30
bb27:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l67, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l2, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l71
  br label %bb28
bb28:
  %t119 = load ptr, ptr %l67, !tbaa !29
  %t120 = load i32, ptr %l71, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t121, ptr %l72
  br label %bb29
bb29:
  %t122 = load i32, ptr %l72, !range !{i32 0, i32 6}
  %t124 = trunc i64 4 to i32
  %t125 = icmp eq i32 %t122, %t124
  %t127 = xor i1 %t125, true
  store i1 %t127, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t129 = load i1, ptr %l65, !tbaa !21
  br i1 %t129, label %bb31, label %bb32
bb31:
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l2, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l79
  br label %bb34
bb34:
  %t137 = load i32, ptr %l79, !tbaa !23
  store i32 %t137, ptr %l2, !tbaa !23
  br label %bb35
bb35:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l7, !tbaa !24
  br label %bb17
bb36:
  %t142 = load i32, ptr %l2, !tbaa !23
  store i32 %t142, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResetAny(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = ptrtoint ptr %v0 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e61
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l2
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l4
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e61
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l2
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = icmp ne ptr %t17, null
  %t19 = select i1 %t18, ptr %t17, ptr null
  %t20 = icmp eq ptr %t19, %t13
  call void @__olang_region_settle(ptr %t13, i1 %t20)
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 61
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l6
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t26
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e61
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = call ptr @__olang_region_or(ptr %t31, ptr null)
  %t33 = icmp ne ptr %t32, null
  %t34 = select i1 %t33, ptr %t32, ptr null
  call void @__olang_region_drop(ptr %t34)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l6
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l8, !tbaa !29
  %t36 = ptrtoint ptr %v0 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e62
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = call ptr @__olang_region_make(ptr %v0)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l9
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %t42)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %l11
  br label %bb10
bb10:
  %t44 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e62
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i64, ptr %l9
  %t47 = inttoptr i64 %t46 to ptr
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 2
  %t49 = load { i64, ptr }, ptr %t48
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = call ptr @__olang_region_or(ptr %t50, ptr null)
  %t52 = icmp ne ptr %t51, null
  %t53 = select i1 %t52, ptr %t51, ptr null
  %t54 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 1
  %t55 = load { i64, ptr }, ptr %t54
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = call ptr @__olang_region_or(ptr %t56, ptr null)
  %t58 = icmp ne ptr %t57, null
  %t59 = select i1 %t58, ptr %t57, ptr %t53
  %t60 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = call ptr @__olang_region_or(ptr %t62, ptr null)
  %t64 = icmp ne ptr %t63, null
  %t65 = select i1 %t64, ptr %t63, ptr %t59
  %t66 = icmp eq ptr %t65, %t47
  call void @__olang_region_settle(ptr %t47, i1 %t66)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l8, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 62
  %t69 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t68
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t69, ptr %l13
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  %t71 = load ptr, ptr %l8, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 62
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %t72
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e62
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = call ptr @__olang_region_or(ptr %t77, ptr null)
  %t79 = icmp ne ptr %t78, null
  %t80 = select i1 %t79, ptr %t78, ptr null
  %t81 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = call ptr @__olang_region_or(ptr %t83, ptr null)
  %t85 = icmp ne ptr %t84, null
  %t86 = select i1 %t85, ptr %t84, ptr %t80
  %t87 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = call ptr @__olang_region_or(ptr %t89, ptr null)
  %t91 = icmp ne ptr %t90, null
  %t92 = select i1 %t91, ptr %t90, ptr %t86
  call void @__olang_region_drop(ptr %t92)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l13
  br label %bb14
bb14:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l15, !tbaa !29
  %t94 = ptrtoint ptr %v0 to i64
  store i64 %t94, ptr %l16, !tbaa !24
  %t95 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e64
  br i1 %t95, label %bb15, label %bb16
bb15:
  %t97 = call ptr @__olang_region_make(ptr %v0)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l16, !tbaa !24
  br label %bb16
bb16:
  %t99 = load i64, ptr %l16
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t100)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t101, ptr %l18
  br label %bb17
bb17:
  %t102 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e64
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load i64, ptr %l16
  %t105 = inttoptr i64 %t104 to ptr
  %t106 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 2
  %t107 = load { i64, ptr }, ptr %t106
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = call ptr @__olang_region_or(ptr %t108, ptr null)
  %t110 = icmp ne ptr %t109, null
  %t111 = select i1 %t110, ptr %t109, ptr null
  %t112 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 1
  %t113 = load { i64, ptr }, ptr %t112
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = call ptr @__olang_region_or(ptr %t114, ptr null)
  %t116 = icmp ne ptr %t115, null
  %t117 = select i1 %t116, ptr %t115, ptr %t111
  %t118 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = call ptr @__olang_region_or(ptr %t120, ptr null)
  %t122 = icmp ne ptr %t121, null
  %t123 = select i1 %t122, ptr %t121, ptr %t117
  %t124 = icmp eq ptr %t123, %t105
  call void @__olang_region_settle(ptr %t105, i1 %t124)
  br label %bb19
bb19:
  %t125 = load ptr, ptr %l15, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 64
  %t127 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t126
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t127, ptr %l20
  %t128 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  %t129 = load ptr, ptr %l15, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 64
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t128, ptr %t130
  %t131 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e64
  br i1 %t131, label %bb20, label %bb21
bb20:
  %t133 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 2
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = call ptr @__olang_region_or(ptr %t135, ptr null)
  %t137 = icmp ne ptr %t136, null
  %t138 = select i1 %t137, ptr %t136, ptr null
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 1
  %t140 = load { i64, ptr }, ptr %t139
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = call ptr @__olang_region_or(ptr %t141, ptr null)
  %t143 = icmp ne ptr %t142, null
  %t144 = select i1 %t143, ptr %t142, ptr %t138
  %t145 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = call ptr @__olang_region_or(ptr %t147, ptr null)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr %t144
  call void @__olang_region_drop(ptr %t150)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l20
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = load i32, ptr %l15, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t35, i32 %t33)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l3, !tbaa !24
  br label %bb3
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t45, i32 %t46)
  store { i64, ptr } %t49, ptr %l33
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = mul i64 %t51, 4
  %t54 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t70, ptr %l41, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i32, ptr %t74, i64 %t71
  %t76 = load i32, ptr %t75, !tbaa !33
  %t78 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t78, i32 %t76)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  call void @__olang_scope_close(ptr %s4)
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l1, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l51
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSettleRaised(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t11, { i64, ptr } %a2)
  store i32 %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load i32, ptr %l12, !tbaa !23
  store i32 %t16, ptr %l4, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 10
  %t20 = load i32, ptr %l3, !tbaa !23
  %t22 = sext i32 %t20 to i64
  %t23 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %t19, i64 %t22, i32 %t23)
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  store i32 %t30, ptr %l20, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l24
  br label %bb4
bb4:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  store ptr %t40, ptr %l26, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l30
  br label %bb5
bb5:
  %t48 = mul i64 1, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 1, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l31, !tbaa !27
  %t52 = load i32, ptr %l30, !tbaa !23
  %t53 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i32, ptr %t54, i64 0
  store i32 %t52, ptr %t55, !tbaa !33
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t56, { i64, ptr } %t57)
  store i32 %t58, ptr %l32
  br label %bb6
bb6:
  %t59 = load ptr, ptr %l19, !tbaa !29
  %t60 = load i32, ptr %l20, !tbaa !23
  %t61 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t62 = load i32, ptr %l32, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEnumBody(ptr %v0, ptr %v0, ptr %t59, i32 %t60, { i64, ptr } %t61, i32 %t62)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca { i64, ptr }
  %l54 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load i64, ptr %l11, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = icmp sle i64 %t10, 1152921504606846975
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_52c8f96a75cfc7a4_95d33db140d5de70)
  unreachable
bb3:
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = mul i64 %t13, 8
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Sig", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_52c8f96a75cfc7a4_95d33db140d5de70)
  unreachable
bb5:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t52 = load i64, ptr %l24, !tbaa !24
  store i64 %t52, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t53 = load i64, ptr %l21, !tbaa !24
  store i64 %t53, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Sig", ptr %t73, i32 0, i32 0
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l44, !tbaa !27
  %t77 = load i64, ptr %l8, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t77
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t84 = getelementptr %"compiler/ast:Param", ptr %t82, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t90 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i64, ptr %t91, i64 %t72
  store i64 %t87, ptr %t92, !tbaa !34
  br label %bb15
bb15:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb11
bb16:
  %t99 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %s0, ptr %t99, { i64, ptr } %t100)
  store i64 %t103, ptr %l54
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t104 = load i64, ptr %l54, !tbaa !24
  store i64 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca i64
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t5 = mul i64 %t3, 65536
  store i64 %t5, ptr %l5, !tbaa !24
  store i64 %a2, ptr %l6, !tbaa !24
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %a0, i32 %t8)
  store { i64, ptr } %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = srem i64 %t14, %t13
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = add i64 %t17, %t16
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i1
  %l49 = alloca i32
  %l51 = alloca i32
  %l53 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i32
  %l63 = alloca i32
  %l65 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l71 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i32
  %l84 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i32
  %l92 = alloca i32
  %l94 = alloca i1
  %l103 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i32 0, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l18
  br label %bb7
bb7:
  %t21 = load i32, ptr %l18, !range !{i32 0, i32 33}
  store i32 %t21, ptr %l6
  %t22 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t24 = trunc i64 25 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l25
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Binding", ptr %t34, i32 0, i32 0
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp eq i64 %t38, %t37
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l29, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l30, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t47, i32 %t48)
  store i64 %t51, ptr %l34
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t52 = load i32, ptr %l2, !tbaa !23
  %t53 = load i1, ptr %l4, !tbaa !21
  %t54 = load i1, ptr %l5, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = load i64, ptr %l34, !tbaa !24
  %t61 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %t55, ptr %t56, i64 %t57, i32 %t52, i1 %t53, i1 %t54)
  store i32 %t61, ptr %l38
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb16, label %ok.63, !prof !99
ok.63:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t64 = load i32, ptr %l38, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  store i32 %t72, ptr %rv
  br label %ret
bb17:
  store i32 0, ptr %rv
  br label %ret
bb18:
  %t74 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t76 = trunc i64 27 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb19, label %bb20
bb19:
  store i32 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l2, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l45
  br label %bb22
bb22:
  %t86 = load i32, ptr %l45, !range !{i32 0, i32 33}
  store i32 %t86, ptr %l7
  %t87 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t89 = trunc i64 18 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load i32, ptr %l6, !range !{i32 0, i32 33}
  store i32 %t92, ptr %l49
  %t93 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t93, ptr %l51
  %t96 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l49, ptr %l51)
  store i1 %t96, ptr %l53
  br label %bb25
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb31
bb25:
  %t97 = load i1, ptr %l53, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb30
bb27:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l1, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l59
  br label %bb28
bb28:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l2, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l63
  br label %bb29
bb29:
  %t114 = load i32, ptr %l59, !tbaa !23
  %t115 = load i32, ptr %l63, !tbaa !23
  %t116 = icmp ne i32 %t114, %t115
  store i1 %t116, ptr %l55, !tbaa !21
  br label %bb30
bb30:
  %t118 = load i1, ptr %l55, !tbaa !21
  store i1 %t118, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t119 = load i1, ptr %l48, !tbaa !21
  br i1 %t119, label %bb32, label %bb33
bb32:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t124 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l68
  br label %bb34
bb33:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb35
bb34:
  %t125 = load i1, ptr %l68, !tbaa !21
  store i1 %t125, ptr %l65, !tbaa !21
  br label %bb35
bb35:
  %t126 = load i1, ptr %l65, !tbaa !21
  br i1 %t126, label %bb36, label %bb37
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  store ptr %t129, ptr %l71, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l2, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l75
  br label %bb38
bb37:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb40
bb38:
  %t137 = load ptr, ptr %l71, !tbaa !29
  %t138 = load i32, ptr %l75, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t139, ptr %l76
  br label %bb39
bb39:
  %t140 = load i32, ptr %l76, !range !{i32 0, i32 6}
  %t142 = trunc i64 4 to i32
  %t143 = icmp eq i32 %t140, %t142
  store i1 %t143, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t145 = load i1, ptr %l69, !tbaa !21
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l79, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  store i32 %t147, ptr %l80, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l2, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l84
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t156 = load i1, ptr %l4, !tbaa !21
  %t157 = load i1, ptr %l5, !tbaa !21
  %t158 = load ptr, ptr %l79, !tbaa !29
  %t159 = load i32, ptr %l80, !tbaa !23
  %t160 = load i32, ptr %l84, !tbaa !23
  %t164 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %t158, i32 %t159, i32 %t160, ptr %t155, i1 %t156, i1 %t157)
  store i32 %t164, ptr %l88
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb45, label %ok.166, !prof !99
ok.166:
  br label %bb44
bb44:
  br label %bb46
bb45:
  %t167 = load i32, ptr %l88, !tbaa !23
  %t168 = lshr i32 %t167, 16
  %t169 = and i32 %t167, 65535
  %t170 = icmp eq i32 %t168, 1
  %t171 = select i1 %t170, i32 1, i32 0
  %t172 = icmp eq i32 %t167, 0
  %t173 = shl i32 %t171, 16
  %t174 = or i32 %t173, %t169
  %t175 = select i1 %t172, i32 0, i32 %t174
  store i32 %t175, ptr %rv
  br label %ret
bb46:
  store i32 0, ptr %rv
  br label %ret
bb47:
  %t177 = load i32, ptr %l6, !range !{i32 0, i32 33}
  store i32 %t177, ptr %l90
  %t178 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t178, ptr %l92
  %t181 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l90, ptr %l92)
  store i1 %t181, ptr %l94
  br label %bb48
bb48:
  %t182 = load i1, ptr %l94, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb49, label %bb50
bb49:
  store i32 65536, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t188 = load i32, ptr %l1, !tbaa !23
  %t189 = load i32, ptr %l2, !tbaa !23
  %t190 = load ptr, ptr %l3, !tbaa !29
  %t191 = load i1, ptr %l5, !tbaa !21
  %t198 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyKind(ptr %v0, ptr %v1, ptr %t186, i32 %t187, i32 %t188, i32 %t189, ptr %t190, i1 %t191)
  store i32 %t198, ptr %l103
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb53, label %ok.200, !prof !99
ok.200:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t201 = load i32, ptr %l103, !tbaa !23
  %t202 = lshr i32 %t201, 16
  %t203 = and i32 %t201, 65535
  %t204 = icmp eq i32 %t202, 1
  %t205 = select i1 %t204, i32 1, i32 0
  %t206 = icmp eq i32 %t201, 0
  %t207 = shl i32 %t205, 16
  %t208 = or i32 %t207, %t203
  %t209 = select i1 %t206, i32 0, i32 %t208
  store i32 %t209, ptr %rv
  br label %ret
bb54:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l10 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %t3)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUniqueSettled(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l10
  br label %bb5
bb5:
  %t17 = load i1, ptr %l10, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epartsReady(ptr %v0, ptr %t20, i32 %t21, i64 0)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l17
  br label %bb10
bb10:
  %t31 = load i1, ptr %l17, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t3, i64 %t4, i64 %t5, i64 %t6)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i32, ptr %l9, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t13, i64 %t14, i64 %t15)
  store i1 %t19, ptr %l13
  br label %bb2
bb2:
  %t20 = load i1, ptr %l13, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l19
  br label %bb5
bb4:
  %t29 = load i32, ptr %l3, !tbaa !23
  store i32 %t29, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i32, ptr %l19, !tbaa !23
  %t33 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l20
  br label %bb6
bb6:
  %t34 = load i32, ptr %l20, !tbaa !23
  store i32 %t34, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t35 = load i32, ptr %l14, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca %"compiler/generic:fnRow"
  %l19 = alloca i1
  %l31 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i64
  %l54 = alloca i64
  %l60 = alloca i1
  %l64 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca i1
  %l84 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l85 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l100 = alloca i1
  %l102 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 29
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 29
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t16 = call %"compiler/generic:fnRow" @compiler_2fgeneric_3afnRow_2ector(ptr %v1, ptr %v0, i64 %t10, ptr %t11, i1 %a3)
  store %"compiler/generic:fnRow" %t16, ptr %l17
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load %"compiler/generic:fnRow", ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2ePush_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t17, %"compiler/generic:fnRow" %t18)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v1, ptr %t19)
  store i1 %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load i1, ptr %l19, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddBuilder(ptr %v0, ptr %v1, ptr %t23, i64 %t24, ptr %t25, i64 %t26)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Func", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Func", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t38, i64 %t44)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t47, ptr %l31
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t48 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t48, ptr %l5
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 34
  %t52 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t55 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t51, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t52)
  %t56 = extractvalue { i32, i64 } %t55, 1
  %t57 = extractvalue { i32, i64 } %t55, 0
  store i32 %t57, ptr %l37
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59, !prof !99
ok.59:
  store i64 %t56, ptr %l36
  br label %bb12
bb12:
  %t60 = load i64, ptr %l36, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l32, !tbaa !24
  br label %bb15
bb15:
  %t61 = load i64, ptr %l32, !tbaa !24
  %t62 = icmp slt i64 %t61, 0
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 34
  %t67 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t68 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t66, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t67, i64 %t68)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %l44, !tbaa !24
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_cab99c6a514cda4c_3636b0df4624338)
  unreachable
bb22:
  br label %bb23
bb23:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Func", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Param", ptr %t84, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 5
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t93 = load ptr, ptr %l43, !tbaa !29
  %t94 = load i64, ptr %l44, !tbaa !24
  %t97 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v1, ptr %t93, i64 %t94, ptr %t88, { i64, ptr } %t92)
  store i64 %t97, ptr %l54
  br label %bb24
bb24:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l6, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t101 = icmp slt i64 %t99, 0
  br i1 %t101, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = ashr i64 %t103, 40
  %t107 = icmp eq i64 %t105, 1
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Func", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %t112, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t109, i32 %t113)
  store { i64, ptr } %t116, ptr %l64
  br label %bb30
bb29:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb32
bb30:
  %t117 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t117, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t118, ptr %l65
  br label %bb31
bb31:
  %t119 = load i1, ptr %l65, !tbaa !21
  store i1 %t119, ptr %l60, !tbaa !21
  br label %bb32
bb32:
  %t120 = load i1, ptr %l60, !tbaa !21
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Func", ptr %t121, i32 0, i32 3
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Sig", ptr %t124, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = icmp eq i64 %t129, 0
  store i1 %t131, ptr %l66, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t133 = load i1, ptr %l66, !tbaa !21
  br i1 %t133, label %bb36, label %bb37
bb36:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i64, ptr %l6, !tbaa !24
  %t138 = shl i64 1, 40
  %t140 = sub i64 %t138, 1
  %t143 = and i64 %t137, %t140
  %t145 = trunc i64 %t143 to i32
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkCopy(ptr %v0, ptr %t136, i32 %t145)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load ptr, ptr %l2, !tbaa !29
  %t152 = getelementptr %"compiler/ast:Func", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %t152, !tbaa !23
  %t155 = sext i32 %t153 to i64
  %t158 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t149, i64 %t155)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t158, ptr %l84
  br label %bb40
bb40:
  %t159 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l84
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t159, ptr %l7
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 36
  %t163 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t166 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t162, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t163)
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l90
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb42, label %ok.170, !prof !99
ok.170:
  store i64 %t167, ptr %l89
  br label %bb41
bb41:
  %t171 = load i64, ptr %l89, !tbaa !24
  store i64 %t171, ptr %l85, !tbaa !24
  br label %bb44
bb42:
  br label %bb43
bb43:
  store i64 -1, ptr %l85, !tbaa !24
  br label %bb44
bb44:
  %t172 = load i64, ptr %l85, !tbaa !24
  store i64 %t172, ptr %l8, !tbaa !24
  %t173 = load i64, ptr %l8, !tbaa !24
  %t175 = icmp slt i64 %t173, 0
  br i1 %t175, label %bb45, label %bb46
bb45:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 36
  %t180 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t181 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t179, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t180, i64 %t181)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb60
bb48:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 37
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t187, i64 %t188)
  store i1 %t191, ptr %l100
  br label %bb49
bb49:
  %t192 = load i1, ptr %l100, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  br label %bb52
bb52:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 37
  %t198 = load i64, ptr %l8, !tbaa !24
  %t201 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t197, i64 %t198)
  %t202 = extractvalue { i32, i64 } %t201, 1
  %t203 = extractvalue { i32, i64 } %t201, 0
  store i32 %t203, ptr %l107
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb54, label %ok.205, !prof !99
ok.205:
  store i64 %t202, ptr %l106
  br label %bb53
bb53:
  %t206 = load i64, ptr %l106, !tbaa !24
  store i64 %t206, ptr %l102, !tbaa !24
  br label %bb56
bb54:
  br label %bb55
bb55:
  store i64 -1, ptr %l102, !tbaa !24
  br label %bb56
bb56:
  %t207 = load i64, ptr %l102, !tbaa !24
  store i64 %t207, ptr %l8, !tbaa !24
  br label %bb57
bb57:
  br label %bb48
bb58:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 37
  %t211 = load i64, ptr %l8, !tbaa !24
  %t212 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t210, i64 %t211, i64 %t212)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t216 = load i64, ptr %l6, !tbaa !24
  %t218 = ashr i64 %t216, 40
  %t220 = icmp eq i64 %t218, 4
  br i1 %t220, label %bb61, label %bb62
bb61:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 38
  %t225 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t224, i64 %t225)
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 39
  %t231 = load i64, ptr %l6, !tbaa !24
  %t232 = shl i64 1, 40
  %t234 = sub i64 %t232, 1
  %t237 = and i64 %t231, %t234
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t230, i64 %t237)
  br label %bb64
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFnsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l45 = alloca i1
  %l50 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6578d57707832f1c_86539f83bfff8b08)
  unreachable
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sgt i64 %t23, 0
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopIf", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6578d57707832f1c_86539f83bfff8b08)
  unreachable
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load ptr, ptr %l18, !tbaa !29
  %t46 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFns(ptr %v0, ptr %v1, ptr %t45, i64 %t46, { i64, ptr } %t44)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopIf", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  store i64 %t58, ptr %l32, !tbaa !24
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8ca182a09b46660b_89b944af5f42b927)
  unreachable
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TopIf", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load ptr, ptr %l31, !tbaa !29
  %t75 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFnsIf(ptr %v0, ptr %v1, ptr %t74, i64 %t75, ptr %t69, i64 %t70, i64 %t73)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t79, i32 0, i32 3
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = add i64 %t89, 1
  %t94 = icmp eq i64 %t88, %t91
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l45, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:TopIf", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e2462b885589950a_643da267921b7c76)
  unreachable
bb27:
  br label %bb28
bb28:
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr %"compiler/ast:TopIf", ptr %t104, i32 0, i32 3
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t110 = getelementptr %"compiler/ast:TopBranch", ptr %t107, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp sgt i64 %t113, 0
  store i1 %t115, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t117 = load i1, ptr %l50, !tbaa !21
  br i1 %t117, label %bb30, label %bb31
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l60, !tbaa !29
  %t119 = load i64, ptr %l1, !tbaa !24
  store i64 %t119, ptr %l61, !tbaa !24
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:TopIf", ptr %t120, i32 0, i32 3
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e2462b885589950a_643da267921b7c76)
  unreachable
bb33:
  br label %bb34
bb34:
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr %"compiler/ast:TopIf", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t133 = getelementptr %"compiler/ast:TopBranch", ptr %t130, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t135 = load ptr, ptr %l60, !tbaa !29
  %t136 = load i64, ptr %l61, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFns(ptr %v0, ptr %v1, ptr %t135, i64 %t136, { i64, ptr } %t134)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca i64
  %l35 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca i32
  %l65 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l97 = alloca i32
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l17, !tbaa !24
  %t4 = load i64, ptr %l17, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l17, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_c23c218140effa50_4db4b783113412a4)
  unreachable
bb3:
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l22, !tbaa !24
  %t19 = load i64, ptr %l22, !tbaa !24
  %t20 = icmp sge i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c23c218140effa50_4db4b783113412a4)
  unreachable
bb5:
  %t22 = load i64, ptr %l22, !tbaa !24
  %t23 = icmp sle i64 %t22, 2305843009213693951
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_7e185c750e76a77d_541671d994da32b1)
  unreachable
bb7:
  %t25 = load i64, ptr %l22, !tbaa !24
  %t26 = mul i64 %t25, 4
  %t27 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l4, !tbaa !27
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l26
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_7e185c750e76a77d_541671d994da32b1)
  unreachable
bb9:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb15
bb12:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l35, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l35, !tbaa !24
  store i64 %t63, ptr %l32, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l32, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb17, label %bb18
bb17:
  br label %bb32
bb18:
  br label %bb19
bb19:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t84, ptr %l54, !tbaa !27
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t92 = getelementptr %"compiler/ast:CaseDecl", ptr %t90, i32 0, i32 1
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t83
  store i32 %t93, ptr %t98, !tbaa !33
  %t99 = load i64, ptr %l11, !tbaa !24
  store i64 %t99, ptr %l58, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t102, ptr %l61, !tbaa !27
  %t103 = load i64, ptr %l11, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t112 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %t100, ptr %a1, ptr %t108, i32 -1)
  store i32 %t112, ptr %l64
  br label %bb20
bb20:
  %t113 = load i32, ptr %l64, !tbaa !23
  %t114 = load i64, ptr %l58, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t114
  store i32 %t113, ptr %t117, !tbaa !33
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t118, ptr %l65, !tbaa !27
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = getelementptr %"compiler/ast:CaseDecl", ptr %t124, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = icmp sgt i64 %t129, 0
  br i1 %t131, label %bb21, label %bb22
bb21:
  %t133 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t133, ptr %l71, !tbaa !27
  %t134 = load i64, ptr %l11, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr ptr, ptr %t137, i64 %t134
  %t139 = load ptr, ptr %t138, !tbaa !39
  %t141 = getelementptr %"compiler/ast:CaseDecl", ptr %t139, i32 0, i32 2
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  store i64 %t146, ptr %l14, !tbaa !24
  br label %bb23
bb22:
  br label %bb30
bb23:
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t156 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t156, ptr %l81, !tbaa !27
  %t157 = load i64, ptr %l13, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr ptr, ptr %t160, i64 %t157
  %t162 = load ptr, ptr %t161, !tbaa !39
  %t166 = getelementptr %"compiler/ast:Param", ptr %t162, i32 0, i32 1
  %t167 = load i32, ptr %t166, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l5, i32 %t167)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l13, !tbaa !24
  br label %bb23
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb16
bb32:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  store ptr %t180, ptr %l92, !tbaa !29
  %t181 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t181, ptr %l93, !tbaa !27
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t184, { i64, ptr } %t185)
  store i32 %t188, ptr %l97
  br label %bb33
bb33:
  %t190 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t190, ptr %l99
  br label %bb34
bb34:
  %t191 = load ptr, ptr %l92, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t193 = load i32, ptr %l97, !tbaa !23
  %t194 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %s0, ptr %s0, ptr %t191, { i64, ptr } %t192, i32 %t193, { i64, ptr } %t194)
  store i32 %t195, ptr %l100
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t196 = load i32, ptr %l100, !tbaa !23
  store i32 %t196, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i32
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i32
  %l53 = alloca i32
  %l57 = alloca i1
  %l61 = alloca i32
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l78 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i32
  %l89 = alloca { i64, ptr }
  %l95 = alloca i1
  %l97 = alloca { i64, ptr }
  %l100 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l118 = alloca i1
  %l123 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i1
  %l143 = alloca i1
  %l145 = alloca { i64, ptr }
  %l151 = alloca i32
  %l154 = alloca i1
  %l158 = alloca i32
  %l162 = alloca i1
  %l164 = alloca ptr
  %l168 = alloca i32
  %l169 = alloca i32
  %l175 = alloca i32
  %l178 = alloca i32
  %l180 = alloca ptr
  %l184 = alloca i32
  %l185 = alloca i32
  %l190 = alloca i32
  %l193 = alloca i1
  %l197 = alloca i32
  %l200 = alloca i1
  %l202 = alloca ptr
  %l206 = alloca i32
  %l210 = alloca i32
  %l211 = alloca i1
  %l212 = alloca i1
  %l214 = alloca { i64, ptr }
  %l221 = alloca i32
  %l223 = alloca i1
  %l227 = alloca i32
  %l231 = alloca i32
  %l234 = alloca { i64, ptr }
  %l235 = alloca i64
  %l237 = alloca ptr
  %l241 = alloca i32
  %l242 = alloca i32
  %l244 = alloca ptr
  %l247 = alloca i32
  %l248 = alloca i1
  %l249 = alloca i1
  %l251 = alloca ptr
  %l254 = alloca i32
  %l255 = alloca i1
  %l259 = alloca i1
  %l263 = alloca i1
  %l264 = alloca i1
  %l266 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l278 = alloca i32
  %l281 = alloca i1
  %l285 = alloca i32
  %l288 = alloca i1
  %l292 = alloca i32
  %l296 = alloca i32
  %l301 = alloca i64
  %l305 = alloca i64
  %l307 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l313 = alloca i64
  %l315 = alloca ptr
  %l319 = alloca i32
  %l331 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t10 = trunc i64 30 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Binding", ptr %t13, i32 0, i32 2
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l19, !tbaa !27
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 %t17
  %t22 = load i32, ptr %t21, !tbaa !33
  store i32 %t22, ptr %l6, !tbaa !23
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Binding", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l24, !tbaa !24
  %t29 = load i32, ptr %l6, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb3:
  br label %bb12
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb7
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l32
  br label %bb6
bb6:
  %t42 = load i32, ptr %l32, !range !{i32 0, i32 33}
  %t44 = trunc i64 30 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t50 = load i32, ptr %l3, !tbaa !23
  store i32 %t50, ptr %l36, !tbaa !23
  br label %bb11
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l6, !tbaa !23
  %t54 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetUnion(ptr %v0, ptr %t52, i32 %t53, i32 %t54)
  store i32 %t58, ptr %l41
  br label %bb10
bb10:
  %t59 = load i32, ptr %l41, !tbaa !23
  store i32 %t59, ptr %l36, !tbaa !23
  br label %bb11
bb11:
  %t60 = load i32, ptr %l36, !tbaa !23
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i32, ptr %t63, i64 %t61
  store i32 %t60, ptr %t64, !tbaa !33
  store i32 0, ptr %rv
  br label %ret
bb12:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb13
bb13:
  %t72 = load i32, ptr %l45, !range !{i32 0, i32 33}
  %t74 = trunc i64 21 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb14, label %bb15
bb14:
  %t77 = load i32, ptr %l3, !tbaa !23
  store i32 %t77, ptr %l48, !tbaa !23
  br label %bb17
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l53
  br label %bb16
bb16:
  %t86 = load i32, ptr %l53, !tbaa !23
  store i32 %t86, ptr %l48, !tbaa !23
  br label %bb17
bb17:
  %t87 = load i32, ptr %l48, !tbaa !23
  store i32 %t87, ptr %l7, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 11
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l61
  br label %bb20
bb19:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb21
bb20:
  %t102 = load i32, ptr %l61, !range !{i32 0, i32 33}
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb22, label %bb23
bb22:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l7, !tbaa !23
  %t112 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t108, i32 %t109)
  store i1 %t112, ptr %l67
  br label %bb24
bb23:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb25
bb24:
  %t113 = load i1, ptr %l67, !tbaa !21
  store i1 %t113, ptr %l64, !tbaa !21
  br label %bb25
bb25:
  %t114 = load i1, ptr %l64, !tbaa !21
  br i1 %t114, label %bb26, label %bb27
bb26:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  store ptr %t117, ptr %l70, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l7, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l74
  br label %bb28
bb27:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb30
bb28:
  %t125 = load ptr, ptr %l70, !tbaa !29
  %t126 = load i32, ptr %l74, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t127, ptr %l75
  br label %bb29
bb29:
  %t128 = load i32, ptr %l75, !range !{i32 0, i32 6}
  %t130 = trunc i64 0 to i32
  %t131 = icmp eq i32 %t128, %t130
  store i1 %t131, ptr %l68, !tbaa !21
  br label %bb30
bb30:
  %t133 = load i1, ptr %l68, !tbaa !21
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l7, !tbaa !23
  %t140 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t140, ptr %l82
  br label %bb33
bb32:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb34
bb33:
  %t141 = load i1, ptr %l82, !tbaa !21
  store i1 %t141, ptr %l78, !tbaa !21
  br label %bb34
bb34:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb35, label %bb36
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l7, !tbaa !23
  %t147 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t145, i32 %t146, i64 %t147)
  store i32 %t151, ptr %l87
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t152 = load i32, ptr %l87, !tbaa !23
  store i32 %t152, ptr %l7, !tbaa !23
  br label %bb38
bb38:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Binding", ptr %t153, i32 0, i32 2
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l89, !tbaa !27
  %t157 = load i64, ptr %l2, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  store i32 %t162, ptr %l8, !tbaa !23
  %t164 = load i32, ptr %l8, !tbaa !23
  %t165 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t168 = icmp eq i32 %t164, %t165
  br i1 %t168, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb44
bb40:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Binding", ptr %t170, i32 0, i32 3
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l97, !tbaa !27
  %t174 = load i64, ptr %l2, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i1, ptr %t177, i64 %t174
  %t179 = load i1, ptr %t178, !tbaa !31
  br i1 %t179, label %bb41, label %bb42
bb41:
  %t181 = load i1, ptr %l4, !tbaa !21
  %t183 = xor i1 %t181, true
  store i1 %t183, ptr %l100, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l100, !tbaa !21
  store i1 %t185, ptr %l95, !tbaa !21
  br label %bb44
bb44:
  %t186 = load i1, ptr %l95, !tbaa !21
  br i1 %t186, label %bb45, label %bb46
bb45:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Binding", ptr %t187, i32 0, i32 2
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l104, !tbaa !27
  %t191 = load i64, ptr %l2, !tbaa !24
  %t192 = load i32, ptr %l7, !tbaa !23
  %t195 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t191
  store i32 %t192, ptr %t197, !tbaa !33
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Binding", ptr %t198, i32 0, i32 3
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l108, !tbaa !27
  %t202 = load i64, ptr %l2, !tbaa !24
  %t203 = load i1, ptr %l4, !tbaa !21
  %t206 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i1, ptr %t207, i64 %t202
  store i1 %t203, ptr %t208, !tbaa !31
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Binding", ptr %t209, i32 0, i32 4
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l112, !tbaa !27
  %t213 = load i64, ptr %l2, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i1, ptr %t218, i64 %t213
  store i1 %a5, ptr %t219, !tbaa !31
  store i32 0, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t220 = load i32, ptr %l8, !tbaa !23
  %t221 = load i32, ptr %l7, !tbaa !23
  %t224 = icmp eq i32 %t220, %t221
  br i1 %t224, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb51
bb49:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l8, !tbaa !23
  %t230 = load i32, ptr %l7, !tbaa !23
  %t234 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t228, i32 %t229, i32 %t230)
  store i1 %t234, ptr %l123
  br label %bb50
bb50:
  %t235 = load i1, ptr %l123, !tbaa !21
  store i1 %t235, ptr %l118, !tbaa !21
  br label %bb51
bb51:
  %t236 = load i1, ptr %l118, !tbaa !21
  br i1 %t236, label %bb52, label %bb53
bb52:
  store i32 0, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t237 = load i1, ptr %l4, !tbaa !21
  br i1 %t237, label %bb55, label %bb56
bb55:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr %"compiler/generic:Binding", ptr %t239, i32 0, i32 3
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l126, !tbaa !27
  %t243 = load i64, ptr %l2, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i1, ptr %t246, i64 %t243
  %t248 = load i1, ptr %t247, !tbaa !31
  br i1 %t248, label %bb57, label %bb58
bb56:
  br label %bb72
bb57:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l8, !tbaa !23
  %t252 = load i32, ptr %l7, !tbaa !23
  %t256 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t250, i32 %t251, i32 %t252)
  store i1 %t256, ptr %l133
  br label %bb59
bb58:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb59:
  %t257 = load i1, ptr %l133, !tbaa !21
  br i1 %t257, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb67
bb61:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/generic:Program", ptr %t258, i32 0, i32 2
  %t261 = load i32, ptr %l8, !tbaa !23
  %t264 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t260, i32 %t261)
  store i1 %t264, ptr %l138
  br label %bb62
bb62:
  %t265 = load i1, ptr %l138, !tbaa !21
  br i1 %t265, label %bb63, label %bb64
bb63:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/generic:Program", ptr %t266, i32 0, i32 2
  %t269 = load i32, ptr %l7, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t268, i32 %t269)
  store i1 %t272, ptr %l143
  br label %bb65
bb64:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb66
bb65:
  %t273 = load i1, ptr %l143, !tbaa !21
  store i1 %t273, ptr %l139, !tbaa !21
  br label %bb66
bb66:
  %t274 = load i1, ptr %l139, !tbaa !21
  store i1 %t274, ptr %l134, !tbaa !21
  br label %bb67
bb67:
  %t275 = load i1, ptr %l134, !tbaa !21
  store i1 %t275, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t276 = load i1, ptr %l129, !tbaa !21
  br i1 %t276, label %bb69, label %bb70
bb69:
  %t277 = load ptr, ptr %l1, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Binding", ptr %t277, i32 0, i32 2
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l145, !tbaa !27
  %t281 = load i64, ptr %l2, !tbaa !24
  %t282 = load i32, ptr %l7, !tbaa !23
  %t285 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i32, ptr %t286, i64 %t281
  store i32 %t282, ptr %t287, !tbaa !33
  br label %bb71
bb70:
  br label %bb71
bb71:
  store i32 0, ptr %rv
  br label %ret
bb72:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %l7, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l151
  br label %bb73
bb73:
  %t295 = load i32, ptr %l151, !range !{i32 0, i32 33}
  %t297 = trunc i64 20 to i32
  %t298 = icmp eq i32 %t295, %t297
  br i1 %t298, label %bb74, label %bb75
bb74:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/generic:Program", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %l8, !tbaa !23
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l158
  br label %bb76
bb75:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb77
bb76:
  %t307 = load i32, ptr %l158, !range !{i32 0, i32 33}
  %t309 = trunc i64 20 to i32
  %t310 = icmp eq i32 %t307, %t309
  %t312 = xor i1 %t310, true
  store i1 %t312, ptr %l154, !tbaa !21
  br label %bb77
bb77:
  %t314 = load i1, ptr %l154, !tbaa !21
  br i1 %t314, label %bb78, label %bb79
bb78:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  store ptr %t317, ptr %l164, !tbaa !29
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  %t321 = load i32, ptr %l7, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l168
  br label %bb80
bb79:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb82
bb80:
  %t325 = load ptr, ptr %l164, !tbaa !29
  %t326 = load i32, ptr %l168, !tbaa !23
  %t327 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t325, i32 %t326)
  store i32 %t327, ptr %l169
  br label %bb81
bb81:
  %t328 = load i32, ptr %l8, !tbaa !23
  %t329 = load i32, ptr %l169, !tbaa !23
  %t331 = icmp eq i32 %t329, %t328
  store i1 %t331, ptr %l162, !tbaa !21
  br label %bb82
bb82:
  %t333 = load i1, ptr %l162, !tbaa !21
  br i1 %t333, label %bb83, label %bb84
bb83:
  store i32 0, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load i32, ptr %l7, !tbaa !23
  %t340 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t336, i32 %t337)
  store i32 %t340, ptr %l175
  br label %bb86
bb86:
  %t341 = load i32, ptr %l175, !range !{i32 0, i32 33}
  %t343 = trunc i64 20 to i32
  %t344 = icmp eq i32 %t341, %t343
  br i1 %t344, label %bb87, label %bb88
bb87:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Program", ptr %t346, i32 0, i32 2
  store ptr %t348, ptr %l180, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/generic:Program", ptr %t349, i32 0, i32 2
  %t352 = load i32, ptr %l7, !tbaa !23
  %t355 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t351, i32 %t352)
  store i32 %t355, ptr %l184
  br label %bb89
bb88:
  %t356 = load i32, ptr %l7, !tbaa !23
  store i32 %t356, ptr %l178, !tbaa !23
  br label %bb91
bb89:
  %t358 = load ptr, ptr %l180, !tbaa !29
  %t359 = load i32, ptr %l184, !tbaa !23
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t358, i32 %t359)
  store i32 %t360, ptr %l185
  br label %bb90
bb90:
  %t361 = load i32, ptr %l185, !tbaa !23
  store i32 %t361, ptr %l178, !tbaa !23
  br label %bb91
bb91:
  %t362 = load i32, ptr %l178, !tbaa !23
  store i32 %t362, ptr %l9, !tbaa !23
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/generic:Program", ptr %t363, i32 0, i32 2
  %t366 = load i32, ptr %l8, !tbaa !23
  %t369 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t365, i32 %t366)
  store i32 %t369, ptr %l190
  br label %bb92
bb92:
  %t370 = load i32, ptr %l190, !range !{i32 0, i32 33}
  %t372 = trunc i64 19 to i32
  %t373 = icmp eq i32 %t370, %t372
  br i1 %t373, label %bb93, label %bb94
bb93:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 2
  %t378 = load i32, ptr %l9, !tbaa !23
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t377, i32 %t378)
  store i32 %t381, ptr %l197
  br label %bb95
bb94:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb96
bb95:
  %t382 = load i32, ptr %l197, !range !{i32 0, i32 33}
  %t384 = trunc i64 19 to i32
  %t385 = icmp eq i32 %t382, %t384
  store i1 %t385, ptr %l193, !tbaa !21
  br label %bb96
bb96:
  %t387 = load i1, ptr %l193, !tbaa !21
  br i1 %t387, label %bb97, label %bb98
bb97:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/generic:Program", ptr %t388, i32 0, i32 2
  store ptr %t390, ptr %l202, !tbaa !29
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/generic:Program", ptr %t391, i32 0, i32 2
  %t394 = load i32, ptr %l8, !tbaa !23
  %t397 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t393, i32 %t394)
  store i32 %t397, ptr %l206
  br label %bb99
bb98:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb102
bb99:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/generic:Program", ptr %t398, i32 0, i32 2
  %t401 = load i32, ptr %l9, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t400, i32 %t401)
  store i32 %t404, ptr %l210
  br label %bb100
bb100:
  %t405 = load ptr, ptr %l202, !tbaa !29
  %t406 = load i32, ptr %l206, !tbaa !23
  %t407 = load i32, ptr %l210, !tbaa !23
  %t408 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t405, i32 %t406, i32 %t407)
  store i1 %t408, ptr %l211
  br label %bb101
bb101:
  %t409 = load i1, ptr %l211, !tbaa !21
  store i1 %t409, ptr %l200, !tbaa !21
  br label %bb102
bb102:
  %t410 = load i1, ptr %l200, !tbaa !21
  br i1 %t410, label %bb103, label %bb104
bb103:
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Binding", ptr %t411, i32 0, i32 4
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  store { i64, ptr } %t414, ptr %l214, !tbaa !27
  %t415 = load i64, ptr %l2, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr i1, ptr %t418, i64 %t415
  %t420 = load i1, ptr %t419, !tbaa !31
  %t422 = xor i1 %t420, true
  store i1 %t422, ptr %l212, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb105
bb105:
  %t424 = load i1, ptr %l212, !tbaa !21
  br i1 %t424, label %bb106, label %bb107
bb106:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l8, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l221
  br label %bb108
bb107:
  br label %bb119
bb108:
  %t432 = load i32, ptr %l221, !tbaa !23
  %t433 = icmp ne i32 %t432, 0
  br i1 %t433, label %bb109, label %bb110
bb109:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/generic:Program", ptr %t435, i32 0, i32 2
  %t438 = load i32, ptr %l9, !tbaa !23
  %t441 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t437, i32 %t438)
  store i32 %t441, ptr %l227
  br label %bb111
bb110:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb113
bb111:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 2
  %t445 = load i32, ptr %l8, !tbaa !23
  %t448 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t444, i32 %t445)
  store i32 %t448, ptr %l231
  br label %bb112
bb112:
  %t449 = load i32, ptr %l227, !tbaa !23
  %t450 = load i32, ptr %l231, !tbaa !23
  %t451 = icmp ne i32 %t449, %t450
  store i1 %t451, ptr %l223, !tbaa !21
  br label %bb113
bb113:
  %t453 = load i1, ptr %l223, !tbaa !21
  br i1 %t453, label %bb114, label %bb115
bb114:
  %t454 = load ptr, ptr %l1, !tbaa !29
  %t456 = getelementptr %"compiler/generic:Binding", ptr %t454, i32 0, i32 2
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  store { i64, ptr } %t457, ptr %l234, !tbaa !27
  %t458 = load i64, ptr %l2, !tbaa !24
  store i64 %t458, ptr %l235, !tbaa !24
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/generic:Program", ptr %t459, i32 0, i32 2
  store ptr %t461, ptr %l237, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/generic:Program", ptr %t462, i32 0, i32 2
  %t465 = load i32, ptr %l8, !tbaa !23
  %t468 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t464, i32 %t465)
  store i32 %t468, ptr %l241
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t469 = load ptr, ptr %l237, !tbaa !29
  %t470 = load i32, ptr %l241, !tbaa !23
  %t471 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t469, i32 %t470, i32 0)
  store i32 %t471, ptr %l242
  br label %bb117
bb117:
  %t472 = load i32, ptr %l242, !tbaa !23
  %t473 = load i64, ptr %l235, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr i32, ptr %t475, i64 %t473
  store i32 %t472, ptr %t476, !tbaa !33
  br label %bb118
bb118:
  store i32 0, ptr %rv
  br label %ret
bb119:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/generic:Program", ptr %t477, i32 0, i32 2
  store ptr %t479, ptr %l244, !tbaa !29
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load i32, ptr %l8, !tbaa !23
  %t484 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t480, i32 %t481)
  store i32 %t484, ptr %l247
  br label %bb120
bb120:
  %t485 = load ptr, ptr %l244, !tbaa !29
  %t486 = load i32, ptr %l247, !tbaa !23
  %t487 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t485, i32 %t486)
  store i1 %t487, ptr %l248
  br label %bb121
bb121:
  %t488 = load i1, ptr %l248, !tbaa !21
  br i1 %t488, label %bb122, label %bb123
bb122:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/generic:Program", ptr %t489, i32 0, i32 2
  store ptr %t491, ptr %l251, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load i32, ptr %l7, !tbaa !23
  %t496 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t492, i32 %t493)
  store i32 %t496, ptr %l254
  br label %bb124
bb123:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb126
bb124:
  %t497 = load ptr, ptr %l251, !tbaa !29
  %t498 = load i32, ptr %l254, !tbaa !23
  %t499 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t497, i32 %t498)
  store i1 %t499, ptr %l255
  br label %bb125
bb125:
  %t500 = load i1, ptr %l255, !tbaa !21
  store i1 %t500, ptr %l249, !tbaa !21
  br label %bb126
bb126:
  %t501 = load i1, ptr %l249, !tbaa !21
  br i1 %t501, label %bb127, label %bb128
bb127:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i32, ptr %l7, !tbaa !23
  %t504 = load i32, ptr %l8, !tbaa !23
  %t508 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t502, i32 %t503, i32 %t504)
  store i1 %t508, ptr %l259
  br label %bb129
bb128:
  br label %bb140
bb129:
  %t509 = load i1, ptr %l259, !tbaa !21
  br i1 %t509, label %bb130, label %bb131
bb130:
  store i32 0, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load i32, ptr %l8, !tbaa !23
  %t512 = load i32, ptr %l7, !tbaa !23
  %t516 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t510, i32 %t511, i32 %t512)
  store i1 %t516, ptr %l263
  br label %bb133
bb133:
  %t517 = load i1, ptr %l263, !tbaa !21
  br i1 %t517, label %bb134, label %bb135
bb134:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr %"compiler/generic:Binding", ptr %t518, i32 0, i32 4
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !27
  store { i64, ptr } %t521, ptr %l266, !tbaa !27
  %t522 = load i64, ptr %l2, !tbaa !24
  %t524 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !27
  %t526 = getelementptr i1, ptr %t525, i64 %t522
  %t527 = load i1, ptr %t526, !tbaa !31
  %t529 = xor i1 %t527, true
  store i1 %t529, ptr %l264, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb136
bb136:
  %t531 = load i1, ptr %l264, !tbaa !21
  br i1 %t531, label %bb137, label %bb138
bb137:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr %"compiler/generic:Binding", ptr %t532, i32 0, i32 2
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l271, !tbaa !27
  %t536 = load i64, ptr %l2, !tbaa !24
  %t537 = load i32, ptr %l7, !tbaa !23
  %t540 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr i32, ptr %t541, i64 %t536
  store i32 %t537, ptr %t542, !tbaa !33
  store i32 0, ptr %rv
  br label %ret
bb138:
  br label %bb139
bb139:
  store i32 65536, ptr %rv
  br label %ret
bb140:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t546 = getelementptr %"compiler/generic:Program", ptr %t544, i32 0, i32 2
  %t547 = load i32, ptr %l8, !tbaa !23
  %t550 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t546, i32 %t547)
  store i32 %t550, ptr %l278
  br label %bb141
bb141:
  %t551 = load i32, ptr %l278, !range !{i32 0, i32 33}
  %t553 = trunc i64 20 to i32
  %t554 = icmp eq i32 %t551, %t553
  br i1 %t554, label %bb142, label %bb143
bb142:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/generic:Program", ptr %t556, i32 0, i32 2
  %t559 = load i32, ptr %l7, !tbaa !23
  %t562 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t558, i32 %t559)
  store i32 %t562, ptr %l285
  br label %bb144
bb143:
  store i1 false, ptr %l281, !tbaa !21
  br label %bb145
bb144:
  %t563 = load i32, ptr %l285, !range !{i32 0, i32 33}
  %t565 = trunc i64 20 to i32
  %t566 = icmp eq i32 %t563, %t565
  store i1 %t566, ptr %l281, !tbaa !21
  br label %bb145
bb145:
  %t568 = load i1, ptr %l281, !tbaa !21
  br i1 %t568, label %bb146, label %bb147
bb146:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t571 = getelementptr %"compiler/generic:Program", ptr %t569, i32 0, i32 2
  %t572 = load i32, ptr %l8, !tbaa !23
  %t575 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t571, i32 %t572)
  store i32 %t575, ptr %l292
  br label %bb148
bb147:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb150
bb148:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/generic:Program", ptr %t576, i32 0, i32 2
  %t579 = load i32, ptr %l7, !tbaa !23
  %t582 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t578, i32 %t579)
  store i32 %t582, ptr %l296
  br label %bb149
bb149:
  %t583 = load i32, ptr %l292, !tbaa !23
  %t584 = load i32, ptr %l296, !tbaa !23
  %t585 = icmp eq i32 %t583, %t584
  store i1 %t585, ptr %l288, !tbaa !21
  br label %bb150
bb150:
  %t587 = load i1, ptr %l288, !tbaa !21
  br i1 %t587, label %bb151, label %bb152
bb151:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = getelementptr %"compiler/generic:Program", ptr %t588, i32 0, i32 2
  %t591 = load i32, ptr %l8, !tbaa !23
  %t594 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t590, i32 %t591)
  store i64 %t594, ptr %l301
  br label %bb153
bb152:
  br label %bb160
bb153:
  %t595 = load i64, ptr %l301, !tbaa !24
  store i64 %t595, ptr %l10, !tbaa !24
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/generic:Program", ptr %t596, i32 0, i32 2
  %t599 = load i32, ptr %l7, !tbaa !23
  %t602 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t598, i32 %t599)
  store i64 %t602, ptr %l305
  br label %bb154
bb154:
  %t603 = load i64, ptr %l305, !tbaa !24
  store i64 %t603, ptr %l11, !tbaa !24
  %t604 = load ptr, ptr %l1, !tbaa !29
  %t606 = getelementptr %"compiler/generic:Binding", ptr %t604, i32 0, i32 4
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !27
  store { i64, ptr } %t607, ptr %l307, !tbaa !27
  %t608 = load i64, ptr %l2, !tbaa !24
  %t610 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = getelementptr i1, ptr %t611, i64 %t608
  %t613 = load i1, ptr %t612, !tbaa !31
  %t615 = xor i1 %t613, true
  br i1 %t615, label %bb155, label %bb156
bb155:
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t619 = getelementptr %"compiler/generic:Binding", ptr %t617, i32 0, i32 2
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l312, !tbaa !27
  %t621 = load i64, ptr %l2, !tbaa !24
  store i64 %t621, ptr %l313, !tbaa !24
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/generic:Program", ptr %t622, i32 0, i32 2
  store ptr %t624, ptr %l315, !tbaa !29
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/generic:Program", ptr %t625, i32 0, i32 2
  %t628 = load i32, ptr %l7, !tbaa !23
  %t631 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t627, i32 %t628)
  store i32 %t631, ptr %l319
  br label %bb157
bb156:
  br label %bb159
bb157:
  %t632 = load i64, ptr %l10, !tbaa !24
  %t633 = load i64, ptr %l11, !tbaa !24
  %t636 = and i64 %t632, %t633
  %t637 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t640 = and i64 %t636, %t637
  %t641 = load i64, ptr %l10, !tbaa !24
  %t642 = load i64, ptr %l11, !tbaa !24
  %t645 = or i64 %t641, %t642
  %t646 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t649 = and i64 %t645, %t646
  %t652 = or i64 %t640, %t649
  %t653 = load ptr, ptr %l315, !tbaa !29
  %t654 = load i32, ptr %l319, !tbaa !23
  %t656 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t653, i32 %t654, i64 %t652)
  store i32 %t656, ptr %l331
  br label %bb158
bb158:
  %t657 = load i32, ptr %l331, !tbaa !23
  %t658 = load i64, ptr %l313, !tbaa !24
  %t659 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t660 = load ptr, ptr %t659, !tbaa !27
  %t661 = getelementptr i32, ptr %t660, i64 %t658
  store i32 %t657, ptr %t661, !tbaa !33
  br label %bb159
bb159:
  store i32 0, ptr %rv
  br label %ret
bb160:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebufferUnended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca i1
  %l9 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l26 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l13, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t27 = load i1, ptr %l18, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t38 = add i64 %a3, 1
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %t33, i32 %t34, ptr %a2, i64 %t38, i1 false)
  store i32 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i32, ptr %l26, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %v2, ptr %t3, { i64, ptr } %t4)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t10 = insertvalue { i32, i32 } zeroinitializer, i32 0, 1
  store { i32, i32 } %t10, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  store ptr %l3, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonType(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  %t16 = extractvalue { i32, i32 } %t15, 1
  %t17 = extractvalue { i32, i32 } %t15, 0
  store i32 %t17, ptr %l14
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb8, label %ok.19, !prof !99
ok.19:
  store i32 %t16, ptr %l13
  br label %bb7
bb7:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %l10, !tbaa !23
  br label %bb9
bb8:
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = lshr i32 %t21, 16
  %t23 = and i32 %t21, 65535
  %t24 = icmp eq i32 %t22, 1
  %t25 = select i1 %t24, i32 1, i32 0
  %t26 = icmp eq i32 %t22, 2
  %t27 = select i1 %t26, i32 2, i32 %t25
  %t28 = icmp eq i32 %t21, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t23
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t33 = insertvalue { i32, i32 } zeroinitializer, i32 %t31, 0
  store { i32, i32 } %t33, ptr %rv
  br label %ret
bb9:
  %t34 = load ptr, ptr %l9, !tbaa !29
  %t35 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t34, i32 %t35)
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %v2, ptr %t36, { i64, ptr } %t37)
  store i1 %t40, ptr %l18
  br label %bb11
bb11:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s2, ptr %t42, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t44, ptr %l20
  br label %bb15
bb15:
  %t45 = load i1, ptr %l20, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t49 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t49, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb6
bb20:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l24, !tbaa !29
  %t54 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t54, ptr %l26
  br label %bb21
bb21:
  %t55 = load ptr, ptr %l24, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t55, { i64, ptr } %t56)
  store i32 %t57, ptr %l27
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l27, !tbaa !23
  %t59 = insertvalue { i32, i32 } zeroinitializer, i32 %t58, 1
  store { i32, i32 } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i1
  %l10 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t3, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t11 = or i64 %t7, %t8
  store i64 %t11, ptr %l2, !tbaa !24
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonInner(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  %t18 = extractvalue { i32, i32 } %t17, 1
  %t19 = extractvalue { i32, i32 } %t17, 0
  store i32 %t19, ptr %l14
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb6, label %ok.21, !prof !99
ok.21:
  store i32 %t18, ptr %l13
  br label %bb5
bb5:
  %t22 = load i32, ptr %l13, !tbaa !23
  store i32 %t22, ptr %l10, !tbaa !23
  br label %bb7
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t24, 2
  %t29 = select i1 %t28, i32 2, i32 %t27
  %t30 = icmp eq i32 %t23, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t25
  %t33 = select i1 %t30, i32 0, i32 %t32
  call void @__olang_scope_close(ptr %s0)
  %t35 = insertvalue { i32, i32 } zeroinitializer, i32 %t33, 0
  store { i32, i32 } %t35, ptr %rv
  br label %ret
bb7:
  %t36 = load i32, ptr %l10, !tbaa !23
  store i32 %t36, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t37, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load i1, ptr %l17, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %l3, !tbaa !23
  %t45 = load i64, ptr %l2, !tbaa !24
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t43, i32 %t44, i64 %t45)
  store i32 %t49, ptr %l22
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i32, ptr %l22, !tbaa !23
  %t51 = insertvalue { i32, i32 } zeroinitializer, i32 %t50, 1
  store { i32, i32 } %t51, ptr %rv
  br label %ret
bb12:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t56 = icmp ne i64 %t52, %t53
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t59 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t60 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t62 = insertvalue { i32, i32 } zeroinitializer, i32 %t60, 1
  store { i32, i32 } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecolumnFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i32
  %l17 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l31 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l68 = alloca i64
  %l71 = alloca { i64, ptr }
  %l74 = alloca i32
  %l80 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i32, ptr %l13, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l17
  br label %bb2
bb2:
  %t14 = load i1, ptr %l17, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l22
  br label %bb5
bb5:
  %t22 = load i1, ptr %l22, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load i1, ptr %l27, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l24, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  store ptr %t38, ptr %l31, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l35
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l31, !tbaa !29
  %t47 = load i32, ptr %l35, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l36
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t49, ptr %l3, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l38, !tbaa !24
  %t53 = load i64, ptr %l38, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = icmp sle i64 %t56, 2305843009213693951
  br i1 %t57, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_5e7d85fe5a4092b0_8f62b4b719433814)
  unreachable
bb18:
  %t59 = load i64, ptr %l38, !tbaa !24
  %t60 = mul i64 %t59, 4
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5e7d85fe5a4092b0_8f62b4b719433814)
  unreachable
bb20:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb25
bb22:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load i64, ptr %l5, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l50, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb24
bb24:
  %t95 = load i64, ptr %l50, !tbaa !24
  store i64 %t95, ptr %l47, !tbaa !24
  br label %bb25
bb25:
  %t96 = load i64, ptr %l47, !tbaa !24
  store i64 %t96, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb26
bb26:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t106 = load i64, ptr %l9, !tbaa !24
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  store i64 %t115, ptr %l68, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t119, ptr %l71, !tbaa !27
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t118, i32 %t125, i32 0)
  store i32 %t128, ptr %l74
  br label %bb30
bb30:
  %t129 = load i32, ptr %l74, !tbaa !23
  %t130 = load i64, ptr %l68, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i32, ptr %t132, i64 %t130
  store i32 %t129, ptr %t133, !tbaa !33
  br label %bb31
bb31:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb26
bb32:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t140, { i64, ptr } %t141)
  store i32 %t144, ptr %l80
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t145 = load i32, ptr %l80, !tbaa !23
  store i32 %t145, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstraint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/generic:varRow"
  %l9 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l34 = alloca i64
  %l39 = alloca %"compiler/generic:varRow"
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i32
  %l54 = alloca i32
  %l58 = alloca i32
  %l59 = alloca %"compiler/generic:varRow"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeParam", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Context", ptr %t8, i32 0, i32 2
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TypeParam", ptr %t11, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  %t17 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v1, ptr %t10, i32 %t14)
  %t18 = extractvalue { i32, i32 } %t17, 1
  %t19 = extractvalue { i32, i32 } %t17, 0
  store i32 %t19, ptr %l15
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb5, label %ok.21, !prof !99
ok.21:
  store i32 %t18, ptr %l14
  br label %bb4
bb4:
  %t22 = load i32, ptr %l14, !tbaa !23
  store i32 %t22, ptr %l9, !tbaa !23
  br label %bb7
bb5:
  br label %bb6
bb6:
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t23, ptr %l9, !tbaa !23
  br label %bb7
bb7:
  %t25 = load i32, ptr %l9, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t35 = trunc i64 25 to i32
  %t36 = icmp eq i32 %t33, %t35
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 14
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Context", ptr %t43, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t49 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t42, i64 %t46)
  %t50 = extractvalue { i32, i64 } %t49, 1
  %t51 = extractvalue { i32, i64 } %t49, 0
  store i32 %t51, ptr %l30
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb13, label %ok.53, !prof !99
ok.53:
  store i64 %t50, ptr %l29
  br label %bb12
bb12:
  %t54 = load i64, ptr %l29, !tbaa !24
  store i64 %t54, ptr %l24, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t57, i32 %t58)
  store i64 %t61, ptr %l34
  br label %bb16
bb16:
  %t62 = load i64, ptr %l24, !tbaa !24
  %t63 = load i64, ptr %l34, !tbaa !24
  %t64 = add i64 %t62, %t63
  store i64 %t64, ptr %l4, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 16
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = call %"compiler/generic:varRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eAt_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %t68, i64 %t69)
  store %"compiler/generic:varRow" %t72, ptr %l39
  br label %bb17
bb17:
  %t73 = load %"compiler/generic:varRow", ptr %l39
  store %"compiler/generic:varRow" %t73, ptr %l5
  %t74 = getelementptr %"compiler/generic:varRow", ptr %l5, i32 0, i32 2
  %t75 = load i32, ptr %t74, !tbaa !23
  %t76 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t79 = icmp ne i32 %t75, %t76
  br i1 %t79, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb20
bb19:
  %t81 = getelementptr %"compiler/generic:varRow", ptr %l5, i32 0, i32 3
  %t82 = load i32, ptr %t81, !tbaa !23
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t86 = icmp ne i32 %t82, %t83
  store i1 %t86, ptr %l43, !tbaa !21
  br label %bb20
bb20:
  %t88 = load i1, ptr %l43, !tbaa !21
  br i1 %t88, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 16
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load i64, ptr %l4, !tbaa !24
  store i64 %t92, ptr %l49, !tbaa !24
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Context", ptr %t93, i32 0, i32 1
  %t96 = load i64, ptr %t95, !tbaa !24
  store i64 %t96, ptr %l51, !tbaa !24
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:TypeParam", ptr %t97, i32 0, i32 1
  %t100 = load i32, ptr %t99, !tbaa !23
  store i32 %t100, ptr %l53, !tbaa !23
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t101, ptr %l54, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t108 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundOf(ptr %v0, ptr %v1, ptr %v2, ptr %t102, ptr %t103, ptr %t104)
  store i32 %t108, ptr %l58
  br label %bb24
bb24:
  %t109 = load i64, ptr %l51, !tbaa !24
  %t110 = load i32, ptr %l53, !tbaa !23
  %t111 = load i32, ptr %l54, !tbaa !23
  %t112 = load i32, ptr %l58, !tbaa !23
  %t113 = call %"compiler/generic:varRow" @compiler_2fgeneric_3avarRow_2ector(ptr %s0, i64 %t109, i32 %t110, i32 %t111, i32 %t112)
  store %"compiler/generic:varRow" %t113, ptr %l59
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l48, !tbaa !29
  %t115 = load i64, ptr %l49, !tbaa !24
  %t116 = load %"compiler/generic:varRow", ptr %l59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eSetAt_H989a0ed1a318d7d0cbb6cc41385b33d2(ptr %v0, ptr %t114, i64 %t115, %"compiler/generic:varRow" %t116)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l21 = alloca %"compiler/generic:Context"
  %l24 = alloca ptr
  %l28 = alloca i1
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l65 = alloca i32
  %l71 = alloca i32
  %l74 = alloca %"compiler/generic:Context"
  %t17 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 12
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l16
  br label %bb1
bb1:
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load i32, ptr %l1, !tbaa !23
  %t13 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t11)
  store i64 %t13, ptr %l18
  br label %bb2
bb2:
  %t14 = load i64, ptr %l18, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t17, ptr %v1, i64 %t15, i64 %t16)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t17, i64 160, i1 false)
  br label %bb3
bb3:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 160, i64 8)
  store ptr %t20, ptr %lp4
  %t21 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %l21, i64 160, i1 false)
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t22, i32 %t23)
  store ptr %t26, ptr %l24
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l24, !tbaa !29
  store ptr %t27, ptr %l5, !tbaa !29
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = icmp sgt i64 %t39, 0
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb8, label %bb9
bb8:
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TypeDecl", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb10, label %bb11
bb9:
  br label %bb24
bb10:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb15
bb12:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l42, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb14
bb14:
  %t77 = load i64, ptr %l42, !tbaa !24
  store i64 %t77, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l11, !tbaa !24
  %t97 = load ptr, ptr %lp4
  %t98 = getelementptr %"compiler/generic:Context", ptr %t97, i32 0, i32 2
  store ptr %t98, ptr %l60, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t101 = getelementptr %"compiler/ast:TypeDecl", ptr %t99, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l62, !tbaa !27
  %t103 = load i64, ptr %l11, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = getelementptr %"compiler/ast:TypeParam", ptr %t108, i32 0, i32 1
  %t111 = load i32, ptr %t110, !tbaa !23
  store i32 %t111, ptr %l65, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i64, ptr %l3, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t114, i64 %t115, i64 %t116, i64 %t117)
  store i32 %t122, ptr %l71
  br label %bb20
bb20:
  %t123 = load ptr, ptr %l60, !tbaa !29
  %t124 = load i32, ptr %l65, !tbaa !23
  %t125 = load i32, ptr %l71, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t123, i32 %t124, i32 %t125)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l10, !tbaa !24
  br label %bb16
bb23:
  br label %bb24
bb24:
  %t130 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t130, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l74, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eensureModules(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l38 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca ptr
  %l53 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 27
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/load:Loader", ptr %t9, i32 0, i32 10
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load i64, ptr %l12, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l16, !tbaa !24
  store i64 %t42, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t51 = load i64, ptr %l1, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l3, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l6, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l38, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/load:Loader", ptr %t67, i32 0, i32 10
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l43
  br label %bb12
bb12:
  %t74 = load ptr, ptr %l43, !tbaa !29
  %t76 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t78 = load ptr, ptr %l38, !tbaa !29
  %t80 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v0, ptr %t78, { i64, ptr } %t77)
  store i64 %t80, ptr %l46
  br label %bb13
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 24
  store ptr %t83, ptr %l48, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/load:Loader", ptr %t87, i32 0, i32 10
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l53
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l53, !tbaa !29
  %t96 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l6, !tbaa !24
  %t99 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t99, { i64, ptr } %t97, i64 %t98)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l5, !tbaa !24
  br label %bb8
bb17:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l59, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 10
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l63
  br label %bb18
bb18:
  %t115 = load i64, ptr %l63, !tbaa !24
  %t116 = load ptr, ptr %l59, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 27
  store i64 %t115, ptr %t117, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentryHeld(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i64
  %l32 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t13, i64 %t14)
  store i32 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i32, ptr %l14, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l18
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l22
  br label %bb8
bb8:
  %t33 = load i32, ptr %l18, !tbaa !23
  %t34 = load i32, ptr %l22, !tbaa !23
  %t35 = icmp eq i32 %t33, %t34
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l28
  br label %bb11
bb10:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l5, !tbaa !23
  %t50 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t50, ptr %l32
  br label %bb12
bb12:
  %t51 = load i64, ptr %l32, !tbaa !65
  %t52 = xor i64 %t51, -1
  %t53 = load i64, ptr %l28, !tbaa !65
  %t55 = and i64 %t53, %t52
  %t57 = icmp eq i64 %t55, 0
  store i1 %t57, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l24, !tbaa !21
  br i1 %t59, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb1
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %t29, i32 %t27, ptr %a2)
  store i1 %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/generic:folded"
  %l6 = alloca %"compiler/generic:folded"
  %l7 = alloca %"compiler/generic:folded"
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i1
  %l24 = alloca %"compiler/generic:folded"
  %l31 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l44 = alloca %"compiler/generic:folded"
  %l48 = alloca %"compiler/generic:folded"
  %l52 = alloca %"compiler/generic:folded"
  %l56 = alloca i1
  %l60 = alloca %"compiler/generic:folded"
  %l64 = alloca i1
  %l70 = alloca %"compiler/generic:folded"
  %l74 = alloca i32
  %l77 = alloca i1
  %l80 = alloca i1
  %l81 = alloca %"compiler/generic:folded"
  %l87 = alloca i1
  %l89 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l102 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l121 = alloca i1
  %l138 = alloca i1
  %l146 = alloca i1
  %l152 = alloca i64
  %l154 = alloca i64
  %l156 = alloca %"compiler/generic:folded"
  %l178 = alloca %"compiler/generic:folded"
  %l182 = alloca i64
  %l197 = alloca i64
  %l226 = alloca i32
  %l231 = alloca i32
  %l237 = alloca i64
  %l239 = alloca ptr
  %l242 = alloca i32
  %l243 = alloca i64
  %l246 = alloca i1
  %l250 = alloca %"compiler/generic:folded"
  %l254 = alloca i64
  %l259 = alloca i1
  %l261 = alloca ptr
  %l264 = alloca i32
  %l265 = alloca i1
  %l266 = alloca i64
  %l270 = alloca i64
  %l274 = alloca i64
  %l283 = alloca i64
  %l284 = alloca %"compiler/generic:folded"
  %l290 = alloca %"compiler/generic:folded"
  %l291 = alloca i64
  %l295 = alloca i64
  %l299 = alloca i64
  %l302 = alloca %"compiler/generic:folded"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t3 = trunc i64 45 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t8 = trunc i64 46 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l18, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t18 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t12, ptr %t13, ptr %t14)
  store %"compiler/generic:folded" %t18, ptr %l24
  br label %bb6
bb5:
  br label %bb23
bb6:
  %t19 = load %"compiler/generic:folded", ptr %l24
  store %"compiler/generic:folded" %t19, ptr %l5
  %t20 = getelementptr %"compiler/generic:folded", ptr %l5, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t25 = icmp ne i64 %t21, %t22
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load %"compiler/generic:folded", ptr %l5
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/generic:folded" %t27, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t29 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t31 = trunc i64 45 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = getelementptr %"compiler/generic:folded", ptr %l5, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp eq i64 %t35, 0
  store i1 %t37, ptr %l31, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l31, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb18
bb14:
  %t40 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t42 = trunc i64 46 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = getelementptr %"compiler/generic:folded", ptr %l5, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = icmp ne i64 %t46, 0
  store i1 %t48, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t50 = load i1, ptr %l37, !tbaa !21
  store i1 %t50, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t52 = load %"compiler/generic:folded", ptr %l5
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/generic:folded" %t52, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t60 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v3, ptr %t54, ptr %t55, ptr %t56)
  store %"compiler/generic:folded" %t60, ptr %l44
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load %"compiler/generic:folded", ptr %l44
  store %"compiler/generic:folded" %t61, ptr %rv
  br label %ret
bb23:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t68 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t62, ptr %t63, ptr %t64)
  store %"compiler/generic:folded" %t68, ptr %l48
  br label %bb24
bb24:
  %t69 = load %"compiler/generic:folded", ptr %l48
  store %"compiler/generic:folded" %t69, ptr %l6
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t76 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v3, ptr %t70, ptr %t71, ptr %t72)
  store %"compiler/generic:folded" %t76, ptr %l52
  br label %bb25
bb25:
  %t77 = load %"compiler/generic:folded", ptr %l52
  store %"compiler/generic:folded" %t77, ptr %l7
  %t78 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t83 = icmp eq i64 %t79, %t80
  br i1 %t83, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  %t85 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 0
  %t86 = load i64, ptr %t85, !tbaa !24
  %t87 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t90 = icmp eq i64 %t86, %t87
  store i1 %t90, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l56, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t93 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t93, ptr %l60
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load %"compiler/generic:folded", ptr %l60
  store %"compiler/generic:folded" %t94, ptr %rv
  br label %ret
bb32:
  %t95 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 0
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t100 = icmp eq i64 %t96, %t97
  br i1 %t100, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb35
bb34:
  %t102 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t107 = icmp eq i64 %t103, %t104
  store i1 %t107, ptr %l64, !tbaa !21
  br label %bb35
bb35:
  %t109 = load i1, ptr %l64, !tbaa !21
  br i1 %t109, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load i64, ptr @G_2ecompiler_2fgeneric_2ePending, !tbaa !24
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t114 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s5, i64 %t110, i64 0, i32 %t111)
  store %"compiler/generic:folded" %t114, ptr %l70
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t115 = load %"compiler/generic:folded", ptr %l70
  store %"compiler/generic:folded" %t115, ptr %rv
  br label %ret
bb39:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/generic:folded", ptr %l6
  %t118 = load %"compiler/generic:folded", ptr %l7
  %t122 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeet(ptr %v0, ptr %t116, %"compiler/generic:folded" %t117, %"compiler/generic:folded" %t118)
  store i32 %t122, ptr %l74
  br label %bb40
bb40:
  %t123 = load i32, ptr %l74, !tbaa !23
  store i32 %t123, ptr %l8, !tbaa !23
  %t124 = load i32, ptr %l8, !tbaa !23
  %t126 = icmp eq i32 %t124, -1
  br i1 %t126, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb44
bb42:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l8, !tbaa !23
  %t132 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewide(ptr %v0, ptr %t128, i32 %t129)
  store i1 %t132, ptr %l80
  br label %bb43
bb43:
  %t133 = load i1, ptr %l80, !tbaa !21
  store i1 %t133, ptr %l77, !tbaa !21
  br label %bb44
bb44:
  %t134 = load i1, ptr %l77, !tbaa !21
  br i1 %t134, label %bb45, label %bb46
bb45:
  %t135 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t135, ptr %l81
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load %"compiler/generic:folded", ptr %l81
  store %"compiler/generic:folded" %t136, ptr %rv
  br label %ret
bb48:
  %t137 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l9, !tbaa !24
  %t140 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  store i64 %t141, ptr %l10, !tbaa !24
  %t143 = load i32, ptr %l8, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t147 = icmp ne i32 %t143, %t144
  br i1 %t147, label %bb49, label %bb50
bb49:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  store ptr %t151, ptr %l89, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l8, !tbaa !23
  %t156 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l92
  br label %bb51
bb50:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb53
bb51:
  %t157 = load ptr, ptr %l89, !tbaa !29
  %t158 = load i32, ptr %l92, !tbaa !23
  %t159 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t157, i32 %t158)
  store i1 %t159, ptr %l93
  br label %bb52
bb52:
  %t160 = load i1, ptr %l93, !tbaa !21
  store i1 %t160, ptr %l87, !tbaa !21
  br label %bb53
bb53:
  %t161 = load i1, ptr %l87, !tbaa !21
  store i1 %t161, ptr %l11, !tbaa !21
  %t162 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t164 = trunc i64 94 to i32
  %t165 = icmp eq i32 %t162, %t164
  br i1 %t165, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb56
bb55:
  %t167 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t169 = trunc i64 95 to i32
  %t170 = icmp eq i32 %t167, %t169
  store i1 %t170, ptr %l96, !tbaa !21
  br label %bb56
bb56:
  %t172 = load i1, ptr %l96, !tbaa !21
  br i1 %t172, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb59
bb58:
  %t173 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t175 = trunc i64 97 to i32
  %t176 = icmp eq i32 %t173, %t175
  store i1 %t176, ptr %l99, !tbaa !21
  br label %bb59
bb59:
  %t178 = load i1, ptr %l99, !tbaa !21
  br i1 %t178, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb62
bb61:
  %t179 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t181 = trunc i64 98 to i32
  %t182 = icmp eq i32 %t179, %t181
  store i1 %t182, ptr %l102, !tbaa !21
  br label %bb62
bb62:
  %t184 = load i1, ptr %l102, !tbaa !21
  br i1 %t184, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb65
bb64:
  %t185 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t187 = trunc i64 99 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l105, !tbaa !21
  br label %bb65
bb65:
  %t190 = load i1, ptr %l105, !tbaa !21
  br i1 %t190, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb68
bb67:
  %t191 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t193 = trunc i64 100 to i32
  %t194 = icmp eq i32 %t191, %t193
  store i1 %t194, ptr %l108, !tbaa !21
  br label %bb68
bb68:
  %t196 = load i1, ptr %l108, !tbaa !21
  br i1 %t196, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = load i1, ptr %l11, !tbaa !21
  br i1 %t197, label %bb71, label %bb72
bb70:
  br label %bb109
bb71:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t201 = load i64, ptr %l10, !tbaa !24
  %t205 = icmp ult i64 %t199, %t201
  store i1 %t205, ptr %l112, !tbaa !21
  br label %bb73
bb72:
  %t207 = load i64, ptr %l9, !tbaa !24
  %t208 = load i64, ptr %l10, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  store i1 %t211, ptr %l112, !tbaa !21
  br label %bb73
bb73:
  %t213 = load i1, ptr %l112, !tbaa !21
  store i1 %t213, ptr %l12, !tbaa !21
  %t214 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t216 = trunc i64 94 to i32
  %t217 = icmp eq i32 %t214, %t216
  br i1 %t217, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t220 = load i64, ptr %l10, !tbaa !24
  %t223 = icmp eq i64 %t219, %t220
  store i1 %t223, ptr %l121, !tbaa !21
  br label %bb104
bb77:
  %t225 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t227 = trunc i64 95 to i32
  %t228 = icmp eq i32 %t225, %t227
  br i1 %t228, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  %t230 = load i64, ptr %l9, !tbaa !24
  %t231 = load i64, ptr %l10, !tbaa !24
  %t234 = icmp ne i64 %t230, %t231
  store i1 %t234, ptr %l121, !tbaa !21
  br label %bb104
bb81:
  %t236 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t238 = trunc i64 97 to i32
  %t239 = icmp eq i32 %t236, %t238
  br i1 %t239, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t241 = load i1, ptr %l12, !tbaa !21
  store i1 %t241, ptr %l121, !tbaa !21
  br label %bb104
bb85:
  %t243 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t245 = trunc i64 98 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t248 = load i1, ptr %l12, !tbaa !21
  br i1 %t248, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb91
bb90:
  %t250 = load i64, ptr %l9, !tbaa !24
  %t251 = load i64, ptr %l10, !tbaa !24
  %t254 = icmp eq i64 %t250, %t251
  store i1 %t254, ptr %l138, !tbaa !21
  br label %bb91
bb91:
  %t256 = load i1, ptr %l138, !tbaa !21
  store i1 %t256, ptr %l121, !tbaa !21
  br label %bb104
bb92:
  %t257 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t259 = trunc i64 99 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t262 = load i1, ptr %l12, !tbaa !21
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb96, label %bb97
bb96:
  %t266 = load i64, ptr %l9, !tbaa !24
  %t267 = load i64, ptr %l10, !tbaa !24
  %t270 = icmp ne i64 %t266, %t267
  store i1 %t270, ptr %l146, !tbaa !21
  br label %bb98
bb97:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb98
bb98:
  %t272 = load i1, ptr %l146, !tbaa !21
  store i1 %t272, ptr %l121, !tbaa !21
  br label %bb104
bb99:
  br i1 true, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  %t273 = load i1, ptr %l12, !tbaa !21
  %t275 = xor i1 %t273, true
  store i1 %t275, ptr %l121, !tbaa !21
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_fa05ab364d453a8b_cb1072875564fc6f)
  unreachable
bb104:
  %t277 = load i1, ptr %l121, !tbaa !21
  %t278 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t278, ptr %l152, !tbaa !24
  br i1 %t277, label %bb105, label %bb106
bb105:
  store i64 1, ptr %l154, !tbaa !24
  br label %bb107
bb106:
  store i64 0, ptr %l154, !tbaa !24
  br label %bb107
bb107:
  %t281 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t282 = load i64, ptr %l152, !tbaa !24
  %t283 = load i64, ptr %l154, !tbaa !24
  %t285 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s7, i64 %t282, i64 %t283, i32 %t281)
  store %"compiler/generic:folded" %t285, ptr %l156
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t286 = load %"compiler/generic:folded", ptr %l156
  store %"compiler/generic:folded" %t286, ptr %rv
  br label %ret
bb109:
  store i64 0, ptr %l14, !tbaa !24
  %t287 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t289 = trunc i64 68 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  %t292 = load i64, ptr %l9, !tbaa !24
  %t293 = load i64, ptr %l10, !tbaa !24
  %t296 = add i64 %t292, %t293
  store i64 %t296, ptr %l14, !tbaa !24
  br label %bb200
bb113:
  %t298 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t300 = trunc i64 69 to i32
  %t301 = icmp eq i32 %t298, %t300
  br i1 %t301, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  %t303 = load i64, ptr %l9, !tbaa !24
  %t304 = load i64, ptr %l10, !tbaa !24
  %t307 = sub i64 %t303, %t304
  store i64 %t307, ptr %l14, !tbaa !24
  br label %bb200
bb117:
  %t309 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t311 = trunc i64 70 to i32
  %t312 = icmp eq i32 %t309, %t311
  br i1 %t312, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  %t314 = load i64, ptr %l9, !tbaa !24
  %t315 = load i64, ptr %l10, !tbaa !24
  %t318 = mul i64 %t314, %t315
  store i64 %t318, ptr %l14, !tbaa !24
  br label %bb200
bb121:
  %t320 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t322 = trunc i64 72 to i32
  %t323 = icmp eq i32 %t320, %t322
  br i1 %t323, label %bb122, label %bb123
bb122:
  br label %bb126
bb123:
  %t325 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t327 = trunc i64 73 to i32
  %t328 = icmp eq i32 %t325, %t327
  br i1 %t328, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb140
bb126:
  %t330 = load i64, ptr %l10, !tbaa !24
  %t332 = icmp eq i64 %t330, 0
  br i1 %t332, label %bb127, label %bb128
bb127:
  %t334 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t334, ptr %l178
  br label %bb129
bb128:
  br label %bb130
bb129:
  call void @__olang_scope_close(ptr %s0)
  %t335 = load %"compiler/generic:folded", ptr %l178
  store %"compiler/generic:folded" %t335, ptr %rv
  br label %ret
bb130:
  %t336 = load i1, ptr %l11, !tbaa !21
  br i1 %t336, label %bb131, label %bb132
bb131:
  %t338 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t340 = trunc i64 72 to i32
  %t341 = icmp eq i32 %t338, %t340
  br i1 %t341, label %bb133, label %bb134
bb132:
  %t343 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t345 = trunc i64 72 to i32
  %t346 = icmp eq i32 %t343, %t345
  br i1 %t346, label %bb136, label %bb137
bb133:
  %t348 = load i64, ptr %l9, !tbaa !24
  %t350 = load i64, ptr %l10, !tbaa !24
  %t354 = udiv i64 %t348, %t350
  store i64 %t354, ptr %l182, !tbaa !24
  br label %bb135
bb134:
  %t357 = load i64, ptr %l9, !tbaa !24
  %t359 = load i64, ptr %l10, !tbaa !24
  %t363 = urem i64 %t357, %t359
  store i64 %t363, ptr %l182, !tbaa !24
  br label %bb135
bb135:
  %t366 = load i64, ptr %l182, !tbaa !24
  store i64 %t366, ptr %l14, !tbaa !24
  br label %bb139
bb136:
  %t367 = load i64, ptr %l9, !tbaa !24
  %t368 = load i64, ptr %l10, !tbaa !24
  %t371 = sdiv i64 %t367, %t368
  store i64 %t371, ptr %l197, !tbaa !24
  br label %bb138
bb137:
  %t373 = load i64, ptr %l9, !tbaa !24
  %t374 = load i64, ptr %l10, !tbaa !24
  %t377 = srem i64 %t373, %t374
  store i64 %t377, ptr %l197, !tbaa !24
  br label %bb138
bb138:
  %t379 = load i64, ptr %l197, !tbaa !24
  store i64 %t379, ptr %l14, !tbaa !24
  br label %bb139
bb139:
  br label %bb200
bb140:
  %t380 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t382 = trunc i64 101 to i32
  %t383 = icmp eq i32 %t380, %t382
  br i1 %t383, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t385 = load i64, ptr %l9, !tbaa !24
  %t386 = load i64, ptr %l10, !tbaa !24
  %t389 = and i64 %t385, %t386
  store i64 %t389, ptr %l14, !tbaa !24
  br label %bb200
bb144:
  %t391 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t393 = trunc i64 102 to i32
  %t394 = icmp eq i32 %t391, %t393
  br i1 %t394, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  %t396 = load i64, ptr %l9, !tbaa !24
  %t397 = load i64, ptr %l10, !tbaa !24
  %t400 = or i64 %t396, %t397
  store i64 %t400, ptr %l14, !tbaa !24
  br label %bb200
bb148:
  %t402 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t404 = trunc i64 103 to i32
  %t405 = icmp eq i32 %t402, %t404
  br i1 %t405, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  %t407 = load i64, ptr %l9, !tbaa !24
  %t408 = load i64, ptr %l10, !tbaa !24
  %t411 = xor i64 %t407, %t408
  store i64 %t411, ptr %l14, !tbaa !24
  br label %bb200
bb152:
  %t413 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t415 = trunc i64 106 to i32
  %t416 = icmp eq i32 %t413, %t415
  br i1 %t416, label %bb153, label %bb154
bb153:
  br label %bb157
bb154:
  %t418 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t420 = trunc i64 107 to i32
  %t421 = icmp eq i32 %t418, %t420
  br i1 %t421, label %bb155, label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb187
bb157:
  %t423 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 2
  %t424 = load i32, ptr %t423, !tbaa !23
  %t425 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t428 = icmp ne i32 %t424, %t425
  br i1 %t428, label %bb158, label %bb159
bb158:
  %t430 = getelementptr %"compiler/generic:folded", ptr %l6, i32 0, i32 2
  %t431 = load i32, ptr %t430, !tbaa !23
  store i32 %t431, ptr %l226, !tbaa !23
  br label %bb163
bb159:
  %t433 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 2
  %t434 = load i32, ptr %t433, !tbaa !23
  %t435 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t438 = icmp eq i32 %t434, %t435
  br i1 %t438, label %bb160, label %bb161
bb160:
  %t440 = getelementptr %"compiler/generic:folded", ptr %l7, i32 0, i32 2
  %t441 = load i32, ptr %t440, !tbaa !23
  store i32 %t441, ptr %l231, !tbaa !23
  br label %bb162
bb161:
  %t443 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t443, ptr %l231, !tbaa !23
  br label %bb162
bb162:
  %t445 = load i32, ptr %l231, !tbaa !23
  store i32 %t445, ptr %l226, !tbaa !23
  br label %bb163
bb163:
  %t446 = load i32, ptr %l226, !tbaa !23
  store i32 %t446, ptr %l8, !tbaa !23
  %t447 = load i32, ptr %l8, !tbaa !23
  %t448 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t451 = icmp eq i32 %t447, %t448
  br i1 %t451, label %bb164, label %bb165
bb164:
  store i64 64, ptr %l237, !tbaa !24
  br label %bb168
bb165:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/generic:Program", ptr %t453, i32 0, i32 2
  store ptr %t455, ptr %l239, !tbaa !29
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i32, ptr %l8, !tbaa !23
  %t460 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t456, i32 %t457)
  store i32 %t460, ptr %l242
  br label %bb166
bb166:
  %t461 = load ptr, ptr %l239, !tbaa !29
  %t462 = load i32, ptr %l242, !tbaa !23
  %t463 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t461, i32 %t462)
  store i64 %t463, ptr %l243
  br label %bb167
bb167:
  %t464 = load i64, ptr %l243, !tbaa !24
  store i64 %t464, ptr %l237, !tbaa !24
  br label %bb168
bb168:
  %t465 = load i64, ptr %l237, !tbaa !24
  store i64 %t465, ptr %l15, !tbaa !24
  %t466 = load i64, ptr %l10, !tbaa !24
  %t468 = icmp slt i64 %t466, 0
  br i1 %t468, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb171
bb170:
  %t470 = load i64, ptr %l10, !tbaa !24
  %t471 = load i64, ptr %l15, !tbaa !24
  %t474 = icmp sge i64 %t470, %t471
  store i1 %t474, ptr %l246, !tbaa !21
  br label %bb171
bb171:
  %t476 = load i1, ptr %l246, !tbaa !21
  br i1 %t476, label %bb172, label %bb173
bb172:
  %t477 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t477, ptr %l250
  br label %bb174
bb173:
  br label %bb175
bb174:
  call void @__olang_scope_close(ptr %s0)
  %t478 = load %"compiler/generic:folded", ptr %l250
  store %"compiler/generic:folded" %t478, ptr %rv
  br label %ret
bb175:
  %t479 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t481 = trunc i64 106 to i32
  %t482 = icmp eq i32 %t479, %t481
  br i1 %t482, label %bb176, label %bb177
bb176:
  %t484 = load i64, ptr %l9, !tbaa !24
  %t485 = load i64, ptr %l10, !tbaa !24
  store i64 %t485, ptr %l254, !tbaa !24
  %t487 = load i64, ptr %l254, !tbaa !24
  %t488 = load i64, ptr %l254, !tbaa !24
  %t489 = shl i64 %t484, %t488
  store i64 %t489, ptr %l14, !tbaa !24
  br label %bb186
bb177:
  %t491 = load i32, ptr %l8, !tbaa !23
  %t492 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t495 = icmp ne i32 %t491, %t492
  br i1 %t495, label %bb178, label %bb179
bb178:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/generic:Program", ptr %t497, i32 0, i32 2
  store ptr %t499, ptr %l261, !tbaa !29
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load i32, ptr %l8, !tbaa !23
  %t504 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t500, i32 %t501)
  store i32 %t504, ptr %l264
  br label %bb180
bb179:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb182
bb180:
  %t505 = load ptr, ptr %l261, !tbaa !29
  %t506 = load i32, ptr %l264, !tbaa !23
  %t507 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t505, i32 %t506)
  store i1 %t507, ptr %l265
  br label %bb181
bb181:
  %t508 = load i1, ptr %l265, !tbaa !21
  store i1 %t508, ptr %l259, !tbaa !21
  br label %bb182
bb182:
  %t509 = load i1, ptr %l259, !tbaa !21
  br i1 %t509, label %bb183, label %bb184
bb183:
  %t510 = load i64, ptr %l9, !tbaa !24
  %t512 = load i64, ptr %l10, !tbaa !24
  store i64 %t512, ptr %l270, !tbaa !65
  %t515 = load i64, ptr %l270, !tbaa !65
  %t516 = load i64, ptr %l270, !tbaa !65
  %t517 = lshr i64 %t510, %t516
  store i64 %t517, ptr %l266, !tbaa !24
  br label %bb185
bb184:
  %t520 = load i64, ptr %l9, !tbaa !24
  %t521 = load i64, ptr %l10, !tbaa !24
  store i64 %t521, ptr %l274, !tbaa !24
  %t523 = load i64, ptr %l274, !tbaa !24
  %t524 = load i64, ptr %l274, !tbaa !24
  %t525 = ashr i64 %t520, %t524
  store i64 %t525, ptr %l266, !tbaa !24
  br label %bb185
bb185:
  %t527 = load i64, ptr %l266, !tbaa !24
  store i64 %t527, ptr %l14, !tbaa !24
  br label %bb186
bb186:
  br label %bb200
bb187:
  %t528 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t530 = trunc i64 47 to i32
  %t531 = icmp eq i32 %t528, %t530
  br i1 %t531, label %bb188, label %bb189
bb188:
  br label %bb190
bb189:
  br label %bb194
bb190:
  %t533 = load i64, ptr %l9, !tbaa !24
  %t535 = icmp ne i64 %t533, 0
  %t536 = load i64, ptr %l10, !tbaa !24
  %t538 = icmp ne i64 %t536, 0
  %t541 = icmp ne i1 %t535, %t538
  br i1 %t541, label %bb191, label %bb192
bb191:
  store i64 1, ptr %l283, !tbaa !24
  br label %bb193
bb192:
  store i64 0, ptr %l283, !tbaa !24
  br label %bb193
bb193:
  %t543 = load i64, ptr %l283, !tbaa !24
  store i64 %t543, ptr %l14, !tbaa !24
  br label %bb200
bb194:
  br i1 true, label %bb195, label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb199
bb197:
  %t544 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t544, ptr %l284
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s0)
  %t545 = load %"compiler/generic:folded", ptr %l284
  store %"compiler/generic:folded" %t545, ptr %rv
  br label %ret
bb199:
  call void @__olang_check_failed(ptr @olang_loc_415c77be4516d04a_7550ee8386647fae)
  unreachable
bb200:
  %t546 = load i32, ptr %l2, !range !{i32 0, i32 114}
  %t548 = trunc i64 47 to i32
  %t549 = icmp eq i32 %t546, %t548
  br i1 %t549, label %bb201, label %bb202
bb201:
  store %olang.scope zeroinitializer, ptr %s30
  %t551 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t552 = load i64, ptr %l14, !tbaa !24
  %t553 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t557 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s30, i64 %t551, i64 %t552, i32 %t553)
  store %"compiler/generic:folded" %t557, ptr %l290
  br label %bb203
bb202:
  br label %bb204
bb203:
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  %t558 = load %"compiler/generic:folded", ptr %l290
  store %"compiler/generic:folded" %t558, ptr %rv
  br label %ret
bb204:
  %t559 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t559, ptr %l291, !tbaa !24
  %t560 = load i32, ptr %l8, !tbaa !23
  %t561 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t564 = icmp ne i32 %t560, %t561
  br i1 %t564, label %bb205, label %bb206
bb205:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i64, ptr %l14, !tbaa !24
  %t568 = load i32, ptr %l8, !tbaa !23
  %t572 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t566, i64 %t567, i32 %t568)
  store i64 %t572, ptr %l299
  br label %bb207
bb206:
  %t573 = load i64, ptr %l14, !tbaa !24
  store i64 %t573, ptr %l295, !tbaa !24
  br label %bb208
bb207:
  %t575 = load i64, ptr %l299, !tbaa !24
  store i64 %t575, ptr %l295, !tbaa !24
  br label %bb208
bb208:
  %t576 = load i32, ptr %l8, !tbaa !23
  %t577 = load i64, ptr %l291, !tbaa !24
  %t578 = load i64, ptr %l295, !tbaa !24
  %t580 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s0, i64 %t577, i64 %t578, i32 %t576)
  store %"compiler/generic:folded" %t580, ptr %l302
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s0)
  %t581 = load %"compiler/generic:folded", ptr %l302
  store %"compiler/generic:folded" %t581, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalLit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca %"compiler/generic:folded"
  %l35 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i32
  %l41 = alloca %"compiler/generic:folded"
  %l45 = alloca %"compiler/generic:folded"
  %l48 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i64
  %l53 = alloca %"compiler/generic:folded"
  %l54 = alloca %"compiler/generic:folded"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 6
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_886433b88e29f460_704fa105f63225d4)
  unreachable
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t24 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v0, ptr %t20, %"compiler/source:Span" %a2)
  store { i64, ptr } %t24, ptr %l19
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 114}
  %t28 = trunc i64 2 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb25
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t31, ptr %l23, !tbaa !27
  %t32 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 0)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l25
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb10, label %ok.36, !prof !99
ok.36:
  store i64 %t33, ptr %l24
  br label %bb9
bb9:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t37, i64 %t38)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l27
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb13, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l26
  br label %bb12
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l29, !tbaa !27
  %t45 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 0)
  %t46 = extractvalue { i32, i64 } %t45, 1
  %t47 = extractvalue { i32, i64 } %t45, 0
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb15, label %ok.49, !prof !99
ok.49:
  store i64 %t46, ptr %l30
  br label %bb14
bb12:
  %t50 = load i64, ptr %l26, !tbaa !24
  store i64 %t50, ptr %l22, !tbaa !24
  br label %bb23
bb13:
  br label %bb11
bb14:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t51, i64 %t52)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l33
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb18, label %ok.57, !prof !99
ok.57:
  store i64 %t54, ptr %l32
  br label %bb17
bb15:
  br label %bb16
bb16:
  %t58 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t58, ptr %l34
  br label %bb19
bb17:
  %t59 = load i64, ptr %l32, !tbaa !65
  store i64 %t59, ptr %l28, !tbaa !65
  br label %bb20
bb18:
  br label %bb16
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t60 = load %"compiler/generic:folded", ptr %l34
  store %"compiler/generic:folded" %t60, ptr %rv
  br label %ret
bb20:
  %t61 = load i64, ptr %l28, !tbaa !65
  %t62 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t62, ptr %l35, !tbaa !24
  store i64 %t61, ptr %l37, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t67, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i32 %t69, ptr %l40
  br label %bb21
bb21:
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = load i64, ptr %l37, !tbaa !24
  %t72 = load i32, ptr %l40, !tbaa !23
  %t73 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s2, i64 %t70, i64 %t71, i32 %t72)
  store %"compiler/generic:folded" %t73, ptr %l41
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t74 = load %"compiler/generic:folded", ptr %l41
  store %"compiler/generic:folded" %t74, ptr %rv
  br label %ret
bb23:
  %t75 = load i64, ptr %l22, !tbaa !24
  %t76 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t78 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s1, i64 %t76, i64 %t75, i32 %t78)
  store %"compiler/generic:folded" %t82, ptr %l45
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t83 = load %"compiler/generic:folded", ptr %l45
  store %"compiler/generic:folded" %t83, ptr %rv
  br label %ret
bb25:
  %t84 = load i32, ptr %l3, !range !{i32 0, i32 114}
  %t86 = trunc i64 6 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb34
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t89, ptr %l48, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t90, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t92, ptr %l50
  br label %bb29
bb29:
  %t93 = load i1, ptr %l50, !tbaa !21
  br i1 %t93, label %bb30, label %bb31
bb30:
  store i64 1, ptr %l51, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb32
bb32:
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t95 = load i64, ptr %l48, !tbaa !24
  %t96 = load i64, ptr %l51, !tbaa !24
  %t98 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s4, i64 %t95, i64 %t96, i32 %t94)
  store %"compiler/generic:folded" %t98, ptr %l53
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  %t99 = load %"compiler/generic:folded", ptr %l53
  store %"compiler/generic:folded" %t99, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t100 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t100, ptr %l54
  br label %bb38
bb38:
  %t101 = load %"compiler/generic:folded", ptr %l54
  store %"compiler/generic:folded" %t101, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_cbe34de7626751c6_f090548a7d71387a)
  unreachable
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/generic:folded"
  %l13 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l5, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t3, ptr %t4, ptr %t5)
  store %"compiler/generic:folded" %t9, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load %"compiler/generic:folded", ptr %l9
  %t18 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstOf(ptr %v0, ptr %v1, ptr %v2, ptr %t13, ptr %t14, %"compiler/generic:folded" %t15, i32 %a3, ptr %t11)
  store i32 %t18, ptr %l13
  br label %bb2
bb2:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l19 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i1
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca { i64, ptr }
  %l75 = alloca i1
  %l77 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l19
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 8
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb40
bb7:
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t37, ptr %l33, !tbaa !27
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  store ptr %t43, ptr %l7, !tbaa !29
  %t45 = load ptr, ptr %l7, !tbaa !29
  store ptr %t45, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t46 = load ptr, ptr %l36, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l36, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 11}
  %t52 = icmp eq i64 %t50, 3
  store i1 %t52, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t53 = load i1, ptr %l37, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = getelementptr { i64, [8 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", ptr }, ptr %t56, i32 0, i32 1
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l8, !tbaa !29
  br label %bb13
bb12:
  br label %bb33
bb13:
  store i64 0, ptr %l9, !tbaa !24
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t62 = getelementptr %"compiler/ast:VarDecl", ptr %t60, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb19
bb16:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l51, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb18
bb18:
  %t93 = load i64, ptr %l51, !tbaa !24
  store i64 %t93, ptr %l48, !tbaa !24
  br label %bb19
bb19:
  %t94 = load i64, ptr %l48, !tbaa !24
  store i64 %t94, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  %t95 = load i64, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb21, label %bb22
bb21:
  br label %bb32
bb22:
  br label %bb23
bb23:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l13, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/ast:VarDecl", ptr %t113, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l70, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t111
  %t122 = load i32, ptr %t121, !tbaa !33
  %t126 = icmp eq i32 %t122, %a2
  br i1 %t126, label %bb24, label %bb25
bb24:
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = call i1 @compiler_2fgeneric_2emutableGlobal(ptr %v0, ptr %t128)
  store i1 %t130, ptr %l77
  br label %bb26
bb25:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb27
bb26:
  %t131 = load i1, ptr %l77, !tbaa !21
  %t132 = xor i1 %t131, true
  store i1 %t132, ptr %l75, !tbaa !21
  br label %bb27
bb27:
  %t134 = load i1, ptr %l75, !tbaa !21
  br i1 %t134, label %bb28, label %bb29
bb28:
  %t135 = load ptr, ptr %l8, !tbaa !29
  store ptr %t135, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l13, !tbaa !24
  br label %bb20
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_3f6d4ec28d03c677_4b12a6ade8d65b03)
  unreachable
bb38:
  br label %bb39
bb39:
  %t142 = load i64, ptr %l5, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l5, !tbaa !24
  br label %bb5
bb40:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalInIf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l9 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l29 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i64
  %l45 = alloca ptr
  %l50 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i64
  %l65 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb3:
  call void @__olang_check_failed(ptr @olang_loc_514348f953d022bc_74505ba6df313dd0)
  unreachable
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sgt i64 %t23, 0
  store i1 %t25, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l9, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l20, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopIf", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_514348f953d022bc_74505ba6df313dd0)
  unreachable
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load i32, ptr %l5, !tbaa !23
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i64, ptr %l20, !tbaa !24
  %t50 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalIn(ptr %v0, ptr %v1, ptr %v2, ptr %t46, i64 %t47, { i64, ptr } %t44, i32 %t45)
  store ptr %t50, ptr %l29
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l29, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/ast:TopIf", ptr %t52, i32 0, i32 2
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l34, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  store i64 %t62, ptr %l35, !tbaa !24
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/ast:TopIf", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_289ae50874ea0e2b_45680487effe832f)
  unreachable
bb17:
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"compiler/ast:TopIf", ptr %t70, i32 0, i32 2
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t75, 1
  %t78 = load i32, ptr %l5, !tbaa !23
  %t79 = load ptr, ptr %l34, !tbaa !29
  %t80 = load i64, ptr %l35, !tbaa !24
  %t85 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalInIf(ptr %v0, ptr %v1, ptr %v2, ptr %t79, i64 %t80, ptr %t73, i64 %t74, i64 %t77, i32 %t78)
  store ptr %t85, ptr %l45
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l45, !tbaa !29
  store ptr %t86, ptr %rv
  br label %ret
bb20:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/ast:TopIf", ptr %t87, i32 0, i32 3
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t97 = load i64, ptr %l4, !tbaa !24
  %t99 = add i64 %t97, 1
  %t102 = icmp eq i64 %t96, %t99
  store i1 %t102, ptr %l50, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb23
bb23:
  %t104 = load i1, ptr %l50, !tbaa !21
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  %t106 = load i64, ptr %l1, !tbaa !24
  store i64 %t106, ptr %l56, !tbaa !24
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t109 = getelementptr %"compiler/ast:TopIf", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d51864a21628ffaa_68720bbe5c137f7e)
  unreachable
bb27:
  br label %bb28
bb28:
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:TopIf", ptr %t114, i32 0, i32 3
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t120 = getelementptr %"compiler/ast:TopBranch", ptr %t117, i32 0, i32 1
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t122 = load i32, ptr %l5, !tbaa !23
  %t123 = load ptr, ptr %l55, !tbaa !29
  %t124 = load i64, ptr %l56, !tbaa !24
  %t127 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalIn(ptr %v0, ptr %v1, ptr %v2, ptr %t123, i64 %t124, { i64, ptr } %t121, i32 %t122)
  store ptr %t127, ptr %l65
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l65, !tbaa !29
  store ptr %t128, ptr %rv
  br label %ret
bb30:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i1
  %l34 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t1, i64 %a2, i32 %a1)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l3, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp ne i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l3, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l17
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l17, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l11, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l25
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t43, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t45, ptr %l28
  br label %bb10
bb10:
  %t46 = load i32, ptr %l25, !tbaa !23
  %t47 = load i32, ptr %l28, !tbaa !23
  %t48 = icmp eq i32 %t46, %t47
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l3, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l34
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t58 = load i32, ptr %l34, !tbaa !23
  %t59 = icmp eq i32 %t58, 0
  store i1 %t59, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i1, ptr %l30, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehashesAll(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  store i32 %t27, ptr %l6, !tbaa !23
  %t29 = load i32, ptr %l6, !tbaa !23
  %t31 = icmp ne i32 %t29, 0
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t37 = add i64 %a2, 1
  %t41 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %t33, i32 %t34, i64 %t37)
  store i1 %t41, ptr %l27
  br label %bb8
bb7:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb9
bb8:
  %t42 = load i1, ptr %l27, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eheld(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l9 = alloca i1
  %l12 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i1, ptr %l12, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr %l1, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l18
  br label %bb9
bb9:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t38 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t36, i32 %t37, i64 %t38)
  store i32 %t42, ptr %l23
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t43 = load i32, ptr %l23, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb13:
  %t44 = load i32, ptr %l1, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisEnumT(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i32, ptr %l14, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t28 = trunc i64 1 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l8, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i32, ptr %l14, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t28 = trunc i64 0 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l8, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eitemsElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i32
  %l17 = alloca i1
  %l21 = alloca i32
  %l23 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca i32
  %l38 = alloca i32
  %l42 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l53 = alloca i1
  %l57 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t10 = trunc i64 19 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l21
  br label %bb4
bb4:
  %t22 = load i32, ptr %l21, !tbaa !23
  %t23 = icmp ne i32 %t22, 0
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load i32, ptr %l3, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l31, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 0
  %t42 = load ptr, ptr %t41, !tbaa !39
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t37, ptr %t42)
  store i32 %t48, ptr %l34
  br label %bb12
bb12:
  %t49 = load i32, ptr %l34, !tbaa !23
  store i32 %t49, ptr %l5, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l38
  br label %bb13
bb13:
  %t57 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t59 = trunc i64 19 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb18
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l44, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l48
  br label %bb16
bb16:
  %t74 = load ptr, ptr %l44, !tbaa !29
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t76, ptr %l49
  br label %bb17
bb17:
  %t77 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t79 = trunc i64 26 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb22
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l5, !tbaa !23
  %t87 = load i32, ptr %l3, !tbaa !23
  %t91 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t85, i32 %t86, i32 %t87)
  store i1 %t91, ptr %l57
  br label %bb21
bb21:
  %t92 = load i1, ptr %l57, !tbaa !21
  %t93 = xor i1 %t92, true
  store i1 %t93, ptr %l53, !tbaa !21
  br label %bb22
bb22:
  %t95 = load i1, ptr %l53, !tbaa !21
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t96 = load i32, ptr %l3, !tbaa !23
  store i32 %t96, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t98 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t98, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l8, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb27, label %bb28
bb27:
  br label %bb36
bb28:
  br label %bb29
bb29:
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t112, ptr %l67, !tbaa !27
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr ptr, ptr %t116, i64 %t113
  %t118 = load ptr, ptr %t117, !tbaa !39
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l71, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t132 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t123, ptr %t124, ptr %t125, ptr %t118)
  store i32 %t132, ptr %l77
  br label %bb30
bb30:
  %t133 = load i32, ptr %l5, !tbaa !23
  %t134 = load ptr, ptr %l71, !tbaa !29
  %t135 = load i32, ptr %l77, !tbaa !23
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t134, i32 %t135, i32 %t133)
  store i1 %t137, ptr %l79
  br label %bb31
bb31:
  %t138 = load i1, ptr %l79, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  %t141 = load i32, ptr %l3, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t143 = load i64, ptr %l7, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l7, !tbaa !24
  br label %bb26
bb36:
  %t147 = load i32, ptr %l5, !tbaa !23
  store i32 %t147, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ekeepsPromise(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca [0 x i64]
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"compiler/diagmsg:Msg"
  %l50 = alloca [0 x i64]
  %l51 = alloca { i64, ptr }
  %l58 = alloca [3 x i64]
  %l59 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca [0 x i64]
  %l68 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca %"compiler/diagmsg:Msg"
  %l81 = alloca [0 x i64]
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l87 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca %"compiler/diagmsg:Msg"
  %l98 = alloca [0 x i64]
  %l99 = alloca { i64, ptr }
  %l106 = alloca [3 x i64]
  %l107 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca %"compiler/diagmsg:Msg"
  %l126 = alloca [0 x i64]
  %l127 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l137 = alloca i1
  %l141 = alloca i32
  %l145 = alloca i32
  %l152 = alloca [3 x i64]
  %l153 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l159 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca %"compiler/diagmsg:Msg"
  %l173 = alloca [0 x i64]
  %l174 = alloca { i64, ptr }
  %l178 = alloca i1
  %l179 = alloca i1
  %l181 = alloca ptr
  %l185 = alloca i32
  %l186 = alloca i32
  %l190 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca { i64, ptr }
  %l201 = alloca i64
  %l204 = alloca i64
  %l226 = alloca i1
  %l231 = alloca i1
  %l233 = alloca { i64, ptr }
  %l236 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l251 = alloca %"compiler/diagmsg:Msg"
  %l252 = alloca [0 x i64]
  %l253 = alloca { i64, ptr }
  %l260 = alloca [3 x i64]
  %l261 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [0 x i64] zeroinitializer, ptr %l6
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/generic:Program", ptr %t2, i32 0, i32 2
  store ptr %t4, ptr %l21, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t7, i32 %a3)
  store i32 %t11, ptr %l25
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l21, !tbaa !29
  %t13 = load i32, ptr %l25, !tbaa !23
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t14, ptr %l26
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %l28, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i32, ptr %t21, i64 %t18
  %t23 = load i32, ptr %t22, !tbaa !33
  %t26 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t16, i32 %t23)
  store i1 %t26, ptr %l31
  br label %bb3
bb3:
  %t27 = load i1, ptr %l31, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t33, ptr %l36, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t32, i32 %t39)
  store i1 %t42, ptr %l39
  br label %bb6
bb5:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb7
bb6:
  %t43 = load i1, ptr %l39, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l33, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i1, ptr %l33, !tbaa !21
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l41, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l42, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  store ptr %t49, ptr %l43, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Promise", ptr %t51, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l46, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 0
  %t58 = load i32, ptr %t57, !tbaa !33
  %t61 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t50, i32 %t58)
  store { i64, ptr } %t61, ptr %l48
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t62 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t63 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsValue(ptr %v0, ptr %v0, { i64, ptr } %t62)
  store %"compiler/diagmsg:Msg" %t63, ptr %l49
  br label %bb11
bb11:
  %t64 = load ptr, ptr %l41, !tbaa !29
  %t65 = load ptr, ptr %l42, !tbaa !29
  %t66 = load ptr, ptr %l43, !tbaa !29
  %t67 = load %"compiler/diagmsg:Msg", ptr %l49
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t64, ptr %t65, ptr %t66, %"compiler/diagmsg:Msg" %t67)
  br label %bb12
bb12:
  %t68 = load [0 x i64], ptr %l6
  store [0 x i64] %t68, ptr %l50
  %t69 = mul i64 0, 8
  %t70 = insertvalue { i64, ptr } undef, i64 0, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t71, ptr %l51, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %l50, i64 %t74, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb13:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Promise", ptr %t76, i32 0, i32 2
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = icmp eq i64 %t81, 1
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr @G_2ecompiler_2ftypes_2eKeepsHome, !tbaa !24
  %t88 = insertvalue [3 x i64] undef, i64 %t85, 0
  %t90 = insertvalue [3 x i64] %t88, i64 %t86, 1
  %t91 = insertvalue [3 x i64] %t90, i64 0, 2
  store [3 x i64] %t91, ptr %l58
  %t92 = mul i64 3, 8
  %t93 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 3, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l59, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = mul i64 3, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %l58, i64 %t98, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t99 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t108 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t100, ptr %t101, ptr %a2, ptr %t103, i64 1)
  store i64 %t108, ptr %l64
  br label %bb17
bb17:
  %t109 = load i64, ptr %l64, !tbaa !24
  store i64 %t109, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = icmp slt i64 %t110, 0
  br i1 %t112, label %bb18, label %bb19
bb18:
  %t114 = load [0 x i64], ptr %l6
  store [0 x i64] %t114, ptr %l67
  %t115 = mul i64 0, 8
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t117, ptr %l68, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %l67, i64 %t120, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t121 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t121, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  br i1 %t126, label %bb21, label %bb22
bb21:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l72, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l73, !tbaa !29
  %t130 = load ptr, ptr %l4, !tbaa !29
  store ptr %t130, ptr %l74, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l4, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Promise", ptr %t132, i32 0, i32 2
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l77, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i32, ptr %t137, i64 0
  %t139 = load i32, ptr %t138, !tbaa !33
  %t142 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t131, i32 %t139)
  store { i64, ptr } %t142, ptr %l79
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t143 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t144 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsSelf(ptr %v0, ptr %v0, { i64, ptr } %t143)
  store %"compiler/diagmsg:Msg" %t144, ptr %l80
  br label %bb24
bb24:
  %t145 = load ptr, ptr %l72, !tbaa !29
  %t146 = load ptr, ptr %l73, !tbaa !29
  %t147 = load ptr, ptr %l74, !tbaa !29
  %t148 = load %"compiler/diagmsg:Msg", ptr %l80
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t145, ptr %t146, ptr %t147, %"compiler/diagmsg:Msg" %t148)
  br label %bb25
bb25:
  %t149 = load [0 x i64], ptr %l6
  store [0 x i64] %t149, ptr %l81
  %t150 = mul i64 0, 8
  %t151 = insertvalue { i64, ptr } undef, i64 0, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t152, ptr %l82, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t154, ptr %l81, i64 %t155, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t156 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t156, ptr %rv
  br label %ret
bb26:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t158, ptr %l84, !tbaa !27
  %t159 = load i64, ptr %l8, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t157, i32 %t164)
  store i1 %t167, ptr %l87
  br label %bb27
bb27:
  %t168 = load i1, ptr %l87, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb28, label %bb29
bb28:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l89, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  store ptr %t172, ptr %l90, !tbaa !29
  %t173 = load ptr, ptr %l4, !tbaa !29
  store ptr %t173, ptr %l91, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l4, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Promise", ptr %t175, i32 0, i32 2
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l94, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i32, ptr %t180, i64 1
  %t182 = load i32, ptr %t181, !tbaa !33
  %t185 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t174, i32 %t182)
  store { i64, ptr } %t185, ptr %l96
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t186 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t187 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsInValue(ptr %v0, ptr %v0, { i64, ptr } %t186)
  store %"compiler/diagmsg:Msg" %t187, ptr %l97
  br label %bb31
bb31:
  %t188 = load ptr, ptr %l89, !tbaa !29
  %t189 = load ptr, ptr %l90, !tbaa !29
  %t190 = load ptr, ptr %l91, !tbaa !29
  %t191 = load %"compiler/diagmsg:Msg", ptr %l97
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t188, ptr %t189, ptr %t190, %"compiler/diagmsg:Msg" %t191)
  br label %bb32
bb32:
  %t192 = load [0 x i64], ptr %l6
  store [0 x i64] %t192, ptr %l98
  %t193 = mul i64 0, 8
  %t194 = insertvalue { i64, ptr } undef, i64 0, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t195, ptr %l99, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %l98, i64 %t198, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb33:
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Promise", ptr %t200, i32 0, i32 2
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t207 = icmp eq i64 %t205, 2
  br i1 %t207, label %bb34, label %bb35
bb34:
  %t209 = load i64, ptr %l5, !tbaa !24
  %t210 = load i64, ptr %l8, !tbaa !24
  %t212 = insertvalue [3 x i64] undef, i64 %t209, 0
  %t214 = insertvalue [3 x i64] %t212, i64 %t210, 1
  %t215 = insertvalue [3 x i64] %t214, i64 0, 2
  store [3 x i64] %t215, ptr %l106
  %t216 = mul i64 3, 8
  %t217 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t216)
  %t218 = insertvalue { i64, ptr } undef, i64 3, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  store { i64, ptr } %t219, ptr %l107, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = mul i64 3, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t221, ptr %l106, i64 %t222, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t223 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t223, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t224 = load ptr, ptr %l4, !tbaa !29
  %t226 = getelementptr %"compiler/ast:Promise", ptr %t224, i32 0, i32 2
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t231 = icmp sgt i64 %t229, 3
  br i1 %t231, label %bb37, label %bb38
bb37:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l112, !tbaa !29
  %t234 = load ptr, ptr %l1, !tbaa !29
  store ptr %t234, ptr %l113, !tbaa !29
  %t235 = load ptr, ptr %l4, !tbaa !29
  store ptr %t235, ptr %l114, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l4, !tbaa !29
  %t239 = getelementptr %"compiler/ast:Promise", ptr %t237, i32 0, i32 2
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l117, !tbaa !27
  %t241 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 1
  %t244 = load i32, ptr %t243, !tbaa !33
  %t247 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t236, i32 %t244)
  store { i64, ptr } %t247, ptr %l119
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t251 = getelementptr %"compiler/ast:Promise", ptr %t249, i32 0, i32 2
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !27
  store { i64, ptr } %t252, ptr %l122, !tbaa !27
  %t253 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr i32, ptr %t254, i64 2
  %t256 = load i32, ptr %t255, !tbaa !33
  %t259 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t248, i32 %t256)
  store { i64, ptr } %t259, ptr %l124
  br label %bb40
bb40:
  %t260 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t262 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsPath(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t260, { i64, ptr } %t261)
  store %"compiler/diagmsg:Msg" %t262, ptr %l125
  br label %bb41
bb41:
  %t263 = load ptr, ptr %l112, !tbaa !29
  %t264 = load ptr, ptr %l113, !tbaa !29
  %t265 = load ptr, ptr %l114, !tbaa !29
  %t266 = load %"compiler/diagmsg:Msg", ptr %l125
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t263, ptr %t264, ptr %t265, %"compiler/diagmsg:Msg" %t266)
  br label %bb42
bb42:
  %t267 = load [0 x i64], ptr %l6
  store [0 x i64] %t267, ptr %l126
  %t268 = mul i64 0, 8
  %t269 = insertvalue { i64, ptr } undef, i64 0, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t270, ptr %l127, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t272, ptr %l126, i64 %t273, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t274 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t274, ptr %rv
  br label %ret
bb43:
  %t275 = load ptr, ptr %l4, !tbaa !29
  %t277 = getelementptr %"compiler/ast:Promise", ptr %t275, i32 0, i32 2
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  store { i64, ptr } %t278, ptr %l129, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr i32, ptr %t280, i64 2
  %t282 = load i32, ptr %t281, !tbaa !33
  store i32 %t282, ptr %l9, !tbaa !23
  %t284 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t284, ptr %l131, !tbaa !27
  %t285 = load i64, ptr %l8, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr i32, ptr %t288, i64 %t285
  %t290 = load i32, ptr %t289, !tbaa !33
  store i32 %t290, ptr %l10, !tbaa !23
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l10, !tbaa !23
  %t298 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l137
  br label %bb44
bb44:
  %t299 = load i1, ptr %l137, !tbaa !21
  br i1 %t299, label %bb45, label %bb46
bb45:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/generic:Program", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %l10, !tbaa !23
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l141
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t307 = load i32, ptr %l141, !tbaa !23
  store i32 %t307, ptr %l10, !tbaa !23
  br label %bb48
bb48:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t308, i32 0, i32 2
  %t311 = load i32, ptr %l10, !tbaa !23
  %t314 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t310, i32 %t311)
  store i32 %t314, ptr %l145
  br label %bb49
bb49:
  %t315 = load i32, ptr %l145, !range !{i32 0, i32 33}
  %t317 = trunc i64 25 to i32
  %t318 = icmp eq i32 %t315, %t317
  br i1 %t318, label %bb50, label %bb51
bb50:
  %t320 = load i64, ptr %l5, !tbaa !24
  %t321 = load i64, ptr %l8, !tbaa !24
  %t322 = load i32, ptr %l9, !tbaa !23
  %t324 = sext i32 %t322 to i64
  %t326 = insertvalue [3 x i64] undef, i64 %t320, 0
  %t328 = insertvalue [3 x i64] %t326, i64 %t321, 1
  %t330 = insertvalue [3 x i64] %t328, i64 %t324, 2
  store [3 x i64] %t330, ptr %l152
  %t331 = mul i64 3, 8
  %t332 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t331)
  %t333 = insertvalue { i64, ptr } undef, i64 3, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  store { i64, ptr } %t334, ptr %l153, !tbaa !27
  %t335 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = mul i64 3, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t336, ptr %l152, i64 %t337, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t338 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t338, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l10, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t339, i32 %t340)
  store { i64, ptr } %t343, ptr %l156
  br label %bb53
bb53:
  %t344 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t344, ptr %l11, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t346 = load i32, ptr %l9, !tbaa !23
  %t349 = call i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %s0, { i64, ptr } %t345, i32 %t346)
  store i1 %t349, ptr %l159
  br label %bb54
bb54:
  %t350 = load i1, ptr %l159, !tbaa !21
  %t351 = xor i1 %t350, true
  br i1 %t351, label %bb55, label %bb56
bb55:
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l161, !tbaa !29
  %t354 = load ptr, ptr %l1, !tbaa !29
  store ptr %t354, ptr %l162, !tbaa !29
  %t355 = load ptr, ptr %l4, !tbaa !29
  store ptr %t355, ptr %l163, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr %l9, !tbaa !23
  %t360 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t356, i32 %t357)
  store { i64, ptr } %t360, ptr %l166
  br label %bb57
bb56:
  br label %bb61
bb57:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l4, !tbaa !29
  %t364 = getelementptr %"compiler/ast:Promise", ptr %t362, i32 0, i32 2
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  store { i64, ptr } %t365, ptr %l169, !tbaa !27
  %t366 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr i32, ptr %t367, i64 1
  %t369 = load i32, ptr %t368, !tbaa !33
  %t372 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t361, i32 %t369)
  store { i64, ptr } %t372, ptr %l171
  br label %bb58
bb58:
  %t373 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t375 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsField(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t373, { i64, ptr } %t374)
  store %"compiler/diagmsg:Msg" %t375, ptr %l172
  br label %bb59
bb59:
  %t376 = load ptr, ptr %l161, !tbaa !29
  %t377 = load ptr, ptr %l162, !tbaa !29
  %t378 = load ptr, ptr %l163, !tbaa !29
  %t379 = load %"compiler/diagmsg:Msg", ptr %l172
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t376, ptr %t377, ptr %t378, %"compiler/diagmsg:Msg" %t379)
  br label %bb60
bb60:
  %t380 = load [0 x i64], ptr %l6
  store [0 x i64] %t380, ptr %l173
  %t381 = mul i64 0, 8
  %t382 = insertvalue { i64, ptr } undef, i64 0, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t383, ptr %l174, !tbaa !27
  %t384 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t385, ptr %l173, i64 %t386, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t387 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t387, ptr %rv
  br label %ret
bb61:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/generic:Program", ptr %t388, i32 0, i32 2
  %t391 = load i32, ptr %l10, !tbaa !23
  %t394 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t390, i32 %t391)
  store i1 %t394, ptr %l178
  br label %bb62
bb62:
  %t395 = load i1, ptr %l178, !tbaa !21
  br i1 %t395, label %bb63, label %bb64
bb63:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/generic:Program", ptr %t396, i32 0, i32 2
  store ptr %t398, ptr %l181, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/generic:Program", ptr %t399, i32 0, i32 2
  %t402 = load i32, ptr %l10, !tbaa !23
  %t405 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t401, i32 %t402)
  store i32 %t405, ptr %l185
  br label %bb65
bb64:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb67
bb65:
  %t406 = load ptr, ptr %l181, !tbaa !29
  %t407 = load i32, ptr %l185, !tbaa !23
  %t408 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t408, ptr %l186
  br label %bb66
bb66:
  %t409 = load i32, ptr %l186, !range !{i32 0, i32 6}
  %t411 = trunc i64 0 to i32
  %t412 = icmp eq i32 %t409, %t411
  store i1 %t412, ptr %l179, !tbaa !21
  br label %bb67
bb67:
  %t414 = load i1, ptr %l179, !tbaa !21
  br i1 %t414, label %bb68, label %bb69
bb68:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/generic:Program", ptr %t415, i32 0, i32 2
  store ptr %t417, ptr %l190, !tbaa !29
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 2
  %t421 = load i32, ptr %l10, !tbaa !23
  %t424 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t420, i32 %t421)
  store i32 %t424, ptr %l194
  br label %bb70
bb69:
  br label %bb98
bb70:
  %t425 = load ptr, ptr %l190, !tbaa !29
  %t426 = load i32, ptr %l194, !tbaa !23
  %t427 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t425, i32 %t426)
  store { i64, ptr } %t427, ptr %l195
  br label %bb71
bb71:
  %t428 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t428, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t429 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t429, 0
  store i64 %t431, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t433 = load i64, ptr %l14, !tbaa !24
  %t434 = load i64, ptr %l13, !tbaa !24
  %t437 = icmp sgt i64 %t433, %t434
  br i1 %t437, label %bb72, label %bb73
bb72:
  %t439 = load i64, ptr %l15, !tbaa !24
  %t441 = icmp sgt i64 %t439, 0
  br i1 %t441, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb77
bb74:
  %t443 = load i64, ptr %l14, !tbaa !24
  %t444 = load i64, ptr %l13, !tbaa !24
  %t447 = sub i64 %t443, %t444
  %t448 = load i64, ptr %l15, !tbaa !24
  %t451 = add i64 %t447, %t448
  %t453 = sub i64 %t451, 1
  %t454 = load i64, ptr %l15, !tbaa !24
  %t457 = sdiv i64 %t453, %t454
  store i64 %t457, ptr %l204, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb76
bb76:
  %t459 = load i64, ptr %l204, !tbaa !24
  store i64 %t459, ptr %l201, !tbaa !24
  br label %bb77
bb77:
  %t460 = load i64, ptr %l201, !tbaa !24
  store i64 %t460, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb78
bb78:
  %t461 = load i64, ptr %l17, !tbaa !24
  %t462 = load i64, ptr %l16, !tbaa !24
  %t465 = icmp slt i64 %t461, %t462
  %t467 = xor i1 %t465, true
  br i1 %t467, label %bb79, label %bb80
bb79:
  br label %bb97
bb80:
  br label %bb81
bb81:
  %t469 = load i64, ptr %l13, !tbaa !24
  %t470 = load i64, ptr %l17, !tbaa !24
  %t471 = load i64, ptr %l15, !tbaa !24
  %t474 = mul i64 %t470, %t471
  %t477 = add i64 %t469, %t474
  store i64 %t477, ptr %l18, !tbaa !24
  %t479 = load i64, ptr %l18, !tbaa !24
  %t481 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = getelementptr i32, ptr %t482, i64 %t479
  %t484 = load i32, ptr %t483, !tbaa !33
  %t485 = load i32, ptr %l9, !tbaa !23
  %t488 = icmp eq i32 %t484, %t485
  br i1 %t488, label %bb82, label %bb83
bb82:
  %t490 = load i64, ptr %l18, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t496 = icmp slt i64 %t490, %t493
  store i1 %t496, ptr %l226, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb84
bb84:
  %t498 = load i1, ptr %l226, !tbaa !21
  br i1 %t498, label %bb85, label %bb86
bb85:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t500, ptr %l233, !tbaa !27
  %t501 = load i64, ptr %l18, !tbaa !24
  %t503 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = getelementptr i32, ptr %t504, i64 %t501
  %t506 = load i32, ptr %t505, !tbaa !33
  %t509 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t499, i32 %t506)
  store i1 %t509, ptr %l236
  br label %bb87
bb86:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb88
bb87:
  %t510 = load i1, ptr %l236, !tbaa !21
  %t511 = xor i1 %t510, true
  store i1 %t511, ptr %l231, !tbaa !21
  br label %bb88
bb88:
  %t513 = load i1, ptr %l231, !tbaa !21
  br i1 %t513, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s14
  %t514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t514, ptr %l238, !tbaa !29
  %t515 = load ptr, ptr %l1, !tbaa !29
  store ptr %t515, ptr %l239, !tbaa !29
  %t516 = load ptr, ptr %l4, !tbaa !29
  store ptr %t516, ptr %l240, !tbaa !29
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load ptr, ptr %l4, !tbaa !29
  %t520 = getelementptr %"compiler/ast:Promise", ptr %t518, i32 0, i32 2
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !27
  store { i64, ptr } %t521, ptr %l243, !tbaa !27
  %t522 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t523 = load ptr, ptr %t522, !tbaa !27
  %t524 = getelementptr i32, ptr %t523, i64 1
  %t525 = load i32, ptr %t524, !tbaa !33
  %t528 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s14, ptr %t517, i32 %t525)
  store { i64, ptr } %t528, ptr %l245
  br label %bb91
bb90:
  br label %bb95
bb91:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load i32, ptr %l9, !tbaa !23
  %t533 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s14, ptr %t529, i32 %t530)
  store { i64, ptr } %t533, ptr %l248
  br label %bb92
bb92:
  %t534 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 1
  %t536 = extractvalue { i64, ptr } %t534, 0
  %t537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t539 = add i64 %t536, %t538
  %t540 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 1
  %t542 = extractvalue { i64, ptr } %t540, 0
  %t543 = add i64 %t539, %t542
  %t544 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t543)
  call void @olang_textcopy(ptr %t544, ptr %t535, i64 %t536)
  %t545 = getelementptr i8, ptr %t544, i64 %t536
  call void @olang_textcopy(ptr %t545, ptr %t537, i64 %t538)
  %t546 = getelementptr i8, ptr %t545, i64 %t538
  call void @olang_textcopy(ptr %t546, ptr %t541, i64 %t542)
  %t547 = insertvalue { i64, ptr } undef, i64 %t543, 0
  %t548 = insertvalue { i64, ptr } %t547, ptr %t544, 1
  %t550 = extractvalue { i64, ptr } %t548, 0
  %t551 = extractvalue { i64, ptr } %t548, 1
  %t552 = mul i64 %t550, 1
  %t553 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t552)
  call void @llvm.memcpy.p0.p0.i64(ptr %t553, ptr %t551, i64 %t552, i1 false)
  %t554 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t555 = insertvalue { i64, ptr } %t554, ptr %t553, 1
  %t557 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsInValue(ptr %v0, ptr %v0, { i64, ptr } %t555)
  store %"compiler/diagmsg:Msg" %t557, ptr %l251
  br label %bb93
bb93:
  %t558 = load ptr, ptr %l238, !tbaa !29
  %t559 = load ptr, ptr %l239, !tbaa !29
  %t560 = load ptr, ptr %l240, !tbaa !29
  %t561 = load %"compiler/diagmsg:Msg", ptr %l251
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t558, ptr %t559, ptr %t560, %"compiler/diagmsg:Msg" %t561)
  br label %bb94
bb94:
  %t562 = load [0 x i64], ptr %l6
  store [0 x i64] %t562, ptr %l252
  %t563 = mul i64 0, 8
  %t564 = insertvalue { i64, ptr } undef, i64 0, 0
  %t565 = insertvalue { i64, ptr } %t564, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t565, ptr %l253, !tbaa !27
  %t566 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t567, ptr %l252, i64 %t568, i1 false)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t569 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t569, ptr %rv
  br label %ret
bb95:
  br label %bb96
bb96:
  %t570 = load i64, ptr %l17, !tbaa !24
  %t572 = add i64 %t570, 1
  store i64 %t572, ptr %l17, !tbaa !24
  br label %bb78
bb97:
  br label %bb98
bb98:
  %t574 = load i64, ptr %l5, !tbaa !24
  %t575 = load i64, ptr %l8, !tbaa !24
  %t576 = load i32, ptr %l9, !tbaa !23
  %t578 = sext i32 %t576 to i64
  %t580 = insertvalue [3 x i64] undef, i64 %t574, 0
  %t582 = insertvalue [3 x i64] %t580, i64 %t575, 1
  %t584 = insertvalue [3 x i64] %t582, i64 %t578, 2
  store [3 x i64] %t584, ptr %l260
  %t585 = mul i64 3, 8
  %t586 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t585)
  %t587 = insertvalue { i64, ptr } undef, i64 3, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t586, 1
  store { i64, ptr } %t588, ptr %l261, !tbaa !27
  %t589 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = mul i64 3, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t590, ptr %l260, i64 %t591, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t592 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t592, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elengthLevels(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i1 %a2, i32 %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l20 = alloca i32
  %l23 = alloca ptr
  %l27 = alloca i32
  %l35 = alloca i1
  %l39 = alloca i32
  %l41 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l50 = alloca i64
  %l53 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l82 = alloca i32
  %l85 = alloca ptr
  %l89 = alloca i32
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l20
  br label %bb4
bb4:
  %t12 = load i32, ptr %l20, !range !{i32 0, i32 33}
  store i32 %t12, ptr %l7
  %t13 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t15 = trunc i64 20 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l23, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l27
  br label %bb8
bb8:
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l23, !tbaa !29
  %t31 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elengthLevels(ptr %v0, ptr %v1, ptr %v2, ptr %t30, i32 %t31, i1 false, i32 %t26, i64 %t27, ptr %t28, ptr %t29)
  br label %bb9
bb9:
  br label %bb49
bb10:
  %t36 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t38 = trunc i64 19 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb44
bb13:
  br i1 %a2, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l39
  br label %bb16
bb15:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb17
bb16:
  %t50 = load i32, ptr %l39, !tbaa !23
  %t51 = icmp eq i32 %t50, 0
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l35, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t54 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s4)
  store %"std/prelude/text:StringBuilder" %t54, ptr %l41
  br label %bb20
bb19:
  br label %bb41
bb20:
  %t55 = load %"std/prelude/text:StringBuilder", ptr %l41
  store %"std/prelude/text:StringBuilder" %t55, ptr %l8
  store ptr %l8, ptr %l42, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l45
  br label %bb21
bb21:
  %t61 = load ptr, ptr %l42, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %v0, ptr %t61, { i64, ptr } %t62)
  br label %bb22
bb22:
  store i64 0, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb23, label %bb24
bb23:
  %t71 = load i64, ptr %l11, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb28
bb25:
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l11, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l53, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb27
bb27:
  %t91 = load i64, ptr %l53, !tbaa !24
  store i64 %t91, ptr %l50, !tbaa !24
  br label %bb28
bb28:
  %t92 = load i64, ptr %l50, !tbaa !24
  store i64 %t92, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t93 = load i64, ptr %l13, !tbaa !24
  %t94 = load i64, ptr %l12, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l13, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l14, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %s6, ptr %l8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l13, !tbaa !24
  br label %bb29
bb35:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %s4, ptr %l8, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l5, !tbaa !29
  store ptr %t117, ptr %l75, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 0
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/load:Loader", ptr %t121, i32 0, i32 3
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l78, !tbaa !29
  %t126 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s4, ptr %s4, ptr %l8)
  store { i64, ptr } %t126, ptr %l80
  br label %bb37
bb37:
  %t127 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t134 = load ptr, ptr %l78, !tbaa !29
  %t136 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s4, ptr %t134, { i64, ptr } %t133)
  store i32 %t136, ptr %l82
  br label %bb38
bb38:
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t138 = load i32, ptr %l82, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t137, i32 %t138)
  br label %bb39
bb39:
  %t139 = load ptr, ptr %l6, !tbaa !29
  %t140 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t139, i64 %t140)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb41:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l85, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l89
  br label %bb42
bb42:
  %t151 = load i32, ptr %l3, !tbaa !23
  %t152 = load i64, ptr %l4, !tbaa !24
  %t154 = add i64 %t152, 1
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t156 = load ptr, ptr %l6, !tbaa !29
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t158 = load i32, ptr %l89, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elengthLevels(ptr %v0, ptr %v1, ptr %v2, ptr %t157, i32 %t158, i1 true, i32 %t151, i64 %t154, ptr %t155, ptr %t156)
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_e8a0dc9ccb955f9f_ce9beed0e9e57113)
  unreachable
bb49:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elengthsDecided(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l18 = alloca i64
  %l26 = alloca i1
  %l35 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/source:Span"
  %l52 = alloca { i64, ptr }
  %l59 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l81 = alloca i1
  %l93 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l118 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/generic:fnRow", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Func", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Sig", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = add i64 %t12, 1
  store i64 %t14, ptr %l18, !tbaa !24
  %t15 = load i64, ptr %l18, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t23, ptr %lp3
  %t25 = load ptr, ptr %lp3
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/generic:fnRow", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 4
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = icmp eq i64 %t34, 0
  br i1 %t36, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4860714026464204_4592c2a1d2b55600)
  unreachable
bb3:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb4:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/generic:fnRow", ptr %t38, i32 0, i32 2
  %t41 = load i1, ptr %t40, !tbaa !21
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t44 = load ptr, ptr %lp3
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 10
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/generic:fnRow", ptr %t53, i32 0, i32 0
  %t56 = load i64, ptr %t55, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t52, i64 %t56)
  store ptr %t59, ptr %l35
  br label %bb9
bb9:
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t62 = getelementptr %"compiler/load:Module", ptr %t60, i32 0, i32 6
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l4, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_360fa96f69d7f913_7dd7870a86c7dc67)
  unreachable
bb11:
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/source:Source", ptr %t69, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l5, !tbaa !27
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/generic:fnRow", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Func", ptr %t78, i32 0, i32 4
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l45, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 0
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t87 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t85)
  store %"compiler/source:Span" %t87, ptr %l47
  br label %bb13
bb13:
  %t88 = getelementptr %"compiler/source:Span", ptr %l47, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t91 = sext i32 %t89 to i64
  store i64 %t91, ptr %l6, !tbaa !24
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/generic:fnRow", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Func", ptr %t96, i32 0, i32 4
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l52, !tbaa !27
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/generic:fnRow", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/ast:Func", ptr %t103, i32 0, i32 4
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t110 = sub i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 %t110
  %t115 = load ptr, ptr %t114, !tbaa !39
  %t117 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t115)
  store %"compiler/source:Span" %t117, ptr %l59
  br label %bb14
bb14:
  %t118 = getelementptr %"compiler/source:Span", ptr %l59, i32 0, i32 1
  %t119 = load i32, ptr %t118, !tbaa !23
  %t121 = sext i32 %t119 to i64
  store i64 %t121, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/generic:fnRow", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Func", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb15, label %bb16
bb15:
  %t135 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t135, ptr %l67, !tbaa !27
  %t136 = load i64, ptr %l6, !tbaa !24
  store i64 %t136, ptr %l68, !tbaa !24
  %t137 = load i64, ptr %l7, !tbaa !24
  store i64 %t137, ptr %l69, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l70, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/generic:fnRow", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Func", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  br i1 %t147, label %bb17, label %bb18
bb16:
  br label %bb22
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4472349556a15fd2_df3caa9bde222db6)
  unreachable
bb18:
  br label %bb19
bb19:
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr %"compiler/generic:fnRow", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/ast:Func", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t158 = getelementptr %"compiler/ast:Param", ptr %t155, i32 0, i32 1
  %t159 = load i32, ptr %t158, !tbaa !23
  %t160 = load ptr, ptr %l70, !tbaa !29
  %t162 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t160, i32 %t159)
  store { i64, ptr } %t162, ptr %l80
  br label %bb20
bb20:
  %t163 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t164 = load i64, ptr %l68, !tbaa !24
  %t165 = load i64, ptr %l69, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t167 = call i1 @compiler_2fgeneric_2eLengthDecided(ptr %v0, ptr %v0, { i64, ptr } %t163, i64 %t164, i64 %t165, { i64, ptr } %t166)
  store i1 %t167, ptr %l81
  br label %bb21
bb21:
  %t168 = load i1, ptr %l81, !tbaa !21
  %t169 = load ptr, ptr %lp3
  %t170 = getelementptr { i64, ptr }, ptr %t169, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i1, ptr %t171, i64 0
  store i1 %t168, ptr %t172, !tbaa !31
  br label %bb22
bb22:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr %"compiler/generic:fnRow", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Func", ptr %t176, i32 0, i32 3
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/ast:Sig", ptr %t179, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  store { i64, ptr } %t182, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t188 = load i64, ptr %l9, !tbaa !24
  %t189 = load i64, ptr %l10, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb24, label %bb25
bb24:
  br label %bb35
bb25:
  br label %bb26
bb26:
  %t196 = load i64, ptr %l9, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t198, ptr %l93, !tbaa !27
  %t199 = load i64, ptr %l9, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr ptr, ptr %t202, i64 %t199
  %t204 = load ptr, ptr %t203, !tbaa !39
  store ptr %t204, ptr %l12, !tbaa !29
  %t208 = add i64 %t196, 1
  store i64 %t208, ptr %l97, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t209, ptr %l98, !tbaa !27
  %t210 = load i64, ptr %l6, !tbaa !24
  store i64 %t210, ptr %l99, !tbaa !24
  %t211 = load i64, ptr %l7, !tbaa !24
  store i64 %t211, ptr %l100, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l12, !tbaa !29
  %t215 = getelementptr %"compiler/ast:Param", ptr %t213, i32 0, i32 1
  %t216 = load i32, ptr %t215, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t212, i32 %t216)
  store { i64, ptr } %t219, ptr %l104
  br label %bb27
bb27:
  %t220 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t221 = load i64, ptr %l99, !tbaa !24
  %t222 = load i64, ptr %l100, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t224 = call i1 @compiler_2fgeneric_2eLengthDecided(ptr %v0, ptr %v0, { i64, ptr } %t220, i64 %t221, i64 %t222, { i64, ptr } %t223)
  store i1 %t224, ptr %l105
  br label %bb28
bb28:
  %t225 = load i1, ptr %l105, !tbaa !21
  br i1 %t225, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb33
bb30:
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l107, !tbaa !29
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr %"compiler/generic:fnRow", ptr %t227, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  store i64 %t230, ptr %l109, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t231, ptr %l110, !tbaa !27
  %t232 = load i64, ptr %l6, !tbaa !24
  store i64 %t232, ptr %l111, !tbaa !24
  %t233 = load i64, ptr %l7, !tbaa !24
  store i64 %t233, ptr %l112, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l12, !tbaa !29
  %t237 = getelementptr %"compiler/ast:Param", ptr %t235, i32 0, i32 1
  %t238 = load i32, ptr %t237, !tbaa !23
  %t241 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t234, i32 %t238)
  store { i64, ptr } %t241, ptr %l116
  br label %bb31
bb31:
  %t243 = load ptr, ptr %l107, !tbaa !29
  %t244 = load i64, ptr %l109, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t246 = load i64, ptr %l111, !tbaa !24
  %t247 = load i64, ptr %l112, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t250 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehandedOn(ptr %v0, ptr %v0, ptr %v0, ptr %t243, i64 %t244, { i64, ptr } %t245, i64 %t246, i64 %t247, { i64, ptr } %t248, i64 %a2)
  store i1 %t250, ptr %l118
  br label %bb32
bb32:
  %t251 = load i1, ptr %l118, !tbaa !21
  store i1 %t251, ptr %l106, !tbaa !21
  br label %bb33
bb33:
  %t252 = load i1, ptr %l106, !tbaa !21
  %t253 = load ptr, ptr %lp3
  %t254 = load i64, ptr %l97, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i1, ptr %t256, i64 %t254
  store i1 %t252, ptr %t257, !tbaa !31
  br label %bb34
bb34:
  %t258 = load i64, ptr %l9, !tbaa !24
  %t260 = add i64 %t258, 1
  store i64 %t260, ptr %l9, !tbaa !24
  br label %bb23
bb35:
  %t262 = load ptr, ptr %lp3
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eliteralType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 114}
  %t3 = trunc i64 2 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i32 %t10, ptr %l7
  br label %bb4
bb4:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb29
bb5:
  %t12 = load i32, ptr %l1, !range !{i32 0, i32 114}
  %t14 = trunc i64 3 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i32 %t21, ptr %l12
  br label %bb9
bb9:
  %t22 = load i32, ptr %l12, !tbaa !23
  store i32 %t22, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb10:
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 114}
  %t25 = trunc i64 6 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t28, ptr %l2, !tbaa !23
  br label %bb29
bb14:
  %t30 = load i32, ptr %l1, !range !{i32 0, i32 114}
  %t32 = trunc i64 5 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %t35)
  store i32 %t37, ptr %l19
  br label %bb18
bb18:
  %t38 = load i32, ptr %l19, !tbaa !23
  store i32 %t38, ptr %l2, !tbaa !23
  br label %bb29
bb19:
  %t39 = load i32, ptr %l1, !range !{i32 0, i32 114}
  %t41 = trunc i64 4 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %s5, ptr %s5, ptr %t44, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d20, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t46, ptr %l23
  br label %bb23
bb23:
  %t47 = load i32, ptr %l23, !tbaa !23
  store i32 %t47, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t48, ptr %l2, !tbaa !23
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fc435fbf179ab4a3_d5536eec81a24b6f)
  unreachable
bb29:
  %t50 = load i32, ptr %l2, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeet(ptr %v0, ptr %a0, %"compiler/generic:folded" %a1, %"compiler/generic:folded" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:folded"
  %l2 = alloca %"compiler/generic:folded"
  %l6 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l27 = alloca i32
  %l34 = alloca i64
  %l37 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l48 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/generic:folded" %a1, ptr %l1
  store %"compiler/generic:folded" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t6 = icmp eq i32 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t9 = load i32, ptr %t8, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t16, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  br i1 %t23, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t29 = load i32, ptr %t28, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t25, i64 %t27, i32 %t29)
  store i64 %t33, ptr %l17
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t34 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t38 = icmp eq i64 %t36, %t35
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l20, !tbaa !23
  br label %bb14
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l22, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t46, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i32 %t48, ptr %l25
  br label %bb12
bb12:
  %t49 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load i32, ptr %l25, !tbaa !23
  %t54 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %t51, i32 %t52, i32 %t50)
  store i32 %t54, ptr %l27
  br label %bb13
bb13:
  %t55 = load i32, ptr %l27, !tbaa !23
  store i32 %t55, ptr %l20, !tbaa !23
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t56 = load i32, ptr %l20, !tbaa !23
  store i32 %t56, ptr %rv
  br label %ret
bb15:
  %t57 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = icmp eq i32 %t58, %t59
  br i1 %t62, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  %t72 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t64, i64 %t66, i32 %t68)
  store i64 %t72, ptr %l34
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t73 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 1
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i64, ptr %l34, !tbaa !24
  %t77 = icmp eq i64 %t75, %t74
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t79 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  store i32 %t80, ptr %l37, !tbaa !23
  br label %bb23
bb20:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l39, !tbaa !29
  %t83 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t84 = load i32, ptr %t83, !tbaa !23
  store i32 %t84, ptr %l40, !tbaa !23
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s3, ptr %t87, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i32 %t89, ptr %l43
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l39, !tbaa !29
  %t91 = load i32, ptr %l40, !tbaa !23
  %t92 = load i32, ptr %l43, !tbaa !23
  %t93 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %t90, i32 %t91, i32 %t92)
  store i32 %t93, ptr %l44
  br label %bb22
bb22:
  %t94 = load i32, ptr %l44, !tbaa !23
  store i32 %t94, ptr %l37, !tbaa !23
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  %t95 = load i32, ptr %l37, !tbaa !23
  store i32 %t95, ptr %rv
  br label %ret
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/generic:folded", ptr %l1, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t99 = getelementptr %"compiler/generic:folded", ptr %l2, i32 0, i32 2
  %t100 = load i32, ptr %t99, !tbaa !23
  %t104 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %t96, i32 %t98, i32 %t100)
  store i32 %t104, ptr %l48
  br label %bb25
bb25:
  %t105 = load i32, ptr %l48, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetsBuilder(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l21 = alloca %"compiler/generic:Context"
  %l22 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i64
  %l31 = alloca i32
  %l35 = alloca i1
  %l39 = alloca i32
  %l47 = alloca i64
  %l51 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca i64
  %l61 = alloca i32
  %l65 = alloca i32
  %l71 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l123 = alloca i1
  %l131 = alloca i32
  %l135 = alloca i32
  %l140 = alloca i1
  %l141 = alloca i1
  %l145 = alloca i1
  %l149 = alloca i1
  %l150 = alloca ptr
  %l154 = alloca i32
  %l158 = alloca i32
  %l159 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t3 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t3, ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t3, i64 160, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l21, i64 160, i1 false)
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l22, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Func", ptr %t8, i32 0, i32 9
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t15 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s0, ptr %v1, ptr %t7, ptr %l4, ptr %t11)
  store i32 %t15, ptr %l27
  br label %bb2
bb2:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t16)
  store i64 %t18, ptr %l29
  br label %bb3
bb3:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = load i32, ptr %l27, !tbaa !23
  %t22 = load i64, ptr %l29, !tbaa !24
  %t24 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t20, i32 %t21, i64 %t22, i32 %t19)
  store i32 %t24, ptr %l31
  br label %bb4
bb4:
  %t25 = load i32, ptr %l31, !tbaa !23
  store i32 %t25, ptr %l5, !tbaa !23
  %t26 = load i32, ptr %l5, !tbaa !23
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t30 = icmp eq i32 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb8
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l5, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l39
  br label %bb7
bb7:
  %t39 = load i32, ptr %l39, !range !{i32 0, i32 33}
  %t41 = trunc i64 25 to i32
  %t42 = icmp eq i32 %t39, %t41
  store i1 %t42, ptr %l35, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l35, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l5, !tbaa !23
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 10
  %t51 = load i32, ptr %t50, !tbaa !23
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t46, i32 %t47, i32 %t51, i1 false)
  store i64 %t55, ptr %l47
  br label %bb12
bb12:
  %t56 = load i64, ptr %l47, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t57, 0
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l51, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Func", ptr %t64, i32 0, i32 3
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %s0, ptr %v1, ptr %t63, ptr %l4, ptr %t67, i32 %t68, i32 0)
  store i32 %t73, ptr %l57
  br label %bb16
bb16:
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t74)
  store i64 %t76, ptr %l59
  br label %bb17
bb17:
  %t77 = load i32, ptr %l2, !tbaa !23
  %t78 = load ptr, ptr %l51, !tbaa !29
  %t79 = load i32, ptr %l57, !tbaa !23
  %t80 = load i64, ptr %l59, !tbaa !24
  %t82 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t78, i32 %t79, i64 %t80, i32 %t77)
  store i32 %t82, ptr %l61
  br label %bb18
bb18:
  %t83 = load i32, ptr %l61, !tbaa !23
  store i32 %t83, ptr %l7, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l6, !tbaa !24
  %t86 = load i32, ptr %l5, !tbaa !23
  %t90 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderSig(ptr %v0, ptr %t84, i64 %t85, i32 %t86)
  store i32 %t90, ptr %l65
  br label %bb19
bb19:
  %t91 = load i32, ptr %l65, !tbaa !23
  store i32 %t91, ptr %l8, !tbaa !23
  %t92 = load i32, ptr %l8, !tbaa !23
  %t93 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t96 = icmp eq i32 %t92, %t93
  br i1 %t96, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l71, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l8, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l75
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l71, !tbaa !29
  %t110 = load i32, ptr %l75, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l76
  br label %bb24
bb24:
  %t112 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t112, ptr %l9, !tbaa !27
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  store ptr %t115, ptr %l78, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l7, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l82
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l78, !tbaa !29
  %t124 = load i32, ptr %l82, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t123, i32 %t124)
  store { i64, ptr } %t125, ptr %l83
  br label %bb26
bb26:
  %t126 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t126, ptr %l10, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t135 = icmp ne i64 %t129, %t132
  br i1 %t135, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  store i64 0, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb30, label %bb31
bb30:
  %t148 = load i64, ptr %l13, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb35
bb32:
  %t152 = load i64, ptr %l12, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l13, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l98, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb34
bb34:
  %t168 = load i64, ptr %l98, !tbaa !24
  store i64 %t168, ptr %l95, !tbaa !24
  br label %bb35
bb35:
  %t169 = load i64, ptr %l95, !tbaa !24
  store i64 %t169, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb36
bb36:
  %t170 = load i64, ptr %l15, !tbaa !24
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb37, label %bb38
bb37:
  br label %bb45
bb38:
  br label %bb39
bb39:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t179 = load i64, ptr %l15, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  store i64 %t186, ptr %l16, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t189, ptr %l117, !tbaa !27
  %t190 = load i64, ptr %l16, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i32, ptr %t193, i64 %t190
  %t195 = load i32, ptr %t194, !tbaa !33
  %t196 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t196, ptr %l120, !tbaa !27
  %t197 = load i64, ptr %l16, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i32, ptr %t200, i64 %t197
  %t202 = load i32, ptr %t201, !tbaa !33
  %t206 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esameUpToShape(ptr %v0, ptr %t188, i32 %t195, i32 %t202)
  store i1 %t206, ptr %l123
  br label %bb40
bb40:
  %t207 = load i1, ptr %l123, !tbaa !21
  %t208 = xor i1 %t207, true
  br i1 %t208, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t211 = load i64, ptr %l15, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l15, !tbaa !24
  br label %bb36
bb45:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  %t218 = load i32, ptr %l8, !tbaa !23
  %t221 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t217, i32 %t218)
  store i32 %t221, ptr %l131
  br label %bb46
bb46:
  %t222 = load i32, ptr %l131, !tbaa !23
  store i32 %t222, ptr %l17, !tbaa !23
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Program", ptr %t223, i32 0, i32 2
  %t226 = load i32, ptr %l7, !tbaa !23
  %t229 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t225, i32 %t226)
  store i32 %t229, ptr %l135
  br label %bb47
bb47:
  %t230 = load i32, ptr %l135, !tbaa !23
  store i32 %t230, ptr %l18, !tbaa !23
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %l17, !tbaa !23
  %t235 = load i32, ptr %l18, !tbaa !23
  %t239 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t233, i32 %t234, i32 %t235)
  store i1 %t239, ptr %l140
  br label %bb48
bb48:
  %t240 = load i1, ptr %l140, !tbaa !21
  br i1 %t240, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb54
bb50:
  %t241 = load i32, ptr %l17, !tbaa !23
  %t242 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t245 = icmp eq i32 %t241, %t242
  br i1 %t245, label %bb51, label %bb52
bb51:
  %t247 = load i32, ptr %l18, !tbaa !23
  %t248 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t251 = icmp eq i32 %t247, %t248
  store i1 %t251, ptr %l145, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb53
bb53:
  %t253 = load i1, ptr %l145, !tbaa !21
  store i1 %t253, ptr %l141, !tbaa !21
  br label %bb54
bb54:
  %t254 = load i1, ptr %l141, !tbaa !21
  br i1 %t254, label %bb55, label %bb56
bb55:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l150, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 2
  %t259 = load i32, ptr %l8, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t258, i32 %t259)
  store i32 %t262, ptr %l154
  br label %bb57
bb56:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb60
bb57:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/generic:Program", ptr %t263, i32 0, i32 2
  %t266 = load i32, ptr %l7, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l158
  br label %bb58
bb58:
  %t270 = load ptr, ptr %l150, !tbaa !29
  %t271 = load i32, ptr %l154, !tbaa !23
  %t272 = load i32, ptr %l158, !tbaa !23
  %t273 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsHeld(ptr %v0, ptr %t270, i32 %t271, i32 %t272)
  store i1 %t273, ptr %l159
  br label %bb59
bb59:
  %t274 = load i1, ptr %l159, !tbaa !21
  store i1 %t274, ptr %l149, !tbaa !21
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t275 = load i1, ptr %l149, !tbaa !21
  store i1 %t275, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/generic:Context"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i32
  %l27 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca %"compiler/generic:Context"
  %l55 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca i64
  %l69 = alloca i32
  %l70 = alloca i32
  %l73 = alloca i1
  %l81 = alloca i1
  %s3 = alloca %olang.scope
  %t68 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l20
  br label %bb3
bb3:
  %t12 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t12, %t14
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l27
  br label %bb8
bb8:
  %t27 = load i32, ptr %l27, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l4, !tbaa !23
  %t32 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store ptr %t32, ptr %l30
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l30, !tbaa !29
  store ptr %t33, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb12
bb11:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/ast:TypeDecl", ptr %t38, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  store i1 %t43, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l33, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TypeDecl", ptr %t46, i32 0, i32 3
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l6, !tbaa !29
  %t51 = load ptr, ptr %l6, !tbaa !29
  store ptr %t51, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t52 = load ptr, ptr %l39, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l39, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 5}
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = getelementptr { i64, [6 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t62, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  br label %bb20
bb19:
  br label %bb42
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t68, ptr %v0, ptr %s3, ptr %t66, i32 %t67)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t68, i64 160, i1 false)
  br label %bb21
bb21:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l47, i64 160, i1 false)
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t71, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb23, label %bb24
bb23:
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t85 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t85, ptr %l55, !tbaa !27
  %t86 = load i64, ptr %l10, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr ptr, ptr %t89, i64 %t86
  %t91 = load ptr, ptr %t90, !tbaa !39
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l58, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t100 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s3, ptr %v0, ptr %t94, ptr %l8, ptr %t91)
  store i32 %t100, ptr %l63
  br label %bb26
bb26:
  %t101 = load i32, ptr %l4, !tbaa !23
  %t103 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t101)
  store i64 %t103, ptr %l65
  br label %bb27
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l69
  br label %bb28
bb28:
  %t111 = load ptr, ptr %l58, !tbaa !29
  %t112 = load i32, ptr %l63, !tbaa !23
  %t113 = load i64, ptr %l65, !tbaa !24
  %t114 = load i32, ptr %l69, !tbaa !23
  %t115 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t111, i32 %t112, i64 %t113, i32 %t114)
  store i32 %t115, ptr %l70
  br label %bb29
bb29:
  %t116 = load i32, ptr %l70, !tbaa !23
  store i32 %t116, ptr %l13, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l13, !tbaa !23
  %t121 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t121, ptr %l73
  br label %bb30
bb30:
  %t122 = load i1, ptr %l73, !tbaa !21
  br i1 %t122, label %bb31, label %bb32
bb31:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l13, !tbaa !23
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t126 = load i64, ptr %l3, !tbaa !24
  %t128 = add i64 %t126, 1
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emembers(ptr %v0, ptr %v1, ptr %t123, i32 %t124, ptr %t125, i64 %t128)
  br label %bb33
bb32:
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t134 = load i32, ptr %l13, !tbaa !23
  %t137 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t133, i32 %t134)
  store i1 %t137, ptr %l81
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t138 = load i1, ptr %l81, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t142 = load i32, ptr %l13, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t141, i32 %t142)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t145 = load i64, ptr %l10, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l10, !tbaa !24
  br label %bb22
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_7c1b9fa6eff766ef_29392a9ca6e4fd4b)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsList(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t35 = add i64 %a4, 1
  %t41 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %t29, i32 %t27, i64 %a2, i64 %a3, i64 %t35)
  store i1 %t41, ptr %l28
  br label %bb6
bb6:
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enameType(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/generic:Context"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca i32
  %l18 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca %"compiler/names:Ref"
  %l28 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca %"compiler/generic:Context"
  %l45 = alloca i1
  %l53 = alloca i32
  %l59 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i32
  %l72 = alloca i64
  %l75 = alloca i64
  %l94 = alloca { i64, ptr }
  %l111 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l116 = alloca { i64, ptr }
  %l120 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t53 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l18, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Context", ptr %a1, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t5, i64 %t9)
  store i64 %t12, ptr %l22
  br label %bb1
bb1:
  %t13 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t15 = load ptr, ptr %l18, !tbaa !29
  %t16 = load i64, ptr %l22, !tbaa !24
  %t18 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t15, i64 %t16, i32 %t14)
  store %"compiler/names:Ref" %t18, ptr %l24
  br label %bb2
bb2:
  %t19 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t19, ptr %l4
  %t20 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t21 = load i32, ptr %t20, !range !{i32 0, i32 9}
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb5
bb4:
  %t28 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l28, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load i32, ptr %l3, !tbaa !23
  %t43 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v0, ptr %t36, i64 %t38, i32 %t39)
  store ptr %t43, ptr %l35
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l35, !tbaa !29
  store ptr %t44, ptr %l5, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t49, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t51 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t53, ptr %s0, i64 %t52, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t53, i64 160, i1 false)
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l40, i64 160, i1 false)
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:VarDecl", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 4
  %t67 = load i1, ptr %t66, !tbaa !21
  %t69 = xor i1 %t67, true
  store i1 %t69, ptr %l45, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t71 = load i1, ptr %l45, !tbaa !21
  br i1 %t71, label %bb17, label %bb18
bb17:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %s0, ptr %v0, ptr %t72, ptr %l6, ptr %t73, i32 %t74)
  store i32 %t79, ptr %l53
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l53, !tbaa !23
  store i32 %t80, ptr %rv
  br label %ret
bb20:
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = shl i64 %t82, 32
  %t85 = load i32, ptr %l3, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t90 = or i64 %t84, %t87
  store i64 %t90, ptr %l7, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 49
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t94, i64 %t95)
  %t99 = extractvalue { i32, i1 } %t98, 1
  %t100 = extractvalue { i32, i1 } %t98, 0
  store i32 %t100, ptr %l64
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb22, label %ok.102, !prof !99
ok.102:
  store i1 %t99, ptr %l63
  br label %bb21
bb21:
  %t103 = load i1, ptr %l63, !tbaa !21
  store i1 %t103, ptr %l59, !tbaa !21
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l59, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t105, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr %"compiler/ast:VarDecl", ptr %t107, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb33
bb30:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l75, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb32
bb32:
  %t140 = load i64, ptr %l75, !tbaa !24
  store i64 %t140, ptr %l72, !tbaa !24
  br label %bb33
bb33:
  %t141 = load i64, ptr %l72, !tbaa !24
  store i64 %t141, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb34
bb34:
  %t142 = load i64, ptr %l13, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb35, label %bb36
bb35:
  br label %bb42
bb36:
  br label %bb37
bb37:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t151 = load i64, ptr %l13, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l14, !tbaa !24
  %t160 = load ptr, ptr %l5, !tbaa !29
  %t162 = getelementptr %"compiler/ast:VarDecl", ptr %t160, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l94, !tbaa !27
  %t164 = load i64, ptr %l14, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t164
  %t169 = load i32, ptr %t168, !tbaa !33
  %t170 = load i32, ptr %l3, !tbaa !23
  %t173 = icmp eq i32 %t169, %t170
  br i1 %t173, label %bb38, label %bb39
bb38:
  %t175 = load i64, ptr %l14, !tbaa !24
  store i64 %t175, ptr %l8, !tbaa !24
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t177 = load i64, ptr %l13, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l13, !tbaa !24
  br label %bb34
bb42:
  %t181 = load i64, ptr %l8, !tbaa !24
  %t182 = load ptr, ptr %l5, !tbaa !29
  %t184 = getelementptr %"compiler/ast:VarDecl", ptr %t182, i32 0, i32 3
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t190 = icmp sge i64 %t181, %t187
  br i1 %t190, label %bb43, label %bb44
bb43:
  %t192 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t192, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 49
  %t197 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t196, i64 %t197, i1 true)
  br label %bb46
bb46:
  %t200 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Hcd3bbe8e64537e19c3182f51d0fe16c9(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t200, ptr %l111
  br label %bb47
bb47:
  %t201 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l111
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t201, ptr %l15
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l5, !tbaa !29
  %t205 = getelementptr %"compiler/ast:VarDecl", ptr %t203, i32 0, i32 3
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  store { i64, ptr } %t206, ptr %l116, !tbaa !27
  %t207 = load i64, ptr %l8, !tbaa !24
  %t209 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr ptr, ptr %t210, i64 %t207
  %t212 = load ptr, ptr %t211, !tbaa !39
  %t218 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %s0, ptr %s0, ptr %v0, ptr %t202, ptr %l6, ptr %l15, ptr %t212)
  store i32 %t218, ptr %l120
  br label %bb48
bb48:
  %t219 = load i32, ptr %l120, !tbaa !23
  store i32 %t219, ptr %l16, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 49
  %t223 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t222, i64 %t223, i1 false)
  br label %bb49
bb49:
  %t226 = load i32, ptr %l16, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t226, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamsSig(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l30 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l46 = alloca i32
  %l53 = alloca i32
  %l55 = alloca ptr
  %l57 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l64 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l14
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l6
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t19, ptr %l22, !tbaa !27
  %t20 = load i64, ptr %l8, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 %t20
  %t25 = load ptr, ptr %t24, !tbaa !39
  store ptr %l5, ptr %l25, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Param", ptr %t25, i32 0, i32 2
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t27, ptr %t28, ptr %t32)
  store i32 %t36, ptr %l30
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load i32, ptr %l30, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t37, i32 %t38)
  br label %bb8
bb8:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t39)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l8, !tbaa !24
  br label %bb3
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l36, !tbaa !29
  %t49 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  store i64 %t49, ptr %l37, !tbaa !24
  %t51 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t51, ptr %l39
  br label %bb12
bb12:
  %t52 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t53 = mul i64 1, 8
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 1, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l41, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i64, ptr %t59, i64 0
  store i64 %t52, ptr %t60, !tbaa !34
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t61, i64 %t62, { i64, ptr } %t63, { i64, ptr } %t64)
  store i32 %t65, ptr %l42
  br label %bb13
bb13:
  %t66 = load i32, ptr %l42, !tbaa !23
  store i32 %t66, ptr %l11, !tbaa !23
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Sig", ptr %t75, i32 0, i32 2
  %t78 = load i1, ptr %t77, !tbaa !21
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Sig", ptr %t79, i32 0, i32 3
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t87 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorList(ptr %v0, ptr %v1, ptr %v3, ptr %t73, ptr %t74, i1 %t78, { i64, ptr } %t82)
  store i32 %t87, ptr %l53
  br label %bb16
bb15:
  store i32 0, ptr %l46, !tbaa !23
  br label %bb17
bb16:
  %t88 = load i32, ptr %l53, !tbaa !23
  store i32 %t88, ptr %l46, !tbaa !23
  br label %bb17
bb17:
  %t89 = load i32, ptr %l46, !tbaa !23
  store i32 %t89, ptr %l12, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  store ptr %t92, ptr %l55, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l57, !tbaa !29
  %t97 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t97, ptr %l59
  br label %bb18
bb18:
  %t98 = load ptr, ptr %l57, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t98, { i64, ptr } %t99)
  store i32 %t100, ptr %l60
  br label %bb19
bb19:
  %t102 = load i32, ptr %l12, !tbaa !23
  %t103 = load i32, ptr %l11, !tbaa !23
  %t104 = load ptr, ptr %l55, !tbaa !29
  %t105 = load i32, ptr %l60, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t104, i32 %t105, i32 %a4, i32 %t102, i32 %t103, i64 0, i1 false, i32 0, i64 0)
  store i32 %t109, ptr %l64
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t110 = load i32, ptr %l64, !tbaa !23
  store i32 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromisesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca { i64, ptr }
  %l44 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l71 = alloca i1
  %l74 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca i64
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l106 = alloca %"compiler/diagmsg:Msg"
  %l109 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca %"compiler/diagmsg:Msg"
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l126 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca %"compiler/diagmsg:Msg"
  %l145 = alloca { i64, ptr }
  %l150 = alloca i64
  %l155 = alloca i64
  %l158 = alloca i64
  %l179 = alloca i64
  %l182 = alloca i1
  %l187 = alloca i64
  %l190 = alloca i1
  %l195 = alloca i64
  %l198 = alloca ptr
  %l199 = alloca ptr
  %l200 = alloca ptr
  %l202 = alloca ptr
  %l204 = alloca ptr
  %l205 = alloca i32
  %l208 = alloca i64
  %l209 = alloca i32
  %l214 = alloca { i64, ptr }
  %l216 = alloca %"compiler/diagmsg:Msg"
  %l226 = alloca { i64, ptr }
  %l239 = alloca i1
  %l241 = alloca i64
  %l243 = alloca ptr
  %l244 = alloca ptr
  %l246 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l248 = alloca %"compiler/diagmsg:Msg"
  %l250 = alloca ptr
  %l251 = alloca i64
  %l253 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l256 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 8
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l4, !tbaa !24
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l29
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l30
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l6
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Sig", ptr %t15, i32 0, i32 8
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load i64, ptr %l8, !tbaa !24
  %t25 = load i64, ptr %l9, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb109
bb8:
  br label %bb9
bb9:
  %t32 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t32, ptr %l39, !tbaa !27
  %t33 = load i64, ptr %l8, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 %t33
  %t38 = load ptr, ptr %t37, !tbaa !39
  store ptr %t38, ptr %l10, !tbaa !29
  %t40 = load ptr, ptr %l10, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Promise", ptr %t40, i32 0, i32 1
  %t43 = load i32, ptr %t42, !range !{i32 0, i32 114}
  %t45 = call i64 @compiler_2fgeneric_2epromiseBit(i32 %t43)
  store i64 %t45, ptr %l44
  br label %bb10
bb10:
  %t46 = load i64, ptr %l44, !tbaa !24
  store i64 %t46, ptr %l11, !tbaa !24
  %t47 = load i64, ptr %l11, !tbaa !24
  %t49 = icmp ne i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = and i64 %t51, %t52
  %t57 = icmp ne i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb12:
  br label %bb36
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l51, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l52, !tbaa !29
  %t61 = load ptr, ptr %l10, !tbaa !29
  store ptr %t61, ptr %l53, !tbaa !29
  %t62 = load ptr, ptr %l10, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Promise", ptr %t62, i32 0, i32 1
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 114}
  %t67 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %t65)
  store { i64, ptr } %t67, ptr %l56
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t68 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseTwice(ptr %v0, ptr %v0, { i64, ptr } %t68)
  store %"compiler/diagmsg:Msg" %t69, ptr %l57
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l51, !tbaa !29
  %t71 = load ptr, ptr %l52, !tbaa !29
  %t72 = load ptr, ptr %l53, !tbaa !29
  %t73 = load %"compiler/diagmsg:Msg", ptr %l57
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t70, ptr %t71, ptr %t72, %"compiler/diagmsg:Msg" %t73)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l10, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Promise", ptr %t74, i32 0, i32 1
  %t77 = load i32, ptr %t76, !range !{i32 0, i32 114}
  %t79 = trunc i64 57 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Sig", ptr %t82, i32 0, i32 4
  %t85 = load i1, ptr %t84, !tbaa !21
  store i1 %t85, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t87 = load i1, ptr %l61, !tbaa !21
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l64, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l65, !tbaa !29
  %t90 = load ptr, ptr %l10, !tbaa !29
  store ptr %t90, ptr %l66, !tbaa !29
  %t91 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseReturnsNoreturn(ptr %v0)
  store %"compiler/diagmsg:Msg" %t91, ptr %l67
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t92 = load ptr, ptr %l64, !tbaa !29
  %t93 = load ptr, ptr %l65, !tbaa !29
  %t94 = load ptr, ptr %l66, !tbaa !29
  %t95 = load %"compiler/diagmsg:Msg", ptr %l67
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t92, ptr %t93, ptr %t94, %"compiler/diagmsg:Msg" %t95)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t96 = load ptr, ptr %l10, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Promise", ptr %t96, i32 0, i32 1
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 114}
  %t101 = trunc i64 66 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb27, label %bb28
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eresultMayHold(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l74
  br label %bb29
bb28:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb30
bb29:
  %t109 = load i1, ptr %l74, !tbaa !21
  %t110 = xor i1 %t109, true
  store i1 %t110, ptr %l71, !tbaa !21
  br label %bb30
bb30:
  %t112 = load i1, ptr %l71, !tbaa !21
  br i1 %t112, label %bb31, label %bb32
bb31:
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l76, !tbaa !29
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l77, !tbaa !29
  %t115 = load ptr, ptr %l10, !tbaa !29
  store ptr %t115, ptr %l78, !tbaa !29
  %t116 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsNothing(ptr %v0, ptr %v0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t116, ptr %l79
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t117 = load ptr, ptr %l76, !tbaa !29
  %t118 = load ptr, ptr %l77, !tbaa !29
  %t119 = load ptr, ptr %l78, !tbaa !29
  %t120 = load %"compiler/diagmsg:Msg", ptr %l79
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t117, ptr %t118, ptr %t119, %"compiler/diagmsg:Msg" %t120)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t121 = load i64, ptr %l4, !tbaa !24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = or i64 %t121, %t122
  store i64 %t125, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load ptr, ptr %l10, !tbaa !29
  %t135 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseParam(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t127, ptr %t128, ptr %t129, ptr %t130, i64 0)
  store i64 %t135, ptr %l87
  br label %bb37
bb37:
  %t136 = load i64, ptr %l87, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = icmp slt i64 %t137, 0
  br i1 %t139, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb39:
  br label %bb40
bb40:
  %t141 = load ptr, ptr %l10, !tbaa !29
  %t143 = getelementptr %"compiler/ast:Promise", ptr %t141, i32 0, i32 1
  %t144 = load i32, ptr %t143, !range !{i32 0, i32 114}
  %t146 = trunc i64 65 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb41, label %bb42
bb41:
  %t149 = load i64, ptr %l12, !tbaa !24
  %t152 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l5, i64 %t149)
  store i1 %t152, ptr %l95
  br label %bb43
bb42:
  br label %bb66
bb43:
  %t153 = load i1, ptr %l95, !tbaa !21
  br i1 %t153, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l96, !tbaa !29
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l97, !tbaa !29
  %t156 = load ptr, ptr %l10, !tbaa !29
  store ptr %t156, ptr %l98, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t160 = getelementptr %"compiler/ast:Promise", ptr %t158, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l101, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 0
  %t165 = load i32, ptr %t164, !tbaa !33
  %t168 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %s10, ptr %t157, i32 %t165)
  store { i64, ptr } %t168, ptr %l103
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t169 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t171 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = add i64 %t170, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t169, i64 %t170)
  %t176 = getelementptr i8, ptr %t175, i64 %t170
  call void @olang_textcopy(ptr %t176, ptr %t172, i64 %t173)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t187 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseTwice(ptr %v0, ptr %v0, { i64, ptr } %t185)
  store %"compiler/diagmsg:Msg" %t187, ptr %l106
  br label %bb47
bb47:
  %t188 = load ptr, ptr %l96, !tbaa !29
  %t189 = load ptr, ptr %l97, !tbaa !29
  %t190 = load ptr, ptr %l98, !tbaa !29
  %t191 = load %"compiler/diagmsg:Msg", ptr %l106
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t188, ptr %t189, ptr %t190, %"compiler/diagmsg:Msg" %t191)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l3, !tbaa !23
  %t196 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eresultMayHold(ptr %v0, ptr %t192, i32 %t193)
  store i1 %t196, ptr %l109
  br label %bb50
bb50:
  %t197 = load i1, ptr %l109, !tbaa !21
  %t198 = xor i1 %t197, true
  br i1 %t198, label %bb51, label %bb52
bb51:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l112, !tbaa !29
  %t202 = load ptr, ptr %l10, !tbaa !29
  store ptr %t202, ptr %l113, !tbaa !29
  %t203 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsNothing(ptr %v0, ptr %v0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t203, ptr %l114
  br label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l115, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/generic:Program", ptr %t205, i32 0, i32 2
  store ptr %t207, ptr %l117, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  %t211 = load i32, ptr %l3, !tbaa !23
  %t214 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t210, i32 %t211)
  store i32 %t214, ptr %l121
  br label %bb55
bb53:
  %t215 = load ptr, ptr %l111, !tbaa !29
  %t216 = load ptr, ptr %l112, !tbaa !29
  %t217 = load ptr, ptr %l113, !tbaa !29
  %t218 = load %"compiler/diagmsg:Msg", ptr %l114
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t215, ptr %t216, ptr %t217, %"compiler/diagmsg:Msg" %t218)
  br label %bb54
bb54:
  br label %bb64
bb55:
  %t219 = load ptr, ptr %l117, !tbaa !29
  %t220 = load i32, ptr %l121, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s13, ptr %t219, i32 %t220)
  store { i64, ptr } %t221, ptr %l122
  br label %bb56
bb56:
  %t222 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t222, ptr %l123, !tbaa !27
  %t223 = load i64, ptr %l12, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i32, ptr %t226, i64 %t223
  %t228 = load i32, ptr %t227, !tbaa !33
  %t229 = load ptr, ptr %l115, !tbaa !29
  %t231 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t229, i32 %t228)
  store i1 %t231, ptr %l126
  br label %bb57
bb57:
  %t232 = load i1, ptr %l126, !tbaa !21
  %t233 = xor i1 %t232, true
  br i1 %t233, label %bb58, label %bb59
bb58:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l128, !tbaa !29
  %t236 = load ptr, ptr %l1, !tbaa !29
  store ptr %t236, ptr %l129, !tbaa !29
  %t237 = load ptr, ptr %l10, !tbaa !29
  store ptr %t237, ptr %l130, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l10, !tbaa !29
  %t241 = getelementptr %"compiler/ast:Promise", ptr %t239, i32 0, i32 2
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l133, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i32, ptr %t244, i64 0
  %t246 = load i32, ptr %t245, !tbaa !33
  %t249 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t238, i32 %t246)
  store { i64, ptr } %t249, ptr %l135
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t250 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t251 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsValue(ptr %v0, ptr %v0, { i64, ptr } %t250)
  store %"compiler/diagmsg:Msg" %t251, ptr %l136
  br label %bb61
bb61:
  %t252 = load ptr, ptr %l128, !tbaa !29
  %t253 = load ptr, ptr %l129, !tbaa !29
  %t254 = load ptr, ptr %l130, !tbaa !29
  %t255 = load %"compiler/diagmsg:Msg", ptr %l136
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t252, ptr %t253, ptr %t254, %"compiler/diagmsg:Msg" %t255)
  br label %bb62
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s13)
  br label %bb64
bb64:
  %t256 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t256)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb66:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t261 = load ptr, ptr %l2, !tbaa !29
  %t262 = load i32, ptr %l3, !tbaa !23
  %t263 = load ptr, ptr %l10, !tbaa !29
  %t264 = load i64, ptr %l12, !tbaa !24
  %t271 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ekeepsPromise(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %s3, ptr %t259, ptr %t260, ptr %t261, i32 %t262, ptr %t263, i64 %t264)
  store { i64, ptr } %t271, ptr %l145
  br label %bb67
bb67:
  %t272 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t272, ptr %l13, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t277 = icmp eq i64 %t275, 0
  br i1 %t277, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb69:
  br label %bb70
bb70:
  store i64 0, ptr %l14, !tbaa !24
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t280, ptr %l150
  br label %bb71
bb71:
  %t281 = load i64, ptr %l150, !tbaa !24
  %t282 = sdiv i64 %t281, 3
  store i64 %t282, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t284 = load i64, ptr %l15, !tbaa !24
  %t285 = load i64, ptr %l14, !tbaa !24
  %t288 = icmp sgt i64 %t284, %t285
  br i1 %t288, label %bb72, label %bb73
bb72:
  %t290 = load i64, ptr %l16, !tbaa !24
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb77
bb74:
  %t294 = load i64, ptr %l15, !tbaa !24
  %t295 = load i64, ptr %l14, !tbaa !24
  %t298 = sub i64 %t294, %t295
  %t299 = load i64, ptr %l16, !tbaa !24
  %t302 = add i64 %t298, %t299
  %t304 = sub i64 %t302, 1
  %t305 = load i64, ptr %l16, !tbaa !24
  %t308 = sdiv i64 %t304, %t305
  store i64 %t308, ptr %l158, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb76
bb76:
  %t310 = load i64, ptr %l158, !tbaa !24
  store i64 %t310, ptr %l155, !tbaa !24
  br label %bb77
bb77:
  %t311 = load i64, ptr %l155, !tbaa !24
  store i64 %t311, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb78
bb78:
  %t312 = load i64, ptr %l18, !tbaa !24
  %t313 = load i64, ptr %l17, !tbaa !24
  %t316 = icmp slt i64 %t312, %t313
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb79, label %bb80
bb79:
  br label %bb100
bb80:
  br label %bb81
bb81:
  %t320 = load i64, ptr %l14, !tbaa !24
  %t321 = load i64, ptr %l18, !tbaa !24
  %t322 = load i64, ptr %l16, !tbaa !24
  %t325 = mul i64 %t321, %t322
  %t328 = add i64 %t320, %t325
  store i64 %t328, ptr %l19, !tbaa !24
  %t330 = load i64, ptr %l19, !tbaa !24
  %t332 = mul i64 3, %t330
  %t335 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t332)
  store i64 %t335, ptr %l179
  br label %bb82
bb82:
  %t336 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i64, ptr %t337, i64 0
  %t339 = load i64, ptr %t338, !tbaa !34
  %t340 = load i64, ptr %l179, !tbaa !24
  %t342 = icmp eq i64 %t340, %t339
  br i1 %t342, label %bb83, label %bb84
bb83:
  %t344 = load i64, ptr %l19, !tbaa !24
  %t346 = mul i64 3, %t344
  %t348 = add i64 %t346, 1
  %t351 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t348)
  store i64 %t351, ptr %l187
  br label %bb85
bb84:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb86
bb85:
  %t352 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = getelementptr i64, ptr %t353, i64 1
  %t355 = load i64, ptr %t354, !tbaa !34
  %t356 = load i64, ptr %l187, !tbaa !24
  %t358 = icmp eq i64 %t356, %t355
  store i1 %t358, ptr %l182, !tbaa !21
  br label %bb86
bb86:
  %t360 = load i1, ptr %l182, !tbaa !21
  br i1 %t360, label %bb87, label %bb88
bb87:
  %t361 = load i64, ptr %l19, !tbaa !24
  %t363 = mul i64 3, %t361
  %t365 = add i64 %t363, 2
  %t368 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t365)
  store i64 %t368, ptr %l195
  br label %bb89
bb88:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb90
bb89:
  %t369 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr i64, ptr %t370, i64 2
  %t372 = load i64, ptr %t371, !tbaa !34
  %t373 = load i64, ptr %l195, !tbaa !24
  %t375 = icmp eq i64 %t373, %t372
  store i1 %t375, ptr %l190, !tbaa !21
  br label %bb90
bb90:
  %t377 = load i1, ptr %l190, !tbaa !21
  br i1 %t377, label %bb91, label %bb92
bb91:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l198, !tbaa !29
  %t379 = load ptr, ptr %l1, !tbaa !29
  store ptr %t379, ptr %l199, !tbaa !29
  %t380 = load ptr, ptr %l10, !tbaa !29
  store ptr %t380, ptr %l200, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/generic:Program", ptr %t381, i32 0, i32 2
  store ptr %t383, ptr %l202, !tbaa !29
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/generic:Program", ptr %t384, i32 0, i32 2
  store ptr %t386, ptr %l204, !tbaa !29
  %t387 = load i32, ptr %l3, !tbaa !23
  store i32 %t387, ptr %l205, !tbaa !23
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l2, !tbaa !29
  %t392 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v2, ptr %t388, ptr %t389)
  store i64 %t392, ptr %l208
  br label %bb93
bb92:
  br label %bb98
bb93:
  %t393 = load ptr, ptr %l204, !tbaa !29
  %t394 = load i32, ptr %l205, !tbaa !23
  %t395 = load i64, ptr %l208, !tbaa !24
  %t396 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t393, i32 %t394, i64 %t395)
  store i32 %t396, ptr %l209
  br label %bb94
bb94:
  %t397 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !27
  %t399 = getelementptr i64, ptr %t398, i64 0
  %t400 = load i64, ptr %t399, !tbaa !34
  %t401 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr i64, ptr %t402, i64 1
  %t404 = load i64, ptr %t403, !tbaa !34
  %t405 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = getelementptr i64, ptr %t406, i64 2
  %t408 = load i64, ptr %t407, !tbaa !34
  %t410 = inttoptr i64 0 to ptr
  %t411 = load ptr, ptr %l202, !tbaa !29
  %t412 = load i32, ptr %l209, !tbaa !23
  %t416 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsText(ptr %v0, ptr %v0, ptr %t410, ptr %t411, i32 %t412, i64 %t400, i64 %t404, i64 %t408)
  store { i64, ptr } %t416, ptr %l214
  br label %bb95
bb95:
  %t417 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 0
  %t419 = extractvalue { i64, ptr } %t417, 1
  %t420 = mul i64 %t418, 1
  %t421 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t420)
  call void @llvm.memcpy.p0.p0.i64(ptr %t421, ptr %t419, i64 %t420, i1 false)
  %t422 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t421, 1
  %t425 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseTwice(ptr %v0, ptr %v0, { i64, ptr } %t423)
  store %"compiler/diagmsg:Msg" %t425, ptr %l216
  br label %bb96
bb96:
  %t426 = load ptr, ptr %l198, !tbaa !29
  %t427 = load ptr, ptr %l199, !tbaa !29
  %t428 = load ptr, ptr %l200, !tbaa !29
  %t429 = load %"compiler/diagmsg:Msg", ptr %l216
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t426, ptr %t427, ptr %t428, %"compiler/diagmsg:Msg" %t429)
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t430 = load i64, ptr %l18, !tbaa !24
  %t432 = add i64 %t430, 1
  store i64 %t432, ptr %l18, !tbaa !24
  br label %bb78
bb100:
  %t434 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t434, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t436 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t436, 0
  store i64 %t438, ptr %l22, !tbaa !24
  br label %bb101
bb101:
  %t440 = load i64, ptr %l21, !tbaa !24
  %t441 = load i64, ptr %l22, !tbaa !24
  %t444 = icmp slt i64 %t440, %t441
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb102, label %bb103
bb102:
  br label %bb107
bb103:
  br label %bb104
bb104:
  %t448 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t448, ptr %l226, !tbaa !27
  %t449 = load i64, ptr %l21, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr i64, ptr %t452, i64 %t449
  %t454 = load i64, ptr %t453, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t454)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t459 = load i64, ptr %l21, !tbaa !24
  %t461 = add i64 %t459, 1
  store i64 %t461, ptr %l21, !tbaa !24
  br label %bb101
bb107:
  call void @__olang_scope_close(ptr %s3)
  br label %bb108
bb108:
  %t463 = load i64, ptr %l8, !tbaa !24
  %t465 = add i64 %t463, 1
  store i64 %t465, ptr %l8, !tbaa !24
  br label %bb6
bb109:
  %t467 = load i64, ptr %l4, !tbaa !24
  %t468 = load i64, ptr @G_2ecompiler_2ftypes_2ePromNoborrow, !tbaa !24
  %t471 = and i64 %t467, %t468
  %t473 = icmp ne i64 %t471, 0
  br i1 %t473, label %bb110, label %bb111
bb110:
  %t476 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t476, ptr %l241
  br label %bb112
bb111:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb113
bb112:
  %t477 = load i64, ptr %l241, !tbaa !24
  %t478 = icmp sgt i64 %t477, 0
  store i1 %t478, ptr %l239, !tbaa !21
  br label %bb113
bb113:
  %t480 = load i1, ptr %l239, !tbaa !21
  br i1 %t480, label %bb114, label %bb115
bb114:
  %t481 = load ptr, ptr %l0, !tbaa !29
  store ptr %t481, ptr %l243, !tbaa !29
  %t482 = load ptr, ptr %l1, !tbaa !29
  store ptr %t482, ptr %l244, !tbaa !29
  %t483 = load ptr, ptr %l2, !tbaa !29
  %t485 = getelementptr %"compiler/ast:Sig", ptr %t483, i32 0, i32 8
  %t486 = load { i64, ptr }, ptr %t485, !tbaa !27
  store { i64, ptr } %t486, ptr %l246, !tbaa !27
  %t487 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = getelementptr ptr, ptr %t488, i64 0
  %t490 = load ptr, ptr %t489, !tbaa !39
  store ptr %t490, ptr %l247, !tbaa !29
  %t491 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsBoth(ptr %v0)
  store %"compiler/diagmsg:Msg" %t491, ptr %l248
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t492 = load ptr, ptr %l243, !tbaa !29
  %t493 = load ptr, ptr %l244, !tbaa !29
  %t494 = load ptr, ptr %l247, !tbaa !29
  %t495 = load %"compiler/diagmsg:Msg", ptr %l248
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t492, ptr %t493, ptr %t494, %"compiler/diagmsg:Msg" %t495)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/generic:Program", ptr %t496, i32 0, i32 2
  store ptr %t498, ptr %l250, !tbaa !29
  %t499 = load i64, ptr %l4, !tbaa !24
  store i64 %t499, ptr %l251, !tbaa !24
  %t501 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t501, ptr %l253
  br label %bb119
bb119:
  %t503 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t503, ptr %l255
  br label %bb120
bb120:
  %t504 = load ptr, ptr %l250, !tbaa !29
  %t505 = load i64, ptr %l251, !tbaa !24
  %t506 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t507 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t508 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %s0, ptr %s0, ptr %t504, i64 %t505, { i64, ptr } %t506, { i64, ptr } %t507)
  store i64 %t508, ptr %l256
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s0)
  %t509 = load i64, ptr %l256, !tbaa !24
  store i64 %t509, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvExact(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %t1, i64 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp ne i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l9, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca i64
  %l51 = alloca %"compiler/names:Ref"
  %l55 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca i1
  %l73 = alloca i32
  %l74 = alloca i64
  %l78 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i1
  %l88 = alloca i1
  %l90 = alloca i64
  %l94 = alloca i32
  %l95 = alloca i64
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %t21, i64 %t22, ptr %t23, { i64, ptr } %t24)
  store i64 %t29, ptr %l24
  br label %bb9
bb9:
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 3
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l26, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %t46, i64 %t47, ptr %t48, { i64, ptr } %t50)
  store i64 %t55, ptr %l36
  br label %bb16
bb16:
  %t56 = load i64, ptr %l36, !tbaa !24
  store i64 %t56, ptr %rv
  br label %ret
bb17:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t58 = load ptr, ptr %l37, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l37, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 8}
  %t64 = icmp eq i64 %t62, 0
  store i1 %t64, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t65 = load i1, ptr %l38, !tbaa !21
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t68, i32 0, i32 0
  %t70 = load %"compiler/source:Span", ptr %t69
  store %"compiler/source:Span" %t70, ptr %l6
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t74, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75
  store { i64, ptr } %t76, ptr %l7, !tbaa !27
  br label %bb22
bb21:
  br label %bb56
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l46, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l49
  br label %bb23
bb23:
  %t87 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = load i64, ptr %l49, !tbaa !24
  %t92 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t89, i64 %t90, i32 %t88)
  store %"compiler/names:Ref" %t92, ptr %l51
  br label %bb24
bb24:
  %t93 = load %"compiler/names:Ref", ptr %l51
  store %"compiler/names:Ref" %t93, ptr %l8
  %t94 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t95 = load i32, ptr %t94, !range !{i32 0, i32 9}
  %t97 = trunc i64 8 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb25, label %bb26
bb25:
  %t100 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t101, ptr %l55, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 0
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call ptr @compiler_2fgeneric_2elisted(ptr %v2, ptr %v2, { i64, ptr } %t100, i32 %t105)
  store ptr %t108, ptr %l57
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t109 = load ptr, ptr %l57, !tbaa !29
  store ptr %t109, ptr %l9, !tbaa !29
  %t110 = load ptr, ptr %l9, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb28, label %bb29
bb28:
  store i64 -1, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l1, !tbaa !24
  %t117 = load ptr, ptr %l9, !tbaa !29
  %t121 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstraintKey(ptr %v0, ptr %v2, ptr %t115, i64 %t116, ptr %t117)
  store i64 %t121, ptr %l64
  br label %bb31
bb31:
  %t122 = load i64, ptr %l64, !tbaa !24
  store i64 %t122, ptr %rv
  br label %ret
bb32:
  %t123 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t124 = load i32, ptr %t123, !range !{i32 0, i32 9}
  %t126 = trunc i64 4 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t129 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = icmp sge i64 %t130, 0
  store i1 %t132, ptr %l67, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l67, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 1
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t139 = load i64, ptr %t138, !tbaa !24
  %t143 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t135, i64 %t137, i64 %t139)
  store i32 %t143, ptr %l73
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t144 = load i32, ptr %l73, !tbaa !23
  %t145 = call i64 @compiler_2fgeneric_2ekeyDecl(i32 %t144)
  store i64 %t145, ptr %l74
  br label %bb39
bb39:
  %t146 = load i64, ptr %l74, !tbaa !24
  store i64 %t146, ptr %rv
  br label %ret
bb40:
  %t147 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t148 = load i32, ptr %t147, !range !{i32 0, i32 9}
  %t150 = trunc i64 7 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t154, ptr %l78, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = sub i64 %t157, 1
  %t161 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t153, i32 %t164)
  store { i64, ptr } %t167, ptr %l83
  br label %bb43
bb42:
  br label %bb55
bb43:
  %t168 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t169, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t171, ptr %l85
  br label %bb44
bb44:
  %t172 = load i1, ptr %l85, !tbaa !21
  br i1 %t172, label %bb45, label %bb46
bb45:
  %t173 = load i64, ptr @G_2ecompiler_2fgeneric_2eArrayKey, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  store i64 %t173, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t175 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t177 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t175, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t177, ptr %l88
  br label %bb48
bb48:
  %t178 = load i1, ptr %l88, !tbaa !21
  br i1 %t178, label %bb49, label %bb50
bb49:
  %t179 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t181 = call i64 @compiler_2fgeneric_2ekeyPrim(i32 %t179)
  store i64 %t181, ptr %l90
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s8)
  %t182 = load i64, ptr %l90, !tbaa !24
  store i64 %t182, ptr %rv
  br label %ret
bb52:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t185, { i64, ptr } %t186)
  store i32 %t189, ptr %l94
  br label %bb53
bb53:
  %t190 = load i32, ptr %l94, !tbaa !23
  %t191 = call i64 @compiler_2fgeneric_2ekeyPrim(i32 %t190)
  store i64 %t191, ptr %l95
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  %t192 = load i64, ptr %l95, !tbaa !24
  store i64 %t192, ptr %rv
  br label %ret
bb55:
  store i64 -1, ptr %rv
  br label %ret
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store i64 -1, ptr %rv
  br label %ret
bb60:
  call void @__olang_check_failed(ptr @olang_loc_769954e80c04bef7_8801cb066681a71b)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eresultMayHold(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s1, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 4
  %t12 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t28, ptr %l17, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %t36, i32 %t34)
  store i1 %t40, ptr %l22
  br label %bb6
bb6:
  %t41 = load i1, ptr %l22, !tbaa !21
  br i1 %t41, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb2
bb11:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eroundTrip(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eParseCanon(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  %t6 = extractvalue { i32, i32 } %t5, 1
  %t7 = extractvalue { i32, i32 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t18 = inttoptr i64 0 to ptr
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t18, ptr %t15, i32 %t12)
  store { i64, ptr } %t21, ptr %l13
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  %t24 = extractvalue { i64, ptr } %t22, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t28, { i64, ptr } %t29)
  store i1 %t32, ptr %l16
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i1, ptr %l16, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esameUpToShape(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i32
  %l11 = alloca i1
  %l16 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i32
  %l41 = alloca i32
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t3, i32 %t4, i32 %t5)
  store i1 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i1, ptr %l11, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l16
  br label %bb5
bb5:
  %t19 = load i32, ptr %l16, !range !{i32 0, i32 33}
  %t21 = trunc i64 20 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l3, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l22
  br label %bb6
bb6:
  %t31 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t33 = trunc i64 20 to i32
  %t34 = icmp eq i32 %t31, %t33
  store i1 %t34, ptr %l4, !tbaa !21
  %t36 = load i1, ptr %l3, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load i1, ptr %l4, !tbaa !21
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l26, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load i1, ptr %l3, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l34
  br label %bb15
bb14:
  %t51 = load i32, ptr %l1, !tbaa !23
  store i32 %t51, ptr %l30, !tbaa !23
  br label %bb16
bb15:
  %t53 = load i32, ptr %l34, !tbaa !23
  store i32 %t53, ptr %l30, !tbaa !23
  br label %bb16
bb16:
  %t54 = load i32, ptr %l30, !tbaa !23
  store i32 %t54, ptr %l5, !tbaa !23
  %t55 = load i1, ptr %l4, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l41
  br label %bb19
bb18:
  %t64 = load i32, ptr %l2, !tbaa !23
  store i32 %t64, ptr %l37, !tbaa !23
  br label %bb20
bb19:
  %t66 = load i32, ptr %l41, !tbaa !23
  store i32 %t66, ptr %l37, !tbaa !23
  br label %bb20
bb20:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l5, !tbaa !23
  %t76 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t70, i32 %t71, i32 %t67)
  store i1 %t76, ptr %l47
  br label %bb21
bb21:
  %t77 = load i1, ptr %l47, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d29, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etraitReaches(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i1
  %l42 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i1
  %l63 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr { i64, [6 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [6 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t21, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [6 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t27, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28
  %t33 = extractvalue { i64, ptr } %t29, 0
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l27, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  store i32 %t38, ptr %l28, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l31
  br label %bb8
bb7:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = load i32, ptr %l28, !tbaa !23
  %t46 = load i32, ptr %l31, !tbaa !23
  %t47 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %t44, i32 %t45, i32 %t46)
  store i1 %t47, ptr %l32
  br label %bb9
bb9:
  %t48 = load i1, ptr %l32, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t53, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb33
bb16:
  br label %bb17
bb17:
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t67, ptr %l42, !tbaa !27
  %t68 = load i64, ptr %l8, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr ptr, ptr %t71, i64 %t68
  %t73 = load ptr, ptr %t72, !tbaa !39
  store ptr %t73, ptr %l10, !tbaa !29
  %t75 = load ptr, ptr %l10, !tbaa !29
  %t77 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v1, ptr %t75)
  store i1 %t77, ptr %l46
  br label %bb18
bb18:
  %t78 = load i1, ptr %l46, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l47, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  store i32 %t80, ptr %l48, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  store ptr %t83, ptr %l50, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l1, !tbaa !23
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l53
  br label %bb21
bb20:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l3, !tbaa !23
  %t91 = load ptr, ptr %l10, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t98 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t89, i32 %t90, i32 %t94)
  store i64 %t98, ptr %l63
  br label %bb27
bb21:
  %t99 = load ptr, ptr %l50, !tbaa !29
  %t100 = load i32, ptr %l53, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t99, i32 %t100)
  store i32 %t101, ptr %l54
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l10, !tbaa !29
  %t103 = load ptr, ptr %l47, !tbaa !29
  %t104 = load i32, ptr %l48, !tbaa !23
  %t105 = load i32, ptr %l54, !tbaa !23
  %t107 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetsBuilder(ptr %v0, ptr %v1, ptr %t103, i32 %t104, i32 %t105, ptr %t102)
  store i1 %t107, ptr %l56
  br label %bb23
bb23:
  %t108 = load i1, ptr %l56, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb24, label %bb25
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb31
bb27:
  %t112 = load i64, ptr %l63, !tbaa !24
  %t113 = icmp slt i64 %t112, 0
  br i1 %t113, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l8, !tbaa !24
  br label %bb14
bb33:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i32
  %l19 = alloca i32
  %l25 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i64
  %l36 = alloca i32
  %l37 = alloca i64
  %l70 = alloca i64
  %l75 = alloca i32
  %l77 = alloca i64
  %l80 = alloca i32
  %l81 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t10 = trunc i64 20 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l14
  br label %bb4
bb3:
  %t20 = load i32, ptr %l1, !tbaa !23
  store i32 %t20, ptr %l10, !tbaa !23
  br label %bb5
bb4:
  %t22 = load i32, ptr %l14, !tbaa !23
  store i32 %t22, ptr %l10, !tbaa !23
  br label %bb5
bb5:
  %t23 = load i32, ptr %l10, !tbaa !23
  store i32 %t23, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l19
  br label %bb6
bb6:
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = load i32, ptr %l19, !tbaa !23
  %t34 = icmp ne i32 %t32, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l25
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t43 = load i32, ptr %l25, !tbaa !23
  store i32 %t43, ptr %l2, !tbaa !23
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l29
  br label %bb11
bb11:
  %t51 = load i32, ptr %l29, !range !{i32 0, i32 33}
  store i32 %t51, ptr %l3
  %t52 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l36
  br label %bb15
bb15:
  %t64 = load i32, ptr %l36, !tbaa !23
  %t65 = call i64 @compiler_2fgeneric_2ekeyDecl(i32 %t64)
  store i64 %t65, ptr %l37
  br label %bb16
bb16:
  %t66 = load i64, ptr %l37, !tbaa !24
  store i64 %t66, ptr %l30, !tbaa !24
  br label %bb67
bb17:
  %t67 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t69 = trunc i64 19 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t72 = load i64, ptr @G_2ecompiler_2fgeneric_2eArrayKey, !tbaa !24
  store i64 %t72, ptr %l30, !tbaa !24
  br label %bb67
bb21:
  %t74 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t76 = trunc i64 2 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb22, label %bb23
bb22:
  br label %bb50
bb23:
  %t79 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t81 = trunc i64 3 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb24, label %bb25
bb24:
  br label %bb50
bb25:
  %t84 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t86 = trunc i64 4 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb26, label %bb27
bb26:
  br label %bb50
bb27:
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t91 = trunc i64 5 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb28, label %bb29
bb28:
  br label %bb50
bb29:
  %t94 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t96 = trunc i64 6 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb30, label %bb31
bb30:
  br label %bb50
bb31:
  %t99 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t101 = trunc i64 7 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb32, label %bb33
bb32:
  br label %bb50
bb33:
  %t104 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t106 = trunc i64 8 to i32
  %t107 = icmp eq i32 %t104, %t106
  br i1 %t107, label %bb34, label %bb35
bb34:
  br label %bb50
bb35:
  %t109 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t111 = trunc i64 9 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb36, label %bb37
bb36:
  br label %bb50
bb37:
  %t114 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t116 = trunc i64 10 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb38, label %bb39
bb38:
  br label %bb50
bb39:
  %t119 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t121 = trunc i64 11 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb40, label %bb41
bb40:
  br label %bb50
bb41:
  %t124 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t126 = trunc i64 12 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb42, label %bb43
bb42:
  br label %bb50
bb43:
  %t129 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t131 = trunc i64 13 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb44, label %bb45
bb44:
  br label %bb50
bb45:
  %t134 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t136 = trunc i64 14 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb46, label %bb47
bb46:
  br label %bb50
bb47:
  %t139 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t141 = trunc i64 31 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t144 = load i32, ptr %l2, !tbaa !23
  %t146 = call i64 @compiler_2fgeneric_2ekeyPrim(i32 %t144)
  store i64 %t146, ptr %l70
  br label %bb51
bb51:
  %t147 = load i64, ptr %l70, !tbaa !24
  store i64 %t147, ptr %l30, !tbaa !24
  br label %bb67
bb52:
  %t148 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t150 = trunc i64 32 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb62
bb55:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l2, !tbaa !23
  %t157 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrDeclOf(ptr %v0, ptr %t153, i32 %t154)
  store i32 %t157, ptr %l75
  br label %bb56
bb56:
  %t158 = load i32, ptr %l75, !tbaa !23
  %t159 = icmp sge i32 %t158, 0
  br i1 %t159, label %bb57, label %bb58
bb57:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l2, !tbaa !23
  %t165 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrDeclOf(ptr %v0, ptr %t161, i32 %t162)
  store i32 %t165, ptr %l80
  br label %bb59
bb58:
  store i64 -1, ptr %l77, !tbaa !24
  br label %bb61
bb59:
  %t166 = load i32, ptr %l80, !tbaa !23
  %t167 = call i64 @compiler_2fgeneric_2ekeyDecl(i32 %t166)
  store i64 %t167, ptr %l81
  br label %bb60
bb60:
  %t168 = load i64, ptr %l81, !tbaa !24
  store i64 %t168, ptr %l77, !tbaa !24
  br label %bb61
bb61:
  %t169 = load i64, ptr %l77, !tbaa !24
  store i64 %t169, ptr %l30, !tbaa !24
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i64 -1, ptr %l30, !tbaa !24
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_cbc970693726adb_6d60ff5fdd174af)
  unreachable
bb67:
  %t170 = load i64, ptr %l30, !tbaa !24
  store i64 %t170, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunaryType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i1
  %l15 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l3, !range !{i32 0, i32 114}
  %t3 = trunc i64 69 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l3, !range !{i32 0, i32 114}
  %t8 = trunc i64 104 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t12, ptr %a1, ptr %a2, ptr %a4)
  store i32 %t21, ptr %l15
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
bb7:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 114}
  %t25 = trunc i64 105 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l19
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
bb11:
  %t32 = load i32, ptr %l3, !range !{i32 0, i32 114}
  %t34 = trunc i64 48 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyErrs(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i1
  %l24 = alloca i32
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l43 = alloca i1
  %l47 = alloca i64
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l69 = alloca i1
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca ptr
  %l87 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %t1, i32 %t2, ptr %t3)
  store i1 %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load i1, ptr %l18, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t19 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %t11, i32 %t12, i32 %t13, ptr %t14, i1 false)
  store i32 %t19, ptr %l24
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb5, label %ok.21, !prof !99
ok.21:
  br label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb6
bb5:
  %t22 = load i32, ptr %l24, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 1, i32 0
  %t27 = icmp eq i32 %t22, 0
  %t28 = shl i32 %t26, 16
  %t29 = or i32 %t28, %t24
  %t30 = select i1 %t27, i32 0, i32 %t29
  call void @__olang_scope_close(ptr %s0)
  store i32 %t30, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb7:
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l26
  br label %bb8
bb8:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l4
  store i64 -1, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l30
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb11, label %bb12
bb11:
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l37, !tbaa !27
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l9, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l9, !tbaa !23
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %t62, i32 %t63, ptr %t64)
  store i1 %t68, ptr %l43
  br label %bb14
bb14:
  %t69 = load i1, ptr %l43, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l9, !tbaa !23
  %t76 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t72, i32 %t73)
  store i64 %t76, ptr %l47
  br label %bb17
bb16:
  %t77 = load i32, ptr %l9, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t77)
  br label %bb18
bb17:
  %t80 = load i64, ptr %l47, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l7, !tbaa !24
  br label %bb10
bb21:
  %t85 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l52
  br label %bb22
bb22:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l10
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l2, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l56
  br label %bb23
bb23:
  %t94 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t94, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  %t99 = load i64, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb25, label %bb26
bb25:
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t108
  %t113 = load i32, ptr %t112, !tbaa !33
  store i32 %t113, ptr %l14, !tbaa !23
  %t115 = load i32, ptr %l14, !tbaa !23
  %t116 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t119 = icmp eq i32 %t115, %t116
  br i1 %t119, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb30
bb29:
  %t121 = load i32, ptr %l14, !tbaa !23
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = icmp eq i32 %t121, %t122
  store i1 %t125, ptr %l69, !tbaa !21
  br label %bb30
bb30:
  %t127 = load i1, ptr %l69, !tbaa !21
  br i1 %t127, label %bb31, label %bb32
bb31:
  br label %bb39
bb32:
  br label %bb33
bb33:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l14, !tbaa !23
  %t133 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentryHeld(ptr %v0, ptr %s0, ptr %t128, i32 %t129, ptr %l4)
  store i1 %t133, ptr %l76
  br label %bb34
bb34:
  %t134 = load i1, ptr %l76, !tbaa !21
  %t135 = xor i1 %t134, true
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t137 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l10, i32 %t137)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l12, !tbaa !24
  br label %bb24
bb40:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l3, !tbaa !29
  store ptr %t145, ptr %l83, !tbaa !29
  %t146 = load i64, ptr %l5, !tbaa !24
  store i64 %t146, ptr %l84, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l85, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  store ptr %t150, ptr %l87, !tbaa !29
  %t152 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t152, ptr %l89
  br label %bb41
bb41:
  %t153 = load ptr, ptr %l87, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t155 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t153, { i64, ptr } %t154)
  store i32 %t155, ptr %l90
  br label %bb42
bb42:
  %t156 = load ptr, ptr %l85, !tbaa !29
  %t157 = load i32, ptr %l90, !tbaa !23
  %t158 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t158, ptr %l91
  br label %bb43
bb43:
  %t159 = load ptr, ptr %l82, !tbaa !29
  %t160 = load ptr, ptr %l83, !tbaa !29
  %t161 = load i64, ptr %l84, !tbaa !24
  %t162 = load i32, ptr %l91, !tbaa !23
  %t163 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebind(ptr %v0, ptr %v1, ptr %t159, ptr %t160, i64 %t161, i32 %t162, i1 false, i1 false)
  store i32 %t163, ptr %l92
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb45, label %ok.165, !prof !99
ok.165:
  br label %bb44
bb44:
  br label %bb46
bb45:
  %t166 = load i32, ptr %l92, !tbaa !23
  %t167 = lshr i32 %t166, 16
  %t168 = and i32 %t166, 65535
  %t169 = icmp eq i32 %t167, 1
  %t170 = select i1 %t169, i32 1, i32 0
  %t171 = icmp eq i32 %t166, 0
  %t172 = shl i32 %t170, 16
  %t173 = or i32 %t172, %t168
  %t174 = select i1 %t171, i32 0, i32 %t173
  call void @__olang_scope_close(ptr %s0)
  store i32 %t174, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunknowns(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t16 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 2
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l4, !tbaa !24
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b7daf7406ba778a4_42e2bd1e0b6e1610)
  unreachable
bb3:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  %t15 = load i32, ptr %l5, !tbaa !23
  store i64 0, ptr %t16
  br label %fill.17
fill.17:
  %t20 = load i64, ptr %t16
  %t21 = icmp slt i64 %t20, %t12
  br i1 %t21, label %fillb.18, label %filld.19
fillb.18:
  %t22 = getelementptr i32, ptr %t14, i64 %t20
  store i32 %t15, ptr %t22
  %t23 = add i64 %t20, 1
  store i64 %t23, ptr %t16
  br label %fill.17
filld.19:
  %t24 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t14, 1
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t26, { i64, ptr } %t25)
  store i32 %t28, ptr %l9
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b7daf7406ba778a4_42e2bd1e0b6e1610)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l9, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eviewGeneratorOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca i32
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l73 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i32
  %l83 = alloca i32
  %l84 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d31, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d32, i32 0, i32 1) })
  %t4 = extractvalue { i32, i32 } %t3, 1
  %t5 = extractvalue { i32, i32 } %t3, 0
  store i32 %t5, ptr %l14
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i32 %t4, ptr %l13
  br label %bb1
bb1:
  %t8 = load i32, ptr %l13, !tbaa !23
  store i32 %t8, ptr %l11, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  store ptr %t14, ptr %l17, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t17, i32 %a1)
  store i32 %t21, ptr %l21
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load i32, ptr %l21, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t22, i32 %t23)
  store { i64, ptr } %t24, ptr %l22
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp eq i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l29, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 0
  %t39 = load i32, ptr %t38, !tbaa !33
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t39)
  store i32 %t42, ptr %l31
  br label %bb9
bb9:
  %t43 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l26, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t51, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l37, !tbaa !24
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = icmp sge i64 %t56, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = icmp sle i64 %t59, 2305843009213693951
  br i1 %t60, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48)
  unreachable
bb16:
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = mul i64 %t62, 4
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 0
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t70, i32 %t75)
  store i32 %t78, ptr %l45
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48)
  unreachable
bb18:
  %t79 = load i32, ptr %l45, !tbaa !23
  %t80 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 0
  store i32 %t79, ptr %t82, !tbaa !33
  store i64 1, ptr %l5, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb24
bb21:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l54, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t113 = load i64, ptr %l54, !tbaa !24
  store i64 %t113, ptr %l51, !tbaa !24
  br label %bb24
bb24:
  %t114 = load i64, ptr %l51, !tbaa !24
  store i64 %t114, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t123 = load i64, ptr %l5, !tbaa !24
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l7, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t134, ptr %l73, !tbaa !27
  %t135 = load i64, ptr %l10, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i32, ptr %t138, i64 %t135
  %t140 = load i32, ptr %t139, !tbaa !33
  %t143 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i32, ptr %t144, i64 %t133
  store i32 %t140, ptr %t145, !tbaa !33
  br label %bb29
bb29:
  %t146 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l78, !tbaa !29
  %t151 = load i32, ptr %l2, !tbaa !23
  store i32 %t151, ptr %l79, !tbaa !23
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t154, { i64, ptr } %t155)
  store i32 %t158, ptr %l83
  br label %bb31
bb31:
  %t159 = load ptr, ptr %l78, !tbaa !29
  %t160 = load i32, ptr %l79, !tbaa !23
  %t161 = load i32, ptr %l83, !tbaa !23
  %t162 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t159, i32 %t160, i32 %t161)
  store i32 %t162, ptr %l84
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t163 = load i32, ptr %l84, !tbaa !23
  store i32 %t163, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewide(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t15, i32 %t16)
  store i64 %t17, ptr %l11
  br label %bb4
bb4:
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp sgt i64 %t18, 64
  store i1 %t19, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l5, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebinds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l50 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 9}
  %t23 = icmp eq i64 %t21, 7
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 9}
  %t38 = icmp eq i64 %t36, 5
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t42, i32 0, i32 2
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t48 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t46, i32 %t47, i64 %t48)
  br label %bb14
bb14:
  br label %bb44
bb15:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t53 = load ptr, ptr %l31, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 9}
  %t59 = icmp eq i64 %t57, 2
  store i1 %t59, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l32, !tbaa !21
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t63, i32 0, i32 2
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l4, !tbaa !27
  br label %bb24
bb19:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb20, label %bb21
bb20:
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 9}
  %t74 = icmp eq i64 %t72, 6
  store i1 %t74, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t75 = load i1, ptr %l38, !tbaa !21
  br i1 %t75, label %bb22, label %bb23
bb22:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t78, i32 0, i32 2
  %t80 = load { i64, ptr }, ptr %t79
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t96 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t96, ptr %l50, !tbaa !27
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebinds(ptr %v0, ptr %v1, ptr %t104, ptr %t102, i64 %t106)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l6, !tbaa !24
  br label %bb25
bb31:
  br label %bb44
bb32:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t115 = load ptr, ptr %l58, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t118 = load ptr, ptr %l58, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 9}
  %t121 = icmp eq i64 %t119, 8
  store i1 %t121, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t122 = load i1, ptr %l59, !tbaa !21
  br i1 %t122, label %bb35, label %bb36
bb35:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l9, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l9, !tbaa !29
  %t131 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebinds(ptr %v0, ptr %v1, ptr %t129, ptr %t130, i64 %t131)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_961f770be6209277_34282562e2239643)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2edeclared(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l34 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca { i64, ptr }
  %l46 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:VarDecl", ptr %t28, i32 0, i32 3
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:VarDecl", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp eq i64 %t33, %t39
  br i1 %t42, label %bb5, label %bb6
bb5:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l6, !tbaa !23
  store i32 %t45, ptr %l27, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 3
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l30, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  %t60 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t46, ptr %t56)
  store i64 %t60, ptr %l34
  br label %bb7
bb6:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:VarDecl", ptr %t61, i32 0, i32 3
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp eq i64 %t66, 1
  br i1 %t68, label %bb9, label %bb10
bb7:
  %t70 = load ptr, ptr %l26, !tbaa !29
  %t71 = load i32, ptr %l27, !tbaa !23
  %t72 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t70, i32 %t71, i64 %t72)
  br label %bb8
bb8:
  br label %bb15
bb9:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l39, !tbaa !29
  %t74 = load i32, ptr %l6, !tbaa !23
  store i32 %t74, ptr %l40, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/ast:VarDecl", ptr %t76, i32 0, i32 3
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l43, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 0
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t75, ptr %t83)
  store i64 %t87, ptr %l46
  br label %bb11
bb10:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l6, !tbaa !23
  %t90 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t88, i32 %t89, i64 %t90)
  br label %bb13
bb11:
  %t94 = load ptr, ptr %l39, !tbaa !29
  %t95 = load i32, ptr %l40, !tbaa !23
  %t96 = load i64, ptr %l46, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t94, i32 %t95, i64 %t96)
  br label %bb12
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t97 = load i64, ptr %l3, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l3, !tbaa !24
  br label %bb1
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2einner(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l77 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l111 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t17 = load ptr, ptr %l22, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 22}
  %t23 = icmp eq i64 %t21, 20
  store i1 %t23, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l23, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t27, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l28, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 22}
  %t38 = icmp eq i64 %t36, 7
  store i1 %t38, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l29, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43
  store { i64, ptr } %t44, ptr %l2, !tbaa !27
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t47 = load ptr, ptr %l34, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 22}
  %t53 = icmp eq i64 %t51, 10
  store i1 %t53, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l35, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load { i64, ptr }, ptr %t58
  store { i64, ptr } %t59, ptr %l2, !tbaa !27
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t61, { i64, ptr } %t62)
  br label %bb18
bb18:
  br label %bb68
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t66 = load ptr, ptr %l42, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l42, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 22}
  %t72 = icmp eq i64 %t70, 8
  store i1 %t72, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l43, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/ast:For3", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  br label %bb25
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/ast:For3", ptr %t89, i32 0, i32 2
  %t92 = load ptr, ptr %t91, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  br label %bb26
bb26:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t99 = getelementptr %"compiler/ast:For3", ptr %t97, i32 0, i32 3
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t96, { i64, ptr } %t100)
  br label %bb27
bb27:
  br label %bb68
bb28:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t104 = load ptr, ptr %l59, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l59, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 22}
  %t110 = icmp eq i64 %t108, 4
  store i1 %t110, ptr %l60, !tbaa !21
  br label %bb30
bb30:
  %t111 = load i1, ptr %l60, !tbaa !21
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l4, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t120, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l5, !tbaa !27
  br label %bb33
bb32:
  br label %bb42
bb33:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb34
bb34:
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t129, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l8, !tbaa !24
  br label %bb35
bb35:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t143 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t143, ptr %l77, !tbaa !27
  %t144 = load i64, ptr %l7, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr ptr, ptr %t147, i64 %t144
  %t149 = load ptr, ptr %t148, !tbaa !39
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/ast:Catch", ptr %t149, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t151, { i64, ptr } %t155)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t158 = load i64, ptr %l7, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l7, !tbaa !24
  br label %bb35
bb41:
  br label %bb68
bb42:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t163 = load ptr, ptr %l85, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb43, label %bb44
bb43:
  %t166 = load ptr, ptr %l85, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 22}
  %t169 = icmp eq i64 %t167, 19
  store i1 %t169, ptr %l86, !tbaa !21
  br label %bb44
bb44:
  %t170 = load i1, ptr %l86, !tbaa !21
  br i1 %t170, label %bb45, label %bb46
bb45:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t173, i32 0, i32 1
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  br label %bb48
bb48:
  br label %bb68
bb49:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t183 = load ptr, ptr %l94, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb50, label %bb51
bb50:
  %t186 = load ptr, ptr %l94, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 22}
  %t189 = icmp eq i64 %t187, 18
  store i1 %t189, ptr %l95, !tbaa !21
  br label %bb51
bb51:
  %t190 = load i1, ptr %l95, !tbaa !21
  br i1 %t190, label %bb52, label %bb53
bb52:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", ptr }, ptr %t193, i32 0, i32 1
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l11, !tbaa !29
  br label %bb54
bb53:
  br label %bb63
bb54:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l11, !tbaa !29
  %t200 = getelementptr %"compiler/ast:JoinS", ptr %t198, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t197, { i64, ptr } %t201)
  br label %bb55
bb55:
  %t204 = load ptr, ptr %l11, !tbaa !29
  %t206 = getelementptr %"compiler/ast:JoinS", ptr %t204, i32 0, i32 2
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  store { i64, ptr } %t207, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l14, !tbaa !24
  br label %bb56
bb56:
  %t213 = load i64, ptr %l13, !tbaa !24
  %t214 = load i64, ptr %l14, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t221 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t221, ptr %l111, !tbaa !27
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/ast:Catch", ptr %t227, i32 0, i32 2
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t229, { i64, ptr } %t233)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t236 = load i64, ptr %l13, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l13, !tbaa !24
  br label %bb56
bb62:
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_c61310131704fb2f_f27aa7cba89c0bc3)
  unreachable
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ematched(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l24 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t9, ptr %l15
  br label %bb1
bb1:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Match", ptr %t11, i32 0, i32 3
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t28, ptr %l24, !tbaa !27
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 %t29
  %t34 = load ptr, ptr %t33, !tbaa !39
  store ptr %t34, ptr %l6, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Case", ptr %t36, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t53, ptr %l35, !tbaa !27
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr ptr, ptr %t57, i64 %t54
  %t59 = load ptr, ptr %t58, !tbaa !39
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebinds(ptr %v0, ptr %v1, ptr %t61, ptr %t59, i64 %t63)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l8, !tbaa !24
  br label %bb6
bb12:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Case", ptr %t72, i32 0, i32 4
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t71, { i64, ptr } %t75)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l4, !tbaa !24
  br label %bb2
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l49 = alloca { i64, ptr }
  %l52 = alloca i64
  %l56 = alloca i64
  %l68 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l73 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l87 = alloca i32
  %l91 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i64
  %l111 = alloca i64
  %l115 = alloca ptr
  %l116 = alloca i1
  %l125 = alloca i64
  %l141 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t6 = load ptr, ptr %l27, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l27, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l28, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2edeclared(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb91
bb10:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t25 = load ptr, ptr %l35, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l35, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 22}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l36, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l36, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", ptr }, ptr %t35, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb31
bb15:
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Multi", ptr %t39, i32 0, i32 2
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t56, ptr %l49, !tbaa !27
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l52, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t65, ptr %t62)
  store i64 %t70, ptr %l56
  br label %bb20
bb20:
  %t71 = load i64, ptr %l52, !tbaa !24
  %t72 = load i64, ptr %l56, !tbaa !24
  %t73 = or i64 %t71, %t72
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb16
bb22:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Multi", ptr %t79, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t96, ptr %l68, !tbaa !27
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l71, !tbaa !29
  %t107 = call i32 @compiler_2fgeneric_2ebaseName(ptr %v1, ptr %t102)
  store i32 %t107, ptr %l73
  br label %bb27
bb27:
  %t108 = load i64, ptr %l4, !tbaa !24
  %t109 = load ptr, ptr %l71, !tbaa !29
  %t110 = load i32, ptr %l73, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t109, i32 %t110, i64 %t108)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l10, !tbaa !24
  br label %bb23
bb30:
  br label %bb91
bb31:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t117 = load ptr, ptr %l77, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb32, label %bb33
bb32:
  %t120 = load ptr, ptr %l77, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 22}
  %t123 = icmp eq i64 %t121, 3
  store i1 %t123, ptr %l78, !tbaa !21
  br label %bb33
bb33:
  %t124 = load i1, ptr %l78, !tbaa !21
  br i1 %t124, label %bb34, label %bb35
bb34:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l13, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t133, i32 0, i32 3
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l14, !tbaa !29
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l85, !tbaa !29
  %t138 = load ptr, ptr %l13, !tbaa !29
  %t140 = call i32 @compiler_2fgeneric_2ebaseName(ptr %v1, ptr %t138)
  store i32 %t140, ptr %l87
  br label %bb37
bb37:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l14, !tbaa !29
  %t146 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  store i64 %t146, ptr %l91
  br label %bb38
bb38:
  %t147 = load ptr, ptr %l85, !tbaa !29
  %t148 = load i32, ptr %l87, !tbaa !23
  %t149 = load i64, ptr %l91, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t147, i32 %t148, i64 %t149)
  br label %bb39
bb39:
  br label %bb91
bb40:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t151 = load ptr, ptr %l92, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb41, label %bb42
bb41:
  %t154 = load ptr, ptr %l92, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 22}
  %t157 = icmp eq i64 %t155, 0
  store i1 %t157, ptr %l93, !tbaa !21
  br label %bb42
bb42:
  %t158 = load i1, ptr %l93, !tbaa !21
  br i1 %t158, label %bb43, label %bb44
bb43:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", ptr }, ptr %t161, i32 0, i32 1
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l15, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %t165, ptr %t166)
  br label %bb46
bb46:
  br label %bb91
bb47:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t170 = load ptr, ptr %l100, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb48, label %bb49
bb48:
  %t173 = load ptr, ptr %l100, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 22}
  %t176 = icmp eq i64 %t174, 21
  store i1 %t176, ptr %l101, !tbaa !21
  br label %bb49
bb49:
  %t177 = load i1, ptr %l101, !tbaa !21
  br i1 %t177, label %bb50, label %bb51
bb50:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", ptr }, ptr %t180, i32 0, i32 1
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l16, !tbaa !29
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l106, !tbaa !29
  %t185 = load ptr, ptr %l106, !tbaa !29
  %t186 = getelementptr %"compiler/generic:genRoots", ptr %t185, i32 0, i32 3
  %t187 = load i64, ptr %t186, !tbaa !24
  store i64 %t187, ptr %l107, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l16, !tbaa !29
  %t193 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t188, ptr %t189)
  store i64 %t193, ptr %l111
  br label %bb53
bb53:
  %t194 = load i64, ptr %l107, !tbaa !24
  %t195 = load i64, ptr %l111, !tbaa !24
  %t196 = or i64 %t194, %t195
  %t198 = load ptr, ptr %l106, !tbaa !29
  %t199 = getelementptr %"compiler/generic:genRoots", ptr %t198, i32 0, i32 3
  store i64 %t196, ptr %t199, !tbaa !24
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  br label %bb54
bb54:
  br label %bb91
bb55:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t205 = load ptr, ptr %l115, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb56, label %bb57
bb56:
  %t208 = load ptr, ptr %l115, !tbaa !29
  %t209 = load i64, ptr %t208, !range !{i64 0, i64 22}
  %t211 = icmp eq i64 %t209, 9
  store i1 %t211, ptr %l116, !tbaa !21
  br label %bb57
bb57:
  %t212 = load i1, ptr %l116, !tbaa !21
  br i1 %t212, label %bb58, label %bb59
bb58:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", ptr }, ptr %t215, i32 0, i32 1
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l17, !tbaa !29
  br label %bb60
bb59:
  br label %bb71
bb60:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l17, !tbaa !29
  %t222 = getelementptr %"compiler/ast:ForIn", ptr %t220, i32 0, i32 2
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t227 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t219, ptr %t223)
  store i64 %t227, ptr %l125
  br label %bb61
bb61:
  %t228 = load i64, ptr %l125, !tbaa !24
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l17, !tbaa !29
  %t232 = getelementptr %"compiler/ast:ForIn", ptr %t230, i32 0, i32 1
  %t233 = load i32, ptr %t232, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t229, i32 %t233, i64 %t228)
  br label %bb62
bb62:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l17, !tbaa !29
  %t241 = getelementptr %"compiler/ast:ForIn", ptr %t239, i32 0, i32 4
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t238, { i64, ptr } %t242)
  br label %bb63
bb63:
  %t245 = load ptr, ptr %l17, !tbaa !29
  %t247 = getelementptr %"compiler/ast:ForIn", ptr %t245, i32 0, i32 5
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l21, !tbaa !24
  br label %bb64
bb64:
  %t254 = load i64, ptr %l20, !tbaa !24
  %t255 = load i64, ptr %l21, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb65, label %bb66
bb65:
  br label %bb70
bb66:
  br label %bb67
bb67:
  %t262 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t262, ptr %l141, !tbaa !27
  %t263 = load i64, ptr %l20, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/ast:Catch", ptr %t268, i32 0, i32 2
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t270, { i64, ptr } %t274)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t277 = load i64, ptr %l20, !tbaa !24
  %t279 = add i64 %t277, 1
  store i64 %t279, ptr %l20, !tbaa !24
  br label %bb64
bb70:
  br label %bb91
bb71:
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t282 = load ptr, ptr %l149, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb72, label %bb73
bb72:
  %t285 = load ptr, ptr %l149, !tbaa !29
  %t286 = load i64, ptr %t285, !range !{i64 0, i64 22}
  %t288 = icmp eq i64 %t286, 5
  store i1 %t288, ptr %l150, !tbaa !21
  br label %bb73
bb73:
  %t289 = load i1, ptr %l150, !tbaa !21
  br i1 %t289, label %bb74, label %bb75
bb74:
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr }, ptr %t292, i32 0, i32 1
  %t294 = load ptr, ptr %t293
  store ptr %t294, ptr %l23, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebranches(ptr %v0, ptr %v1, ptr %t296, ptr %t297)
  br label %bb77
bb77:
  br label %bb91
bb78:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t302 = load ptr, ptr %l158, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb79, label %bb80
bb79:
  %t305 = load ptr, ptr %l158, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 22}
  %t308 = icmp eq i64 %t306, 11
  store i1 %t308, ptr %l159, !tbaa !21
  br label %bb80
bb80:
  %t309 = load i1, ptr %l159, !tbaa !21
  br i1 %t309, label %bb81, label %bb82
bb81:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [4 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr }, ptr %t312, i32 0, i32 1
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l24, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ematched(ptr %v0, ptr %v1, ptr %t316, ptr %t317)
  br label %bb84
bb84:
  br label %bb91
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2einner(ptr %v0, ptr %v1, ptr %t320, ptr %t321)
  br label %bb89
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_df5307d3a8bec99f_effac078aaeab34b)
  unreachable
bb91:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded() #0 {
entry:
  %l2 = alloca %"compiler/generic:folded"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s0, i64 %t1, i64 0, i32 %t2)
  store %"compiler/generic:folded" %t5, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/generic:folded", ptr %l2
  store %"compiler/generic:folded" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local i64 @compiler_2fgeneric_2ekeyDecl(i32 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = shl i64 1, 40
  %t4 = sext i32 %a0 to i64
  %t7 = or i64 %t1, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ekeyPrim(i32 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = shl i64 3, 40
  %t4 = sext i32 %a0 to i64
  %t7 = or i64 %t1, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2elitOnly(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb25
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fgeneric_2elitOnly(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l15
  br label %bb12
bb12:
  %t28 = load i1, ptr %l15, !tbaa !21
  store i1 %t28, ptr %l3, !tbaa !21
  br label %bb25
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 30}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr }, ptr %t40, i32 0, i32 1
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call i1 @compiler_2fgeneric_2elitOnly(ptr %v0, ptr %t44)
  store i1 %t46, ptr %l23
  br label %bb19
bb19:
  %t47 = load i1, ptr %l23, !tbaa !21
  store i1 %t47, ptr %l3, !tbaa !21
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_de533036e7174fdb_fce805c56f435877)
  unreachable
bb25:
  %t48 = load i1, ptr %l3, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2enameChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb10:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 47
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb14
bb13:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 46
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb14
bb14:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb16:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 45
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb20
bb19:
  %t30 = load i8, ptr %l0, !tbaa !22
  %t32 = icmp eq i8 %t30, 64
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb20
bb20:
  %t34 = load i1, ptr %l18, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2eskipBlank(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp slt i64 %t3, %a2
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp eq i8 %t15, 32
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = icmp eq i8 %t25, 9
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l13, !tbaa !21
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l8, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  br label %bb1
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/generic:AnyTable" @compiler_2fgeneric_3aAnyTable_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/generic:AnyTable"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l5, !tbaa !23
  store i32 %a1, ptr %l6, !tbaa !23
  store i32 %a2, ptr %l7, !tbaa !23
  store i64 %a3, ptr %l8, !tbaa !24
  store %"compiler/source:Span" %a4, ptr %l9
  %t11 = ptrtoint ptr %v0 to i64
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aAnyTable_2e5
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = call ptr @__olang_region_make(ptr %v0)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l16, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l16
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t17, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l18
  br label %bb3
bb3:
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aAnyTable_2e5
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l16
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = call ptr @__olang_region_or(ptr %t25, ptr null)
  %t27 = icmp ne ptr %t26, null
  %t28 = select i1 %t27, ptr %t26, ptr null
  %t29 = icmp eq ptr %t28, %t22
  call void @__olang_region_settle(ptr %t22, i1 %t29)
  br label %bb5
bb5:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t31 = load i32, ptr %l5, !tbaa !23
  %t32 = insertvalue %"compiler/generic:AnyTable" undef, i32 %t31, 0
  %t33 = load i32, ptr %l6, !tbaa !23
  %t34 = insertvalue %"compiler/generic:AnyTable" %t32, i32 %t33, 1
  %t35 = load i32, ptr %l7, !tbaa !23
  %t36 = insertvalue %"compiler/generic:AnyTable" %t34, i32 %t35, 2
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = insertvalue %"compiler/generic:AnyTable" %t36, i64 %t37, 3
  %t39 = load %"compiler/source:Span", ptr %l9
  %t40 = insertvalue %"compiler/generic:AnyTable" %t38, %"compiler/source:Span" %t39, 4
  %t42 = insertvalue %"compiler/generic:AnyTable" %t40, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, 5
  store %"compiler/generic:AnyTable" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:AnyTable", ptr %rv
  ret %"compiler/generic:AnyTable" %rr
}

define dso_local %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/generic:Origin"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/generic:Origin" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/generic:Origin" %t10, %"compiler/source:Span" %a1, 1
  %t14 = insertvalue %"compiler/generic:Origin" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/generic:Origin" %t14, i32 %a3, 3
  store %"compiler/generic:Origin" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Origin", ptr %rv
  ret %"compiler/generic:Origin" %rr
}

define dso_local void @compiler_2fgeneric_3aProgram_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/types:Table"
  %l5 = alloca %"compiler/facts:Table"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l25 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l26 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca i64
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l48 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l50 = alloca i64
  %l51 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l52 = alloca i64
  %l53 = alloca %"compiler/generic:Origin"
  %l54 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l55 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l56 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l59 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l60 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l61 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l71 = alloca %"compiler/types:Table"
  %l72 = alloca i64
  %l74 = alloca %"compiler/facts:Table"
  %l76 = alloca i64
  %l78 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l80 = alloca i64
  %l82 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l84 = alloca i64
  %l86 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l92 = alloca i64
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca i64
  %l98 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l100 = alloca i64
  %l102 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l104 = alloca i64
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l108 = alloca i64
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l112 = alloca i64
  %l114 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l116 = alloca i64
  %l118 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l120 = alloca i64
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca i64
  %l126 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l128 = alloca i64
  %l130 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l132 = alloca i64
  %l134 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l136 = alloca i64
  %l138 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l140 = alloca i64
  %l142 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l144 = alloca i64
  %l146 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l148 = alloca i64
  %l150 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l152 = alloca i64
  %l154 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l156 = alloca i64
  %l158 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l160 = alloca i64
  %l162 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l164 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l165 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l166 = alloca i64
  %l168 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l170 = alloca i64
  %l172 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l174 = alloca i64
  %l176 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l178 = alloca i64
  %l180 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l182 = alloca i64
  %l184 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l186 = alloca i64
  %l188 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l190 = alloca i64
  %l192 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l194 = alloca i64
  %l196 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l198 = alloca i64
  %l200 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l202 = alloca i64
  %l204 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l206 = alloca i64
  %l208 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca i64
  %l212 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l214 = alloca i64
  %l216 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l218 = alloca i64
  %l220 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l222 = alloca i64
  %l224 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l226 = alloca i64
  %l228 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l230 = alloca i64
  %l232 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l234 = alloca i64
  %l236 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l239 = alloca i64
  %l241 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l243 = alloca i64
  %l245 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l247 = alloca i64
  %l249 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l251 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l252 = alloca i64
  %l254 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l256 = alloca i64
  %l258 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l260 = alloca i64
  %l262 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l264 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l265 = alloca i64
  %l267 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l269 = alloca i64
  %l271 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l273 = alloca i64
  %l275 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l277 = alloca i64
  %l279 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l281 = alloca i64
  %l283 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l285 = alloca %"compiler/generic:Program"
  %t9 = alloca %"compiler/types:Table", align 8
  %t16 = alloca %"compiler/facts:Table", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/load:Loader", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  call void @compiler_2ftypes_2eTable_2eNew(ptr %t9, ptr %v0, ptr %v2, ptr %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t9, i64 2096, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l71, i64 2096, i1 false)
  %t11 = ptrtoint ptr %v2 to i64
  store i64 %t11, ptr %l72, !tbaa !24
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e3
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = call ptr @__olang_region_make(ptr %v2)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l72, !tbaa !24
  br label %bb3
bb3:
  %t17 = load i64, ptr %l72
  %t18 = inttoptr i64 %t17 to ptr
  call void @compiler_2ffacts_3aTable_2ector(ptr %t16, ptr %t18)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t16, i64 232, i1 false)
  br label %bb4
bb4:
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e3
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l72
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 2
  %t24 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t23, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = call ptr @__olang_region_or(ptr %t26, ptr null)
  %t28 = icmp ne ptr %t27, null
  %t29 = select i1 %t28, ptr %t27, ptr null
  %t30 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 2
  %t31 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t30, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = call ptr @__olang_region_or(ptr %t33, ptr null)
  %t35 = icmp ne ptr %t34, null
  %t36 = select i1 %t35, ptr %t34, ptr %t29
  %t37 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 2
  %t38 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t37, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = call ptr @__olang_region_or(ptr %t40, ptr null)
  %t42 = icmp ne ptr %t41, null
  %t43 = select i1 %t42, ptr %t41, ptr %t36
  %t44 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 1
  %t45 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t44, i32 0, i32 2
  %t46 = load { i64, ptr }, ptr %t45
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = call ptr @__olang_region_or(ptr %t47, ptr null)
  %t49 = icmp ne ptr %t48, null
  %t50 = select i1 %t49, ptr %t48, ptr %t43
  %t51 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 1
  %t52 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t51, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = call ptr @__olang_region_or(ptr %t54, ptr null)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr %t50
  %t58 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 1
  %t59 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr %t57
  %t65 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 0
  %t66 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t65, i32 0, i32 2
  %t67 = load { i64, ptr }, ptr %t66
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = call ptr @__olang_region_or(ptr %t68, ptr null)
  %t70 = icmp ne ptr %t69, null
  %t71 = select i1 %t70, ptr %t69, ptr %t64
  %t72 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 0
  %t73 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t72, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = call ptr @__olang_region_or(ptr %t75, ptr null)
  %t77 = icmp ne ptr %t76, null
  %t78 = select i1 %t77, ptr %t76, ptr %t71
  %t79 = getelementptr %"compiler/facts:Table", ptr %l74, i32 0, i32 0
  %t80 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t79, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = call ptr @__olang_region_or(ptr %t82, ptr null)
  %t84 = icmp ne ptr %t83, null
  %t85 = select i1 %t84, ptr %t83, ptr %t78
  %t86 = icmp eq ptr %t85, %t22
  call void @__olang_region_settle(ptr %t22, i1 %t86)
  br label %bb6
bb6:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l74, i64 232, i1 false)
  %t87 = ptrtoint ptr %v2 to i64
  store i64 %t87, ptr %l76, !tbaa !24
  %t88 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e4
  br i1 %t88, label %bb7, label %bb8
bb7:
  %t90 = call ptr @__olang_region_make(ptr %v2)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l76, !tbaa !24
  br label %bb8
bb8:
  %t92 = load i64, ptr %l76
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e(ptr %t93)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t94, ptr %l78
  br label %bb9
bb9:
  %t95 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e4
  br i1 %t95, label %bb10, label %bb11
bb10:
  %t97 = load i64, ptr %l76
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l78, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %t99
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = call ptr @__olang_region_or(ptr %t101, ptr null)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr null
  %t105 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l78, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = call ptr @__olang_region_or(ptr %t107, ptr null)
  %t109 = icmp ne ptr %t108, null
  %t110 = select i1 %t109, ptr %t108, ptr %t104
  %t111 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l78, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = call ptr @__olang_region_or(ptr %t113, ptr null)
  %t115 = icmp ne ptr %t114, null
  %t116 = select i1 %t115, ptr %t114, ptr %t110
  %t117 = icmp eq ptr %t116, %t98
  call void @__olang_region_settle(ptr %t98, i1 %t117)
  br label %bb11
bb11:
  %t118 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l78
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t118, ptr %l6
  %t119 = ptrtoint ptr %v2 to i64
  store i64 %t119, ptr %l80, !tbaa !24
  %t120 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e5
  br i1 %t120, label %bb12, label %bb13
bb12:
  %t122 = call ptr @__olang_region_make(ptr %v2)
  %t123 = ptrtoint ptr %t122 to i64
  store i64 %t123, ptr %l80, !tbaa !24
  br label %bb13
bb13:
  %t124 = load i64, ptr %l80
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_3e(ptr %t125)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t126, ptr %l82
  br label %bb14
bb14:
  %t127 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e5
  br i1 %t127, label %bb15, label %bb16
bb15:
  %t129 = load i64, ptr %l80
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l82, i32 0, i32 2
  %t132 = load { i64, ptr }, ptr %t131
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = call ptr @__olang_region_or(ptr %t133, ptr null)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, ptr %t134, ptr null
  %t137 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l82, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = call ptr @__olang_region_or(ptr %t139, ptr null)
  %t141 = icmp ne ptr %t140, null
  %t142 = select i1 %t141, ptr %t140, ptr %t136
  %t143 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l82, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = call ptr @__olang_region_or(ptr %t145, ptr null)
  %t147 = icmp ne ptr %t146, null
  %t148 = select i1 %t147, ptr %t146, ptr %t142
  %t149 = icmp eq ptr %t148, %t130
  call void @__olang_region_settle(ptr %t130, i1 %t149)
  br label %bb16
bb16:
  %t150 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l82
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t150, ptr %l7
  %t151 = ptrtoint ptr %v2 to i64
  store i64 %t151, ptr %l84, !tbaa !24
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e6
  br i1 %t152, label %bb17, label %bb18
bb17:
  %t154 = call ptr @__olang_region_make(ptr %v2)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l84, !tbaa !24
  br label %bb18
bb18:
  %t156 = load i64, ptr %l84
  %t157 = inttoptr i64 %t156 to ptr
  %t158 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_3e(ptr %t157)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t158, ptr %l86
  br label %bb19
bb19:
  %t159 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e6
  br i1 %t159, label %bb20, label %bb21
bb20:
  %t161 = load i64, ptr %l84
  %t162 = inttoptr i64 %t161 to ptr
  %t163 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86, i32 0, i32 2
  %t164 = load { i64, ptr }, ptr %t163
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = call ptr @__olang_region_or(ptr %t165, ptr null)
  %t167 = icmp ne ptr %t166, null
  %t168 = select i1 %t167, ptr %t166, ptr null
  %t169 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86, i32 0, i32 1
  %t170 = load { i64, ptr }, ptr %t169
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = call ptr @__olang_region_or(ptr %t171, ptr null)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, ptr %t172, ptr %t168
  %t175 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86, i32 0, i32 0
  %t176 = load { i64, ptr }, ptr %t175
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = call ptr @__olang_region_or(ptr %t177, ptr null)
  %t179 = icmp ne ptr %t178, null
  %t180 = select i1 %t179, ptr %t178, ptr %t174
  %t181 = icmp eq ptr %t180, %t162
  call void @__olang_region_settle(ptr %t162, i1 %t181)
  br label %bb21
bb21:
  %t182 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t182, ptr %l8
  %t183 = ptrtoint ptr %v2 to i64
  store i64 %t183, ptr %l88, !tbaa !24
  %t184 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e7
  br i1 %t184, label %bb22, label %bb23
bb22:
  %t186 = call ptr @__olang_region_make(ptr %v2)
  %t187 = ptrtoint ptr %t186 to i64
  store i64 %t187, ptr %l88, !tbaa !24
  br label %bb23
bb23:
  %t188 = load i64, ptr %l88
  %t189 = inttoptr i64 %t188 to ptr
  %t190 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e(ptr %t189)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t190, ptr %l90
  br label %bb24
bb24:
  %t191 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e7
  br i1 %t191, label %bb25, label %bb26
bb25:
  %t193 = load i64, ptr %l88
  %t194 = inttoptr i64 %t193 to ptr
  %t195 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l90, i32 0, i32 2
  %t196 = load { i64, ptr }, ptr %t195
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = call ptr @__olang_region_or(ptr %t197, ptr null)
  %t199 = icmp ne ptr %t198, null
  %t200 = select i1 %t199, ptr %t198, ptr null
  %t201 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l90, i32 0, i32 1
  %t202 = load { i64, ptr }, ptr %t201
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = call ptr @__olang_region_or(ptr %t203, ptr null)
  %t205 = icmp ne ptr %t204, null
  %t206 = select i1 %t205, ptr %t204, ptr %t200
  %t207 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l90, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr %t206
  %t213 = icmp eq ptr %t212, %t194
  call void @__olang_region_settle(ptr %t194, i1 %t213)
  br label %bb26
bb26:
  %t214 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l90
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t214, ptr %l9
  %t215 = ptrtoint ptr %v2 to i64
  store i64 %t215, ptr %l92, !tbaa !24
  %t216 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e8
  br i1 %t216, label %bb27, label %bb28
bb27:
  %t218 = call ptr @__olang_region_make(ptr %v2)
  %t219 = ptrtoint ptr %t218 to i64
  store i64 %t219, ptr %l92, !tbaa !24
  br label %bb28
bb28:
  %t220 = load i64, ptr %l92
  %t221 = inttoptr i64 %t220 to ptr
  %t222 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t221, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t222, ptr %l94
  br label %bb29
bb29:
  %t223 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e8
  br i1 %t223, label %bb30, label %bb31
bb30:
  %t225 = load i64, ptr %l92
  %t226 = inttoptr i64 %t225 to ptr
  %t227 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227
  %t229 = extractvalue { i64, ptr } %t228, 1
  %t230 = call ptr @__olang_region_or(ptr %t229, ptr null)
  %t231 = icmp ne ptr %t230, null
  %t232 = select i1 %t231, ptr %t230, ptr null
  %t233 = icmp eq ptr %t232, %t226
  call void @__olang_region_settle(ptr %t226, i1 %t233)
  br label %bb31
bb31:
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l10
  %t235 = ptrtoint ptr %v2 to i64
  store i64 %t235, ptr %l96, !tbaa !24
  %t236 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e9
  br i1 %t236, label %bb32, label %bb33
bb32:
  %t238 = call ptr @__olang_region_make(ptr %v2)
  %t239 = ptrtoint ptr %t238 to i64
  store i64 %t239, ptr %l96, !tbaa !24
  br label %bb33
bb33:
  %t240 = load i64, ptr %l96
  %t241 = inttoptr i64 %t240 to ptr
  %t242 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e(ptr %t241)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t242, ptr %l98
  br label %bb34
bb34:
  %t243 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e9
  br i1 %t243, label %bb35, label %bb36
bb35:
  %t245 = load i64, ptr %l96
  %t246 = inttoptr i64 %t245 to ptr
  %t247 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 2
  %t248 = load { i64, ptr }, ptr %t247
  %t249 = extractvalue { i64, ptr } %t248, 1
  %t250 = call ptr @__olang_region_or(ptr %t249, ptr null)
  %t251 = icmp ne ptr %t250, null
  %t252 = select i1 %t251, ptr %t250, ptr null
  %t253 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 1
  %t254 = load { i64, ptr }, ptr %t253
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = call ptr @__olang_region_or(ptr %t255, ptr null)
  %t257 = icmp ne ptr %t256, null
  %t258 = select i1 %t257, ptr %t256, ptr %t252
  %t259 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 0
  %t260 = load { i64, ptr }, ptr %t259
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = call ptr @__olang_region_or(ptr %t261, ptr null)
  %t263 = icmp ne ptr %t262, null
  %t264 = select i1 %t263, ptr %t262, ptr %t258
  %t265 = icmp eq ptr %t264, %t246
  call void @__olang_region_settle(ptr %t246, i1 %t265)
  br label %bb36
bb36:
  %t266 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t266, ptr %l11
  %t267 = ptrtoint ptr %v2 to i64
  store i64 %t267, ptr %l100, !tbaa !24
  %t268 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e10
  br i1 %t268, label %bb37, label %bb38
bb37:
  %t270 = call ptr @__olang_region_make(ptr %v2)
  %t271 = ptrtoint ptr %t270 to i64
  store i64 %t271, ptr %l100, !tbaa !24
  br label %bb38
bb38:
  %t272 = load i64, ptr %l100
  %t273 = inttoptr i64 %t272 to ptr
  %t274 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e(ptr %t273)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t274, ptr %l102
  br label %bb39
bb39:
  %t275 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e10
  br i1 %t275, label %bb40, label %bb41
bb40:
  %t277 = load i64, ptr %l100
  %t278 = inttoptr i64 %t277 to ptr
  %t279 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102, i32 0, i32 2
  %t280 = load { i64, ptr }, ptr %t279
  %t281 = extractvalue { i64, ptr } %t280, 1
  %t282 = call ptr @__olang_region_or(ptr %t281, ptr null)
  %t283 = icmp ne ptr %t282, null
  %t284 = select i1 %t283, ptr %t282, ptr null
  %t285 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102, i32 0, i32 1
  %t286 = load { i64, ptr }, ptr %t285
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = call ptr @__olang_region_or(ptr %t287, ptr null)
  %t289 = icmp ne ptr %t288, null
  %t290 = select i1 %t289, ptr %t288, ptr %t284
  %t291 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102, i32 0, i32 0
  %t292 = load { i64, ptr }, ptr %t291
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = call ptr @__olang_region_or(ptr %t293, ptr null)
  %t295 = icmp ne ptr %t294, null
  %t296 = select i1 %t295, ptr %t294, ptr %t290
  %t297 = icmp eq ptr %t296, %t278
  call void @__olang_region_settle(ptr %t278, i1 %t297)
  br label %bb41
bb41:
  %t298 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t298, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  %t299 = ptrtoint ptr %v2 to i64
  store i64 %t299, ptr %l104, !tbaa !24
  %t300 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e12
  br i1 %t300, label %bb42, label %bb43
bb42:
  %t302 = call ptr @__olang_region_make(ptr %v2)
  %t303 = ptrtoint ptr %t302 to i64
  store i64 %t303, ptr %l104, !tbaa !24
  br label %bb43
bb43:
  %t304 = load i64, ptr %l104
  %t305 = inttoptr i64 %t304 to ptr
  %t306 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t305, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %l106
  br label %bb44
bb44:
  %t307 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e12
  br i1 %t307, label %bb45, label %bb46
bb45:
  %t309 = load i64, ptr %l104
  %t310 = inttoptr i64 %t309 to ptr
  %t311 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106, i32 0, i32 0
  %t312 = load { i64, ptr }, ptr %t311
  %t313 = extractvalue { i64, ptr } %t312, 1
  %t314 = call ptr @__olang_region_or(ptr %t313, ptr null)
  %t315 = icmp ne ptr %t314, null
  %t316 = select i1 %t315, ptr %t314, ptr null
  %t317 = icmp eq ptr %t316, %t310
  call void @__olang_region_settle(ptr %t310, i1 %t317)
  br label %bb46
bb46:
  %t318 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t318, ptr %l14
  %t319 = ptrtoint ptr %v2 to i64
  store i64 %t319, ptr %l108, !tbaa !24
  %t320 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e13
  br i1 %t320, label %bb47, label %bb48
bb47:
  %t322 = call ptr @__olang_region_make(ptr %v2)
  %t323 = ptrtoint ptr %t322 to i64
  store i64 %t323, ptr %l108, !tbaa !24
  br label %bb48
bb48:
  %t324 = load i64, ptr %l108
  %t325 = inttoptr i64 %t324 to ptr
  %t326 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t325, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t326, ptr %l110
  br label %bb49
bb49:
  %t327 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e13
  br i1 %t327, label %bb50, label %bb51
bb50:
  %t329 = load i64, ptr %l108
  %t330 = inttoptr i64 %t329 to ptr
  %t331 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110, i32 0, i32 0
  %t332 = load { i64, ptr }, ptr %t331
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = call ptr @__olang_region_or(ptr %t333, ptr null)
  %t335 = icmp ne ptr %t334, null
  %t336 = select i1 %t335, ptr %t334, ptr null
  %t337 = icmp eq ptr %t336, %t330
  call void @__olang_region_settle(ptr %t330, i1 %t337)
  br label %bb51
bb51:
  %t338 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t338, ptr %l15
  %t339 = ptrtoint ptr %v2 to i64
  store i64 %t339, ptr %l112, !tbaa !24
  %t340 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e14
  br i1 %t340, label %bb52, label %bb53
bb52:
  %t342 = call ptr @__olang_region_make(ptr %v2)
  %t343 = ptrtoint ptr %t342 to i64
  store i64 %t343, ptr %l112, !tbaa !24
  br label %bb53
bb53:
  %t344 = load i64, ptr %l112
  %t345 = inttoptr i64 %t344 to ptr
  %t346 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t345)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t346, ptr %l114
  br label %bb54
bb54:
  %t347 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e14
  br i1 %t347, label %bb55, label %bb56
bb55:
  %t349 = load i64, ptr %l112
  %t350 = inttoptr i64 %t349 to ptr
  %t351 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l114, i32 0, i32 2
  %t352 = load { i64, ptr }, ptr %t351
  %t353 = extractvalue { i64, ptr } %t352, 1
  %t354 = call ptr @__olang_region_or(ptr %t353, ptr null)
  %t355 = icmp ne ptr %t354, null
  %t356 = select i1 %t355, ptr %t354, ptr null
  %t357 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l114, i32 0, i32 1
  %t358 = load { i64, ptr }, ptr %t357
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = call ptr @__olang_region_or(ptr %t359, ptr null)
  %t361 = icmp ne ptr %t360, null
  %t362 = select i1 %t361, ptr %t360, ptr %t356
  %t363 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l114, i32 0, i32 0
  %t364 = load { i64, ptr }, ptr %t363
  %t365 = extractvalue { i64, ptr } %t364, 1
  %t366 = call ptr @__olang_region_or(ptr %t365, ptr null)
  %t367 = icmp ne ptr %t366, null
  %t368 = select i1 %t367, ptr %t366, ptr %t362
  %t369 = icmp eq ptr %t368, %t350
  call void @__olang_region_settle(ptr %t350, i1 %t369)
  br label %bb56
bb56:
  %t370 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l114
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t370, ptr %l16
  %t371 = ptrtoint ptr %v2 to i64
  store i64 %t371, ptr %l116, !tbaa !24
  %t372 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e15
  br i1 %t372, label %bb57, label %bb58
bb57:
  %t374 = call ptr @__olang_region_make(ptr %v2)
  %t375 = ptrtoint ptr %t374 to i64
  store i64 %t375, ptr %l116, !tbaa !24
  br label %bb58
bb58:
  %t376 = load i64, ptr %l116
  %t377 = inttoptr i64 %t376 to ptr
  %t378 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t377)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t378, ptr %l118
  br label %bb59
bb59:
  %t379 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e15
  br i1 %t379, label %bb60, label %bb61
bb60:
  %t381 = load i64, ptr %l116
  %t382 = inttoptr i64 %t381 to ptr
  %t383 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l118, i32 0, i32 2
  %t384 = load { i64, ptr }, ptr %t383
  %t385 = extractvalue { i64, ptr } %t384, 1
  %t386 = call ptr @__olang_region_or(ptr %t385, ptr null)
  %t387 = icmp ne ptr %t386, null
  %t388 = select i1 %t387, ptr %t386, ptr null
  %t389 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l118, i32 0, i32 1
  %t390 = load { i64, ptr }, ptr %t389
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = call ptr @__olang_region_or(ptr %t391, ptr null)
  %t393 = icmp ne ptr %t392, null
  %t394 = select i1 %t393, ptr %t392, ptr %t388
  %t395 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l118, i32 0, i32 0
  %t396 = load { i64, ptr }, ptr %t395
  %t397 = extractvalue { i64, ptr } %t396, 1
  %t398 = call ptr @__olang_region_or(ptr %t397, ptr null)
  %t399 = icmp ne ptr %t398, null
  %t400 = select i1 %t399, ptr %t398, ptr %t394
  %t401 = icmp eq ptr %t400, %t382
  call void @__olang_region_settle(ptr %t382, i1 %t401)
  br label %bb61
bb61:
  %t402 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l118
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t402, ptr %l17
  %t403 = ptrtoint ptr %v2 to i64
  store i64 %t403, ptr %l120, !tbaa !24
  %t404 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e16
  br i1 %t404, label %bb62, label %bb63
bb62:
  %t406 = call ptr @__olang_region_make(ptr %v2)
  %t407 = ptrtoint ptr %t406 to i64
  store i64 %t407, ptr %l120, !tbaa !24
  br label %bb63
bb63:
  %t408 = load i64, ptr %l120
  %t409 = inttoptr i64 %t408 to ptr
  %t410 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2ector(ptr %t409, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t410, ptr %l122
  br label %bb64
bb64:
  %t411 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e16
  br i1 %t411, label %bb65, label %bb66
bb65:
  %t413 = load i64, ptr %l120
  %t414 = inttoptr i64 %t413 to ptr
  %t415 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122, i32 0, i32 0
  %t416 = load { i64, ptr }, ptr %t415
  %t417 = extractvalue { i64, ptr } %t416, 1
  %t418 = call ptr @__olang_region_or(ptr %t417, ptr null)
  %t419 = icmp ne ptr %t418, null
  %t420 = select i1 %t419, ptr %t418, ptr null
  %t421 = icmp eq ptr %t420, %t414
  call void @__olang_region_settle(ptr %t414, i1 %t421)
  br label %bb66
bb66:
  %t422 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t422, ptr %l18
  %t423 = ptrtoint ptr %v2 to i64
  store i64 %t423, ptr %l124, !tbaa !24
  %t424 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e17
  br i1 %t424, label %bb67, label %bb68
bb67:
  %t426 = call ptr @__olang_region_make(ptr %v2)
  %t427 = ptrtoint ptr %t426 to i64
  store i64 %t427, ptr %l124, !tbaa !24
  br label %bb68
bb68:
  %t428 = load i64, ptr %l124
  %t429 = inttoptr i64 %t428 to ptr
  %t430 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t429)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t430, ptr %l126
  br label %bb69
bb69:
  %t431 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e17
  br i1 %t431, label %bb70, label %bb71
bb70:
  %t433 = load i64, ptr %l124
  %t434 = inttoptr i64 %t433 to ptr
  %t435 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l126, i32 0, i32 2
  %t436 = load { i64, ptr }, ptr %t435
  %t437 = extractvalue { i64, ptr } %t436, 1
  %t438 = call ptr @__olang_region_or(ptr %t437, ptr null)
  %t439 = icmp ne ptr %t438, null
  %t440 = select i1 %t439, ptr %t438, ptr null
  %t441 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l126, i32 0, i32 1
  %t442 = load { i64, ptr }, ptr %t441
  %t443 = extractvalue { i64, ptr } %t442, 1
  %t444 = call ptr @__olang_region_or(ptr %t443, ptr null)
  %t445 = icmp ne ptr %t444, null
  %t446 = select i1 %t445, ptr %t444, ptr %t440
  %t447 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l126, i32 0, i32 0
  %t448 = load { i64, ptr }, ptr %t447
  %t449 = extractvalue { i64, ptr } %t448, 1
  %t450 = call ptr @__olang_region_or(ptr %t449, ptr null)
  %t451 = icmp ne ptr %t450, null
  %t452 = select i1 %t451, ptr %t450, ptr %t446
  %t453 = icmp eq ptr %t452, %t434
  call void @__olang_region_settle(ptr %t434, i1 %t453)
  br label %bb71
bb71:
  %t454 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l126
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t454, ptr %l19
  %t455 = ptrtoint ptr %v2 to i64
  store i64 %t455, ptr %l128, !tbaa !24
  %t456 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e18
  br i1 %t456, label %bb72, label %bb73
bb72:
  %t458 = call ptr @__olang_region_make(ptr %v2)
  %t459 = ptrtoint ptr %t458 to i64
  store i64 %t459, ptr %l128, !tbaa !24
  br label %bb73
bb73:
  %t460 = load i64, ptr %l128
  %t461 = inttoptr i64 %t460 to ptr
  %t462 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t461)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t462, ptr %l130
  br label %bb74
bb74:
  %t463 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e18
  br i1 %t463, label %bb75, label %bb76
bb75:
  %t465 = load i64, ptr %l128
  %t466 = inttoptr i64 %t465 to ptr
  %t467 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l130, i32 0, i32 2
  %t468 = load { i64, ptr }, ptr %t467
  %t469 = extractvalue { i64, ptr } %t468, 1
  %t470 = call ptr @__olang_region_or(ptr %t469, ptr null)
  %t471 = icmp ne ptr %t470, null
  %t472 = select i1 %t471, ptr %t470, ptr null
  %t473 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l130, i32 0, i32 1
  %t474 = load { i64, ptr }, ptr %t473
  %t475 = extractvalue { i64, ptr } %t474, 1
  %t476 = call ptr @__olang_region_or(ptr %t475, ptr null)
  %t477 = icmp ne ptr %t476, null
  %t478 = select i1 %t477, ptr %t476, ptr %t472
  %t479 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l130, i32 0, i32 0
  %t480 = load { i64, ptr }, ptr %t479
  %t481 = extractvalue { i64, ptr } %t480, 1
  %t482 = call ptr @__olang_region_or(ptr %t481, ptr null)
  %t483 = icmp ne ptr %t482, null
  %t484 = select i1 %t483, ptr %t482, ptr %t478
  %t485 = icmp eq ptr %t484, %t466
  call void @__olang_region_settle(ptr %t466, i1 %t485)
  br label %bb76
bb76:
  %t486 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l130
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t486, ptr %l20
  %t487 = ptrtoint ptr %v2 to i64
  store i64 %t487, ptr %l132, !tbaa !24
  %t488 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e19
  br i1 %t488, label %bb77, label %bb78
bb77:
  %t490 = call ptr @__olang_region_make(ptr %v2)
  %t491 = ptrtoint ptr %t490 to i64
  store i64 %t491, ptr %l132, !tbaa !24
  br label %bb78
bb78:
  %t492 = load i64, ptr %l132
  %t493 = inttoptr i64 %t492 to ptr
  %t494 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t493)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t494, ptr %l134
  br label %bb79
bb79:
  %t495 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e19
  br i1 %t495, label %bb80, label %bb81
bb80:
  %t497 = load i64, ptr %l132
  %t498 = inttoptr i64 %t497 to ptr
  %t499 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l134, i32 0, i32 2
  %t500 = load { i64, ptr }, ptr %t499
  %t501 = extractvalue { i64, ptr } %t500, 1
  %t502 = call ptr @__olang_region_or(ptr %t501, ptr null)
  %t503 = icmp ne ptr %t502, null
  %t504 = select i1 %t503, ptr %t502, ptr null
  %t505 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l134, i32 0, i32 1
  %t506 = load { i64, ptr }, ptr %t505
  %t507 = extractvalue { i64, ptr } %t506, 1
  %t508 = call ptr @__olang_region_or(ptr %t507, ptr null)
  %t509 = icmp ne ptr %t508, null
  %t510 = select i1 %t509, ptr %t508, ptr %t504
  %t511 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l134, i32 0, i32 0
  %t512 = load { i64, ptr }, ptr %t511
  %t513 = extractvalue { i64, ptr } %t512, 1
  %t514 = call ptr @__olang_region_or(ptr %t513, ptr null)
  %t515 = icmp ne ptr %t514, null
  %t516 = select i1 %t515, ptr %t514, ptr %t510
  %t517 = icmp eq ptr %t516, %t498
  call void @__olang_region_settle(ptr %t498, i1 %t517)
  br label %bb81
bb81:
  %t518 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l134
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t518, ptr %l21
  %t519 = ptrtoint ptr %v2 to i64
  store i64 %t519, ptr %l136, !tbaa !24
  %t520 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e20
  br i1 %t520, label %bb82, label %bb83
bb82:
  %t522 = call ptr @__olang_region_make(ptr %v2)
  %t523 = ptrtoint ptr %t522 to i64
  store i64 %t523, ptr %l136, !tbaa !24
  br label %bb83
bb83:
  %t524 = load i64, ptr %l136
  %t525 = inttoptr i64 %t524 to ptr
  %t526 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hf4514b6649a0255133072aa3e28fef27(ptr %t525)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t526, ptr %l138
  br label %bb84
bb84:
  %t527 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e20
  br i1 %t527, label %bb85, label %bb86
bb85:
  %t529 = load i64, ptr %l136
  %t530 = inttoptr i64 %t529 to ptr
  %t531 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l138, i32 0, i32 2
  %t532 = load { i64, ptr }, ptr %t531
  %t533 = extractvalue { i64, ptr } %t532, 1
  %t534 = call ptr @__olang_region_or(ptr %t533, ptr null)
  %t535 = icmp ne ptr %t534, null
  %t536 = select i1 %t535, ptr %t534, ptr null
  %t537 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l138, i32 0, i32 1
  %t538 = load { i64, ptr }, ptr %t537
  %t539 = extractvalue { i64, ptr } %t538, 1
  %t540 = call ptr @__olang_region_or(ptr %t539, ptr null)
  %t541 = icmp ne ptr %t540, null
  %t542 = select i1 %t541, ptr %t540, ptr %t536
  %t543 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l138, i32 0, i32 0
  %t544 = load { i64, ptr }, ptr %t543
  %t545 = extractvalue { i64, ptr } %t544, 1
  %t546 = call ptr @__olang_region_or(ptr %t545, ptr null)
  %t547 = icmp ne ptr %t546, null
  %t548 = select i1 %t547, ptr %t546, ptr %t542
  %t549 = icmp eq ptr %t548, %t530
  call void @__olang_region_settle(ptr %t530, i1 %t549)
  br label %bb86
bb86:
  %t550 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l138
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t550, ptr %l22
  %t551 = ptrtoint ptr %v2 to i64
  store i64 %t551, ptr %l140, !tbaa !24
  %t552 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e21
  br i1 %t552, label %bb87, label %bb88
bb87:
  %t554 = call ptr @__olang_region_make(ptr %v2)
  %t555 = ptrtoint ptr %t554 to i64
  store i64 %t555, ptr %l140, !tbaa !24
  br label %bb88
bb88:
  %t556 = load i64, ptr %l140
  %t557 = inttoptr i64 %t556 to ptr
  %t558 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__H50c0e2fd81a181d0fc73c1f447a09921(ptr %t557)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t558, ptr %l142
  br label %bb89
bb89:
  %t559 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e21
  br i1 %t559, label %bb90, label %bb91
bb90:
  %t561 = load i64, ptr %l140
  %t562 = inttoptr i64 %t561 to ptr
  %t563 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 2
  %t564 = load { i64, ptr }, ptr %t563
  %t565 = extractvalue { i64, ptr } %t564, 1
  %t566 = call ptr @__olang_region_or(ptr %t565, ptr null)
  %t567 = icmp ne ptr %t566, null
  %t568 = select i1 %t567, ptr %t566, ptr null
  %t569 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 1
  %t570 = load { i64, ptr }, ptr %t569
  %t571 = extractvalue { i64, ptr } %t570, 1
  %t572 = call ptr @__olang_region_or(ptr %t571, ptr null)
  %t573 = icmp ne ptr %t572, null
  %t574 = select i1 %t573, ptr %t572, ptr %t568
  %t575 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 0
  %t576 = load { i64, ptr }, ptr %t575
  %t577 = extractvalue { i64, ptr } %t576, 1
  %t578 = call ptr @__olang_region_or(ptr %t577, ptr null)
  %t579 = icmp ne ptr %t578, null
  %t580 = select i1 %t579, ptr %t578, ptr %t574
  %t581 = icmp eq ptr %t580, %t562
  call void @__olang_region_settle(ptr %t562, i1 %t581)
  br label %bb91
bb91:
  %t582 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t582, ptr %l23
  %t583 = ptrtoint ptr %v2 to i64
  store i64 %t583, ptr %l144, !tbaa !24
  %t584 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e22
  br i1 %t584, label %bb92, label %bb93
bb92:
  %t586 = call ptr @__olang_region_make(ptr %v2)
  %t587 = ptrtoint ptr %t586 to i64
  store i64 %t587, ptr %l144, !tbaa !24
  br label %bb93
bb93:
  %t588 = load i64, ptr %l144
  %t589 = inttoptr i64 %t588 to ptr
  %t590 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t589)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t590, ptr %l146
  br label %bb94
bb94:
  %t591 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e22
  br i1 %t591, label %bb95, label %bb96
bb95:
  %t593 = load i64, ptr %l144
  %t594 = inttoptr i64 %t593 to ptr
  %t595 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l146, i32 0, i32 2
  %t596 = load { i64, ptr }, ptr %t595
  %t597 = extractvalue { i64, ptr } %t596, 1
  %t598 = call ptr @__olang_region_or(ptr %t597, ptr null)
  %t599 = icmp ne ptr %t598, null
  %t600 = select i1 %t599, ptr %t598, ptr null
  %t601 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l146, i32 0, i32 1
  %t602 = load { i64, ptr }, ptr %t601
  %t603 = extractvalue { i64, ptr } %t602, 1
  %t604 = call ptr @__olang_region_or(ptr %t603, ptr null)
  %t605 = icmp ne ptr %t604, null
  %t606 = select i1 %t605, ptr %t604, ptr %t600
  %t607 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l146, i32 0, i32 0
  %t608 = load { i64, ptr }, ptr %t607
  %t609 = extractvalue { i64, ptr } %t608, 1
  %t610 = call ptr @__olang_region_or(ptr %t609, ptr null)
  %t611 = icmp ne ptr %t610, null
  %t612 = select i1 %t611, ptr %t610, ptr %t606
  %t613 = icmp eq ptr %t612, %t594
  call void @__olang_region_settle(ptr %t594, i1 %t613)
  br label %bb96
bb96:
  %t614 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l146
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t614, ptr %l24
  %t615 = ptrtoint ptr %v2 to i64
  store i64 %t615, ptr %l148, !tbaa !24
  %t616 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e23
  br i1 %t616, label %bb97, label %bb98
bb97:
  %t618 = call ptr @__olang_region_make(ptr %v2)
  %t619 = ptrtoint ptr %t618 to i64
  store i64 %t619, ptr %l148, !tbaa !24
  br label %bb98
bb98:
  %t620 = load i64, ptr %l148
  %t621 = inttoptr i64 %t620 to ptr
  %t622 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t621)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t622, ptr %l150
  br label %bb99
bb99:
  %t623 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e23
  br i1 %t623, label %bb100, label %bb101
bb100:
  %t625 = load i64, ptr %l148
  %t626 = inttoptr i64 %t625 to ptr
  %t627 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l150, i32 0, i32 2
  %t628 = load { i64, ptr }, ptr %t627
  %t629 = extractvalue { i64, ptr } %t628, 1
  %t630 = call ptr @__olang_region_or(ptr %t629, ptr null)
  %t631 = icmp ne ptr %t630, null
  %t632 = select i1 %t631, ptr %t630, ptr null
  %t633 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l150, i32 0, i32 1
  %t634 = load { i64, ptr }, ptr %t633
  %t635 = extractvalue { i64, ptr } %t634, 1
  %t636 = call ptr @__olang_region_or(ptr %t635, ptr null)
  %t637 = icmp ne ptr %t636, null
  %t638 = select i1 %t637, ptr %t636, ptr %t632
  %t639 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l150, i32 0, i32 0
  %t640 = load { i64, ptr }, ptr %t639
  %t641 = extractvalue { i64, ptr } %t640, 1
  %t642 = call ptr @__olang_region_or(ptr %t641, ptr null)
  %t643 = icmp ne ptr %t642, null
  %t644 = select i1 %t643, ptr %t642, ptr %t638
  %t645 = icmp eq ptr %t644, %t626
  call void @__olang_region_settle(ptr %t626, i1 %t645)
  br label %bb101
bb101:
  %t646 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l150
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t646, ptr %l25
  %t647 = ptrtoint ptr %v2 to i64
  store i64 %t647, ptr %l152, !tbaa !24
  %t648 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e24
  br i1 %t648, label %bb102, label %bb103
bb102:
  %t650 = call ptr @__olang_region_make(ptr %v2)
  %t651 = ptrtoint ptr %t650 to i64
  store i64 %t651, ptr %l152, !tbaa !24
  br label %bb103
bb103:
  %t652 = load i64, ptr %l152
  %t653 = inttoptr i64 %t652 to ptr
  %t654 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t653)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t654, ptr %l154
  br label %bb104
bb104:
  %t655 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e24
  br i1 %t655, label %bb105, label %bb106
bb105:
  %t657 = load i64, ptr %l152
  %t658 = inttoptr i64 %t657 to ptr
  %t659 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l154, i32 0, i32 2
  %t660 = load { i64, ptr }, ptr %t659
  %t661 = extractvalue { i64, ptr } %t660, 1
  %t662 = call ptr @__olang_region_or(ptr %t661, ptr null)
  %t663 = icmp ne ptr %t662, null
  %t664 = select i1 %t663, ptr %t662, ptr null
  %t665 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l154, i32 0, i32 1
  %t666 = load { i64, ptr }, ptr %t665
  %t667 = extractvalue { i64, ptr } %t666, 1
  %t668 = call ptr @__olang_region_or(ptr %t667, ptr null)
  %t669 = icmp ne ptr %t668, null
  %t670 = select i1 %t669, ptr %t668, ptr %t664
  %t671 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l154, i32 0, i32 0
  %t672 = load { i64, ptr }, ptr %t671
  %t673 = extractvalue { i64, ptr } %t672, 1
  %t674 = call ptr @__olang_region_or(ptr %t673, ptr null)
  %t675 = icmp ne ptr %t674, null
  %t676 = select i1 %t675, ptr %t674, ptr %t670
  %t677 = icmp eq ptr %t676, %t658
  call void @__olang_region_settle(ptr %t658, i1 %t677)
  br label %bb106
bb106:
  %t678 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l154
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t678, ptr %l26
  %t679 = ptrtoint ptr %v2 to i64
  store i64 %t679, ptr %l156, !tbaa !24
  %t680 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e25
  br i1 %t680, label %bb107, label %bb108
bb107:
  %t682 = call ptr @__olang_region_make(ptr %v2)
  %t683 = ptrtoint ptr %t682 to i64
  store i64 %t683, ptr %l156, !tbaa !24
  br label %bb108
bb108:
  %t684 = load i64, ptr %l156
  %t685 = inttoptr i64 %t684 to ptr
  %t686 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t685)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t686, ptr %l158
  br label %bb109
bb109:
  %t687 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e25
  br i1 %t687, label %bb110, label %bb111
bb110:
  %t689 = load i64, ptr %l156
  %t690 = inttoptr i64 %t689 to ptr
  %t691 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l158, i32 0, i32 2
  %t692 = load { i64, ptr }, ptr %t691
  %t693 = extractvalue { i64, ptr } %t692, 1
  %t694 = call ptr @__olang_region_or(ptr %t693, ptr null)
  %t695 = icmp ne ptr %t694, null
  %t696 = select i1 %t695, ptr %t694, ptr null
  %t697 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l158, i32 0, i32 1
  %t698 = load { i64, ptr }, ptr %t697
  %t699 = extractvalue { i64, ptr } %t698, 1
  %t700 = call ptr @__olang_region_or(ptr %t699, ptr null)
  %t701 = icmp ne ptr %t700, null
  %t702 = select i1 %t701, ptr %t700, ptr %t696
  %t703 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l158, i32 0, i32 0
  %t704 = load { i64, ptr }, ptr %t703
  %t705 = extractvalue { i64, ptr } %t704, 1
  %t706 = call ptr @__olang_region_or(ptr %t705, ptr null)
  %t707 = icmp ne ptr %t706, null
  %t708 = select i1 %t707, ptr %t706, ptr %t702
  %t709 = icmp eq ptr %t708, %t690
  call void @__olang_region_settle(ptr %t690, i1 %t709)
  br label %bb111
bb111:
  %t710 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l158
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t710, ptr %l27
  %t711 = ptrtoint ptr %v2 to i64
  store i64 %t711, ptr %l160, !tbaa !24
  %t712 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e26
  br i1 %t712, label %bb112, label %bb113
bb112:
  %t714 = call ptr @__olang_region_make(ptr %v2)
  %t715 = ptrtoint ptr %t714 to i64
  store i64 %t715, ptr %l160, !tbaa !24
  br label %bb113
bb113:
  %t716 = load i64, ptr %l160
  %t717 = inttoptr i64 %t716 to ptr
  %t718 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t717)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t718, ptr %l162
  br label %bb114
bb114:
  %t719 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e26
  br i1 %t719, label %bb115, label %bb116
bb115:
  %t721 = load i64, ptr %l160
  %t722 = inttoptr i64 %t721 to ptr
  %t723 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l162, i32 0, i32 2
  %t724 = load { i64, ptr }, ptr %t723
  %t725 = extractvalue { i64, ptr } %t724, 1
  %t726 = call ptr @__olang_region_or(ptr %t725, ptr null)
  %t727 = icmp ne ptr %t726, null
  %t728 = select i1 %t727, ptr %t726, ptr null
  %t729 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l162, i32 0, i32 1
  %t730 = load { i64, ptr }, ptr %t729
  %t731 = extractvalue { i64, ptr } %t730, 1
  %t732 = call ptr @__olang_region_or(ptr %t731, ptr null)
  %t733 = icmp ne ptr %t732, null
  %t734 = select i1 %t733, ptr %t732, ptr %t728
  %t735 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l162, i32 0, i32 0
  %t736 = load { i64, ptr }, ptr %t735
  %t737 = extractvalue { i64, ptr } %t736, 1
  %t738 = call ptr @__olang_region_or(ptr %t737, ptr null)
  %t739 = icmp ne ptr %t738, null
  %t740 = select i1 %t739, ptr %t738, ptr %t734
  %t741 = icmp eq ptr %t740, %t722
  call void @__olang_region_settle(ptr %t722, i1 %t741)
  br label %bb116
bb116:
  %t742 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l162
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t742, ptr %l28
  store i64 0, ptr %l29, !tbaa !24
  %t743 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t743, ptr %l164
  br label %bb117
bb117:
  %t744 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l164
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t744, ptr %l30
  %t745 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t745, ptr %l165
  br label %bb118
bb118:
  %t746 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l165
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t746, ptr %l31
  %t747 = ptrtoint ptr %v2 to i64
  store i64 %t747, ptr %l166, !tbaa !24
  %t748 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e30
  br i1 %t748, label %bb119, label %bb120
bb119:
  %t750 = call ptr @__olang_region_make(ptr %v2)
  %t751 = ptrtoint ptr %t750 to i64
  store i64 %t751, ptr %l166, !tbaa !24
  br label %bb120
bb120:
  %t752 = load i64, ptr %l166
  %t753 = inttoptr i64 %t752 to ptr
  %t754 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t753)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t754, ptr %l168
  br label %bb121
bb121:
  %t755 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e30
  br i1 %t755, label %bb122, label %bb123
bb122:
  %t757 = load i64, ptr %l166
  %t758 = inttoptr i64 %t757 to ptr
  %t759 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l168, i32 0, i32 2
  %t760 = load { i64, ptr }, ptr %t759
  %t761 = extractvalue { i64, ptr } %t760, 1
  %t762 = call ptr @__olang_region_or(ptr %t761, ptr null)
  %t763 = icmp ne ptr %t762, null
  %t764 = select i1 %t763, ptr %t762, ptr null
  %t765 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l168, i32 0, i32 1
  %t766 = load { i64, ptr }, ptr %t765
  %t767 = extractvalue { i64, ptr } %t766, 1
  %t768 = call ptr @__olang_region_or(ptr %t767, ptr null)
  %t769 = icmp ne ptr %t768, null
  %t770 = select i1 %t769, ptr %t768, ptr %t764
  %t771 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l168, i32 0, i32 0
  %t772 = load { i64, ptr }, ptr %t771
  %t773 = extractvalue { i64, ptr } %t772, 1
  %t774 = call ptr @__olang_region_or(ptr %t773, ptr null)
  %t775 = icmp ne ptr %t774, null
  %t776 = select i1 %t775, ptr %t774, ptr %t770
  %t777 = icmp eq ptr %t776, %t758
  call void @__olang_region_settle(ptr %t758, i1 %t777)
  br label %bb123
bb123:
  %t778 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l168
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t778, ptr %l32
  %t779 = ptrtoint ptr %v2 to i64
  store i64 %t779, ptr %l170, !tbaa !24
  %t780 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e31
  br i1 %t780, label %bb124, label %bb125
bb124:
  %t782 = call ptr @__olang_region_make(ptr %v2)
  %t783 = ptrtoint ptr %t782 to i64
  store i64 %t783, ptr %l170, !tbaa !24
  br label %bb125
bb125:
  %t784 = load i64, ptr %l170
  %t785 = inttoptr i64 %t784 to ptr
  %t786 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t785)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t786, ptr %l172
  br label %bb126
bb126:
  %t787 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e31
  br i1 %t787, label %bb127, label %bb128
bb127:
  %t789 = load i64, ptr %l170
  %t790 = inttoptr i64 %t789 to ptr
  %t791 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l172, i32 0, i32 2
  %t792 = load { i64, ptr }, ptr %t791
  %t793 = extractvalue { i64, ptr } %t792, 1
  %t794 = call ptr @__olang_region_or(ptr %t793, ptr null)
  %t795 = icmp ne ptr %t794, null
  %t796 = select i1 %t795, ptr %t794, ptr null
  %t797 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l172, i32 0, i32 1
  %t798 = load { i64, ptr }, ptr %t797
  %t799 = extractvalue { i64, ptr } %t798, 1
  %t800 = call ptr @__olang_region_or(ptr %t799, ptr null)
  %t801 = icmp ne ptr %t800, null
  %t802 = select i1 %t801, ptr %t800, ptr %t796
  %t803 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l172, i32 0, i32 0
  %t804 = load { i64, ptr }, ptr %t803
  %t805 = extractvalue { i64, ptr } %t804, 1
  %t806 = call ptr @__olang_region_or(ptr %t805, ptr null)
  %t807 = icmp ne ptr %t806, null
  %t808 = select i1 %t807, ptr %t806, ptr %t802
  %t809 = icmp eq ptr %t808, %t790
  call void @__olang_region_settle(ptr %t790, i1 %t809)
  br label %bb128
bb128:
  %t810 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l172
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t810, ptr %l33
  store i64 -1, ptr %l34, !tbaa !24
  %t811 = ptrtoint ptr %v2 to i64
  store i64 %t811, ptr %l174, !tbaa !24
  %t812 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e33
  br i1 %t812, label %bb129, label %bb130
bb129:
  %t814 = call ptr @__olang_region_make(ptr %v2)
  %t815 = ptrtoint ptr %t814 to i64
  store i64 %t815, ptr %l174, !tbaa !24
  br label %bb130
bb130:
  %t816 = load i64, ptr %l174
  %t817 = inttoptr i64 %t816 to ptr
  %t818 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e(ptr %t817)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t818, ptr %l176
  br label %bb131
bb131:
  %t819 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e33
  br i1 %t819, label %bb132, label %bb133
bb132:
  %t821 = load i64, ptr %l174
  %t822 = inttoptr i64 %t821 to ptr
  %t823 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 2
  %t824 = load { i64, ptr }, ptr %t823
  %t825 = extractvalue { i64, ptr } %t824, 1
  %t826 = call ptr @__olang_region_or(ptr %t825, ptr null)
  %t827 = icmp ne ptr %t826, null
  %t828 = select i1 %t827, ptr %t826, ptr null
  %t829 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 1
  %t830 = load { i64, ptr }, ptr %t829
  %t831 = extractvalue { i64, ptr } %t830, 1
  %t832 = call ptr @__olang_region_or(ptr %t831, ptr null)
  %t833 = icmp ne ptr %t832, null
  %t834 = select i1 %t833, ptr %t832, ptr %t828
  %t835 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176, i32 0, i32 0
  %t836 = load { i64, ptr }, ptr %t835
  %t837 = extractvalue { i64, ptr } %t836, 1
  %t838 = call ptr @__olang_region_or(ptr %t837, ptr null)
  %t839 = icmp ne ptr %t838, null
  %t840 = select i1 %t839, ptr %t838, ptr %t834
  %t841 = icmp eq ptr %t840, %t822
  call void @__olang_region_settle(ptr %t822, i1 %t841)
  br label %bb133
bb133:
  %t842 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l176
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t842, ptr %l35
  %t843 = ptrtoint ptr %v2 to i64
  store i64 %t843, ptr %l178, !tbaa !24
  %t844 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e34
  br i1 %t844, label %bb134, label %bb135
bb134:
  %t846 = call ptr @__olang_region_make(ptr %v2)
  %t847 = ptrtoint ptr %t846 to i64
  store i64 %t847, ptr %l178, !tbaa !24
  br label %bb135
bb135:
  %t848 = load i64, ptr %l178
  %t849 = inttoptr i64 %t848 to ptr
  %t850 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t849)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t850, ptr %l180
  br label %bb136
bb136:
  %t851 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e34
  br i1 %t851, label %bb137, label %bb138
bb137:
  %t853 = load i64, ptr %l178
  %t854 = inttoptr i64 %t853 to ptr
  %t855 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l180, i32 0, i32 2
  %t856 = load { i64, ptr }, ptr %t855
  %t857 = extractvalue { i64, ptr } %t856, 1
  %t858 = call ptr @__olang_region_or(ptr %t857, ptr null)
  %t859 = icmp ne ptr %t858, null
  %t860 = select i1 %t859, ptr %t858, ptr null
  %t861 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l180, i32 0, i32 1
  %t862 = load { i64, ptr }, ptr %t861
  %t863 = extractvalue { i64, ptr } %t862, 1
  %t864 = call ptr @__olang_region_or(ptr %t863, ptr null)
  %t865 = icmp ne ptr %t864, null
  %t866 = select i1 %t865, ptr %t864, ptr %t860
  %t867 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l180, i32 0, i32 0
  %t868 = load { i64, ptr }, ptr %t867
  %t869 = extractvalue { i64, ptr } %t868, 1
  %t870 = call ptr @__olang_region_or(ptr %t869, ptr null)
  %t871 = icmp ne ptr %t870, null
  %t872 = select i1 %t871, ptr %t870, ptr %t866
  %t873 = icmp eq ptr %t872, %t854
  call void @__olang_region_settle(ptr %t854, i1 %t873)
  br label %bb138
bb138:
  %t874 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l180
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t874, ptr %l36
  %t875 = ptrtoint ptr %v2 to i64
  store i64 %t875, ptr %l182, !tbaa !24
  %t876 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e35
  br i1 %t876, label %bb139, label %bb140
bb139:
  %t878 = call ptr @__olang_region_make(ptr %v2)
  %t879 = ptrtoint ptr %t878 to i64
  store i64 %t879, ptr %l182, !tbaa !24
  br label %bb140
bb140:
  %t880 = load i64, ptr %l182
  %t881 = inttoptr i64 %t880 to ptr
  %t882 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2ector(ptr %t881)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t882, ptr %l184
  br label %bb141
bb141:
  %t883 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e35
  br i1 %t883, label %bb142, label %bb143
bb142:
  %t885 = load i64, ptr %l182
  %t886 = inttoptr i64 %t885 to ptr
  %t887 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l184, i32 0, i32 2
  %t888 = load { i64, ptr }, ptr %t887
  %t889 = extractvalue { i64, ptr } %t888, 1
  %t890 = call ptr @__olang_region_or(ptr %t889, ptr null)
  %t891 = icmp ne ptr %t890, null
  %t892 = select i1 %t891, ptr %t890, ptr null
  %t893 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l184, i32 0, i32 1
  %t894 = load { i64, ptr }, ptr %t893
  %t895 = extractvalue { i64, ptr } %t894, 1
  %t896 = call ptr @__olang_region_or(ptr %t895, ptr null)
  %t897 = icmp ne ptr %t896, null
  %t898 = select i1 %t897, ptr %t896, ptr %t892
  %t899 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l184, i32 0, i32 0
  %t900 = load { i64, ptr }, ptr %t899
  %t901 = extractvalue { i64, ptr } %t900, 1
  %t902 = call ptr @__olang_region_or(ptr %t901, ptr null)
  %t903 = icmp ne ptr %t902, null
  %t904 = select i1 %t903, ptr %t902, ptr %t898
  %t905 = icmp eq ptr %t904, %t886
  call void @__olang_region_settle(ptr %t886, i1 %t905)
  br label %bb143
bb143:
  %t906 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l184
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t906, ptr %l37
  %t907 = ptrtoint ptr %v2 to i64
  store i64 %t907, ptr %l186, !tbaa !24
  %t908 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e36
  br i1 %t908, label %bb144, label %bb145
bb144:
  %t910 = call ptr @__olang_region_make(ptr %v2)
  %t911 = ptrtoint ptr %t910 to i64
  store i64 %t911, ptr %l186, !tbaa !24
  br label %bb145
bb145:
  %t912 = load i64, ptr %l186
  %t913 = inttoptr i64 %t912 to ptr
  %t914 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t913)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t914, ptr %l188
  br label %bb146
bb146:
  %t915 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e36
  br i1 %t915, label %bb147, label %bb148
bb147:
  %t917 = load i64, ptr %l186
  %t918 = inttoptr i64 %t917 to ptr
  %t919 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l188, i32 0, i32 2
  %t920 = load { i64, ptr }, ptr %t919
  %t921 = extractvalue { i64, ptr } %t920, 1
  %t922 = call ptr @__olang_region_or(ptr %t921, ptr null)
  %t923 = icmp ne ptr %t922, null
  %t924 = select i1 %t923, ptr %t922, ptr null
  %t925 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l188, i32 0, i32 1
  %t926 = load { i64, ptr }, ptr %t925
  %t927 = extractvalue { i64, ptr } %t926, 1
  %t928 = call ptr @__olang_region_or(ptr %t927, ptr null)
  %t929 = icmp ne ptr %t928, null
  %t930 = select i1 %t929, ptr %t928, ptr %t924
  %t931 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l188, i32 0, i32 0
  %t932 = load { i64, ptr }, ptr %t931
  %t933 = extractvalue { i64, ptr } %t932, 1
  %t934 = call ptr @__olang_region_or(ptr %t933, ptr null)
  %t935 = icmp ne ptr %t934, null
  %t936 = select i1 %t935, ptr %t934, ptr %t930
  %t937 = icmp eq ptr %t936, %t918
  call void @__olang_region_settle(ptr %t918, i1 %t937)
  br label %bb148
bb148:
  %t938 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l188
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t938, ptr %l38
  %t939 = ptrtoint ptr %v2 to i64
  store i64 %t939, ptr %l190, !tbaa !24
  %t940 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e37
  br i1 %t940, label %bb149, label %bb150
bb149:
  %t942 = call ptr @__olang_region_make(ptr %v2)
  %t943 = ptrtoint ptr %t942 to i64
  store i64 %t943, ptr %l190, !tbaa !24
  br label %bb150
bb150:
  %t944 = load i64, ptr %l190
  %t945 = inttoptr i64 %t944 to ptr
  %t946 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t945)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t946, ptr %l192
  br label %bb151
bb151:
  %t947 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e37
  br i1 %t947, label %bb152, label %bb153
bb152:
  %t949 = load i64, ptr %l190
  %t950 = inttoptr i64 %t949 to ptr
  %t951 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l192, i32 0, i32 2
  %t952 = load { i64, ptr }, ptr %t951
  %t953 = extractvalue { i64, ptr } %t952, 1
  %t954 = call ptr @__olang_region_or(ptr %t953, ptr null)
  %t955 = icmp ne ptr %t954, null
  %t956 = select i1 %t955, ptr %t954, ptr null
  %t957 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l192, i32 0, i32 1
  %t958 = load { i64, ptr }, ptr %t957
  %t959 = extractvalue { i64, ptr } %t958, 1
  %t960 = call ptr @__olang_region_or(ptr %t959, ptr null)
  %t961 = icmp ne ptr %t960, null
  %t962 = select i1 %t961, ptr %t960, ptr %t956
  %t963 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l192, i32 0, i32 0
  %t964 = load { i64, ptr }, ptr %t963
  %t965 = extractvalue { i64, ptr } %t964, 1
  %t966 = call ptr @__olang_region_or(ptr %t965, ptr null)
  %t967 = icmp ne ptr %t966, null
  %t968 = select i1 %t967, ptr %t966, ptr %t962
  %t969 = icmp eq ptr %t968, %t950
  call void @__olang_region_settle(ptr %t950, i1 %t969)
  br label %bb153
bb153:
  %t970 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l192
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t970, ptr %l39
  %t971 = ptrtoint ptr %v2 to i64
  store i64 %t971, ptr %l194, !tbaa !24
  %t972 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e38
  br i1 %t972, label %bb154, label %bb155
bb154:
  %t974 = call ptr @__olang_region_make(ptr %v2)
  %t975 = ptrtoint ptr %t974 to i64
  store i64 %t975, ptr %l194, !tbaa !24
  br label %bb155
bb155:
  %t976 = load i64, ptr %l194
  %t977 = inttoptr i64 %t976 to ptr
  %t978 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t977, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t978, ptr %l196
  br label %bb156
bb156:
  %t979 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e38
  br i1 %t979, label %bb157, label %bb158
bb157:
  %t981 = load i64, ptr %l194
  %t982 = inttoptr i64 %t981 to ptr
  %t983 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l196, i32 0, i32 0
  %t984 = load { i64, ptr }, ptr %t983
  %t985 = extractvalue { i64, ptr } %t984, 1
  %t986 = call ptr @__olang_region_or(ptr %t985, ptr null)
  %t987 = icmp ne ptr %t986, null
  %t988 = select i1 %t987, ptr %t986, ptr null
  %t989 = icmp eq ptr %t988, %t982
  call void @__olang_region_settle(ptr %t982, i1 %t989)
  br label %bb158
bb158:
  %t990 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l196
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t990, ptr %l40
  %t991 = ptrtoint ptr %v2 to i64
  store i64 %t991, ptr %l198, !tbaa !24
  %t992 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e39
  br i1 %t992, label %bb159, label %bb160
bb159:
  %t994 = call ptr @__olang_region_make(ptr %v2)
  %t995 = ptrtoint ptr %t994 to i64
  store i64 %t995, ptr %l198, !tbaa !24
  br label %bb160
bb160:
  %t996 = load i64, ptr %l198
  %t997 = inttoptr i64 %t996 to ptr
  %t998 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t997, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t998, ptr %l200
  br label %bb161
bb161:
  %t999 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e39
  br i1 %t999, label %bb162, label %bb163
bb162:
  %t1001 = load i64, ptr %l198
  %t1002 = inttoptr i64 %t1001 to ptr
  %t1003 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l200, i32 0, i32 0
  %t1004 = load { i64, ptr }, ptr %t1003
  %t1005 = extractvalue { i64, ptr } %t1004, 1
  %t1006 = call ptr @__olang_region_or(ptr %t1005, ptr null)
  %t1007 = icmp ne ptr %t1006, null
  %t1008 = select i1 %t1007, ptr %t1006, ptr null
  %t1009 = icmp eq ptr %t1008, %t1002
  call void @__olang_region_settle(ptr %t1002, i1 %t1009)
  br label %bb163
bb163:
  %t1010 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l200
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1010, ptr %l41
  %t1011 = ptrtoint ptr %v2 to i64
  store i64 %t1011, ptr %l202, !tbaa !24
  %t1012 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e40
  br i1 %t1012, label %bb164, label %bb165
bb164:
  %t1014 = call ptr @__olang_region_make(ptr %v2)
  %t1015 = ptrtoint ptr %t1014 to i64
  store i64 %t1015, ptr %l202, !tbaa !24
  br label %bb165
bb165:
  %t1016 = load i64, ptr %l202
  %t1017 = inttoptr i64 %t1016 to ptr
  %t1018 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t1017)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1018, ptr %l204
  br label %bb166
bb166:
  %t1019 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e40
  br i1 %t1019, label %bb167, label %bb168
bb167:
  %t1021 = load i64, ptr %l202
  %t1022 = inttoptr i64 %t1021 to ptr
  %t1023 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l204, i32 0, i32 2
  %t1024 = load { i64, ptr }, ptr %t1023
  %t1025 = extractvalue { i64, ptr } %t1024, 1
  %t1026 = call ptr @__olang_region_or(ptr %t1025, ptr null)
  %t1027 = icmp ne ptr %t1026, null
  %t1028 = select i1 %t1027, ptr %t1026, ptr null
  %t1029 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l204, i32 0, i32 1
  %t1030 = load { i64, ptr }, ptr %t1029
  %t1031 = extractvalue { i64, ptr } %t1030, 1
  %t1032 = call ptr @__olang_region_or(ptr %t1031, ptr null)
  %t1033 = icmp ne ptr %t1032, null
  %t1034 = select i1 %t1033, ptr %t1032, ptr %t1028
  %t1035 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l204, i32 0, i32 0
  %t1036 = load { i64, ptr }, ptr %t1035
  %t1037 = extractvalue { i64, ptr } %t1036, 1
  %t1038 = call ptr @__olang_region_or(ptr %t1037, ptr null)
  %t1039 = icmp ne ptr %t1038, null
  %t1040 = select i1 %t1039, ptr %t1038, ptr %t1034
  %t1041 = icmp eq ptr %t1040, %t1022
  call void @__olang_region_settle(ptr %t1022, i1 %t1041)
  br label %bb168
bb168:
  %t1042 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l204
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1042, ptr %l42
  %t1043 = ptrtoint ptr %v2 to i64
  store i64 %t1043, ptr %l206, !tbaa !24
  %t1044 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e41
  br i1 %t1044, label %bb169, label %bb170
bb169:
  %t1046 = call ptr @__olang_region_make(ptr %v2)
  %t1047 = ptrtoint ptr %t1046 to i64
  store i64 %t1047, ptr %l206, !tbaa !24
  br label %bb170
bb170:
  %t1048 = load i64, ptr %l206
  %t1049 = inttoptr i64 %t1048 to ptr
  %t1050 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t1049, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1050, ptr %l208
  br label %bb171
bb171:
  %t1051 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e41
  br i1 %t1051, label %bb172, label %bb173
bb172:
  %t1053 = load i64, ptr %l206
  %t1054 = inttoptr i64 %t1053 to ptr
  %t1055 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l208, i32 0, i32 0
  %t1056 = load { i64, ptr }, ptr %t1055
  %t1057 = extractvalue { i64, ptr } %t1056, 1
  %t1058 = call ptr @__olang_region_or(ptr %t1057, ptr null)
  %t1059 = icmp ne ptr %t1058, null
  %t1060 = select i1 %t1059, ptr %t1058, ptr null
  %t1061 = icmp eq ptr %t1060, %t1054
  call void @__olang_region_settle(ptr %t1054, i1 %t1061)
  br label %bb173
bb173:
  %t1062 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l208
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1062, ptr %l43
  %t1063 = ptrtoint ptr %v2 to i64
  store i64 %t1063, ptr %l210, !tbaa !24
  %t1064 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e42
  br i1 %t1064, label %bb174, label %bb175
bb174:
  %t1066 = call ptr @__olang_region_make(ptr %v2)
  %t1067 = ptrtoint ptr %t1066 to i64
  store i64 %t1067, ptr %l210, !tbaa !24
  br label %bb175
bb175:
  %t1068 = load i64, ptr %l210
  %t1069 = inttoptr i64 %t1068 to ptr
  %t1070 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t1069, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1070, ptr %l212
  br label %bb176
bb176:
  %t1071 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e42
  br i1 %t1071, label %bb177, label %bb178
bb177:
  %t1073 = load i64, ptr %l210
  %t1074 = inttoptr i64 %t1073 to ptr
  %t1075 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l212, i32 0, i32 0
  %t1076 = load { i64, ptr }, ptr %t1075
  %t1077 = extractvalue { i64, ptr } %t1076, 1
  %t1078 = call ptr @__olang_region_or(ptr %t1077, ptr null)
  %t1079 = icmp ne ptr %t1078, null
  %t1080 = select i1 %t1079, ptr %t1078, ptr null
  %t1081 = icmp eq ptr %t1080, %t1074
  call void @__olang_region_settle(ptr %t1074, i1 %t1081)
  br label %bb178
bb178:
  %t1082 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l212
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1082, ptr %l44
  %t1083 = ptrtoint ptr %v2 to i64
  store i64 %t1083, ptr %l214, !tbaa !24
  %t1084 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e43
  br i1 %t1084, label %bb179, label %bb180
bb179:
  %t1086 = call ptr @__olang_region_make(ptr %v2)
  %t1087 = ptrtoint ptr %t1086 to i64
  store i64 %t1087, ptr %l214, !tbaa !24
  br label %bb180
bb180:
  %t1088 = load i64, ptr %l214
  %t1089 = inttoptr i64 %t1088 to ptr
  %t1090 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e(ptr %t1089)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1090, ptr %l216
  br label %bb181
bb181:
  %t1091 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e43
  br i1 %t1091, label %bb182, label %bb183
bb182:
  %t1093 = load i64, ptr %l214
  %t1094 = inttoptr i64 %t1093 to ptr
  %t1095 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l216, i32 0, i32 2
  %t1096 = load { i64, ptr }, ptr %t1095
  %t1097 = extractvalue { i64, ptr } %t1096, 1
  %t1098 = call ptr @__olang_region_or(ptr %t1097, ptr null)
  %t1099 = icmp ne ptr %t1098, null
  %t1100 = select i1 %t1099, ptr %t1098, ptr null
  %t1101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l216, i32 0, i32 1
  %t1102 = load { i64, ptr }, ptr %t1101
  %t1103 = extractvalue { i64, ptr } %t1102, 1
  %t1104 = call ptr @__olang_region_or(ptr %t1103, ptr null)
  %t1105 = icmp ne ptr %t1104, null
  %t1106 = select i1 %t1105, ptr %t1104, ptr %t1100
  %t1107 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l216, i32 0, i32 0
  %t1108 = load { i64, ptr }, ptr %t1107
  %t1109 = extractvalue { i64, ptr } %t1108, 1
  %t1110 = call ptr @__olang_region_or(ptr %t1109, ptr null)
  %t1111 = icmp ne ptr %t1110, null
  %t1112 = select i1 %t1111, ptr %t1110, ptr %t1106
  %t1113 = icmp eq ptr %t1112, %t1094
  call void @__olang_region_settle(ptr %t1094, i1 %t1113)
  br label %bb183
bb183:
  %t1114 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l216
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1114, ptr %l45
  %t1115 = ptrtoint ptr %v2 to i64
  store i64 %t1115, ptr %l218, !tbaa !24
  %t1116 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e44
  br i1 %t1116, label %bb184, label %bb185
bb184:
  %t1118 = call ptr @__olang_region_make(ptr %v2)
  %t1119 = ptrtoint ptr %t1118 to i64
  store i64 %t1119, ptr %l218, !tbaa !24
  br label %bb185
bb185:
  %t1120 = load i64, ptr %l218
  %t1121 = inttoptr i64 %t1120 to ptr
  %t1122 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2ector(ptr %t1121, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1122, ptr %l220
  br label %bb186
bb186:
  %t1123 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e44
  br i1 %t1123, label %bb187, label %bb188
bb187:
  %t1125 = load i64, ptr %l218
  %t1126 = inttoptr i64 %t1125 to ptr
  %t1127 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l220, i32 0, i32 0
  %t1128 = load { i64, ptr }, ptr %t1127
  %t1129 = extractvalue { i64, ptr } %t1128, 1
  %t1130 = call ptr @__olang_region_or(ptr %t1129, ptr null)
  %t1131 = icmp ne ptr %t1130, null
  %t1132 = select i1 %t1131, ptr %t1130, ptr null
  %t1133 = icmp eq ptr %t1132, %t1126
  call void @__olang_region_settle(ptr %t1126, i1 %t1133)
  br label %bb188
bb188:
  %t1134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l220
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1134, ptr %l46
  %t1135 = ptrtoint ptr %v2 to i64
  store i64 %t1135, ptr %l222, !tbaa !24
  %t1136 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e45
  br i1 %t1136, label %bb189, label %bb190
bb189:
  %t1138 = call ptr @__olang_region_make(ptr %v2)
  %t1139 = ptrtoint ptr %t1138 to i64
  store i64 %t1139, ptr %l222, !tbaa !24
  br label %bb190
bb190:
  %t1140 = load i64, ptr %l222
  %t1141 = inttoptr i64 %t1140 to ptr
  %t1142 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_H8dba770dae4e465ce066c85e61266c0b(ptr %t1141)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1142, ptr %l224
  br label %bb191
bb191:
  %t1143 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e45
  br i1 %t1143, label %bb192, label %bb193
bb192:
  %t1145 = load i64, ptr %l222
  %t1146 = inttoptr i64 %t1145 to ptr
  %t1147 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l224, i32 0, i32 2
  %t1148 = load { i64, ptr }, ptr %t1147
  %t1149 = extractvalue { i64, ptr } %t1148, 1
  %t1150 = call ptr @__olang_region_or(ptr %t1149, ptr null)
  %t1151 = icmp ne ptr %t1150, null
  %t1152 = select i1 %t1151, ptr %t1150, ptr null
  %t1153 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l224, i32 0, i32 1
  %t1154 = load { i64, ptr }, ptr %t1153
  %t1155 = extractvalue { i64, ptr } %t1154, 1
  %t1156 = call ptr @__olang_region_or(ptr %t1155, ptr null)
  %t1157 = icmp ne ptr %t1156, null
  %t1158 = select i1 %t1157, ptr %t1156, ptr %t1152
  %t1159 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l224, i32 0, i32 0
  %t1160 = load { i64, ptr }, ptr %t1159
  %t1161 = extractvalue { i64, ptr } %t1160, 1
  %t1162 = call ptr @__olang_region_or(ptr %t1161, ptr null)
  %t1163 = icmp ne ptr %t1162, null
  %t1164 = select i1 %t1163, ptr %t1162, ptr %t1158
  %t1165 = icmp eq ptr %t1164, %t1146
  call void @__olang_region_settle(ptr %t1146, i1 %t1165)
  br label %bb193
bb193:
  %t1166 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l224
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1166, ptr %l47
  %t1167 = ptrtoint ptr %v2 to i64
  store i64 %t1167, ptr %l226, !tbaa !24
  %t1168 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e46
  br i1 %t1168, label %bb194, label %bb195
bb194:
  %t1170 = call ptr @__olang_region_make(ptr %v2)
  %t1171 = ptrtoint ptr %t1170 to i64
  store i64 %t1171, ptr %l226, !tbaa !24
  br label %bb195
bb195:
  %t1172 = load i64, ptr %l226
  %t1173 = inttoptr i64 %t1172 to ptr
  %t1174 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aListId__Hdad8023f09f4aec299a20fd2eb5533cd(ptr %t1173)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1174, ptr %l228
  br label %bb196
bb196:
  %t1175 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e46
  br i1 %t1175, label %bb197, label %bb198
bb197:
  %t1177 = load i64, ptr %l226
  %t1178 = inttoptr i64 %t1177 to ptr
  %t1179 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l228, i32 0, i32 2
  %t1180 = load { i64, ptr }, ptr %t1179
  %t1181 = extractvalue { i64, ptr } %t1180, 1
  %t1182 = call ptr @__olang_region_or(ptr %t1181, ptr null)
  %t1183 = icmp ne ptr %t1182, null
  %t1184 = select i1 %t1183, ptr %t1182, ptr null
  %t1185 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l228, i32 0, i32 1
  %t1186 = load { i64, ptr }, ptr %t1185
  %t1187 = extractvalue { i64, ptr } %t1186, 1
  %t1188 = call ptr @__olang_region_or(ptr %t1187, ptr null)
  %t1189 = icmp ne ptr %t1188, null
  %t1190 = select i1 %t1189, ptr %t1188, ptr %t1184
  %t1191 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l228, i32 0, i32 0
  %t1192 = load { i64, ptr }, ptr %t1191
  %t1193 = extractvalue { i64, ptr } %t1192, 1
  %t1194 = call ptr @__olang_region_or(ptr %t1193, ptr null)
  %t1195 = icmp ne ptr %t1194, null
  %t1196 = select i1 %t1195, ptr %t1194, ptr %t1190
  %t1197 = icmp eq ptr %t1196, %t1178
  call void @__olang_region_settle(ptr %t1178, i1 %t1197)
  br label %bb198
bb198:
  %t1198 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l228
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1198, ptr %l48
  %t1199 = ptrtoint ptr %v2 to i64
  store i64 %t1199, ptr %l230, !tbaa !24
  %t1200 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e47
  br i1 %t1200, label %bb199, label %bb200
bb199:
  %t1202 = call ptr @__olang_region_make(ptr %v2)
  %t1203 = ptrtoint ptr %t1202 to i64
  store i64 %t1203, ptr %l230, !tbaa !24
  br label %bb200
bb200:
  %t1204 = load i64, ptr %l230
  %t1205 = inttoptr i64 %t1204 to ptr
  %t1206 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t1205)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1206, ptr %l232
  br label %bb201
bb201:
  %t1207 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e47
  br i1 %t1207, label %bb202, label %bb203
bb202:
  %t1209 = load i64, ptr %l230
  %t1210 = inttoptr i64 %t1209 to ptr
  %t1211 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l232, i32 0, i32 2
  %t1212 = load { i64, ptr }, ptr %t1211
  %t1213 = extractvalue { i64, ptr } %t1212, 1
  %t1214 = call ptr @__olang_region_or(ptr %t1213, ptr null)
  %t1215 = icmp ne ptr %t1214, null
  %t1216 = select i1 %t1215, ptr %t1214, ptr null
  %t1217 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l232, i32 0, i32 1
  %t1218 = load { i64, ptr }, ptr %t1217
  %t1219 = extractvalue { i64, ptr } %t1218, 1
  %t1220 = call ptr @__olang_region_or(ptr %t1219, ptr null)
  %t1221 = icmp ne ptr %t1220, null
  %t1222 = select i1 %t1221, ptr %t1220, ptr %t1216
  %t1223 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l232, i32 0, i32 0
  %t1224 = load { i64, ptr }, ptr %t1223
  %t1225 = extractvalue { i64, ptr } %t1224, 1
  %t1226 = call ptr @__olang_region_or(ptr %t1225, ptr null)
  %t1227 = icmp ne ptr %t1226, null
  %t1228 = select i1 %t1227, ptr %t1226, ptr %t1222
  %t1229 = icmp eq ptr %t1228, %t1210
  call void @__olang_region_settle(ptr %t1210, i1 %t1229)
  br label %bb203
bb203:
  %t1230 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l232
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1230, ptr %l49
  store i64 0, ptr %l50, !tbaa !24
  %t1231 = ptrtoint ptr %v2 to i64
  store i64 %t1231, ptr %l234, !tbaa !24
  %t1232 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e49
  br i1 %t1232, label %bb204, label %bb205
bb204:
  %t1234 = call ptr @__olang_region_make(ptr %v2)
  %t1235 = ptrtoint ptr %t1234 to i64
  store i64 %t1235, ptr %l234, !tbaa !24
  br label %bb205
bb205:
  %t1236 = load i64, ptr %l234
  %t1237 = inttoptr i64 %t1236 to ptr
  %t1238 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t1237)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1238, ptr %l236
  br label %bb206
bb206:
  %t1239 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e49
  br i1 %t1239, label %bb207, label %bb208
bb207:
  %t1241 = load i64, ptr %l234
  %t1242 = inttoptr i64 %t1241 to ptr
  %t1243 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l236, i32 0, i32 2
  %t1244 = load { i64, ptr }, ptr %t1243
  %t1245 = extractvalue { i64, ptr } %t1244, 1
  %t1246 = call ptr @__olang_region_or(ptr %t1245, ptr null)
  %t1247 = icmp ne ptr %t1246, null
  %t1248 = select i1 %t1247, ptr %t1246, ptr null
  %t1249 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l236, i32 0, i32 1
  %t1250 = load { i64, ptr }, ptr %t1249
  %t1251 = extractvalue { i64, ptr } %t1250, 1
  %t1252 = call ptr @__olang_region_or(ptr %t1251, ptr null)
  %t1253 = icmp ne ptr %t1252, null
  %t1254 = select i1 %t1253, ptr %t1252, ptr %t1248
  %t1255 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l236, i32 0, i32 0
  %t1256 = load { i64, ptr }, ptr %t1255
  %t1257 = extractvalue { i64, ptr } %t1256, 1
  %t1258 = call ptr @__olang_region_or(ptr %t1257, ptr null)
  %t1259 = icmp ne ptr %t1258, null
  %t1260 = select i1 %t1259, ptr %t1258, ptr %t1254
  %t1261 = icmp eq ptr %t1260, %t1242
  call void @__olang_region_settle(ptr %t1242, i1 %t1261)
  br label %bb208
bb208:
  %t1262 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l236
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1262, ptr %l51
  store i64 0, ptr %l52, !tbaa !24
  %t1263 = load %"compiler/generic:Origin", ptr @G_2ecompiler_2fgeneric_2eNoOrigin
  store %"compiler/generic:Origin" %t1263, ptr %l53
  %t1265 = ptrtoint ptr %v2 to i64
  store i64 %t1265, ptr %l239, !tbaa !24
  %t1266 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e52
  br i1 %t1266, label %bb209, label %bb210
bb209:
  %t1268 = call ptr @__olang_region_make(ptr %v2)
  %t1269 = ptrtoint ptr %t1268 to i64
  store i64 %t1269, ptr %l239, !tbaa !24
  br label %bb210
bb210:
  %t1270 = load i64, ptr %l239
  %t1271 = inttoptr i64 %t1270 to ptr
  %t1272 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hd1c4ecf17a82b8a38b337307038559b1(ptr %t1271)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1272, ptr %l241
  br label %bb211
bb211:
  %t1273 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e52
  br i1 %t1273, label %bb212, label %bb213
bb212:
  %t1275 = load i64, ptr %l239
  %t1276 = inttoptr i64 %t1275 to ptr
  %t1277 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l241, i32 0, i32 2
  %t1278 = load { i64, ptr }, ptr %t1277
  %t1279 = extractvalue { i64, ptr } %t1278, 1
  %t1280 = call ptr @__olang_region_or(ptr %t1279, ptr null)
  %t1281 = icmp ne ptr %t1280, null
  %t1282 = select i1 %t1281, ptr %t1280, ptr null
  %t1283 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l241, i32 0, i32 1
  %t1284 = load { i64, ptr }, ptr %t1283
  %t1285 = extractvalue { i64, ptr } %t1284, 1
  %t1286 = call ptr @__olang_region_or(ptr %t1285, ptr null)
  %t1287 = icmp ne ptr %t1286, null
  %t1288 = select i1 %t1287, ptr %t1286, ptr %t1282
  %t1289 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l241, i32 0, i32 0
  %t1290 = load { i64, ptr }, ptr %t1289
  %t1291 = extractvalue { i64, ptr } %t1290, 1
  %t1292 = call ptr @__olang_region_or(ptr %t1291, ptr null)
  %t1293 = icmp ne ptr %t1292, null
  %t1294 = select i1 %t1293, ptr %t1292, ptr %t1288
  %t1295 = icmp eq ptr %t1294, %t1276
  call void @__olang_region_settle(ptr %t1276, i1 %t1295)
  br label %bb213
bb213:
  %t1296 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l241
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1296, ptr %l54
  %t1297 = ptrtoint ptr %v2 to i64
  store i64 %t1297, ptr %l243, !tbaa !24
  %t1298 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e53
  br i1 %t1298, label %bb214, label %bb215
bb214:
  %t1300 = call ptr @__olang_region_make(ptr %v2)
  %t1301 = ptrtoint ptr %t1300 to i64
  store i64 %t1301, ptr %l243, !tbaa !24
  br label %bb215
bb215:
  %t1302 = load i64, ptr %l243
  %t1303 = inttoptr i64 %t1302 to ptr
  %t1304 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %t1303)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1304, ptr %l245
  br label %bb216
bb216:
  %t1305 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e53
  br i1 %t1305, label %bb217, label %bb218
bb217:
  %t1307 = load i64, ptr %l243
  %t1308 = inttoptr i64 %t1307 to ptr
  %t1309 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l245, i32 0, i32 2
  %t1310 = load { i64, ptr }, ptr %t1309
  %t1311 = extractvalue { i64, ptr } %t1310, 1
  %t1312 = call ptr @__olang_region_or(ptr %t1311, ptr null)
  %t1313 = icmp ne ptr %t1312, null
  %t1314 = select i1 %t1313, ptr %t1312, ptr null
  %t1315 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l245, i32 0, i32 1
  %t1316 = load { i64, ptr }, ptr %t1315
  %t1317 = extractvalue { i64, ptr } %t1316, 1
  %t1318 = call ptr @__olang_region_or(ptr %t1317, ptr null)
  %t1319 = icmp ne ptr %t1318, null
  %t1320 = select i1 %t1319, ptr %t1318, ptr %t1314
  %t1321 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l245, i32 0, i32 0
  %t1322 = load { i64, ptr }, ptr %t1321
  %t1323 = extractvalue { i64, ptr } %t1322, 1
  %t1324 = call ptr @__olang_region_or(ptr %t1323, ptr null)
  %t1325 = icmp ne ptr %t1324, null
  %t1326 = select i1 %t1325, ptr %t1324, ptr %t1320
  %t1327 = icmp eq ptr %t1326, %t1308
  call void @__olang_region_settle(ptr %t1308, i1 %t1327)
  br label %bb218
bb218:
  %t1328 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l245
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1328, ptr %l55
  %t1329 = ptrtoint ptr %v2 to i64
  store i64 %t1329, ptr %l247, !tbaa !24
  %t1330 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e54
  br i1 %t1330, label %bb219, label %bb220
bb219:
  %t1332 = call ptr @__olang_region_make(ptr %v2)
  %t1333 = ptrtoint ptr %t1332 to i64
  store i64 %t1333, ptr %l247, !tbaa !24
  br label %bb220
bb220:
  %t1334 = load i64, ptr %l247
  %t1335 = inttoptr i64 %t1334 to ptr
  %t1336 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t1335)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1336, ptr %l249
  br label %bb221
bb221:
  %t1337 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e54
  br i1 %t1337, label %bb222, label %bb223
bb222:
  %t1339 = load i64, ptr %l247
  %t1340 = inttoptr i64 %t1339 to ptr
  %t1341 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l249, i32 0, i32 2
  %t1342 = load { i64, ptr }, ptr %t1341
  %t1343 = extractvalue { i64, ptr } %t1342, 1
  %t1344 = call ptr @__olang_region_or(ptr %t1343, ptr null)
  %t1345 = icmp ne ptr %t1344, null
  %t1346 = select i1 %t1345, ptr %t1344, ptr null
  %t1347 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l249, i32 0, i32 1
  %t1348 = load { i64, ptr }, ptr %t1347
  %t1349 = extractvalue { i64, ptr } %t1348, 1
  %t1350 = call ptr @__olang_region_or(ptr %t1349, ptr null)
  %t1351 = icmp ne ptr %t1350, null
  %t1352 = select i1 %t1351, ptr %t1350, ptr %t1346
  %t1353 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l249, i32 0, i32 0
  %t1354 = load { i64, ptr }, ptr %t1353
  %t1355 = extractvalue { i64, ptr } %t1354, 1
  %t1356 = call ptr @__olang_region_or(ptr %t1355, ptr null)
  %t1357 = icmp ne ptr %t1356, null
  %t1358 = select i1 %t1357, ptr %t1356, ptr %t1352
  %t1359 = icmp eq ptr %t1358, %t1340
  call void @__olang_region_settle(ptr %t1340, i1 %t1359)
  br label %bb223
bb223:
  %t1360 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l249
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1360, ptr %l56
  %t1361 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1361, ptr %l251
  br label %bb224
bb224:
  %t1362 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l251
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1362, ptr %l57
  %t1363 = ptrtoint ptr %v2 to i64
  store i64 %t1363, ptr %l252, !tbaa !24
  %t1364 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e56
  br i1 %t1364, label %bb225, label %bb226
bb225:
  %t1366 = call ptr @__olang_region_make(ptr %v2)
  %t1367 = ptrtoint ptr %t1366 to i64
  store i64 %t1367, ptr %l252, !tbaa !24
  br label %bb226
bb226:
  %t1368 = load i64, ptr %l252
  %t1369 = inttoptr i64 %t1368 to ptr
  %t1370 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_H6229cef23ae97e8e8df94ae881e620c3(ptr %t1369)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1370, ptr %l254
  br label %bb227
bb227:
  %t1371 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e56
  br i1 %t1371, label %bb228, label %bb229
bb228:
  %t1373 = load i64, ptr %l252
  %t1374 = inttoptr i64 %t1373 to ptr
  %t1375 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l254, i32 0, i32 2
  %t1376 = load { i64, ptr }, ptr %t1375
  %t1377 = extractvalue { i64, ptr } %t1376, 1
  %t1378 = call ptr @__olang_region_or(ptr %t1377, ptr null)
  %t1379 = icmp ne ptr %t1378, null
  %t1380 = select i1 %t1379, ptr %t1378, ptr null
  %t1381 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l254, i32 0, i32 1
  %t1382 = load { i64, ptr }, ptr %t1381
  %t1383 = extractvalue { i64, ptr } %t1382, 1
  %t1384 = call ptr @__olang_region_or(ptr %t1383, ptr null)
  %t1385 = icmp ne ptr %t1384, null
  %t1386 = select i1 %t1385, ptr %t1384, ptr %t1380
  %t1387 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l254, i32 0, i32 0
  %t1388 = load { i64, ptr }, ptr %t1387
  %t1389 = extractvalue { i64, ptr } %t1388, 1
  %t1390 = call ptr @__olang_region_or(ptr %t1389, ptr null)
  %t1391 = icmp ne ptr %t1390, null
  %t1392 = select i1 %t1391, ptr %t1390, ptr %t1386
  %t1393 = icmp eq ptr %t1392, %t1374
  call void @__olang_region_settle(ptr %t1374, i1 %t1393)
  br label %bb229
bb229:
  %t1394 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l254
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1394, ptr %l58
  %t1395 = ptrtoint ptr %v2 to i64
  store i64 %t1395, ptr %l256, !tbaa !24
  %t1396 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e57
  br i1 %t1396, label %bb230, label %bb231
bb230:
  %t1398 = call ptr @__olang_region_make(ptr %v2)
  %t1399 = ptrtoint ptr %t1398 to i64
  store i64 %t1399, ptr %l256, !tbaa !24
  br label %bb231
bb231:
  %t1400 = load i64, ptr %l256
  %t1401 = inttoptr i64 %t1400 to ptr
  %t1402 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cI64_3e_26_3e(ptr %t1401)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1402, ptr %l258
  br label %bb232
bb232:
  %t1403 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e57
  br i1 %t1403, label %bb233, label %bb234
bb233:
  %t1405 = load i64, ptr %l256
  %t1406 = inttoptr i64 %t1405 to ptr
  %t1407 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l258, i32 0, i32 2
  %t1408 = load { i64, ptr }, ptr %t1407
  %t1409 = extractvalue { i64, ptr } %t1408, 1
  %t1410 = call ptr @__olang_region_or(ptr %t1409, ptr null)
  %t1411 = icmp ne ptr %t1410, null
  %t1412 = select i1 %t1411, ptr %t1410, ptr null
  %t1413 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l258, i32 0, i32 1
  %t1414 = load { i64, ptr }, ptr %t1413
  %t1415 = extractvalue { i64, ptr } %t1414, 1
  %t1416 = call ptr @__olang_region_or(ptr %t1415, ptr null)
  %t1417 = icmp ne ptr %t1416, null
  %t1418 = select i1 %t1417, ptr %t1416, ptr %t1412
  %t1419 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l258, i32 0, i32 0
  %t1420 = load { i64, ptr }, ptr %t1419
  %t1421 = extractvalue { i64, ptr } %t1420, 1
  %t1422 = call ptr @__olang_region_or(ptr %t1421, ptr null)
  %t1423 = icmp ne ptr %t1422, null
  %t1424 = select i1 %t1423, ptr %t1422, ptr %t1418
  %t1425 = icmp eq ptr %t1424, %t1406
  call void @__olang_region_settle(ptr %t1406, i1 %t1425)
  br label %bb234
bb234:
  %t1426 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l258
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1426, ptr %l59
  %t1427 = ptrtoint ptr %v2 to i64
  store i64 %t1427, ptr %l260, !tbaa !24
  %t1428 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e58
  br i1 %t1428, label %bb235, label %bb236
bb235:
  %t1430 = call ptr @__olang_region_make(ptr %v2)
  %t1431 = ptrtoint ptr %t1430 to i64
  store i64 %t1431, ptr %l260, !tbaa !24
  br label %bb236
bb236:
  %t1432 = load i64, ptr %l260
  %t1433 = inttoptr i64 %t1432 to ptr
  %t1434 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %t1433)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1434, ptr %l262
  br label %bb237
bb237:
  %t1435 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e58
  br i1 %t1435, label %bb238, label %bb239
bb238:
  %t1437 = load i64, ptr %l260
  %t1438 = inttoptr i64 %t1437 to ptr
  %t1439 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l262, i32 0, i32 2
  %t1440 = load { i64, ptr }, ptr %t1439
  %t1441 = extractvalue { i64, ptr } %t1440, 1
  %t1442 = call ptr @__olang_region_or(ptr %t1441, ptr null)
  %t1443 = icmp ne ptr %t1442, null
  %t1444 = select i1 %t1443, ptr %t1442, ptr null
  %t1445 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l262, i32 0, i32 1
  %t1446 = load { i64, ptr }, ptr %t1445
  %t1447 = extractvalue { i64, ptr } %t1446, 1
  %t1448 = call ptr @__olang_region_or(ptr %t1447, ptr null)
  %t1449 = icmp ne ptr %t1448, null
  %t1450 = select i1 %t1449, ptr %t1448, ptr %t1444
  %t1451 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l262, i32 0, i32 0
  %t1452 = load { i64, ptr }, ptr %t1451
  %t1453 = extractvalue { i64, ptr } %t1452, 1
  %t1454 = call ptr @__olang_region_or(ptr %t1453, ptr null)
  %t1455 = icmp ne ptr %t1454, null
  %t1456 = select i1 %t1455, ptr %t1454, ptr %t1450
  %t1457 = icmp eq ptr %t1456, %t1438
  call void @__olang_region_settle(ptr %t1438, i1 %t1457)
  br label %bb239
bb239:
  %t1458 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l262
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1458, ptr %l60
  %t1459 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_H8af9c018c4362535021af37a38e67a7c(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1459, ptr %l264
  br label %bb240
bb240:
  %t1460 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l264
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1460, ptr %l61
  %t1461 = ptrtoint ptr %v2 to i64
  store i64 %t1461, ptr %l265, !tbaa !24
  %t1462 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e60
  br i1 %t1462, label %bb241, label %bb242
bb241:
  %t1464 = call ptr @__olang_region_make(ptr %v2)
  %t1465 = ptrtoint ptr %t1464 to i64
  store i64 %t1465, ptr %l265, !tbaa !24
  br label %bb242
bb242:
  %t1466 = load i64, ptr %l265
  %t1467 = inttoptr i64 %t1466 to ptr
  %t1468 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t1467, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1468, ptr %l267
  br label %bb243
bb243:
  %t1469 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e60
  br i1 %t1469, label %bb244, label %bb245
bb244:
  %t1471 = load i64, ptr %l265
  %t1472 = inttoptr i64 %t1471 to ptr
  %t1473 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267, i32 0, i32 0
  %t1474 = load { i64, ptr }, ptr %t1473
  %t1475 = extractvalue { i64, ptr } %t1474, 1
  %t1476 = call ptr @__olang_region_or(ptr %t1475, ptr null)
  %t1477 = icmp ne ptr %t1476, null
  %t1478 = select i1 %t1477, ptr %t1476, ptr null
  %t1479 = icmp eq ptr %t1478, %t1472
  call void @__olang_region_settle(ptr %t1472, i1 %t1479)
  br label %bb245
bb245:
  %t1480 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1480, ptr %l62
  %t1481 = ptrtoint ptr %v2 to i64
  store i64 %t1481, ptr %l269, !tbaa !24
  %t1482 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e61
  br i1 %t1482, label %bb246, label %bb247
bb246:
  %t1484 = call ptr @__olang_region_make(ptr %v2)
  %t1485 = ptrtoint ptr %t1484 to i64
  store i64 %t1485, ptr %l269, !tbaa !24
  br label %bb247
bb247:
  %t1486 = load i64, ptr %l269
  %t1487 = inttoptr i64 %t1486 to ptr
  %t1488 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2ector(ptr %t1487, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1488, ptr %l271
  br label %bb248
bb248:
  %t1489 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e61
  br i1 %t1489, label %bb249, label %bb250
bb249:
  %t1491 = load i64, ptr %l269
  %t1492 = inttoptr i64 %t1491 to ptr
  %t1493 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l271, i32 0, i32 0
  %t1494 = load { i64, ptr }, ptr %t1493
  %t1495 = extractvalue { i64, ptr } %t1494, 1
  %t1496 = call ptr @__olang_region_or(ptr %t1495, ptr null)
  %t1497 = icmp ne ptr %t1496, null
  %t1498 = select i1 %t1497, ptr %t1496, ptr null
  %t1499 = icmp eq ptr %t1498, %t1492
  call void @__olang_region_settle(ptr %t1492, i1 %t1499)
  br label %bb250
bb250:
  %t1500 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l271
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1500, ptr %l63
  %t1501 = ptrtoint ptr %v2 to i64
  store i64 %t1501, ptr %l273, !tbaa !24
  %t1502 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e62
  br i1 %t1502, label %bb251, label %bb252
bb251:
  %t1504 = call ptr @__olang_region_make(ptr %v2)
  %t1505 = ptrtoint ptr %t1504 to i64
  store i64 %t1505, ptr %l273, !tbaa !24
  br label %bb252
bb252:
  %t1506 = load i64, ptr %l273
  %t1507 = inttoptr i64 %t1506 to ptr
  %t1508 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %t1507)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1508, ptr %l275
  br label %bb253
bb253:
  %t1509 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e62
  br i1 %t1509, label %bb254, label %bb255
bb254:
  %t1511 = load i64, ptr %l273
  %t1512 = inttoptr i64 %t1511 to ptr
  %t1513 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l275, i32 0, i32 2
  %t1514 = load { i64, ptr }, ptr %t1513
  %t1515 = extractvalue { i64, ptr } %t1514, 1
  %t1516 = call ptr @__olang_region_or(ptr %t1515, ptr null)
  %t1517 = icmp ne ptr %t1516, null
  %t1518 = select i1 %t1517, ptr %t1516, ptr null
  %t1519 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l275, i32 0, i32 1
  %t1520 = load { i64, ptr }, ptr %t1519
  %t1521 = extractvalue { i64, ptr } %t1520, 1
  %t1522 = call ptr @__olang_region_or(ptr %t1521, ptr null)
  %t1523 = icmp ne ptr %t1522, null
  %t1524 = select i1 %t1523, ptr %t1522, ptr %t1518
  %t1525 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l275, i32 0, i32 0
  %t1526 = load { i64, ptr }, ptr %t1525
  %t1527 = extractvalue { i64, ptr } %t1526, 1
  %t1528 = call ptr @__olang_region_or(ptr %t1527, ptr null)
  %t1529 = icmp ne ptr %t1528, null
  %t1530 = select i1 %t1529, ptr %t1528, ptr %t1524
  %t1531 = icmp eq ptr %t1530, %t1512
  call void @__olang_region_settle(ptr %t1512, i1 %t1531)
  br label %bb255
bb255:
  %t1532 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l275
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1532, ptr %l64
  %t1533 = ptrtoint ptr %v2 to i64
  store i64 %t1533, ptr %l277, !tbaa !24
  %t1534 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e63
  br i1 %t1534, label %bb256, label %bb257
bb256:
  %t1536 = call ptr @__olang_region_make(ptr %v2)
  %t1537 = ptrtoint ptr %t1536 to i64
  store i64 %t1537, ptr %l277, !tbaa !24
  br label %bb257
bb257:
  %t1538 = load i64, ptr %l277
  %t1539 = inttoptr i64 %t1538 to ptr
  %t1540 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hdff0a0f3a8e4aec496bff26ce81ff432(ptr %t1539)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1540, ptr %l279
  br label %bb258
bb258:
  %t1541 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e63
  br i1 %t1541, label %bb259, label %bb260
bb259:
  %t1543 = load i64, ptr %l277
  %t1544 = inttoptr i64 %t1543 to ptr
  %t1545 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l279, i32 0, i32 2
  %t1546 = load { i64, ptr }, ptr %t1545
  %t1547 = extractvalue { i64, ptr } %t1546, 1
  %t1548 = call ptr @__olang_region_or(ptr %t1547, ptr null)
  %t1549 = icmp ne ptr %t1548, null
  %t1550 = select i1 %t1549, ptr %t1548, ptr null
  %t1551 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l279, i32 0, i32 1
  %t1552 = load { i64, ptr }, ptr %t1551
  %t1553 = extractvalue { i64, ptr } %t1552, 1
  %t1554 = call ptr @__olang_region_or(ptr %t1553, ptr null)
  %t1555 = icmp ne ptr %t1554, null
  %t1556 = select i1 %t1555, ptr %t1554, ptr %t1550
  %t1557 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l279, i32 0, i32 0
  %t1558 = load { i64, ptr }, ptr %t1557
  %t1559 = extractvalue { i64, ptr } %t1558, 1
  %t1560 = call ptr @__olang_region_or(ptr %t1559, ptr null)
  %t1561 = icmp ne ptr %t1560, null
  %t1562 = select i1 %t1561, ptr %t1560, ptr %t1556
  %t1563 = icmp eq ptr %t1562, %t1544
  call void @__olang_region_settle(ptr %t1544, i1 %t1563)
  br label %bb260
bb260:
  %t1564 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l279
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1564, ptr %l65
  %t1565 = ptrtoint ptr %v2 to i64
  store i64 %t1565, ptr %l281, !tbaa !24
  %t1566 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e64
  br i1 %t1566, label %bb261, label %bb262
bb261:
  %t1568 = call ptr @__olang_region_make(ptr %v2)
  %t1569 = ptrtoint ptr %t1568 to i64
  store i64 %t1569, ptr %l281, !tbaa !24
  br label %bb262
bb262:
  %t1570 = load i64, ptr %l281
  %t1571 = inttoptr i64 %t1570 to ptr
  %t1572 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t1571)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1572, ptr %l283
  br label %bb263
bb263:
  %t1573 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aProgram_2e64
  br i1 %t1573, label %bb264, label %bb265
bb264:
  %t1575 = load i64, ptr %l281
  %t1576 = inttoptr i64 %t1575 to ptr
  %t1577 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l283, i32 0, i32 2
  %t1578 = load { i64, ptr }, ptr %t1577
  %t1579 = extractvalue { i64, ptr } %t1578, 1
  %t1580 = call ptr @__olang_region_or(ptr %t1579, ptr null)
  %t1581 = icmp ne ptr %t1580, null
  %t1582 = select i1 %t1581, ptr %t1580, ptr null
  %t1583 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l283, i32 0, i32 1
  %t1584 = load { i64, ptr }, ptr %t1583
  %t1585 = extractvalue { i64, ptr } %t1584, 1
  %t1586 = call ptr @__olang_region_or(ptr %t1585, ptr null)
  %t1587 = icmp ne ptr %t1586, null
  %t1588 = select i1 %t1587, ptr %t1586, ptr %t1582
  %t1589 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l283, i32 0, i32 0
  %t1590 = load { i64, ptr }, ptr %t1589
  %t1591 = extractvalue { i64, ptr } %t1590, 1
  %t1592 = call ptr @__olang_region_or(ptr %t1591, ptr null)
  %t1593 = icmp ne ptr %t1592, null
  %t1594 = select i1 %t1593, ptr %t1592, ptr %t1588
  %t1595 = icmp eq ptr %t1594, %t1576
  call void @__olang_region_settle(ptr %t1576, i1 %t1595)
  br label %bb265
bb265:
  %t1596 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l283
  %t1597 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 0
  %t1598 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1598, ptr %t1597, !tbaa !29
  %t1599 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 1
  %t1600 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1600, ptr %t1599, !tbaa !29
  %t1601 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t1601, ptr %l4, i64 2096, i1 false)
  %t1602 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %t1602, ptr %l5, i64 232, i1 false)
  %t1603 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 4
  %t1604 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1604, ptr %t1603
  %t1605 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 5
  %t1606 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1606, ptr %t1605
  %t1607 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 6
  %t1608 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1608, ptr %t1607
  %t1609 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 7
  %t1610 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1610, ptr %t1609
  %t1611 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 8
  %t1612 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1612, ptr %t1611
  %t1613 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 9
  %t1614 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1614, ptr %t1613
  %t1615 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 10
  %t1616 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1616, ptr %t1615
  %t1617 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 11
  %t1618 = load i64, ptr %l13, !tbaa !24
  store i64 %t1618, ptr %t1617, !tbaa !24
  %t1619 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 12
  %t1620 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1620, ptr %t1619
  %t1621 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 13
  %t1622 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1622, ptr %t1621
  %t1623 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 14
  %t1624 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1624, ptr %t1623
  %t1625 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 15
  %t1626 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1626, ptr %t1625
  %t1627 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 16
  %t1628 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1628, ptr %t1627
  %t1629 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 17
  %t1630 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1630, ptr %t1629
  %t1631 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 18
  %t1632 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1632, ptr %t1631
  %t1633 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 19
  %t1634 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1634, ptr %t1633
  %t1635 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 20
  %t1636 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1636, ptr %t1635
  %t1637 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 21
  %t1638 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1638, ptr %t1637
  %t1639 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 22
  %t1640 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1640, ptr %t1639
  %t1641 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 23
  %t1642 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1642, ptr %t1641
  %t1643 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 24
  %t1644 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l26
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1644, ptr %t1643
  %t1645 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 25
  %t1646 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1646, ptr %t1645
  %t1647 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 26
  %t1648 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1648, ptr %t1647
  %t1649 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 27
  %t1650 = load i64, ptr %l29, !tbaa !24
  store i64 %t1650, ptr %t1649, !tbaa !24
  %t1651 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 28
  %t1652 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l30
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1652, ptr %t1651
  %t1653 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 29
  %t1654 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1654, ptr %t1653
  %t1655 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 30
  %t1656 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1656, ptr %t1655
  %t1657 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 31
  %t1658 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1658, ptr %t1657
  %t1659 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 32
  %t1660 = load i64, ptr %l34, !tbaa !24
  store i64 %t1660, ptr %t1659, !tbaa !24
  %t1661 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 33
  %t1662 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1662, ptr %t1661
  %t1663 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 34
  %t1664 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1664, ptr %t1663
  %t1665 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 35
  %t1666 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1666, ptr %t1665
  %t1667 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 36
  %t1668 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1668, ptr %t1667
  %t1669 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 37
  %t1670 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l39
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1670, ptr %t1669
  %t1671 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 38
  %t1672 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1672, ptr %t1671
  %t1673 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 39
  %t1674 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1674, ptr %t1673
  %t1675 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 40
  %t1676 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l42
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1676, ptr %t1675
  %t1677 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 41
  %t1678 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1678, ptr %t1677
  %t1679 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 42
  %t1680 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1680, ptr %t1679
  %t1681 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 43
  %t1682 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1682, ptr %t1681
  %t1683 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 44
  %t1684 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1684, ptr %t1683
  %t1685 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 45
  %t1686 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1686, ptr %t1685
  %t1687 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 46
  %t1688 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l48
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1688, ptr %t1687
  %t1689 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 47
  %t1690 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1690, ptr %t1689
  %t1691 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 48
  %t1692 = load i64, ptr %l50, !tbaa !24
  store i64 %t1692, ptr %t1691, !tbaa !24
  %t1693 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 49
  %t1694 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l51
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1694, ptr %t1693
  %t1695 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 50
  %t1696 = load i64, ptr %l52, !tbaa !24
  store i64 %t1696, ptr %t1695, !tbaa !24
  %t1697 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 51
  %t1698 = load %"compiler/generic:Origin", ptr %l53
  store %"compiler/generic:Origin" %t1698, ptr %t1697
  %t1699 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 52
  %t1700 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1700, ptr %t1699
  %t1701 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 53
  %t1702 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l55
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1702, ptr %t1701
  %t1703 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 54
  %t1704 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1704, ptr %t1703
  %t1705 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 55
  %t1706 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1706, ptr %t1705
  %t1707 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 56
  %t1708 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1708, ptr %t1707
  %t1709 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 57
  %t1710 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l59
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1710, ptr %t1709
  %t1711 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 58
  %t1712 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l60
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1712, ptr %t1711
  %t1713 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 59
  %t1714 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l61
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1714, ptr %t1713
  %t1715 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 60
  %t1716 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1716, ptr %t1715
  %t1717 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 61
  %t1718 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1718, ptr %t1717
  %t1719 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 62
  %t1720 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l64
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1720, ptr %t1719
  %t1721 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 63
  %t1722 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1722, ptr %t1721
  %t1723 = getelementptr %"compiler/generic:Program", ptr %l285, i32 0, i32 64
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1596, ptr %t1723
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l285, i64 5856, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/generic:cursor" @compiler_2fgeneric_3acursor_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca %"compiler/generic:cursor"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/generic:cursor" undef, { i64, ptr } %a0, 0
  %t6 = insertvalue %"compiler/generic:cursor" %t4, i64 0, 1
  store %"compiler/generic:cursor" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:cursor", ptr %rv
  ret %"compiler/generic:cursor" %rr
}

define dso_local %"compiler/generic:fnRow" @compiler_2fgeneric_3afnRow_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/generic:fnRow"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/generic:fnRow" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/generic:fnRow" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/generic:fnRow" %t10, i1 %a2, 2
  store %"compiler/generic:fnRow" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:fnRow", ptr %rv
  ret %"compiler/generic:fnRow" %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/generic:folded"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/generic:folded" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/generic:folded" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/generic:folded" %t10, i32 %a2, 2
  store %"compiler/generic:folded" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_empty_array = external constant [16 x i64]
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_0(ptr %env, i32 %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrBefore(ptr %vc0, ptr %cv0, i32 %a0, i32 %a1)
  store i1 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@olang_2esole_2ecompiler_2fgeneric_3ainstance_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d4 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Columns" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e61 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e62 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e64 = weak hidden constant i1 false
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 33}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 33}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Copy" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"[0]" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".Len()" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d20 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Char" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Hcd3bbe8e64537e19c3182f51d0fe16c9(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d24 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"noborrow" }>, align 8
@.d25 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"borrows " }>, align 8
@.d26 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"borrows" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d29 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d31 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d32 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ViewGenerator" }>, align 8
@olang_2esole_2ecompiler_2fgeneric_3aAnyTable_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e4 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e5 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e7 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e9 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e10 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e14 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e17 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e20 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hf4514b6649a0255133072aa3e28fef27(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e21 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__H50c0e2fd81a181d0fc73c1f447a09921(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2fmap_3aMap_3cc_Hf610e65333a7029b8334323649a7dbe0(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e22 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e23 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e24 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e25 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e26 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e30 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e31 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e33 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e34 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e35 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e36 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e37 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e38 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e39 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e40 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e41 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e42 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e43 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e44 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e45 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_H8dba770dae4e465ce066c85e61266c0b(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftypes_3aListId_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e46 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aListId__Hdad8023f09f4aec299a20fd2eb5533cd(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aListId_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e47 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e49 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e52 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hd1c4ecf17a82b8a38b337307038559b1(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e53 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e54 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e56 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_H6229cef23ae97e8e8df94ae881e620c3(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e57 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cI64_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e58 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_H8af9c018c4362535021af37a38e67a7c(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fast_3aVarDecl_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e60 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aProgram_2e63 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hdff0a0f3a8e4aec496bff26ce81ff432(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fgeneric_3aAnySlot_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @compiler_2fnames_2eWrittenMut(ptr %v0, ptr %a0)
@olang_loc_16dbf6b4ccd94c8c_8f0170059e61e7c0 = external constant [0 x i8]
@olang_loc_b4eb6cf3622f1222_98250c586f701fa6 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H5ded0725d411df67b2648301e639bd4e(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c2f0255997df361c_a6c9f390e9e9df68 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H9e3d6110ebf70523261e6bda2644191a(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAny(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWithReceiver(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/generic:AnySlot" @compiler_2fgeneric_3aAnySlot_2ector(ptr %v0, i32 %a0, i32 %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2ePush_H53ed042998733b8f648bef68c9e795c2(ptr %v0, ptr %a0, %"compiler/generic:AnySlot" %a1)
@olang_loc_8bb21cabdbc81f72_d9374099c3cf9016 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eLen__H711cec3afad496782566ddd729023773(ptr %v0, ptr %a0)
@olang_loc_98166f45573479aa_46aa63c900b34a36 = external constant [0 x i8]
declare %"compiler/generic:AnySlot" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnySlot_3e_2eAt_3ccompiler_2fgeneric_3aAnySlot_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H5c1f2db077436d08712784f933dc3852(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__Hbe724e949204db7f54e3bca969c5f391(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_799e213f453ad9fb_869f4f41e63ea5ff = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkUnique(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkPacked(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEndsHeld(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkEnds(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__H7ddd7dd10a6733ce5265405d8e7c8faa(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emergeEntries(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2farray_2eArray_3ccompiler_2ftypes_3aTypeId_3e_2eSort_3ccompiler_2ftypes_3aTypeId_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrVal(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetErrRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNameErrVal(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_de4c5053baae2eb0_7e20459b6f7605c4 = external constant [0 x i8]
@olang_loc_16d3c7726565025d_3b40f943fadf33d1 = external constant [0 x i8]
@olang_loc_7b14d935e96e16e5_1eebf856974cc301 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2einstanceArgs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__Hfc7ca136f786d4bb067f513e5dea5730(ptr %v0, ptr %a0, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eLen_Hf1590ba3dea8cd8a914b2a9f5344a2c6(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/generic:instance" @compiler_2fgeneric_3ainstance_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, %"compiler/generic:Origin" %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2ePus_Hca36cd1c69200a0db62aadeba49cf6ed(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:instance" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5edca056502a242264473f986489341f(ptr %v0, ptr %a0, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereadsLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@G_2ecompiler_2fgeneric_2eUnfolded = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2evarsBound(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fgeneric_2eRunTimeLength = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\80" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v0, ptr %a0)
declare %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %a0)
@olang_loc_99cf014ebb3d252c_a323a427e7fb0b10 = external constant [0 x i8]
@olang_loc_9c491d6513909eb9_b2019bc0b634333d = external constant [0 x i8]
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare %"compiler/generic:ConstAsk" @compiler_2fgeneric_3aConstAsk_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, ptr %a1, i32 %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ePus_H9314813d35e39659e36ddfdc05758427(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:ConstAsk" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnknownConst(ptr %v0, ptr %a0)
@G_2ecompiler_2fgeneric_2eFolded = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/generic:folded" %a2, i32 %a3, ptr %a4)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edescDecl(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3993e9d21a27b6abd527556382000d9e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f85b3d57f52ff5f3_99e1343e21fb4c8f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDepth(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eMaxDepth = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\30\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunbounded(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hf7241cd153db7dbb97afc4b39a688af4(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H52a70901e2e6ceea4e17edd807bbe24b(ptr %v0, ptr %a0, i32 %a1, %"compiler/generic:Origin" %a2)
declare %"compiler/generic:instance" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eAt__Hf3965267bb92d0ee7aeaa2339e2e46fa(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6743fd6fdd876d533cce32e3c0cd25b6(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hcfc2a2943c600247d4ded3fb914681ab(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_25bcbd8d25f60d50_252e633c827b5284 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Ha2fdd285cc075e465cab85a1d0fe3f31(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hc32bd40495535e8a7e7ddcc641d0c371(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hce1a5ca8c8bc252d00e2ccbd39de0b40(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fpair_3aPair_3cI64_2c_20I64_3_Hca1409b49ac7e9b021f6a95c9301ae1a(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_91e581c61227d1c4_deb54d58cf8aa350 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_632aa6436eca4593_afccf639e057e8af = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ementionsName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__H9861f6f09602cf23d49075e82ac9429b(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fnames_2ePayloadName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__Hbdd7c5068e376aa260a62181a9f99429(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEnumBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3)
@olang_loc_52c8f96a75cfc7a4_95d33db140d5de70 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyKind(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i32 %a3, ptr %a4, i1 %a5)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUniqueSettled(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epartsReady(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2ePush_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:fnRow" %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddBuilder(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
@olang_loc_cab99c6a514cda4c_3636b0df4624338 = external constant [0 x i8]
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkCopy(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6578d57707832f1c_86539f83bfff8b08 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFns(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_8ca182a09b46660b_89b944af5f42b927 = external constant [0 x i8]
@olang_loc_e2462b885589950a_643da267921b7c76 = external constant [0 x i8]
@olang_loc_c23c218140effa50_4db4b783113412a4 = external constant [0 x i8]
@olang_loc_7e185c750e76a77d_541671d994da32b1 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetUnion(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3, i1 %a4)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonInner(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5e7d85fe5a4092b0_8f62b4b719433814 = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:varRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eAt_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/generic:varRow" @compiler_2fgeneric_3avarRow_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eSetAt_H989a0ed1a318d7d0cbb6cc41385b33d2(ptr %v0, ptr %a0, i64 %a1, %"compiler/generic:varRow" %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@G_2ecompiler_2fgeneric_2ePending = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fa05ab364d453a8b_cb1072875564fc6f = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_415c77be4516d04a_7550ee8386647fae = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_886433b88e29f460_704fa105f63225d4 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_cbe34de7626751c6_f090548a7d71387a = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2emutableGlobal(ptr %v0, ptr %a0)
@olang_loc_3f6d4ec28d03c677_4b12a6ade8d65b03 = external constant [0 x i8]
@olang_loc_514348f953d022bc_74505ba6df313dd0 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3)
@olang_loc_289ae50874ea0e2b_45680487effe832f = external constant [0 x i8]
@olang_loc_d51864a21628ffaa_68720bbe5c137f7e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehasHash(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emayHold(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseErr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, %"compiler/diagmsg:Msg" %a3)
@G_2ecompiler_2ftypes_2eKeepsHome = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromiseParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsSelf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsInValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsPath(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseKeepsField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e8a0dc9ccb955f9f_ce9beed0e9e57113 = external constant [0 x i8]
@olang_loc_4860714026464204_4592c2a1d2b55600 = external constant [0 x i8]
@olang_loc_360fa96f69d7f913_7dd7870a86c7dc67 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_4472349556a15fd2_df3caa9bde222db6 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2eLengthDecided(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehandedOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3, i64 %a4, { i64, ptr } %a5, i64 %a6)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_fc435fbf179ab4a3_d5536eec81a24b6f = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7c1b9fa6eff766ef_29392a9ca6e4fd4b = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i64 @compiler_2fgeneric_2epromiseBit(i32 %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseReturnsNoreturn(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsNothing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
@G_2ecompiler_2ftypes_2ePromNoborrow = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\80\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseBorrowsBoth(ptr %v0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare ptr @compiler_2fgeneric_2elisted(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstraintKey(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@G_2ecompiler_2fgeneric_2eArrayKey = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\02\00\00" }>, align 8
@olang_loc_769954e80c04bef7_8801cb066681a71b = external constant [0 x i8]
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eParseCanon(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrDeclOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_cbc970693726adb_6d60ff5fdd174af = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyLists(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4)
@olang_loc_b7daf7406ba778a4_42e2bd1e0b6e1610 = external constant [0 x i8]
@olang_loc_6b949e9fdbc9587c_5a8bb2436952ea48 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_961f770be6209277_34282562e2239643 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eGenLocalBit = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c61310131704fb2f_f27aa7cba89c0bc3 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ebaseName(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebranches(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_df5307d3a8bec99f_effac078aaeab34b = external constant [0 x i8]
@olang_loc_de533036e7174fdb_fce805c56f435877 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @compiler_2ftypes_2eTable_2eNew(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ffacts_3aTable_2ector(ptr %out, ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2fgeneric_2eNoOrigin = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\00\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\01\00\00\00\00\00\00\00" }>, align 32
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrBefore(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2fmap_3aMap_3cc_Hf610e65333a7029b8334323649a7dbe0(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fgeneric_3apattern_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftypes_3aListId_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aListId_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fast_3aVarDecl_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fgeneric_3aAnySlot_3e_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
