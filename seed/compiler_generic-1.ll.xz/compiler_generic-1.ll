; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:fnRow" = type { i64, ptr, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1, ptr }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:varRow" = type { i64, i32, i32, i32, i32 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:instance" = type { i64, i32, i32, { i64, ptr }, { i64, ptr }, %"compiler/generic:Origin" }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/generic:memberRow" = type { i64, %"compiler/source:Span", ptr, i32, { i64, ptr }, ptr, i32, i64 }
%"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", i64 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/generic:folded" = type { i64, i64, i32 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/generic:cursor" = type { { i64, ptr }, i64 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/generic:genRoots" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:ConstAsk" = type { i64, ptr, i32, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/generic:pattern" = type { ptr, i64, i64, i32, ptr }
define dso_local i64 @compiler_2fgeneric_2eCtorOwner(i32 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a0 to i64
  %t5 = mul i64 %t3, 2
  %t7 = add i64 %t5, 2
  %t9 = sub i64 0, %t7
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a0 to i64
  %t5 = mul i64 %t3, 2
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %rv = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t3 = ptrtoint ptr %t2 to i64
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 %t3, i64 8)
  %t5 = getelementptr { ptr, ptr }, ptr %t4, i32 0, i32 0
  store ptr %a0, ptr %t5, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t7 = call ptr @__olang_scope_hold(ptr %v0)
  %t8 = getelementptr { ptr, ptr }, ptr %t4, i32 0, i32 1
  store ptr %t7, ptr %t8, !tbaa !28
  %t9 = call ptr @__olang_scope_hold(ptr %v1)
  %t10 = call ptr @olang_lambda_0.coro(ptr %t4, ptr %t9)
  call void @__olang_scope_register_dtor(ptr %v1, ptr %t10, ptr @olang_lambda_0.drop)
  %t11 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t12 = insertvalue { ptr, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { ptr, ptr } %t12, 0
  %t15 = extractvalue { ptr, ptr } %t12, 1
  %t16 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @std_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aVarDecl_3e_2ector(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t16, ptr %l3
  br label %bb1
bb1:
  %t17 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l3
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %rv
  ret %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %rr
}

define dso_local i64 @compiler_2fgeneric_2eFnOwner(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 2
  %t5 = add i64 %t3, 1
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fgeneric_2eisErrsArg(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2eMemberOwner(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = shl i64 1, 41
  %t3 = sub i64 0, %t1
  %t7 = sub i64 %t3, %a0
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/generic:Unmet" @compiler_2fgeneric_2eUnmet_2emet() #0 {
entry:
  %l1 = alloca %"compiler/generic:Unmet"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Unmet"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t3 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s0, i64 -1, i32 %t1, i32 0, i1 false, i1 false, i1 false)
  store %"compiler/generic:Unmet" %t3, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/generic:Unmet", ptr %l1
  store %"compiler/generic:Unmet" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Unmet", ptr %rv
  ret %"compiler/generic:Unmet" %rr
}

define dso_local i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fnames_2eWrittenMut(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ebyValueParam(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Param", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_16dbf6b4ccd94c8c_8f0170059e61e7c0)
  unreachable
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Param", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 8}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 8}
  %t37 = icmp eq i64 %t35, 4
  store i1 %t37, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_b4eb6cf3622f1222_98250c586f701fa6)
  unreachable
bb21:
  %t39 = load i1, ptr %l11, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l54 = alloca %"compiler/generic:fnRow"
  %l62 = alloca i64
  %l72 = alloca { i64, ptr }
  %l78 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %s0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 40
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l22
  br label %bb3
bb3:
  %t14 = load i64, ptr %l22, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb6:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l29, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l29, !tbaa !24
  store i64 %t41, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l26, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 40
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i64, ptr %l50, !tbaa !24
  store i64 %t68, ptr %l10, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 31
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s2, ptr %t71, i64 %t72)
  store %"compiler/generic:fnRow" %t75, ptr %l54
  br label %bb15
bb15:
  %t76 = getelementptr %"compiler/generic:fnRow", ptr %l54, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t84 = icmp ne i32 %t80, %a2
  br i1 %t84, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 41
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t88, i64 %t89)
  store i64 %t92, ptr %l62
  br label %bb19
bb19:
  %t93 = load i64, ptr %l62, !tbaa !24
  %t94 = trunc i64 %t93 to i32
  store i32 %t94, ptr %l11, !tbaa !23
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t104 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t111 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t111, ptr %l72, !tbaa !27
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t112
  %t117 = load i32, ptr %t116, !tbaa !33
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t121, i32 %t117)
  store i32 %t125, ptr %l78
  br label %bb24
bb24:
  %t126 = load i32, ptr %l11, !tbaa !23
  %t127 = load i32, ptr %l78, !tbaa !23
  %t129 = icmp eq i32 %t127, %t126
  br i1 %t129, label %bb25, label %bb26
bb25:
  %t131 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t131, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t133 = load i64, ptr %l13, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l13, !tbaa !24
  br label %bb20
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l8, !tbaa !24
  br label %bb10
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i1
  %l17 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l10
  br label %bb2
bb2:
  %t16 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t18 = trunc i64 19 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t28 = load i32, ptr %l17, !tbaa !23
  %t29 = icmp eq i32 %t28, 0
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l13, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t42 = load ptr, ptr %l20, !tbaa !29
  %t43 = load i32, ptr %l24, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t44, ptr %l25
  br label %bb10
bb10:
  %t45 = load i32, ptr %l25, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
bb11:
  %t46 = load i32, ptr %l1, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca i32
  %l13 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i64
  %l15 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 71
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = sext i32 %t11 to i64
  %t15 = sext i32 %a2 to i64
  %t18 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t12, i64 %t15)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t18, ptr %l13
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  %t21 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t19, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t20)
  %t22 = extractvalue { i32, i64 } %t21, 1
  %t23 = extractvalue { i32, i64 } %t21, 0
  store i32 %t23, ptr %l15
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb4, label %ok.25, !prof !99
ok.25:
  store i64 %t22, ptr %l14
  br label %bb3
bb3:
  %t26 = load i64, ptr %l14, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l23 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l40 = alloca i32
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l51 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeParam", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/ast:TypeParam", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t10, ptr %t11, ptr %t15)
  store i32 %t19, ptr %l16
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l16, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
bb4:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l17
  br label %bb5
bb5:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l3
  store ptr %l3, ptr %l18, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TypeParam", ptr %t25, i32 0, i32 2
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t32 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t23, ptr %t24, ptr %t28)
  store i32 %t32, ptr %l23
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i32, ptr %l23, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t33, i32 %t34)
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TypeParam", ptr %t35, i32 0, i32 3
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t52, ptr %l32, !tbaa !27
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 %t53
  %t58 = load ptr, ptr %t57, !tbaa !39
  store ptr %l3, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t67 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t60, ptr %t61, ptr %t58)
  store i32 %t67, ptr %l40
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = load i32, ptr %l40, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t68, i32 %t69)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = add i64 %t70, 1
  store i64 %t73, ptr %l5, !tbaa !24
  br label %bb8
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  store ptr %t77, ptr %l45, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  store ptr %t80, ptr %l47, !tbaa !29
  %t82 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t82, ptr %l49
  br label %bb16
bb16:
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t83, { i64, ptr } %t84)
  store i32 %t85, ptr %l50
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l45, !tbaa !29
  %t87 = load i32, ptr %l50, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t88, ptr %l51
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load i32, ptr %l51, !tbaa !23
  store i32 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l19 = alloca [1 x i32]
  %l20 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 22 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l9, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l13
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l9, !tbaa !29
  %t24 = load i32, ptr %l13, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %t23, i32 %t24)
  store { i64, ptr } %t25, ptr %l14
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t26, ptr %l15, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l16, !tbaa !24
  %t29 = load i64, ptr %l16, !tbaa !24
  %t30 = mul i64 %t29, 4
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = load i64, ptr %l16, !tbaa !24
  %t39 = mul i64 %t38, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t35, ptr %t37, i64 %t39, i1 false)
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t40, ptr %l15, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb6:
  %t42 = load i32, ptr %l1, !tbaa !23
  %t44 = insertvalue [1 x i32] undef, i32 %t42, 0
  store [1 x i32] %t44, ptr %l19
  %t45 = mul i64 1, 4
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 1, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l20, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = mul i64 1, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %l19, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuildersOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:fnRow"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i32
  %l28 = alloca i32
  %l29 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l60 = alloca %"compiler/generic:fnRow"
  %l62 = alloca i1
  %l64 = alloca i1
  %l69 = alloca i1
  %l74 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l13
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l15, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l19
  br label %bb3
bb3:
  %t15 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t17 = trunc i64 20 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l26
  br label %bb6
bb5:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l22, !tbaa !23
  br label %bb7
bb6:
  %t29 = load i32, ptr %l26, !tbaa !23
  store i32 %t29, ptr %l22, !tbaa !23
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load i32, ptr %l22, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t32, ptr %l28
  br label %bb8
bb8:
  %t33 = load i32, ptr %l28, !tbaa !23
  store i32 %t33, ptr %l3, !tbaa !23
  %t34 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l29
  br label %bb9
bb9:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l29
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 31
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l32
  br label %bb10
bb10:
  %t41 = load i64, ptr %l32, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb16
bb13:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l39, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t68 = load i64, ptr %l39, !tbaa !24
  store i64 %t68, ptr %l36, !tbaa !24
  br label %bb16
bb16:
  %t69 = load i64, ptr %l36, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb18, label %bb19
bb18:
  br label %bb37
bb19:
  br label %bb20
bb20:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l10, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 31
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t90, i64 %t91)
  store %"compiler/generic:fnRow" %t94, ptr %l60
  br label %bb21
bb21:
  %t95 = load %"compiler/generic:fnRow", ptr %l60
  store %"compiler/generic:fnRow" %t95, ptr %l11
  %t96 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t97)
  store i1 %t99, ptr %l62
  br label %bb22
bb22:
  %t100 = load i1, ptr %l62, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb26
bb24:
  %t103 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Func", ptr %t104, i32 0, i32 9
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  %t112 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t109)
  store i1 %t112, ptr %l69
  br label %bb25
bb25:
  %t113 = load i1, ptr %l69, !tbaa !21
  store i1 %t113, ptr %l64, !tbaa !21
  br label %bb26
bb26:
  %t114 = load i1, ptr %l64, !tbaa !21
  br i1 %t114, label %bb27, label %bb28
bb27:
  br label %bb36
bb28:
  br label %bb29
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l3, !tbaa !23
  %t117 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Func", ptr %t118, i32 0, i32 9
  %t121 = load i32, ptr %t120, !tbaa !23
  %t125 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t115, i32 %t116, i32 %t121, i1 false)
  store i64 %t125, ptr %l74
  br label %bb30
bb30:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t127 = load i64, ptr %l74, !tbaa !24
  %t129 = icmp ne i64 %t127, %t126
  br i1 %t129, label %bb31, label %bb32
bb31:
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t131 = getelementptr %"compiler/generic:fnRow", ptr %l11, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Func", ptr %t132, i32 0, i32 9
  %t135 = load i32, ptr %t134, !tbaa !23
  %t137 = sext i32 %t135 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l4, i64 %t137, i1 true)
  br label %bb34
bb34:
  %t140 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l2, i64 %t140)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t143 = load i64, ptr %l9, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l9, !tbaa !24
  br label %bb17
bb37:
  %t148 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t148, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l14 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumnVec(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t14 = load i1, ptr %l10, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l7, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l18
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = load i32, ptr %l18, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t30, i32 %t31)
  store { i64, ptr } %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %l2, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t38 = icmp eq i64 %t36, 1
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 0
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l23, !tbaa !23
  br label %bb13
bb12:
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t46, ptr %l23, !tbaa !23
  br label %bb13
bb13:
  %t48 = load i32, ptr %l23, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca %"compiler/generic:Context"
  %l19 = alloca i32
  %l21 = alloca i64
  %l25 = alloca { i64, ptr }
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l53 = alloca ptr
  %l57 = alloca %"compiler/generic:varRow"
  %l58 = alloca i32
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l72 = alloca i32
  %l76 = alloca %"compiler/generic:Context"
  %t3 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %t3, ptr %v0, ptr %v1, ptr %t1, i32 %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t3, i64 160, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 160, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %l15, i64 160, i1 false)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l19
  br label %bb2
bb2:
  %t15 = load i32, ptr %l19, !tbaa !23
  store i32 %t15, ptr %l4, !tbaa !23
  %t16 = load i32, ptr %l4, !tbaa !23
  %t18 = call i64 @compiler_2fgeneric_2eCtorOwner(i32 %t16)
  store i64 %t18, ptr %l21
  br label %bb3
bb3:
  %t19 = load i64, ptr %l21, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t22, i32 %a2)
  store { i64, ptr } %t26, ptr %l25
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l4, !tbaa !23
  %t32 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t28, i32 %t29)
  store i64 %t32, ptr %l28
  br label %bb5
bb5:
  %t33 = load i64, ptr %l28, !tbaa !24
  store i64 %t33, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb8:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l35, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb10
bb10:
  %t60 = load i64, ptr %l35, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t61 = load i64, ptr %l32, !tbaa !24
  store i64 %t61, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t62 = load i64, ptr %l11, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb13, label %bb14
bb13:
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l12, !tbaa !24
  %t80 = load ptr, ptr %lp3
  %t81 = getelementptr %"compiler/generic:Context", ptr %t80, i32 0, i32 2
  store ptr %t81, ptr %l53, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l5, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  %t88 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t82, i64 %t83, i64 %t84)
  store %"compiler/generic:varRow" %t88, ptr %l57
  br label %bb16
bb16:
  %t89 = getelementptr %"compiler/generic:varRow", ptr %l57, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  store i32 %t90, ptr %l58, !tbaa !23
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  br i1 %t97, label %bb17, label %bb18
bb17:
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t99, ptr %l64, !tbaa !27
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  store i32 %t105, ptr %l63, !tbaa !23
  br label %bb20
bb18:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t109, i64 %t110, i64 %t111, i64 %t112)
  store i32 %t117, ptr %l72
  br label %bb19
bb19:
  %t118 = load i32, ptr %l72, !tbaa !23
  store i32 %t118, ptr %l63, !tbaa !23
  br label %bb20
bb20:
  %t119 = load ptr, ptr %l53, !tbaa !29
  %t120 = load i32, ptr %l58, !tbaa !23
  %t121 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t119, i32 %t120, i32 %t121)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = add i64 %t122, 1
  store i64 %t125, ptr %l11, !tbaa !24
  br label %bb12
bb23:
  %t127 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t127, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l76, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 0)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca %"compiler/generic:Context"
  %t3 = alloca %"compiler/generic:Context", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t3, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t3, i64 160, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"compiler/names:Entry"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l28 = alloca ptr
  %l32 = alloca %"compiler/names:Entry"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l85 = alloca i32
  %l89 = alloca i1
  %l99 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = shl i64 %t1, 32
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = or i64 %t3, %t4
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__Hbe724e949204db7f54e3bca969c5f391(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, i32 } %t15, 1
  %t17 = extractvalue { i32, i32 } %t15, 0
  store i32 %t17, ptr %l19
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb2, label %ok.19, !prof !99
ok.19:
  store i32 %t16, ptr %l18
  br label %bb1
bb1:
  %t20 = load i32, ptr %l18, !tbaa !23
  store i32 %t20, ptr %l14, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i32 -1, ptr %l14, !tbaa !23
  br label %bb4
bb4:
  %t21 = load i32, ptr %l14, !tbaa !23
  store i32 %t21, ptr %l4, !tbaa !23
  %t22 = load i32, ptr %l4, !tbaa !23
  %t24 = icmp sge i32 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load i32, ptr %l4, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eensureModules(ptr %v0, ptr %t28)
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l28
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l28, !tbaa !29
  %t42 = getelementptr %"compiler/names:Table", ptr %t40, i32 0, i32 0
  %t43 = load i64, ptr %l2, !tbaa !24
  %t46 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t42, i64 %t43)
  store %"compiler/names:Entry" %t46, ptr %l32
  br label %bb10
bb10:
  %t47 = load %"compiler/names:Entry", ptr %l32
  store %"compiler/names:Entry" %t47, ptr %l5
  store i32 2, ptr %l6
  store i32 0, ptr %l7, !tbaa !23
  %t49 = getelementptr %"compiler/names:Entry", ptr %l5, i32 0, i32 4
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l8, !tbaa !29
  %t52 = load ptr, ptr %l8, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb11, label %bb12
bb11:
  store i32 0, ptr %l6
  %t59 = load ptr, ptr %l8, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TypeDecl", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb13, label %bb14
bb12:
  br label %bb50
bb13:
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr %"compiler/ast:TypeDecl", ptr %t68, i32 0, i32 3
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l9, !tbaa !29
  %t73 = load ptr, ptr %l9, !tbaa !29
  store ptr %t73, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t74 = load ptr, ptr %l45, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb15, label %bb16
bb14:
  br label %bb46
bb15:
  %t77 = load ptr, ptr %l45, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 5}
  %t80 = icmp eq i64 %t78, 0
  store i1 %t80, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 0, ptr %l6
  br label %bb45
bb20:
  %t83 = load ptr, ptr %l9, !tbaa !29
  store ptr %t83, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t84 = load ptr, ptr %l50, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb21, label %bb22
bb21:
  %t87 = load ptr, ptr %l50, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 5}
  %t90 = icmp eq i64 %t88, 1
  store i1 %t90, ptr %l51, !tbaa !21
  br label %bb22
bb22:
  %t91 = load i1, ptr %l51, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i32 1, ptr %l6
  br label %bb45
bb26:
  %t93 = load ptr, ptr %l9, !tbaa !29
  store ptr %t93, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t94 = load ptr, ptr %l55, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l55, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 5}
  %t100 = icmp eq i64 %t98, 2
  store i1 %t100, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l56, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 3, ptr %l6
  br label %bb45
bb32:
  %t103 = load ptr, ptr %l9, !tbaa !29
  store ptr %t103, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t104 = load ptr, ptr %l60, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb33, label %bb34
bb33:
  %t107 = load ptr, ptr %l60, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 5}
  %t110 = icmp eq i64 %t108, 3
  store i1 %t110, ptr %l61, !tbaa !21
  br label %bb34
bb34:
  %t111 = load i1, ptr %l61, !tbaa !21
  br i1 %t111, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i32 4, ptr %l6
  br label %bb45
bb38:
  %t113 = load ptr, ptr %l9, !tbaa !29
  store ptr %t113, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t114 = load ptr, ptr %l65, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb39, label %bb40
bb39:
  %t117 = load ptr, ptr %l65, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 5}
  %t120 = icmp eq i64 %t118, 4
  store i1 %t120, ptr %l66, !tbaa !21
  br label %bb40
bb40:
  %t121 = load i1, ptr %l66, !tbaa !21
  br i1 %t121, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i32 5, ptr %l6
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_799e213f453ad9fb_869f4f41e63ea5ff)
  unreachable
bb45:
  br label %bb46
bb46:
  %t123 = load ptr, ptr %l8, !tbaa !29
  %t125 = getelementptr %"compiler/ast:TypeDecl", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb47, label %bb48
bb47:
  %t132 = load ptr, ptr %l8, !tbaa !29
  %t134 = getelementptr %"compiler/ast:TypeDecl", ptr %t132, i32 0, i32 1
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t139 = trunc i64 %t137 to i32
  store i32 %t139, ptr %l7, !tbaa !23
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i64, ptr %l1, !tbaa !24
  %t145 = getelementptr %"compiler/names:Entry", ptr %l5, i32 0, i32 0
  %t146 = load i32, ptr %t145, !tbaa !23
  %t147 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t148 = load i32, ptr %l7, !tbaa !23
  %t150 = inttoptr i64 0 to ptr
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %t150, ptr %t143, i64 %t144, i32 %t146, i32 %t147, i32 %t148)
  store i32 %t156, ptr %l85
  br label %bb51
bb51:
  %t157 = load i32, ptr %l85, !tbaa !23
  store i32 %t157, ptr %l4, !tbaa !23
  %t158 = load ptr, ptr %l8, !tbaa !29
  %t160 = icmp eq ptr %t158, null
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb52, label %bb53
bb52:
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/ast:TypeDecl", ptr %t164, i32 0, i32 4
  %t167 = load i32, ptr %t166, !range !{i32 0, i32 3}
  %t169 = trunc i64 2 to i32
  %t170 = icmp eq i32 %t167, %t169
  store i1 %t170, ptr %l89, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb54
bb54:
  %t172 = load i1, ptr %l89, !tbaa !21
  br i1 %t172, label %bb55, label %bb56
bb55:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkUnique(ptr %v0, ptr %t175, i32 %t176)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t179 = load ptr, ptr %l8, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb59, label %bb60
bb59:
  %t185 = load ptr, ptr %l8, !tbaa !29
  %t187 = getelementptr %"compiler/ast:TypeDecl", ptr %t185, i32 0, i32 5
  %t188 = load i1, ptr %t187, !tbaa !21
  store i1 %t188, ptr %l99, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb61
bb61:
  %t190 = load i1, ptr %l99, !tbaa !21
  br i1 %t190, label %bb62, label %bb63
bb62:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/generic:Program", ptr %t191, i32 0, i32 2
  %t194 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkPacked(ptr %v0, ptr %t193, i32 %t194)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t197 = load ptr, ptr %l8, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb66, label %bb67
bb66:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l1, !tbaa !24
  %t205 = load ptr, ptr %l8, !tbaa !29
  %t209 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEndsHeld(ptr %v0, ptr %v0, ptr %t203, i64 %t204, ptr %t205)
  store i1 %t209, ptr %l112
  br label %bb68
bb67:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb69
bb68:
  %t210 = load i1, ptr %l112, !tbaa !21
  store i1 %t210, ptr %l108, !tbaa !21
  br label %bb69
bb69:
  %t211 = load i1, ptr %l108, !tbaa !21
  br i1 %t211, label %bb70, label %bb71
bb70:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkEnds(ptr %v0, ptr %t214, i32 %t215)
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 4
  %t221 = load i64, ptr %l3, !tbaa !24
  %t222 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__H7ddd7dd10a6733ce5265405d8e7c8faa(ptr %v0, ptr %t220, i64 %t221, i32 %t222)
  br label %bb74
bb74:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 14
  %t229 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  br label %bb75
bb75:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/generic:Program", ptr %t232, i32 0, i32 15
  %t235 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t234, i64 %t235)
  br label %bb76
bb76:
  %t238 = load i32, ptr %l4, !tbaa !23
  store i32 %t238, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i32
  %l30 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i64
  %l62 = alloca %"compiler/generic:fnRow"
  %l70 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i32
  %l90 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t3)
  br label %bb2
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l19
  br label %bb3
bb3:
  %t12 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l26
  br label %bb6
bb5:
  %t24 = load i32, ptr %l1, !tbaa !23
  store i32 %t24, ptr %l22, !tbaa !23
  br label %bb7
bb6:
  %t26 = load i32, ptr %l26, !tbaa !23
  store i32 %t26, ptr %l22, !tbaa !23
  br label %bb7
bb7:
  %t27 = load i32, ptr %l22, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 40
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l30
  br label %bb8
bb8:
  %t33 = load i64, ptr %l30, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb11:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l37, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb13
bb13:
  %t60 = load i64, ptr %l37, !tbaa !24
  store i64 %t60, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l34, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb17:
  br label %bb18
bb18:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 40
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l58
  br label %bb19
bb19:
  %t87 = load i64, ptr %l58, !tbaa !24
  store i64 %t87, ptr %l11, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 31
  %t91 = load i64, ptr %l11, !tbaa !24
  %t94 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s2, ptr %t90, i64 %t91)
  store %"compiler/generic:fnRow" %t94, ptr %l62
  br label %bb20
bb20:
  %t95 = getelementptr %"compiler/generic:fnRow", ptr %l62, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Func", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %t98, !tbaa !23
  %t103 = icmp ne i32 %t99, %a2
  br i1 %t103, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb22:
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 41
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t107, i64 %t108)
  store i64 %t111, ptr %l70
  br label %bb24
bb24:
  %t112 = load i64, ptr %l70, !tbaa !24
  %t113 = trunc i64 %t112 to i32
  store i32 %t113, ptr %l12, !tbaa !23
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l12, !tbaa !23
  %t120 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t116, i32 %t117)
  store ptr %t120, ptr %l75
  br label %bb25
bb25:
  %t121 = load ptr, ptr %l75, !tbaa !29
  store ptr %t121, ptr %l13, !tbaa !29
  %t122 = load ptr, ptr %l13, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb28
bb27:
  %t126 = load ptr, ptr %l13, !tbaa !29
  %t128 = getelementptr %"compiler/ast:TypeDecl", ptr %t126, i32 0, i32 3
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  store i1 %t131, ptr %l78, !tbaa !21
  br label %bb28
bb28:
  %t133 = load i1, ptr %l78, !tbaa !21
  br i1 %t133, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb30:
  br label %bb31
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l82, !tbaa !29
  %t135 = load i32, ptr %l12, !tbaa !23
  store i32 %t135, ptr %l83, !tbaa !23
  %t136 = load ptr, ptr %l13, !tbaa !29
  %t138 = getelementptr %"compiler/ast:TypeDecl", ptr %t136, i32 0, i32 3
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  br i1 %t141, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e3e3caa307fb777e_fe02cb9db66a417a)
  unreachable
bb33:
  br label %bb34
bb34:
  %t143 = load ptr, ptr %l13, !tbaa !29
  %t145 = getelementptr %"compiler/ast:TypeDecl", ptr %t143, i32 0, i32 3
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i32, ptr %l4, !tbaa !23
  %t148 = load ptr, ptr %l82, !tbaa !29
  %t149 = load i32, ptr %l83, !tbaa !23
  %t152 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etraitReaches(ptr %v0, ptr %v0, ptr %t148, i32 %t149, ptr %t146, i32 %t147)
  store i1 %t152, ptr %l90
  br label %bb35
bb35:
  %t153 = load i1, ptr %l90, !tbaa !21
  br i1 %t153, label %bb36, label %bb37
bb36:
  %t154 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l3, i64 %t154)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l9, !tbaa !24
  br label %bb15
bb41:
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i1
  %l27 = alloca ptr
  %l32 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l49 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edescDecl(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l5, !tbaa !23
  %t9 = icmp slt i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t17, ptr %l16
  br label %bb5
bb5:
  %t18 = load i32, ptr %l16, !tbaa !23
  store i32 %t18, ptr %l6, !tbaa !23
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l17
  br label %bb6
bb6:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i32 %a2)
  br label %bb7
bb7:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t28 = icmp eq i64 %t24, %t25
  br i1 %t28, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t34 = icmp eq i64 %t30, %t31
  store i1 %t34, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  store ptr %l7, ptr %l27, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l6, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t39, i32 %t40, i64 %a3)
  store i32 %t45, ptr %l32
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = load i32, ptr %l32, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t46, i32 %t47)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t48 = load i64, ptr %l1, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t52 = icmp ne i64 %t48, %t49
  br i1 %t52, label %bb16, label %bb17
bb16:
  store ptr %l7, ptr %l36, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l6, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t56, i32 %t57, i64 %a4)
  store i32 %t62, ptr %l41
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t63 = load ptr, ptr %l36, !tbaa !29
  %t64 = load i32, ptr %l41, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t63, i32 %t64)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l42, !tbaa !29
  %t66 = load i32, ptr %l5, !tbaa !23
  store i32 %t66, ptr %l43, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l45, !tbaa !29
  %t71 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t71, ptr %l47
  br label %bb21
bb21:
  %t72 = load ptr, ptr %l45, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t72, { i64, ptr } %t73)
  store i32 %t74, ptr %l48
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i32, ptr %l43, !tbaa !23
  %t77 = load i32, ptr %l48, !tbaa !23
  %t78 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t75, i32 %t76, i32 %t77)
  store i32 %t78, ptr %l49
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t79 = load i32, ptr %l49, !tbaa !23
  store i32 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEndsHeld(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %t1, i32 0, i32 4
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 3}
  %t6 = trunc i64 2 to i32
  %t7 = icmp eq i32 %t4, %t6
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/ast:TypeDecl", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TypeDecl", ptr %t19, i32 0, i32 3
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  store i1 %t24, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l13, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb10
bb8:
  %t31 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %a0, i64 %a1)
  store i1 %t31, ptr %l20
  br label %bb9
bb9:
  %t32 = load i1, ptr %l20, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TypeDecl", ptr %t37, i32 0, i32 3
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 5}
  %t49 = icmp eq i64 %t47, 0
  store i1 %t49, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t50 = load i1, ptr %l27, !tbaa !21
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr { i64, [6 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { ptr }, ptr %t53, i32 0, i32 0
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/ast:StructBody", ptr %t57, i32 0, i32 4
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp sgt i64 %t62, 0
  store i1 %t64, ptr %l25, !tbaa !21
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4139559e1c186529_46f8c3a78fef470d)
  unreachable
bb24:
  %t66 = load i1, ptr %l25, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentriesOf(ptr %v0, ptr %v1, ptr %s0, ptr %a0, i32 %a1, ptr %a2, ptr %l3)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOfType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l31 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %s0, ptr %t3, i32 %t4, ptr %l2)
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l8, !tbaa !29
  %t10 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } %t12)
  store i32 %t13, ptr %l11
  br label %bb4
bb4:
  %t14 = load i32, ptr %l11, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb8:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i32, ptr %l21, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t31, i32 %t32)
  store { i64, ptr } %t33, ptr %l22
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t37 = icmp sgt i64 %t35, 1
  store i1 %t37, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l15, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  store i32 %t43, ptr %l27, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l31
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i32, ptr %l27, !tbaa !23
  %t53 = load i32, ptr %l31, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNameErrVal(ptr %v0, ptr %t51, i32 %t52, i32 %t53)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t54 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca i1
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 19
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t11 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  %t12 = extractvalue { i32, i1 } %t11, 1
  %t13 = extractvalue { i32, i1 } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load i1, ptr %l9, !tbaa !21
  store i1 %t16, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i1, ptr %l3, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorDecl(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t13 = icmp sle i64 0, 1152921504606846975
  br i1 %t13, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_e11f9621bf6c2a4e_ffbbdf781a3c7e7a)
  unreachable
bb6:
  %t15 = mul i64 0, 8
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e11f9621bf6c2a4e_ffbbdf781a3c7e7a)
  unreachable
bb8:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 12}
  %t26 = icmp eq i64 %t24, 6
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t30, i32 0, i32 3
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t34, ptr %l12, !tbaa !27
  br label %bb23
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t36 = icmp sge i64 0, 0
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = icmp sle i64 0, 1152921504606846975
  br i1 %t38, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_882f12ba06d2ce43_a9b5d482619655cf)
  unreachable
bb20:
  %t40 = mul i64 0, 8
  %t41 = insertvalue { i64, ptr } undef, i64 0, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t42, ptr %l12, !tbaa !27
  br label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_882f12ba06d2ce43_a9b5d482619655cf)
  unreachable
bb22:
  call void @__olang_check_failed(ptr @olang_loc_76207083d0f68b9f_74e05cac4bc21103)
  unreachable
bb23:
  %t44 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorDecl(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t13 = icmp sle i64 0, 2305843009213693951
  br i1 %t13, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_de4c5053baae2eb0_7e20459b6f7605c4)
  unreachable
bb6:
  %t15 = mul i64 0, 4
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_de4c5053baae2eb0_7e20459b6f7605c4)
  unreachable
bb8:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 12}
  %t26 = icmp eq i64 %t24, 6
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t30, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t34, ptr %l12, !tbaa !27
  br label %bb23
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t36 = icmp sge i64 0, 0
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = icmp sle i64 0, 2305843009213693951
  br i1 %t38, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_16d3c7726565025d_3b40f943fadf33d1)
  unreachable
bb20:
  %t40 = mul i64 0, 4
  %t41 = insertvalue { i64, ptr } undef, i64 0, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t42, ptr %l12, !tbaa !27
  br label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_16d3c7726565025d_3b40f943fadf33d1)
  unreachable
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7b14d935e96e16e5_1eebf856974cc301)
  unreachable
bb23:
  %t44 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsHeld(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l51 = alloca i1
  %l55 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l16
  br label %bb4
bb4:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l3
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l20
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l27, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t31
  %t36 = load i32, ptr %t35, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %t36)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb6
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t52, ptr %l38
  br label %bb13
bb13:
  %t53 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t53, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t66, ptr %l45, !tbaa !27
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i32, ptr %t70, i64 %t67
  %t72 = load i32, ptr %t71, !tbaa !33
  store i32 %t72, ptr %l11, !tbaa !23
  %t74 = load i32, ptr %l11, !tbaa !23
  %t75 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t78 = icmp eq i32 %t74, %t75
  br i1 %t78, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb21
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l11, !tbaa !23
  %t85 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentryHeld(ptr %v0, ptr %s0, ptr %t80, i32 %t81, ptr %l3)
  store i1 %t85, ptr %l55
  br label %bb20
bb20:
  %t86 = load i1, ptr %l55, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l51, !tbaa !21
  br label %bb21
bb21:
  %t89 = load i1, ptr %l51, !tbaa !21
  br i1 %t89, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l9, !tbaa !24
  br label %bb14
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb10
bb8:
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = load i32, ptr %l18, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load i32, ptr %l19, !range !{i32 0, i32 6}
  %t35 = trunc i64 4 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l12, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l27
  br label %bb13
bb12:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb15
bb13:
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t48 = load i32, ptr %l27, !tbaa !23
  %t49 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eextends(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t49, ptr %l28
  br label %bb14
bb14:
  %t50 = load i1, ptr %l28, !tbaa !21
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t51 = load i1, ptr %l22, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l27 = alloca i32
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eensureModules(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 26
  %t9 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %a1)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l10
  br label %bb2
bb2:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  %t16 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t16, ptr %rv
  br label %ret
bb5:
  %t17 = load i64, ptr %l6, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l14, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/load:Loader", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t30 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v2, ptr %t26, { i64, ptr } %a2)
  store i32 %t30, ptr %l19
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = load i32, ptr %l19, !tbaa !23
  %t34 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t31, i64 %t32, i32 %t33)
  store i64 %t34, ptr %l20
  br label %bb7
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp slt i64 %t36, 0
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t41 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t41, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t42, i64 %t43, i64 %t44)
  store i32 %t48, ptr %l27
  br label %bb11
bb11:
  %t49 = load i32, ptr %l27, !tbaa !23
  %t50 = insertvalue { i32, i32 } zeroinitializer, i32 %t49, 1
  store { i32, i32 } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFirstUnmet(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:varRow"
  %l11 = alloca i32
  %l12 = alloca %"compiler/generic:Unmet"
  %l16 = alloca { i64, ptr }
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l51 = alloca %"compiler/generic:varRow"
  %l55 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l67 = alloca i32
  %l71 = alloca i1
  %l74 = alloca { i64, ptr }
  %l78 = alloca %"compiler/generic:Unmet"
  %l87 = alloca %"compiler/generic:Unmet"
  %l91 = alloca %"compiler/generic:Unmet"
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Unmet"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l2, !tbaa !23
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %t4)
  store { i64, ptr } %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb35
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  store i64 %t59, ptr %l43, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l46
  br label %bb12
bb12:
  %t65 = load i64, ptr %l43, !tbaa !24
  %t66 = load i64, ptr %l46, !tbaa !24
  %t67 = icmp sge i64 %t65, %t66
  br i1 %t67, label %bb13, label %bb14
bb13:
  br label %bb35
bb14:
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l1, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t75 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t69, i64 %t70, i64 %t71)
  store %"compiler/generic:varRow" %t75, ptr %l51
  br label %bb16
bb16:
  %t76 = load %"compiler/generic:varRow", ptr %l51
  store %"compiler/generic:varRow" %t76, ptr %l10
  %t77 = getelementptr %"compiler/generic:varRow", ptr %l10, i32 0, i32 3
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = icmp eq i32 %t78, %t79
  br i1 %t82, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb20
bb18:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l58, !tbaa !27
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i32, ptr %t91, i64 %t88
  %t93 = load i32, ptr %t92, !tbaa !33
  %t96 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t86, i32 %t93)
  store i1 %t96, ptr %l61
  br label %bb19
bb19:
  %t97 = load i1, ptr %l61, !tbaa !21
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l55, !tbaa !21
  br label %bb20
bb20:
  %t100 = load i1, ptr %l55, !tbaa !21
  br i1 %t100, label %bb21, label %bb22
bb21:
  br label %bb34
bb22:
  br label %bb23
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/generic:varRow", ptr %l10, i32 0, i32 3
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = load i64, ptr %l1, !tbaa !24
  %t105 = load i32, ptr %l2, !tbaa !23
  %t110 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t101, i32 %t103, i64 %t104, i32 %t105)
  store i32 %t110, ptr %l67
  br label %bb24
bb24:
  %t111 = load i32, ptr %l67, !tbaa !23
  store i32 %t111, ptr %l11, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l11, !tbaa !23
  %t118 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t114, i32 %t115)
  store i1 %t118, ptr %l71
  br label %bb25
bb25:
  %t119 = load i1, ptr %l71, !tbaa !21
  %t120 = xor i1 %t119, true
  br i1 %t120, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t123, ptr %l74, !tbaa !27
  %t124 = load i64, ptr %l9, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  %t130 = load i32, ptr %l11, !tbaa !23
  %t134 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t122, i32 %t129, i32 %t130, i1 true, i64 0)
  store %"compiler/generic:Unmet" %t134, ptr %l78
  br label %bb29
bb29:
  %t135 = load %"compiler/generic:Unmet", ptr %l78
  store %"compiler/generic:Unmet" %t135, ptr %l12
  %t136 = getelementptr %"compiler/generic:Unmet", ptr %l12, i32 0, i32 0
  %t137 = load i64, ptr %t136, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = getelementptr %"compiler/generic:Unmet", ptr %l12, i32 0, i32 1
  %t143 = load i32, ptr %t142, !tbaa !23
  %t144 = getelementptr %"compiler/generic:Unmet", ptr %l12, i32 0, i32 2
  %t145 = load i32, ptr %t144, !tbaa !23
  %t146 = getelementptr %"compiler/generic:Unmet", ptr %l12, i32 0, i32 3
  %t147 = load i1, ptr %t146, !tbaa !21
  %t148 = getelementptr %"compiler/generic:Unmet", ptr %l12, i32 0, i32 4
  %t149 = load i1, ptr %t148, !tbaa !21
  %t150 = getelementptr %"compiler/generic:Unmet", ptr %l12, i32 0, i32 5
  %t151 = load i1, ptr %t150, !tbaa !21
  %t158 = call %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %s6, i64 %t141, i32 %t143, i32 %t145, i1 %t147, i1 %t149, i1 %t151)
  store %"compiler/generic:Unmet" %t158, ptr %l87
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  %t159 = load %"compiler/generic:Unmet", ptr %l87
  store %"compiler/generic:Unmet" %t159, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t160 = load i64, ptr %l8, !tbaa !24
  %t163 = add i64 %t160, 1
  store i64 %t163, ptr %l8, !tbaa !24
  br label %bb8
bb35:
  %t165 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2eUnmet_2emet()
  store %"compiler/generic:Unmet" %t165, ptr %l91
  br label %bb36
bb36:
  %t166 = load %"compiler/generic:Unmet", ptr %l91
  store %"compiler/generic:Unmet" %t166, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Unmet", ptr %rv
  ret %"compiler/generic:Unmet" %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l12 = alloca i32
  %l19 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l35 = alloca i64
  %l39 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i1
  %l63 = alloca i1
  %l69 = alloca i1
  %l73 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l86 = alloca i1
  %l88 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l12
  br label %bb4
bb4:
  %t13 = load i32, ptr %l12, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = icmp ne i32 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l3, !tbaa !23
  %t22 = load i32, ptr %l2, !tbaa !23
  %t26 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t20, i32 %t21, i32 %t22)
  store i1 %t26, ptr %l19
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t27 = load i1, ptr %l19, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t30, i32 %t31)
  store i1 %t34, ptr %l23
  br label %bb9
bb9:
  %t35 = load i1, ptr %l23, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l29
  br label %bb12
bb12:
  %t45 = load i1, ptr %l29, !tbaa !21
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l35
  br label %bb17
bb17:
  %t57 = load i64, ptr %l35, !tbaa !24
  store i64 %t57, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t60, i32 %t61)
  store i64 %t64, ptr %l39
  br label %bb18
bb18:
  %t65 = load i64, ptr %l39, !tbaa !24
  store i64 %t65, ptr %l5, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l43
  br label %bb19
bb19:
  %t73 = load i1, ptr %l43, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb23
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l48
  br label %bb22
bb22:
  %t81 = load i1, ptr %l48, !tbaa !21
  store i1 %t81, ptr %l44, !tbaa !21
  br label %bb23
bb23:
  %t82 = load i1, ptr %l44, !tbaa !21
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l52
  br label %bb26
bb25:
  br label %bb37
bb26:
  %t90 = load i1, ptr %l52, !tbaa !21
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l57
  br label %bb29
bb28:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb30
bb29:
  %t98 = load i1, ptr %l57, !tbaa !21
  store i1 %t98, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t99 = load i1, ptr %l53, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb31, label %bb32
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t103 = load i64, ptr %l4, !tbaa !24
  %t104 = load i64, ptr %l5, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  br i1 %t107, label %bb34, label %bb35
bb34:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = icmp sge i64 %t109, 32
  store i1 %t111, ptr %l63, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb36
bb36:
  %t113 = load i1, ptr %l63, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
bb37:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l1, !tbaa !23
  %t120 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t116, i32 %t117)
  store i1 %t120, ptr %l69
  br label %bb38
bb38:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %l2, !tbaa !23
  %t127 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t123, i32 %t124)
  store i1 %t127, ptr %l73
  br label %bb39
bb39:
  %t128 = load i1, ptr %l69, !tbaa !21
  %t129 = load i1, ptr %l73, !tbaa !21
  %t130 = icmp eq i1 %t128, %t129
  br i1 %t130, label %bb40, label %bb41
bb40:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t133 = load i64, ptr %l5, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  store i1 %t136, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l1, !tbaa !23
  %t144 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l81
  br label %bb43
bb43:
  %t145 = load i1, ptr %l81, !tbaa !21
  br i1 %t145, label %bb44, label %bb45
bb44:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l2, !tbaa !23
  %t152 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t148, i32 %t149)
  store i1 %t152, ptr %l86
  br label %bb46
bb45:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb47
bb46:
  %t153 = load i1, ptr %l86, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l82, !tbaa !21
  br label %bb47
bb47:
  %t156 = load i1, ptr %l82, !tbaa !21
  br i1 %t156, label %bb48, label %bb49
bb48:
  %t157 = load i64, ptr %l4, !tbaa !24
  %t158 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  store i1 %t161, ptr %l88, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t163 = load i1, ptr %l88, !tbaa !21
  store i1 %t163, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i32
  %l20 = alloca %"compiler/generic:fnRow"
  %l23 = alloca %"compiler/generic:Context"
  %l27 = alloca { i64, ptr }
  %l30 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca %"compiler/generic:varRow"
  %l60 = alloca i32
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l74 = alloca i32
  %l78 = alloca %"compiler/generic:Context"
  %s0 = alloca %olang.scope
  %t20 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t1)
  store i64 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t5, i64 %t6)
  store i32 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 31
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s0, ptr %t12, i64 %t13)
  store %"compiler/generic:fnRow" %t16, ptr %l20
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/generic:fnRow", ptr %l20, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t20, ptr %v1, i64 %t18, i64 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t20, i64 160, i1 false)
  br label %bb4
bb4:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 160, i64 8)
  store ptr %t23, ptr %lp4
  %t24 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %l23, i64 160, i1 false)
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t27, i32 %a2)
  store { i64, ptr } %t31, ptr %l27
  br label %bb5
bb5:
  %t32 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t33, i64 %t34)
  store i64 %t37, ptr %l30
  br label %bb6
bb6:
  %t38 = load i64, ptr %l30, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l11, !tbaa !24
  %t85 = load ptr, ptr %lp4
  %t86 = getelementptr %"compiler/generic:Context", ptr %t85, i32 0, i32 2
  store ptr %t86, ptr %l55, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t93 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t87, i64 %t88, i64 %t89)
  store %"compiler/generic:varRow" %t93, ptr %l59
  br label %bb17
bb17:
  %t94 = getelementptr %"compiler/generic:varRow", ptr %l59, i32 0, i32 1
  %t95 = load i32, ptr %t94, !tbaa !23
  store i32 %t95, ptr %l60, !tbaa !23
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t104, ptr %l66, !tbaa !27
  %t105 = load i64, ptr %l11, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 %t105
  %t110 = load i32, ptr %t109, !tbaa !33
  store i32 %t110, ptr %l65, !tbaa !23
  br label %bb21
bb19:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i64, ptr %l3, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t114, i64 %t115, i64 %t116, i64 %t117)
  store i32 %t122, ptr %l74
  br label %bb20
bb20:
  %t123 = load i32, ptr %l74, !tbaa !23
  store i32 %t123, ptr %l65, !tbaa !23
  br label %bb21
bb21:
  %t124 = load ptr, ptr %l55, !tbaa !29
  %t125 = load i32, ptr %l60, !tbaa !23
  %t126 = load i32, ptr %l65, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t124, i32 %t125, i32 %t126)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t127 = load i64, ptr %l10, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l10, !tbaa !24
  br label %bb13
bb24:
  %t132 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l78, ptr %t132, i64 160, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l78, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/generic:fnRow"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/generic:fnRow"
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l30 = alloca i32
  %l34 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca i1
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 31
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/generic:fnRow" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:fnRow", ptr %l13
  store %"compiler/generic:fnRow" %t8, ptr %l2
  %t9 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t10, ptr %l3
  store ptr %l3, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 10
  %t17 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t16, i64 %t18)
  store ptr %t21, ptr %l20
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t26 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t26, { i64, ptr } %t25)
  br label %bb4
bb4:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 58)
  br label %bb5
bb5:
  %t29 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Func", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %t39, i64 %t40)
  store i32 %t43, ptr %l30
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t44 = load i32, ptr %l30, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb9
bb9:
  %t52 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb10, label %bb11
bb10:
  store ptr %l3, ptr %l37, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l38, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  store ptr %t60, ptr %l40, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l44
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t68 = load ptr, ptr %l40, !tbaa !29
  %t69 = load i32, ptr %l44, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l45
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = load i32, ptr %l45, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l46
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l46, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t74, { i64, ptr } %t75)
  br label %bb15
bb15:
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 46)
  br label %bb17
bb17:
  br label %bb18
bb18:
  store ptr %l3, ptr %l48, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t77, i32 %t82)
  store { i64, ptr } %t85, ptr %l52
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l52, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t86, { i64, ptr } %t87)
  br label %bb20
bb20:
  store i64 -3750763034362895579, ptr %l5, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s3, ptr %l3)
  store { i64, ptr } %t89, ptr %l54
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t90, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l8, !tbaa !24
  %t97 = sub i64 %t96, 1
  store i64 %t97, ptr %l58, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t99 = icmp slt i64 %t98, 2147483648
  %t100 = load i64, ptr %l7, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  %t104 = and i1 %t99, %t101
  store i1 %t104, ptr %l61, !tbaa !21
  br label %bb22
bb22:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t113 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t113, ptr %l66, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i8, ptr %t117, i64 %t114
  %t119 = load i8, ptr %t118, !tbaa !32
  %t121 = load i64, ptr %l5, !tbaa !24
  %t125 = zext i8 %t119 to i64
  %t128 = xor i64 %t121, %t125
  %t130 = mul i64 %t128, 1099511628211
  store i64 %t130, ptr %l5, !tbaa !24
  br label %bb26
bb26:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l7, !tbaa !24
  br label %bb22
bb27:
  call void @__olang_scope_close(ptr %s3)
  %t137 = load i64, ptr %l5, !tbaa !24
  %t139 = and i64 %t137, 4611686018427387903
  call void @__olang_scope_close(ptr %s0)
  store i64 %t139, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca i64
  %l13 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efnsIn(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 36
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = sext i32 %a2 to i64
  %t14 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t8, i64 %t11)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  %t17 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t15, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t16)
  %t18 = extractvalue { i32, i64 } %t17, 1
  %t19 = extractvalue { i32, i64 } %t17, 0
  store i32 %t19, ptr %l13
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb4, label %ok.21, !prof !99
ok.21:
  store i64 %t18, ptr %l12
  br label %bb3
bb3:
  %t22 = load i64, ptr %l12, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i64, ptr %l5, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFuncDescriptor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l9 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i32
  %l30 = alloca i32
  %l37 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edescDecl(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t9 = icmp slt i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t19, i64 %t20)
  store i32 %t23, ptr %l19
  br label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t24, i64 %t25, i32 %t26)
  store i32 %t30, ptr %l23
  br label %bb8
bb7:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l16, !tbaa !23
  br label %bb9
bb8:
  %t32 = load i32, ptr %l23, !tbaa !23
  store i32 %t32, ptr %l16, !tbaa !23
  br label %bb9
bb9:
  %t33 = load i32, ptr %l16, !tbaa !23
  store i32 %t33, ptr %l5, !tbaa !23
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t38 = icmp ne i32 %t34, %t35
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i32, ptr %l3, !tbaa !23
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderSig(ptr %v0, ptr %t40, i64 %t41, i32 %t42)
  store i32 %t46, ptr %l30
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t47 = load i32, ptr %l30, !tbaa !23
  store i32 %t47, ptr %l5, !tbaa !23
  br label %bb13
bb13:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t52 = icmp eq i32 %t48, %t49
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t54, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnKey(ptr %v0, ptr %t56, i64 %t57)
  store i64 %t60, ptr %l37
  br label %bb17
bb17:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 33
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t64, i64 %t65, i64 %t66)
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l42, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  store i32 %t71, ptr %l43, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  store ptr %t74, ptr %l45, !tbaa !29
  %t75 = load i32, ptr %l5, !tbaa !23
  store i32 %t75, ptr %l46, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l48, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t81, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t83, ptr %l51
  br label %bb19
bb19:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load ptr, ptr %l48, !tbaa !29
  %t86 = load i32, ptr %l51, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t85, i32 %t86, i64 %t84)
  store i32 %t88, ptr %l53
  br label %bb20
bb20:
  %t89 = mul i64 2, 4
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 2, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i32, ptr %t95, i64 0
  store i32 %t93, ptr %t96, !tbaa !33
  %t97 = load i32, ptr %l53, !tbaa !23
  %t98 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 1
  store i32 %t97, ptr %t100, !tbaa !33
  %t101 = load ptr, ptr %l45, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t101, { i64, ptr } %t102)
  store i32 %t103, ptr %l55
  br label %bb21
bb21:
  %t104 = load ptr, ptr %l42, !tbaa !29
  %t105 = load i32, ptr %l43, !tbaa !23
  %t106 = load i32, ptr %l55, !tbaa !23
  %t107 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t104, i32 %t105, i32 %t106)
  store i32 %t107, ptr %l56
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i32, ptr %l56, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenElem(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 21
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, i64 } %t12, 1
  %t14 = extractvalue { i32, i64 } %t12, 0
  store i32 %t14, ptr %l10
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16, !prof !99
ok.16:
  store i64 %t13, ptr %l9
  br label %bb2
bb2:
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %l5, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 5
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = sext i32 %t23 to i64
  %t25 = load ptr, ptr %l10, !tbaa !29
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3993e9d21a27b6abd527556382000d9e(ptr %v0, ptr %t25, i64 %t24)
  store i1 %t27, ptr %l16
  br label %bb5
bb5:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l8, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHeld(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eheld(ptr %v0, ptr %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i64
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t3, i32 %t4, i32 %t5)
  store i32 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDepth(ptr %v0, ptr %t13, i32 %t14)
  store i64 %t17, ptr %l12
  br label %bb2
bb2:
  %t18 = load i64, ptr @G_2ecompiler_2fgeneric_2eMaxDepth, !tbaa !24
  %t20 = add i64 %t18, 1
  %t21 = load i64, ptr %l12, !tbaa !24
  %t23 = icmp sgt i64 %t21, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunbounded(ptr %v0, ptr %t25, i32 %t26)
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
bb6:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = icmp ne i32 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 60
  %t38 = getelementptr %"compiler/generic:Origin", ptr %t37, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 61
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hf7241cd153db7dbb97afc4b39a688af4(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l29
  br label %bb12
bb11:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t54 = load i1, ptr %l25, !tbaa !21
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 61
  %t58 = load i32, ptr %l3, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 60
  %t62 = load %"compiler/generic:Origin", ptr %t61
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H52a70901e2e6ceea4e17edd807bbe24b(ptr %v0, ptr %t57, i32 %t58, %"compiler/generic:Origin" %t62)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t66 = load i32, ptr %l3, !tbaa !23
  store i32 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/generic:instance"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 53
  %t7 = call %"compiler/generic:instance" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eAt__Hf3965267bb92d0ee7aeaa2339e2e46fa(ptr %v0, ptr %s0, ptr %t3, i64 %a1)
  store %"compiler/generic:instance" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/generic:instance", ptr %l5, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/generic:instance"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Origin"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 53
  %t7 = call %"compiler/generic:instance" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eAt__Hf3965267bb92d0ee7aeaa2339e2e46fa(ptr %v0, ptr %s0, ptr %t3, i64 %a1)
  store %"compiler/generic:instance" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/generic:instance", ptr %l5, i32 0, i32 5
  %t9 = load %"compiler/generic:Origin", ptr %t8
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/generic:Origin" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Origin", ptr %rv
  ret %"compiler/generic:Origin" %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeNamed(ptr %v0, ptr %s0, ptr %a0, i32 %a1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 20
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, i1 } %t12, 1
  %t14 = extractvalue { i32, i1 } %t12, 0
  store i32 %t14, ptr %l10
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16, !prof !99
ok.16:
  store i1 %t13, ptr %l9
  br label %bb2
bb2:
  %t17 = load i1, ptr %l9, !tbaa !21
  store i1 %t17, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l5, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l23 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l24 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l26 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l27 = alloca i32
  %l29 = alloca i1
  %l31 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  store ptr %l3, ptr %l7, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 10
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Context", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t8, i64 %t12)
  store ptr %t15, ptr %l13
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 4
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l15, !tbaa !24
  %t22 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %a2)
  store %"compiler/source:Span" %t22, ptr %l17
  br label %bb3
bb3:
  %t23 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t31 = sext i32 %t24 to i64
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t33 = add i64 %t29, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  %t35 = call i64 @__olang_fmt_i64(ptr %t34, i64 %t25)
  %t36 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  %t38 = call i64 @__olang_fmt_i64(ptr %t37, i64 %t31)
  %t39 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t34, 1
  %t42 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t42, { i64, ptr } %t40)
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Context", ptr %t44, i32 0, i32 2
  %t48 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v1, ptr %v1, ptr %t46)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t48, ptr %l23
  br label %bb5
bb5:
  %t49 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l23
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t49, ptr %l4
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v1, ptr %l4)
  %t52 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t51, 1
  %t53 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t51, 0
  store i32 %t53, ptr %l27
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb8, label %ok.55, !prof !99
ok.55:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t52, ptr %l26
  br label %bb7
bb7:
  %t56 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l26
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t56, ptr %l24
  br label %bb10
bb8:
  %t57 = load i32, ptr %l27, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb10:
  %t61 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l24
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t61, ptr %l5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb11
bb11:
  store ptr %l3, ptr %l31, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l5, i32 0, i32 1
  %t67 = load i32, ptr %t66, !tbaa !23
  %t69 = inttoptr i64 0 to ptr
  %t72 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t69, ptr %t65, i32 %t67)
  store { i64, ptr } %t72, ptr %l36
  br label %bb12
bb12:
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t74 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t74, { i64, ptr } %t73)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  br label %bb6
bb15:
  %t77 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t77, ptr %l39
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i1
  %l12 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i1
  %l32 = alloca ptr
  %l36 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t3, i32 %t4, i32 %t5)
  store i1 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb5
bb5:
  %t19 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t21 = trunc i64 19 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  %t38 = xor i1 %t36, true
  store i1 %t38, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l16, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l28
  br label %bb13
bb13:
  %t49 = load i32, ptr %l28, !tbaa !23
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l32, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb16
bb15:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb19
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l40
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l32, !tbaa !29
  %t70 = load i32, ptr %l36, !tbaa !23
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t69, i32 %t70, i32 %t71)
  store i1 %t72, ptr %l41
  br label %bb18
bb18:
  %t73 = load i1, ptr %l41, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l30, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l1, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l48
  br label %bb23
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l2, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l52
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = load i32, ptr %l48, !tbaa !23
  %t95 = load i32, ptr %l52, !tbaa !23
  %t96 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t93, i32 %t94, i32 %t95)
  store i1 %t96, ptr %l53
  br label %bb25
bb25:
  %t97 = load i1, ptr %l53, !tbaa !21
  store i1 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t7 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/load:Loader", ptr %t8, i32 0, i32 10
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t14, ptr %l9
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t20, ptr %l12
  br label %bb4
bb4:
  %t21 = load i1, ptr %l12, !tbaa !21
  store i1 %t21, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i1, ptr %l4, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMatches(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5) #0 {
entry:
  %l6 = alloca %"compiler/generic:Binding"
  %l9 = alloca %"compiler/generic:Binding"
  %l15 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %a3, i64 %a4)
  store %"compiler/generic:Binding" %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load %"compiler/generic:Binding", ptr %l9
  store %"compiler/generic:Binding" %t6, ptr %l6
  %t16 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %s0, ptr %a0, i32 %a1, i32 %a2, ptr %l6, i1 false, i1 %a5)
  store i32 %t16, ptr %l15
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18, !prof !99
ok.18:
  br label %bb2
bb2:
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l11 = alloca i64
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 50
  store ptr %t5, ptr %l6, !tbaa !29
  %t9 = sext i32 %a2 to i64
  %t12 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %t9)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l12
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb4, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l11
  br label %bb3
bb3:
  %t20 = load i64, ptr %l11, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberBefore(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/generic:memberRow"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca %"compiler/generic:memberRow"
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l34 = alloca %"compiler/generic:memberRow"
  %l38 = alloca i1
  %l42 = alloca %"compiler/generic:memberRow"
  %l51 = alloca i64
  %l53 = alloca ptr
  %l57 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l58 = alloca i64
  %l59 = alloca i32
  %l63 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 46
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/generic:memberRow" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:memberRow", ptr %l10
  store %"compiler/generic:memberRow" %t8, ptr %l2
  %t9 = getelementptr %"compiler/generic:memberRow", ptr %l2, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = getelementptr %"compiler/generic:memberRow", ptr %l2, i32 0, i32 7
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = ashr i64 %t16, 40
  %t20 = icmp eq i64 %t18, 4
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 49
  store ptr %t24, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb26
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l19, !tbaa !24
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load i64, ptr %l19, !tbaa !24
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l26
  br label %bb12
bb12:
  %t41 = load i64, ptr %l26, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = icmp sge i64 %t42, %t43
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 46
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %s4, ptr %t51, i64 %t52)
  store %"compiler/generic:memberRow" %t55, ptr %l34
  br label %bb16
bb16:
  %t56 = getelementptr %"compiler/generic:memberRow", ptr %l34, i32 0, i32 7
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = getelementptr %"compiler/generic:memberRow", ptr %l2, i32 0, i32 7
  %t59 = load i64, ptr %t58, !tbaa !24
  %t62 = icmp eq i64 %t57, %t59
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 46
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %s4, ptr %t66, i64 %t67)
  store %"compiler/generic:memberRow" %t70, ptr %l42
  br label %bb19
bb18:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb20
bb19:
  %t71 = getelementptr %"compiler/generic:memberRow", ptr %l42, i32 0, i32 3
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = getelementptr %"compiler/generic:memberRow", ptr %l2, i32 0, i32 3
  %t74 = load i32, ptr %t73, !tbaa !23
  %t77 = icmp eq i32 %t72, %t74
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t79 = load i1, ptr %l38, !tbaa !21
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t80 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t80, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l4, !tbaa !24
  br label %bb7
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb26:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 47
  store ptr %t90, ptr %l53, !tbaa !29
  %t91 = getelementptr %"compiler/generic:memberRow", ptr %l2, i32 0, i32 7
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = getelementptr %"compiler/generic:memberRow", ptr %l2, i32 0, i32 3
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = sext i32 %t94 to i64
  %t99 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t92, i64 %t96)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t99, ptr %l57
  br label %bb27
bb27:
  %t100 = load ptr, ptr %l53, !tbaa !29
  %t101 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l57
  %t102 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t100, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t101)
  %t103 = extractvalue { i32, i64 } %t102, 1
  %t104 = extractvalue { i32, i64 } %t102, 0
  store i32 %t104, ptr %l59
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb29, label %ok.106, !prof !99
ok.106:
  store i64 %t103, ptr %l58
  br label %bb28
bb28:
  %t107 = load i64, ptr %l58, !tbaa !24
  store i64 %t107, ptr %l51, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l51, !tbaa !24
  br label %bb31
bb31:
  %t108 = load i64, ptr %l51, !tbaa !24
  store i64 %t108, ptr %l6, !tbaa !24
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l1, !tbaa !24
  %t113 = icmp ne i64 %t109, %t110
  br i1 %t113, label %bb32, label %bb33
bb32:
  %t115 = load i64, ptr %l6, !tbaa !24
  store i64 %t115, ptr %l63, !tbaa !24
  br label %bb34
bb33:
  store i64 -1, ptr %l63, !tbaa !24
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t117 = load i64, ptr %l63, !tbaa !24
  store i64 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberCount(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 46
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eLe_Hffef742b46d9f4381d344302148f855f(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/generic:memberRow"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 46
  %t7 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %s0, ptr %t3, i64 %a1)
  store %"compiler/generic:memberRow" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/generic:memberRow", ptr %l5, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberName(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca %"compiler/generic:memberRow"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 46
  %t7 = call %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %s0, ptr %t3, i64 %a1)
  store %"compiler/generic:memberRow" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/generic:memberRow", ptr %l5, i32 0, i32 3
  %t9 = load i32, ptr %t8, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l5, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t9, { i64, ptr } %a2)
  store i32 %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t15 = load i32, ptr %l5, !tbaa !23
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOf(ptr %v0, ptr %t14, i32 %t15, i32 %t16)
  store i64 %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = load i64, ptr %l11, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberType(ptr %v0, ptr %t23, i64 %t24, i32 %t25)
  store i32 %t29, ptr %l18
  br label %bb5
bb4:
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t30, ptr %l14, !tbaa !23
  br label %bb6
bb5:
  %t32 = load i32, ptr %l18, !tbaa !23
  store i32 %t32, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t33 = load i32, ptr %l14, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca { i64, ptr }
  %l49 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 22
  %t9 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6743fd6fdd876d533cce32e3c0cd25b6(ptr %v0, ptr %t5, i32 %t1)
  store i1 %t9, ptr %l14
  br label %bb1
bb1:
  %t10 = load i1, ptr %l14, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 22
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hcfc2a2943c600247d4ded3fb914681ab(ptr %v0, ptr %v1, ptr %t13, i32 %t14)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l20
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb5, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l19
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t23 = icmp sge i64 0, 0
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = icmp sle i64 0, 2305843009213693951
  br i1 %t25, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_25bcbd8d25f60d50_252e633c827b5284)
  unreachable
bb9:
  %t27 = mul i64 0, 4
  %t28 = insertvalue { i64, ptr } undef, i64 0, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t29, ptr %l15, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_25bcbd8d25f60d50_252e633c827b5284)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb12:
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l24
  br label %bb13
bb13:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l3
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emembers(ptr %v0, ptr %s0, ptr %t34, i32 %t35, ptr %l3, i64 0)
  br label %bb14
bb14:
  %t40 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t40, ptr %l29
  br label %bb15
bb15:
  %t41 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t41, ptr %l4, !tbaa !27
  %t42 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t42, ptr %l30
  br label %bb16
bb16:
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t43, ptr %lp5
  %t44 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l30
  %t45 = load ptr, ptr %lp5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t44, ptr %t45
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  %t68 = load ptr, ptr %lp5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t68, i32 %t66, i1 true)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l49
  br label %bb24
bb24:
  %t84 = load i1, ptr %l49, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 22
  %t88 = load i32, ptr %l1, !tbaa !23
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Ha2fdd285cc075e465cab85a1d0fe3f31(ptr %v0, ptr %v1, ptr %t87, i32 %t88, { i64, ptr } %t89)
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 23
  %t96 = load i32, ptr %l1, !tbaa !23
  %t97 = load ptr, ptr %lp5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hc32bd40495535e8a7e7ddcc641d0c371(ptr %v0, ptr %v0, ptr %t95, i32 %t96, ptr %t97)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t101, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodNames(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l4 = alloca %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i32
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l15 = alloca %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708"
  %l17 = alloca %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708"
  %l18 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i1
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i64
  %l43 = alloca %"compiler/generic:fnRow"
  %l49 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l10
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l11
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 38
  %t11 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hce1a5ca8c8bc252d00e2ccbd39de0b40(ptr %v0, ptr %v0, ptr %t9)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t11, ptr %l14
  br label %bb4
bb4:
  %t12 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l14
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t12, ptr %l3
  br label %bb5
bb5:
  %t14 = call { i32, %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fpair_3aPair_3cI64_2c_20I64_3_Hca1409b49ac7e9b021f6a95c9301ae1a(ptr %v0, ptr %l3)
  %t15 = extractvalue { i32, %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" } %t14, 1
  %t16 = extractvalue { i32, %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" } %t14, 0
  store i32 %t16, ptr %l18
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb7, label %ok.18, !prof !99
ok.18:
  store %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" %t15, ptr %l17
  br label %bb6
bb6:
  %t19 = load %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l17
  store %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" %t19, ptr %l15
  br label %bb9
bb7:
  %t20 = load i32, ptr %l18, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  br label %bb17
bb9:
  %t24 = load %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l15
  store %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" %t24, ptr %l4
  %t25 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l4, i32 0, i32 0
  %t26 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t25, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t27)
  store i1 %t30, ptr %l23
  br label %bb10
bb10:
  %t31 = load i1, ptr %l23, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t32 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l4, i32 0, i32 0
  %t33 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t32, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t34, i1 true)
  br label %bb14
bb14:
  %t37 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %l4, i32 0, i32 0
  %t38 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t37, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = trunc i64 %t39 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %l2, i32 %t41)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb5
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 40
  store ptr %t47, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l32, !tbaa !24
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l34
  br label %bb19
bb19:
  %t53 = load i64, ptr %l32, !tbaa !24
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb21:
  br label %bb22
bb22:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l39
  br label %bb23
bb23:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 31
  %t71 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %s5, ptr %t67, i64 %t64)
  store %"compiler/generic:fnRow" %t71, ptr %l43
  br label %bb24
bb24:
  %t72 = getelementptr %"compiler/generic:fnRow", ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Func", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %t75, !tbaa !23
  store i32 %t76, ptr %l8, !tbaa !23
  %t78 = load i32, ptr %l8, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t83 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t80)
  store i1 %t83, ptr %l49
  br label %bb25
bb25:
  %t84 = load i1, ptr %l49, !tbaa !21
  br i1 %t84, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t85 = load i32, ptr %l8, !tbaa !23
  %t87 = sext i32 %t85 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t87, i1 true)
  br label %bb29
bb29:
  %t90 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %l2, i32 %t90)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = add i64 %t93, 1
  store i64 %t96, ptr %l6, !tbaa !24
  br label %bb18
bb32:
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMinArity(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l45 = alloca %"compiler/generic:varRow"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %t1, i32 %t2)
  br label %bb1
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t5)
  store i64 %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load i64, ptr %l13, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t9, i32 %t10)
  store i64 %t13, ptr %l16
  br label %bb3
bb3:
  %t14 = load i64, ptr %l16, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb6:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l24, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l24, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t69 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t63, i64 %t64, i64 %t65)
  store %"compiler/generic:varRow" %t69, ptr %l45
  br label %bb14
bb14:
  %t70 = getelementptr %"compiler/generic:varRow", ptr %l45, i32 0, i32 4
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t75 = icmp ne i32 %t71, %t72
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load i64, ptr %l9, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l8, !tbaa !24
  br label %bb10
bb19:
  %t84 = load i64, ptr %l3, !tbaa !24
  store i64 %t84, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/generic:fnRow"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"compiler/generic:fnRow"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca { i64, ptr }
  %l65 = alloca i1
  %l81 = alloca { i64, ptr }
  %l88 = alloca i1
  %l98 = alloca i1
  %l103 = alloca i1
  %l108 = alloca i1
  %l113 = alloca i1
  %l119 = alloca i1
  %l123 = alloca i64
  %l125 = alloca i64
  %l131 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 31
  %t7 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/generic:fnRow" %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:fnRow", ptr %l20
  store %"compiler/generic:fnRow" %t8, ptr %l2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l21
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l3
  %t11 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Func", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l26, !tbaa !29
  %t22 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l27, !tbaa !24
  %t24 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Func", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb5, label %bb6
bb4:
  br label %bb9
bb5:
  call void @__olang_check_failed(ptr @olang_loc_91e581c61227d1c4_deb54d58cf8aa350)
  unreachable
bb6:
  br label %bb7
bb7:
  %t32 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Func", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Param", ptr %t36, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %l27, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v0, ptr %s0, ptr %t41, i64 %t42, ptr %t40, ptr %l3, i1 false)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t45 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Func", ptr %t46, i32 0, i32 8
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 8
  %t62 = load ptr, ptr %t61, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v0, ptr %s0, ptr %t55, i64 %t57, ptr %t62, ptr %l3, i1 false)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l46
  br label %bb14
bb14:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l4
  %t70 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Func", ptr %t71, i32 0, i32 5
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Func", ptr %t81, i32 0, i32 5
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb17
bb16:
  br label %bb73
bb17:
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  br label %bb27
bb19:
  br label %bb20
bb20:
  %t98 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t98, ptr %l59, !tbaa !27
  %t99 = load i64, ptr %l6, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 %t99
  %t104 = load ptr, ptr %t103, !tbaa !39
  store ptr %t104, ptr %l8, !tbaa !29
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/ast:TypeParam", ptr %t106, i32 0, i32 1
  %t109 = load i32, ptr %t108, !tbaa !23
  %t112 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l3, i32 %t109)
  store i1 %t112, ptr %l65
  br label %bb21
bb21:
  %t113 = load i1, ptr %l65, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr %"compiler/ast:TypeParam", ptr %t116, i32 0, i32 1
  %t119 = load i32, ptr %t118, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l3, i32 %t119)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t125 = add i64 %t122, 1
  store i64 %t125, ptr %l6, !tbaa !24
  br label %bb17
bb27:
  %t127 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/ast:Func", ptr %t128, i32 0, i32 5
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  %t137 = load i64, ptr %l10, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb29, label %bb30
bb29:
  br label %bb72
bb30:
  br label %bb31
bb31:
  %t145 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t145, ptr %l81, !tbaa !27
  %t146 = load i64, ptr %l10, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr ptr, ptr %t149, i64 %t146
  %t151 = load ptr, ptr %t150, !tbaa !39
  store ptr %t151, ptr %l12, !tbaa !29
  %t153 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Func", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb32, label %bb33
bb32:
  %t163 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/ast:Func", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  br i1 %t169, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_632aa6436eca4593_afccf639e057e8af)
  unreachable
bb35:
  br label %bb36
bb36:
  %t171 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/ast:Func", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Param", ptr %t175, i32 0, i32 2
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t180 = load ptr, ptr %l12, !tbaa !29
  %t182 = getelementptr %"compiler/ast:TypeParam", ptr %t180, i32 0, i32 1
  %t183 = load i32, ptr %t182, !tbaa !23
  %t186 = call i1 @compiler_2fgeneric_2ementionsName(ptr %v0, ptr %t179, i32 %t183)
  store i1 %t186, ptr %l98
  br label %bb37
bb37:
  %t187 = load i1, ptr %l98, !tbaa !21
  store i1 %t187, ptr %l88, !tbaa !21
  br label %bb38
bb38:
  %t188 = load i1, ptr %l88, !tbaa !21
  br i1 %t188, label %bb39, label %bb40
bb39:
  br label %bb71
bb40:
  br label %bb41
bb41:
  %t189 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/ast:Func", ptr %t190, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = icmp eq ptr %t193, null
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb42, label %bb43
bb42:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t202 = load ptr, ptr %l12, !tbaa !29
  %t204 = getelementptr %"compiler/ast:TypeParam", ptr %t202, i32 0, i32 1
  %t205 = load i32, ptr %t204, !tbaa !23
  %t209 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvBinds(ptr %v0, ptr %v0, ptr %t199, ptr %t201, i32 %t205)
  store i1 %t209, ptr %l108
  br label %bb44
bb43:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb45
bb44:
  %t210 = load i1, ptr %l108, !tbaa !21
  store i1 %t210, ptr %l103, !tbaa !21
  br label %bb45
bb45:
  %t211 = load i1, ptr %l103, !tbaa !21
  br i1 %t211, label %bb46, label %bb47
bb46:
  br label %bb71
bb47:
  br label %bb48
bb48:
  %t212 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = getelementptr %"compiler/ast:Func", ptr %t213, i32 0, i32 8
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = icmp eq ptr %t216, null
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb49, label %bb50
bb49:
  %t222 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/ast:Func", ptr %t223, i32 0, i32 8
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = load ptr, ptr %l12, !tbaa !29
  %t230 = getelementptr %"compiler/ast:TypeParam", ptr %t228, i32 0, i32 1
  %t231 = load i32, ptr %t230, !tbaa !23
  %t234 = call i1 @compiler_2fgeneric_2ementionsName(ptr %v0, ptr %t226, i32 %t231)
  store i1 %t234, ptr %l119
  br label %bb51
bb50:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb52
bb51:
  %t235 = load i1, ptr %l119, !tbaa !21
  store i1 %t235, ptr %l113, !tbaa !21
  br label %bb52
bb52:
  %t236 = load i1, ptr %l113, !tbaa !21
  br i1 %t236, label %bb53, label %bb54
bb53:
  br label %bb71
bb54:
  br label %bb55
bb55:
  %t237 = load ptr, ptr %l12, !tbaa !29
  %t239 = getelementptr %"compiler/ast:TypeParam", ptr %t237, i32 0, i32 4
  %t240 = load i1, ptr %t239, !tbaa !21
  br i1 %t240, label %bb56, label %bb57
bb56:
  br label %bb71
bb57:
  br label %bb58
bb58:
  store ptr %l3, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb59
bb59:
  %t243 = load i64, ptr %l14, !tbaa !24
  store i64 %t243, ptr %l123, !tbaa !24
  %t244 = load ptr, ptr %l13, !tbaa !29
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t244)
  store i64 %t246, ptr %l125
  br label %bb60
bb60:
  %t247 = load i64, ptr %l123, !tbaa !24
  %t248 = load i64, ptr %l125, !tbaa !24
  %t249 = icmp slt i64 %t247, %t248
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb61, label %bb62
bb61:
  br label %bb70
bb62:
  br label %bb63
bb63:
  %t253 = load i64, ptr %l14, !tbaa !24
  store i64 %t253, ptr %l15, !tbaa !24
  %t255 = load ptr, ptr %l13, !tbaa !29
  %t256 = load i64, ptr %l14, !tbaa !24
  %t259 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t255, i64 %t256)
  store i32 %t259, ptr %l131
  br label %bb64
bb64:
  %t260 = load i32, ptr %l131, !tbaa !23
  %t262 = load ptr, ptr %l12, !tbaa !29
  %t264 = getelementptr %"compiler/ast:TypeParam", ptr %t262, i32 0, i32 1
  %t265 = load i32, ptr %t264, !tbaa !23
  %t268 = icmp eq i32 %t260, %t265
  br i1 %t268, label %bb65, label %bb66
bb65:
  %t270 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %l4, i64 %t270)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t273 = load i64, ptr %l14, !tbaa !24
  %t276 = add i64 %t273, 1
  store i64 %t276, ptr %l14, !tbaa !24
  br label %bb59
bb70:
  br label %bb71
bb71:
  %t278 = load i64, ptr %l10, !tbaa !24
  %t281 = add i64 %t278, 1
  store i64 %t281, ptr %l10, !tbaa !24
  br label %bb28
bb72:
  br label %bb73
bb73:
  %t283 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t283, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerVarCount(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/generic:fnRow"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"compiler/generic:fnRow"
  %l9 = alloca i1
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 31
  %t7 = call %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/generic:fnRow" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:fnRow", ptr %l7
  store %"compiler/generic:fnRow" %t8, ptr %l2
  %t9 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t10)
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i1, ptr %l9, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l12
  br label %bb6
bb6:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l3
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = getelementptr %"compiler/generic:fnRow", ptr %l2, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Func", ptr %t23, i32 0, i32 8
  %t26 = load ptr, ptr %t25, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v0, ptr %s0, ptr %t19, i64 %t21, ptr %t26, ptr %l3, i1 false)
  br label %bb7
bb7:
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l3)
  store i64 %t32, ptr %l19
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca i32
  %l59 = alloca i64
  %l64 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t16 = trunc i64 18 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t22, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l22
  br label %bb8
bb8:
  %t31 = load i32, ptr %l22, !tbaa !23
  store i32 %t31, ptr %l2, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l26
  br label %bb9
bb9:
  %t39 = load i32, ptr %l26, !range !{i32 0, i32 6}
  %t41 = trunc i64 2 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 9
  %t51 = load i32, ptr %l2, !tbaa !23
  %t53 = sext i32 %t51 to i64
  %t56 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__H9861f6f09602cf23d49075e82ac9429b(ptr %v0, ptr %t50, i64 %t53)
  %t57 = extractvalue { i32, i32 } %t56, 1
  %t58 = extractvalue { i32, i32 } %t56, 0
  store i32 %t58, ptr %l37
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb14, label %ok.60, !prof !99
ok.60:
  store i32 %t57, ptr %l36
  br label %bb13
bb13:
  %t61 = load i32, ptr %l36, !tbaa !23
  store i32 %t61, ptr %l31, !tbaa !23
  br label %bb16
bb14:
  br label %bb15
bb15:
  store i32 -1, ptr %l31, !tbaa !23
  br label %bb16
bb16:
  %t62 = load i32, ptr %l31, !tbaa !23
  store i32 %t62, ptr %l3, !tbaa !23
  %t63 = load i32, ptr %l3, !tbaa !23
  %t65 = icmp ne i32 %t63, -1
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t67, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t71, i32 %t72)
  store i64 %t75, ptr %l44
  br label %bb20
bb20:
  %t76 = load i64, ptr %l44, !tbaa !24
  store i64 %t76, ptr %l4, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l45, !tbaa !29
  %t78 = load i64, ptr %l4, !tbaa !24
  store i64 %t78, ptr %l46, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l49, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l2, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l54
  br label %bb21
bb21:
  %t94 = load ptr, ptr %l50, !tbaa !29
  %t95 = load i32, ptr %l54, !tbaa !23
  %t96 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t94, i32 %t95)
  store { i64, ptr } %t96, ptr %l55
  br label %bb22
bb22:
  %t97 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t98 = call { i64, ptr } @compiler_2fnames_2ePayloadName(ptr %v0, ptr %s0, { i64, ptr } %t97)
  store { i64, ptr } %t98, ptr %l56
  br label %bb23
bb23:
  %t99 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t100 = load ptr, ptr %l49, !tbaa !29
  %t102 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t100, { i64, ptr } %t99)
  store i32 %t102, ptr %l58
  br label %bb24
bb24:
  %t103 = load ptr, ptr %l45, !tbaa !29
  %t104 = load i64, ptr %l46, !tbaa !24
  %t105 = load i32, ptr %l58, !tbaa !23
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t103, i64 %t104, i32 %t105)
  store i64 %t106, ptr %l59
  br label %bb25
bb25:
  %t107 = load i64, ptr %l59, !tbaa !24
  store i64 %t107, ptr %l5, !tbaa !24
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t108, ptr %l6, !tbaa !23
  %t110 = load i64, ptr %l5, !tbaa !24
  %t112 = icmp sge i64 %t110, 0
  br i1 %t112, label %bb26, label %bb27
bb26:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  store ptr %t116, ptr %l64, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l4, !tbaa !24
  %t119 = load i64, ptr %l5, !tbaa !24
  %t123 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t117, i64 %t118, i64 %t119)
  store i32 %t123, ptr %l68
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t124 = load ptr, ptr %l64, !tbaa !29
  %t125 = load i32, ptr %l68, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t124, i32 %t125, i32 0)
  store i32 %t126, ptr %l69
  br label %bb29
bb29:
  %t127 = load i32, ptr %l69, !tbaa !23
  store i32 %t127, ptr %l6, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l6, !tbaa !23
  %t132 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t128, i32 %t129)
  store i1 %t132, ptr %l72
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 9
  %t136 = load i32, ptr %l2, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t139 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__Hbdd7c5068e376aa260a62181a9f99429(ptr %v0, ptr %t135, i64 %t138, i32 %t139)
  br label %bb32
bb32:
  %t143 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eensureModules(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 26
  %t9 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %a1)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l9
  br label %bb2
bb2:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  store i64 %t16, ptr %l13, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 3
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t29 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v2, ptr %t25, { i64, ptr } %a2)
  store i32 %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l12, !tbaa !29
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = load i32, ptr %l18, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t30, i64 %t31, i32 %t32)
  store i64 %t33, ptr %l19
  br label %bb7
bb7:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorDecl(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t12, ptr %rv
  br label %ret
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  store ptr %t13, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 12}
  %t20 = icmp eq i64 %t18, 6
  store i1 %t20, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l12, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr { i64, [8 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l3
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t28 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t28, ptr %l10
  br label %bb17
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t30 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t30, ptr %l18
  br label %bb15
bb15:
  %t31 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t31, ptr %l10
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7fa838ee20be17d9_9f8073ee4b7324d5)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = sext i32 %t11 to i64
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t15 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t13, i64 %t12)
  %t16 = extractvalue { i32, i32 } %t15, 1
  %t17 = extractvalue { i32, i32 } %t15, 0
  store i32 %t17, ptr %l11
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i32 %t16, ptr %l10
  br label %bb2
bb2:
  %t20 = load i32, ptr %l10, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i32 0, ptr %l2, !tbaa !23
  br label %bb5
bb5:
  %t21 = load i32, ptr %l2, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedSettled(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = sext i32 %t11 to i64
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hd32df9536ace7093dedc2ceceb7810b4(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l9
  br label %bb2
bb2:
  %t16 = load i1, ptr %l9, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflKind(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l14 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 4, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l14
  br label %bb5
bb5:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i64 2, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l19
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  store i64 3, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb13
bb13:
  %t39 = load i32, ptr %l24, !range !{i32 0, i32 33}
  store i32 %t39, ptr %l3
  %t40 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t42 = trunc i64 19 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i64 5, ptr %l25, !tbaa !24
  br label %bb46
bb17:
  %t45 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t47 = trunc i64 20 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 6, ptr %l25, !tbaa !24
  br label %bb46
bb21:
  %t50 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t52 = trunc i64 21 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i64 7, ptr %l25, !tbaa !24
  br label %bb46
bb25:
  %t55 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t57 = trunc i64 18 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l36
  br label %bb29
bb29:
  %t65 = load i1, ptr %l36, !tbaa !21
  br i1 %t65, label %bb30, label %bb31
bb30:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb36
bb31:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l2, !tbaa !23
  %t70 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisEnumT(ptr %v0, ptr %t66, i32 %t67)
  store i1 %t70, ptr %l40
  br label %bb32
bb32:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb33, label %bb34
bb33:
  store i64 1, ptr %l41, !tbaa !24
  br label %bb35
bb34:
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb35
bb35:
  %t72 = load i64, ptr %l41, !tbaa !24
  store i64 %t72, ptr %l37, !tbaa !24
  br label %bb36
bb36:
  %t73 = load i64, ptr %l37, !tbaa !24
  store i64 %t73, ptr %l25, !tbaa !24
  br label %bb46
bb37:
  %t74 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t76 = trunc i64 32 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i64 8, ptr %l25, !tbaa !24
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_bea3dfbd3e43d709_f7b1d9dae3096955)
  unreachable
bb46:
  %t79 = load i64, ptr %l25, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i32
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l27 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l79 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l17, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l21
  br label %bb4
bb3:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load i32, ptr %l21, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i32, ptr %l22, !range !{i32 0, i32 6}
  %t28 = trunc i64 2 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOfType(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l27
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t37 = load i32, ptr %l27, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb10:
  %t38 = load i32, ptr %l1, !tbaa !23
  store i32 %t38, ptr %l2, !tbaa !23
  store i64 0, ptr %l3, !tbaa !24
  store i64 64, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb16
bb13:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l35, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t66 = load i64, ptr %l35, !tbaa !24
  store i64 %t66, ptr %l32, !tbaa !24
  br label %bb16
bb16:
  %t67 = load i64, ptr %l32, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %bb36
bb19:
  br label %bb20
bb20:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l5, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l8, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l2, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l56
  br label %bb21
bb21:
  %t93 = load i32, ptr %l56, !range !{i32 0, i32 33}
  %t95 = trunc i64 18 to i32
  %t96 = icmp eq i32 %t93, %t95
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb25
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l2, !tbaa !23
  %t104 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l63
  br label %bb24
bb24:
  %t105 = load i1, ptr %l63, !tbaa !21
  %t106 = xor i1 %t105, true
  store i1 %t106, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t108 = load i1, ptr %l60, !tbaa !21
  br i1 %t108, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb30
bb27:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l67, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l2, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l71
  br label %bb28
bb28:
  %t119 = load ptr, ptr %l67, !tbaa !29
  %t120 = load i32, ptr %l71, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t121, ptr %l72
  br label %bb29
bb29:
  %t122 = load i32, ptr %l72, !range !{i32 0, i32 6}
  %t124 = trunc i64 4 to i32
  %t125 = icmp eq i32 %t122, %t124
  %t127 = xor i1 %t125, true
  store i1 %t127, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t129 = load i1, ptr %l65, !tbaa !21
  br i1 %t129, label %bb31, label %bb32
bb31:
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l2, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l79
  br label %bb34
bb34:
  %t137 = load i32, ptr %l79, !tbaa !23
  store i32 %t137, ptr %l2, !tbaa !23
  br label %bb35
bb35:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l7, !tbaa !24
  br label %bb17
bb36:
  %t143 = load i32, ptr %l2, !tbaa !23
  store i32 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca %"compiler/generic:Unmet"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 true, i64 0)
  store %"compiler/generic:Unmet" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/generic:Unmet", ptr %l6, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = load i32, ptr %l15, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t35, i32 %t33)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb3
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t46, i32 %t47)
  store { i64, ptr } %t50, ptr %l34
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t51, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t65, ptr %l42, !tbaa !27
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 %t66
  %t71 = load i32, ptr %t70, !tbaa !33
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %t73, i32 %t71)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t77, 1
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb11
bb17:
  call void @__olang_scope_close(ptr %s4)
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l1, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l53
  br label %bb18
bb18:
  %t89 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSettleRaised(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t11, { i64, ptr } %a2)
  store i32 %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load i32, ptr %l12, !tbaa !23
  store i32 %t16, ptr %l4, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 10
  %t20 = load i32, ptr %l3, !tbaa !23
  %t22 = sext i32 %t20 to i64
  %t23 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %t19, i64 %t22, i32 %t23)
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  store i32 %t30, ptr %l20, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l24
  br label %bb4
bb4:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  store ptr %t40, ptr %l26, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l30
  br label %bb5
bb5:
  %t48 = mul i64 1, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 1, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l31, !tbaa !27
  %t52 = load i32, ptr %l30, !tbaa !23
  %t53 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i32, ptr %t54, i64 0
  store i32 %t52, ptr %t55, !tbaa !33
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t56, { i64, ptr } %t57)
  store i32 %t58, ptr %l32
  br label %bb6
bb6:
  %t59 = load ptr, ptr %l19, !tbaa !29
  %t60 = load i32, ptr %l20, !tbaa !23
  %t61 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t62 = load i32, ptr %l32, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEnumBody(ptr %v0, ptr %v0, ptr %t59, i32 %t60, { i64, ptr } %t61, i32 %t62)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNameIds(ptr %v0, ptr %v1, ptr %s0, ptr %t4, ptr %a1)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca i64
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t5 = mul i64 %t3, 65536
  store i64 %t5, ptr %l5, !tbaa !24
  store i64 %a2, ptr %l6, !tbaa !24
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %a0, i32 %t8)
  store { i64, ptr } %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = srem i64 %t14, %t13
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = add i64 %t17, %t16
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTraitSig(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca i32
  %l8 = alloca %"compiler/generic:Context"
  %l14 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i32
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l35 = alloca i64
  %l37 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t3 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t3, ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t3, i64 160, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l8, i64 160, i1 false)
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Func", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %s0, ptr %v1, ptr %t6, ptr %l4, ptr %t10, i32 %t11, i32 0)
  store i32 %t16, ptr %l14
  br label %bb2
bb2:
  %t17 = load i32, ptr %l14, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  store ptr %t20, ptr %l16, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load i32, ptr %l5, !tbaa !23
  store i32 %t24, ptr %l19, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i32, ptr %l5, !tbaa !23
  %t35 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromisesOf(ptr %v0, ptr %s0, ptr %v1, ptr %t25, ptr %l4, ptr %t29, i32 %t30)
  store i64 %t35, ptr %l25
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i32, ptr %l19, !tbaa !23
  %t38 = load i64, ptr %l25, !tbaa !24
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithPromises(ptr %v0, ptr %t36, i32 %t37, i64 %t38)
  store i32 %t39, ptr %l26
  br label %bb4
bb4:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/ast:Func", ptr %t41, i32 0, i32 3
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t47 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %t40, ptr %t44)
  store i64 %t47, ptr %l30
  br label %bb5
bb5:
  %t48 = load ptr, ptr %l16, !tbaa !29
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = load i64, ptr %l30, !tbaa !24
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t48, i32 %t49, i64 %t50)
  store i32 %t51, ptr %l31
  br label %bb6
bb6:
  %t52 = load i32, ptr %l31, !tbaa !23
  store i32 %t52, ptr %l5, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  %t54 = load i32, ptr %l5, !tbaa !23
  store i32 %t54, ptr %l33, !tbaa !23
  %t55 = load i32, ptr %l1, !tbaa !23
  %t57 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t55)
  store i64 %t57, ptr %l35
  br label %bb7
bb7:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load i32, ptr %l33, !tbaa !23
  %t61 = load i64, ptr %l35, !tbaa !24
  %t63 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t59, i32 %t60, i64 %t61, i32 %a3)
  store i32 %t63, ptr %l37
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load i32, ptr %l37, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 0, i1 false)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l8 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t9 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i64 0)
  store i64 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l10 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %t3)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUniqueSettled(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l10
  br label %bb5
bb5:
  %t17 = load i1, ptr %l10, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epartsReady(ptr %v0, ptr %t20, i32 %t21, i64 0)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l17
  br label %bb10
bb10:
  %t31 = load i1, ptr %l17, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnknownConst(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 2
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v0, ptr %t3, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i32 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i32, ptr %l3, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t3, i64 %t4, i64 %t5, i64 %t6)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i32, ptr %l9, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t13, i64 %t14, i64 %t15)
  store i1 %t19, ptr %l13
  br label %bb2
bb2:
  %t20 = load i1, ptr %l13, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l19
  br label %bb5
bb4:
  %t29 = load i32, ptr %l3, !tbaa !23
  store i32 %t29, ptr %l14, !tbaa !23
  br label %bb7
bb5:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i32, ptr %l19, !tbaa !23
  %t33 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l20
  br label %bb6
bb6:
  %t34 = load i32, ptr %l20, !tbaa !23
  store i32 %t34, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t35 = load i32, ptr %l14, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i1
  %l26 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorDecl(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store ptr %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l7, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t13 = icmp sle i64 0, 1152921504606846975
  br i1 %t13, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8e4deaec3e2f71aa_ab3a032f79647ee)
  unreachable
bb6:
  %t15 = mul i64 0, 8
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8e4deaec3e2f71aa_ab3a032f79647ee)
  unreachable
bb8:
  %t19 = load ptr, ptr %l3, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 12}
  %t26 = icmp eq i64 %t24, 6
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr { i64, [8 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t30, i32 0, i32 4
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp slt i64 %t38, %t41
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb17:
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t47, ptr %l26, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = getelementptr %"compiler/ast:CaseDecl", ptr %t53, i32 0, i32 2
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_231a5def5f2dccd8_8883f165640dcf84)
  unreachable
bb25:
  %t58 = icmp sge i64 0, 0
  br i1 %t58, label %bb26, label %bb27
bb26:
  %t60 = icmp sle i64 0, 1152921504606846975
  br i1 %t60, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_b927a1007eda2e1c_4bb59e0dd95e8bc0)
  unreachable
bb28:
  %t62 = mul i64 0, 8
  %t63 = insertvalue { i64, ptr } undef, i64 0, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t64, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_b927a1007eda2e1c_4bb59e0dd95e8bc0)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFnsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l45 = alloca i1
  %l50 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6578d57707832f1c_86539f83bfff8b08)
  unreachable
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sgt i64 %t23, 0
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopIf", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6578d57707832f1c_86539f83bfff8b08)
  unreachable
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load ptr, ptr %l18, !tbaa !29
  %t46 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFns(ptr %v0, ptr %v1, ptr %t45, i64 %t46, { i64, ptr } %t44)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopIf", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  store i64 %t58, ptr %l32, !tbaa !24
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8ca182a09b46660b_89b944af5f42b927)
  unreachable
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TopIf", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load ptr, ptr %l31, !tbaa !29
  %t75 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFnsIf(ptr %v0, ptr %v1, ptr %t74, i64 %t75, ptr %t69, i64 %t70, i64 %t73)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t79, i32 0, i32 3
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = add i64 %t89, 1
  %t94 = icmp eq i64 %t88, %t91
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l45, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:TopIf", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_e2462b885589950a_643da267921b7c76)
  unreachable
bb27:
  br label %bb28
bb28:
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr %"compiler/ast:TopIf", ptr %t104, i32 0, i32 3
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t110 = getelementptr %"compiler/ast:TopBranch", ptr %t107, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp sgt i64 %t113, 0
  store i1 %t115, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t117 = load i1, ptr %l50, !tbaa !21
  br i1 %t117, label %bb30, label %bb31
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l60, !tbaa !29
  %t119 = load i64, ptr %l1, !tbaa !24
  store i64 %t119, ptr %l61, !tbaa !24
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:TopIf", ptr %t120, i32 0, i32 3
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e2462b885589950a_643da267921b7c76)
  unreachable
bb33:
  br label %bb34
bb34:
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr %"compiler/ast:TopIf", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t133 = getelementptr %"compiler/ast:TopBranch", ptr %t130, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t135 = load ptr, ptr %l60, !tbaa !29
  %t136 = load i64, ptr %l61, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFns(ptr %v0, ptr %v1, ptr %t135, i64 %t136, { i64, ptr } %t134)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4, { i64, ptr } %a5, ptr %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l11 = alloca i64
  %l14 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l31 = alloca %"compiler/generic:memberRow"
  %l33 = alloca ptr
  %l37 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l50 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l51 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i32
  %l66 = alloca i1
  %l68 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 46
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eLe_Hffef742b46d9f4381d344302148f855f(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i64, ptr %l14, !tbaa !24
  store i64 %t6, ptr %l8, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %t7, i64 %t8, ptr %t9, { i64, ptr } %t11)
  store i64 %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load i64, ptr %l20, !tbaa !24
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 46
  store ptr %t20, ptr %l22, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load %"compiler/source:Span", ptr %l2
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = load i64, ptr %l9, !tbaa !24
  %t37 = call %"compiler/generic:memberRow" @compiler_2fgeneric_3amemberRow_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %v0, i64 %t21, %"compiler/source:Span" %t22, ptr %t23, i32 %t24, { i64, ptr } %t25, ptr %a6, i32 %a7, i64 %t28)
  store %"compiler/generic:memberRow" %t37, ptr %l31
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load %"compiler/generic:memberRow", ptr %l31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2ePu_Hd08e06a92da62f0f388e5d473a774064(ptr %v0, ptr %v0, ptr %t38, %"compiler/generic:memberRow" %t39)
  br label %bb4
bb4:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 50
  store ptr %t42, ptr %l33, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  %t50 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t43, i64 %t47)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t50, ptr %l37
  br label %bb5
bb5:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load ptr, ptr %l33, !tbaa !29
  %t53 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l37
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t52, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t53, i64 %t51)
  br label %bb6
bb6:
  %t55 = load i64, ptr %l9, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t59 = load i64, ptr %l9, !tbaa !24
  %t61 = ashr i64 %t59, 40
  %t63 = icmp eq i64 %t61, 4
  br i1 %t63, label %bb10, label %bb11
bb10:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 49
  %t68 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 %t68)
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t71 = load i64, ptr %l9, !tbaa !24
  %t72 = load i32, ptr %l4, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t77 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t71, i64 %t74)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t77, ptr %l50
  br label %bb14
bb14:
  %t78 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l50
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t78, ptr %l10
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 47
  %t82 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  %t85 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t81, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t82)
  %t86 = extractvalue { i32, i64 } %t85, 1
  %t87 = extractvalue { i32, i64 } %t85, 0
  store i32 %t87, ptr %l56
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb16, label %ok.89, !prof !99
ok.89:
  store i64 %t86, ptr %l55
  br label %bb15
bb15:
  %t90 = load i64, ptr %l55, !tbaa !24
  store i64 %t90, ptr %l51, !tbaa !24
  br label %bb18
bb16:
  br label %bb17
bb17:
  store i64 -1, ptr %l51, !tbaa !24
  br label %bb18
bb18:
  %t91 = load i64, ptr %l51, !tbaa !24
  store i64 %t91, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp slt i64 %t92, 0
  br i1 %t94, label %bb19, label %bb20
bb19:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 47
  %t99 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  %t100 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t98, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t99, i64 %t100)
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 48
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t106, i64 %t107)
  store i1 %t110, ptr %l66
  br label %bb24
bb24:
  %t111 = load i1, ptr %l66, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb25, label %bb26
bb25:
  br label %bb33
bb26:
  br label %bb27
bb27:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 48
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t116, i64 %t117)
  %t121 = extractvalue { i32, i64 } %t120, 1
  %t122 = extractvalue { i32, i64 } %t120, 0
  store i32 %t122, ptr %l73
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb29, label %ok.124, !prof !99
ok.124:
  store i64 %t121, ptr %l72
  br label %bb28
bb28:
  %t125 = load i64, ptr %l72, !tbaa !24
  store i64 %t125, ptr %l68, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t126 = load i64, ptr %l68, !tbaa !24
  store i64 %t126, ptr %l11, !tbaa !24
  br label %bb32
bb32:
  br label %bb23
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 48
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t129, i64 %t130, i64 %t131)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l19 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l42 = alloca %"compiler/generic:varRow"
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l12
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 16
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l16, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 18
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eLen_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l19
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t25, i64 %t26, i64 %t27)
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 17
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t30, i64 %t31, i64 %t34)
  br label %bb10
bb10:
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t52, ptr %l32, !tbaa !27
  %t53 = load i64, ptr %l4, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 %t53
  %t58 = load i32, ptr %t57, !tbaa !33
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 18
  store ptr %t62, ptr %l36, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = call %"compiler/generic:varRow" @compiler_2fgeneric_3avarRow_2ector(ptr %s3, i64 %t63, i32 %t58, i32 %t65, i32 %t66, i32 %t67)
  store %"compiler/generic:varRow" %t73, ptr %l42
  br label %bb15
bb15:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load %"compiler/generic:varRow", ptr %l42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2ePush_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %t74, %"compiler/generic:varRow" %t75)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t79 = add i64 %t76, 1
  store i64 %t79, ptr %l4, !tbaa !24
  br label %bb11
bb18:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanyGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 68
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i32, ptr %l2, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t10 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t4, i64 %t7)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  %t13 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hcad520af686b186b53ef29921f8ab48b(ptr %v0, ptr %v1, ptr %t11, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12)
  %t14 = extractvalue { i32, ptr } %t13, 1
  %t15 = extractvalue { i32, ptr } %t13, 0
  store i32 %t15, ptr %l12
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb3, label %ok.17, !prof !99
ok.17:
  store ptr %t14, ptr %l11
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l11, !tbaa !29
  store ptr %t18, ptr %l4, !tbaa !29
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 10
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l19
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/load:Module", ptr %t31, i32 0, i32 8
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = load i32, ptr %l2, !tbaa !23
  %t36 = load ptr, ptr %l13, !tbaa !29
  %t37 = load i64, ptr %l14, !tbaa !24
  %t40 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalIn(ptr %v0, ptr %v0, ptr %v1, ptr %t36, i64 %t37, { i64, ptr } %t34, i32 %t35)
  store ptr %t40, ptr %l23
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load ptr, ptr %l23, !tbaa !29
  store ptr %t41, ptr %rv
  br label %ret
bb7:
  %t42 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t42, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2earrayRecvApplies(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i32
  %l12 = alloca i32
  %l18 = alloca i64
  %l21 = alloca i64
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %l34 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i1
  %l41 = alloca ptr
  %l45 = alloca i32
  %l49 = alloca i32
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t16 = trunc i64 19 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t22)
  store i64 %t24, ptr %l18
  br label %bb6
bb6:
  %t25 = load i64, ptr %l18, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l21
  br label %bb7
bb7:
  %t31 = load i64, ptr %l21, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l27, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l31
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i32, ptr %l31, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l32
  br label %bb11
bb11:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l34, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l38
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l34, !tbaa !29
  %t63 = load i32, ptr %l38, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l39
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l25, !tbaa !29
  %t66 = load i32, ptr %l32, !tbaa !23
  %t67 = load i32, ptr %l39, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t65, i32 %t66, i32 %t67)
  store i1 %t68, ptr %l40
  br label %bb14
bb14:
  %t69 = load i1, ptr %l40, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l41, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l45
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l49
  br label %bb17
bb17:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t86 = load i64, ptr %l5, !tbaa !24
  %t87 = load ptr, ptr %l41, !tbaa !29
  %t88 = load i32, ptr %l45, !tbaa !23
  %t89 = load i32, ptr %l49, !tbaa !23
  %t92 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMatches(ptr %v0, ptr %t87, i32 %t88, i32 %t89, i64 %t85, i64 %t86, i1 true)
  store i1 %t92, ptr %l52
  br label %bb18
bb18:
  %t93 = load i1, ptr %l52, !tbaa !21
  store i1 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eat(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %rv = alloca { i64, [3 x i64] }
  %t14 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %a0, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t10 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 0
  store i64 3, ptr %t15
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = insertvalue { i64, i64, i64 } undef, i64 %t16, 0
  %t19 = insertvalue { i64, i64, i64 } %t17, i64 %t9, 1
  %t21 = insertvalue { i64, i64, i64 } %t19, i64 %t13, 2
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  store { i64, i64, i64 } %t21, ptr %t22
  %t23 = load { i64, [3 x i64] }, ptr %t14
  store { i64, [3 x i64] } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebinaryType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l43 = alloca i32
  %l49 = alloca i32
  %l52 = alloca i1
  %l53 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i1
  %l58 = alloca i32
  %l60 = alloca i32
  %l63 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t3 = trunc i64 95 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t8 = trunc i64 96 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t14 = trunc i64 98 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t20 = trunc i64 99 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l16, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t26 = trunc i64 100 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t32 = trunc i64 101 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t38 = trunc i64 45 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l25, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb21
bb20:
  %t42 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t44 = trunc i64 46 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb24
bb23:
  %t48 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t50 = trunc i64 28 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l31, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb27
bb26:
  %t54 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t56 = trunc i64 106 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l34, !tbaa !21
  br label %bb27
bb27:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb28, label %bb29
bb28:
  %t60 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t60, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t71 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t62, ptr %t63, ptr %t64, ptr %a4)
  store i32 %t71, ptr %l43
  br label %bb31
bb31:
  %t72 = load i32, ptr %l43, !tbaa !23
  store i32 %t72, ptr %l6, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t82 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t73, ptr %t74, ptr %t75, ptr %a5)
  store i32 %t82, ptr %l49
  br label %bb32
bb32:
  %t83 = load i32, ptr %l49, !tbaa !23
  store i32 %t83, ptr %l7, !tbaa !23
  %t84 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t86 = trunc i64 68 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t89 = load i32, ptr %l6, !tbaa !23
  store i32 %t89, ptr %l53, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %t90)
  store i32 %t92, ptr %l55
  br label %bb35
bb34:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb40
bb35:
  %t93 = load i32, ptr %l53, !tbaa !23
  %t94 = load i32, ptr %l55, !tbaa !23
  %t95 = icmp eq i32 %t93, %t94
  br i1 %t95, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb39
bb37:
  %t97 = load i32, ptr %l7, !tbaa !23
  store i32 %t97, ptr %l58, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %t98)
  store i32 %t100, ptr %l60
  br label %bb38
bb38:
  %t101 = load i32, ptr %l58, !tbaa !23
  %t102 = load i32, ptr %l60, !tbaa !23
  %t103 = icmp eq i32 %t101, %t102
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb39
bb39:
  %t105 = load i1, ptr %l57, !tbaa !21
  store i1 %t105, ptr %l52, !tbaa !21
  br label %bb40
bb40:
  %t106 = load i1, ptr %l52, !tbaa !21
  br i1 %t106, label %bb41, label %bb42
bb41:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %t107)
  store i32 %t109, ptr %l63
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t110 = load i32, ptr %l63, !tbaa !23
  store i32 %t110, ptr %rv
  br label %ret
bb44:
  %t111 = load i32, ptr %l6, !tbaa !23
  %t112 = load i32, ptr %l7, !tbaa !23
  %t115 = icmp ne i32 %t111, %t112
  br i1 %t115, label %bb45, label %bb46
bb45:
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t122 = load i32, ptr %l6, !tbaa !23
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t125, ptr %l71
  br label %bb48
bb48:
  %t126 = load i1, ptr %l71, !tbaa !21
  br i1 %t126, label %bb49, label %bb50
bb49:
  %t127 = load i32, ptr %l6, !tbaa !23
  store i32 %t127, ptr %l72, !tbaa !23
  br label %bb51
bb50:
  %t129 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t129, ptr %l72, !tbaa !23
  br label %bb51
bb51:
  %t131 = load i32, ptr %l72, !tbaa !23
  store i32 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebindOwnerArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l17 = alloca i32
  %l22 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l56 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca i64
  %l66 = alloca %"compiler/names:Ref"
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l4, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l17
  br label %bb1
bb1:
  %t8 = load i32, ptr %l17, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l22, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l26
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l22, !tbaa !29
  %t26 = load i32, ptr %l26, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l27
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store { i64, ptr } %a3, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  br label %bb37
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l7, !tbaa !24
  store i64 %t43, ptr %l9, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t45, ptr %l36, !tbaa !27
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l10, !tbaa !29
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp sge i64 %t53, %t56
  br i1 %t59, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t61 = load ptr, ptr %l10, !tbaa !29
  store ptr %t61, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t62 = load ptr, ptr %l43, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 8}
  %t68 = icmp eq i64 %t66, 0
  store i1 %t68, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t69 = load i1, ptr %l44, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l10, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l11
  %t76 = load ptr, ptr %l10, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t78, i32 0, i32 1
  %t80 = load { i64, ptr }, ptr %t79
  store { i64, ptr } %t80, ptr %l12, !tbaa !27
  %t82 = load ptr, ptr %l10, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t84, i32 0, i32 2
  %t86 = load { i64, ptr }, ptr %t85
  store { i64, ptr } %t86, ptr %l13, !tbaa !27
  br label %bb18
bb17:
  br label %bb30
bb18:
  %t88 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp eq i64 %t90, 1
  br i1 %t92, label %bb19, label %bb20
bb19:
  %t94 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t98 = icmp eq i64 %t96, 0
  store i1 %t98, ptr %l56, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb21
bb21:
  %t100 = load i1, ptr %l56, !tbaa !21
  br i1 %t100, label %bb22, label %bb23
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  store ptr %t104, ptr %l61, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t109 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t105, i64 %a2)
  store i64 %t109, ptr %l64
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t110 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = load ptr, ptr %l61, !tbaa !29
  %t113 = load i64, ptr %l64, !tbaa !24
  %t115 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t112, i64 %t113, i32 %t111)
  store %"compiler/names:Ref" %t115, ptr %l66
  br label %bb25
bb25:
  %t116 = getelementptr %"compiler/names:Ref", ptr %l66, i32 0, i32 0
  %t117 = load i32, ptr %t116, !range !{i32 0, i32 9}
  %t119 = trunc i64 8 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb26, label %bb27
bb26:
  %t124 = getelementptr %"compiler/generic:Context", ptr %a1, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t125, ptr %l71, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 0
  %t129 = load i32, ptr %t128, !tbaa !33
  %t130 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t130, ptr %l73, !tbaa !27
  %t131 = load i64, ptr %l9, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i32, ptr %t134, i64 %t131
  %t136 = load i32, ptr %t135, !tbaa !33
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t124, i32 %t129, i32 %t136)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_1f5b32fdadeb85ff_22810fceb0d0eac3)
  unreachable
bb35:
  br label %bb36
bb36:
  %t140 = load i64, ptr %l7, !tbaa !24
  %t143 = add i64 %t140, 1
  store i64 %t143, ptr %l7, !tbaa !24
  br label %bb7
bb37:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebufferUnended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca i1
  %l9 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l26 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l13, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t27 = load i1, ptr %l18, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t38 = add i64 %a3, 1
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %t33, i32 %t34, ptr %a2, i64 %t38, i1 false)
  store i32 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i32, ptr %l26, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecFunc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i32
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l28 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l37 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i32
  %l47 = alloca i64
  %l50 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %a1, ptr %a2)
  store i32 %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l19, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l4, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l25
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i32, ptr %l25, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l26
  br label %bb7
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l28, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l32
  br label %bb8
bb8:
  %t52 = load ptr, ptr %l28, !tbaa !29
  %t53 = load i32, ptr %l32, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l33
  br label %bb9
bb9:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l4, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l37
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l4, !tbaa !23
  %t68 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t64, i32 %t65)
  store i64 %t68, ptr %l41
  br label %bb11
bb11:
  %t69 = load ptr, ptr %l19, !tbaa !29
  %t70 = load i32, ptr %l26, !tbaa !23
  %t71 = load i32, ptr %l33, !tbaa !23
  %t72 = load i32, ptr %l37, !tbaa !23
  %t73 = load i64, ptr %l41, !tbaa !24
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t69, i32 %t70, i32 %t71, i32 %t72, i32 0, i64 %t73, i1 false, i32 0, i64 0)
  store i32 %t74, ptr %l42
  br label %bb12
bb12:
  %t75 = load i32, ptr %l42, !tbaa !23
  store i32 %t75, ptr %l4, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load i32, ptr %l4, !tbaa !23
  store i32 %t79, ptr %l45, !tbaa !23
  br i1 %a3, label %bb13, label %bb14
bb13:
  %t82 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  store i64 %t82, ptr %l47, !tbaa !24
  br label %bb15
bb14:
  %t84 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t84, ptr %l47, !tbaa !24
  br label %bb15
bb15:
  %t86 = load ptr, ptr %l44, !tbaa !29
  %t87 = load i32, ptr %l45, !tbaa !23
  %t88 = load i64, ptr %l47, !tbaa !24
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t86, i32 %t87, i64 %t88)
  store i32 %t89, ptr %l50
  br label %bb16
bb16:
  %t90 = load i32, ptr %l50, !tbaa !23
  store i32 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %v2, ptr %t3, { i64, ptr } %t4)
  store i1 %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load i1, ptr %l7, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t10 = insertvalue { i32, i32 } zeroinitializer, i32 0, 1
  store { i32, i32 } %t10, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  store ptr %l3, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonType(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  %t16 = extractvalue { i32, i32 } %t15, 1
  %t17 = extractvalue { i32, i32 } %t15, 0
  store i32 %t17, ptr %l14
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb8, label %ok.19, !prof !99
ok.19:
  store i32 %t16, ptr %l13
  br label %bb7
bb7:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %l10, !tbaa !23
  br label %bb9
bb8:
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = lshr i32 %t21, 16
  %t23 = and i32 %t21, 65535
  %t24 = icmp eq i32 %t22, 1
  %t25 = select i1 %t24, i32 1, i32 0
  %t26 = icmp eq i32 %t22, 2
  %t27 = select i1 %t26, i32 2, i32 %t25
  %t28 = icmp eq i32 %t21, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t23
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t33 = insertvalue { i32, i32 } zeroinitializer, i32 %t31, 0
  store { i32, i32 } %t33, ptr %rv
  br label %ret
bb9:
  %t34 = load ptr, ptr %l9, !tbaa !29
  %t35 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t34, i32 %t35)
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %v2, ptr %t36, { i64, ptr } %t37)
  store i1 %t40, ptr %l18
  br label %bb11
bb11:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s2, ptr %t42, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t44, ptr %l20
  br label %bb15
bb15:
  %t45 = load i1, ptr %l20, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t49 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t49, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb6
bb20:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l24, !tbaa !29
  %t54 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t54, ptr %l26
  br label %bb21
bb21:
  %t55 = load ptr, ptr %l24, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t55, { i64, ptr } %t56)
  store i32 %t57, ptr %l27
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l27, !tbaa !23
  %t59 = insertvalue { i32, i32 } zeroinitializer, i32 %t58, 1
  store { i32, i32 } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l23 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t3, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t12 = or i64 %t7, %t9
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonInner(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  %t19 = extractvalue { i32, i32 } %t18, 1
  %t20 = extractvalue { i32, i32 } %t18, 0
  store i32 %t20, ptr %l15
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22, !prof !99
ok.22:
  store i32 %t19, ptr %l14
  br label %bb5
bb5:
  %t23 = load i32, ptr %l14, !tbaa !23
  store i32 %t23, ptr %l11, !tbaa !23
  br label %bb7
bb6:
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = lshr i32 %t24, 16
  %t26 = and i32 %t24, 65535
  %t27 = icmp eq i32 %t25, 1
  %t28 = select i1 %t27, i32 1, i32 0
  %t29 = icmp eq i32 %t25, 2
  %t30 = select i1 %t29, i32 2, i32 %t28
  %t31 = icmp eq i32 %t24, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t26
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  %t36 = insertvalue { i32, i32 } zeroinitializer, i32 %t34, 0
  store { i32, i32 } %t36, ptr %rv
  br label %ret
bb7:
  %t37 = load i32, ptr %l11, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v1, ptr %s0, ptr %t38, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t40, ptr %l18
  br label %bb8
bb8:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l3, !tbaa !23
  %t46 = load i64, ptr %l2, !tbaa !24
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t44, i32 %t45, i64 %t46)
  store i32 %t50, ptr %l23
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load i32, ptr %l23, !tbaa !23
  %t52 = insertvalue { i32, i32 } zeroinitializer, i32 %t51, 1
  store { i32, i32 } %t52, ptr %rv
  br label %ret
bb12:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t57 = icmp ne i64 %t53, %t54
  br i1 %t57, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t60, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t61 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t63 = insertvalue { i32, i32 } zeroinitializer, i32 %t61, 1
  store { i32, i32 } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2econstraint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/generic:varRow"
  %l6 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l26 = alloca i32
  %l30 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l40 = alloca i64
  %l45 = alloca %"compiler/generic:varRow"
  %l49 = alloca i1
  %l53 = alloca i1
  %l61 = alloca i32
  %l65 = alloca i32
  %l71 = alloca i32
  %l77 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca i64
  %l89 = alloca %"compiler/generic:varRow"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeParam", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/ast:TypeParam", ptr %t8, i32 0, i32 5
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Context", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TypeParam", ptr %t19, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v1, ptr %t18, i32 %t22)
  %t26 = extractvalue { i32, i32 } %t25, 1
  %t27 = extractvalue { i32, i32 } %t25, 0
  store i32 %t27, ptr %l21
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb8, label %ok.29, !prof !99
ok.29:
  store i32 %t26, ptr %l20
  br label %bb7
bb7:
  %t30 = load i32, ptr %l20, !tbaa !23
  store i32 %t30, ptr %l15, !tbaa !23
  br label %bb10
bb8:
  br label %bb9
bb9:
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t31, ptr %l15, !tbaa !23
  br label %bb10
bb10:
  %t33 = load i32, ptr %l15, !tbaa !23
  store i32 %t33, ptr %l3, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l26
  br label %bb11
bb11:
  %t41 = load i32, ptr %l26, !range !{i32 0, i32 33}
  %t43 = trunc i64 25 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 16
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Context", ptr %t51, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t50, i64 %t54)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l36
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb16, label %ok.61, !prof !99
ok.61:
  store i64 %t58, ptr %l35
  br label %bb15
bb15:
  %t62 = load i64, ptr %l35, !tbaa !24
  store i64 %t62, ptr %l30, !tbaa !24
  br label %bb18
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l40
  br label %bb19
bb19:
  %t70 = load i64, ptr %l30, !tbaa !24
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = add i64 %t70, %t71
  store i64 %t72, ptr %l4, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 18
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = call %"compiler/generic:varRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eAt_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/generic:varRow" %t80, ptr %l45
  br label %bb20
bb20:
  %t81 = load %"compiler/generic:varRow", ptr %l45
  store %"compiler/generic:varRow" %t81, ptr %l5
  %t82 = getelementptr %"compiler/generic:varRow", ptr %l5, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t84 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t87 = icmp ne i32 %t83, %t84
  br i1 %t87, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb22:
  %t89 = getelementptr %"compiler/generic:varRow", ptr %l5, i32 0, i32 3
  %t90 = load i32, ptr %t89, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t94 = icmp ne i32 %t90, %t91
  store i1 %t94, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb26
bb25:
  %t97 = getelementptr %"compiler/generic:varRow", ptr %l5, i32 0, i32 4
  %t98 = load i32, ptr %t97, !tbaa !23
  %t99 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t102 = icmp ne i32 %t98, %t99
  store i1 %t102, ptr %l53, !tbaa !21
  br label %bb26
bb26:
  %t104 = load i1, ptr %l53, !tbaa !21
  br i1 %t104, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  br label %bb29
bb29:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:TypeParam", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = icmp eq ptr %t108, null
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb30, label %bb31
bb30:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t120 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundOf(ptr %v0, ptr %v1, ptr %v2, ptr %t114, ptr %t115, ptr %t116)
  store i32 %t120, ptr %l65
  br label %bb32
bb31:
  %t121 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t121, ptr %l61, !tbaa !23
  br label %bb33
bb32:
  %t123 = load i32, ptr %l65, !tbaa !23
  store i32 %t123, ptr %l61, !tbaa !23
  br label %bb33
bb33:
  %t124 = load i32, ptr %l61, !tbaa !23
  store i32 %t124, ptr %l6, !tbaa !23
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = getelementptr %"compiler/ast:TypeParam", ptr %t125, i32 0, i32 5
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t138 = getelementptr %"compiler/ast:TypeParam", ptr %t136, i32 0, i32 5
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t144 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t134, ptr %t135, ptr %t139)
  store i32 %t144, ptr %l77
  br label %bb36
bb35:
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t145, ptr %l71, !tbaa !23
  br label %bb37
bb36:
  %t147 = load i32, ptr %l77, !tbaa !23
  store i32 %t147, ptr %l71, !tbaa !23
  br label %bb37
bb37:
  %t148 = load i32, ptr %l71, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 18
  store ptr %t151, ptr %l80, !tbaa !29
  %t152 = load i64, ptr %l4, !tbaa !24
  store i64 %t152, ptr %l81, !tbaa !24
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Context", ptr %t153, i32 0, i32 1
  %t156 = load i64, ptr %t155, !tbaa !24
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/ast:TypeParam", ptr %t157, i32 0, i32 1
  %t160 = load i32, ptr %t159, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t162 = load i32, ptr %l6, !tbaa !23
  %t169 = call %"compiler/generic:varRow" @compiler_2fgeneric_3avarRow_2ector(ptr %s0, i64 %t156, i32 %t160, i32 %t161, i32 %t162, i32 %t148)
  store %"compiler/generic:varRow" %t169, ptr %l89
  br label %bb38
bb38:
  %t170 = load ptr, ptr %l80, !tbaa !29
  %t171 = load i64, ptr %l81, !tbaa !24
  %t172 = load %"compiler/generic:varRow", ptr %l89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eSetAt_H989a0ed1a318d7d0cbb6cc41385b33d2(ptr %v0, ptr %t170, i64 %t171, %"compiler/generic:varRow" %t172)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l21 = alloca %"compiler/generic:Context"
  %l24 = alloca ptr
  %l28 = alloca i1
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l65 = alloca i32
  %l71 = alloca i32
  %l75 = alloca %"compiler/generic:Context"
  %t17 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 14
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l16
  br label %bb1
bb1:
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load i32, ptr %l1, !tbaa !23
  %t13 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t11)
  store i64 %t13, ptr %l18
  br label %bb2
bb2:
  %t14 = load i64, ptr %l18, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t17, ptr %v1, i64 %t15, i64 %t16)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t17, i64 160, i1 false)
  br label %bb3
bb3:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 160, i64 8)
  store ptr %t20, ptr %lp4
  %t21 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %l21, i64 160, i1 false)
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t22, i32 %t23)
  store ptr %t26, ptr %l24
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l24, !tbaa !29
  store ptr %t27, ptr %l5, !tbaa !29
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = icmp sgt i64 %t39, 0
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb8, label %bb9
bb8:
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TypeDecl", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb10, label %bb11
bb9:
  br label %bb24
bb10:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb15
bb12:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l42, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb14
bb14:
  %t77 = load i64, ptr %l42, !tbaa !24
  store i64 %t77, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l11, !tbaa !24
  %t97 = load ptr, ptr %lp4
  %t98 = getelementptr %"compiler/generic:Context", ptr %t97, i32 0, i32 2
  store ptr %t98, ptr %l60, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t101 = getelementptr %"compiler/ast:TypeDecl", ptr %t99, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l62, !tbaa !27
  %t103 = load i64, ptr %l11, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = getelementptr %"compiler/ast:TypeParam", ptr %t108, i32 0, i32 1
  %t111 = load i32, ptr %t110, !tbaa !23
  store i32 %t111, ptr %l65, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i64, ptr %l3, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t114, i64 %t115, i64 %t116, i64 %t117)
  store i32 %t122, ptr %l71
  br label %bb20
bb20:
  %t123 = load ptr, ptr %l60, !tbaa !29
  %t124 = load i32, ptr %l65, !tbaa !23
  %t125 = load i32, ptr %l71, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t123, i32 %t124, i32 %t125)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = add i64 %t126, 1
  store i64 %t129, ptr %l10, !tbaa !24
  br label %bb16
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr %t131, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l75, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclaresEq(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %t12, i32 %t13, i32 %t14)
  store i1 %t15, ptr %l8
  br label %bb2
bb2:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l10, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  store i32 %t18, ptr %l11, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 3
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t25, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i32 %t27, ptr %l15
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l10, !tbaa !29
  %t29 = load i32, ptr %l11, !tbaa !23
  %t30 = load i32, ptr %l15, !tbaa !23
  %t31 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %t28, i32 %t29, i32 %t30)
  store i1 %t31, ptr %l16
  br label %bb6
bb6:
  %t32 = load i1, ptr %l16, !tbaa !21
  store i1 %t32, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i1, ptr %l9, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edescDecl(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l3, !tbaa !29
  %t4 = call { i64, ptr } @compiler_2fgeneric_2edescName(ptr %s0, i64 %a1)
  store { i64, ptr } %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %s0, ptr %s0, ptr %t6, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d13, i32 0, i32 1) }, { i64, ptr } %t5)
  %t9 = extractvalue { i32, i32 } %t8, 1
  %t10 = extractvalue { i32, i32 } %t8, 0
  store i32 %t10, ptr %l8
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb3, label %ok.12, !prof !99
ok.12:
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t13 = load i32, ptr %l7, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i32 -1, ptr %l2, !tbaa !23
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i32, ptr %l2, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eensureModules(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l38 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca ptr
  %l53 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/load:Loader", ptr %t9, i32 0, i32 10
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load i64, ptr %l12, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l16, !tbaa !24
  store i64 %t42, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t51 = load i64, ptr %l1, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l3, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l6, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l38, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/load:Loader", ptr %t67, i32 0, i32 10
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l43
  br label %bb12
bb12:
  %t74 = load ptr, ptr %l43, !tbaa !29
  %t76 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t78 = load ptr, ptr %l38, !tbaa !29
  %t80 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v0, ptr %t78, { i64, ptr } %t77)
  store i64 %t80, ptr %l46
  br label %bb13
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 26
  store ptr %t83, ptr %l48, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/load:Loader", ptr %t87, i32 0, i32 10
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l53
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l53, !tbaa !29
  %t96 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l6, !tbaa !24
  %t99 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t99, { i64, ptr } %t97, i64 %t98)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t105 = add i64 %t102, 1
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb8
bb17:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l60, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/load:Loader", ptr %t111, i32 0, i32 10
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t113)
  store i64 %t115, ptr %l64
  br label %bb18
bb18:
  %t116 = load i64, ptr %l64, !tbaa !24
  %t117 = load ptr, ptr %l60, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 29
  store i64 %t116, ptr %t118, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentryHeld(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i64
  %l32 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t13, i64 %t14)
  store i32 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i32, ptr %l14, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l18
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l22
  br label %bb8
bb8:
  %t33 = load i32, ptr %l18, !tbaa !23
  %t34 = load i32, ptr %l22, !tbaa !23
  %t35 = icmp eq i32 %t33, %t34
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l28
  br label %bb11
bb10:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l5, !tbaa !23
  %t50 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t50, ptr %l32
  br label %bb12
bb12:
  %t51 = load i64, ptr %l32, !tbaa !65
  %t52 = xor i64 %t51, -1
  %t53 = load i64, ptr %l28, !tbaa !65
  %t55 = and i64 %t53, %t52
  %t57 = icmp eq i64 %t55, 0
  store i1 %t57, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l24, !tbaa !21
  br i1 %t59, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = add i64 %t61, 1
  store i64 %t64, ptr %l4, !tbaa !24
  br label %bb1
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsHaveVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t7 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t3, i32 %a1)
  store { i64, ptr } %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i32, ptr %t25, i64 %t22
  %t27 = load i32, ptr %t26, !tbaa !33
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %t29, i32 %t27, ptr %a2)
  store i1 %t35, ptr %l23
  br label %bb6
bb6:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalLit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca %"compiler/generic:folded"
  %l35 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i32
  %l41 = alloca %"compiler/generic:folded"
  %l45 = alloca %"compiler/generic:folded"
  %l48 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i64
  %l53 = alloca %"compiler/generic:folded"
  %l54 = alloca %"compiler/generic:folded"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 6
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_886433b88e29f460_704fa105f63225d4)
  unreachable
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t24 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v0, ptr %t20, %"compiler/source:Span" %a2)
  store { i64, ptr } %t24, ptr %l19
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t28 = trunc i64 2 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb25
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t31, ptr %l23, !tbaa !27
  %t32 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 0)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l25
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb10, label %ok.36, !prof !99
ok.36:
  store i64 %t33, ptr %l24
  br label %bb9
bb9:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t37, i64 %t38)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l27
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb13, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l26
  br label %bb12
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l29, !tbaa !27
  %t45 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 0)
  %t46 = extractvalue { i32, i64 } %t45, 1
  %t47 = extractvalue { i32, i64 } %t45, 0
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb15, label %ok.49, !prof !99
ok.49:
  store i64 %t46, ptr %l30
  br label %bb14
bb12:
  %t50 = load i64, ptr %l26, !tbaa !24
  store i64 %t50, ptr %l22, !tbaa !24
  br label %bb23
bb13:
  br label %bb11
bb14:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t51, i64 %t52)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l33
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb18, label %ok.57, !prof !99
ok.57:
  store i64 %t54, ptr %l32
  br label %bb17
bb15:
  br label %bb16
bb16:
  %t58 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t58, ptr %l34
  br label %bb19
bb17:
  %t59 = load i64, ptr %l32, !tbaa !65
  store i64 %t59, ptr %l28, !tbaa !65
  br label %bb20
bb18:
  br label %bb16
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t60 = load %"compiler/generic:folded", ptr %l34
  store %"compiler/generic:folded" %t60, ptr %rv
  br label %ret
bb20:
  %t61 = load i64, ptr %l28, !tbaa !65
  %t62 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t62, ptr %l35, !tbaa !24
  store i64 %t61, ptr %l37, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t67, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t69, ptr %l40
  br label %bb21
bb21:
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = load i64, ptr %l37, !tbaa !24
  %t72 = load i32, ptr %l40, !tbaa !23
  %t73 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s2, i64 %t70, i64 %t71, i32 %t72)
  store %"compiler/generic:folded" %t73, ptr %l41
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t74 = load %"compiler/generic:folded", ptr %l41
  store %"compiler/generic:folded" %t74, ptr %rv
  br label %ret
bb23:
  %t75 = load i64, ptr %l22, !tbaa !24
  %t76 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t78 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s1, i64 %t76, i64 %t75, i32 %t78)
  store %"compiler/generic:folded" %t82, ptr %l45
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t83 = load %"compiler/generic:folded", ptr %l45
  store %"compiler/generic:folded" %t83, ptr %rv
  br label %ret
bb25:
  %t84 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t86 = trunc i64 6 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb34
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t89, ptr %l48, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t90, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t92, ptr %l50
  br label %bb29
bb29:
  %t93 = load i1, ptr %l50, !tbaa !21
  br i1 %t93, label %bb30, label %bb31
bb30:
  store i64 1, ptr %l51, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb32
bb32:
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t95 = load i64, ptr %l48, !tbaa !24
  %t96 = load i64, ptr %l51, !tbaa !24
  %t98 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s4, i64 %t95, i64 %t96, i32 %t94)
  store %"compiler/generic:folded" %t98, ptr %l53
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  %t99 = load %"compiler/generic:folded", ptr %l53
  store %"compiler/generic:folded" %t99, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t100 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t100, ptr %l54
  br label %bb38
bb38:
  %t101 = load %"compiler/generic:folded", ptr %l54
  store %"compiler/generic:folded" %t101, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_cbe34de7626751c6_f090548a7d71387a)
  unreachable
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eevalUnary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca %"compiler/generic:folded"
  %l8 = alloca %"compiler/generic:folded"
  %l13 = alloca %"compiler/generic:folded"
  %l16 = alloca i64
  %l21 = alloca i64
  %l23 = alloca %"compiler/generic:folded"
  %l26 = alloca i64
  %l31 = alloca i64
  %l33 = alloca %"compiler/generic:folded"
  %l40 = alloca %"compiler/generic:folded"
  %l41 = alloca %"compiler/generic:folded"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %a1, ptr %a3)
  store %"compiler/generic:folded" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:folded", ptr %l8
  store %"compiler/generic:folded" %t8, ptr %l4
  %t9 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t14 = icmp ne i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load %"compiler/generic:folded", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/generic:folded" %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t20 = trunc i64 69 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t23 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t23, ptr %l16, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = sub i64 0, %t26
  %t29 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t34 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t24, i64 %t28, i32 %t30)
  store i64 %t34, ptr %l21
  br label %bb8
bb8:
  %t35 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  %t37 = load i64, ptr %l16, !tbaa !24
  %t38 = load i64, ptr %l21, !tbaa !24
  %t40 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s0, i64 %t37, i64 %t38, i32 %t36)
  store %"compiler/generic:folded" %t40, ptr %l23
  br label %bb9
bb9:
  %t41 = load %"compiler/generic:folded", ptr %l23
  store %"compiler/generic:folded" %t41, ptr %l13
  br label %bb27
bb10:
  %t42 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t44 = trunc i64 105 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t47 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  store i64 %t47, ptr %l26, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 1
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = xor i64 %t50, -1
  %t53 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t54 = load i32, ptr %t53, !tbaa !23
  %t58 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %t48, i64 %t52, i32 %t54)
  store i64 %t58, ptr %l31
  br label %bb14
bb14:
  %t59 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 2
  %t60 = load i32, ptr %t59, !tbaa !23
  %t61 = load i64, ptr %l26, !tbaa !24
  %t62 = load i64, ptr %l31, !tbaa !24
  %t64 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s0, i64 %t61, i64 %t62, i32 %t60)
  store %"compiler/generic:folded" %t64, ptr %l33
  br label %bb15
bb15:
  %t65 = load %"compiler/generic:folded", ptr %l33
  store %"compiler/generic:folded" %t65, ptr %l13
  br label %bb27
bb16:
  %t66 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t68 = trunc i64 48 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t71 = load i64, ptr @G_2ecompiler_2fgeneric_2eFolded, !tbaa !24
  %t72 = getelementptr %"compiler/generic:folded", ptr %l4, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = sub i64 1, %t73
  %t76 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t80 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s0, i64 %t71, i64 %t75, i32 %t76)
  store %"compiler/generic:folded" %t80, ptr %l40
  br label %bb20
bb20:
  %t81 = load %"compiler/generic:folded", ptr %l40
  store %"compiler/generic:folded" %t81, ptr %l13
  br label %bb27
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t82 = call %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded()
  store %"compiler/generic:folded" %t82, ptr %l41
  br label %bb25
bb25:
  %t83 = load %"compiler/generic:folded", ptr %l41
  store %"compiler/generic:folded" %t83, ptr %l13
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_5392f566c0fc8331_15db183dd26dbb85)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load %"compiler/generic:folded", ptr %l13
  store %"compiler/generic:folded" %t84, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eextends(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store ptr %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 2
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalInIf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l9 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l29 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i64
  %l45 = alloca ptr
  %l50 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i64
  %l65 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb3:
  call void @__olang_check_failed(ptr @olang_loc_514348f953d022bc_74505ba6df313dd0)
  unreachable
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sgt i64 %t23, 0
  store i1 %t25, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l9, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l20, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopIf", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_514348f953d022bc_74505ba6df313dd0)
  unreachable
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load i32, ptr %l5, !tbaa !23
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i64, ptr %l20, !tbaa !24
  %t50 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalIn(ptr %v0, ptr %v1, ptr %v2, ptr %t46, i64 %t47, { i64, ptr } %t44, i32 %t45)
  store ptr %t50, ptr %l29
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l29, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/ast:TopIf", ptr %t52, i32 0, i32 2
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l34, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  store i64 %t62, ptr %l35, !tbaa !24
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/ast:TopIf", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_289ae50874ea0e2b_45680487effe832f)
  unreachable
bb17:
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"compiler/ast:TopIf", ptr %t70, i32 0, i32 2
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t75, 1
  %t78 = load i32, ptr %l5, !tbaa !23
  %t79 = load ptr, ptr %l34, !tbaa !29
  %t80 = load i64, ptr %l35, !tbaa !24
  %t85 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalInIf(ptr %v0, ptr %v1, ptr %v2, ptr %t79, i64 %t80, ptr %t73, i64 %t74, i64 %t77, i32 %t78)
  store ptr %t85, ptr %l45
  br label %bb19
bb19:
  %t86 = load ptr, ptr %l45, !tbaa !29
  store ptr %t86, ptr %rv
  br label %ret
bb20:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/ast:TopIf", ptr %t87, i32 0, i32 3
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t97 = load i64, ptr %l4, !tbaa !24
  %t99 = add i64 %t97, 1
  %t102 = icmp eq i64 %t96, %t99
  store i1 %t102, ptr %l50, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb23
bb23:
  %t104 = load i1, ptr %l50, !tbaa !21
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  %t106 = load i64, ptr %l1, !tbaa !24
  store i64 %t106, ptr %l56, !tbaa !24
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t109 = getelementptr %"compiler/ast:TopIf", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d51864a21628ffaa_68720bbe5c137f7e)
  unreachable
bb27:
  br label %bb28
bb28:
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:TopIf", ptr %t114, i32 0, i32 3
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t120 = getelementptr %"compiler/ast:TopBranch", ptr %t117, i32 0, i32 1
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t122 = load i32, ptr %l5, !tbaa !23
  %t123 = load ptr, ptr %l55, !tbaa !29
  %t124 = load i64, ptr %l56, !tbaa !24
  %t127 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalIn(ptr %v0, ptr %v1, ptr %v2, ptr %t123, i64 %t124, { i64, ptr } %t121, i32 %t122)
  store ptr %t127, ptr %l65
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l65, !tbaa !29
  store ptr %t128, ptr %rv
  br label %ret
bb30:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eheld(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l9 = alloca i1
  %l12 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i1, ptr %l12, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr %l1, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l18
  br label %bb9
bb9:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t38 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t36, i32 %t37, i64 %t38)
  store i32 %t42, ptr %l23
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t43 = load i32, ptr %l23, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb13:
  %t44 = load i32, ptr %l1, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i64
  %l47 = alloca %"compiler/names:Ref"
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l57 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l131 = alloca { i64, ptr }
  %l138 = alloca i1
  %l140 = alloca ptr
  %l143 = alloca i64
  %l146 = alloca %"compiler/names:Ref"
  %l149 = alloca i1
  %l152 = alloca { i64, ptr }
  %l154 = alloca i1
  %l158 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t6 = load ptr, ptr %l22, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l22, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l23, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l23, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l5
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l6, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t28, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  store { i64, ptr } %t30, ptr %l7, !tbaa !27
  br label %bb8
bb7:
  br label %bb35
bb8:
  %t32 = load i1, ptr %l4, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t38 = icmp eq i64 %t36, 1
  store i1 %t38, ptr %l33, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l33, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  store i1 %t45, ptr %l37, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l37, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  store ptr %t51, ptr %l42, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l45
  br label %bb17
bb16:
  br label %bb27
bb17:
  %t57 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = load ptr, ptr %l42, !tbaa !29
  %t60 = load i64, ptr %l45, !tbaa !24
  %t62 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t59, i64 %t60, i32 %t58)
  store %"compiler/names:Ref" %t62, ptr %l47
  br label %bb18
bb18:
  %t63 = getelementptr %"compiler/names:Ref", ptr %l47, i32 0, i32 0
  %t64 = load i32, ptr %t63, !range !{i32 0, i32 9}
  %t66 = trunc i64 8 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t70, ptr %l52, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 0
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t69, i32 %t74)
  store i1 %t77, ptr %l54
  br label %bb21
bb20:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t78 = load i1, ptr %l54, !tbaa !21
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t81 = load i1, ptr %l50, !tbaa !21
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t83, ptr %l57, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i32, ptr %t85, i64 0
  %t87 = load i32, ptr %t86, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t82, i32 %t87)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %ret
bb27:
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l10, !tbaa !24
  br label %bb28
bb28:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t104, ptr %l66, !tbaa !27
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l1, !tbaa !24
  %t116 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v1, ptr %v2, ptr %t112, i64 %t113, ptr %t110, ptr %t116, i1 true)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l9, !tbaa !24
  br label %bb28
bb34:
  br label %bb90
bb35:
  %t126 = load ptr, ptr %l2, !tbaa !29
  store ptr %t126, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t127 = load ptr, ptr %l77, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb36, label %bb37
bb36:
  %t130 = load ptr, ptr %l77, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 8}
  %t133 = icmp eq i64 %t131, 3
  store i1 %t133, ptr %l78, !tbaa !21
  br label %bb37
bb37:
  %t134 = load i1, ptr %l78, !tbaa !21
  br i1 %t134, label %bb38, label %bb39
bb38:
  %t135 = load ptr, ptr %l2, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t137, i32 0, i32 1
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l12, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l1, !tbaa !24
  %t143 = load ptr, ptr %l12, !tbaa !29
  %t145 = load ptr, ptr %l3, !tbaa !29
  %t146 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v1, ptr %v2, ptr %t141, i64 %t142, ptr %t143, ptr %t145, i1 %t146)
  br label %bb41
bb41:
  br label %bb90
bb42:
  %t152 = load ptr, ptr %l2, !tbaa !29
  store ptr %t152, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t153 = load ptr, ptr %l89, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb43, label %bb44
bb43:
  %t156 = load ptr, ptr %l89, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 8}
  %t159 = icmp eq i64 %t157, 4
  store i1 %t159, ptr %l90, !tbaa !21
  br label %bb44
bb44:
  %t160 = load i1, ptr %l90, !tbaa !21
  br i1 %t160, label %bb45, label %bb46
bb45:
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t163 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t163, i32 0, i32 1
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l13, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i64, ptr %l1, !tbaa !24
  %t169 = load ptr, ptr %l13, !tbaa !29
  %t170 = load ptr, ptr %l3, !tbaa !29
  %t171 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v1, ptr %v2, ptr %t167, i64 %t168, ptr %t169, ptr %t170, i1 %t171)
  br label %bb48
bb48:
  br label %bb90
bb49:
  %t177 = load ptr, ptr %l2, !tbaa !29
  store ptr %t177, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t178 = load ptr, ptr %l100, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb50, label %bb51
bb50:
  %t181 = load ptr, ptr %l100, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 8}
  %t184 = icmp eq i64 %t182, 5
  store i1 %t184, ptr %l101, !tbaa !21
  br label %bb51
bb51:
  %t185 = load i1, ptr %l101, !tbaa !21
  br i1 %t185, label %bb52, label %bb53
bb52:
  %t186 = load ptr, ptr %l2, !tbaa !29
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", ptr }, ptr %t188, i32 0, i32 1
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l14, !tbaa !29
  br label %bb58
bb53:
  %t192 = load ptr, ptr %l2, !tbaa !29
  store ptr %t192, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t193 = load ptr, ptr %l106, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb54, label %bb55
bb54:
  %t196 = load ptr, ptr %l106, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 8}
  %t199 = icmp eq i64 %t197, 7
  store i1 %t199, ptr %l107, !tbaa !21
  br label %bb55
bb55:
  %t200 = load i1, ptr %l107, !tbaa !21
  br i1 %t200, label %bb56, label %bb57
bb56:
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t203 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", ptr }, ptr %t203, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l14, !tbaa !29
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  %t209 = load ptr, ptr %l14, !tbaa !29
  %t211 = load ptr, ptr %l3, !tbaa !29
  %t212 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eintroductions(ptr %v0, ptr %v1, ptr %v2, ptr %t207, i64 %t208, ptr %t209, ptr %t211, i1 %t212)
  br label %bb59
bb59:
  br label %bb90
bb60:
  %t218 = load ptr, ptr %l2, !tbaa !29
  store ptr %t218, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t219 = load ptr, ptr %l118, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb61, label %bb62
bb61:
  %t222 = load ptr, ptr %l118, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 8}
  %t225 = icmp eq i64 %t223, 6
  store i1 %t225, ptr %l119, !tbaa !21
  br label %bb62
bb62:
  %t226 = load i1, ptr %l119, !tbaa !21
  br i1 %t226, label %bb63, label %bb64
bb63:
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t229 = getelementptr { i64, [5 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t229, i32 0, i32 1
  %t231 = load { i64, ptr }, ptr %t230
  store { i64, ptr } %t231, ptr %l15, !tbaa !27
  br label %bb65
bb64:
  br label %bb85
bb65:
  %t233 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t233, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l18, !tbaa !24
  br label %bb66
bb66:
  %t239 = load i64, ptr %l17, !tbaa !24
  %t240 = load i64, ptr %l18, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb67, label %bb68
bb67:
  br label %bb84
bb68:
  br label %bb69
bb69:
  %t247 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t247, ptr %l131, !tbaa !27
  %t248 = load i64, ptr %l17, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr ptr, ptr %t251, i64 %t248
  %t253 = load ptr, ptr %t252, !tbaa !39
  store ptr %t253, ptr %l19, !tbaa !29
  %t255 = load ptr, ptr %l19, !tbaa !29
  %t257 = getelementptr %"compiler/ast:Path", ptr %t255, i32 0, i32 1
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t262 = icmp eq i64 %t260, 1
  br i1 %t262, label %bb70, label %bb71
bb70:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  store ptr %t267, ptr %l140, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load i64, ptr %l1, !tbaa !24
  %t272 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t268, i64 %t269)
  store i64 %t272, ptr %l143
  br label %bb72
bb71:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb74
bb72:
  %t273 = load ptr, ptr %l19, !tbaa !29
  %t275 = getelementptr %"compiler/ast:Path", ptr %t273, i32 0, i32 0
  %t276 = getelementptr %"compiler/source:Span", ptr %t275, i32 0, i32 0
  %t277 = load i32, ptr %t276, !tbaa !23
  %t278 = load ptr, ptr %l140, !tbaa !29
  %t279 = load i64, ptr %l143, !tbaa !24
  %t281 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t278, i64 %t279, i32 %t277)
  store %"compiler/names:Ref" %t281, ptr %l146
  br label %bb73
bb73:
  %t282 = getelementptr %"compiler/names:Ref", ptr %l146, i32 0, i32 0
  %t283 = load i32, ptr %t282, !range !{i32 0, i32 9}
  %t285 = trunc i64 8 to i32
  %t286 = icmp eq i32 %t283, %t285
  store i1 %t286, ptr %l138, !tbaa !21
  br label %bb74
bb74:
  %t288 = load i1, ptr %l138, !tbaa !21
  br i1 %t288, label %bb75, label %bb76
bb75:
  %t289 = load ptr, ptr %l3, !tbaa !29
  %t290 = load ptr, ptr %l19, !tbaa !29
  %t292 = getelementptr %"compiler/ast:Path", ptr %t290, i32 0, i32 1
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  store { i64, ptr } %t293, ptr %l152, !tbaa !27
  %t294 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr i32, ptr %t295, i64 0
  %t297 = load i32, ptr %t296, !tbaa !33
  %t300 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t289, i32 %t297)
  store i1 %t300, ptr %l154
  br label %bb77
bb76:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb78
bb77:
  %t301 = load i1, ptr %l154, !tbaa !21
  %t302 = xor i1 %t301, true
  store i1 %t302, ptr %l149, !tbaa !21
  br label %bb78
bb78:
  %t304 = load i1, ptr %l149, !tbaa !21
  br i1 %t304, label %bb79, label %bb80
bb79:
  %t305 = load ptr, ptr %l3, !tbaa !29
  %t306 = load ptr, ptr %l19, !tbaa !29
  %t308 = getelementptr %"compiler/ast:Path", ptr %t306, i32 0, i32 1
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  store { i64, ptr } %t309, ptr %l158, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i32, ptr %t311, i64 0
  %t313 = load i32, ptr %t312, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t305, i32 %t313)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t316 = load i64, ptr %l17, !tbaa !24
  %t319 = add i64 %t316, 1
  store i64 %t319, ptr %l17, !tbaa !24
  br label %bb66
bb84:
  br label %bb90
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_e8d533ef83292235_9ed3ad18ce9fa601)
  unreachable
bb90:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i32
  %l18 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t10 = trunc i64 20 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l13
  br label %bb4
bb3:
  %t20 = load i32, ptr %l1, !tbaa !23
  store i32 %t20, ptr %l9, !tbaa !23
  br label %bb5
bb4:
  %t22 = load i32, ptr %l13, !tbaa !23
  store i32 %t22, ptr %l9, !tbaa !23
  br label %bb5
bb5:
  %t23 = load i32, ptr %l9, !tbaa !23
  store i32 %t23, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereprReady(ptr %v0, ptr %t24, i32 %t25)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = load i32, ptr %l22, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l23
  br label %bb8
bb8:
  %t41 = load i32, ptr %l23, !range !{i32 0, i32 33}
  %t43 = trunc i64 19 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisEnumT(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i32, ptr %l14, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t28 = trunc i64 1 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l8, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisStructT(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t10 = trunc i64 18 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i32, ptr %l14, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t28 = trunc i64 0 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l8, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eisVar(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t10 = trunc i64 25 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t15, i32 %t16)
  store i64 %t19, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t22 = getelementptr %"compiler/generic:Binding", ptr %a2, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t26 = icmp eq i64 %t24, %t23
  store i1 %t26, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t28 = load i1, ptr %l9, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eitemsElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i32
  %l17 = alloca i1
  %l21 = alloca i32
  %l23 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca i32
  %l38 = alloca i32
  %l42 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l53 = alloca i1
  %l57 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t10 = trunc i64 19 to i32
  %t11 = icmp eq i32 %t8, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l21
  br label %bb4
bb4:
  %t22 = load i32, ptr %l21, !tbaa !23
  %t23 = icmp ne i32 %t22, 0
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load i32, ptr %l3, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l31, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 0
  %t42 = load ptr, ptr %t41, !tbaa !39
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t37, ptr %t42)
  store i32 %t48, ptr %l34
  br label %bb12
bb12:
  %t49 = load i32, ptr %l34, !tbaa !23
  store i32 %t49, ptr %l5, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l38
  br label %bb13
bb13:
  %t57 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t59 = trunc i64 19 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb18
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l44, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l48
  br label %bb16
bb16:
  %t74 = load ptr, ptr %l44, !tbaa !29
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t76, ptr %l49
  br label %bb17
bb17:
  %t77 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t79 = trunc i64 26 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb22
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l5, !tbaa !23
  %t87 = load i32, ptr %l3, !tbaa !23
  %t91 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t85, i32 %t86, i32 %t87)
  store i1 %t91, ptr %l57
  br label %bb21
bb21:
  %t92 = load i1, ptr %l57, !tbaa !21
  %t93 = xor i1 %t92, true
  store i1 %t93, ptr %l53, !tbaa !21
  br label %bb22
bb22:
  %t95 = load i1, ptr %l53, !tbaa !21
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t96 = load i32, ptr %l3, !tbaa !23
  store i32 %t96, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t98 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t98, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l8, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb27, label %bb28
bb27:
  br label %bb36
bb28:
  br label %bb29
bb29:
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t112, ptr %l67, !tbaa !27
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr ptr, ptr %t116, i64 %t113
  %t118 = load ptr, ptr %t117, !tbaa !39
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l71, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t132 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t123, ptr %t124, ptr %t125, ptr %t118)
  store i32 %t132, ptr %l77
  br label %bb30
bb30:
  %t133 = load i32, ptr %l5, !tbaa !23
  %t134 = load ptr, ptr %l71, !tbaa !29
  %t135 = load i32, ptr %l77, !tbaa !23
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t134, i32 %t135, i32 %t133)
  store i1 %t137, ptr %l79
  br label %bb31
bb31:
  %t138 = load i1, ptr %l79, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  %t141 = load i32, ptr %l3, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t143 = load i64, ptr %l7, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l7, !tbaa !24
  br label %bb26
bb36:
  %t148 = load i32, ptr %l5, !tbaa !23
  store i32 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elengthsDecided(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l18 = alloca i64
  %l26 = alloca i1
  %l35 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/source:Span"
  %l52 = alloca { i64, ptr }
  %l59 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l81 = alloca i1
  %l93 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l118 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/generic:fnRow", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Func", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Sig", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = add i64 %t12, 1
  store i64 %t14, ptr %l18, !tbaa !24
  %t15 = load i64, ptr %l18, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/generic:fnRow", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Func", ptr %t27, i32 0, i32 4
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4860714026464204_4592c2a1d2b55600)
  unreachable
bb3:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb4:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/generic:fnRow", ptr %t36, i32 0, i32 2
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb6, label %bb7
bb6:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 10
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/generic:fnRow", ptr %t50, i32 0, i32 0
  %t53 = load i64, ptr %t52, !tbaa !24
  %t56 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t49, i64 %t53)
  store ptr %t56, ptr %l35
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t59 = getelementptr %"compiler/load:Module", ptr %t57, i32 0, i32 6
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l4, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_360fa96f69d7f913_7dd7870a86c7dc67)
  unreachable
bb11:
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/source:Source", ptr %t66, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l5, !tbaa !27
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/generic:fnRow", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Func", ptr %t75, i32 0, i32 4
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l45, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 0
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t84 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t82)
  store %"compiler/source:Span" %t84, ptr %l47
  br label %bb13
bb13:
  %t85 = getelementptr %"compiler/source:Span", ptr %l47, i32 0, i32 0
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = sext i32 %t86 to i64
  store i64 %t88, ptr %l6, !tbaa !24
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/generic:fnRow", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Func", ptr %t93, i32 0, i32 4
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l52, !tbaa !27
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/generic:fnRow", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Func", ptr %t100, i32 0, i32 4
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = sub i64 %t105, 1
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 %t107
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l59
  br label %bb14
bb14:
  %t115 = getelementptr %"compiler/source:Span", ptr %l59, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store i64 %t118, ptr %l7, !tbaa !24
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr %"compiler/generic:fnRow", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Func", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb15, label %bb16
bb15:
  %t132 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t132, ptr %l67, !tbaa !27
  %t133 = load i64, ptr %l6, !tbaa !24
  store i64 %t133, ptr %l68, !tbaa !24
  %t134 = load i64, ptr %l7, !tbaa !24
  store i64 %t134, ptr %l69, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l70, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr %"compiler/generic:fnRow", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Func", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  br i1 %t144, label %bb17, label %bb18
bb16:
  br label %bb22
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4472349556a15fd2_df3caa9bde222db6)
  unreachable
bb18:
  br label %bb19
bb19:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr %"compiler/generic:fnRow", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/ast:Func", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t155 = getelementptr %"compiler/ast:Param", ptr %t152, i32 0, i32 1
  %t156 = load i32, ptr %t155, !tbaa !23
  %t157 = load ptr, ptr %l70, !tbaa !29
  %t159 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t157, i32 %t156)
  store { i64, ptr } %t159, ptr %l80
  br label %bb20
bb20:
  %t160 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t161 = load i64, ptr %l68, !tbaa !24
  %t162 = load i64, ptr %l69, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t164 = call i1 @compiler_2fgeneric_2eLengthDecided(ptr %v0, ptr %v0, { i64, ptr } %t160, i64 %t161, i64 %t162, { i64, ptr } %t163)
  store i1 %t164, ptr %l81
  br label %bb21
bb21:
  %t165 = load i1, ptr %l81, !tbaa !21
  %t166 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i1, ptr %t167, i64 0
  store i1 %t165, ptr %t168, !tbaa !31
  br label %bb22
bb22:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/generic:fnRow", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/ast:Func", ptr %t172, i32 0, i32 3
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Sig", ptr %t175, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t184 = load i64, ptr %l9, !tbaa !24
  %t185 = load i64, ptr %l10, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb24, label %bb25
bb24:
  br label %bb35
bb25:
  br label %bb26
bb26:
  %t192 = load i64, ptr %l9, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t194, ptr %l93, !tbaa !27
  %t195 = load i64, ptr %l9, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  store ptr %t200, ptr %l12, !tbaa !29
  %t204 = add i64 %t192, 1
  store i64 %t204, ptr %l97, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t205, ptr %l98, !tbaa !27
  %t206 = load i64, ptr %l6, !tbaa !24
  store i64 %t206, ptr %l99, !tbaa !24
  %t207 = load i64, ptr %l7, !tbaa !24
  store i64 %t207, ptr %l100, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l12, !tbaa !29
  %t211 = getelementptr %"compiler/ast:Param", ptr %t209, i32 0, i32 1
  %t212 = load i32, ptr %t211, !tbaa !23
  %t215 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t208, i32 %t212)
  store { i64, ptr } %t215, ptr %l104
  br label %bb27
bb27:
  %t216 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t217 = load i64, ptr %l99, !tbaa !24
  %t218 = load i64, ptr %l100, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t220 = call i1 @compiler_2fgeneric_2eLengthDecided(ptr %v0, ptr %v0, { i64, ptr } %t216, i64 %t217, i64 %t218, { i64, ptr } %t219)
  store i1 %t220, ptr %l105
  br label %bb28
bb28:
  %t221 = load i1, ptr %l105, !tbaa !21
  br i1 %t221, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb33
bb30:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l107, !tbaa !29
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr %"compiler/generic:fnRow", ptr %t223, i32 0, i32 0
  %t226 = load i64, ptr %t225, !tbaa !24
  store i64 %t226, ptr %l109, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t227, ptr %l110, !tbaa !27
  %t228 = load i64, ptr %l6, !tbaa !24
  store i64 %t228, ptr %l111, !tbaa !24
  %t229 = load i64, ptr %l7, !tbaa !24
  store i64 %t229, ptr %l112, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l12, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Param", ptr %t231, i32 0, i32 1
  %t234 = load i32, ptr %t233, !tbaa !23
  %t237 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t230, i32 %t234)
  store { i64, ptr } %t237, ptr %l116
  br label %bb31
bb31:
  %t239 = load ptr, ptr %l107, !tbaa !29
  %t240 = load i64, ptr %l109, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t242 = load i64, ptr %l111, !tbaa !24
  %t243 = load i64, ptr %l112, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t246 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehandedOn(ptr %v0, ptr %v0, ptr %v0, ptr %t239, i64 %t240, { i64, ptr } %t241, i64 %t242, i64 %t243, { i64, ptr } %t244, i64 %a2)
  store i1 %t246, ptr %l118
  br label %bb32
bb32:
  %t247 = load i1, ptr %l118, !tbaa !21
  store i1 %t247, ptr %l106, !tbaa !21
  br label %bb33
bb33:
  %t248 = load i1, ptr %l106, !tbaa !21
  %t249 = load i64, ptr %l97, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i1, ptr %t251, i64 %t249
  store i1 %t248, ptr %t252, !tbaa !31
  br label %bb34
bb34:
  %t253 = load i64, ptr %l9, !tbaa !24
  %t256 = add i64 %t253, 1
  store i64 %t256, ptr %l9, !tbaa !24
  br label %bb23
bb35:
  %t258 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t258, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elevelCount(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i64
  %l20 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i64
  %l27 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l3
  %t9 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t11 = trunc i64 20 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l11, !tbaa !29
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elevelCount(ptr %v0, ptr %t22, i32 %t23, i1 false)
  store i64 %t24, ptr %l16
  br label %bb6
bb6:
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %l8, !tbaa !24
  br label %bb25
bb7:
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t28 = trunc i64 19 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  br i1 %a2, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l24
  br label %bb13
bb12:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb13:
  %t40 = load i32, ptr %l24, !tbaa !23
  %t41 = icmp eq i32 %t40, 0
  store i1 %t41, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l26, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb17
bb17:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l31
  br label %bb18
bb18:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i32, ptr %l31, !tbaa !23
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2elevelCount(ptr %v0, ptr %t52, i32 %t53, i1 true)
  store i64 %t54, ptr %l32
  br label %bb19
bb19:
  %t55 = load i64, ptr %l26, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = add i64 %t55, %t56
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_c640e61325a8531d_77d5bebedc0f2c09)
  unreachable
bb25:
  %t59 = load i64, ptr %l8, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eliteralType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t3 = trunc i64 2 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i32 %t10, ptr %l7
  br label %bb4
bb4:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb29
bb5:
  %t12 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t14 = trunc i64 3 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i32 %t21, ptr %l12
  br label %bb9
bb9:
  %t22 = load i32, ptr %l12, !tbaa !23
  store i32 %t22, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb10:
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t25 = trunc i64 6 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t28, ptr %l2, !tbaa !23
  br label %bb29
bb14:
  %t30 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t32 = trunc i64 5 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %t35)
  store i32 %t37, ptr %l19
  br label %bb18
bb18:
  %t38 = load i32, ptr %l19, !tbaa !23
  store i32 %t38, ptr %l2, !tbaa !23
  br label %bb29
bb19:
  %t39 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t41 = trunc i64 4 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %s5, ptr %s5, ptr %t44, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d18, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i32 %t46, ptr %l23
  br label %bb23
bb23:
  %t47 = load i32, ptr %l23, !tbaa !23
  store i32 %t47, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t48, ptr %l2, !tbaa !23
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fc435fbf179ab4a3_d5536eec81a24b6f)
  unreachable
bb29:
  %t50 = load i32, ptr %l2, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emadeType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l33 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca %"compiler/names:Ref"
  %l42 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i32
  %l67 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t9 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecallType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1, ptr %t2, ptr %t3, ptr %t4)
  store i32 %t9, ptr %l13
  br label %bb1
bb1:
  %t10 = load i32, ptr %l13, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t12 = load ptr, ptr %l14, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l14, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 28}
  %t18 = icmp eq i64 %t16, 11
  store i1 %t18, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb6:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 28}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32 }, ptr %t40, i32 0, i32 0
  %t42 = load %"compiler/source:Span", ptr %t41
  store %"compiler/source:Span" %t42, ptr %l6
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32 }, ptr %t50, i32 0, i32 1
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l7, !tbaa !23
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t56, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  br label %bb11
bb10:
  br label %bb33
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Context", ptr %t65, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  %t71 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t64, i64 %t68)
  store i64 %t71, ptr %l37
  br label %bb12
bb12:
  %t72 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  %t74 = load ptr, ptr %l33, !tbaa !29
  %t75 = load i64, ptr %l37, !tbaa !24
  %t77 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t74, i64 %t75, i32 %t73)
  store %"compiler/names:Ref" %t77, ptr %l39
  br label %bb13
bb13:
  %t78 = getelementptr %"compiler/names:Ref", ptr %l39, i32 0, i32 0
  %t79 = load i32, ptr %t78, !range !{i32 0, i32 9}
  %t81 = trunc i64 7 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l7, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v0, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l45
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb18
bb16:
  %t89 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t89, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t90, ptr %l46
  br label %bb17
bb17:
  %t91 = load i1, ptr %l46, !tbaa !21
  store i1 %t91, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t92 = load i1, ptr %l42, !tbaa !21
  br i1 %t92, label %bb19, label %bb20
bb19:
  %t93 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp eq i64 %t95, 1
  store i1 %t97, ptr %l47, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb21
bb21:
  %t99 = load i1, ptr %l47, !tbaa !21
  br i1 %t99, label %bb22, label %bb23
bb22:
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = icmp sgt i64 %t102, 0
  store i1 %t104, ptr %l51, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t106 = load i1, ptr %l51, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l5, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l59
  br label %bb27
bb26:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb28
bb27:
  %t114 = load i32, ptr %l59, !range !{i32 0, i32 33}
  %t116 = trunc i64 19 to i32
  %t117 = icmp eq i32 %t114, %t116
  store i1 %t117, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t119 = load i1, ptr %l55, !tbaa !21
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t123 = load i32, ptr %l5, !tbaa !23
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t130 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2earrayMade(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t120, ptr %t121, ptr %t122, i32 %t123, { i64, ptr } %t124)
  store i32 %t130, ptr %l67
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s1)
  %t131 = load i32, ptr %l67, !tbaa !23
  store i32 %t131, ptr %rv
  br label %ret
bb32:
  call void @__olang_scope_close(ptr %s1)
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_5761ebb5a70d3685_c26bb19c18fbb051)
  unreachable
bb38:
  %t132 = load i32, ptr %l5, !tbaa !23
  store i32 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetTyped(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l1, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t11 = load i32, ptr %l2, !tbaa !23
  %t15 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t9, i32 %t10, i32 %t11)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  store i32 %t17, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t21 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t19, i32 %t20, i32 %t21)
  store i1 %t25, ptr %l15
  br label %bb8
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/generic:Context"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i32
  %l27 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca %"compiler/generic:Context"
  %l55 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca i64
  %l69 = alloca i32
  %l70 = alloca i32
  %l73 = alloca i1
  %l81 = alloca i1
  %s3 = alloca %olang.scope
  %t68 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l20
  br label %bb3
bb3:
  %t12 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t12, %t14
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l27
  br label %bb8
bb8:
  %t27 = load i32, ptr %l27, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l4, !tbaa !23
  %t32 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store ptr %t32, ptr %l30
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l30, !tbaa !29
  store ptr %t33, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb12
bb11:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/ast:TypeDecl", ptr %t38, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  store i1 %t43, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l33, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TypeDecl", ptr %t46, i32 0, i32 3
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l6, !tbaa !29
  %t51 = load ptr, ptr %l6, !tbaa !29
  store ptr %t51, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t52 = load ptr, ptr %l39, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l39, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 5}
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = getelementptr { i64, [6 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t62, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  br label %bb20
bb19:
  br label %bb42
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclContext(ptr %t68, ptr %v0, ptr %s3, ptr %t66, i32 %t67)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t68, i64 160, i1 false)
  br label %bb21
bb21:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l47, i64 160, i1 false)
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t71, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb23, label %bb24
bb23:
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t85 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t85, ptr %l55, !tbaa !27
  %t86 = load i64, ptr %l10, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr ptr, ptr %t89, i64 %t86
  %t91 = load ptr, ptr %t90, !tbaa !39
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l58, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t100 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s3, ptr %v0, ptr %t94, ptr %l8, ptr %t91)
  store i32 %t100, ptr %l63
  br label %bb26
bb26:
  %t101 = load i32, ptr %l4, !tbaa !23
  %t103 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t101)
  store i64 %t103, ptr %l65
  br label %bb27
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l69
  br label %bb28
bb28:
  %t111 = load ptr, ptr %l58, !tbaa !29
  %t112 = load i32, ptr %l63, !tbaa !23
  %t113 = load i64, ptr %l65, !tbaa !24
  %t114 = load i32, ptr %l69, !tbaa !23
  %t115 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t111, i32 %t112, i64 %t113, i32 %t114)
  store i32 %t115, ptr %l70
  br label %bb29
bb29:
  %t116 = load i32, ptr %l70, !tbaa !23
  store i32 %t116, ptr %l13, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l13, !tbaa !23
  %t121 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t121, ptr %l73
  br label %bb30
bb30:
  %t122 = load i1, ptr %l73, !tbaa !21
  br i1 %t122, label %bb31, label %bb32
bb31:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l13, !tbaa !23
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t126 = load i64, ptr %l3, !tbaa !24
  %t128 = add i64 %t126, 1
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emembers(ptr %v0, ptr %v1, ptr %t123, i32 %t124, ptr %t125, i64 %t128)
  br label %bb33
bb32:
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t134 = load i32, ptr %l13, !tbaa !23
  %t137 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t133, i32 %t134)
  store i1 %t137, ptr %l81
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t138 = load i1, ptr %l81, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t142 = load i32, ptr %l13, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t141, i32 %t142)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l10, !tbaa !24
  br label %bb22
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_7c1b9fa6eff766ef_29392a9ca6e4fd4b)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enamedType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/names:Ref"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca i64
  %l21 = alloca %"compiler/names:Ref"
  %l30 = alloca i1
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca { i64, ptr }
  %l78 = alloca i64
  %l88 = alloca { i64, ptr }
  %l92 = alloca i64
  %l97 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l14, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Context", ptr %a1, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %t5, i64 %t9)
  store i64 %t12, ptr %l18
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Path", ptr %t13, i32 0, i32 0
  %t16 = getelementptr %"compiler/source:Span", ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t19 = load i64, ptr %l18, !tbaa !24
  %t21 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t18, i64 %t19, i32 %t17)
  store %"compiler/names:Ref" %t21, ptr %l21
  br label %bb2
bb2:
  %t22 = load %"compiler/names:Ref", ptr %l21
  store %"compiler/names:Ref" %t22, ptr %l3
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Path", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp eq i64 %t30, 1
  br i1 %t32, label %bb3, label %bb4
bb3:
  %t34 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 9}
  %t37 = trunc i64 4 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb5, label %bb6
bb4:
  br label %bb13
bb5:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb7
bb6:
  %t42 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb7
bb7:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  %t61 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t53, i64 %t55, i64 %t57)
  store i32 %t61, ptr %l39
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l35, !tbaa !29
  %t63 = load i32, ptr %l39, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t62, i32 %t63, i32 0)
  store i32 %t64, ptr %l40
  br label %bb12
bb12:
  %t65 = load i32, ptr %l40, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
bb13:
  %t66 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 9}
  %t69 = trunc i64 5 to i32
  %t70 = icmp eq i32 %t67, %t69
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t76 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = sub i64 %t79, 1
  store i64 %t81, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb17, label %bb18
bb17:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t109 = load i64, ptr %l54, !tbaa !24
  store i64 %t109, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t110 = load i64, ptr %l51, !tbaa !24
  store i64 %t110, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb24, label %bb25
bb24:
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i64, ptr %l5, !tbaa !24
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/ast:Path", ptr %t131, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l75, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i32, ptr %t138, i64 %t127
  %t140 = load i32, ptr %t139, !tbaa !33
  %t144 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ealiasStep(ptr %v0, ptr %t129, i64 %t130, i32 %t140)
  store i64 %t144, ptr %l78
  br label %bb27
bb27:
  %t145 = load i64, ptr %l78, !tbaa !24
  store i64 %t145, ptr %l5, !tbaa !24
  %t146 = load i64, ptr %l5, !tbaa !24
  %t148 = icmp slt i64 %t146, 0
  br i1 %t148, label %bb28, label %bb29
bb28:
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t150, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t152 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l10, !tbaa !24
  br label %bb23
bb32:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i64, ptr %l5, !tbaa !24
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Path", ptr %t159, i32 0, i32 1
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l88, !tbaa !27
  %t163 = load i64, ptr %l4, !tbaa !24
  %t165 = sub i64 %t163, 1
  %t167 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i32, ptr %t168, i64 %t165
  %t170 = load i32, ptr %t169, !tbaa !33
  %t174 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t157, i64 %t158, i32 %t170)
  store i64 %t174, ptr %l92
  br label %bb33
bb33:
  %t175 = load i64, ptr %l92, !tbaa !24
  store i64 %t175, ptr %l12, !tbaa !24
  %t176 = load i64, ptr %l12, !tbaa !24
  %t178 = icmp slt i64 %t176, 0
  br i1 %t178, label %bb34, label %bb35
bb34:
  %t180 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t180, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  store ptr %t184, ptr %l97, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i64, ptr %l5, !tbaa !24
  %t187 = load i64, ptr %l12, !tbaa !24
  %t191 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t185, i64 %t186, i64 %t187)
  store i32 %t191, ptr %l101
  br label %bb37
bb37:
  %t192 = load ptr, ptr %l97, !tbaa !29
  %t193 = load i32, ptr %l101, !tbaa !23
  %t194 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t192, i32 %t193, i32 0)
  store i32 %t194, ptr %l102
  br label %bb38
bb38:
  %t195 = load i32, ptr %l102, !tbaa !23
  store i32 %t195, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i32
  %l21 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l31 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca i64
  %l33 = alloca i32
  %l40 = alloca i1
  %l42 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Program", ptr %t3, i32 0, i32 2
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t12 = trunc i64 20 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l17
  br label %bb5
bb4:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l13, !tbaa !23
  br label %bb6
bb5:
  %t24 = load i32, ptr %l17, !tbaa !23
  store i32 %t24, ptr %l13, !tbaa !23
  br label %bb6
bb6:
  %t25 = load i32, ptr %l13, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %t26, i32 %t27)
  store i64 %t30, ptr %l21
  br label %bb7
bb7:
  %t31 = load i64, ptr %l21, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 38
  store ptr %t39, ptr %l27, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sext i32 %a2 to i64
  %t46 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t40, i64 %t43)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t46, ptr %l31
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  %t49 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t47, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t48)
  %t50 = extractvalue { i32, i64 } %t49, 1
  %t51 = extractvalue { i32, i64 } %t49, 0
  store i32 %t51, ptr %l33
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb13, label %ok.53, !prof !99
ok.53:
  store i64 %t50, ptr %l32
  br label %bb12
bb12:
  %t54 = load i64, ptr %l32, !tbaa !24
  store i64 %t54, ptr %l25, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb15
bb15:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp sge i64 %t56, 0
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb17, label %bb18
bb17:
  br label %bb29
bb18:
  br label %bb19
bb19:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i32, ptr %l3, !tbaa !23
  %t68 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvApplies(ptr %v0, ptr %t62, i64 %t63, i32 %t64)
  store i1 %t68, ptr %l40
  br label %bb20
bb20:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 39
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t73, i64 %t74)
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l47
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb25, label %ok.81, !prof !99
ok.81:
  store i64 %t78, ptr %l46
  br label %bb24
bb24:
  %t82 = load i64, ptr %l46, !tbaa !24
  store i64 %t82, ptr %l42, !tbaa !24
  br label %bb27
bb25:
  br label %bb26
bb26:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb27
bb27:
  %t83 = load i64, ptr %l42, !tbaa !24
  store i64 %t83, ptr %l5, !tbaa !24
  br label %bb28
bb28:
  br label %bb16
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eownerApplies(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerOf(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t14)
  store i64 %t16, ptr %l14
  br label %bb5
bb5:
  %t17 = load i64, ptr %l14, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l17
  br label %bb6
bb6:
  %t23 = load i64, ptr %l17, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp eq i64 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l25
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l29
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l21, !tbaa !29
  %t46 = load i32, ptr %l25, !tbaa !23
  %t47 = load i32, ptr %l29, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t45, i32 %t46, i32 %t47)
  store i1 %t48, ptr %l30
  br label %bb11
bb11:
  %t49 = load i1, ptr %l30, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l3, !tbaa !23
  %t52 = load i32, ptr %l2, !tbaa !23
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t60 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMatches(ptr %v0, ptr %t50, i32 %t51, i32 %t52, i64 %t53, i64 %t54, i1 true)
  store i1 %t60, ptr %l36
  br label %bb13
bb13:
  %t61 = load i1, ptr %l36, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamsSig(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l30 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i64
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %l47 = alloca i32
  %l54 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l65 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l14
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l6
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t19, ptr %l22, !tbaa !27
  %t20 = load i64, ptr %l8, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 %t20
  %t25 = load ptr, ptr %t24, !tbaa !39
  store ptr %l5, ptr %l25, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Param", ptr %t25, i32 0, i32 2
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t27, ptr %t28, ptr %t32)
  store i32 %t36, ptr %l30
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load i32, ptr %l30, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t37, i32 %t38)
  br label %bb8
bb8:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t39)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb3
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l37, !tbaa !29
  %t50 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  store i64 %t50, ptr %l38, !tbaa !24
  %t52 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t52, ptr %l40
  br label %bb12
bb12:
  %t53 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t54 = mul i64 1, 8
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 1, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l42, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 0
  store i64 %t53, ptr %t61, !tbaa !34
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load i64, ptr %l38, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t62, i64 %t63, { i64, ptr } %t64, { i64, ptr } %t65)
  store i32 %t66, ptr %l43
  br label %bb13
bb13:
  %t67 = load i32, ptr %l43, !tbaa !23
  store i32 %t67, ptr %l11, !tbaa !23
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Sig", ptr %t76, i32 0, i32 2
  %t79 = load i1, ptr %t78, !tbaa !21
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Sig", ptr %t80, i32 0, i32 3
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorList(ptr %v0, ptr %v1, ptr %v3, ptr %t74, ptr %t75, i1 %t79, { i64, ptr } %t83)
  store i32 %t88, ptr %l54
  br label %bb16
bb15:
  store i32 0, ptr %l47, !tbaa !23
  br label %bb17
bb16:
  %t89 = load i32, ptr %l54, !tbaa !23
  store i32 %t89, ptr %l47, !tbaa !23
  br label %bb17
bb17:
  %t90 = load i32, ptr %l47, !tbaa !23
  store i32 %t90, ptr %l12, !tbaa !23
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  store ptr %t93, ptr %l56, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  store ptr %t96, ptr %l58, !tbaa !29
  %t98 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t98, ptr %l60
  br label %bb18
bb18:
  %t99 = load ptr, ptr %l58, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t99, { i64, ptr } %t100)
  store i32 %t101, ptr %l61
  br label %bb19
bb19:
  %t103 = load i32, ptr %l12, !tbaa !23
  %t104 = load i32, ptr %l11, !tbaa !23
  %t105 = load ptr, ptr %l56, !tbaa !29
  %t106 = load i32, ptr %l61, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t105, i32 %t106, i32 %a4, i32 %t103, i32 %t104, i64 0, i1 false, i32 0, i64 0)
  store i32 %t110, ptr %l65
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i32, ptr %l65, !tbaa !23
  store i32 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epartsReady(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i32
  %l23 = alloca i1
  %l29 = alloca ptr
  %l33 = alloca i32
  %l39 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l14
  br label %bb3
bb3:
  %t12 = load i1, ptr %l14, !tbaa !21
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l18
  br label %bb8
bb8:
  %t21 = load i32, ptr %l18, !range !{i32 0, i32 33}
  store i32 %t21, ptr %l3
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t24 = trunc i64 18 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l23
  br label %bb12
bb12:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t35 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enamedPartsReady(ptr %v0, ptr %t33, i32 %t34, i64 %t35)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb41
bb17:
  %t39 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t41 = trunc i64 19 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l33
  br label %bb21
bb21:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = add i64 %t52, 1
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epartsReady(ptr %v0, ptr %t55, i32 %t56, i64 %t54)
  br label %bb22
bb22:
  br label %bb41
bb23:
  %t58 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t60 = trunc i64 23 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb36
bb26:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l39, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l43
  br label %bb27
bb27:
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t74 = load i32, ptr %l43, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l44
  br label %bb28
bb28:
  %t76 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t76, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb29
bb29:
  %t81 = load i64, ptr %l5, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l51, !tbaa !27
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = add i64 %t99, 1
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epartsReady(ptr %v0, ptr %t97, i32 %t95, i64 %t101)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l5, !tbaa !24
  br label %bb29
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_c5022c2221033445_fbaef66a28713951)
  unreachable
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFindDecl(ptr %v0, ptr %v1, ptr %v2, ptr %t1, { i64, ptr } %a1, { i64, ptr } %a2)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i32, ptr %l8, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
bb4:
  %t15 = load i32, ptr %l4, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t18, i32 %t15, i32 0)
  store i32 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i32, ptr %l14, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvExact(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %t1, i64 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp ne i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l9, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t7, i64 %a1)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l6, !tbaa !29
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t15, i32 %t16)
  store { i64, ptr } %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp eq i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 0
  %t34 = load i32, ptr %t33, !tbaa !33
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t29, i32 %t34)
  store i32 %t37, ptr %l20
  br label %bb7
bb7:
  %t38 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t40 = trunc i64 20 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 0
  %t50 = load i32, ptr %t49, !tbaa !33
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t45, i32 %t50)
  store i32 %t53, ptr %l28
  br label %bb10
bb9:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l29, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 0
  %t58 = load i32, ptr %t57, !tbaa !33
  store i32 %t58, ptr %l23, !tbaa !23
  br label %bb11
bb10:
  %t60 = load i32, ptr %l28, !tbaa !23
  store i32 %t60, ptr %l23, !tbaa !23
  br label %bb11
bb11:
  %t61 = load i32, ptr %l23, !tbaa !23
  store i32 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erefType(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i32
  %l21 = alloca i32
  %l26 = alloca i32
  %l30 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca i64
  %l39 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l3, !tbaa !23
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t10 = trunc i64 21 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i1, ptr %l4, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l17
  br label %bb6
bb5:
  %t22 = load i32, ptr %l3, !tbaa !23
  store i32 %t22, ptr %l13, !tbaa !23
  br label %bb7
bb6:
  %t24 = load i32, ptr %l17, !tbaa !23
  store i32 %t24, ptr %l13, !tbaa !23
  br label %bb7
bb7:
  %t25 = load i32, ptr %l13, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l21
  br label %bb9
bb9:
  %t31 = load i32, ptr %l21, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp ne i32 %t32, %t33
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load i1, ptr %l4, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l5, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l30
  br label %bb14
bb13:
  %t47 = load i32, ptr %l5, !tbaa !23
  store i32 %t47, ptr %l26, !tbaa !23
  br label %bb15
bb14:
  %t49 = load i32, ptr %l30, !tbaa !23
  store i32 %t49, ptr %l26, !tbaa !23
  br label %bb15
bb15:
  %t50 = load i32, ptr %l26, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  store ptr %t53, ptr %l33, !tbaa !29
  %t54 = load i32, ptr %l3, !tbaa !23
  store i32 %t54, ptr %l34, !tbaa !23
  %t55 = load i1, ptr %l4, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  store i64 %t57, ptr %l36, !tbaa !24
  br label %bb19
bb18:
  %t59 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t59, ptr %l36, !tbaa !24
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l33, !tbaa !29
  %t62 = load i32, ptr %l34, !tbaa !23
  %t63 = load i64, ptr %l36, !tbaa !24
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t61, i32 %t62, i64 %t63)
  store i32 %t64, ptr %l39
  br label %bb20
bb20:
  %t65 = load i32, ptr %l39, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereflHead(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Context", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l2, !tbaa !23
  %t7 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v1, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load i32, ptr %l10, !tbaa !23
  store i32 %t12, ptr %l6, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i32 -1, ptr %l6, !tbaa !23
  br label %bb4
bb4:
  %t13 = load i32, ptr %l6, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t16 = icmp sge i32 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l3, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l17
  br label %bb7
bb6:
  br label %bb21
bb7:
  %t25 = load i32, ptr %l17, !range !{i32 0, i32 33}
  store i32 %t25, ptr %l4
  %t26 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t28 = trunc i64 26 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t31 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t33 = trunc i64 27 to i32
  %t34 = icmp eq i32 %t31, %t33
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t37 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t39 = trunc i64 30 to i32
  %t40 = icmp eq i32 %t37, %t39
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb17
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t47 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t47, ptr %l29
  br label %bb16
bb16:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  store i32 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t51 = load i32, ptr %l3, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Context", ptr %t53, i32 0, i32 3
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v1, ptr %t55, i32 %t56)
  %t60 = extractvalue { i32, i32 } %t59, 1
  %t61 = extractvalue { i32, i32 } %t59, 0
  store i32 %t61, ptr %l37
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb23, label %ok.63, !prof !99
ok.63:
  store i32 %t60, ptr %l36
  br label %bb22
bb22:
  %t64 = load i32, ptr %l36, !tbaa !23
  store i32 %t64, ptr %l32, !tbaa !23
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i32 -1, ptr %l32, !tbaa !23
  br label %bb25
bb25:
  %t65 = load i32, ptr %l32, !tbaa !23
  store i32 %t65, ptr %l5, !tbaa !23
  %t66 = load i32, ptr %l5, !tbaa !23
  %t68 = icmp sge i32 %t66, 0
  br i1 %t68, label %bb26, label %bb27
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l5, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l44
  br label %bb28
bb27:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb29
bb28:
  %t77 = load i32, ptr %l44, !range !{i32 0, i32 33}
  %t79 = trunc i64 26 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t84 = load i1, ptr %l40, !tbaa !21
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t85 = load i32, ptr %l5, !tbaa !23
  store i32 %t85, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eroundTrip(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eParseCanon(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  %t6 = extractvalue { i32, i32 } %t5, 1
  %t7 = extractvalue { i32, i32 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t18 = inttoptr i64 0 to ptr
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t18, ptr %t15, i32 %t12)
  store { i64, ptr } %t21, ptr %l13
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t22, { i64, ptr } %t23)
  store i1 %t26, ptr %l16
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esameUpToShape(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i32
  %l11 = alloca i1
  %l16 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i32
  %l41 = alloca i32
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Program", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t3, i32 %t4, i32 %t5)
  store i1 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i1, ptr %l11, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l16
  br label %bb5
bb5:
  %t19 = load i32, ptr %l16, !range !{i32 0, i32 33}
  %t21 = trunc i64 20 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l3, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l22
  br label %bb6
bb6:
  %t31 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t33 = trunc i64 20 to i32
  %t34 = icmp eq i32 %t31, %t33
  store i1 %t34, ptr %l4, !tbaa !21
  %t36 = load i1, ptr %l3, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load i1, ptr %l4, !tbaa !21
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l26, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load i1, ptr %l3, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l34
  br label %bb15
bb14:
  %t51 = load i32, ptr %l1, !tbaa !23
  store i32 %t51, ptr %l30, !tbaa !23
  br label %bb16
bb15:
  %t53 = load i32, ptr %l34, !tbaa !23
  store i32 %t53, ptr %l30, !tbaa !23
  br label %bb16
bb16:
  %t54 = load i32, ptr %l30, !tbaa !23
  store i32 %t54, ptr %l5, !tbaa !23
  %t55 = load i1, ptr %l4, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l41
  br label %bb19
bb18:
  %t64 = load i32, ptr %l2, !tbaa !23
  store i32 %t64, ptr %l37, !tbaa !23
  br label %bb20
bb19:
  %t66 = load i32, ptr %l41, !tbaa !23
  store i32 %t66, ptr %l37, !tbaa !23
  br label %bb20
bb20:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l5, !tbaa !23
  %t76 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t70, i32 %t71, i32 %t67)
  store i1 %t76, ptr %l47
  br label %bb21
bb21:
  %t77 = load i1, ptr %l47, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eshape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [6 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { { i64, ptr }, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17, { i64, ptr } %t18)
  store i32 %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load i32, ptr %l15, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  br label %bb20
bb7:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 5}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { ptr }, ptr %t35, i32 0, i32 0
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = getelementptr %"compiler/ast:StructBody", ptr %t44, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamTypes(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43, { i64, ptr } %t47)
  store i32 %t51, ptr %l28
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l23, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load i32, ptr %l29, !tbaa !23
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t56, ptr %l5, !tbaa !23
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a096310d429842c5_b38f3d186616d6e9)
  unreachable
bb20:
  %t58 = load i32, ptr %l5, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esubstList(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l57 = alloca i32
  %l64 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l18
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = icmp sle i64 %t21, 2305843009213693951
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4439a413e01d0c26_16c6d6890310944a)
  unreachable
bb7:
  %t24 = load i64, ptr %l20, !tbaa !24
  %t25 = mul i64 %t24, 4
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4439a413e01d0c26_16c6d6890310944a)
  unreachable
bb9:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb14
bb11:
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l32, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb13
bb13:
  %t60 = load i64, ptr %l32, !tbaa !24
  store i64 %t60, ptr %l29, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l29, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t70 = load i64, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l11, !tbaa !24
  store i64 %t80, ptr %l50, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t82, ptr %l52, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t95 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t81, i32 %t88, i64 %a2, i32 %a3)
  store i32 %t95, ptr %l57
  br label %bb19
bb19:
  %t96 = load i32, ptr %l57, !tbaa !23
  %t97 = load i64, ptr %l50, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 %t97
  store i32 %t96, ptr %t100, !tbaa !33
  br label %bb20
bb20:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t108, { i64, ptr } %t109)
  store i32 %t112, ptr %l64
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load i32, ptr %l64, !tbaa !23
  store i32 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etraitReaches(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i1
  %l42 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i1
  %l63 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr { i64, [6 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t15, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [6 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t21, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [6 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t27, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28
  %t33 = extractvalue { i64, ptr } %t29, 0
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l27, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  store i32 %t38, ptr %l28, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l31
  br label %bb8
bb7:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = load i32, ptr %l28, !tbaa !23
  %t46 = load i32, ptr %l31, !tbaa !23
  %t47 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %t44, i32 %t45, i32 %t46)
  store i1 %t47, ptr %l32
  br label %bb9
bb9:
  %t48 = load i1, ptr %l32, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t53, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb33
bb16:
  br label %bb17
bb17:
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t67, ptr %l42, !tbaa !27
  %t68 = load i64, ptr %l8, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr ptr, ptr %t71, i64 %t68
  %t73 = load ptr, ptr %t72, !tbaa !39
  store ptr %t73, ptr %l10, !tbaa !29
  %t75 = load ptr, ptr %l10, !tbaa !29
  %t77 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v1, ptr %t75)
  store i1 %t77, ptr %l46
  br label %bb18
bb18:
  %t78 = load i1, ptr %l46, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l47, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  store i32 %t80, ptr %l48, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  store ptr %t83, ptr %l50, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l1, !tbaa !23
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l53
  br label %bb21
bb20:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l3, !tbaa !23
  %t91 = load ptr, ptr %l10, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t98 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t89, i32 %t90, i32 %t94)
  store i64 %t98, ptr %l63
  br label %bb27
bb21:
  %t99 = load ptr, ptr %l50, !tbaa !29
  %t100 = load i32, ptr %l53, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t99, i32 %t100)
  store i32 %t101, ptr %l54
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l10, !tbaa !29
  %t103 = load ptr, ptr %l47, !tbaa !29
  %t104 = load i32, ptr %l48, !tbaa !23
  %t105 = load i32, ptr %l54, !tbaa !23
  %t107 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetsBuilder(ptr %v0, ptr %v1, ptr %t103, i32 %t104, i32 %t105, ptr %t102)
  store i1 %t107, ptr %l56
  br label %bb23
bb23:
  %t108 = load i1, ptr %l56, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb24, label %bb25
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb31
bb27:
  %t112 = load i64, ptr %l63, !tbaa !24
  %t113 = icmp slt i64 %t112, 0
  br i1 %t113, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l8, !tbaa !24
  br label %bb14
bb33:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunaryType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i1
  %l15 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t3 = trunc i64 69 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t8 = trunc i64 105 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t12, ptr %a1, ptr %a2, ptr %a4)
  store i32 %t21, ptr %l15
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
bb7:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t25 = trunc i64 107 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etextType(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l19
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
bb11:
  %t32 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t34 = trunc i64 48 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca i32
  %l29 = alloca i32
  %l33 = alloca i1
  %l37 = alloca i32
  %l39 = alloca i1
  %l41 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i32
  %l51 = alloca i32
  %l52 = alloca ptr
  %l56 = alloca i32
  %l61 = alloca i32
  %l66 = alloca ptr
  %l68 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l77 = alloca i32
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca { i64, ptr }
  %l91 = alloca i32
  %l99 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a1)
  store i32 %t13, ptr %l13
  br label %bb4
bb4:
  %t14 = load i32, ptr %l13, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l5, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l17
  br label %bb5
bb5:
  %t22 = load i32, ptr %l17, !range !{i32 0, i32 33}
  store i32 %t22, ptr %l6
  %t23 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t25 = trunc i64 20 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l25
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = load i32, ptr %l25, !tbaa !23
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %t40, i32 %t41, ptr %t36, i64 %t39, i1 true)
  store i32 %t44, ptr %l29
  br label %bb10
bb10:
  %t45 = load i32, ptr %l29, !tbaa !23
  store i32 %t45, ptr %l18, !tbaa !23
  br label %bb56
bb11:
  %t46 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t48 = trunc i64 19 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb30
bb14:
  %t51 = load i1, ptr %l4, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l5, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l37
  br label %bb17
bb16:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb18
bb17:
  %t60 = load i32, ptr %l37, !tbaa !23
  %t61 = icmp eq i32 %t60, 0
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l41, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l45
  br label %bb21
bb20:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb23
bb21:
  %t74 = load ptr, ptr %l41, !tbaa !29
  %t75 = load i32, ptr %l45, !tbaa !23
  %t76 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t76, ptr %l46
  br label %bb22
bb22:
  %t77 = load i1, ptr %l46, !tbaa !21
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l5, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l51
  br label %bb26
bb25:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l52, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l5, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l56
  br label %bb27
bb26:
  %t94 = load i32, ptr %l51, !tbaa !23
  store i32 %t94, ptr %l47, !tbaa !23
  br label %bb29
bb27:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = add i64 %t96, 1
  %t99 = load i1, ptr %l4, !tbaa !21
  %t100 = load ptr, ptr %l52, !tbaa !29
  %t101 = load i32, ptr %l56, !tbaa !23
  %t105 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunended(ptr %v0, ptr %v1, ptr %t100, i32 %t101, ptr %t95, i64 %t98, i1 %t99)
  store i32 %t105, ptr %l61
  br label %bb28
bb28:
  %t106 = load i32, ptr %l61, !tbaa !23
  store i32 %t106, ptr %l47, !tbaa !23
  br label %bb29
bb29:
  %t107 = load i32, ptr %l47, !tbaa !23
  store i32 %t107, ptr %l18, !tbaa !23
  br label %bb56
bb30:
  %t108 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t110 = trunc i64 23 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  %t113 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t115 = trunc i64 22 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l66, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  store ptr %t121, ptr %l68, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l5, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l72
  br label %bb36
bb36:
  %t129 = load ptr, ptr %l68, !tbaa !29
  %t130 = load i32, ptr %l72, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t129, i32 %t130)
  store { i64, ptr } %t131, ptr %l73
  br label %bb37
bb37:
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t133 = load i64, ptr %l3, !tbaa !24
  %t134 = load i1, ptr %l4, !tbaa !21
  %t135 = load ptr, ptr %l66, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t140 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedIn(ptr %v0, ptr %v0, ptr %v1, ptr %t135, { i64, ptr } %t136, ptr %t132, i64 %t133, i1 %t134)
  store i32 %t140, ptr %l77
  br label %bb38
bb38:
  %t141 = load i32, ptr %l77, !tbaa !23
  store i32 %t141, ptr %l18, !tbaa !23
  br label %bb56
bb39:
  %t142 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t144 = trunc i64 24 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l80, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  store ptr %t150, ptr %l82, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i32, ptr %l5, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t153, i32 %t154)
  store i32 %t157, ptr %l86
  br label %bb43
bb43:
  %t158 = load ptr, ptr %l82, !tbaa !29
  %t159 = load i32, ptr %l86, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t158, i32 %t159)
  store { i64, ptr } %t160, ptr %l87
  br label %bb44
bb44:
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t162 = load i64, ptr %l3, !tbaa !24
  %t163 = load i1, ptr %l4, !tbaa !21
  %t164 = load ptr, ptr %l80, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedIn(ptr %v0, ptr %v0, ptr %v1, ptr %t164, { i64, ptr } %t165, ptr %t161, i64 %t162, i1 %t163)
  store i32 %t169, ptr %l91
  br label %bb45
bb45:
  %t170 = load i32, ptr %l91, !tbaa !23
  store i32 %t170, ptr %l18, !tbaa !23
  br label %bb56
bb46:
  %t171 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t173 = trunc i64 18 to i32
  %t174 = icmp eq i32 %t171, %t173
  br i1 %t174, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l5, !tbaa !23
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t179 = load i64, ptr %l3, !tbaa !24
  %t180 = load i1, ptr %l4, !tbaa !21
  %t186 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedNamed(ptr %v0, ptr %v1, ptr %t176, i32 %t177, ptr %t178, i64 %t179, i1 %t180)
  store i32 %t186, ptr %l99
  br label %bb50
bb50:
  %t187 = load i32, ptr %l99, !tbaa !23
  store i32 %t187, ptr %l18, !tbaa !23
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t188 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t188, ptr %l18, !tbaa !23
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_e6b22f697499a1dd_b3ee10b0849b47b1)
  unreachable
bb56:
  %t190 = load i32, ptr %l18, !tbaa !23
  store i32 %t190, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunknowns(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t16 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/generic:Program", ptr %a0, i32 0, i32 2
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l4, !tbaa !24
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b7daf7406ba778a4_42e2bd1e0b6e1610)
  unreachable
bb3:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  %t15 = load i32, ptr %l5, !tbaa !23
  store i64 0, ptr %t16
  br label %fill.17
fill.17:
  %t20 = load i64, ptr %t16
  %t21 = icmp slt i64 %t20, %t12
  br i1 %t21, label %fillb.18, label %filld.19
fillb.18:
  %t22 = getelementptr i32, ptr %t14, i64 %t20
  store i32 %t15, ptr %t22
  %t23 = add i64 %t20, 1
  store i64 %t23, ptr %t16
  br label %fill.17
filld.19:
  %t24 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t14, 1
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t26, { i64, ptr } %t25)
  store i32 %t28, ptr %l9
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b7daf7406ba778a4_42e2bd1e0b6e1610)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l9, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewide(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l10
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load i32, ptr %l10, !tbaa !23
  %t17 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t15, i32 %t16)
  store i64 %t17, ptr %l11
  br label %bb4
bb4:
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp sgt i64 %t18, 64
  store i1 %t19, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l5, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2epeek(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i8
  %l9 = alloca { i64, ptr }
  %rv = alloca i8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:cursor", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/generic:cursor", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp slt i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/generic:cursor", ptr %t15, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l9, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/generic:cursor", ptr %t19, i32 0, i32 1
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 %t22
  %t27 = load i8, ptr %t26, !tbaa !32
  store i8 %t27, ptr %l7, !tbaa !22
  br label %bb3
bb2:
  store i8 0, ptr %l7, !tbaa !22
  br label %bb3
bb3:
  %t29 = load i8, ptr %l7, !tbaa !22
  store i8 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebinds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l50 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 9}
  %t23 = icmp eq i64 %t21, 7
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 9}
  %t38 = icmp eq i64 %t36, 5
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t42, i32 0, i32 2
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t48 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t46, i32 %t47, i64 %t48)
  br label %bb14
bb14:
  br label %bb44
bb15:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t53 = load ptr, ptr %l31, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 9}
  %t59 = icmp eq i64 %t57, 2
  store i1 %t59, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l32, !tbaa !21
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t63, i32 0, i32 2
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l4, !tbaa !27
  br label %bb24
bb19:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb20, label %bb21
bb20:
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 9}
  %t74 = icmp eq i64 %t72, 6
  store i1 %t74, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t75 = load i1, ptr %l38, !tbaa !21
  br i1 %t75, label %bb22, label %bb23
bb22:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t78, i32 0, i32 2
  %t80 = load { i64, ptr }, ptr %t79
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t96 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t96, ptr %l50, !tbaa !27
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebinds(ptr %v0, ptr %v1, ptr %t104, ptr %t102, i64 %t106)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb25
bb31:
  br label %bb44
bb32:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t116 = load ptr, ptr %l59, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb33, label %bb34
bb33:
  %t119 = load ptr, ptr %l59, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 9}
  %t122 = icmp eq i64 %t120, 8
  store i1 %t122, ptr %l60, !tbaa !21
  br label %bb34
bb34:
  %t123 = load i1, ptr %l60, !tbaa !21
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l9, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l9, !tbaa !29
  %t132 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebinds(ptr %v0, ptr %v1, ptr %t130, ptr %t131, i64 %t132)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_961f770be6209277_34282562e2239643)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebranches(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l8 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:If", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l8, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:If", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb6, label %bb7
bb5:
  br label %bb10
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9e9a19de368b1652_6a1b6384f5ca11a6)
  unreachable
bb7:
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:If", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t30, { i64, ptr } %t29)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/ast:If", ptr %t33, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t32, ptr %t36)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ecallRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i64
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_5dbf3bacf45043d5_48a0238198051071)
  unreachable
bb12:
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2edeclared(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l34 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca { i64, ptr }
  %l46 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:VarDecl", ptr %t28, i32 0, i32 3
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:VarDecl", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp eq i64 %t33, %t39
  br i1 %t42, label %bb5, label %bb6
bb5:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l6, !tbaa !23
  store i32 %t45, ptr %l27, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 3
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l30, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  %t60 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t46, ptr %t56)
  store i64 %t60, ptr %l34
  br label %bb7
bb6:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:VarDecl", ptr %t61, i32 0, i32 3
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp eq i64 %t66, 1
  br i1 %t68, label %bb9, label %bb10
bb7:
  %t70 = load ptr, ptr %l26, !tbaa !29
  %t71 = load i32, ptr %l27, !tbaa !23
  %t72 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t70, i32 %t71, i64 %t72)
  br label %bb8
bb8:
  br label %bb15
bb9:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l39, !tbaa !29
  %t74 = load i32, ptr %l6, !tbaa !23
  store i32 %t74, ptr %l40, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/ast:VarDecl", ptr %t76, i32 0, i32 3
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l43, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 0
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t75, ptr %t83)
  store i64 %t87, ptr %l46
  br label %bb11
bb10:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l6, !tbaa !23
  %t90 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t88, i32 %t89, i64 %t90)
  br label %bb13
bb11:
  %t94 = load ptr, ptr %l39, !tbaa !29
  %t95 = load i32, ptr %l40, !tbaa !23
  %t96 = load i64, ptr %l46, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t94, i32 %t95, i64 %t96)
  br label %bb12
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t97 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t97, 1
  store i64 %t100, ptr %l3, !tbaa !24
  br label %bb1
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2einner(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l77 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l112 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t17 = load ptr, ptr %l22, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 22}
  %t23 = icmp eq i64 %t21, 20
  store i1 %t23, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l23, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t27, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l28, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 22}
  %t38 = icmp eq i64 %t36, 7
  store i1 %t38, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l29, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43
  store { i64, ptr } %t44, ptr %l2, !tbaa !27
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t47 = load ptr, ptr %l34, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 22}
  %t53 = icmp eq i64 %t51, 10
  store i1 %t53, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l35, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load { i64, ptr }, ptr %t58
  store { i64, ptr } %t59, ptr %l2, !tbaa !27
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t61, { i64, ptr } %t62)
  br label %bb18
bb18:
  br label %bb68
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t66 = load ptr, ptr %l42, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l42, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 22}
  %t72 = icmp eq i64 %t70, 8
  store i1 %t72, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l43, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/ast:For3", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  br label %bb25
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/ast:For3", ptr %t89, i32 0, i32 2
  %t92 = load ptr, ptr %t91, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  br label %bb26
bb26:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t99 = getelementptr %"compiler/ast:For3", ptr %t97, i32 0, i32 3
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t96, { i64, ptr } %t100)
  br label %bb27
bb27:
  br label %bb68
bb28:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t104 = load ptr, ptr %l59, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l59, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 22}
  %t110 = icmp eq i64 %t108, 4
  store i1 %t110, ptr %l60, !tbaa !21
  br label %bb30
bb30:
  %t111 = load i1, ptr %l60, !tbaa !21
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l4, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t120, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l5, !tbaa !27
  br label %bb33
bb32:
  br label %bb42
bb33:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb34
bb34:
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t129, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l8, !tbaa !24
  br label %bb35
bb35:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t143 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t143, ptr %l77, !tbaa !27
  %t144 = load i64, ptr %l7, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr ptr, ptr %t147, i64 %t144
  %t149 = load ptr, ptr %t148, !tbaa !39
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/ast:Catch", ptr %t149, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t151, { i64, ptr } %t155)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t158 = load i64, ptr %l7, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l7, !tbaa !24
  br label %bb35
bb41:
  br label %bb68
bb42:
  %t163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t163, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t164 = load ptr, ptr %l86, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb43, label %bb44
bb43:
  %t167 = load ptr, ptr %l86, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 22}
  %t170 = icmp eq i64 %t168, 19
  store i1 %t170, ptr %l87, !tbaa !21
  br label %bb44
bb44:
  %t171 = load i1, ptr %l87, !tbaa !21
  br i1 %t171, label %bb45, label %bb46
bb45:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [4 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t174, i32 0, i32 1
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %t178, ptr %t179)
  br label %bb48
bb48:
  br label %bb68
bb49:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t184 = load ptr, ptr %l95, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb50, label %bb51
bb50:
  %t187 = load ptr, ptr %l95, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 22}
  %t190 = icmp eq i64 %t188, 18
  store i1 %t190, ptr %l96, !tbaa !21
  br label %bb51
bb51:
  %t191 = load i1, ptr %l96, !tbaa !21
  br i1 %t191, label %bb52, label %bb53
bb52:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l11, !tbaa !29
  br label %bb54
bb53:
  br label %bb63
bb54:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l11, !tbaa !29
  %t201 = getelementptr %"compiler/ast:JoinS", ptr %t199, i32 0, i32 1
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t198, { i64, ptr } %t202)
  br label %bb55
bb55:
  %t205 = load ptr, ptr %l11, !tbaa !29
  %t207 = getelementptr %"compiler/ast:JoinS", ptr %t205, i32 0, i32 2
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t210 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l14, !tbaa !24
  br label %bb56
bb56:
  %t214 = load i64, ptr %l13, !tbaa !24
  %t215 = load i64, ptr %l14, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t222 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t222, ptr %l112, !tbaa !27
  %t223 = load i64, ptr %l13, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr ptr, ptr %t226, i64 %t223
  %t228 = load ptr, ptr %t227, !tbaa !39
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Catch", ptr %t228, i32 0, i32 2
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t230, { i64, ptr } %t234)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t237 = load i64, ptr %l13, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l13, !tbaa !24
  br label %bb56
bb62:
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_c61310131704fb2f_f27aa7cba89c0bc3)
  unreachable
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ematched(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l24 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t9, ptr %l15
  br label %bb1
bb1:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Match", ptr %t11, i32 0, i32 3
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t28, ptr %l24, !tbaa !27
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 %t29
  %t34 = load ptr, ptr %t33, !tbaa !39
  store ptr %t34, ptr %l6, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Case", ptr %t36, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t53, ptr %l35, !tbaa !27
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr ptr, ptr %t57, i64 %t54
  %t59 = load ptr, ptr %t58, !tbaa !39
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebinds(ptr %v0, ptr %v1, ptr %t61, ptr %t59, i64 %t63)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l8, !tbaa !24
  br label %bb6
bb12:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l6, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Case", ptr %t73, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t72, { i64, ptr } %t76)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l4, !tbaa !24
  br label %bb2
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eparamBit(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l40 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l52 = alloca i64
  %l54 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/generic:genRoots", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l14, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = sub i64 %t36, 1
  store i64 %t37, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t38, 2147483648
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  %t44 = and i1 %t39, %t41
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb8, label %bb9
bb8:
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l7, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/generic:genRoots", ptr %t63, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l40, !tbaa !27
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i32, ptr %t70, i64 %t67
  %t72 = load i32, ptr %t71, !tbaa !33
  %t76 = icmp ne i32 %t72, %a1
  br i1 %t76, label %bb11, label %bb12
bb11:
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/generic:genRoots", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l46, !tbaa !27
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i1, ptr %t85, i64 %t82
  %t87 = load i1, ptr %t86, !tbaa !31
  br i1 %t87, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb16
bb15:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = icmp sge i64 %t89, 62
  store i1 %t91, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t93 = load i1, ptr %l49, !tbaa !21
  br i1 %t93, label %bb17, label %bb18
bb17:
  %t94 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenLocalBit, !tbaa !24
  store i64 %t94, ptr %l52, !tbaa !24
  br label %bb19
bb18:
  %t96 = load i64, ptr %l7, !tbaa !24
  store i64 %t96, ptr %l54, !tbaa !24
  %t97 = load i64, ptr %l54, !tbaa !24
  %t98 = load i64, ptr %l54, !tbaa !24
  %t99 = shl i64 1, %t98
  store i64 %t99, ptr %l52, !tbaa !24
  br label %bb19
bb19:
  %t101 = load i64, ptr %l52, !tbaa !24
  store i64 %t101, ptr %rv
  br label %ret
bb20:
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t102, 1
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb7
bb21:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i1
  %l88 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca i1
  %l100 = alloca i64
  %l104 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca i64
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 28}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2enameRoot(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l22
  br label %bb9
bb9:
  %t26 = load i64, ptr %l22, !tbaa !24
  store i64 %t26, ptr %l13, !tbaa !24
  br label %bb82
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t28 = load ptr, ptr %l23, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 28}
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr }, ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb27
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t43 = load ptr, ptr %l29, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 28}
  %t49 = icmp eq i64 %t47, 24
  store i1 %t49, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l30, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l3, !tbaa !29
  br label %bb27
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l35, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 28}
  %t64 = icmp eq i64 %t62, 26
  store i1 %t64, ptr %l36, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l36, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", ptr }, ptr %t68, i32 0, i32 1
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l3, !tbaa !29
  br label %bb27
bb22:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t73 = load ptr, ptr %l41, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb23, label %bb24
bb23:
  %t76 = load ptr, ptr %l41, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 28}
  %t79 = icmp eq i64 %t77, 4
  store i1 %t79, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t80 = load i1, ptr %l42, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t92 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store i64 %t92, ptr %l50
  br label %bb28
bb28:
  %t93 = load i64, ptr %l50, !tbaa !24
  store i64 %t93, ptr %l13, !tbaa !24
  br label %bb82
bb29:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t95 = load ptr, ptr %l51, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l51, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 28}
  %t101 = icmp eq i64 %t99, 12
  store i1 %t101, ptr %l52, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l52, !tbaa !21
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l4, !tbaa !29
  br label %bb46
bb33:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t110 = load ptr, ptr %l57, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb34, label %bb35
bb34:
  %t113 = load ptr, ptr %l57, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 28}
  %t116 = icmp eq i64 %t114, 13
  store i1 %t116, ptr %l58, !tbaa !21
  br label %bb35
bb35:
  %t117 = load i1, ptr %l58, !tbaa !21
  br i1 %t117, label %bb36, label %bb37
bb36:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t120, i32 0, i32 1
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l4, !tbaa !29
  br label %bb46
bb37:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t125 = load ptr, ptr %l63, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb38, label %bb39
bb38:
  %t128 = load ptr, ptr %l63, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 28}
  %t131 = icmp eq i64 %t129, 14
  store i1 %t131, ptr %l64, !tbaa !21
  br label %bb39
bb39:
  %t132 = load i1, ptr %l64, !tbaa !21
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t135, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l4, !tbaa !29
  br label %bb46
bb41:
  %t139 = load ptr, ptr %l1, !tbaa !29
  store ptr %t139, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t140 = load ptr, ptr %l69, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb42, label %bb43
bb42:
  %t143 = load ptr, ptr %l69, !tbaa !29
  %t144 = load i64, ptr %t143, !range !{i64 0, i64 28}
  %t146 = icmp eq i64 %t144, 9
  store i1 %t146, ptr %l70, !tbaa !21
  br label %bb43
bb43:
  %t147 = load i1, ptr %l70, !tbaa !21
  br i1 %t147, label %bb44, label %bb45
bb44:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t150, i32 0, i32 1
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l4, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t159 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t154, ptr %t155)
  store i64 %t159, ptr %l78
  br label %bb47
bb47:
  %t160 = load i64, ptr %l78, !tbaa !24
  store i64 %t160, ptr %l13, !tbaa !24
  br label %bb82
bb48:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t162 = load ptr, ptr %l79, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb49, label %bb50
bb49:
  %t165 = load ptr, ptr %l79, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 28}
  %t168 = icmp eq i64 %t166, 19
  store i1 %t168, ptr %l80, !tbaa !21
  br label %bb50
bb50:
  %t169 = load i1, ptr %l80, !tbaa !21
  br i1 %t169, label %bb51, label %bb52
bb51:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t172, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l5, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l5, !tbaa !29
  %t181 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  store i64 %t181, ptr %l88
  br label %bb54
bb54:
  %t182 = load i64, ptr %l88, !tbaa !24
  store i64 %t182, ptr %l13, !tbaa !24
  br label %bb82
bb55:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t184 = load ptr, ptr %l89, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb56, label %bb57
bb56:
  %t187 = load ptr, ptr %l89, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 28}
  %t190 = icmp eq i64 %t188, 8
  store i1 %t190, ptr %l90, !tbaa !21
  br label %bb57
bb57:
  %t191 = load i1, ptr %l90, !tbaa !21
  br i1 %t191, label %bb58, label %bb59
bb58:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l6, !tbaa !29
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t200, i32 0, i32 3
  %t202 = load ptr, ptr %t201
  store ptr %t202, ptr %l7, !tbaa !29
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l6, !tbaa !29
  %t209 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t204, ptr %t205)
  store i64 %t209, ptr %l100
  br label %bb61
bb61:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load ptr, ptr %l7, !tbaa !29
  %t215 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t210, ptr %t211)
  store i64 %t215, ptr %l104
  br label %bb62
bb62:
  %t216 = load i64, ptr %l100, !tbaa !24
  %t217 = load i64, ptr %l104, !tbaa !24
  %t218 = or i64 %t216, %t217
  store i64 %t218, ptr %l13, !tbaa !24
  br label %bb82
bb63:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t221 = load ptr, ptr %l106, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb64, label %bb65
bb64:
  %t224 = load ptr, ptr %l106, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 28}
  %t227 = icmp eq i64 %t225, 10
  store i1 %t227, ptr %l107, !tbaa !21
  br label %bb65
bb65:
  %t228 = load i1, ptr %l107, !tbaa !21
  br i1 %t228, label %bb66, label %bb67
bb66:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t231, i32 0, i32 1
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l8, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l8, !tbaa !29
  %t239 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ecallRoot(ptr %v0, ptr %v1, ptr %t235, ptr %t236)
  store i64 %t239, ptr %l114
  br label %bb69
bb69:
  %t240 = load i64, ptr %l114, !tbaa !24
  store i64 %t240, ptr %l13, !tbaa !24
  br label %bb82
bb70:
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t242 = load ptr, ptr %l115, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb71, label %bb72
bb71:
  %t245 = load ptr, ptr %l115, !tbaa !29
  %t246 = load i64, ptr %t245, !range !{i64 0, i64 28}
  %t248 = icmp eq i64 %t246, 21
  store i1 %t248, ptr %l116, !tbaa !21
  br label %bb72
bb72:
  %t249 = load i1, ptr %l116, !tbaa !21
  br i1 %t249, label %bb73, label %bb74
bb73:
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", ptr }, ptr %t252, i32 0, i32 1
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l9, !tbaa !29
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load ptr, ptr %l9, !tbaa !29
  %t260 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ecaseRoots(ptr %v0, ptr %v1, ptr %t256, ptr %t257)
  store i64 %t260, ptr %l123
  br label %bb76
bb76:
  %t261 = load i64, ptr %l123, !tbaa !24
  store i64 %t261, ptr %l13, !tbaa !24
  br label %bb82
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_3ab543dc145c7b05_675409dfde5f91a1)
  unreachable
bb82:
  %t262 = load i64, ptr %l13, !tbaa !24
  store i64 %t262, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l49 = alloca { i64, ptr }
  %l52 = alloca i64
  %l56 = alloca i64
  %l69 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l74 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i1
  %l87 = alloca ptr
  %l89 = alloca i32
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i64
  %l113 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca i1
  %l127 = alloca i64
  %l143 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t6 = load ptr, ptr %l27, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l27, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l28, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2edeclared(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb91
bb10:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t25 = load ptr, ptr %l35, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l35, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 22}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l36, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l36, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", ptr }, ptr %t35, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb31
bb15:
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Multi", ptr %t39, i32 0, i32 2
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t56, ptr %l49, !tbaa !27
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l52, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t65, ptr %t62)
  store i64 %t70, ptr %l56
  br label %bb20
bb20:
  %t71 = load i64, ptr %l52, !tbaa !24
  %t72 = load i64, ptr %l56, !tbaa !24
  %t73 = or i64 %t71, %t72
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l6, !tbaa !24
  br label %bb16
bb22:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Multi", ptr %t80, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l11, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t97 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t97, ptr %l69, !tbaa !27
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr ptr, ptr %t101, i64 %t98
  %t103 = load ptr, ptr %t102, !tbaa !39
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l72, !tbaa !29
  %t108 = call i32 @compiler_2fgeneric_2ebaseName(ptr %v1, ptr %t103)
  store i32 %t108, ptr %l74
  br label %bb27
bb27:
  %t109 = load i64, ptr %l4, !tbaa !24
  %t110 = load ptr, ptr %l72, !tbaa !29
  %t111 = load i32, ptr %l74, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t110, i32 %t111, i64 %t109)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %l10, !tbaa !24
  br label %bb23
bb30:
  br label %bb91
bb31:
  %t118 = load ptr, ptr %l1, !tbaa !29
  store ptr %t118, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t119 = load ptr, ptr %l79, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb32, label %bb33
bb32:
  %t122 = load ptr, ptr %l79, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 22}
  %t125 = icmp eq i64 %t123, 3
  store i1 %t125, ptr %l80, !tbaa !21
  br label %bb33
bb33:
  %t126 = load i1, ptr %l80, !tbaa !21
  br i1 %t126, label %bb34, label %bb35
bb34:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l13, !tbaa !29
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t135, i32 0, i32 3
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l14, !tbaa !29
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l87, !tbaa !29
  %t140 = load ptr, ptr %l13, !tbaa !29
  %t142 = call i32 @compiler_2fgeneric_2ebaseName(ptr %v1, ptr %t140)
  store i32 %t142, ptr %l89
  br label %bb37
bb37:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l14, !tbaa !29
  %t148 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t143, ptr %t144)
  store i64 %t148, ptr %l93
  br label %bb38
bb38:
  %t149 = load ptr, ptr %l87, !tbaa !29
  %t150 = load i32, ptr %l89, !tbaa !23
  %t151 = load i64, ptr %l93, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t149, i32 %t150, i64 %t151)
  br label %bb39
bb39:
  br label %bb91
bb40:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t153 = load ptr, ptr %l94, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb41, label %bb42
bb41:
  %t156 = load ptr, ptr %l94, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 22}
  %t159 = icmp eq i64 %t157, 0
  store i1 %t159, ptr %l95, !tbaa !21
  br label %bb42
bb42:
  %t160 = load i1, ptr %l95, !tbaa !21
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr }, ptr %t163, i32 0, i32 1
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l15, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %t167, ptr %t168)
  br label %bb46
bb46:
  br label %bb91
bb47:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t172 = load ptr, ptr %l102, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb48, label %bb49
bb48:
  %t175 = load ptr, ptr %l102, !tbaa !29
  %t176 = load i64, ptr %t175, !range !{i64 0, i64 22}
  %t178 = icmp eq i64 %t176, 21
  store i1 %t178, ptr %l103, !tbaa !21
  br label %bb49
bb49:
  %t179 = load i1, ptr %l103, !tbaa !21
  br i1 %t179, label %bb50, label %bb51
bb50:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", ptr }, ptr %t182, i32 0, i32 1
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l16, !tbaa !29
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l108, !tbaa !29
  %t187 = load ptr, ptr %l108, !tbaa !29
  %t188 = getelementptr %"compiler/generic:genRoots", ptr %t187, i32 0, i32 3
  %t189 = load i64, ptr %t188, !tbaa !24
  store i64 %t189, ptr %l109, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l16, !tbaa !29
  %t195 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t190, ptr %t191)
  store i64 %t195, ptr %l113
  br label %bb53
bb53:
  %t196 = load i64, ptr %l109, !tbaa !24
  %t197 = load i64, ptr %l113, !tbaa !24
  %t198 = or i64 %t196, %t197
  %t200 = load ptr, ptr %l108, !tbaa !29
  %t201 = getelementptr %"compiler/generic:genRoots", ptr %t200, i32 0, i32 3
  store i64 %t198, ptr %t201, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %t202, ptr %t203)
  br label %bb54
bb54:
  br label %bb91
bb55:
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t207 = load ptr, ptr %l117, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb56, label %bb57
bb56:
  %t210 = load ptr, ptr %l117, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 22}
  %t213 = icmp eq i64 %t211, 9
  store i1 %t213, ptr %l118, !tbaa !21
  br label %bb57
bb57:
  %t214 = load i1, ptr %l118, !tbaa !21
  br i1 %t214, label %bb58, label %bb59
bb58:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr }, ptr %t217, i32 0, i32 1
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l17, !tbaa !29
  br label %bb60
bb59:
  br label %bb71
bb60:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l17, !tbaa !29
  %t224 = getelementptr %"compiler/ast:ForIn", ptr %t222, i32 0, i32 2
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t229 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2eroot(ptr %v0, ptr %v1, ptr %t221, ptr %t225)
  store i64 %t229, ptr %l127
  br label %bb61
bb61:
  %t230 = load i64, ptr %l127, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l17, !tbaa !29
  %t234 = getelementptr %"compiler/ast:ForIn", ptr %t232, i32 0, i32 1
  %t235 = load i32, ptr %t234, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %t231, i32 %t235, i64 %t230)
  br label %bb62
bb62:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l17, !tbaa !29
  %t243 = getelementptr %"compiler/ast:ForIn", ptr %t241, i32 0, i32 4
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t240, { i64, ptr } %t244)
  br label %bb63
bb63:
  %t247 = load ptr, ptr %l17, !tbaa !29
  %t249 = getelementptr %"compiler/ast:ForIn", ptr %t247, i32 0, i32 5
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  store { i64, ptr } %t250, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t252 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t252, 0
  store i64 %t254, ptr %l21, !tbaa !24
  br label %bb64
bb64:
  %t256 = load i64, ptr %l20, !tbaa !24
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = icmp slt i64 %t256, %t257
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb65, label %bb66
bb65:
  br label %bb70
bb66:
  br label %bb67
bb67:
  %t264 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t264, ptr %l143, !tbaa !27
  %t265 = load i64, ptr %l20, !tbaa !24
  %t267 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr ptr, ptr %t268, i64 %t265
  %t270 = load ptr, ptr %t269, !tbaa !39
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/ast:Catch", ptr %t270, i32 0, i32 2
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %t272, { i64, ptr } %t276)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t279 = load i64, ptr %l20, !tbaa !24
  %t282 = add i64 %t279, 1
  store i64 %t282, ptr %l20, !tbaa !24
  br label %bb64
bb70:
  br label %bb91
bb71:
  %t284 = load ptr, ptr %l1, !tbaa !29
  store ptr %t284, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t285 = load ptr, ptr %l152, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb72, label %bb73
bb72:
  %t288 = load ptr, ptr %l152, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 22}
  %t291 = icmp eq i64 %t289, 5
  store i1 %t291, ptr %l153, !tbaa !21
  br label %bb73
bb73:
  %t292 = load i1, ptr %l153, !tbaa !21
  br i1 %t292, label %bb74, label %bb75
bb74:
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", ptr }, ptr %t295, i32 0, i32 1
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l23, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ebranches(ptr %v0, ptr %v1, ptr %t299, ptr %t300)
  br label %bb77
bb77:
  br label %bb91
bb78:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t305 = load ptr, ptr %l161, !tbaa !29
  %t306 = icmp ne ptr %t305, null
  br i1 %t306, label %bb79, label %bb80
bb79:
  %t308 = load ptr, ptr %l161, !tbaa !29
  %t309 = load i64, ptr %t308, !range !{i64 0, i64 22}
  %t311 = icmp eq i64 %t309, 11
  store i1 %t311, ptr %l162, !tbaa !21
  br label %bb80
bb80:
  %t312 = load i1, ptr %l162, !tbaa !21
  br i1 %t312, label %bb81, label %bb82
bb81:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr }, ptr %t315, i32 0, i32 1
  %t317 = load ptr, ptr %t316
  store ptr %t317, ptr %l24, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ematched(ptr %v0, ptr %v1, ptr %t319, ptr %t320)
  br label %bb84
bb84:
  br label %bb91
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2einner(ptr %v0, ptr %v1, ptr %t323, ptr %t324)
  br label %bb89
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_df5307d3a8bec99f_effac078aaeab34b)
  unreachable
bb91:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fgeneric_2eerrorDeclIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb33
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 12}
  %t37 = icmp eq i64 %t35, 6
  store i1 %t37, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l24, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [8 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l6, !tbaa !23
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t45 = load i32, ptr %l6, !tbaa !23
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = icmp eq i32 %t45, %t46
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l5, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb31
bb16:
  %t54 = load ptr, ptr %l5, !tbaa !29
  store ptr %t54, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t55 = load ptr, ptr %l34, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t58 = load ptr, ptr %l34, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 12}
  %t61 = icmp eq i64 %t59, 8
  store i1 %t61, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l35, !tbaa !21
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = getelementptr { i64, [8 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l7, !tbaa !29
  br label %bb21
bb20:
  br label %bb26
bb21:
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call ptr @compiler_2fgeneric_2eerrorDeclInIf(ptr %v0, ptr %v1, ptr %t69, i32 %t70)
  store ptr %t73, ptr %l42
  br label %bb22
bb22:
  %t74 = load ptr, ptr %l42, !tbaa !29
  store ptr %t74, ptr %l8, !tbaa !29
  %t75 = load ptr, ptr %l8, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t81 = load ptr, ptr %l8, !tbaa !29
  store ptr %t81, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_e63a4179e5518e65_559deced239d0aa9)
  unreachable
bb31:
  br label %bb32
bb32:
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l3, !tbaa !24
  br label %bb4
bb33:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_2efolded_2eunfolded() #0 {
entry:
  %l2 = alloca %"compiler/generic:folded"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/generic:folded"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr @G_2ecompiler_2fgeneric_2eUnfolded, !tbaa !24
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = call %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %s0, i64 %t1, i64 0, i32 %t2)
  store %"compiler/generic:folded" %t5, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/generic:folded", ptr %l2
  store %"compiler/generic:folded" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local i64 @compiler_2fgeneric_2ekeyDecl(i32 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = shl i64 1, 40
  %t4 = sext i32 %a0 to i64
  %t7 = or i64 %t1, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fgeneric_2ekeyPrim(i32 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = shl i64 3, 40
  %t4 = sext i32 %a0 to i64
  %t7 = or i64 %t1, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fgeneric_2emutableGlobal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:VarDecl", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l1, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 8}
  %t21 = icmp eq i64 %t19, 4
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t25, i32 0, i32 2
  %t27 = load i1, ptr %t26
  store i1 %t27, ptr %l2, !tbaa !21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %l9, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1f702846f089801_8e5e44ce193a520d)
  unreachable
bb14:
  %t31 = load i1, ptr %l9, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/generic:AnyTable" @compiler_2fgeneric_3aAnyTable_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/generic:AnyTable"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l5, !tbaa !23
  store i32 %a1, ptr %l6, !tbaa !23
  store i32 %a2, ptr %l7, !tbaa !23
  store i64 %a3, ptr %l8, !tbaa !24
  store %"compiler/source:Span" %a4, ptr %l9
  %t11 = call ptr @__olang_scope_hold(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l16, !tbaa !24
  %t13 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aAnyTable_2e5
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = call ptr @__olang_region_make(ptr %v0)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l16, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l16
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l18
  br label %bb3
bb3:
  %t20 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aAnyTable_2e5
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l16
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = call ptr @__olang_region_or(ptr %t26, ptr null)
  %t28 = call ptr @__olang_region_home(ptr %t27)
  %t29 = icmp ne ptr %t28, null
  %t30 = select i1 %t29, ptr %t28, ptr null
  call void @__olang_region_settle_in(ptr %t23, ptr %t30)
  br label %bb5
bb5:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = insertvalue %"compiler/generic:AnyTable" undef, i32 %t32, 0
  %t34 = load i32, ptr %l6, !tbaa !23
  %t35 = insertvalue %"compiler/generic:AnyTable" %t33, i32 %t34, 1
  %t36 = load i32, ptr %l7, !tbaa !23
  %t37 = insertvalue %"compiler/generic:AnyTable" %t35, i32 %t36, 2
  %t38 = load i64, ptr %l8, !tbaa !24
  %t39 = insertvalue %"compiler/generic:AnyTable" %t37, i64 %t38, 3
  %t40 = load %"compiler/source:Span", ptr %l9
  %t41 = insertvalue %"compiler/generic:AnyTable" %t39, %"compiler/source:Span" %t40, 4
  %t43 = insertvalue %"compiler/generic:AnyTable" %t41, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, 5
  store %"compiler/generic:AnyTable" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:AnyTable", ptr %rv
  ret %"compiler/generic:AnyTable" %rr
}

define dso_local %"compiler/generic:ConstAsk" @compiler_2fgeneric_3aConstAsk_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, ptr %a1, i32 %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %rv = alloca %"compiler/generic:ConstAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/generic:ConstAsk" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/generic:ConstAsk" %t16, ptr %a1, 1
  %t20 = insertvalue %"compiler/generic:ConstAsk" %t18, i32 %a2, 2
  %t22 = insertvalue %"compiler/generic:ConstAsk" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/generic:ConstAsk" %t22, { i64, ptr } %a4, 4
  %t26 = insertvalue %"compiler/generic:ConstAsk" %t24, { i64, ptr } %a5, 5
  %t28 = insertvalue %"compiler/generic:ConstAsk" %t26, { i64, ptr } %a6, 6
  store %"compiler/generic:ConstAsk" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:ConstAsk", ptr %rv
  ret %"compiler/generic:ConstAsk" %rr
}

define dso_local %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/generic:Origin"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/generic:Origin" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/generic:Origin" %t10, %"compiler/source:Span" %a1, 1
  %t14 = insertvalue %"compiler/generic:Origin" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/generic:Origin" %t14, i32 %a3, 3
  store %"compiler/generic:Origin" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Origin", ptr %rv
  ret %"compiler/generic:Origin" %rr
}

define dso_local %"compiler/generic:cursor" @compiler_2fgeneric_3acursor_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca %"compiler/generic:cursor"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/generic:cursor" undef, { i64, ptr } %a0, 0
  %t6 = insertvalue %"compiler/generic:cursor" %t4, i64 0, 1
  store %"compiler/generic:cursor" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:cursor", ptr %rv
  ret %"compiler/generic:cursor" %rr
}

define dso_local %"compiler/generic:folded" @compiler_2fgeneric_3afolded_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/generic:folded"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/generic:folded" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/generic:folded" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/generic:folded" %t10, i32 %a2, 2
  store %"compiler/generic:folded" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:folded", ptr %rv
  ret %"compiler/generic:folded" %rr
}

define dso_local %"compiler/generic:memberRow" @compiler_2fgeneric_3amemberRow_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i64 %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, i32 %a6, i64 %a7) #0 {
entry:
  %rv = alloca %"compiler/generic:memberRow"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/generic:memberRow" undef, i64 %a0, 0
  %t20 = insertvalue %"compiler/generic:memberRow" %t18, %"compiler/source:Span" %a1, 1
  %t22 = insertvalue %"compiler/generic:memberRow" %t20, ptr %a2, 2
  %t24 = insertvalue %"compiler/generic:memberRow" %t22, i32 %a3, 3
  %t26 = insertvalue %"compiler/generic:memberRow" %t24, { i64, ptr } %a4, 4
  %t28 = insertvalue %"compiler/generic:memberRow" %t26, ptr %a5, 5
  %t30 = insertvalue %"compiler/generic:memberRow" %t28, i32 %a6, 6
  %t32 = insertvalue %"compiler/generic:memberRow" %t30, i64 %a7, 7
  store %"compiler/generic:memberRow" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:memberRow", ptr %rv
  ret %"compiler/generic:memberRow" %rr
}

define dso_local %"compiler/generic:pattern" @compiler_2fgeneric_3apattern_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, i32 %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/generic:pattern"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/generic:pattern" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/generic:pattern" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/generic:pattern" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/generic:pattern" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/generic:pattern" %t18, ptr %a4, 4
  store %"compiler/generic:pattern" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:pattern", ptr %rv
  ret %"compiler/generic:pattern" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal { i32, ptr } @olang_lambda_0(ptr %env, ptr %v0) #0 {
entry:
  %p = call ptr @llvm.coro.promise(ptr %env, i32 8, i1 false)
  %pr = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 1
  %running = load i32, ptr %pr
  switch i32 %running, label %again [ i32 0, label %go i32 2, label %drop ]
again:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
drop:
  call void @llvm.coro.destroy(ptr %env)
  br label %over
go:
  %done = call i1 @llvm.coro.done(ptr %env)
  br i1 %done, label %over, label %run
run:
  %pv0 = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 3
  store ptr %v0, ptr %pv0
  store i32 1, ptr %pr
  call void @llvm.coro.resume(ptr %env)
  store i32 0, ptr %pr
  %r = load { i32, ptr }, ptr %p
  ret { i32, ptr } %r
over:
  %x = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  ret { i32, ptr } %x
}

define internal { i32, ptr } @olang_lambda_0.wnext(ptr %env, ptr %v0) alwaysinline #0 {
entry:
  %p = call ptr @llvm.coro.promise(ptr %env, i32 8, i1 false)
  %pr = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 1
  %running = load i32, ptr %pr
  %stop = icmp eq i32 %running, 2
  br i1 %stop, label %drop, label %run
drop:
  call void @llvm.coro.destroy(ptr %env)
  br label %over
run:
  %pv0 = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 3
  store ptr %v0, ptr %pv0
  call void @llvm.coro.resume(ptr %env)
  %r = load { i32, ptr }, ptr %p
  ret { i32, ptr } %r
over:
  %x = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  ret { i32, ptr } %x
}

define internal ptr @olang_lambda_0.coro(ptr %env, ptr %home) presplitcoroutine alwaysinline #0 {
entry:
  %prom = alloca { { i32, ptr }, i32, ptr, ptr }, align 8
  store { { i32, ptr }, i32, ptr, ptr } zeroinitializer, ptr %prom
  %rv = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %prom, i32 0, i32 0
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %cid = call token @llvm.coro.id(i32 8, ptr %prom, ptr null, ptr null)
  %cneed = call i1 @llvm.coro.alloc(token %cid)
  br i1 %cneed, label %coro.alloc, label %coro.begin
coro.alloc:
  %csz = call i64 @llvm.coro.size.i64()
  %cal = call i64 @llvm.coro.align.i64()
  %cmem0 = call ptr @__olang_scope_alloc_a(ptr %home, i64 %csz, i64 %cal)
  br label %coro.begin
coro.begin:
  %cmem = phi ptr [ null, %entry ], [ %cmem0, %coro.alloc ]
  %hdl = call ptr @llvm.coro.begin(token %cid, ptr %cmem)
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l0
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  %is = call i8 @llvm.coro.suspend(token none, i1 false)
  switch i8 %is, label %gen.end [ i8 0, label %gen.go i8 1, label %gen.fresh ]
gen.fresh:
  br label %gen.free
gen.go:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/ast:StructBody", ptr %t1, i32 0, i32 2
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  br label %bb22
bb3:
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l5, !tbaa !29
  %t28 = load ptr, ptr %l5, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 22}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t43 = load ptr, ptr %l6, !tbaa !29
  %t45 = getelementptr %"compiler/ast:VarDecl", ptr %t43, i32 0, i32 5
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = insertvalue { i32, ptr } zeroinitializer, ptr %t48, 1
  store { i32, ptr } %t50, ptr %rv
  %t51 = call i8 @llvm.coro.suspend(token none, i1 false)
  switch i8 %t51, label %gen.end [ i8 0, label %gen.res.52 i8 1, label %gen.drop.53 ]
gen.res.52:
  br label %bb12
gen.drop.53:
  br label %bb13
bb11:
  br label %bb14
bb12:
  br label %bb14
bb13:
  br label %gen.free
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_4e9784bcac016c39_bf9d00668e70ebe5)
  unreachable
bb20:
  br label %bb21
bb21:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = add i64 %t54, 1
  store i64 %t57, ptr %l3, !tbaa !24
  br label %bb1
bb22:
  %t60 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t60, ptr %rv
  br label %ret
ret:
  %fs = call i8 @llvm.coro.suspend(token none, i1 true)
  switch i8 %fs, label %gen.end [ i8 0, label %gen.dead i8 1, label %gen.free ]
gen.dead:
  unreachable
gen.free:
  %fm = call ptr @llvm.coro.free(token %cid, ptr %hdl)
  br label %gen.end
gen.end:
  %ce = call i1 @llvm.coro.end(ptr %hdl, i1 false, token none)
  ret ptr %hdl
}

define internal void @olang_lambda_0.drop(ptr %h, ptr %scope) #0 {
entry:
  %p = call ptr @llvm.coro.promise(ptr %h, i32 8, i1 false)
  %pr = getelementptr { { i32, ptr }, i32, ptr, ptr }, ptr %p, i32 0, i32 1
  %r = load i32, ptr %pr
  %idle = icmp eq i32 %r, 0
  br i1 %idle, label %d, label %x
d:
  call void @llvm.coro.destroy(ptr %h)
  br label %x
x:
  ret void
}

declare void @__olang_scope_register_dtor(ptr, ptr, ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Columns" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d13 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"std/prelude/reflect" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d18 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Char" }>, align 8
@.d20 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d21 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d22 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@olang_2esole_2ecompiler_2fgeneric_3aAnyTable_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare ptr @llvm.coro.promise(ptr, i32, i1)
@.c23 = private unnamed_addr constant [87 x i8] c"compiler/generic.olang:2629: a generator asked for its next value inside its own walk\0A\00"
declare void @llvm.coro.destroy(ptr)
declare i1 @llvm.coro.done(ptr)
declare void @llvm.coro.resume(ptr)
declare token @llvm.coro.id(i32, ptr, ptr, ptr)
declare i1 @llvm.coro.alloc(token)
declare i64 @llvm.coro.size.i64()
declare i64 @llvm.coro.align.i64()
declare ptr @llvm.coro.begin(token, ptr)
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare i8 @llvm.coro.suspend(token, i1)
declare ptr @llvm.coro.free(token, ptr)
declare i1 @llvm.coro.end(ptr, i1, token)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @std_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aVarDecl_3e_2ector(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e)
declare i1 @compiler_2fgeneric_2eisErrsArg(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"compiler/generic:Unmet" @compiler_2fgeneric_3aUnmet_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i1 %a3, i1 %a4, i1 %a5)
declare i1 @compiler_2fnames_2eWrittenMut(ptr %v0, ptr %a0)
@olang_loc_16dbf6b4ccd94c8c_8f0170059e61e7c0 = external constant [0 x i8]
@olang_loc_b4eb6cf3622f1222_98250c586f701fa6 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eallFns(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyCovers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:fnRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eAt_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3afnRow_3e_2eLen_3ccompiler_2fgeneric_3afnRow_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumnVec(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__Hbe724e949204db7f54e3bca969c5f391(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_799e213f453ad9fb_869f4f41e63ea5ff = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkUnique(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkPacked(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eMarkEnds(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__H7ddd7dd10a6733ce5265405d8e7c8faa(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_e3e3caa307fb777e_fe02cb9db66a417a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_4139559e1c186529_46f8c3a78fef470d = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eentriesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNameErrVal(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_e11f9621bf6c2a4e_ffbbdf781a3c7e7a = external constant [0 x i8]
@olang_loc_882f12ba06d2ce43_a9b5d482619655cf = external constant [0 x i8]
@olang_loc_76207083d0f68b9f_74e05cac4bc21103 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_de4c5053baae2eb0_7e20459b6f7605c4 = external constant [0 x i8]
@olang_loc_16d3c7726565025d_3b40f943fadf33d1 = external constant [0 x i8]
@olang_loc_7b14d935e96e16e5_1eebf856974cc301 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrsArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enumberOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efnsIn(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fgeneric_2eGenPerTurn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3993e9d21a27b6abd527556382000d9e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDepth(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eMaxDepth = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\30\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunbounded(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Hf7241cd153db7dbb97afc4b39a688af4(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H52a70901e2e6ceea4e17edd807bbe24b(ptr %v0, ptr %a0, i32 %a1, %"compiler/generic:Origin" %a2)
declare %"compiler/generic:instance" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3ainstance_3e_2eAt__Hf3965267bb92d0ee7aeaa2339e2e46fa(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epreludeNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare %"compiler/generic:memberRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eAt_H0818468919c31b926123191f6718935b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2eLe_Hffef742b46d9f4381d344302148f855f(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6743fd6fdd876d533cce32e3c0cd25b6(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hcfc2a2943c600247d4ded3fb914681ab(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_25bcbd8d25f60d50_252e633c827b5284 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Ha2fdd285cc075e465cab85a1d0fe3f31(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hc32bd40495535e8a7e7ddcc641d0c371(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hce1a5ca8c8bc252d00e2ccbd39de0b40(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fpair_3aPair_3cI64_2c_20I64_3_Hca1409b49ac7e9b021f6a95c9301ae1a(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2edeclVars(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_91e581c61227d1c4_deb54d58cf8aa350 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_632aa6436eca4593_afccf639e057e8af = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ementionsName(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvBinds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__H9861f6f09602cf23d49075e82ac9429b(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fnames_2ePayloadName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__Hbdd7c5068e376aa260a62181a9f99429(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_7fa838ee20be17d9_9f8073ee4b7324d5 = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hd32df9536ace7093dedc2ceceb7810b4(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bea3dfbd3e43d709_f7b1d9dae3096955 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ebodiesOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRecord(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetEnumBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNameIds(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2esigType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i32 %a4)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2epromisesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithPromises(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i64 %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUniqueSettled(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstExpr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8e4deaec3e2f71aa_ab3a032f79647ee = external constant [0 x i8]
@olang_loc_231a5def5f2dccd8_8883f165640dcf84 = external constant [0 x i8]
@olang_loc_b927a1007eda2e1c_4bb59e0dd95e8bc0 = external constant [0 x i8]
@olang_loc_6578d57707832f1c_86539f83bfff8b08 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eaddFns(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_8ca182a09b46660b_89b944af5f42b927 = external constant [0 x i8]
@olang_loc_e2462b885589950a_643da267921b7c76 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvKey(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3amemberRow_3e_2ePu_Hd08e06a92da62f0f388e5d473a774064(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:memberRow" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eLen_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %a0)
declare %"compiler/generic:varRow" @compiler_2fgeneric_3avarRow_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2ePush_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %a0, %"compiler/generic:varRow" %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hcad520af686b186b53ef29921f8ab48b(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eglobalIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2efile(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInfer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_1f5b32fdadeb85ff_22810fceb0d0eac3 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3acursor_2eeat(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecanonInner(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:varRow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eAt_3ccompiler_2fgeneric_3avarRow_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3avarRow_3e_2eSetAt_H989a0ed1a318d7d0cbb6cc41385b33d2(ptr %v0, ptr %a0, i64 %a1, %"compiler/generic:varRow" %a2)
declare { i64, ptr } @compiler_2fgeneric_2edescName(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_886433b88e29f460_704fa105f63225d4 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
@G_2ecompiler_2fgeneric_2eFolded = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_cbe34de7626751c6_f090548a7d71387a = external constant [0 x i8]
declare %"compiler/generic:folded" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eeval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ewrap(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_5392f566c0fc8331_15db183dd26dbb85 = external constant [0 x i8]
@olang_loc_514348f953d022bc_74505ba6df313dd0 = external constant [0 x i8]
@olang_loc_289ae50874ea0e2b_45680487effe832f = external constant [0 x i8]
@olang_loc_d51864a21628ffaa_68720bbe5c137f7e = external constant [0 x i8]
@olang_loc_e8d533ef83292235_9ed3ad18ce9fa601 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ereprReady(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4860714026464204_4592c2a1d2b55600 = external constant [0 x i8]
@olang_loc_360fa96f69d7f913_7dd7870a86c7dc67 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_4472349556a15fd2_df3caa9bde222db6 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2eLengthDecided(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ehandedOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3, i64 %a4, { i64, ptr } %a5, i64 %a6)
@olang_loc_c640e61325a8531d_77d5bebedc0f2c09 = external constant [0 x i8]
@olang_loc_fc435fbf179ab4a3_d5536eec81a24b6f = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ecallType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2earrayMade(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, { i64, ptr } %a4)
@olang_loc_5761ebb5a70d3685_c26bb19c18fbb051 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7c1b9fa6eff766ef_29392a9ca6e4fd4b = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ealiasStep(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2etypeKey(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2erecvApplies(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerOf(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eerrorList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, { i64, ptr } %a3)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2enamedPartsReady(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_c5022c2221033445_fbaef66a28713951 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclaredFunc(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eParseCanon(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eanonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eparamTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_a096310d429842c5_b38f3d186616d6e9 = external constant [0 x i8]
@olang_loc_4439a413e01d0c26_16c6d6890310944a = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2emeetsBuilder(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3, i1 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eunendedNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3, i1 %a4)
@olang_loc_e6b22f697499a1dd_b3ee10b0849b47b1 = external constant [0 x i8]
@olang_loc_b7daf7406ba778a4_42e2bd1e0b6e1610 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2egrow(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_961f770be6209277_34282562e2239643 = external constant [0 x i8]
@olang_loc_9e9a19de368b1652_6a1b6384f5ca11a6 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_5dbf3bacf45043d5_48a0238198051071 = external constant [0 x i8]
@G_2ecompiler_2fgeneric_2eGenLocalBit = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@olang_loc_c61310131704fb2f_f27aa7cba89c0bc3 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2enameRoot(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2ecaseRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_3ab543dc145c7b05_675409dfde5f91a1 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ebaseName(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3agenRoots_2estored(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_df5307d3a8bec99f_effac078aaeab34b = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2eerrorDeclInIf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_e63a4179e5518e65_559deced239d0aa9 = external constant [0 x i8]
@G_2ecompiler_2fgeneric_2eUnfolded = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@olang_loc_1f702846f089801_8e5e44ce193a520d = external constant [0 x i8]
@olang_loc_4e9784bcac016c39_bf9d00668e70ebe5 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
