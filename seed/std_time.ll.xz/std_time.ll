; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/time:Date" = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
@G_2estd_2ftime_2eBillion = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\14\00\00\00\00\00\00\00", ptr @G_2estd_2ftime_2eBillion.k1 }>, align 8
@G_2estd_2ftime_2eBillion.k1 = internal global <{ [20 x i8] }> <{ [20 x i8] c"\32\30\30\31\2D\30\39\2D\30\39\54\30\31\3A\34\36\3A\34\30\5A" }>, align 8
@G_2estd_2ftime_2eEpochText = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\14\00\00\00\00\00\00\00", ptr @G_2estd_2ftime_2eEpochText.k1 }>, align 8
@G_2estd_2ftime_2eEpochText.k1 = internal global <{ [20 x i8] }> <{ [20 x i8] c"\31\39\37\30\2D\30\31\2D\30\31\54\30\30\3A\30\30\3A\30\30\5A" }>, align 8
@G_2estd_2ftime_2eclockMonotonic = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2ftime_2eclockRealtime = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
define dso_local void @olang_2einit_2estd_2ftime() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2ftime_2eclockRealtime_2einit()
  br label %bb1
bb1:
  call void @std_2ftime_2eclockMonotonic_2einit()
  br label %bb2
bb2:
  call void @std_2ftime_2eEpochText_2einit()
  br label %bb3
bb3:
  call void @std_2ftime_2eBillion_2einit()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2ftime_2eBillion_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call { i64, ptr } @std_2ftime_2eFormat(ptr %t1, i64 1000000000000000000, i64 0)
  store { i64, ptr } %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load { i64, ptr }, ptr @G_2estd_2ftime_2eBillion, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t4, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = getelementptr { i64, ptr }, ptr @G_2estd_2ftime_2eBillion, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = mul i64 %t15, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %t14, i64 %t16, i1 false)
  br label %bb4
bb3:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr @G_2estd_2ftime_2eBillion, !tbaa !27
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local %"std/time:Date" @std_2ftime_2eDateOf(i64 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l33 = alloca i64
  %l76 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l104 = alloca %"std/time:Date"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/time:Date"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t2, 60000000000
  %t7 = add i64 %a0, %t4
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = sdiv i64 %t9, 86400000000000
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = srem i64 %t13, 86400000000000
  store i64 %t15, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t17, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t21, 1
  store i64 %t23, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t25, 86400000000000
  store i64 %t27, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = add i64 %t29, 719468
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sge i64 %t33, 0
  br i1 %t35, label %bb4, label %bb5
bb4:
  %t37 = load i64, ptr %l5, !tbaa !24
  store i64 %t37, ptr %l33, !tbaa !24
  br label %bb6
bb5:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = sub i64 %t39, 146096
  store i64 %t41, ptr %l33, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l33, !tbaa !24
  %t44 = sdiv i64 %t43, 146097
  store i64 %t44, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = mul i64 %t47, 146097
  %t52 = sub i64 %t46, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = sdiv i64 %t55, 1460
  %t60 = sub i64 %t54, %t57
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t61, 36524
  %t66 = add i64 %t60, %t63
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = sdiv i64 %t67, 146096
  %t72 = sub i64 %t66, %t69
  %t74 = sdiv i64 %t72, 365
  store i64 %t74, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 365, %t77
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = sdiv i64 %t80, 4
  %t85 = add i64 %t79, %t82
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = sdiv i64 %t86, 100
  %t91 = sub i64 %t85, %t88
  %t94 = sub i64 %t76, %t91
  store i64 %t94, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = mul i64 5, %t96
  %t100 = add i64 %t98, 2
  %t102 = sdiv i64 %t100, 153
  store i64 %t102, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t105 = load i64, ptr %l10, !tbaa !24
  %t107 = mul i64 153, %t105
  %t109 = add i64 %t107, 2
  %t111 = sdiv i64 %t109, 5
  %t114 = sub i64 %t104, %t111
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t120 = icmp slt i64 %t118, 10
  br i1 %t120, label %bb7, label %bb8
bb7:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t124 = add i64 %t122, 3
  store i64 %t124, ptr %l76, !tbaa !24
  br label %bb9
bb8:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t128 = sub i64 %t126, 9
  store i64 %t128, ptr %l76, !tbaa !24
  br label %bb9
bb9:
  %t130 = load i64, ptr %l76, !tbaa !24
  store i64 %t130, ptr %l12, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t134 = mul i64 %t132, 400
  %t137 = add i64 %t131, %t134
  store i64 %t137, ptr %l84, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp sle i64 %t138, 2
  br i1 %t140, label %bb10, label %bb11
bb10:
  store i64 1, ptr %l87, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb12
bb12:
  %t142 = load i64, ptr %l84, !tbaa !24
  %t143 = load i64, ptr %l87, !tbaa !24
  %t144 = add i64 %t142, %t143
  %t146 = load i64, ptr %l4, !tbaa !24
  %t148 = sdiv i64 %t146, 1000000000
  store i64 %t148, ptr %l14, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t153 = load i64, ptr %l14, !tbaa !24
  %t155 = sdiv i64 %t153, 3600
  %t156 = load i64, ptr %l14, !tbaa !24
  %t158 = sdiv i64 %t156, 60
  %t160 = srem i64 %t158, 60
  %t161 = load i64, ptr %l14, !tbaa !24
  %t163 = srem i64 %t161, 60
  %t164 = load i64, ptr %l4, !tbaa !24
  %t166 = srem i64 %t164, 1000000000
  %t167 = load i64, ptr %l1, !tbaa !24
  %t176 = call %"std/time:Date" @std_2ftime_3aDate_2ector(ptr %s0, i64 %t144, i64 %t151, i64 %t152, i64 %t155, i64 %t160, i64 %t163, i64 %t166, i64 %t167)
  store %"std/time:Date" %t176, ptr %l104
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t177 = load %"std/time:Date", ptr %l104
  store %"std/time:Date" %t177, ptr %rv
  br label %ret
ret:
  %rr = load %"std/time:Date", ptr %rv
  ret %"std/time:Date" %rr
}

define dso_local i64 @std_2ftime_2eElapsed(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l1
  br label %bb1
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t3, %a0
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2ftime_2eEpochText_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call { i64, ptr } @std_2ftime_2eFormat(ptr %t1, i64 0, i64 0)
  store { i64, ptr } %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load { i64, ptr }, ptr @G_2estd_2ftime_2eEpochText, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t4, %t8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = getelementptr { i64, ptr }, ptr @G_2estd_2ftime_2eEpochText, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = mul i64 %t15, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %t14, i64 %t16, i1 false)
  br label %bb4
bb3:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr @G_2estd_2ftime_2eEpochText, !tbaa !27
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2ftime_2eFormat(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l4 = alloca %"std/time:Date"
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/time:Date" @std_2ftime_2eDateOf(i64 %a0, i64 %a1)
  store %"std/time:Date" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load %"std/time:Date", ptr %l4
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"std/time:Date" %t6, ptr %t7
  %t9 = call { i64, ptr } @std_2ftime_2estd_2ftime_3aDate_2eStr(ptr %v0, ptr %v0, ptr %t7)
  store { i64, ptr } %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2ftime_2eHours(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 3600000000000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eMicros(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 1000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eMillis(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 1000000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eMinutes(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 60000000000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eNanos(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eNow() #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2estd_2ftime_2eclockMonotonic, !tbaa !23
  %t3 = call i64 @std_2ftime_2eread(i32 %t1)
  store i64 %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, %"std/time:Date" } @std_2ftime_2eParse(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i32
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l57 = alloca i32
  %l59 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i32
  %l65 = alloca i32
  %l67 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i32
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca i1
  %l100 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l141 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i32
  %l151 = alloca i32
  %l153 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i32
  %l162 = alloca i1
  %l170 = alloca { i64, ptr }
  %l186 = alloca i1
  %l189 = alloca i1
  %l192 = alloca i1
  %l193 = alloca i64
  %l196 = alloca i64
  %l198 = alloca i1
  %l201 = alloca i1
  %l204 = alloca i1
  %l216 = alloca %"std/time:Date"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, %"std/time:Date" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t1, i64 0, i64 4)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l17
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l16
  br label %bb1
bb1:
  %t8 = load i64, ptr %l16, !tbaa !24
  store i64 %t8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i32, ptr %l17, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t17, 0
  store { i32, %"std/time:Date" } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load i64, ptr %l14, !tbaa !24
  store i64 %t20, ptr %l1, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t21, i64 4, i8 45)
  store i32 %t23, ptr %l20
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25
ok.25:
  br label %bb4
bb4:
  br label %bb6
bb5:
  %t26 = load i32, ptr %l20, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  %t36 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t34, 0
  store { i32, %"std/time:Date" } %t36, ptr %rv
  br label %ret
bb6:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t37, i64 5, i64 2)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l25
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb8, label %ok.43
ok.43:
  store i64 %t40, ptr %l24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l24, !tbaa !24
  store i64 %t44, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  %t45 = load i32, ptr %l25, !tbaa !23
  %t46 = lshr i32 %t45, 16
  %t47 = and i32 %t45, 65535
  %t48 = icmp eq i32 %t46, 1
  %t49 = select i1 %t48, i32 1, i32 0
  %t50 = icmp eq i32 %t45, 0
  %t51 = shl i32 %t49, 16
  %t52 = or i32 %t51, %t47
  %t53 = select i1 %t50, i32 0, i32 %t52
  call void @__olang_scope_close(ptr %s0)
  %t55 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t53, 0
  store { i32, %"std/time:Date" } %t55, ptr %rv
  br label %ret
bb9:
  %t56 = load i64, ptr %l22, !tbaa !24
  store i64 %t56, ptr %l2, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t57, i64 7, i8 45)
  store i32 %t59, ptr %l28
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb11, label %ok.61
ok.61:
  br label %bb10
bb10:
  br label %bb12
bb11:
  %t62 = load i32, ptr %l28, !tbaa !23
  %t63 = lshr i32 %t62, 16
  %t64 = and i32 %t62, 65535
  %t65 = icmp eq i32 %t63, 1
  %t66 = select i1 %t65, i32 1, i32 0
  %t67 = icmp eq i32 %t62, 0
  %t68 = shl i32 %t66, 16
  %t69 = or i32 %t68, %t64
  %t70 = select i1 %t67, i32 0, i32 %t69
  call void @__olang_scope_close(ptr %s0)
  %t72 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t70, 0
  store { i32, %"std/time:Date" } %t72, ptr %rv
  br label %ret
bb12:
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t75 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t73, i64 8, i64 2)
  %t76 = extractvalue { i32, i64 } %t75, 1
  %t77 = extractvalue { i32, i64 } %t75, 0
  store i32 %t77, ptr %l33
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb14, label %ok.79
ok.79:
  store i64 %t76, ptr %l32
  br label %bb13
bb13:
  %t80 = load i64, ptr %l32, !tbaa !24
  store i64 %t80, ptr %l30, !tbaa !24
  br label %bb15
bb14:
  %t81 = load i32, ptr %l33, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  call void @__olang_scope_close(ptr %s0)
  %t91 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t89, 0
  store { i32, %"std/time:Date" } %t91, ptr %rv
  br label %ret
bb15:
  %t92 = load i64, ptr %l30, !tbaa !24
  store i64 %t92, ptr %l3, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp sle i64 %t95, 10
  br i1 %t97, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb24
bb17:
  %t99 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t99, ptr %l39, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 10
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = icmp ne i8 %t103, 84
  br i1 %t105, label %bb18, label %bb19
bb18:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l43, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i8, ptr %t109, i64 10
  %t111 = load i8, ptr %t110, !tbaa !32
  %t113 = icmp ne i8 %t111, 116
  store i1 %t113, ptr %l42, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t115 = load i1, ptr %l42, !tbaa !21
  br i1 %t115, label %bb21, label %bb22
bb21:
  %t116 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t116, ptr %l47, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i8, ptr %t118, i64 10
  %t120 = load i8, ptr %t119, !tbaa !32
  %t122 = icmp ne i8 %t120, 32
  store i1 %t122, ptr %l46, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t124 = load i1, ptr %l46, !tbaa !21
  store i1 %t124, ptr %l38, !tbaa !21
  br label %bb24
bb24:
  %t125 = load i1, ptr %l38, !tbaa !21
  br i1 %t125, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t127 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t127, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t128 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t130 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t128, i64 11, i64 2)
  %t131 = extractvalue { i32, i64 } %t130, 1
  %t132 = extractvalue { i32, i64 } %t130, 0
  store i32 %t132, ptr %l54
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb29, label %ok.134
ok.134:
  store i64 %t131, ptr %l53
  br label %bb28
bb28:
  %t135 = load i64, ptr %l53, !tbaa !24
  store i64 %t135, ptr %l51, !tbaa !24
  br label %bb30
bb29:
  %t136 = load i32, ptr %l54, !tbaa !23
  %t137 = lshr i32 %t136, 16
  %t138 = and i32 %t136, 65535
  %t139 = icmp eq i32 %t137, 1
  %t140 = select i1 %t139, i32 1, i32 0
  %t141 = icmp eq i32 %t136, 0
  %t142 = shl i32 %t140, 16
  %t143 = or i32 %t142, %t138
  %t144 = select i1 %t141, i32 0, i32 %t143
  call void @__olang_scope_close(ptr %s0)
  %t146 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t144, 0
  store { i32, %"std/time:Date" } %t146, ptr %rv
  br label %ret
bb30:
  %t147 = load i64, ptr %l51, !tbaa !24
  store i64 %t147, ptr %l4, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t150 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t148, i64 13, i8 58)
  store i32 %t150, ptr %l57
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb32, label %ok.152
ok.152:
  br label %bb31
bb31:
  br label %bb33
bb32:
  %t153 = load i32, ptr %l57, !tbaa !23
  %t154 = lshr i32 %t153, 16
  %t155 = and i32 %t153, 65535
  %t156 = icmp eq i32 %t154, 1
  %t157 = select i1 %t156, i32 1, i32 0
  %t158 = icmp eq i32 %t153, 0
  %t159 = shl i32 %t157, 16
  %t160 = or i32 %t159, %t155
  %t161 = select i1 %t158, i32 0, i32 %t160
  call void @__olang_scope_close(ptr %s0)
  %t163 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t161, 0
  store { i32, %"std/time:Date" } %t163, ptr %rv
  br label %ret
bb33:
  %t164 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t166 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t164, i64 14, i64 2)
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l62
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb35, label %ok.170
ok.170:
  store i64 %t167, ptr %l61
  br label %bb34
bb34:
  %t171 = load i64, ptr %l61, !tbaa !24
  store i64 %t171, ptr %l59, !tbaa !24
  br label %bb36
bb35:
  %t172 = load i32, ptr %l62, !tbaa !23
  %t173 = lshr i32 %t172, 16
  %t174 = and i32 %t172, 65535
  %t175 = icmp eq i32 %t173, 1
  %t176 = select i1 %t175, i32 1, i32 0
  %t177 = icmp eq i32 %t172, 0
  %t178 = shl i32 %t176, 16
  %t179 = or i32 %t178, %t174
  %t180 = select i1 %t177, i32 0, i32 %t179
  call void @__olang_scope_close(ptr %s0)
  %t182 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t180, 0
  store { i32, %"std/time:Date" } %t182, ptr %rv
  br label %ret
bb36:
  %t183 = load i64, ptr %l59, !tbaa !24
  store i64 %t183, ptr %l5, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t186 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t184, i64 16, i8 58)
  store i32 %t186, ptr %l65
  %t187 = icmp ne i32 %t186, 0
  br i1 %t187, label %bb38, label %ok.188
ok.188:
  br label %bb37
bb37:
  br label %bb39
bb38:
  %t189 = load i32, ptr %l65, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  call void @__olang_scope_close(ptr %s0)
  %t199 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t197, 0
  store { i32, %"std/time:Date" } %t199, ptr %rv
  br label %ret
bb39:
  %t200 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t202 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t200, i64 17, i64 2)
  %t203 = extractvalue { i32, i64 } %t202, 1
  %t204 = extractvalue { i32, i64 } %t202, 0
  store i32 %t204, ptr %l70
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb41, label %ok.206
ok.206:
  store i64 %t203, ptr %l69
  br label %bb40
bb40:
  %t207 = load i64, ptr %l69, !tbaa !24
  store i64 %t207, ptr %l67, !tbaa !24
  br label %bb42
bb41:
  %t208 = load i32, ptr %l70, !tbaa !23
  %t209 = lshr i32 %t208, 16
  %t210 = and i32 %t208, 65535
  %t211 = icmp eq i32 %t209, 1
  %t212 = select i1 %t211, i32 1, i32 0
  %t213 = icmp eq i32 %t208, 0
  %t214 = shl i32 %t212, 16
  %t215 = or i32 %t214, %t210
  %t216 = select i1 %t213, i32 0, i32 %t215
  call void @__olang_scope_close(ptr %s0)
  %t218 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t216, 0
  store { i32, %"std/time:Date" } %t218, ptr %rv
  br label %ret
bb42:
  %t219 = load i64, ptr %l67, !tbaa !24
  store i64 %t219, ptr %l6, !tbaa !24
  store i64 19, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t220 = load i64, ptr %l7, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t226 = icmp slt i64 %t220, %t223
  br i1 %t226, label %bb43, label %bb44
bb43:
  %t228 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t228, ptr %l77, !tbaa !27
  %t229 = load i64, ptr %l7, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i8, ptr %t232, i64 %t229
  %t234 = load i8, ptr %t233, !tbaa !32
  %t236 = icmp eq i8 %t234, 46
  store i1 %t236, ptr %l76, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb45
bb45:
  %t238 = load i1, ptr %l76, !tbaa !21
  br i1 %t238, label %bb46, label %bb47
bb46:
  %t239 = load i64, ptr %l7, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l7, !tbaa !24
  %t243 = load i64, ptr %l7, !tbaa !24
  store i64 %t243, ptr %l9, !tbaa !24
  store i64 100000000, ptr %l10, !tbaa !24
  br label %bb48
bb47:
  br label %bb64
bb48:
  store %olang.scope zeroinitializer, ptr %s3
  %t245 = load i64, ptr %l7, !tbaa !24
  %t246 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t251 = icmp slt i64 %t245, %t248
  br i1 %t251, label %bb49, label %bb50
bb49:
  %t253 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t253, ptr %l89, !tbaa !27
  %t254 = load i64, ptr %l7, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i8, ptr %t257, i64 %t254
  %t259 = load i8, ptr %t258, !tbaa !32
  %t261 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t259)
  store i1 %t261, ptr %l92
  br label %bb51
bb50:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb52
bb51:
  %t262 = load i1, ptr %l92, !tbaa !21
  store i1 %t262, ptr %l88, !tbaa !21
  br label %bb52
bb52:
  %t263 = load i1, ptr %l88, !tbaa !21
  %t264 = xor i1 %t263, true
  br i1 %t264, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb54:
  br label %bb55
bb55:
  %t266 = load i64, ptr %l7, !tbaa !24
  %t267 = load i64, ptr %l9, !tbaa !24
  %t270 = sub i64 %t266, %t267
  %t272 = icmp sge i64 %t270, 9
  br i1 %t272, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t275 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t275, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t276 = load i64, ptr %l8, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t277, ptr %l100, !tbaa !27
  %t278 = load i64, ptr %l7, !tbaa !24
  %t280 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr i8, ptr %t281, i64 %t278
  %t283 = load i8, ptr %t282, !tbaa !32
  %t285 = sub i8 %t283, 48
  %t287 = zext i8 %t285 to i64
  %t288 = load i64, ptr %l10, !tbaa !24
  %t291 = mul i64 %t287, %t288
  %t294 = add i64 %t276, %t291
  store i64 %t294, ptr %l8, !tbaa !24
  %t296 = load i64, ptr %l10, !tbaa !24
  %t298 = sdiv i64 %t296, 10
  store i64 %t298, ptr %l10, !tbaa !24
  %t300 = load i64, ptr %l7, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb59:
  br label %bb48
bb60:
  %t304 = load i64, ptr %l7, !tbaa !24
  %t305 = load i64, ptr %l9, !tbaa !24
  %t308 = icmp eq i64 %t304, %t305
  br i1 %t308, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t311 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t311, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t312 = load i64, ptr %l7, !tbaa !24
  %t313 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t318 = icmp sge i64 %t312, %t315
  br i1 %t318, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t321 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t321, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  store i64 0, ptr %l11, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t322, ptr %l121, !tbaa !27
  %t323 = load i64, ptr %l7, !tbaa !24
  %t325 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr i8, ptr %t326, i64 %t323
  %t328 = load i8, ptr %t327, !tbaa !32
  %t330 = icmp eq i8 %t328, 90
  br i1 %t330, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb70
bb69:
  %t332 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t332, ptr %l126, !tbaa !27
  %t333 = load i64, ptr %l7, !tbaa !24
  %t335 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr i8, ptr %t336, i64 %t333
  %t338 = load i8, ptr %t337, !tbaa !32
  %t340 = icmp eq i8 %t338, 122
  store i1 %t340, ptr %l125, !tbaa !21
  br label %bb70
bb70:
  %t342 = load i1, ptr %l125, !tbaa !21
  br i1 %t342, label %bb71, label %bb72
bb71:
  %t343 = load i64, ptr %l7, !tbaa !24
  %t345 = add i64 %t343, 1
  store i64 %t345, ptr %l7, !tbaa !24
  br label %bb97
bb72:
  %t347 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t347, ptr %l132, !tbaa !27
  %t348 = load i64, ptr %l7, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr i8, ptr %t351, i64 %t348
  %t353 = load i8, ptr %t352, !tbaa !32
  %t355 = icmp eq i8 %t353, 43
  br i1 %t355, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb75
bb74:
  %t357 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t357, ptr %l137, !tbaa !27
  %t358 = load i64, ptr %l7, !tbaa !24
  %t360 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr i8, ptr %t361, i64 %t358
  %t363 = load i8, ptr %t362, !tbaa !32
  %t365 = icmp eq i8 %t363, 45
  store i1 %t365, ptr %l136, !tbaa !21
  br label %bb75
bb75:
  %t367 = load i1, ptr %l136, !tbaa !21
  br i1 %t367, label %bb76, label %bb77
bb76:
  %t368 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t369 = load i64, ptr %l7, !tbaa !24
  %t371 = add i64 %t369, 1
  %t374 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t368, i64 %t371, i64 2)
  %t375 = extractvalue { i32, i64 } %t374, 1
  %t376 = extractvalue { i32, i64 } %t374, 0
  store i32 %t376, ptr %l146
  %t377 = icmp ne i32 %t376, 0
  br i1 %t377, label %bb79, label %ok.378
ok.378:
  store i64 %t375, ptr %l145
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t380 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t380, ptr %rv
  br label %ret
bb78:
  %t381 = load i64, ptr %l145, !tbaa !24
  store i64 %t381, ptr %l141, !tbaa !24
  br label %bb80
bb79:
  %t382 = load i32, ptr %l146, !tbaa !23
  %t383 = lshr i32 %t382, 16
  %t384 = and i32 %t382, 65535
  %t385 = icmp eq i32 %t383, 1
  %t386 = select i1 %t385, i32 1, i32 0
  %t387 = icmp eq i32 %t382, 0
  %t388 = shl i32 %t386, 16
  %t389 = or i32 %t388, %t384
  %t390 = select i1 %t387, i32 0, i32 %t389
  call void @__olang_scope_close(ptr %s0)
  %t392 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t390, 0
  store { i32, %"std/time:Date" } %t392, ptr %rv
  br label %ret
bb80:
  %t393 = load i64, ptr %l141, !tbaa !24
  store i64 %t393, ptr %l12, !tbaa !24
  %t394 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t395 = load i64, ptr %l7, !tbaa !24
  %t397 = add i64 %t395, 3
  %t400 = call i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %t394, i64 %t397, i8 58)
  store i32 %t400, ptr %l151
  %t401 = icmp ne i32 %t400, 0
  br i1 %t401, label %bb82, label %ok.402
ok.402:
  br label %bb81
bb81:
  br label %bb83
bb82:
  %t403 = load i32, ptr %l151, !tbaa !23
  %t404 = lshr i32 %t403, 16
  %t405 = and i32 %t403, 65535
  %t406 = icmp eq i32 %t404, 1
  %t407 = select i1 %t406, i32 1, i32 0
  %t408 = icmp eq i32 %t403, 0
  %t409 = shl i32 %t407, 16
  %t410 = or i32 %t409, %t405
  %t411 = select i1 %t408, i32 0, i32 %t410
  call void @__olang_scope_close(ptr %s0)
  %t413 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t411, 0
  store { i32, %"std/time:Date" } %t413, ptr %rv
  br label %ret
bb83:
  %t414 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t415 = load i64, ptr %l7, !tbaa !24
  %t417 = add i64 %t415, 4
  %t420 = call { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %t414, i64 %t417, i64 2)
  %t421 = extractvalue { i32, i64 } %t420, 1
  %t422 = extractvalue { i32, i64 } %t420, 0
  store i32 %t422, ptr %l158
  %t423 = icmp ne i32 %t422, 0
  br i1 %t423, label %bb85, label %ok.424
ok.424:
  store i64 %t421, ptr %l157
  br label %bb84
bb84:
  %t425 = load i64, ptr %l157, !tbaa !24
  store i64 %t425, ptr %l153, !tbaa !24
  br label %bb86
bb85:
  %t426 = load i32, ptr %l158, !tbaa !23
  %t427 = lshr i32 %t426, 16
  %t428 = and i32 %t426, 65535
  %t429 = icmp eq i32 %t427, 1
  %t430 = select i1 %t429, i32 1, i32 0
  %t431 = icmp eq i32 %t426, 0
  %t432 = shl i32 %t430, 16
  %t433 = or i32 %t432, %t428
  %t434 = select i1 %t431, i32 0, i32 %t433
  call void @__olang_scope_close(ptr %s0)
  %t436 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 %t434, 0
  store { i32, %"std/time:Date" } %t436, ptr %rv
  br label %ret
bb86:
  %t437 = load i64, ptr %l153, !tbaa !24
  store i64 %t437, ptr %l13, !tbaa !24
  %t438 = load i64, ptr %l12, !tbaa !24
  %t440 = icmp sgt i64 %t438, 23
  br i1 %t440, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb89
bb88:
  %t442 = load i64, ptr %l13, !tbaa !24
  %t444 = icmp sgt i64 %t442, 59
  store i1 %t444, ptr %l162, !tbaa !21
  br label %bb89
bb89:
  %t446 = load i1, ptr %l162, !tbaa !21
  br i1 %t446, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s0)
  %t448 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65537, 0
  store { i32, %"std/time:Date" } %t448, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  %t449 = load i64, ptr %l12, !tbaa !24
  %t451 = mul i64 %t449, 60
  %t452 = load i64, ptr %l13, !tbaa !24
  %t455 = add i64 %t451, %t452
  store i64 %t455, ptr %l11, !tbaa !24
  %t457 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t457, ptr %l170, !tbaa !27
  %t458 = load i64, ptr %l7, !tbaa !24
  %t460 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr i8, ptr %t461, i64 %t458
  %t463 = load i8, ptr %t462, !tbaa !32
  %t465 = icmp eq i8 %t463, 45
  br i1 %t465, label %bb93, label %bb94
bb93:
  %t467 = load i64, ptr %l11, !tbaa !24
  %t469 = sub i64 0, %t467
  store i64 %t469, ptr %l11, !tbaa !24
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t471 = load i64, ptr %l7, !tbaa !24
  %t473 = add i64 %t471, 6
  store i64 %t473, ptr %l7, !tbaa !24
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t475 = load i64, ptr %l7, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t476, 0
  %t481 = icmp ne i64 %t475, %t478
  br i1 %t481, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s0)
  %t484 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65536, 0
  store { i32, %"std/time:Date" } %t484, ptr %rv
  br label %ret
bb99:
  br label %bb100
bb100:
  %t485 = load i64, ptr %l2, !tbaa !24
  %t487 = icmp slt i64 %t485, 1
  br i1 %t487, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb103
bb102:
  %t489 = load i64, ptr %l2, !tbaa !24
  %t491 = icmp sgt i64 %t489, 12
  store i1 %t491, ptr %l186, !tbaa !21
  br label %bb103
bb103:
  %t493 = load i1, ptr %l186, !tbaa !21
  br i1 %t493, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb106
bb105:
  %t494 = load i64, ptr %l3, !tbaa !24
  %t496 = icmp slt i64 %t494, 1
  store i1 %t496, ptr %l189, !tbaa !21
  br label %bb106
bb106:
  %t498 = load i1, ptr %l189, !tbaa !21
  br i1 %t498, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb110
bb108:
  %t499 = load i64, ptr %l3, !tbaa !24
  store i64 %t499, ptr %l193, !tbaa !24
  %t500 = load i64, ptr %l1, !tbaa !24
  %t501 = load i64, ptr %l2, !tbaa !24
  %t504 = call i64 @std_2ftime_2edaysIn(i64 %t500, i64 %t501)
  store i64 %t504, ptr %l196
  br label %bb109
bb109:
  %t505 = load i64, ptr %l193, !tbaa !24
  %t506 = load i64, ptr %l196, !tbaa !24
  %t507 = icmp sgt i64 %t505, %t506
  store i1 %t507, ptr %l192, !tbaa !21
  br label %bb110
bb110:
  %t509 = load i1, ptr %l192, !tbaa !21
  br i1 %t509, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb113
bb112:
  %t510 = load i64, ptr %l4, !tbaa !24
  %t512 = icmp sgt i64 %t510, 23
  store i1 %t512, ptr %l198, !tbaa !21
  br label %bb113
bb113:
  %t514 = load i1, ptr %l198, !tbaa !21
  br i1 %t514, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb116
bb115:
  %t515 = load i64, ptr %l5, !tbaa !24
  %t517 = icmp sgt i64 %t515, 59
  store i1 %t517, ptr %l201, !tbaa !21
  br label %bb116
bb116:
  %t519 = load i1, ptr %l201, !tbaa !21
  br i1 %t519, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb119
bb118:
  %t520 = load i64, ptr %l6, !tbaa !24
  %t522 = icmp sgt i64 %t520, 59
  store i1 %t522, ptr %l204, !tbaa !21
  br label %bb119
bb119:
  %t524 = load i1, ptr %l204, !tbaa !21
  br i1 %t524, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s0)
  %t526 = insertvalue { i32, %"std/time:Date" } zeroinitializer, i32 65537, 0
  store { i32, %"std/time:Date" } %t526, ptr %rv
  br label %ret
bb121:
  br label %bb122
bb122:
  %t527 = load i64, ptr %l1, !tbaa !24
  %t528 = load i64, ptr %l2, !tbaa !24
  %t529 = load i64, ptr %l3, !tbaa !24
  %t530 = load i64, ptr %l4, !tbaa !24
  %t531 = load i64, ptr %l5, !tbaa !24
  %t532 = load i64, ptr %l6, !tbaa !24
  %t533 = load i64, ptr %l8, !tbaa !24
  %t534 = load i64, ptr %l11, !tbaa !24
  %t543 = call %"std/time:Date" @std_2ftime_3aDate_2ector(ptr %s0, i64 %t527, i64 %t528, i64 %t529, i64 %t530, i64 %t531, i64 %t532, i64 %t533, i64 %t534)
  store %"std/time:Date" %t543, ptr %l216
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s0)
  %t544 = load %"std/time:Date", ptr %l216
  %t545 = insertvalue { i32, %"std/time:Date" } zeroinitializer, %"std/time:Date" %t544, 1
  store { i32, %"std/time:Date" } %t545, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/time:Date" }, ptr %rv
  ret { i32, %"std/time:Date" } %rr
}

define dso_local i64 @std_2ftime_2eSeconds(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 1000000000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eSince(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l1
  br label %bb1
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t3, %a0
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2ftime_2eSleep(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca [2 x i64]
  %l2 = alloca [2 x i64]
  %l19 = alloca i32
  %s2 = alloca %olang.scope
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t8 = sdiv i64 %t5, 1000000000
  %t9 = load i64, ptr %l0, !tbaa !24
  %t12 = srem i64 %t9, 1000000000
  %t14 = insertvalue [2 x i64] undef, i64 %t8, 0
  %t16 = insertvalue [2 x i64] %t14, i64 %t12, 1
  store [2 x i64] %t16, ptr %l1
  %t18 = insertvalue [2 x i64] undef, i64 0, 0
  %t19 = insertvalue [2 x i64] %t18, i64 0, 1
  store [2 x i64] %t19, ptr %l2
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = insertvalue { i64, ptr } undef, i64 2, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %l1, 1
  %t26 = insertvalue { i64, ptr } undef, i64 2, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %l2, 1
  %t30 = extractvalue { i64, ptr } %t23, 1
  %t31 = extractvalue { i64, ptr } %t23, 0
  %t33 = extractvalue { i64, ptr } %t27, 1
  %t34 = extractvalue { i64, ptr } %t27, 0
  %t35 = call i32 @nanosleep(ptr %t30, ptr %t33)
  store i32 %t35, ptr %l19
  br label %bb5
bb5:
  %t36 = load i32, ptr %l19, !tbaa !23
  %t37 = icmp ne i32 %t36, 0
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t41 = getelementptr [2 x i64], ptr %l2, i64 0, i64 0
  %t42 = load i64, ptr %t41, !tbaa !34
  %t44 = getelementptr [2 x i64], ptr %l1, i64 0, i64 0
  store i64 %t42, ptr %t44, !tbaa !34
  %t45 = getelementptr [2 x i64], ptr %l2, i64 0, i64 1
  %t46 = load i64, ptr %t45, !tbaa !34
  %t48 = getelementptr [2 x i64], ptr %l1, i64 0, i64 1
  store i64 %t46, ptr %t48, !tbaa !34
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2ftime_2eWall() #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2estd_2ftime_2eclockRealtime, !tbaa !23
  %t3 = call i64 @std_2ftime_2eread(i32 %t1)
  store i64 %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2ftime_2eclockMonotonic_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2estd_2ftime_2eclockMonotonic, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @std_2ftime_2eclockRealtime_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2estd_2ftime_2eclockRealtime, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2ftime_2edaysFromCivil(i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i64
  %l28 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sle i64 %t1, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = sub i64 %t5, 1
  store i64 %t7, ptr %l11, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  store i64 %t9, ptr %l11, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l11, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = sub i64 %t18, 399
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = sdiv i64 %t22, 400
  store i64 %t23, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = mul i64 %t26, 400
  %t31 = sub i64 %t25, %t28
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp sgt i64 %t33, 2
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = sub i64 %t37, 3
  store i64 %t39, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = add i64 %t41, 9
  store i64 %t43, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t48 = mul i64 153, %t45
  %t50 = add i64 %t48, 2
  %t52 = sdiv i64 %t50, 5
  %t56 = add i64 %t52, %a2
  %t58 = sub i64 %t56, 1
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = mul i64 %t60, 365
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = sdiv i64 %t63, 4
  %t68 = add i64 %t62, %t65
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = sdiv i64 %t69, 100
  %t74 = sub i64 %t68, %t71
  %t78 = add i64 %t74, %t58
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = mul i64 %t80, 146097
  %t86 = add i64 %t82, %t78
  %t88 = sub i64 %t86, 719468
  store i64 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2edaysIn(i64 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i64
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t7 = call i1 @std_2ftime_2eisLeap(i64 %a0)
  store i1 %t7, ptr %l5
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  store i64 29, ptr %l6, !tbaa !24
  br label %bb6
bb5:
  store i64 28, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb7:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp eq i64 %t10, 4
  br i1 %t12, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = icmp eq i64 %t14, 6
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb10
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb13
bb12:
  %t19 = load i64, ptr %l1, !tbaa !24
  %t21 = icmp eq i64 %t19, 9
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb13
bb13:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb16
bb15:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp eq i64 %t24, 11
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb16
bb16:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb17, label %bb18
bb17:
  store i64 30, ptr %l18, !tbaa !24
  br label %bb19
bb18:
  store i64 31, ptr %l18, !tbaa !24
  br label %bb19
bb19:
  %t29 = load i64, ptr %l18, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @std_2ftime_2edigitsAt(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i8
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca { i64, ptr }
  %l49 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = add i64 %t1, %t2
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp sgt i64 %t5, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb6:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l25, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l22, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l43, !tbaa !27
  %t64 = load i64, ptr %l1, !tbaa !24
  %t68 = add i64 %t64, %t61
  %t70 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i8, ptr %t71, i64 %t68
  %t73 = load i8, ptr %t72, !tbaa !32
  store i8 %t73, ptr %l10, !tbaa !22
  %t75 = load i8, ptr %l10, !tbaa !22
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t75)
  store i1 %t77, ptr %l49
  br label %bb14
bb14:
  %t78 = load i1, ptr %l49, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  %t82 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t82, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t83 = load i64, ptr %l3, !tbaa !24
  %t85 = mul i64 %t83, 10
  %t86 = load i8, ptr %l10, !tbaa !22
  %t88 = sub i8 %t86, 48
  %t90 = zext i8 %t88 to i64
  %t93 = add i64 %t85, %t90
  store i64 %t93, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l8, !tbaa !24
  br label %bb10
bb19:
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = insertvalue { i32, i64 } zeroinitializer, i64 %t99, 1
  store { i32, i64 } %t101, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @std_2ftime_2eexpect(ptr %v0, { i64, ptr } %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp sge i64 %t1, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t19 = icmp ne i8 %t15, %a2
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i32 65536, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2ftime_2efraction(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i1
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !65
  %t2 = load i64, ptr %l1, !tbaa !65
  %t5 = udiv i64 %t1, %t2
  store i64 %t5, ptr %l2, !tbaa !65
  %t7 = load i64, ptr %l0, !tbaa !65
  %t8 = load i64, ptr %l1, !tbaa !65
  %t11 = urem i64 %t7, %t8
  store i64 %t11, ptr %l3, !tbaa !65
  %t13 = load i64, ptr %l3, !tbaa !65
  %t15 = icmp eq i64 %t13, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i64, ptr %l2, !tbaa !65
  %t19 = call i64 @__olang_fmt_u64(ptr null, i64 %t17)
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  %t21 = call i64 @__olang_fmt_u64(ptr %t20, i64 %t17)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t25 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t26, ptr %l4
  %t27 = load i64, ptr %l1, !tbaa !65
  %t29 = udiv i64 %t27, 10
  store i64 %t29, ptr %l5, !tbaa !65
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i64, ptr %l5, !tbaa !65
  %t33 = icmp ugt i64 %t31, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l3, !tbaa !65
  %t37 = icmp ugt i64 %t35, 0
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l21, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t42 = zext i8 48 to i64
  %t43 = load i64, ptr %l3, !tbaa !65
  %t44 = load i64, ptr %l5, !tbaa !65
  %t47 = udiv i64 %t43, %t44
  %t50 = add i64 %t42, %t47
  %t52 = trunc i64 %t50 to i8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 %t52)
  br label %bb12
bb12:
  %t55 = load i64, ptr %l3, !tbaa !65
  %t56 = load i64, ptr %l5, !tbaa !65
  %t59 = urem i64 %t55, %t56
  store i64 %t59, ptr %l3, !tbaa !65
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t61 = load i64, ptr %l5, !tbaa !65
  %t63 = udiv i64 %t61, 10
  store i64 %t63, ptr %l5, !tbaa !65
  br label %bb5
bb14:
  %t65 = load i64, ptr %l2, !tbaa !65
  store i64 %t65, ptr %l37, !tbaa !65
  %t67 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t67, ptr %l39
  br label %bb15
bb15:
  %t68 = load i64, ptr %l37, !tbaa !65
  %t69 = call i64 @__olang_fmt_u64(ptr null, i64 %t68)
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = add i64 %t72, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t76)
  %t78 = call i64 @__olang_fmt_u64(ptr %t77, i64 %t68)
  %t79 = getelementptr i8, ptr %t77, i64 %t69
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t80, ptr %t74, i64 %t75)
  %t81 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t77, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @std_2ftime_2eisLeap(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = srem i64 %t1, 4
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l0, !tbaa !24
  %t9 = srem i64 %t7, 100
  %t11 = icmp ne i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb6
bb3:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i64, ptr %l0, !tbaa !24
  %t15 = srem i64 %t13, 400
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l8, !tbaa !21
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l4, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2ftime_2eread(i32 %a0) #0 {
entry:
  %l1 = alloca [2 x i64]
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i64] undef, i64 0, 0
  %t2 = insertvalue [2 x i64] %t1, i64 0, 1
  store [2 x i64] %t2, ptr %l1
  %t6 = insertvalue { i64, ptr } undef, i64 2, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %l1, 1
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = call i32 @clock_gettime(i32 %a0, ptr %t11)
  store i32 %t13, ptr %l7
  br label %bb1
bb1:
  %t14 = getelementptr [2 x i64], ptr %l1, i64 0, i64 0
  %t15 = load i64, ptr %t14, !tbaa !34
  %t17 = mul i64 %t15, 1000000000
  %t18 = getelementptr [2 x i64], ptr %l1, i64 0, i64 1
  %t19 = load i64, ptr %t18, !tbaa !34
  %t22 = add i64 %t17, %t19
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @std_2ftime_2estd_2ftime_3aDate_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca i64
  %l62 = alloca i64
  %l68 = alloca ptr
  %l72 = alloca i8
  %l73 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l6, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/time:Date", ptr %t3, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  %t8 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %s0, i64 %t6, i64 4, i8 48)
  store { i64, ptr } %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = mul i64 %t10, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @llvm.memcpy.p0.p0.i64(ptr %t13, ptr %t11, i64 %t12, i1 false)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t16 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t16, { i64, ptr } %t15)
  br label %bb3
bb3:
  store ptr %l1, ptr %l11, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/time:Date", ptr %t18, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t21)
  store { i64, ptr } %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/time:Date", ptr %t24, i32 0, i32 2
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t27)
  store { i64, ptr } %t29, ptr %l17
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"std/time:Date", ptr %t30, i32 0, i32 3
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t33)
  store { i64, ptr } %t35, ptr %l20
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/time:Date", ptr %t36, i32 0, i32 4
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t39)
  store { i64, ptr } %t41, ptr %l23
  br label %bb7
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"std/time:Date", ptr %t42, i32 0, i32 5
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s0, i64 %t45)
  store { i64, ptr } %t47, ptr %l26
  br label %bb8
bb8:
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t50 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t48, i64 %t49)
  %t83 = getelementptr i8, ptr %t82, i64 %t49
  call void @olang_textcopy(ptr %t83, ptr %t51, i64 %t52)
  %t84 = getelementptr i8, ptr %t83, i64 %t52
  call void @olang_textcopy(ptr %t84, ptr %t54, i64 %t55)
  %t85 = getelementptr i8, ptr %t84, i64 %t55
  call void @olang_textcopy(ptr %t85, ptr %t58, i64 %t59)
  %t86 = getelementptr i8, ptr %t85, i64 %t59
  call void @olang_textcopy(ptr %t86, ptr %t61, i64 %t62)
  %t87 = getelementptr i8, ptr %t86, i64 %t62
  call void @olang_textcopy(ptr %t87, ptr %t65, i64 %t66)
  %t88 = getelementptr i8, ptr %t87, i64 %t66
  call void @olang_textcopy(ptr %t88, ptr %t68, i64 %t69)
  %t89 = getelementptr i8, ptr %t88, i64 %t69
  call void @olang_textcopy(ptr %t89, ptr %t72, i64 %t73)
  %t90 = getelementptr i8, ptr %t89, i64 %t73
  call void @olang_textcopy(ptr %t90, ptr %t75, i64 %t76)
  %t91 = getelementptr i8, ptr %t90, i64 %t76
  call void @olang_textcopy(ptr %t91, ptr %t79, i64 %t80)
  %t92 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t82, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t101, { i64, ptr } %t100)
  br label %bb9
bb9:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"std/time:Date", ptr %t103, i32 0, i32 6
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = icmp ne i64 %t106, 0
  br i1 %t108, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 46)
  br label %bb12
bb11:
  br label %bb30
bb12:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"std/time:Date", ptr %t111, i32 0, i32 6
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %s2, i64 %t114, i64 9, i8 48)
  store { i64, ptr } %t116, ptr %l35
  br label %bb13
bb13:
  %t117 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t117, ptr %l2, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  store i64 %t120, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t122 = load i64, ptr %l3, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb15, label %bb16
bb15:
  %t126 = load i64, ptr %l3, !tbaa !24
  %t128 = sub i64 %t126, 1
  %t130 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i8, ptr %t131, i64 %t128
  %t133 = load i8, ptr %t132, !tbaa !32
  %t135 = icmp eq i8 %t133, 48
  store i1 %t135, ptr %l40, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t137 = load i1, ptr %l40, !tbaa !21
  %t138 = xor i1 %t137, true
  br i1 %t138, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t140 = load i64, ptr %l3, !tbaa !24
  %t142 = sub i64 %t140, 1
  store i64 %t142, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  br label %bb14
bb22:
  store ptr %l1, ptr %l48, !tbaa !29
  %t144 = load i64, ptr %l3, !tbaa !24
  store i64 %t144, ptr %l49, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l50, !tbaa !24
  %t147 = icmp sge i64 0, 0
  br i1 %t147, label %bb23, label %bb24
bb23:
  %t149 = load i64, ptr %l49, !tbaa !24
  %t150 = icmp sle i64 0, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f63687bbaea10838_93db7057d6025df4)
  unreachable
bb25:
  %t152 = load i64, ptr %l49, !tbaa !24
  %t153 = load i64, ptr %l50, !tbaa !24
  %t154 = icmp sle i64 %t152, %t153
  br i1 %t154, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f63687bbaea10838_93db7057d6025df4)
  unreachable
bb27:
  %t156 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l49, !tbaa !24
  %t159 = getelementptr i8, ptr %t157, i64 0
  %t160 = sub i64 %t158, 0
  %t161 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t159, 1
  %t163 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t163, { i64, ptr } %t162)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f63687bbaea10838_93db7057d6025df4)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"std/time:Date", ptr %t165, i32 0, i32 7
  %t168 = load i64, ptr %t167, !tbaa !24
  %t170 = icmp eq i64 %t168, 0
  br i1 %t170, label %bb31, label %bb32
bb31:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 90)
  br label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"std/time:Date", ptr %t173, i32 0, i32 7
  %t176 = load i64, ptr %t175, !tbaa !24
  %t178 = icmp sgt i64 %t176, 0
  br i1 %t178, label %bb34, label %bb35
bb33:
  br label %bb44
bb34:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"std/time:Date", ptr %t180, i32 0, i32 7
  %t183 = load i64, ptr %t182, !tbaa !24
  store i64 %t183, ptr %l62, !tbaa !24
  br label %bb36
bb35:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"std/time:Date", ptr %t185, i32 0, i32 7
  %t188 = load i64, ptr %t187, !tbaa !24
  %t190 = sub i64 0, %t188
  store i64 %t190, ptr %l62, !tbaa !24
  br label %bb36
bb36:
  %t192 = load i64, ptr %l62, !tbaa !24
  store i64 %t192, ptr %l4, !tbaa !24
  store ptr %l1, ptr %l68, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"std/time:Date", ptr %t193, i32 0, i32 7
  %t196 = load i64, ptr %t195, !tbaa !24
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb37, label %bb38
bb37:
  store i8 43, ptr %l72, !tbaa !22
  br label %bb39
bb38:
  store i8 45, ptr %l72, !tbaa !22
  br label %bb39
bb39:
  %t200 = load ptr, ptr %l68, !tbaa !29
  %t201 = load i8, ptr %l72, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t200, i8 %t201)
  br label %bb40
bb40:
  store ptr %l1, ptr %l73, !tbaa !29
  %t202 = load i64, ptr %l4, !tbaa !24
  %t204 = sdiv i64 %t202, 60
  %t206 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s5, i64 %t204)
  store { i64, ptr } %t206, ptr %l76
  br label %bb41
bb41:
  %t207 = load i64, ptr %l4, !tbaa !24
  %t209 = srem i64 %t207, 60
  %t211 = call { i64, ptr } @std_2ftime_2etwoDigits(ptr %s5, i64 %t209)
  store { i64, ptr } %t211, ptr %l79
  br label %bb42
bb42:
  %t212 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t213, i64 %t214)
  %t223 = getelementptr i8, ptr %t222, i64 %t214
  call void @olang_textcopy(ptr %t223, ptr %t215, i64 %t216)
  %t224 = getelementptr i8, ptr %t223, i64 %t216
  call void @olang_textcopy(ptr %t224, ptr %t219, i64 %t220)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t222, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  %t234 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t234, { i64, ptr } %t233)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  %t237 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t237, ptr %l83
  br label %bb45
bb45:
  %t238 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t238, ptr %l84, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  store i64 %t240, ptr %l85, !tbaa !24
  %t241 = load i64, ptr %l85, !tbaa !24
  %t242 = mul i64 %t241, 1
  %t243 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t242)
  %t244 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  store { i64, ptr } %t245, ptr %l86, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = load i64, ptr %l85, !tbaa !24
  %t251 = mul i64 %t250, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t247, ptr %t249, i64 %t251, i1 false)
  %t252 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t252, ptr %l84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t253 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t253, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDate_2eWall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/time:Date", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/time:Date", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/time:Date", ptr %t9, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t16 = call i64 @std_2ftime_2edaysFromCivil(i64 %t4, i64 %t8, i64 %t12)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t20 = mul i64 %t17, 86400
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/time:Date", ptr %t21, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = mul i64 %t24, 3600
  %t29 = add i64 %t20, %t26
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"std/time:Date", ptr %t30, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = mul i64 %t33, 60
  %t38 = add i64 %t29, %t35
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"std/time:Date", ptr %t39, i32 0, i32 5
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = add i64 %t38, %t42
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/time:Date", ptr %t46, i32 0, i32 7
  %t49 = load i64, ptr %t48, !tbaa !24
  %t51 = mul i64 %t49, 60
  %t54 = sub i64 %t45, %t51
  %t58 = mul i64 %t54, 1000000000
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/time:Date", ptr %t59, i32 0, i32 6
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = add i64 %t58, %t62
  store i64 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDate_2eWeekday(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/time:Date", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/time:Date", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/time:Date", ptr %t9, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t16 = call i64 @std_2ftime_2edaysFromCivil(i64 %t4, i64 %t8, i64 %t12)
  store i64 %t16, ptr %l8
  br label %bb1
bb1:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = add i64 %t17, 4
  %t20 = srem i64 %t18, 7
  store i64 %t20, ptr %l1, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = add i64 %t26, 7
  store i64 %t28, ptr %l13, !tbaa !24
  br label %bb4
bb3:
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDate_2eYearDay(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/time:Date", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/time:Date", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/time:Date", ptr %t9, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t16 = call i64 @std_2ftime_2edaysFromCivil(i64 %t4, i64 %t8, i64 %t12)
  store i64 %t16, ptr %l7
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/time:Date", ptr %t17, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = call i64 @std_2ftime_2edaysFromCivil(i64 %t20, i64 1, i64 1)
  store i64 %t22, ptr %l10
  br label %bb2
bb2:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = sub i64 %t23, %t24
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDuration_2eMicros(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t4 = sdiv i64 %a0, 1000
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDuration_2eMillis(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t4 = sdiv i64 %a0, 1000000
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDuration_2eNanos(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local double @std_2ftime_2estd_2ftime_3aDuration_2eSeconds(i64 %a0) #0 {
entry:
  %rv = alloca double
  br label %start
start:
  br label %bb0
bb0:
  %t4 = sitofp i64 %a0 to double
  %t6 = fdiv double %t4, 0x41cdcd6500000000
  store double %t6, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local { i64, ptr } @std_2ftime_2estd_2ftime_3aDuration_2eStr(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l1, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t8, ptr %l12, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l13, !tbaa !24
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t28, ptr %l2, !tbaa !27
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = sub i64 0, %t33
  store i64 %t35, ptr %l20, !tbaa !65
  br label %bb9
bb8:
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l20, !tbaa !65
  br label %bb9
bb9:
  %t41 = load i64, ptr %l20, !tbaa !65
  store i64 %t41, ptr %l3, !tbaa !65
  %t42 = load i64, ptr %l3, !tbaa !65
  %t44 = icmp ult i64 %t42, 1000
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = load i64, ptr %l3, !tbaa !65
  %t49 = extractvalue { i64, ptr } %t46, 1
  %t50 = extractvalue { i64, ptr } %t46, 0
  %t52 = call i64 @__olang_fmt_u64(ptr null, i64 %t47)
  %t53 = add i64 %t50, %t52
  %t54 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  %t59 = call i64 @__olang_fmt_u64(ptr %t58, i64 %t47)
  %t60 = getelementptr i8, ptr %t58, i64 %t52
  call void @olang_textcopy(ptr %t60, ptr %t54, i64 %t55)
  %t61 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t64 = load i64, ptr %l3, !tbaa !65
  %t66 = icmp ult i64 %t64, 1000000
  br i1 %t66, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l33, !tbaa !27
  %t69 = load i64, ptr %l3, !tbaa !65
  %t71 = call { i64, ptr } @std_2ftime_2efraction(ptr %s4, i64 %t69, i64 1000)
  store { i64, ptr } %t71, ptr %l35
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t72 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb16:
  %t88 = load i64, ptr %l3, !tbaa !65
  %t90 = icmp ult i64 %t88, 1000000000
  br i1 %t90, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l39, !tbaa !27
  %t93 = load i64, ptr %l3, !tbaa !65
  %t95 = call { i64, ptr } @std_2ftime_2efraction(ptr %s6, i64 %t93, i64 1000000)
  store { i64, ptr } %t95, ptr %l41
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t96 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = add i64 %t98, %t101
  %t103 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t97, i64 %t98)
  %t107 = getelementptr i8, ptr %t106, i64 %t98
  call void @olang_textcopy(ptr %t107, ptr %t100, i64 %t101)
  %t108 = getelementptr i8, ptr %t107, i64 %t101
  call void @olang_textcopy(ptr %t108, ptr %t103, i64 %t104)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t106, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb20:
  %t112 = load i64, ptr %l3, !tbaa !65
  %t114 = udiv i64 %t112, 3600000000000
  store i64 %t114, ptr %l4, !tbaa !65
  %t116 = load i64, ptr %l3, !tbaa !65
  %t118 = udiv i64 %t116, 60000000000
  %t120 = urem i64 %t118, 60
  store i64 %t120, ptr %l5, !tbaa !65
  %t122 = load i64, ptr %l3, !tbaa !65
  %t124 = urem i64 %t122, 60000000000
  %t126 = call { i64, ptr } @std_2ftime_2efraction(ptr %s0, i64 %t124, i64 1000000000)
  store { i64, ptr } %t126, ptr %l50
  br label %bb21
bb21:
  %t127 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t127, ptr %l6, !tbaa !27
  %t128 = load i64, ptr %l4, !tbaa !65
  %t130 = icmp ugt i64 %t128, 0
  br i1 %t130, label %bb22, label %bb23
bb22:
  %t132 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t133 = load i64, ptr %l4, !tbaa !65
  %t134 = load i64, ptr %l5, !tbaa !65
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t132, 1
  %t138 = extractvalue { i64, ptr } %t132, 0
  %t140 = call i64 @__olang_fmt_u64(ptr null, i64 %t133)
  %t141 = add i64 %t138, %t140
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = call i64 @__olang_fmt_u64(ptr null, i64 %t134)
  %t147 = add i64 %t144, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t152 = extractvalue { i64, ptr } %t135, 1
  %t153 = extractvalue { i64, ptr } %t135, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t137, i64 %t138)
  %t159 = getelementptr i8, ptr %t158, i64 %t138
  %t160 = call i64 @__olang_fmt_u64(ptr %t159, i64 %t133)
  %t161 = getelementptr i8, ptr %t159, i64 %t140
  call void @olang_textcopy(ptr %t161, ptr %t142, i64 %t143)
  %t162 = getelementptr i8, ptr %t161, i64 %t143
  %t163 = call i64 @__olang_fmt_u64(ptr %t162, i64 %t134)
  %t164 = getelementptr i8, ptr %t162, i64 %t146
  call void @olang_textcopy(ptr %t164, ptr %t148, i64 %t149)
  %t165 = getelementptr i8, ptr %t164, i64 %t149
  call void @olang_textcopy(ptr %t165, ptr %t152, i64 %t153)
  %t166 = getelementptr i8, ptr %t165, i64 %t153
  call void @olang_textcopy(ptr %t166, ptr %t155, i64 %t156)
  %t167 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t158, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t168, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t170 = load i64, ptr %l5, !tbaa !65
  %t172 = icmp ugt i64 %t170, 0
  br i1 %t172, label %bb25, label %bb26
bb25:
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t175 = load i64, ptr %l5, !tbaa !65
  %t176 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t174, 1
  %t179 = extractvalue { i64, ptr } %t174, 0
  %t181 = call i64 @__olang_fmt_u64(ptr null, i64 %t175)
  %t182 = add i64 %t179, %t181
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t187 = extractvalue { i64, ptr } %t176, 1
  %t188 = extractvalue { i64, ptr } %t176, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t178, i64 %t179)
  %t194 = getelementptr i8, ptr %t193, i64 %t179
  %t195 = call i64 @__olang_fmt_u64(ptr %t194, i64 %t175)
  %t196 = getelementptr i8, ptr %t194, i64 %t181
  call void @olang_textcopy(ptr %t196, ptr %t183, i64 %t184)
  %t197 = getelementptr i8, ptr %t196, i64 %t184
  call void @olang_textcopy(ptr %t197, ptr %t187, i64 %t188)
  %t198 = getelementptr i8, ptr %t197, i64 %t188
  call void @olang_textcopy(ptr %t198, ptr %t190, i64 %t191)
  %t199 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t193, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t200, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t202 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = extractvalue { i64, ptr } %t202, 0
  %t208 = extractvalue { i64, ptr } %t203, 1
  %t209 = extractvalue { i64, ptr } %t203, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = getelementptr i8, ptr %t214, i64 %t206
  call void @olang_textcopy(ptr %t215, ptr %t208, i64 %t209)
  %t216 = getelementptr i8, ptr %t215, i64 %t209
  call void @olang_textcopy(ptr %t216, ptr %t211, i64 %t212)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t214, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t218, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2ftime_2etwoDigits(ptr %v0, i64 %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %v0, i64 %a0, i64 2, i8 48)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t4, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/time:Date" @std_2ftime_3aDate_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7) #0 {
entry:
  %rv = alloca %"std/time:Date"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"std/time:Date" undef, i64 %a0, 0
  %t20 = insertvalue %"std/time:Date" %t18, i64 %a1, 1
  %t22 = insertvalue %"std/time:Date" %t20, i64 %a2, 2
  %t24 = insertvalue %"std/time:Date" %t22, i64 %a3, 3
  %t26 = insertvalue %"std/time:Date" %t24, i64 %a4, 4
  %t28 = insertvalue %"std/time:Date" %t26, i64 %a5, 5
  %t30 = insertvalue %"std/time:Date" %t28, i64 %a6, 6
  %t32 = insertvalue %"std/time:Date" %t30, i64 %a7, 7
  store %"std/time:Date" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"std/time:Date", ptr %rv
  ret %"std/time:Date" %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare i32 @nanosleep(ptr, ptr)
declare i64 @__olang_fmt_u64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i32 @clock_gettime(i32, ptr)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"T" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare void @__olang_check_failed(ptr)
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0s" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ns" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"us" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ms" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"h" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %v0, i64 %a0, i64 %a1, i8 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_f63687bbaea10838_93db7057d6025df4 = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
