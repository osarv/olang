; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/time:Date" = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%"<fcntl.h>:timespec" = type { i64, i64 }
%"std/time:Timer" = type { i64 }
@G_2estd_2ftime_2eBillion = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\14\00\00\00\00\00\00\00", ptr @G_2estd_2ftime_2eBillion.k1 }>, align 8
@G_2estd_2ftime_2eBillion.k1 = internal global <{ [20 x i8] }> <{ [20 x i8] c"\32\30\30\31\2D\30\39\2D\30\39\54\30\31\3A\34\36\3A\34\30\5A" }>, align 8
@G_2estd_2ftime_2eEpochText = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\14\00\00\00\00\00\00\00", ptr @G_2estd_2ftime_2eEpochText.k1 }>, align 8
@G_2estd_2ftime_2eEpochText.k1 = internal global <{ [20 x i8] }> <{ [20 x i8] c"\31\39\37\30\2D\30\31\2D\30\31\54\30\30\3A\30\30\3A\30\30\5A" }>, align 8
@G_2estd_2ftime_2eVirtualStart = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\43\52\CF\4C\23\0D" }>, align 8
@G_2estd_2ftime_2eWhyBaked = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\15\00\00\00\00\00\00\00", ptr @G_2estd_2ftime_2eWhyBaked.k1 }>, align 8
@G_2estd_2ftime_2eWhyBaked.k1 = internal global <{ [21 x i8] }> <{ [21 x i8] c"\74\69\6D\65\2E\45\72\72\6F\72\2E\53\79\6E\74\61\78\28\32\32\29" }>, align 8
@G_2estd_2ftime_2eclockMonotonic = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2ftime_2eclockRealtime = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2estd_2ftime_2evirtualDepth = global <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2estd_2ftime_2evirtualNs = global <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
define dso_local %"std/time:Date" @std_2ftime_2eDate_2eLocal(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca %"std/time:Date"
  %rv = alloca %"std/time:Date"
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l0, !tbaa !24
  %t4 = call i64 @std_2ftime_2eLocalOffset(i64 %t2)
  store i64 %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = sdiv i64 %t5, 60
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = call %"std/time:Date" @std_2ftime_2eDate_2eOf(i64 %t7, i64 %t6)
  store %"std/time:Date" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/time:Date", ptr %l5
  store %"std/time:Date" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"std/time:Date", ptr %rv
  ret %"std/time:Date" %rr
}

define dso_local i64 @std_2ftime_2eDuration_2eElapsed(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l1
  br label %bb1
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t3, %a0
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eDuration_2eHours(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 3600000000000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eDuration_2eMicros(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 1000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eDuration_2eMillis(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 1000000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eDuration_2eMinutes(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 60000000000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eDuration_2eNanos(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eDuration_2eSeconds(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 1000000000
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @std_2ftime_2eFormat(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l4 = alloca %"std/time:Date"
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call %"std/time:Date" @std_2ftime_2eDate_2eOf(i64 %a0, i64 %a1)
  store %"std/time:Date" %t5, ptr %l4
  br label %bb1
bb1:
  %t7 = call { i64, ptr } @std_2ftime_2estd_2ftime_3aDate_2eStr(ptr %s0, ptr %v0, ptr %l4)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @std_2ftime_2eIsVirtual() #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2ftime_2eLocalOffset(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca [1 x i64]
  %l15 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = sdiv i64 %t1, 1000000000
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = srem i64 %t5, 1000000000
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = sub i64 %t11, 1
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t16 = insertvalue [1 x i64] undef, i64 0, 0
  store [1 x i64] %t16, ptr %l2
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = getelementptr [1 x i64], ptr %l2, i64 0, i64 0
  store i64 %t18, ptr %t20, !tbaa !34
  %t22 = insertvalue { i64, ptr } undef, i64 1, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %l2, 1
  %t25 = call i64 @std_2ftime_2eoffsetOf(ptr %s0, { i64, ptr } %t23)
  store i64 %t25, ptr %l15
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i64, ptr %l15, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eNow() #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2estd_2ftime_2eclockMonotonic, !tbaa !23
  %t3 = call i64 @std_2ftime_2eread(i32 %t1)
  store i64 %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2ftime_2eReach(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = xor i1 false, true
  br i1 %t1, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  br label %bb4
bb4:
  %t4 = load atomic i64, ptr @G_2estd_2ftime_2evirtualNs seq_cst, align 8
  store i64 %t4, ptr %l1, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l0, !tbaa !24
  %t10 = icmp sge i64 %t6, %t7
  br i1 %t10, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb7
bb6:
  %t13 = load atomic i64, ptr @G_2estd_2ftime_2evirtualDepth seq_cst, align 8
  %t15 = icmp eq i64 %t13, 0
  store i1 %t15, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load i64, ptr %l0, !tbaa !24
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l13, !tbaa !24
  %t24 = cmpxchg ptr @G_2estd_2ftime_2evirtualNs, i64 %t22, i64 %t19 seq_cst seq_cst
  %t25 = extractvalue { i64, i1 } %t24, 0
  %t26 = load i64, ptr %l1, !tbaa !24
  %t29 = icmp eq i64 %t25, %t26
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb4
ret:
  ret void
}

define dso_local i64 @std_2ftime_2eSince(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l1
  br label %bb1
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t3, %a0
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2ftime_2eSleep(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca %"<fcntl.h>:timespec"
  %l2 = alloca %"<fcntl.h>:timespec"
  %l5 = alloca %"<fcntl.h>:timespec"
  %l14 = alloca %"<fcntl.h>:timespec"
  %l17 = alloca i32
  %s0 = alloca %olang.scope
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = call %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %s0)
  store %"<fcntl.h>:timespec" %t5, ptr %l5
  br label %bb4
bb4:
  %t6 = load %"<fcntl.h>:timespec", ptr %l5
  store %"<fcntl.h>:timespec" %t6, ptr %l1
  %t7 = load i64, ptr %l0, !tbaa !24
  %t10 = sdiv i64 %t7, 1000000000
  %t12 = getelementptr %"<fcntl.h>:timespec", ptr %l1, i32 0, i32 0
  store i64 %t10, ptr %t12, !tbaa !24
  %t13 = load i64, ptr %l0, !tbaa !24
  %t16 = srem i64 %t13, 1000000000
  %t18 = trunc i64 %t16 to i32
  %t20 = sext i32 %t18 to i64
  %t22 = getelementptr %"<fcntl.h>:timespec", ptr %l1, i32 0, i32 1
  store i64 %t20, ptr %t22, !tbaa !24
  %t23 = call %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %s0)
  store %"<fcntl.h>:timespec" %t23, ptr %l14
  br label %bb5
bb5:
  %t24 = load %"<fcntl.h>:timespec", ptr %l14
  store %"<fcntl.h>:timespec" %t24, ptr %l2
  br label %bb6
bb6:
  %t27 = call i32 @nanosleep(ptr %l1, ptr %l2)
  store i32 %t27, ptr %l17
  br label %bb7
bb7:
  %t28 = load i32, ptr %l17, !tbaa !23
  %t29 = icmp ne i32 %t28, 0
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t33 = getelementptr %"<fcntl.h>:timespec", ptr %l2, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = getelementptr %"<fcntl.h>:timespec", ptr %l1, i32 0, i32 0
  store i64 %t34, ptr %t36, !tbaa !24
  %t37 = getelementptr %"<fcntl.h>:timespec", ptr %l2, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = getelementptr %"<fcntl.h>:timespec", ptr %l1, i32 0, i32 1
  store i64 %t38, ptr %t40, !tbaa !24
  br label %bb11
bb11:
  br label %bb6
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/time:Timer" @std_2ftime_2eTimer_2eAfter(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l5 = alloca %"std/time:Timer"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/time:Timer"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l1
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = add i64 %t4, %a0
  %t8 = call %"std/time:Timer" @std_2ftime_3aTimer_2ector(ptr %s0, i64 %t6)
  store %"std/time:Timer" %t8, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"std/time:Timer", ptr %l5
  store %"std/time:Timer" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/time:Timer", ptr %rv
  ret %"std/time:Timer" %rr
}

define dso_local i64 @std_2ftime_2eWall() #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2estd_2ftime_2eclockRealtime, !tbaa !23
  %t3 = call i64 @std_2ftime_2eread(i32 %t1)
  store i64 %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2edaysFromCivil(i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i64
  %l28 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sle i64 %t1, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = sub i64 %t5, 1
  store i64 %t7, ptr %l11, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  store i64 %t9, ptr %l11, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l11, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = sub i64 %t18, 399
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = sdiv i64 %t22, 400
  store i64 %t23, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = mul i64 %t26, 400
  %t31 = sub i64 %t25, %t28
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp sgt i64 %t33, 2
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = sub i64 %t37, 3
  store i64 %t39, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = add i64 %t41, 9
  store i64 %t43, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t48 = mul i64 153, %t45
  %t50 = add i64 %t48, 2
  %t52 = sdiv i64 %t50, 5
  %t56 = add i64 %t52, %a2
  %t58 = sub i64 %t56, 1
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = mul i64 %t60, 365
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = sdiv i64 %t63, 4
  %t68 = add i64 %t62, %t65
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = sdiv i64 %t69, 100
  %t74 = sub i64 %t68, %t71
  %t78 = add i64 %t74, %t58
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = mul i64 %t80, 146097
  %t86 = add i64 %t82, %t78
  %t88 = sub i64 %t86, 719468
  store i64 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eread(i32 %a0) #0 {
entry:
  %l1 = alloca %"<fcntl.h>:timespec"
  %l2 = alloca %"<fcntl.h>:timespec"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %s0)
  store %"<fcntl.h>:timespec" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"<fcntl.h>:timespec", ptr %l2
  store %"<fcntl.h>:timespec" %t2, ptr %l1
  %t6 = call i32 @clock_gettime(i32 %a0, ptr %l1)
  store i32 %t6, ptr %l5
  br label %bb2
bb2:
  %t7 = getelementptr %"<fcntl.h>:timespec", ptr %l1, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = mul i64 %t8, 1000000000
  %t11 = getelementptr %"<fcntl.h>:timespec", ptr %l1, i32 0, i32 1
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = add i64 %t10, %t12
  call void @__olang_scope_close(ptr %s0)
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDate_2eWall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/time:Date", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/time:Date", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/time:Date", ptr %t9, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t16 = call i64 @std_2ftime_2edaysFromCivil(i64 %t4, i64 %t8, i64 %t12)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t20 = mul i64 %t17, 86400
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/time:Date", ptr %t21, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = mul i64 %t24, 3600
  %t29 = add i64 %t20, %t26
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"std/time:Date", ptr %t30, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = mul i64 %t33, 60
  %t38 = add i64 %t29, %t35
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"std/time:Date", ptr %t39, i32 0, i32 5
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = add i64 %t38, %t42
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/time:Date", ptr %t46, i32 0, i32 7
  %t49 = load i64, ptr %t48, !tbaa !24
  %t51 = mul i64 %t49, 60
  %t54 = sub i64 %t45, %t51
  %t58 = mul i64 %t54, 1000000000
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/time:Date", ptr %t59, i32 0, i32 6
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = add i64 %t58, %t62
  store i64 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDate_2eWeekday(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/time:Date", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/time:Date", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/time:Date", ptr %t9, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t16 = call i64 @std_2ftime_2edaysFromCivil(i64 %t4, i64 %t8, i64 %t12)
  store i64 %t16, ptr %l8
  br label %bb1
bb1:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = add i64 %t17, 4
  %t20 = srem i64 %t18, 7
  store i64 %t20, ptr %l1, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = add i64 %t26, 7
  store i64 %t28, ptr %l13, !tbaa !24
  br label %bb4
bb3:
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDate_2eYearDay(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/time:Date", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/time:Date", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/time:Date", ptr %t9, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t16 = call i64 @std_2ftime_2edaysFromCivil(i64 %t4, i64 %t8, i64 %t12)
  store i64 %t16, ptr %l7
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/time:Date", ptr %t17, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = call i64 @std_2ftime_2edaysFromCivil(i64 %t20, i64 1, i64 1)
  store i64 %t22, ptr %l10
  br label %bb2
bb2:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = sub i64 %t23, %t24
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDuration_2eMicros(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t4 = sdiv i64 %a0, 1000
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDuration_2eMillis(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t4 = sdiv i64 %a0, 1000000
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aDuration_2eNanos(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local double @std_2ftime_2estd_2ftime_3aDuration_2eSeconds(i64 %a0) #0 {
entry:
  %rv = alloca double
  br label %start
start:
  br label %bb0
bb0:
  %t4 = sitofp i64 %a0 to double
  %t6 = fdiv double %t4, 0x41cdcd6500000000
  store double %t6, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local i64 @std_2ftime_2estd_2ftime_3aTimer_2eDue(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/time:Timer", ptr %a0, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @std_2ftime_2estd_2ftime_3aTimer_2eTryNow(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load i64, ptr %l2, !tbaa !24
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t6 = getelementptr %"std/time:Timer", ptr %a0, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t10 = icmp slt i64 %t3, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t13 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = insertvalue { i32, i64 } zeroinitializer, i64 %t14, 1
  store { i32, i64 } %t16, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local %"std/time:Date" @std_2ftime_3aDate_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7) #0 {
entry:
  %rv = alloca %"std/time:Date"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"std/time:Date" undef, i64 %a0, 0
  %t20 = insertvalue %"std/time:Date" %t18, i64 %a1, 1
  %t22 = insertvalue %"std/time:Date" %t20, i64 %a2, 2
  %t24 = insertvalue %"std/time:Date" %t22, i64 %a3, 3
  %t26 = insertvalue %"std/time:Date" %t24, i64 %a4, 4
  %t28 = insertvalue %"std/time:Date" %t26, i64 %a5, 5
  %t30 = insertvalue %"std/time:Date" %t28, i64 %a6, 6
  %t32 = insertvalue %"std/time:Date" %t30, i64 %a7, 7
  store %"std/time:Date" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"std/time:Date", ptr %rv
  ret %"std/time:Date" %rr
}

define dso_local %"std/time:Timer" @std_2ftime_3aTimer_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/time:Timer"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"std/time:Timer" undef, i64 %a0, 0
  store %"std/time:Timer" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/time:Timer", ptr %rv
  ret %"std/time:Timer" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare i32 @nanosleep(ptr, ptr)
declare i32 @clock_gettime(i32, ptr)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"std/time:Date" @std_2ftime_2eDate_2eOf(i64 %a0, i64 %a1)
declare { i64, ptr } @std_2ftime_2estd_2ftime_3aDate_2eStr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2ftime_2eoffsetOf(ptr %v0, { i64, ptr } %a0)
declare %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
