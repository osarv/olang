; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
@G_2estd_2ftime_2eclockMonotonic = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2ftime_2eclockRealtime = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
define dso_local void @olang_2einit_2estd_2ftime() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2ftime_2eclockRealtime_2einit()
  br label %bb1
bb1:
  call void @std_2ftime_2eclockMonotonic_2einit()
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2ftime_2eNow() #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2estd_2ftime_2eclockMonotonic, !tbaa !23
  %t3 = call i64 @std_2ftime_2eread(i32 %t1)
  store i64 %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eSince(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l1
  br label %bb1
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t3, %a0
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2ftime_2eWall() #0 {
entry:
  %l1 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2estd_2ftime_2eclockRealtime, !tbaa !23
  %t3 = call i64 @std_2ftime_2eread(i32 %t1)
  store i64 %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2ftime_2eclockMonotonic_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2estd_2ftime_2eclockMonotonic, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @std_2ftime_2eclockRealtime_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2estd_2ftime_2eclockRealtime, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2ftime_2eread(i32 %a0) #0 {
entry:
  %l1 = alloca [2 x i64]
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i64] undef, i64 0, 0
  %t2 = insertvalue [2 x i64] %t1, i64 0, 1
  store [2 x i64] %t2, ptr %l1
  %t6 = insertvalue { i64, ptr } undef, i64 2, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %l1, 1
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = call i32 @clock_gettime(i32 %a0, ptr %t11)
  store i32 %t13, ptr %l7
  br label %bb1
bb1:
  %t14 = getelementptr [2 x i64], ptr %l1, i64 0, i64 0
  %t15 = load i64, ptr %t14, !tbaa !34
  %t17 = mul i64 %t15, 1000000000
  %t18 = getelementptr [2 x i64], ptr %l1, i64 0, i64 1
  %t19 = load i64, ptr %t18, !tbaa !34
  %t22 = add i64 %t17, %t19
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare i32 @clock_gettime(i32, ptr)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
