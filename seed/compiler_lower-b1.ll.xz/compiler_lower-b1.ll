; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/lower:CloneSum" = type { i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/lower:CloneHand" = type { i64, { i64, [2 x i64] }, i64, i64 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i32, i32, i32, i64, i64, %"compiler/source:Span", { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i64, i64, i64, i32, i32, { i64, [1 x i64] }, ptr, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:DropHolding", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" = type { { i64, [2 x i64] }, i64 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { ptr, ptr }, { ptr, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/mir:GenInfo", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/lower:hoistWalk" = type { i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [4 x i64] }, { i64, [4 x i64] }, { i64, [4 x i64] } }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/lower:relPath" = type { i64, { i64, ptr }, i1, i1, i64, i64, i32, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eCloneSumText(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/lower:CloneSum"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/lower:CloneHand"
  %l11 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/lower:CloneSum"
  %l17 = alloca %"compiler/lower:CloneSum"
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca %"compiler/lower:CloneHand"
  %l49 = alloca ptr
  %l51 = alloca { i64, [2 x i64] }
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 55
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ecloneSum(ptr %v0, ptr %t4, { i64, [2 x i64] } %a1)
  store i64 %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  %t10 = load i64, ptr %l14, !tbaa !24
  %t11 = call %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store %"compiler/lower:CloneSum" %t11, ptr %l15
  br label %bb2
bb2:
  %t13 = call %"compiler/lower:CloneSum" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3aCloneSum(ptr %s0, ptr %l15)
  store %"compiler/lower:CloneSum" %t13, ptr %l17
  br label %bb3
bb3:
  %t14 = load %"compiler/lower:CloneSum", ptr %l17
  store %"compiler/lower:CloneSum" %t14, ptr %l2
  %t15 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t16, ptr %l3
  %t17 = getelementptr %"compiler/lower:CloneSum", ptr %l2, i32 0, i32 0
  %t18 = load i1, ptr %t17, !tbaa !21
  %t19 = getelementptr %"compiler/lower:CloneSum", ptr %l2, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t24 = select i1 %t18, ptr @.c1, ptr @.c2
  %t25 = select i1 %t18, i64 4, i64 5
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t31 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t32 = add i64 %t29, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t21, i64 %t22)
  %t37 = getelementptr i8, ptr %t36, i64 %t22
  call void @olang_textcopy(ptr %t37, ptr %t24, i64 %t25)
  %t38 = getelementptr i8, ptr %t37, i64 %t25
  call void @olang_textcopy(ptr %t38, ptr %t27, i64 %t28)
  %t39 = getelementptr i8, ptr %t38, i64 %t28
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t20)
  %t41 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t41, ptr %t33, i64 %t34)
  %t42 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t36, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t43)
  br label %bb5
bb5:
  %t47 = getelementptr %"compiler/lower:CloneSum", ptr %l2, i32 0, i32 2
  store ptr %t47, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l5, !tbaa !24
  store i64 %t49, ptr %l25, !tbaa !24
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t50)
  store i64 %t52, ptr %l27
  br label %bb7
bb7:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = load i64, ptr %l27, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l32
  br label %bb11
bb11:
  %t64 = load i64, ptr %l32, !tbaa !24
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t69 = call i64 @__olang_fmt_i64(ptr null, i64 %t64)
  %t70 = add i64 %t67, %t69
  %t71 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t66, i64 %t67)
  %t72 = getelementptr i8, ptr %t71, i64 %t67
  %t73 = call i64 @__olang_fmt_i64(ptr %t72, i64 %t64)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t71, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } %t75)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb6
bb14:
  %t84 = getelementptr %"compiler/lower:CloneSum", ptr %l2, i32 0, i32 3
  store ptr %t84, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s7
  %t86 = load i64, ptr %l8, !tbaa !24
  store i64 %t86, ptr %l41, !tbaa !24
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e_2eLen__Hdac5394885c7d3b88563717d707df765(ptr %s0, ptr %t87)
  store i64 %t89, ptr %l43
  br label %bb16
bb16:
  %t90 = load i64, ptr %l41, !tbaa !24
  %t91 = load i64, ptr %l43, !tbaa !24
  %t92 = icmp slt i64 %t90, %t91
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t96 = load ptr, ptr %l7, !tbaa !29
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = call %"compiler/lower:CloneHand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e_2eAt_3ccompiler_2flower_3aCloneHand_3e(ptr %s0, ptr %t96, i64 %t97)
  store %"compiler/lower:CloneHand" %t100, ptr %l48
  br label %bb20
bb20:
  %t101 = load %"compiler/lower:CloneHand", ptr %l48
  store %"compiler/lower:CloneHand" %t101, ptr %l9
  store ptr %l3, ptr %l49, !tbaa !29
  %t102 = getelementptr %"compiler/lower:CloneHand", ptr %l9, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"compiler/lower:CloneHand", ptr %l9, i32 0, i32 1
  %t105 = load { i64, [2 x i64] }, ptr %t104
  store { i64, [2 x i64] } %t105, ptr %l51
  %t106 = getelementptr %"compiler/lower:CloneHand", ptr %l9, i32 0, i32 2
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l52, !tbaa !24
  %t108 = getelementptr %"compiler/lower:CloneHand", ptr %l9, i32 0, i32 3
  %t109 = load i64, ptr %t108, !tbaa !24
  store i64 %t109, ptr %l53, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t110 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t110, i64 %t111)
  %t113 = call ptr @__olang_sb_room(ptr %s8, i64 24)
  %t114 = call i64 @__olang_fmt_i64(ptr %t113, i64 %t103)
  call void @__olang_sb_add(ptr %s8, i64 %t114)
  %t115 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t115, i64 %t116)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aFnKey(ptr %s8, ptr %l51, i64 0)
  br label %bb21
bb21:
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t118, i64 %t119)
  %t120 = load i64, ptr %l52, !tbaa !24
  %t121 = call ptr @__olang_sb_room(ptr %s8, i64 24)
  %t122 = call i64 @__olang_fmt_i64(ptr %t121, i64 %t120)
  call void @__olang_sb_add(ptr %s8, i64 %t122)
  %t123 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t123, i64 %t124)
  %t125 = load i64, ptr %l53, !tbaa !24
  %t126 = call ptr @__olang_sb_room(ptr %s8, i64 24)
  %t127 = call i64 @__olang_fmt_i64(ptr %t126, i64 %t125)
  call void @__olang_sb_add(ptr %s8, i64 %t127)
  %t128 = load ptr, ptr %s8
  %t129 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t130 = load i64, ptr %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t128, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l55, !tbaa !27
  %t134 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t135 = load ptr, ptr %t134
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %sbgrew.137, label %sbdone.138
sbgrew.137:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.138
sbdone.138:
  %t139 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t140 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t140, { i64, ptr } %t139)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb23:
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l8, !tbaa !24
  br label %bb15
bb24:
  %t148 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t148, ptr %l61
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t149 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t149, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eadapterFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %lp12 = alloca ptr
  %lp13 = alloca ptr
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i1
  %l68 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l82 = alloca i32
  %l87 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i32
  %l95 = alloca %"compiler/typed:Body"
  %l96 = alloca ptr
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l105 = alloca %"compiler/mir:Fn"
  %l109 = alloca %"compiler/lower:lowering"
  %l113 = alloca { i64, ptr }
  %l117 = alloca %"compiler/mir:Fn"
  %l119 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t176 = alloca %"compiler/typed:Body", align 8
  %t190 = alloca { i64, [2 x i64] }, align 8
  %t197 = alloca %"compiler/mir:Fn", align 8
  %t205 = alloca %"compiler/lower:lowering", align 8
  %t234 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t8 = sext i32 %t6 to i64
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t4, i64 %t8)
  store ptr %t11, ptr %l19
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l19, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %t14, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:Lowerer", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l24, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:Lowerer", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l29
  br label %bb2
bb2:
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = load i32, ptr %l29, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t35, ptr %l30
  br label %bb3
bb3:
  %t36 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t36, ptr %l3, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = sub i64 %t39, 1
  store i64 %t41, ptr %l33, !tbaa !24
  %t42 = load i64, ptr %l33, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb4, label %bb5
bb4:
  %t45 = load i64, ptr %l33, !tbaa !24
  %t46 = icmp sle i64 %t45, 2305843009213693951
  br i1 %t46, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2)
  unreachable
bb6:
  %t48 = load i64, ptr %l33, !tbaa !24
  %t49 = mul i64 %t48, 4
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2)
  unreachable
bb8:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb13
bb10:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = sub i64 %t68, %t69
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t72, %t73
  %t78 = sub i64 %t76, 1
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = sdiv i64 %t78, %t79
  store i64 %t82, ptr %l45, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb12
bb12:
  %t84 = load i64, ptr %l45, !tbaa !24
  store i64 %t84, ptr %l42, !tbaa !24
  br label %bb13
bb13:
  %t85 = load i64, ptr %l42, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = sub i64 %t86, 1
  store i64 %t87, ptr %l54, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = icmp slt i64 %t88, 2147483648
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp sge i64 %t90, 0
  %t94 = and i1 %t89, %t91
  store i1 %t94, ptr %l57, !tbaa !21
  br label %bb14
bb14:
  %t95 = load i64, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l10, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t114, ptr %l68, !tbaa !27
  %t115 = load i64, ptr %l10, !tbaa !24
  %t117 = add i64 %t115, 1
  %t119 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t117
  %t122 = load i32, ptr %t121, !tbaa !33
  %t125 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t113
  store i32 %t122, ptr %t127, !tbaa !33
  br label %bb18
bb18:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb14
bb19:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/lower:Lowerer", ptr %t133, i32 0, i32 0
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  store ptr %t138, ptr %l77, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/lower:Lowerer", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t144, { i64, ptr } %t145)
  store i32 %t148, ptr %l82
  br label %bb20
bb20:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/lower:Lowerer", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l2, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l87
  br label %bb21
bb21:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/lower:Lowerer", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  %t165 = load i32, ptr %l2, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t164, i32 %t165)
  store i32 %t168, ptr %l92
  br label %bb22
bb22:
  %t169 = load ptr, ptr %l77, !tbaa !29
  %t170 = load i32, ptr %l82, !tbaa !23
  %t171 = load i32, ptr %l87, !tbaa !23
  %t172 = load i32, ptr %l92, !tbaa !23
  %t173 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t169, i32 %t170, i32 %t171, i32 %t172, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t173, ptr %l93
  br label %bb23
bb23:
  %t174 = load i32, ptr %l93, !tbaa !23
  store i32 %t174, ptr %l11, !tbaa !23
  %t175 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2estandIn(ptr %t176, ptr %v1, i32 %t175)
  call void @llvm.memmove.p0.p0.i64(ptr %l95, ptr %t176, i64 440, i1 false)
  br label %bb24
bb24:
  %t178 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 440, i64 8)
  store ptr %t178, ptr %lp12
  %t179 = load ptr, ptr %lp12
  call void @llvm.memmove.p0.p0.i64(ptr %t179, ptr %l95, i64 440, i1 false)
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l96, !tbaa !29
  %t181 = load ptr, ptr %lp12
  store ptr %t181, ptr %l97, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/lower:Lowerer", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 2
  store ptr %t187, ptr %l100, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [2 x i64] }, ptr %t190, i32 0, i32 0
  store i64 1, ptr %t191
  %t193 = insertvalue { i32 } undef, i32 %t189, 0
  %t194 = getelementptr { i64, [2 x i64] }, ptr %t190, i32 0, i32 1
  store { i32 } %t193, ptr %t194
  %t195 = load { i64, [2 x i64] }, ptr %t190
  %t196 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t197, ptr %v0, ptr %v1, ptr %t188, { i64, [2 x i64] } %t195, i32 %t196)
  call void @llvm.memmove.p0.p0.i64(ptr %l105, ptr %t197, i64 808, i1 false)
  br label %bb25
bb25:
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t201, ptr %l105, i64 808, i1 false)
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/lower:Lowerer", ptr %t202, i32 0, i32 3
  %t206 = load ptr, ptr %l96, !tbaa !29
  %t207 = load ptr, ptr %l97, !tbaa !29
  %t208 = load ptr, ptr %l100, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t205, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %t206, ptr %t207, ptr %t208, ptr %t201, ptr %t204)
  call void @llvm.memmove.p0.p0.i64(ptr %l109, ptr %t205, i64 4104, i1 false)
  br label %bb26
bb26:
  %t211 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 4104, i64 8)
  store ptr %t211, ptr %lp13
  %t212 = load ptr, ptr %lp13
  call void @llvm.memmove.p0.p0.i64(ptr %t212, ptr %l109, i64 4104, i1 false)
  %t213 = load ptr, ptr %lp13
  %t214 = load i32, ptr %l1, !tbaa !23
  %t215 = load i32, ptr %l2, !tbaa !23
  %t216 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t216, ptr %l113, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i32, ptr %t218, i64 0
  %t220 = load i32, ptr %t219, !tbaa !33
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v1, ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t213, i32 %t214, i32 %t215, i32 %t220)
  br label %bb27
bb27:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %lp13
  %t227 = getelementptr %"compiler/lower:lowering", ptr %t226, i32 0, i32 13
  %t228 = load i1, ptr %t227, !tbaa !21
  %t231 = getelementptr %"compiler/lower:Lowerer", ptr %t225, i32 0, i32 14
  store i1 %t228, ptr %t231, !tbaa !21
  %t232 = load ptr, ptr %lp13
  %t233 = getelementptr %"compiler/lower:lowering", ptr %t232, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l117, ptr %t233, i64 808, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aFn(ptr %t234, ptr %v1, ptr %l117)
  call void @llvm.memmove.p0.p0.i64(ptr %l119, ptr %t234, i64 808, i1 false)
  br label %bb28
bb28:
  call void @llvm.memmove.p0.p0.i64(ptr %l117, ptr %l119, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l117, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshLocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca %"compiler/typed:Local"
  %l24 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l82 = alloca i64
  %l85 = alloca i1
  %l86 = alloca ptr
  %l90 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i1
  %l103 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 7
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t3, i64 %t4)
  store %"compiler/typed:Local" %t7, ptr %l21
  br label %bb1
bb1:
  %t8 = load %"compiler/typed:Local", ptr %l21
  store %"compiler/typed:Local" %t8, ptr %l4
  %t9 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb4
bb3:
  %t15 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t16 = load i32, ptr %t15, !range !{i32 0, i32 7}
  %t18 = trunc i64 5 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l24, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l24, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb8
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LocalUses", ptr %t22, i32 0, i32 7
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l31
  br label %bb7
bb7:
  %t29 = load i1, ptr %l31, !tbaa !21
  store i1 %t29, ptr %l27, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l27, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/typed:LocalUses", ptr %t31, i32 0, i32 4
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t33, i64 %t34)
  store i1 %t37, ptr %l36
  br label %bb11
bb11:
  %t38 = load i1, ptr %l36, !tbaa !21
  store i1 %t38, ptr %l32, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l32, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/typed:LocalUses", ptr %t41, i32 0, i32 20
  %t44 = load i64, ptr %l3, !tbaa !24
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v2, ptr %v2, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l41
  br label %bb16
bb16:
  %t48 = load ptr, ptr %l41, !tbaa !29
  store ptr %t48, ptr %l5, !tbaa !29
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb20
bb18:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t61 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t53, ptr %t54, ptr %t55, ptr %t56)
  store i1 %t61, ptr %l49
  br label %bb19
bb19:
  %t62 = load i1, ptr %l49, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l44, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l44, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %t67, i32 0, i32 24
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t69)
  store i64 %t71, ptr %l54
  br label %bb24
bb24:
  %t72 = load i64, ptr %l54, !tbaa !24
  store i64 %t72, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb25, label %bb26
bb25:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb30
bb27:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l61, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb29
bb29:
  %t99 = load i64, ptr %l61, !tbaa !24
  store i64 %t99, ptr %l58, !tbaa !24
  br label %bb30
bb30:
  %t100 = load i64, ptr %l58, !tbaa !24
  store i64 %t100, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb32, label %bb33
bb32:
  br label %bb46
bb33:
  br label %bb34
bb34:
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l11, !tbaa !24
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/typed:LocalUses", ptr %t119, i32 0, i32 24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t121, i64 %t122)
  store i64 %t125, ptr %l82
  br label %bb35
bb35:
  %t126 = load i64, ptr %l3, !tbaa !24
  %t127 = load i64, ptr %l82, !tbaa !24
  %t129 = icmp eq i64 %t127, %t126
  br i1 %t129, label %bb36, label %bb37
bb36:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l86, !tbaa !29
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t134 = getelementptr %"compiler/typed:LocalUses", ptr %t132, i32 0, i32 25
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t134, i64 %t135)
  store i64 %t138, ptr %l90
  br label %bb38
bb37:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb41
bb38:
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t141 = getelementptr %"compiler/typed:LocalUses", ptr %t139, i32 0, i32 26
  %t142 = load i64, ptr %l11, !tbaa !24
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t141, i64 %t142)
  store i64 %t145, ptr %l94
  br label %bb39
bb39:
  %t146 = load ptr, ptr %l86, !tbaa !29
  %t147 = load i64, ptr %l90, !tbaa !24
  %t148 = load i64, ptr %l94, !tbaa !24
  %t149 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshParam(ptr %v0, ptr %t146, i64 %t147, i64 %t148)
  store i1 %t149, ptr %l95
  br label %bb40
bb40:
  %t150 = load i1, ptr %l95, !tbaa !21
  %t151 = xor i1 %t150, true
  store i1 %t151, ptr %l85, !tbaa !21
  br label %bb41
bb41:
  %t153 = load i1, ptr %l85, !tbaa !21
  br i1 %t153, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t155 = load i64, ptr %l10, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l10, !tbaa !24
  br label %bb31
bb46:
  store i64 0, ptr %l12, !tbaa !24
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t162 = getelementptr %"compiler/typed:LocalUses", ptr %t160, i32 0, i32 19
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t162)
  store i64 %t164, ptr %l103
  br label %bb47
bb47:
  %t165 = load i64, ptr %l103, !tbaa !24
  store i64 %t165, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t166 = load i64, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = icmp sgt i64 %t166, %t167
  br i1 %t170, label %bb48, label %bb49
bb48:
  %t172 = load i64, ptr %l14, !tbaa !24
  %t174 = icmp sgt i64 %t172, 0
  br i1 %t174, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb53
bb50:
  %t176 = load i64, ptr %l13, !tbaa !24
  %t177 = load i64, ptr %l12, !tbaa !24
  %t180 = sub i64 %t176, %t177
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = add i64 %t180, %t181
  %t186 = sub i64 %t184, 1
  %t187 = load i64, ptr %l14, !tbaa !24
  %t190 = sdiv i64 %t186, %t187
  store i64 %t190, ptr %l110, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb52
bb52:
  %t192 = load i64, ptr %l110, !tbaa !24
  store i64 %t192, ptr %l107, !tbaa !24
  br label %bb53
bb53:
  %t193 = load i64, ptr %l107, !tbaa !24
  store i64 %t193, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb54
bb54:
  %t194 = load i64, ptr %l16, !tbaa !24
  %t195 = load i64, ptr %l15, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb55, label %bb56
bb55:
  br label %bb63
bb56:
  br label %bb57
bb57:
  %t202 = load i64, ptr %l12, !tbaa !24
  %t203 = load i64, ptr %l16, !tbaa !24
  %t204 = load i64, ptr %l14, !tbaa !24
  %t207 = mul i64 %t203, %t204
  %t210 = add i64 %t202, %t207
  %t212 = load ptr, ptr %l2, !tbaa !29
  %t214 = getelementptr %"compiler/typed:LocalUses", ptr %t212, i32 0, i32 19
  %t218 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t214, i64 %t210)
  store i64 %t218, ptr %l131
  br label %bb58
bb58:
  %t219 = load i64, ptr %l3, !tbaa !24
  %t220 = load i64, ptr %l131, !tbaa !24
  %t222 = icmp eq i64 %t220, %t219
  br i1 %t222, label %bb59, label %bb60
bb59:
  store i1 false, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t225 = load i64, ptr %l16, !tbaa !24
  %t228 = add i64 %t225, 1
  store i64 %t228, ptr %l16, !tbaa !24
  br label %bb54
bb63:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flower_2ecompiler_2flower_3aLowerer_2egenValue(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l40 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l11, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/lower:Lowerer", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3993e9d21a27b6abd527556382000d9e(ptr %v0, ptr %t8, i64 %t9)
  store i1 %t12, ptr %l16
  br label %bb2
bb2:
  %t13 = load i1, ptr %l16, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t14, { i64, ptr } %t15)
  br label %bb6
bb6:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t16)
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  %t23 = call i64 @__olang_fmt_i64(ptr %t22, i64 %t16)
  %t24 = getelementptr i8, ptr %t22, i64 %t18
  call void @olang_textcopy(ptr %t24, ptr %t19, i64 %t20)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t22, 1
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l20
  br label %bb7
bb7:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l4
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:Lowerer", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 7
  %t37 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hc20348a7e3f4966d079d7d53957fcef1(ptr %v0, ptr %v0, ptr %t35)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t37, ptr %l24
  br label %bb8
bb8:
  %t38 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l24
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t38, ptr %l5
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H25a1fa74df5469e35efe3ff4130517ef(ptr %v0, ptr %s3, ptr %l5)
  %t41 = extractvalue { i32, { i64, ptr } } %t40, 1
  %t42 = extractvalue { i32, { i64, ptr } } %t40, 0
  store i32 %t42, ptr %l28
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb11, label %ok.44, !prof !99
ok.44:
  store { i64, ptr } %t41, ptr %l27
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l31, !tbaa !24
  %t47 = load i64, ptr %l31, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l32, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t58, ptr %l25, !tbaa !27
  br label %bb13
bb11:
  %t59 = load i32, ptr %l28, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb13:
  %t63 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t63, ptr %l6, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s0, { i64, ptr } %t64, { i64, ptr } %t65)
  store i1 %t68, ptr %l35
  br label %bb14
bb14:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  store ptr %l4, ptr %l36, !tbaa !29
  %t70 = call ptr @__olang_scope_hold(ptr %s0)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l37, !tbaa !24
  %t72 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t72, label %bb17, label %bb18
bb16:
  br label %bb26
bb17:
  %t74 = call ptr @__olang_region_make(ptr %s0)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l37, !tbaa !24
  br label %bb18
bb18:
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l40, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l42, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l43, !tbaa !24
  %t84 = load i64, ptr %l40, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb19, label %bb20
bb19:
  %t87 = load i64, ptr %l40, !tbaa !24
  %t88 = load i64, ptr %l42, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c32f9218f06293f2_15f5ca50bc3801e)
  unreachable
bb21:
  %t91 = load i64, ptr %l42, !tbaa !24
  %t92 = load i64, ptr %l43, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c32f9218f06293f2_15f5ca50bc3801e)
  unreachable
bb23:
  %t95 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l40, !tbaa !24
  %t98 = load i64, ptr %l42, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = extractvalue { i64, ptr } %t102, 0
  %t106 = load i64, ptr %l37
  %t107 = inttoptr i64 %t106 to ptr
  %t108 = call ptr @__olang_held_alloc(ptr %t107, i64 %t105)
  call void @olang_textcopy(ptr %t108, ptr %t104, i64 %t105)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t112 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t112, { i64, ptr } %t110)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_c32f9218f06293f2_15f5ca50bc3801e)
  unreachable
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb9
bb28:
  %t114 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_13, 0
  %t115 = insertvalue { ptr, ptr } %t114, ptr null, 1
  %t118 = extractvalue { ptr, ptr } %t115, 0
  %t119 = extractvalue { ptr, ptr } %t115, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l4, ptr %t118, ptr %t119)
  br label %bb29
bb29:
  store ptr %l4, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t121 = load i64, ptr %l8, !tbaa !24
  store i64 %t121, ptr %l53, !tbaa !24
  %t122 = load ptr, ptr %l7, !tbaa !29
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t122)
  store i64 %t124, ptr %l55
  br label %bb31
bb31:
  %t125 = load i64, ptr %l53, !tbaa !24
  %t126 = load i64, ptr %l55, !tbaa !24
  %t127 = icmp slt i64 %t125, %t126
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t131 = load ptr, ptr %l7, !tbaa !29
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t131, i64 %t132)
  store { i64, ptr } %t135, ptr %l60
  br label %bb35
bb35:
  %t136 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t138 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t141 = extractvalue { i64, ptr } %t136, 1
  %t142 = extractvalue { i64, ptr } %t136, 0
  %t143 = add i64 %t139, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t138, i64 %t139)
  %t145 = getelementptr i8, ptr %t144, i64 %t139
  call void @olang_textcopy(ptr %t145, ptr %t141, i64 %t142)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l2, { i64, ptr } %t147)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l8, !tbaa !24
  br label %bb30
bb38:
  %t157 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t157, ptr %l69
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehandsBack(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:LocalUses"
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l25 = alloca i64
  %l32 = alloca %"compiler/typed:LocalUses"
  %l36 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i1
  %l91 = alloca ptr
  %l94 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i1
  %l105 = alloca i64
  %l109 = alloca i64
  %l112 = alloca i64
  %l132 = alloca i64
  %l135 = alloca i1
  %l136 = alloca ptr
  %l139 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t27 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb4
bb2:
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l22, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 5
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l25
  br label %bb3
bb3:
  %t14 = load i64, ptr %l22, !tbaa !24
  %t15 = load i64, ptr %l25, !tbaa !24
  %t16 = icmp sge i64 %t14, %t15
  store i1 %t16, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l21, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:Lowerer", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t27, ptr %v0, ptr %v1, ptr %s0, ptr %t25, ptr %t26)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t27, i64 1640, i1 false)
  br label %bb8
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l32, i64 1640, i1 false)
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 5
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l36
  br label %bb9
bb9:
  %t37 = load i32, ptr %l36, !tbaa !23
  %t38 = sext i32 %t37 to i64
  store i64 %t38, ptr %l4, !tbaa !24
  %t40 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 2
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t40, i64 %t41)
  store i1 %t44, ptr %l40
  br label %bb10
bb10:
  %t45 = load i1, ptr %l40, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb14
bb12:
  %t46 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 4
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t46, i64 %t47)
  store i1 %t50, ptr %l44
  br label %bb13
bb13:
  %t51 = load i1, ptr %l44, !tbaa !21
  store i1 %t51, ptr %l41, !tbaa !21
  br label %bb14
bb14:
  %t52 = load i1, ptr %l41, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb18
bb16:
  %t53 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 8
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t53, i64 %t54)
  store i1 %t57, ptr %l48
  br label %bb17
bb17:
  %t58 = load i1, ptr %l48, !tbaa !21
  store i1 %t58, ptr %l45, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l45, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb22
bb20:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 19
  %t66 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %t62, i64 %t60)
  store i1 %t66, ptr %l53
  br label %bb21
bb21:
  %t67 = load i1, ptr %l53, !tbaa !21
  store i1 %t67, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t68 = load i1, ptr %l49, !tbaa !21
  br i1 %t68, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb26
bb24:
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 22
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = call i1 @compiler_2flower_2ehas(ptr %s0, ptr %t69, i64 %t70)
  store i1 %t73, ptr %l57
  br label %bb25
bb25:
  %t74 = load i1, ptr %l57, !tbaa !21
  store i1 %t74, ptr %l54, !tbaa !21
  br label %bb26
bb26:
  %t75 = load i1, ptr %l54, !tbaa !21
  br i1 %t75, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  store i64 0, ptr %l6, !tbaa !24
  %t77 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 27
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t77)
  store i64 %t79, ptr %l60
  br label %bb30
bb30:
  %t80 = load i64, ptr %l60, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb31, label %bb32
bb31:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb36
bb33:
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l67, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb35
bb35:
  %t107 = load i64, ptr %l67, !tbaa !24
  store i64 %t107, ptr %l64, !tbaa !24
  br label %bb36
bb36:
  %t108 = load i64, ptr %l64, !tbaa !24
  store i64 %t108, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb37
bb37:
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb38, label %bb39
bb38:
  br label %bb52
bb39:
  br label %bb40
bb40:
  %t117 = load i64, ptr %l6, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l11, !tbaa !24
  %t127 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 27
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t127, i64 %t128)
  store i64 %t131, ptr %l87
  br label %bb41
bb41:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t133 = load i64, ptr %l87, !tbaa !24
  %t135 = icmp eq i64 %t133, %t132
  br i1 %t135, label %bb42, label %bb43
bb42:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l91, !tbaa !29
  %t138 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 28
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t138, i64 %t139)
  store i64 %t142, ptr %l94
  br label %bb44
bb43:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb47
bb44:
  %t143 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 29
  %t144 = load i64, ptr %l11, !tbaa !24
  %t147 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t143, i64 %t144)
  store i64 %t147, ptr %l97
  br label %bb45
bb45:
  %t148 = load ptr, ptr %l91, !tbaa !29
  %t149 = load i64, ptr %l94, !tbaa !24
  %t150 = load i64, ptr %l97, !tbaa !24
  %t151 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNoRef(ptr %v0, ptr %t148, i64 %t149, i64 %t150)
  store i1 %t151, ptr %l98
  br label %bb46
bb46:
  %t152 = load i1, ptr %l98, !tbaa !21
  %t153 = xor i1 %t152, true
  store i1 %t153, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t155 = load i1, ptr %l90, !tbaa !21
  br i1 %t155, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb37
bb52:
  store i64 0, ptr %l12, !tbaa !24
  %t162 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 24
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t162)
  store i64 %t164, ptr %l105
  br label %bb53
bb53:
  %t165 = load i64, ptr %l105, !tbaa !24
  store i64 %t165, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t166 = load i64, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = icmp sgt i64 %t166, %t167
  br i1 %t170, label %bb54, label %bb55
bb54:
  %t172 = load i64, ptr %l14, !tbaa !24
  %t174 = icmp sgt i64 %t172, 0
  br i1 %t174, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb59
bb56:
  %t176 = load i64, ptr %l13, !tbaa !24
  %t177 = load i64, ptr %l12, !tbaa !24
  %t180 = sub i64 %t176, %t177
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = add i64 %t180, %t181
  %t186 = sub i64 %t184, 1
  %t187 = load i64, ptr %l14, !tbaa !24
  %t190 = sdiv i64 %t186, %t187
  store i64 %t190, ptr %l112, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb58
bb58:
  %t192 = load i64, ptr %l112, !tbaa !24
  store i64 %t192, ptr %l109, !tbaa !24
  br label %bb59
bb59:
  %t193 = load i64, ptr %l109, !tbaa !24
  store i64 %t193, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb60
bb60:
  %t194 = load i64, ptr %l16, !tbaa !24
  %t195 = load i64, ptr %l15, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb61, label %bb62
bb61:
  br label %bb75
bb62:
  br label %bb63
bb63:
  %t202 = load i64, ptr %l12, !tbaa !24
  %t203 = load i64, ptr %l16, !tbaa !24
  %t204 = load i64, ptr %l14, !tbaa !24
  %t207 = mul i64 %t203, %t204
  %t210 = add i64 %t202, %t207
  store i64 %t210, ptr %l17, !tbaa !24
  %t212 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 24
  %t213 = load i64, ptr %l17, !tbaa !24
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t212, i64 %t213)
  store i64 %t216, ptr %l132
  br label %bb64
bb64:
  %t217 = load i64, ptr %l4, !tbaa !24
  %t218 = load i64, ptr %l132, !tbaa !24
  %t220 = icmp eq i64 %t218, %t217
  br i1 %t220, label %bb65, label %bb66
bb65:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l136, !tbaa !29
  %t223 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 25
  %t224 = load i64, ptr %l17, !tbaa !24
  %t227 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t223, i64 %t224)
  store i64 %t227, ptr %l139
  br label %bb67
bb66:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb70
bb67:
  %t228 = getelementptr %"compiler/typed:LocalUses", ptr %l3, i32 0, i32 26
  %t229 = load i64, ptr %l17, !tbaa !24
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l142
  br label %bb68
bb68:
  %t233 = load ptr, ptr %l136, !tbaa !29
  %t234 = load i64, ptr %l139, !tbaa !24
  %t235 = load i64, ptr %l142, !tbaa !24
  %t236 = call i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epreserves(ptr %v0, ptr %t233, i64 %t234, i64 %t235)
  store i1 %t236, ptr %l143
  br label %bb69
bb69:
  %t237 = load i1, ptr %l143, !tbaa !21
  %t238 = xor i1 %t237, true
  store i1 %t238, ptr %l135, !tbaa !21
  br label %bb70
bb70:
  %t240 = load i1, ptr %l135, !tbaa !21
  br i1 %t240, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t242 = load i64, ptr %l16, !tbaa !24
  %t245 = add i64 %t242, 1
  store i64 %t245, ptr %l16, !tbaa !24
  br label %bb60
bb75:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2enoteCloneCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, %"compiler/mir:Call" %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Call"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, [7 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca { i64, [4 x i64] }
  %l22 = alloca i64
  %l23 = alloca i64
  %l33 = alloca { i64, [4 x i64] }
  %l40 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l47 = alloca i64
  %l55 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca i64
  %l97 = alloca { i64, [4 x i64] }
  %l100 = alloca { i64, [4 x i64] }
  %l101 = alloca i64
  %l108 = alloca i1
  %l112 = alloca i64
  %l114 = alloca i1
  %l119 = alloca i1
  %l121 = alloca ptr
  %l123 = alloca i64
  %l124 = alloca %"compiler/mir:Local"
  %l126 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l137 = alloca %"compiler/lower:CloneHand"
  %s7 = alloca %olang.scope
  %t237 = alloca { i64, [2 x i64] }, align 8
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/mir:Call" %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 0
  %t9 = load { i64, [7 x i64] }, ptr %t8
  store { i64, [7 x i64] } %t9, ptr %l7
  %t11 = load { i64, [7 x i64] }, ptr %l7
  %t13 = extractvalue { i64, [7 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 2
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t17 = getelementptr { { i64, [4 x i64] } }, ptr %t16, i32 0, i32 0
  %t18 = load { i64, [4 x i64] }, ptr %t17
  store { i64, [4 x i64] } %t18, ptr %l8
  br label %bb3
bb2:
  br label %bb23
bb3:
  %t20 = load { i64, [4 x i64] }, ptr %l8
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = call { i64, [4 x i64] } @compiler_2flower_2eKnownOf(ptr %v3, { i64, [4 x i64] } %t20, { i64, ptr } %t21)
  store { i64, [4 x i64] } %t24, ptr %l33
  br label %bb4
bb4:
  %t25 = load { i64, [4 x i64] }, ptr %l33
  store { i64, [4 x i64] } %t25, ptr %l9
  %t26 = load { i64, [4 x i64] }, ptr %l9
  %t28 = extractvalue { i64, [4 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = getelementptr { i64, [4 x i64] }, ptr %l9, i32 0, i32 1
  %t32 = getelementptr { i64 }, ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %t32
  store i64 %t33, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  br label %bb17
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/lower:CloneSum", ptr %t35, i32 0, i32 2
  %t38 = load i64, ptr %l10, !tbaa !24
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l40
  br label %bb8
bb8:
  %t42 = load i64, ptr %l40, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load i64, ptr %l5, !tbaa !24
  store i64 %t45, ptr %l43, !tbaa !24
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/lower:CloneSum", ptr %t46, i32 0, i32 2
  %t49 = load i64, ptr %l10, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l47
  br label %bb11
bb10:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb12
bb11:
  %t53 = load i64, ptr %l43, !tbaa !24
  %t54 = load i64, ptr %l47, !tbaa !24
  %t55 = icmp sgt i64 %t53, %t54
  store i1 %t55, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l42, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/lower:CloneSum", ptr %t58, i32 0, i32 2
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v1, ptr %t60, i64 %t61, i64 %t62)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_1c8e237ef9fc0f77_d8ac58b856c76263)
  unreachable
bb22:
  br label %bb77
bb23:
  %t66 = load { i64, [7 x i64] }, ptr %l7
  %t68 = extractvalue { i64, [7 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 0
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t71 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t72 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t71, i32 0, i32 0
  %t73 = load { i64, [2 x i64] }, ptr %t72
  %t75 = extractvalue { i64, [2 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 0
  store i1 %t76, ptr %l55, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb26
bb26:
  %t78 = load i1, ptr %l55, !tbaa !21
  br i1 %t78, label %bb27, label %bb28
bb27:
  %t79 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t80 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t79, i32 0, i32 0
  %t81 = getelementptr { i64, [2 x i64] }, ptr %t80, i32 0, i32 1
  %t82 = getelementptr { i32 }, ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l11, !tbaa !23
  %t85 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t86 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t85, i32 0, i32 1
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l12, !tbaa !23
  br label %bb29
bb28:
  br label %bb72
bb29:
  %t89 = load ptr, ptr %l6, !tbaa !29
  store ptr %t89, ptr %l60, !tbaa !29
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t91 = load i32, ptr %l12, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l63
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l60, !tbaa !29
  %t96 = load i32, ptr %l63, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t95, i32 %t96)
  store { i64, ptr } %t97, ptr %l64
  br label %bb31
bb31:
  %t98 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t98, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t99 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 1
  %t100 = getelementptr %"compiler/mir:Range", ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100, !tbaa !23
  %t103 = sext i32 %t101 to i64
  store i64 %t103, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t105 = load i64, ptr %l15, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb32, label %bb33
bb32:
  %t111 = load i64, ptr %l16, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb37
bb34:
  %t115 = load i64, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l16, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l16, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l73, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb36
bb36:
  %t131 = load i64, ptr %l73, !tbaa !24
  store i64 %t131, ptr %l70, !tbaa !24
  br label %bb37
bb37:
  %t132 = load i64, ptr %l70, !tbaa !24
  store i64 %t132, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t133 = load i64, ptr %l18, !tbaa !24
  %t134 = load i64, ptr %l17, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb40:
  br label %bb41
bb41:
  %t141 = load i64, ptr %l14, !tbaa !24
  %t142 = load i64, ptr %l18, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = mul i64 %t142, %t143
  %t149 = add i64 %t141, %t146
  store i64 %t149, ptr %l19, !tbaa !24
  %t151 = load ptr, ptr %l2, !tbaa !29
  %t153 = getelementptr %"compiler/mir:Fn", ptr %t151, i32 0, i32 11
  %t154 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 1
  %t155 = getelementptr %"compiler/mir:Range", ptr %t154, i32 0, i32 0
  %t156 = load i32, ptr %t155, !tbaa !23
  %t158 = sext i32 %t156 to i64
  %t159 = load i64, ptr %l19, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t165 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v2, ptr %t153, i64 %t162)
  store { i64, [4 x i64] } %t165, ptr %l97
  br label %bb42
bb42:
  %t166 = load { i64, [4 x i64] }, ptr %l97
  store { i64, [4 x i64] } %t166, ptr %l20
  %t167 = load { i64, [4 x i64] }, ptr %l20
  %t168 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t171 = call { i64, [4 x i64] } @compiler_2flower_2eKnownOf(ptr %v3, { i64, [4 x i64] } %t167, { i64, ptr } %t168)
  store { i64, [4 x i64] } %t171, ptr %l100
  br label %bb43
bb43:
  %t172 = load { i64, [4 x i64] }, ptr %l100
  store { i64, [4 x i64] } %t172, ptr %l21
  %t173 = load { i64, [4 x i64] }, ptr %l21
  %t175 = extractvalue { i64, [4 x i64] } %t173, 0
  %t176 = icmp eq i64 %t175, 1
  br i1 %t176, label %bb44, label %bb45
bb44:
  %t178 = getelementptr { i64, [4 x i64] }, ptr %l21, i32 0, i32 1
  %t179 = getelementptr { i64 }, ptr %t178, i32 0, i32 0
  %t180 = load i64, ptr %t179
  store i64 %t180, ptr %l22, !tbaa !24
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t182 = load i64, ptr %l22, !tbaa !24
  store i64 %t182, ptr %l101, !tbaa !24
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store i64 -1, ptr %l101, !tbaa !24
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_3bb6ecc05d6dab56_3c8834dd1d368462)
  unreachable
bb52:
  %t184 = load i64, ptr %l101, !tbaa !24
  store i64 %t184, ptr %l23, !tbaa !24
  %t185 = load i64, ptr %l23, !tbaa !24
  %t187 = icmp slt i64 %t185, 0
  br i1 %t187, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb56
bb54:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/lower:CloneSum", ptr %t189, i32 0, i32 2
  %t192 = load i64, ptr %l23, !tbaa !24
  %t195 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l112
  br label %bb55
bb55:
  %t196 = load i64, ptr %l112, !tbaa !24
  %t197 = icmp slt i64 %t196, 0
  store i1 %t197, ptr %l108, !tbaa !21
  br label %bb56
bb56:
  %t199 = load i1, ptr %l108, !tbaa !21
  br i1 %t199, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb59
bb58:
  %t200 = load i64, ptr %l19, !tbaa !24
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t206 = icmp sge i64 %t200, %t203
  store i1 %t206, ptr %l114, !tbaa !21
  br label %bb59
bb59:
  %t208 = load i1, ptr %l114, !tbaa !21
  br i1 %t208, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb64
bb61:
  %t209 = load ptr, ptr %l2, !tbaa !29
  %t211 = getelementptr %"compiler/mir:Fn", ptr %t209, i32 0, i32 7
  store ptr %t211, ptr %l121, !tbaa !29
  %t212 = load { i64, [4 x i64] }, ptr %l20
  %t214 = call i64 @compiler_2flower_2ewholeLocal({ i64, [4 x i64] } %t212)
  store i64 %t214, ptr %l123
  br label %bb62
bb62:
  %t215 = load ptr, ptr %l121, !tbaa !29
  %t216 = load i64, ptr %l123, !tbaa !24
  %t217 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v2, ptr %t215, i64 %t216)
  store %"compiler/mir:Local" %t217, ptr %l124
  br label %bb63
bb63:
  %t218 = getelementptr %"compiler/mir:Local", ptr %l124, i32 0, i32 2
  %t219 = load i32, ptr %t218, !tbaa !23
  %t220 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t220, ptr %l126, !tbaa !27
  %t221 = load i64, ptr %l19, !tbaa !24
  %t223 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i32, ptr %t224, i64 %t221
  %t226 = load i32, ptr %t225, !tbaa !33
  %t229 = icmp ne i32 %t219, %t226
  store i1 %t229, ptr %l119, !tbaa !21
  br label %bb64
bb64:
  %t231 = load i1, ptr %l119, !tbaa !21
  br i1 %t231, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb66:
  br label %bb67
bb67:
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr %"compiler/lower:CloneSum", ptr %t232, i32 0, i32 3
  store ptr %t234, ptr %l131, !tbaa !29
  %t235 = load i64, ptr %l23, !tbaa !24
  %t236 = load i32, ptr %l11, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [2 x i64] }, ptr %t237, i32 0, i32 0
  store i64 0, ptr %t238
  %t240 = insertvalue { i32 } undef, i32 %t236, 0
  %t241 = getelementptr { i64, [2 x i64] }, ptr %t237, i32 0, i32 1
  store { i32 } %t240, ptr %t241
  %t242 = load { i64, [2 x i64] }, ptr %t237
  %t243 = load i64, ptr %l19, !tbaa !24
  %t244 = load i64, ptr %l5, !tbaa !24
  %t249 = call %"compiler/lower:CloneHand" @compiler_2flower_3aCloneHand_2ector(ptr %s7, i64 %t235, { i64, [2 x i64] } %t242, i64 %t243, i64 %t244)
  store %"compiler/lower:CloneHand" %t249, ptr %l137
  br label %bb68
bb68:
  %t250 = load ptr, ptr %l131, !tbaa !29
  %t251 = load %"compiler/lower:CloneHand", ptr %l137
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e_2ePush_H85e09a50fcd8a8472d6e0741db5df478(ptr %v1, ptr %t250, %"compiler/lower:CloneHand" %t251)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb70:
  %t252 = load i64, ptr %l18, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l18, !tbaa !24
  br label %bb38
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_f74ed6c6f28c676d_f94a3fd07e079859)
  unreachable
bb77:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epayPlan(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i64 %a2, i64 %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/lower:CloneHand"
  %l16 = alloca i64
  %l19 = alloca i64
  %l23 = alloca %"compiler/lower:CloneSum"
  %l27 = alloca i1
  %l28 = alloca i64
  %l32 = alloca %"compiler/lower:CloneSum"
  %l34 = alloca i64
  %l36 = alloca i1
  %l40 = alloca %"compiler/lower:CloneSum"
  %l43 = alloca i64
  %l49 = alloca %"compiler/lower:CloneSum"
  %l52 = alloca i64
  %l56 = alloca %"compiler/lower:CloneSum"
  %l61 = alloca %"compiler/lower:CloneSum"
  %l63 = alloca %"compiler/lower:CloneSum"
  %l65 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca ptr
  %l71 = alloca %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef"
  %l79 = alloca { i64, ptr }
  %l85 = alloca i1
  %l89 = alloca i1
  %l94 = alloca i1
  %l102 = alloca i64
  %l105 = alloca i1
  %l124 = alloca i1
  %l126 = alloca i64
  %l130 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ecloneSum(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:Lowerer", ptr %t7, i32 0, i32 55
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = call %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %s0, ptr %t9, i64 %t10)
  store %"compiler/lower:CloneSum" %t13, ptr %l23
  br label %bb2
bb2:
  %t14 = getelementptr %"compiler/lower:CloneSum", ptr %l23, i32 0, i32 0
  %t15 = load i1, ptr %t14, !tbaa !21
  %t19 = xor i1 %t15, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb7
bb4:
  %t21 = load i64, ptr %l2, !tbaa !24
  store i64 %t21, ptr %l28, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:Lowerer", ptr %t22, i32 0, i32 55
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = call %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/lower:CloneSum" %t28, ptr %l32
  br label %bb5
bb5:
  %t29 = getelementptr %"compiler/lower:CloneSum", ptr %l32, i32 0, i32 2
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l34
  br label %bb6
bb6:
  %t32 = load i64, ptr %l28, !tbaa !24
  %t33 = load i64, ptr %l34, !tbaa !24
  %t34 = icmp sge i64 %t32, %t33
  store i1 %t34, ptr %l27, !tbaa !21
  br label %bb7
bb7:
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb12
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:Lowerer", ptr %t37, i32 0, i32 55
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = call %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %v0, ptr %t39, i64 %t40)
  store %"compiler/lower:CloneSum" %t43, ptr %l40
  br label %bb10
bb10:
  %t44 = getelementptr %"compiler/lower:CloneSum", ptr %l40, i32 0, i32 2
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t48, ptr %l43
  br label %bb11
bb11:
  %t49 = load i64, ptr %l43, !tbaa !24
  %t50 = icmp slt i64 %t49, 0
  store i1 %t50, ptr %l36, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l36, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lower:Lowerer", ptr %t54, i32 0, i32 55
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = call %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store %"compiler/lower:CloneSum" %t60, ptr %l49
  br label %bb16
bb16:
  %t61 = getelementptr %"compiler/lower:CloneSum", ptr %l49, i32 0, i32 2
  %t62 = load i64, ptr %l2, !tbaa !24
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l52
  br label %bb17
bb17:
  %t66 = load i64, ptr %l52, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:Lowerer", ptr %t67, i32 0, i32 55
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = call %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %s0, ptr %t69, i64 %t70)
  store %"compiler/lower:CloneSum" %t73, ptr %l56
  br label %bb18
bb18:
  %t74 = getelementptr %"compiler/lower:CloneSum", ptr %l56, i32 0, i32 1
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l9, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:Lowerer", ptr %t77, i32 0, i32 55
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = call %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store %"compiler/lower:CloneSum" %t83, ptr %l61
  br label %bb19
bb19:
  %t85 = call %"compiler/lower:CloneSum" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3aCloneSum(ptr %v0, ptr %l61)
  store %"compiler/lower:CloneSum" %t85, ptr %l63
  br label %bb20
bb20:
  %t86 = getelementptr %"compiler/lower:CloneSum", ptr %l63, i32 0, i32 3
  %t88 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e_2eToAr_Hf2705ae9b9c3665d2bce5131843165c9(ptr %v0, ptr %s0, ptr %t86)
  store { i64, ptr } %t88, ptr %l65
  br label %bb21
bb21:
  %t89 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t89, ptr %l10, !tbaa !27
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H4f55ef78e9e24b109145d8f1cf8f3346(ptr %v1, ptr %t90)
  store i64 %t92, ptr %l67
  br label %bb22
bb22:
  %t93 = load i64, ptr %l67, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  %t94 = load ptr, ptr %l4, !tbaa !29
  store ptr %t94, ptr %l68, !tbaa !29
  %t95 = load { i64, [2 x i64] }, ptr %l1
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = call %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" @std_2fpair_3aPair_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %s0, { i64, [2 x i64] } %t95, i64 %t96)
  store %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" %t99, ptr %l71
  br label %bb23
bb23:
  %t100 = load ptr, ptr %l68, !tbaa !29
  %t101 = load %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef", ptr %l71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H50aa64e76645cf352fa094d09391d67b(ptr %v1, ptr %t100, %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" %t101)
  br label %bb24
bb24:
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t102, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l14, !tbaa !24
  br label %bb25
bb25:
  %t108 = load i64, ptr %l13, !tbaa !24
  %t109 = load i64, ptr %l14, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb26, label %bb27
bb26:
  br label %bb47
bb27:
  br label %bb28
bb28:
  %t116 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t116, ptr %l79, !tbaa !27
  %t117 = load i64, ptr %l13, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr %"compiler/lower:CloneHand", ptr %t120, i64 %t117
  %t122 = load %"compiler/lower:CloneHand", ptr %t121
  store %"compiler/lower:CloneHand" %t122, ptr %l15
  %t124 = getelementptr %"compiler/lower:CloneHand", ptr %l15, i32 0, i32 0
  %t125 = load i64, ptr %t124, !tbaa !24
  %t126 = load i64, ptr %l2, !tbaa !24
  %t129 = icmp ne i64 %t125, %t126
  br i1 %t129, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb31
bb30:
  %t131 = load i64, ptr %l3, !tbaa !24
  %t132 = load i64, ptr @G_2ecompiler_2flower_2eCloneDepth, !tbaa !24
  %t135 = icmp sge i64 %t131, %t132
  store i1 %t135, ptr %l85, !tbaa !21
  br label %bb31
bb31:
  %t137 = load i1, ptr %l85, !tbaa !21
  br i1 %t137, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb35
bb33:
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t139 = load i64, ptr %l5, !tbaa !24
  %t140 = getelementptr %"compiler/lower:CloneHand", ptr %l15, i32 0, i32 1
  %t141 = load { i64, [2 x i64] }, ptr %t140
  %t142 = getelementptr %"compiler/lower:CloneHand", ptr %l15, i32 0, i32 2
  %t143 = load i64, ptr %t142, !tbaa !24
  %t148 = call i1 @compiler_2flower_2eplanHas(ptr %v1, ptr %t138, i64 %t139, { i64, [2 x i64] } %t141, i64 %t143)
  store i1 %t148, ptr %l94
  br label %bb34
bb34:
  %t149 = load i1, ptr %l94, !tbaa !21
  store i1 %t149, ptr %l89, !tbaa !21
  br label %bb35
bb35:
  %t150 = load i1, ptr %l89, !tbaa !21
  br i1 %t150, label %bb36, label %bb37
bb36:
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/lower:CloneHand", ptr %l15, i32 0, i32 1
  %t153 = load { i64, [2 x i64] }, ptr %t152
  %t154 = getelementptr %"compiler/lower:CloneHand", ptr %l15, i32 0, i32 2
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = load i64, ptr %l3, !tbaa !24
  %t158 = add i64 %t156, 1
  %t159 = load ptr, ptr %l4, !tbaa !29
  %t160 = load i64, ptr %l5, !tbaa !24
  %t167 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epayPlan(ptr %v0, ptr %v1, ptr %t151, { i64, [2 x i64] } %t153, i64 %t155, i64 %t158, ptr %t159, i64 %t160)
  store i64 %t167, ptr %l102
  br label %bb39
bb39:
  %t168 = load i64, ptr %l102, !tbaa !24
  store i64 %t168, ptr %l16, !tbaa !24
  %t169 = load i64, ptr %l16, !tbaa !24
  %t171 = icmp sgt i64 %t169, 0
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t173 = load i64, ptr %l16, !tbaa !24
  %t174 = getelementptr %"compiler/lower:CloneHand", ptr %l15, i32 0, i32 3
  %t175 = load i64, ptr %t174, !tbaa !24
  %t178 = add i64 %t173, %t175
  %t179 = load i64, ptr %l8, !tbaa !24
  %t182 = icmp sgt i64 %t178, %t179
  store i1 %t182, ptr %l105, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb42
bb42:
  %t184 = load i1, ptr %l105, !tbaa !21
  br i1 %t184, label %bb43, label %bb44
bb43:
  %t185 = load i64, ptr %l16, !tbaa !24
  %t186 = getelementptr %"compiler/lower:CloneHand", ptr %l15, i32 0, i32 3
  %t187 = load i64, ptr %t186, !tbaa !24
  %t190 = add i64 %t185, %t187
  store i64 %t190, ptr %l8, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t192 = load i64, ptr %l13, !tbaa !24
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %l13, !tbaa !24
  br label %bb25
bb47:
  %t197 = load i64, ptr %l8, !tbaa !24
  %t199 = icmp sle i64 %t197, 0
  br i1 %t199, label %bb48, label %bb49
bb48:
  %t201 = load ptr, ptr %l4, !tbaa !29
  %t202 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_Heb9f32f192b0b9cb232597ba4ed0fe11(ptr %v1, ptr %t201, i64 %t202)
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb51:
  %t206 = load i64, ptr %l3, !tbaa !24
  %t208 = icmp eq i64 %t206, 0
  br i1 %t208, label %bb52, label %bb53
bb52:
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H4f55ef78e9e24b109145d8f1cf8f3346(ptr %v1, ptr %t210)
  store i64 %t212, ptr %l126
  br label %bb54
bb53:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb55
bb54:
  %t213 = load i64, ptr %l11, !tbaa !24
  %t215 = add i64 %t213, 1
  %t216 = load i64, ptr %l126, !tbaa !24
  %t218 = icmp eq i64 %t216, %t215
  store i1 %t218, ptr %l124, !tbaa !21
  br label %bb55
bb55:
  %t220 = load i1, ptr %l124, !tbaa !21
  br i1 %t220, label %bb56, label %bb57
bb56:
  %t221 = load i64, ptr %l9, !tbaa !24
  %t222 = load i64, ptr @G_2ecompiler_2flower_2eCloneSmall, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  store i1 %t225, ptr %l130, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb58
bb58:
  %t227 = load i1, ptr %l130, !tbaa !21
  br i1 %t227, label %bb59, label %bb60
bb59:
  %t228 = load ptr, ptr %l4, !tbaa !29
  %t229 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_Heb9f32f192b0b9cb232597ba4ed0fe11(ptr %v1, ptr %t228, i64 %t229)
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb62:
  %t233 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t233, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, [4 x i64] }
  %l21 = alloca i1
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca %"compiler/mir:Lvalue"
  %l41 = alloca i64
  %l43 = alloca i1
  %l45 = alloca ptr
  %l47 = alloca i32
  %l69 = alloca { i64, ptr }
  %l81 = alloca i1
  %l89 = alloca { i64, [4 x i64] }
  %l90 = alloca ptr
  %l92 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/mir:Lvalue"
  %l99 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l131 = alloca i1
  %l139 = alloca { i64, [4 x i64] }
  %l140 = alloca ptr
  %l142 = alloca %"compiler/source:Span"
  %l144 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t43 = alloca { i64, [15 x i64] }, align 8
  %t49 = alloca { i64, [21 x i64] }, align 8
  %t178 = alloca { i64, [15 x i64] }, align 8
  %t184 = alloca { i64, [21 x i64] }, align 8
  %t293 = alloca { i64, [15 x i64] }, align 8
  %t299 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Arm", ptr %t8, i32 0, i32 4
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb12
bb3:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t21 = icmp ne i32 %t17, %t18
  store i1 %t21, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Arm", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t24, ptr %t28)
  store { i64, [4 x i64] } %t32, ptr %l29
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t33 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t33, ptr %l3
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l30, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Arm", ptr %t35, i32 0, i32 0
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l32
  %t39 = load i32, ptr %l2, !tbaa !23
  %t41 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t39)
  store %"compiler/mir:Lvalue" %t41, ptr %l34
  br label %bb9
bb9:
  %t42 = load { i64, [4 x i64] }, ptr %l3
  store { i64, [15 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [15 x i64] }, ptr %t43, i32 0, i32 0
  store i64 0, ptr %t44
  %t46 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t42, 0
  %t47 = getelementptr { i64, [15 x i64] }, ptr %t43, i32 0, i32 1
  store { { i64, [4 x i64] } } %t46, ptr %t47
  %t48 = load { i64, [15 x i64] }, ptr %t43
  store { i64, [21 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [21 x i64] }, ptr %t49, i32 0, i32 0
  store i64 0, ptr %t50
  %t51 = load %"compiler/source:Span", ptr %l32
  %t52 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t51, 0
  %t53 = load %"compiler/mir:Lvalue", ptr %l34
  %t54 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t52, %"compiler/mir:Lvalue" %t53, 1
  %t56 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t54, { i64, [15 x i64] } %t48, 2
  %t57 = getelementptr { i64, [21 x i64] }, ptr %t49, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t56, ptr %t57
  %t58 = load { i64, [21 x i64] }, ptr %t49
  %t60 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t58, ptr %t60
  %t61 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %v3, ptr %v2, ptr %t61, ptr %t60)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 14
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l41
  br label %bb13
bb13:
  %t68 = load i64, ptr %l41, !tbaa !24
  %t69 = icmp sgt i64 %t68, 0
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %s0, ptr %t71)
  store ptr %t73, ptr %l45
  br label %bb16
bb15:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb20
bb16:
  %t74 = load ptr, ptr %l45, !tbaa !29
  %t76 = getelementptr %"compiler/lower:level", ptr %t74, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  store i32 %t77, ptr %l47, !tbaa !23
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Arm", ptr %t78, i32 0, i32 3
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  br i1 %t83, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2262f7260befbeda_ad33d1a86099f68e)
  unreachable
bb18:
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Arm", ptr %t85, i32 0, i32 3
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Block", ptr %t88, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = load i32, ptr %l47, !tbaa !23
  %t95 = icmp eq i32 %t93, %t92
  store i1 %t95, ptr %l43, !tbaa !21
  br label %bb20
bb20:
  %t97 = load i1, ptr %l43, !tbaa !21
  br i1 %t97, label %bb21, label %bb22
bb21:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Arm", ptr %t98, i32 0, i32 3
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb23, label %bb24
bb22:
  br label %bb42
bb23:
  call void @__olang_check_failed(ptr @olang_loc_78466967dd42e061_bdc585e3e8213235)
  unreachable
bb24:
  br label %bb25
bb25:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Arm", ptr %t105, i32 0, i32 3
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Block", ptr %t108, i32 0, i32 1
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t126 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t126, ptr %l69, !tbaa !27
  %t127 = load i64, ptr %l5, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  %t134 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %v4, ptr %v2, ptr %v3, ptr %v5, ptr %t134, ptr %t132)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t138 = load i64, ptr %l5, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l5, !tbaa !24
  br label %bb26
bb32:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Arm", ptr %t143, i32 0, i32 4
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb33, label %bb34
bb33:
  %t152 = load i32, ptr %l2, !tbaa !23
  %t153 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t156 = icmp ne i32 %t152, %t153
  store i1 %t156, ptr %l81, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb35
bb35:
  %t158 = load i1, ptr %l81, !tbaa !21
  br i1 %t158, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Arm", ptr %t160, i32 0, i32 4
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t167 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t159, ptr %t163)
  store { i64, [4 x i64] } %t167, ptr %l89
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t168 = load { i64, [4 x i64] }, ptr %l89
  store { i64, [4 x i64] } %t168, ptr %l8
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l90, !tbaa !29
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Arm", ptr %t170, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l92
  %t174 = load i32, ptr %l2, !tbaa !23
  %t176 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t174)
  store %"compiler/mir:Lvalue" %t176, ptr %l94
  br label %bb39
bb39:
  %t177 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [15 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [15 x i64] }, ptr %t178, i32 0, i32 0
  store i64 0, ptr %t179
  %t181 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t177, 0
  %t182 = getelementptr { i64, [15 x i64] }, ptr %t178, i32 0, i32 1
  store { { i64, [4 x i64] } } %t181, ptr %t182
  %t183 = load { i64, [15 x i64] }, ptr %t178
  store { i64, [21 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [21 x i64] }, ptr %t184, i32 0, i32 0
  store i64 0, ptr %t185
  %t186 = load %"compiler/source:Span", ptr %l92
  %t187 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t186, 0
  %t188 = load %"compiler/mir:Lvalue", ptr %l94
  %t189 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t187, %"compiler/mir:Lvalue" %t188, 1
  %t191 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t189, { i64, [15 x i64] } %t183, 2
  %t192 = getelementptr { i64, [21 x i64] }, ptr %t184, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t191, ptr %t192
  %t193 = load { i64, [21 x i64] }, ptr %t184
  %t195 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t193, ptr %t195
  %t196 = load ptr, ptr %l90, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %v3, ptr %v2, ptr %t196, ptr %t195)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l99, !tbaa !29
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/typed:Arm", ptr %t199, i32 0, i32 3
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  br i1 %t204, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6143a96035d3ceac_ef612191f7538720)
  unreachable
bb44:
  br label %bb45
bb45:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Arm", ptr %t206, i32 0, i32 3
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t210 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %v4, ptr %v3, ptr %v2, ptr %t210, ptr %t209, i32 1, i32 0)
  br label %bb46
bb46:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Arm", ptr %t213, i32 0, i32 3
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = icmp eq ptr %t216, null
  br i1 %t218, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_9919e1798def049b_eb223155b689b93f)
  unreachable
bb48:
  br label %bb49
bb49:
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Arm", ptr %t220, i32 0, i32 3
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t226 = getelementptr %"compiler/typed:Block", ptr %t223, i32 0, i32 1
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  store { i64, ptr } %t227, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  store i64 %t231, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  %t233 = load i64, ptr %l10, !tbaa !24
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = icmp slt i64 %t233, %t234
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb51, label %bb52
bb51:
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t241 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t241, ptr %l119, !tbaa !27
  %t242 = load i64, ptr %l10, !tbaa !24
  %t244 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 %t242
  %t247 = load ptr, ptr %t246, !tbaa !39
  %t249 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %v4, ptr %v2, ptr %v3, ptr %v5, ptr %t249, ptr %t247)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t253 = load i64, ptr %l10, !tbaa !24
  %t256 = add i64 %t253, 1
  store i64 %t256, ptr %l10, !tbaa !24
  br label %bb50
bb56:
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr %"compiler/typed:Arm", ptr %t258, i32 0, i32 4
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t263 = icmp eq ptr %t261, null
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb57, label %bb58
bb57:
  %t267 = load i32, ptr %l2, !tbaa !23
  %t268 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t271 = icmp ne i32 %t267, %t268
  store i1 %t271, ptr %l131, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb59
bb59:
  %t273 = load i1, ptr %l131, !tbaa !21
  br i1 %t273, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Arm", ptr %t275, i32 0, i32 4
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t282 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t274, ptr %t278)
  store { i64, [4 x i64] } %t282, ptr %l139
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t283 = load { i64, [4 x i64] }, ptr %l139
  store { i64, [4 x i64] } %t283, ptr %l13
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l140, !tbaa !29
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Arm", ptr %t285, i32 0, i32 0
  %t288 = load %"compiler/source:Span", ptr %t287
  store %"compiler/source:Span" %t288, ptr %l142
  %t289 = load i32, ptr %l2, !tbaa !23
  %t291 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t289)
  store %"compiler/mir:Lvalue" %t291, ptr %l144
  br label %bb63
bb63:
  %t292 = load { i64, [4 x i64] }, ptr %l13
  store { i64, [15 x i64] } zeroinitializer, ptr %t293
  %t294 = getelementptr { i64, [15 x i64] }, ptr %t293, i32 0, i32 0
  store i64 0, ptr %t294
  %t296 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t292, 0
  %t297 = getelementptr { i64, [15 x i64] }, ptr %t293, i32 0, i32 1
  store { { i64, [4 x i64] } } %t296, ptr %t297
  %t298 = load { i64, [15 x i64] }, ptr %t293
  store { i64, [21 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [21 x i64] }, ptr %t299, i32 0, i32 0
  store i64 0, ptr %t300
  %t301 = load %"compiler/source:Span", ptr %l142
  %t302 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t301, 0
  %t303 = load %"compiler/mir:Lvalue", ptr %l144
  %t304 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t302, %"compiler/mir:Lvalue" %t303, 1
  %t306 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t304, { i64, [15 x i64] } %t298, 2
  %t307 = getelementptr { i64, [21 x i64] }, ptr %t299, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t306, ptr %t307
  %t308 = load { i64, [21 x i64] }, ptr %t299
  %t310 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 176, i64 8)
  store { i64, [21 x i64] } %t308, ptr %t310
  %t311 = load ptr, ptr %l140, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s11, ptr %v3, ptr %v2, ptr %t311, ptr %t310)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  %t313 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %v4, ptr %v3, ptr %v2, ptr %v5, ptr %t313)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eassemble(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, [1 x i64] }
  %l21 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca i32
  %l54 = alloca ptr
  %l56 = alloca i64
  %l58 = alloca i1
  %l65 = alloca ptr
  %l67 = alloca ptr
  %l69 = alloca i32
  %l72 = alloca { i64, [4 x i64] }
  %l80 = alloca ptr
  %l82 = alloca i64
  %l87 = alloca ptr
  %l89 = alloca i64
  %l93 = alloca i64
  %l96 = alloca i64
  %l114 = alloca i64
  %l116 = alloca ptr
  %l119 = alloca i32
  %l122 = alloca %"compiler/mir:Lvalue"
  %l127 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca i32
  %l133 = alloca %"compiler/mir:Range"
  %l137 = alloca { i64, [4 x i64] }
  %l142 = alloca { i64, [1 x i64] }
  %l151 = alloca { i64, [4 x i64] }
  %l152 = alloca ptr
  %l155 = alloca i32
  %l158 = alloca i1
  %l159 = alloca ptr
  %l162 = alloca i1
  %l163 = alloca i1
  %l164 = alloca ptr
  %l167 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t151 = alloca { i64, [8 x i64] }, align 8
  %t260 = alloca { i64, [4 x i64] }, align 8
  %t286 = alloca { i64, [15 x i64] }, align 8
  %t320 = alloca { i64, [15 x i64] }, align 8
  %t390 = alloca { i64, [21 x i64] }, align 8
  %t414 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l21, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t13 = load ptr, ptr %l21, !tbaa !29
  %t14 = call ptr @__olang_scope_or(ptr %v1, ptr %t13)
  %t15 = call ptr @__olang_scope_hold(ptr %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = inttoptr i64 %t16 to ptr
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t21 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t18, ptr %t19, i32 %t12)
  store i1 %t21, ptr %l24
  br label %bb1
bb1:
  %t22 = load i1, ptr %l24, !tbaa !21
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l3, !tbaa !29
  store ptr %t23, ptr %l26, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t25 = load ptr, ptr %l26, !tbaa !29
  %t26 = call ptr @__olang_scope_or(ptr %v1, ptr %t25)
  %t27 = call ptr @__olang_scope_hold(ptr %t26)
  %t28 = ptrtoint ptr %t27 to i64
  %t30 = inttoptr i64 %t28 to ptr
  %t31 = load ptr, ptr %l26, !tbaa !29
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t30, ptr %t31, i32 %t24)
  store i32 %t33, ptr %l29
  br label %bb4
bb3:
  %t34 = load i32, ptr %l1, !tbaa !23
  store i32 %t34, ptr %l25, !tbaa !23
  br label %bb5
bb4:
  %t36 = load i32, ptr %l29, !tbaa !23
  store i32 %t36, ptr %l25, !tbaa !23
  br label %bb5
bb5:
  %t37 = load i32, ptr %l25, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %l31, !tbaa !29
  %t39 = load i32, ptr %l4, !tbaa !23
  %t40 = load ptr, ptr %l31, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v1, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l31, !tbaa !29
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t45, ptr %t46, i32 %t39)
  store i32 %t48, ptr %l34
  br label %bb6
bb6:
  %t49 = load i32, ptr %l34, !tbaa !23
  store i32 %t49, ptr %l5, !tbaa !23
  %t50 = load ptr, ptr %l3, !tbaa !29
  store ptr %t50, ptr %l35, !tbaa !29
  %t51 = load i32, ptr %l5, !tbaa !23
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t53 = call ptr @__olang_scope_or(ptr %v1, ptr %t52)
  %t54 = call ptr @__olang_scope_hold(ptr %t53)
  %t55 = ptrtoint ptr %t54 to i64
  %t57 = inttoptr i64 %t55 to ptr
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t57, ptr %t58, i32 %t51)
  store i32 %t60, ptr %l38
  br label %bb7
bb7:
  %t61 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t63 = trunc i64 18 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb8, label %bb9
bb8:
  %t66 = load ptr, ptr %l3, !tbaa !29
  store ptr %t66, ptr %l42, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  store ptr %t67, ptr %l43, !tbaa !29
  %t68 = load i32, ptr %l5, !tbaa !23
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = call ptr @__olang_scope_or(ptr %v1, ptr %t69)
  %t71 = call ptr @__olang_scope_hold(ptr %t70)
  %t72 = ptrtoint ptr %t71 to i64
  %t74 = inttoptr i64 %t72 to ptr
  %t75 = load ptr, ptr %l43, !tbaa !29
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t74, ptr %t75, i32 %t68)
  store i32 %t77, ptr %l46
  br label %bb10
bb9:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb12
bb10:
  %t78 = load ptr, ptr %l42, !tbaa !29
  %t79 = call ptr @__olang_scope_or(ptr %v1, ptr %t78)
  %t80 = call ptr @__olang_scope_hold(ptr %t79)
  %t81 = ptrtoint ptr %t80 to i64
  %t83 = inttoptr i64 %t81 to ptr
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t85 = load i32, ptr %l46, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %t83, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l48
  br label %bb11
bb11:
  %t87 = load i32, ptr %l48, !range !{i32 0, i32 6}
  %t89 = trunc i64 0 to i32
  %t90 = icmp eq i32 %t87, %t89
  store i1 %t90, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t92 = load i1, ptr %l41, !tbaa !21
  %t95 = xor i1 %t92, true
  br i1 %t95, label %bb13, label %bb14
bb13:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Body", ptr %t97, i32 0, i32 10
  store ptr %t99, ptr %l54, !tbaa !29
  %t100 = load ptr, ptr %l54, !tbaa !29
  %t101 = call ptr @__olang_scope_or(ptr %v2, ptr %t100)
  %t102 = call ptr @__olang_scope_hold(ptr %t101)
  %t103 = ptrtoint ptr %t102 to i64
  %t105 = inttoptr i64 %t103 to ptr
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t105, ptr %t106)
  store i64 %t107, ptr %l56
  br label %bb15
bb14:
  br label %bb27
bb15:
  %t108 = load i64, ptr %l56, !tbaa !24
  %t109 = icmp ne i64 %t108, 1
  br i1 %t109, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb18
bb17:
  %t111 = load i32, ptr %l4, !tbaa !23
  %t112 = load i32, ptr %l1, !tbaa !23
  %t115 = icmp ne i32 %t111, %t112
  store i1 %t115, ptr %l58, !tbaa !21
  br label %bb18
bb18:
  %t117 = load i1, ptr %l58, !tbaa !21
  br i1 %t117, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 4
  %t122 = load %"compiler/source:Span", ptr %t121
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s2, ptr %v3, ptr %t118, %"compiler/source:Span" %t122, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l65, !tbaa !29
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 10
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = load ptr, ptr %l67, !tbaa !29
  %t130 = call ptr @__olang_scope_or(ptr %v2, ptr %t129)
  %t131 = call ptr @__olang_scope_hold(ptr %t130)
  %t132 = ptrtoint ptr %t131 to i64
  %t134 = inttoptr i64 %t132 to ptr
  %t135 = load ptr, ptr %l67, !tbaa !29
  %t136 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t134, ptr %t135, i64 0)
  store i32 %t136, ptr %l69
  br label %bb23
bb23:
  %t137 = load i32, ptr %l69, !tbaa !23
  %t139 = load ptr, ptr %l65, !tbaa !29
  %t141 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %t139, i32 %t137)
  store { i64, [4 x i64] } %t141, ptr %l72
  br label %bb24
bb24:
  %t142 = load { i64, [4 x i64] }, ptr %l72
  store { i64, [4 x i64] } %t142, ptr %l7
  %t143 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %t143, i64 0)
  br label %bb25
bb25:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Body", ptr %t146, i32 0, i32 4
  %t149 = load %"compiler/source:Span", ptr %t148
  %t150 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [8 x i64] } zeroinitializer, ptr %t151
  %t152 = getelementptr { i64, [8 x i64] }, ptr %t151, i32 0, i32 0
  store i64 5, ptr %t152
  %t154 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t149, 0
  %t156 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t154, { i64, [4 x i64] } %t150, 1
  %t157 = getelementptr { i64, [8 x i64] }, ptr %t151, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t156, ptr %t157
  %t158 = load { i64, [8 x i64] }, ptr %t151
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v3, ptr %v1, ptr %t145, { i64, [8 x i64] } %t158)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 10
  store ptr %t163, ptr %l80, !tbaa !29
  %t164 = load ptr, ptr %l80, !tbaa !29
  %t165 = call ptr @__olang_scope_or(ptr %v2, ptr %t164)
  %t166 = call ptr @__olang_scope_hold(ptr %t165)
  %t167 = ptrtoint ptr %t166 to i64
  %t169 = inttoptr i64 %t167 to ptr
  %t170 = load ptr, ptr %l80, !tbaa !29
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t169, ptr %t170)
  store i64 %t171, ptr %l82
  br label %bb28
bb28:
  %t172 = load i64, ptr %l82, !tbaa !24
  %t173 = icmp sge i64 %t172, 0
  br i1 %t173, label %bb29, label %bb30
bb29:
  %t175 = load i64, ptr %l82, !tbaa !24
  %t176 = icmp sle i64 %t175, 230584300921369395
  br i1 %t176, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de)
  unreachable
bb31:
  %t178 = load i64, ptr %l82, !tbaa !24
  %t179 = mul i64 %t178, 40
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t186 = getelementptr %"compiler/typed:Body", ptr %t184, i32 0, i32 10
  store ptr %t186, ptr %l87, !tbaa !29
  %t187 = load ptr, ptr %l87, !tbaa !29
  %t188 = call ptr @__olang_scope_or(ptr %v2, ptr %t187)
  %t189 = call ptr @__olang_scope_hold(ptr %t188)
  %t190 = ptrtoint ptr %t189 to i64
  %t192 = inttoptr i64 %t190 to ptr
  %t193 = load ptr, ptr %l87, !tbaa !29
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t192, ptr %t193)
  store i64 %t194, ptr %l89
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de)
  unreachable
bb33:
  %t195 = load i64, ptr %l89, !tbaa !24
  store i64 %t195, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t196 = load i64, ptr %l10, !tbaa !24
  %t197 = load i64, ptr %l9, !tbaa !24
  %t200 = icmp sgt i64 %t196, %t197
  br i1 %t200, label %bb34, label %bb35
bb34:
  %t202 = load i64, ptr %l11, !tbaa !24
  %t204 = icmp sgt i64 %t202, 0
  br i1 %t204, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb39
bb36:
  %t206 = load i64, ptr %l10, !tbaa !24
  %t207 = load i64, ptr %l9, !tbaa !24
  %t210 = sub i64 %t206, %t207
  %t211 = load i64, ptr %l11, !tbaa !24
  %t214 = add i64 %t210, %t211
  %t216 = sub i64 %t214, 1
  %t217 = load i64, ptr %l11, !tbaa !24
  %t220 = sdiv i64 %t216, %t217
  store i64 %t220, ptr %l96, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb38
bb38:
  %t222 = load i64, ptr %l96, !tbaa !24
  store i64 %t222, ptr %l93, !tbaa !24
  br label %bb39
bb39:
  %t223 = load i64, ptr %l93, !tbaa !24
  store i64 %t223, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb40
bb40:
  %t224 = load i64, ptr %l13, !tbaa !24
  %t225 = load i64, ptr %l12, !tbaa !24
  %t228 = icmp slt i64 %t224, %t225
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb41, label %bb42
bb41:
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t232 = load i64, ptr %l9, !tbaa !24
  %t233 = load i64, ptr %l13, !tbaa !24
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = mul i64 %t233, %t234
  %t240 = add i64 %t232, %t237
  store i64 %t240, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l14, !tbaa !24
  store i64 %t242, ptr %l114, !tbaa !24
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Body", ptr %t243, i32 0, i32 10
  store ptr %t245, ptr %l116, !tbaa !29
  %t246 = load i64, ptr %l14, !tbaa !24
  %t247 = load ptr, ptr %l116, !tbaa !29
  %t248 = call ptr @__olang_scope_or(ptr %v2, ptr %t247)
  %t249 = call ptr @__olang_scope_hold(ptr %t248)
  %t250 = ptrtoint ptr %t249 to i64
  %t252 = inttoptr i64 %t250 to ptr
  %t253 = load ptr, ptr %l116, !tbaa !29
  %t255 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t252, ptr %t253, i64 %t246)
  store i32 %t255, ptr %l119
  br label %bb44
bb44:
  %t256 = load i32, ptr %l119, !tbaa !23
  %t259 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t256)
  store %"compiler/mir:Lvalue" %t259, ptr %l122
  br label %bb45
bb45:
  store { i64, [4 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [4 x i64] }, ptr %t260, i32 0, i32 0
  store i64 1, ptr %t261
  %t262 = load %"compiler/mir:Lvalue", ptr %l122
  %t263 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t262, 0
  %t264 = getelementptr { i64, [4 x i64] }, ptr %t260, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t263, ptr %t264
  %t265 = load { i64, [4 x i64] }, ptr %t260
  %t267 = load i64, ptr %l114, !tbaa !24
  %t268 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr { i64, [4 x i64] }, ptr %t269, i64 %t267
  store { i64, [4 x i64] } %t265, ptr %t270
  br label %bb46
bb46:
  %t271 = load i64, ptr %l13, !tbaa !24
  %t274 = add i64 %t271, 1
  store i64 %t274, ptr %l13, !tbaa !24
  br label %bb40
bb47:
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l127, !tbaa !29
  %t277 = load i32, ptr %l4, !tbaa !23
  store i32 %t277, ptr %l128, !tbaa !23
  %t278 = load i32, ptr %l4, !tbaa !23
  store i32 %t278, ptr %l129, !tbaa !23
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/lower:lowering", ptr %t279, i32 0, i32 3
  %t282 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t285 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t281, { i64, ptr } %t282)
  store %"compiler/mir:Range" %t285, ptr %l133
  br label %bb48
bb48:
  store { i64, [15 x i64] } zeroinitializer, ptr %t286
  %t287 = getelementptr { i64, [15 x i64] }, ptr %t286, i32 0, i32 0
  store i64 6, ptr %t287
  %t288 = load i32, ptr %l129, !tbaa !23
  %t289 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t288, 0
  %t290 = insertvalue { i32, i64, %"compiler/mir:Range" } %t289, i64 0, 1
  %t291 = load %"compiler/mir:Range", ptr %l133
  %t292 = insertvalue { i32, i64, %"compiler/mir:Range" } %t290, %"compiler/mir:Range" %t291, 2
  %t293 = getelementptr { i64, [15 x i64] }, ptr %t286, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t292, ptr %t293
  %t294 = load { i64, [15 x i64] }, ptr %t286
  %t295 = load ptr, ptr %l2, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Body", ptr %t295, i32 0, i32 4
  %t298 = load %"compiler/source:Span", ptr %t297
  %t299 = load ptr, ptr %l127, !tbaa !29
  %t300 = load i32, ptr %l128, !tbaa !23
  %t303 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v3, ptr %t299, i32 %t300, { i64, [15 x i64] } %t294, %"compiler/source:Span" %t298)
  store { i64, [4 x i64] } %t303, ptr %l137
  br label %bb49
bb49:
  %t304 = load { i64, [4 x i64] }, ptr %l137
  store { i64, [4 x i64] } %t304, ptr %l15
  %t305 = load i32, ptr %l4, !tbaa !23
  %t306 = load i32, ptr %l1, !tbaa !23
  %t309 = icmp ne i32 %t305, %t306
  br i1 %t309, label %bb50, label %bb51
bb50:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %v2, ptr %t311)
  store { i64, [1 x i64] } %t313, ptr %l142
  br label %bb52
bb51:
  br label %bb67
bb52:
  %t314 = load { i64, [1 x i64] }, ptr %l142
  store { i64, [1 x i64] } %t314, ptr %l16
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load i32, ptr %l1, !tbaa !23
  %t317 = load { i64, [1 x i64] }, ptr %l16
  %t318 = load { i64, [4 x i64] }, ptr %l15
  %t319 = load i32, ptr %l1, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t320
  %t321 = getelementptr { i64, [15 x i64] }, ptr %t320, i32 0, i32 0
  store i64 7, ptr %t321
  %t323 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t317, 0
  %t325 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t323, { i64, [4 x i64] } %t318, 1
  %t327 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t325, i32 %t319, 2
  %t328 = getelementptr { i64, [15 x i64] }, ptr %t320, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t327, ptr %t328
  %t329 = load { i64, [15 x i64] }, ptr %t320
  %t330 = load ptr, ptr %l2, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Body", ptr %t330, i32 0, i32 4
  %t333 = load %"compiler/source:Span", ptr %t332
  %t338 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v3, ptr %t315, i32 %t316, { i64, [15 x i64] } %t329, %"compiler/source:Span" %t333)
  store { i64, [4 x i64] } %t338, ptr %l151
  br label %bb53
bb53:
  %t339 = load { i64, [4 x i64] }, ptr %l151
  store { i64, [4 x i64] } %t339, ptr %l15
  %t340 = load ptr, ptr %l3, !tbaa !29
  store ptr %t340, ptr %l152, !tbaa !29
  %t341 = load i32, ptr %l5, !tbaa !23
  %t342 = load ptr, ptr %l152, !tbaa !29
  %t343 = call ptr @__olang_scope_or(ptr %v1, ptr %t342)
  %t344 = call ptr @__olang_scope_hold(ptr %t343)
  %t345 = ptrtoint ptr %t344 to i64
  %t347 = inttoptr i64 %t345 to ptr
  %t348 = load ptr, ptr %l152, !tbaa !29
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t347, ptr %t348, i32 %t341)
  store i32 %t350, ptr %l155
  br label %bb54
bb54:
  %t351 = load i32, ptr %l155, !range !{i32 0, i32 33}
  %t353 = trunc i64 18 to i32
  %t354 = icmp eq i32 %t351, %t353
  br i1 %t354, label %bb55, label %bb56
bb55:
  %t356 = load ptr, ptr %l3, !tbaa !29
  store ptr %t356, ptr %l159, !tbaa !29
  %t357 = load i32, ptr %l5, !tbaa !23
  %t358 = load ptr, ptr %l159, !tbaa !29
  %t359 = call ptr @__olang_scope_or(ptr %v1, ptr %t358)
  %t360 = call ptr @__olang_scope_hold(ptr %t359)
  %t361 = ptrtoint ptr %t360 to i64
  %t363 = inttoptr i64 %t361 to ptr
  %t364 = load ptr, ptr %l159, !tbaa !29
  %t366 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t363, ptr %t364, i32 %t357)
  store i1 %t366, ptr %l162
  br label %bb57
bb56:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb58
bb57:
  %t367 = load i1, ptr %l162, !tbaa !21
  store i1 %t367, ptr %l158, !tbaa !21
  br label %bb58
bb58:
  %t368 = load i1, ptr %l158, !tbaa !21
  br i1 %t368, label %bb59, label %bb60
bb59:
  %t369 = load ptr, ptr %l3, !tbaa !29
  store ptr %t369, ptr %l164, !tbaa !29
  %t370 = load i32, ptr %l5, !tbaa !23
  %t371 = load ptr, ptr %l164, !tbaa !29
  %t372 = call ptr @__olang_scope_or(ptr %v1, ptr %t371)
  %t373 = call ptr @__olang_scope_hold(ptr %t372)
  %t374 = ptrtoint ptr %t373 to i64
  %t376 = inttoptr i64 %t374 to ptr
  %t377 = load ptr, ptr %l164, !tbaa !29
  %t379 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %t376, ptr %t377, i32 %t370)
  store i1 %t379, ptr %l167
  br label %bb61
bb60:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb62
bb61:
  %t380 = load i1, ptr %l167, !tbaa !21
  store i1 %t380, ptr %l163, !tbaa !21
  br label %bb62
bb62:
  %t381 = load i1, ptr %l163, !tbaa !21
  br i1 %t381, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load ptr, ptr %l2, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Body", ptr %t383, i32 0, i32 4
  %t386 = load %"compiler/source:Span", ptr %t385
  %t387 = load { i64, [1 x i64] }, ptr %l16
  %t388 = load i32, ptr %l4, !tbaa !23
  %t389 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [21 x i64] } zeroinitializer, ptr %t390
  %t391 = getelementptr { i64, [21 x i64] }, ptr %t390, i32 0, i32 0
  store i64 5, ptr %t391
  %t393 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t386, 0
  %t395 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t393, { i64, [1 x i64] } %t387, 1
  %t397 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t395, i32 %t388, 2
  %t399 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t397, { i64, [4 x i64] } %t389, 3
  %t400 = getelementptr { i64, [21 x i64] }, ptr %t390, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t399, ptr %t400
  %t401 = load { i64, [21 x i64] }, ptr %t390
  %t403 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t401, ptr %t403
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %v1, ptr %v3, ptr %t382, ptr %t403)
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t406 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %t406, i64 0)
  br label %bb68
bb68:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load ptr, ptr %l2, !tbaa !29
  %t411 = getelementptr %"compiler/typed:Body", ptr %t409, i32 0, i32 4
  %t412 = load %"compiler/source:Span", ptr %t411
  %t413 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [8 x i64] } zeroinitializer, ptr %t414
  %t415 = getelementptr { i64, [8 x i64] }, ptr %t414, i32 0, i32 0
  store i64 5, ptr %t415
  %t417 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t412, 0
  %t419 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t417, { i64, [4 x i64] } %t413, 1
  %t420 = getelementptr { i64, [8 x i64] }, ptr %t414, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t419, ptr %t420
  %t421 = load { i64, [8 x i64] }, ptr %t414
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v3, ptr %v1, ptr %t408, { i64, [8 x i64] } %t421)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l48 = alloca i32
  %l51 = alloca i32
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, [4 x i64] }
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca i32
  %l73 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l83 = alloca { i64, [4 x i64] }
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l92 = alloca i32
  %l95 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t105 = alloca { i64, [8 x i64] }, align 8
  %t151 = alloca { i64, [8 x i64] }, align 8
  %t180 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store { i64, ptr } %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l8, !tbaa !24
  store i64 2, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l9, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l9, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l28, !tbaa !24
  store i64 %t39, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l25, !tbaa !24
  store i64 %t40, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l11, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l11, !tbaa !24
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l12, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 3
  %t63 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t61)
  store i32 %t63, ptr %l48
  br label %bb12
bb12:
  %t64 = load i32, ptr %l48, !tbaa !23
  store i32 %t64, ptr %l13, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t65, i32 0, i32 3
  %t69 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t67)
  store i32 %t69, ptr %l51
  br label %bb13
bb13:
  %t70 = load i32, ptr %l51, !tbaa !23
  store i32 %t70, ptr %l14, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t74, ptr %l56, !tbaa !27
  %t75 = load i64, ptr %l12, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t78, i64 %t75
  %t80 = load { i64, [4 x i64] }, ptr %t79
  %t81 = mul i64 2, 40
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 2, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l59, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i64 0
  store { i64, [4 x i64] } %a1, ptr %t88
  %t90 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t91, i64 1
  store { i64, [4 x i64] } %t80, ptr %t92
  %t93 = load %"compiler/source:Span", ptr %l3
  %t97 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t99 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %v1, ptr %v2, ptr %t71, i32 13, i32 %t72, { i64, ptr } %t97, %"compiler/source:Span" %t93)
  store { i64, [4 x i64] } %t99, ptr %l61
  br label %bb14
bb14:
  %t100 = load { i64, [4 x i64] }, ptr %l61
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l13, !tbaa !23
  %t104 = load i32, ptr %l14, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [8 x i64] }, ptr %t105, i32 0, i32 0
  store i64 2, ptr %t106
  %t108 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t100, 0
  %t110 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t108, i32 %t103, 1
  %t112 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t110, i32 %t104, 2
  %t113 = getelementptr { i64, [8 x i64] }, ptr %t105, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t112, ptr %t113
  %t114 = load { i64, [8 x i64] }, ptr %t105
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t101, { i64, [8 x i64] } %t114)
  br label %bb15
bb15:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t117, i32 %t118)
  br label %bb16
bb16:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l69, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t122, ptr %l70
  %t123 = load i32, ptr %l4, !range !{i32 0, i32 20}
  store i32 %t123, ptr %l71
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l73, !tbaa !27
  %t126 = load i64, ptr %l12, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t129, i64 %t126
  %t131 = load { i64, [4 x i64] }, ptr %t130
  %t132 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t132, ptr %l76, !tbaa !27
  %t133 = load i64, ptr %l12, !tbaa !24
  %t135 = add i64 %t133, 1
  %t137 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, [4 x i64] }, ptr %t138, i64 %t135
  %t140 = load { i64, [4 x i64] }, ptr %t139
  %t141 = load i32, ptr %l2, !tbaa !23
  %t142 = load %"compiler/source:Span", ptr %l3
  %t150 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewithPayload(ptr %v0, ptr %v1, ptr %v2, ptr %t124, { i64, [4 x i64] } %t131, { i64, [4 x i64] } %t140, i32 %t141, %"compiler/source:Span" %t142, i1 %a5)
  store { i64, [4 x i64] } %t150, ptr %l83
  br label %bb17
bb17:
  store { i64, [8 x i64] } zeroinitializer, ptr %t151
  %t152 = getelementptr { i64, [8 x i64] }, ptr %t151, i32 0, i32 0
  store i64 9, ptr %t152
  %t153 = load %"compiler/source:Span", ptr %l70
  %t154 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t153, 0
  %t155 = load i32, ptr %l71, !range !{i32 0, i32 20}
  %t156 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t154, i32 %t155, 1
  %t157 = load { i64, [4 x i64] }, ptr %l83
  %t158 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t156, { i64, [4 x i64] } %t157, 2
  %t159 = getelementptr { i64, [8 x i64] }, ptr %t151, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t158, ptr %t159
  %t160 = load { i64, [8 x i64] }, ptr %t151
  %t161 = load ptr, ptr %l69, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t161, { i64, [8 x i64] } %t160)
  br label %bb18
bb18:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t163, i32 %t164)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t167 = load i64, ptr %l11, !tbaa !24
  %t170 = add i64 %t167, 1
  store i64 %t170, ptr %l11, !tbaa !24
  br label %bb8
bb21:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l90, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t173, ptr %l91
  %t174 = load i32, ptr %l4, !range !{i32 0, i32 20}
  store i32 %t174, ptr %l92
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l3
  %t179 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t175, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d16, i32 0, i32 1) }, %"compiler/source:Span" %t176)
  store { i64, [4 x i64] } %t179, ptr %l95
  br label %bb22
bb22:
  store { i64, [8 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [8 x i64] }, ptr %t180, i32 0, i32 0
  store i64 9, ptr %t181
  %t182 = load %"compiler/source:Span", ptr %l91
  %t183 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t182, 0
  %t184 = load i32, ptr %l92, !range !{i32 0, i32 20}
  %t185 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t183, i32 %t184, 1
  %t186 = load { i64, [4 x i64] }, ptr %l95
  %t187 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t185, { i64, [4 x i64] } %t186, 2
  %t188 = getelementptr { i64, [8 x i64] }, ptr %t180, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t187, ptr %t188
  %t189 = load { i64, [8 x i64] }, ptr %t180
  %t190 = load ptr, ptr %l90, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t190, { i64, [8 x i64] } %t189)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eclausesTake(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/typed:Item"
  %l22 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l50 = alloca i32
  %l52 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Spawn", ptr %a1, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  br label %bb24
bb3:
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l7, !tbaa !29
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t33 = getelementptr %"compiler/typed:TaskClause", ptr %t31, i32 0, i32 2
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l7, !tbaa !29
  %t39 = getelementptr %"compiler/typed:TaskClause", ptr %t37, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l10, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  %t55 = load i64, ptr %l9, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/typed:Item", ptr %t58, i64 %t55
  %t60 = load %"compiler/typed:Item", ptr %t59
  store %"compiler/typed:Item" %t60, ptr %l11
  %t62 = getelementptr %"compiler/typed:Item", ptr %l11, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb12, label %bb13
bb12:
  %t67 = load ptr, ptr %l3, !tbaa !29
  store ptr %t67, ptr %l42, !tbaa !29
  %t68 = load ptr, ptr %l3, !tbaa !29
  store ptr %t68, ptr %l43, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Item", ptr %l11, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = load ptr, ptr %l43, !tbaa !29
  %t72 = call ptr @__olang_scope_or(ptr %v2, ptr %t71)
  %t73 = call ptr @__olang_scope_hold(ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l43, !tbaa !29
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t76, ptr %t77, i32 %t70)
  store i32 %t79, ptr %l46
  br label %bb14
bb13:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb17
bb14:
  %t80 = load ptr, ptr %l3, !tbaa !29
  store ptr %t80, ptr %l47, !tbaa !29
  %t82 = load ptr, ptr %l47, !tbaa !29
  %t83 = call ptr @__olang_scope_or(ptr %v2, ptr %t82)
  %t84 = call ptr @__olang_scope_hold(ptr %t83)
  %t85 = ptrtoint ptr %t84 to i64
  %t87 = inttoptr i64 %t85 to ptr
  %t88 = load ptr, ptr %l47, !tbaa !29
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t87, ptr %t88, i32 %a2)
  store i32 %t90, ptr %l50
  br label %bb15
bb15:
  %t91 = load ptr, ptr %l42, !tbaa !29
  %t92 = call ptr @__olang_scope_or(ptr %v2, ptr %t91)
  %t93 = call ptr @__olang_scope_hold(ptr %t92)
  %t94 = ptrtoint ptr %t93 to i64
  %t96 = inttoptr i64 %t94 to ptr
  %t97 = load ptr, ptr %l42, !tbaa !29
  %t98 = load i32, ptr %l46, !tbaa !23
  %t99 = load i32, ptr %l50, !tbaa !23
  %t100 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t96, ptr %t97, i32 %t98, i32 %t99)
  store i1 %t100, ptr %l52
  br label %bb16
bb16:
  %t101 = load i1, ptr %l52, !tbaa !21
  store i1 %t101, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t102 = load i1, ptr %l41, !tbaa !21
  br i1 %t102, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb8
bb22:
  br label %bb23
bb23:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb1
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i32
  %l15 = alloca %"compiler/lower:pl"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/lower:pl"
  %l24 = alloca i64
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca i32
  %l31 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca %"compiler/lower:pl"
  %l38 = alloca %"compiler/lower:pl"
  %l39 = alloca %"compiler/mir:Lvalue"
  %l43 = alloca { i64, [4 x i64] }
  %l44 = alloca ptr
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca %"compiler/lower:pl"
  %l54 = alloca %"compiler/lower:pl"
  %l58 = alloca { i64, [4 x i64] }
  %l59 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca ptr
  %l66 = alloca i32
  %l69 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca ptr
  %l78 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca %"compiler/lower:pl"
  %l84 = alloca %"compiler/lower:pl"
  %l85 = alloca %"compiler/mir:Lvalue"
  %l90 = alloca { i64, [4 x i64] }
  %l93 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca i32
  %l96 = alloca ptr
  %l97 = alloca %"compiler/lower:pl"
  %l99 = alloca %"compiler/lower:pl"
  %l102 = alloca { i64, [4 x i64] }
  %l103 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, [4 x i64] }
  %l109 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca %"compiler/lower:pl"
  %l119 = alloca %"compiler/lower:pl"
  %l120 = alloca %"compiler/mir:Lvalue"
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, [4 x i64] }
  %l128 = alloca i32
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca %"compiler/mir:Lvalue"
  %l142 = alloca i64
  %l145 = alloca { i64, [1 x i64] }
  %l150 = alloca { i64, [1 x i64] }
  %l152 = alloca ptr
  %l153 = alloca { i64, [4 x i64] }
  %l154 = alloca %"compiler/source:Span"
  %l155 = alloca ptr
  %l156 = alloca %"compiler/lower:pl"
  %l158 = alloca %"compiler/lower:pl"
  %l167 = alloca %"compiler/mir:Lvalue"
  %l171 = alloca ptr
  %l172 = alloca i32
  %l173 = alloca i32
  %l174 = alloca ptr
  %l175 = alloca %"compiler/lower:pl"
  %l177 = alloca %"compiler/lower:pl"
  %l180 = alloca { i64, [4 x i64] }
  %l181 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l186 = alloca { i64, [4 x i64] }
  %l187 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca %"compiler/lower:pl"
  %l193 = alloca %"compiler/lower:pl"
  %l194 = alloca %"compiler/mir:Lvalue"
  %l198 = alloca { i64, [4 x i64] }
  %l201 = alloca i32
  %l204 = alloca %"compiler/lower:pl"
  %l206 = alloca ptr
  %l209 = alloca i1
  %l212 = alloca { i64, ptr }
  %l218 = alloca i64
  %l221 = alloca i64
  %l239 = alloca ptr
  %l240 = alloca %"compiler/lower:pl"
  %l242 = alloca %"compiler/lower:pl"
  %l245 = alloca %"compiler/lower:pl"
  %l249 = alloca i64
  %l252 = alloca ptr
  %l253 = alloca %"compiler/lower:pl"
  %l255 = alloca %"compiler/lower:pl"
  %l271 = alloca ptr
  %l274 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i32
  %l277 = alloca ptr
  %l278 = alloca %"compiler/lower:pl"
  %l280 = alloca %"compiler/lower:pl"
  %l281 = alloca %"compiler/mir:Lvalue"
  %l284 = alloca { i64, [4 x i64] }
  %l285 = alloca ptr
  %l288 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l290 = alloca { i64, [4 x i64] }
  %l291 = alloca %"compiler/source:Span"
  %l292 = alloca ptr
  %l293 = alloca %"compiler/lower:pl"
  %l295 = alloca %"compiler/lower:pl"
  %l299 = alloca ptr
  %l302 = alloca i32
  %l305 = alloca ptr
  %l308 = alloca i32
  %l309 = alloca ptr
  %l310 = alloca ptr
  %l311 = alloca ptr
  %l312 = alloca ptr
  %l315 = alloca i32
  %l317 = alloca i64
  %l318 = alloca { i64, [4 x i64] }
  %l319 = alloca %"compiler/source:Span"
  %l320 = alloca ptr
  %l321 = alloca %"compiler/lower:pl"
  %l323 = alloca %"compiler/lower:pl"
  %l331 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t23 = alloca { i64, [4 x i64] }, align 8
  %t29 = alloca { i64, [15 x i64] }, align 8
  %t138 = alloca { i64, [4 x i64] }, align 8
  %t220 = alloca { i64, [4 x i64] }, align 8
  %t258 = alloca { i64, [4 x i64] }, align 8
  %t261 = alloca { i64, [15 x i64] }, align 8
  %t273 = alloca { i64, [21 x i64] }, align 8
  %t357 = alloca { i64, [4 x i64] }, align 8
  %t419 = alloca { i64, [4 x i64] }, align 8
  %t425 = alloca { i64, [15 x i64] }, align 8
  %t446 = alloca { i64, [2 x i64] }, align 8
  %t545 = alloca { i64, [1 x i64] }, align 8
  %t628 = alloca { i64, [15 x i64] }, align 8
  %t658 = alloca { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, align 8
  %t763 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eownsStorage(ptr %v0, ptr %v2, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l31
  br label %bb1
bb1:
  %t11 = load i1, ptr %l31, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l33, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  store i32 %t15, ptr %l34, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l35, !tbaa !29
  %t17 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t17, ptr %l36
  %t19 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s1, ptr %l36)
  store %"compiler/lower:pl" %t19, ptr %l38
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t20 = load ptr, ptr %l35, !tbaa !29
  %t21 = load %"compiler/lower:pl", ptr %l38
  %t22 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s1, ptr %v3, ptr %t20, %"compiler/lower:pl" %t21)
  store %"compiler/mir:Lvalue" %t22, ptr %l39
  br label %bb5
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 0
  store i64 1, ptr %t24
  %t25 = load %"compiler/mir:Lvalue", ptr %l39
  %t26 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t25, 0
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t26, ptr %t27
  %t28 = load { i64, [4 x i64] }, ptr %t23
  store { i64, [15 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [15 x i64] }, ptr %t29, i32 0, i32 0
  store i64 0, ptr %t30
  %t32 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t28, 0
  %t33 = getelementptr { i64, [15 x i64] }, ptr %t29, i32 0, i32 1
  store { { i64, [4 x i64] } } %t32, ptr %t33
  %t34 = load { i64, [15 x i64] }, ptr %t29
  %t35 = load %"compiler/source:Span", ptr %l4
  %t36 = load ptr, ptr %l33, !tbaa !29
  %t37 = load i32, ptr %l34, !tbaa !23
  %t40 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v3, ptr %t36, i32 %t37, { i64, [15 x i64] } %t34, %"compiler/source:Span" %t35)
  store { i64, [4 x i64] } %t40, ptr %l43
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { i64, [4 x i64] }, ptr %l43
  store { i64, [4 x i64] } %t41, ptr %rv
  br label %ret
bb7:
  %t42 = load ptr, ptr %l7, !tbaa !29
  store ptr %t42, ptr %l44, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t44 = load ptr, ptr %l44, !tbaa !29
  %t45 = call ptr @__olang_scope_or(ptr %v2, ptr %t44)
  %t46 = call ptr @__olang_scope_hold(ptr %t45)
  %t47 = ptrtoint ptr %t46 to i64
  %t49 = inttoptr i64 %t47 to ptr
  %t50 = load ptr, ptr %l44, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %t49, ptr %t50, i32 %t43)
  store i1 %t52, ptr %l47
  br label %bb8
bb8:
  %t53 = load i1, ptr %l47, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  %t56 = xor i1 %a6, true
  store i1 %t56, ptr %l48, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb11
bb11:
  %t58 = load i1, ptr %l48, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l51, !tbaa !29
  %t60 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t60, ptr %l52
  %t62 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l52)
  store %"compiler/lower:pl" %t62, ptr %l54
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t63 = load i32, ptr %l2, !tbaa !23
  %t64 = load { i64, [1 x i64] }, ptr %l3
  %t65 = load %"compiler/source:Span", ptr %l4
  %t66 = load ptr, ptr %l51, !tbaa !29
  %t67 = load %"compiler/lower:pl", ptr %l54
  %t71 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edeclaredCopy(ptr %v0, ptr %s2, ptr %v3, ptr %v2, ptr %t66, %"compiler/lower:pl" %t67, i32 %t63, { i64, [1 x i64] } %t64, %"compiler/source:Span" %t65)
  store { i64, [4 x i64] } %t71, ptr %l58
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, [4 x i64] }, ptr %l58
  store { i64, [4 x i64] } %t72, ptr %rv
  br label %ret
bb16:
  %t73 = load ptr, ptr %l7, !tbaa !29
  store ptr %t73, ptr %l59, !tbaa !29
  %t74 = load i32, ptr %l2, !tbaa !23
  %t75 = load ptr, ptr %l59, !tbaa !29
  %t76 = call ptr @__olang_scope_or(ptr %v2, ptr %t75)
  %t77 = call ptr @__olang_scope_hold(ptr %t76)
  %t78 = ptrtoint ptr %t77 to i64
  %t80 = inttoptr i64 %t78 to ptr
  %t81 = load ptr, ptr %l59, !tbaa !29
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t80, ptr %t81, i32 %t74)
  store i32 %t83, ptr %l62
  br label %bb17
bb17:
  %t84 = load i32, ptr %l62, !tbaa !23
  store i32 %t84, ptr %l8, !tbaa !23
  %t85 = load ptr, ptr %l7, !tbaa !29
  store ptr %t85, ptr %l63, !tbaa !29
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load ptr, ptr %l63, !tbaa !29
  %t88 = call ptr @__olang_scope_or(ptr %v2, ptr %t87)
  %t89 = call ptr @__olang_scope_hold(ptr %t88)
  %t90 = ptrtoint ptr %t89 to i64
  %t92 = inttoptr i64 %t90 to ptr
  %t93 = load ptr, ptr %l63, !tbaa !29
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t92, ptr %t93, i32 %t86)
  store i32 %t95, ptr %l66
  br label %bb18
bb18:
  %t96 = load i32, ptr %l66, !range !{i32 0, i32 33}
  %t98 = trunc i64 19 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb19, label %bb20
bb19:
  %t101 = load ptr, ptr %l7, !tbaa !29
  store ptr %t101, ptr %l70, !tbaa !29
  %t102 = load i32, ptr %l8, !tbaa !23
  %t103 = load ptr, ptr %l70, !tbaa !29
  %t104 = call ptr @__olang_scope_or(ptr %v2, ptr %t103)
  %t105 = call ptr @__olang_scope_hold(ptr %t104)
  %t106 = ptrtoint ptr %t105 to i64
  %t108 = inttoptr i64 %t106 to ptr
  %t109 = load ptr, ptr %l70, !tbaa !29
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t108, ptr %t109, i32 %t102)
  store i32 %t111, ptr %l73
  br label %bb21
bb20:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb22
bb21:
  %t112 = load i32, ptr %l73, !tbaa !23
  %t113 = icmp eq i32 %t112, 0
  store i1 %t113, ptr %l69, !tbaa !21
  br label %bb22
bb22:
  %t115 = load i1, ptr %l69, !tbaa !21
  br i1 %t115, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t116 = load ptr, ptr %l7, !tbaa !29
  store ptr %t116, ptr %l75, !tbaa !29
  %t117 = load i32, ptr %l2, !tbaa !23
  %t118 = load ptr, ptr %l75, !tbaa !29
  %t119 = call ptr @__olang_scope_or(ptr %v2, ptr %t118)
  %t120 = call ptr @__olang_scope_hold(ptr %t119)
  %t121 = ptrtoint ptr %t120 to i64
  %t123 = inttoptr i64 %t121 to ptr
  %t124 = load ptr, ptr %l75, !tbaa !29
  %t126 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %t123, ptr %t124, i32 %t117)
  store i1 %t126, ptr %l78
  br label %bb25
bb24:
  br label %bb53
bb25:
  %t127 = load i1, ptr %l78, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l80, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l81, !tbaa !29
  %t132 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t132, ptr %l82
  %t134 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s4, ptr %l82)
  store %"compiler/lower:pl" %t134, ptr %l84
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t135 = load ptr, ptr %l81, !tbaa !29
  %t136 = load %"compiler/lower:pl", ptr %l84
  %t137 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s4, ptr %v3, ptr %t135, %"compiler/lower:pl" %t136)
  store %"compiler/mir:Lvalue" %t137, ptr %l85
  br label %bb29
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 0
  store i64 1, ptr %t139
  %t140 = load %"compiler/mir:Lvalue", ptr %l85
  %t141 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t140, 0
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t141, ptr %t142
  %t143 = load { i64, [4 x i64] }, ptr %t138
  %t144 = load i32, ptr %l2, !tbaa !23
  %t145 = load %"compiler/source:Span", ptr %l4
  %t146 = load { i64, [1 x i64] }, ptr %l3
  %t147 = load ptr, ptr %l80, !tbaa !29
  %t152 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %v2, ptr %v3, ptr %t147, { i64, [4 x i64] } %t143, i32 %t144, %"compiler/source:Span" %t145, { i64, [1 x i64] } %t146, i1 false)
  store { i64, [4 x i64] } %t152, ptr %l90
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, [4 x i64] }, ptr %l90
  store { i64, [4 x i64] } %t153, ptr %rv
  br label %ret
bb31:
  %t154 = load i1, ptr %l5, !tbaa !21
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l93, !tbaa !29
  store i32 4, ptr %l94
  %t159 = load i32, ptr %l2, !tbaa !23
  store i32 %t159, ptr %l95, !tbaa !23
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l96, !tbaa !29
  %t161 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t161, ptr %l97
  %t163 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s5, ptr %l97)
  store %"compiler/lower:pl" %t163, ptr %l99
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t164 = load i32, ptr %l2, !tbaa !23
  %t165 = load %"compiler/source:Span", ptr %l4
  %t166 = load ptr, ptr %l96, !tbaa !29
  %t167 = load %"compiler/lower:pl", ptr %l99
  %t170 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %s5, ptr %v2, ptr %v3, ptr %t166, %"compiler/lower:pl" %t167, i32 %t164, %"compiler/source:Span" %t165)
  store { i64, [4 x i64] } %t170, ptr %l102
  br label %bb35
bb35:
  %t171 = mul i64 1, 40
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 1, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l103, !tbaa !27
  %t175 = load { i64, [4 x i64] }, ptr %l102
  %t176 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t177, i64 0
  store { i64, [4 x i64] } %t175, ptr %t178
  %t179 = load { i64, [1 x i64] }, ptr %l3
  %t180 = mul i64 1, 16
  %t181 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 1, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l105, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, [1 x i64] }, ptr %t186, i64 0
  store { i64, [1 x i64] } %t179, ptr %t187
  %t188 = load i32, ptr %l2, !tbaa !23
  %t189 = load %"compiler/source:Span", ptr %l4
  %t190 = load ptr, ptr %l93, !tbaa !29
  %t191 = load i32, ptr %l94, !range !{i32 0, i32 10}
  %t192 = load i32, ptr %l95, !tbaa !23
  %t193 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t197 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %s5, ptr %s5, ptr %v3, ptr %v2, ptr %t190, i32 %t191, i32 %t192, { i64, ptr } %t193, { i64, ptr } %t194, i32 %t188, %"compiler/source:Span" %t189)
  store { i64, [4 x i64] } %t197, ptr %l108
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t198 = load { i64, [4 x i64] }, ptr %l108
  store { i64, [4 x i64] } %t198, ptr %rv
  br label %ret
bb37:
  %t199 = load ptr, ptr %l7, !tbaa !29
  store ptr %t199, ptr %l109, !tbaa !29
  %t200 = load i32, ptr %l8, !tbaa !23
  %t201 = load ptr, ptr %l109, !tbaa !29
  %t202 = call ptr @__olang_scope_or(ptr %v2, ptr %t201)
  %t203 = call ptr @__olang_scope_hold(ptr %t202)
  %t204 = ptrtoint ptr %t203 to i64
  %t206 = inttoptr i64 %t204 to ptr
  %t207 = load ptr, ptr %l109, !tbaa !29
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t206, ptr %t207, i32 %t200)
  store i32 %t209, ptr %l112
  br label %bb38
bb38:
  %t210 = load i32, ptr %l112, !tbaa !23
  store i32 %t210, ptr %l9, !tbaa !23
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l113, !tbaa !29
  store i32 22, ptr %l114
  %t212 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t212, ptr %l115, !tbaa !23
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l116, !tbaa !29
  %t214 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t214, ptr %l117
  %t216 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s3, ptr %l117)
  store %"compiler/lower:pl" %t216, ptr %l119
  br label %bb39
bb39:
  %t217 = load ptr, ptr %l116, !tbaa !29
  %t218 = load %"compiler/lower:pl", ptr %l119
  %t219 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s3, ptr %v3, ptr %t217, %"compiler/lower:pl" %t218)
  store %"compiler/mir:Lvalue" %t219, ptr %l120
  br label %bb40
bb40:
  store { i64, [4 x i64] } zeroinitializer, ptr %t220
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t220, i32 0, i32 0
  store i64 1, ptr %t221
  %t222 = load %"compiler/mir:Lvalue", ptr %l120
  %t223 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t222, 0
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t220, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t223, ptr %t224
  %t225 = load { i64, [4 x i64] }, ptr %t220
  %t226 = mul i64 1, 40
  %t227 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t226)
  %t228 = insertvalue { i64, ptr } undef, i64 1, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l122, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t232, i64 0
  store { i64, [4 x i64] } %t225, ptr %t233
  %t234 = load %"compiler/source:Span", ptr %l4
  %t235 = load ptr, ptr %l113, !tbaa !29
  %t236 = load i32, ptr %l114, !range !{i32 0, i32 54}
  %t237 = load i32, ptr %l115, !tbaa !23
  %t238 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t240 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %v2, ptr %v3, ptr %t235, i32 %t236, i32 %t237, { i64, ptr } %t238, %"compiler/source:Span" %t234)
  store { i64, [4 x i64] } %t240, ptr %l124
  br label %bb41
bb41:
  %t241 = load { i64, [4 x i64] }, ptr %l124
  store { i64, [4 x i64] } %t241, ptr %l10
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l2, !tbaa !23
  %t244 = load %"compiler/source:Span", ptr %l4
  %t248 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t242, i32 %t243, %"compiler/source:Span" %t244)
  store i32 %t248, ptr %l128
  br label %bb42
bb42:
  %t249 = load i32, ptr %l128, !tbaa !23
  store i32 %t249, ptr %l11, !tbaa !23
  %t250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t250, ptr %l129, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t251, ptr %l130
  %t252 = load i32, ptr %l11, !tbaa !23
  %t254 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t252)
  store %"compiler/mir:Lvalue" %t254, ptr %l132
  br label %bb43
bb43:
  %t255 = load { i64, [1 x i64] }, ptr %l3
  %t256 = load i32, ptr %l2, !tbaa !23
  %t257 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } zeroinitializer, ptr %t258
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 0
  store i64 0, ptr %t259
  %t260 = load { i64, [4 x i64] }, ptr %t258
  store { i64, [15 x i64] } zeroinitializer, ptr %t261
  %t262 = getelementptr { i64, [15 x i64] }, ptr %t261, i32 0, i32 0
  store i64 8, ptr %t262
  %t264 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t255, 0
  %t266 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t264, i32 %t256, 1
  %t268 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t266, { i64, [4 x i64] } %t257, 2
  %t270 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t268, { i64, [4 x i64] } %t260, 3
  %t271 = getelementptr { i64, [15 x i64] }, ptr %t261, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t270, ptr %t271
  %t272 = load { i64, [15 x i64] }, ptr %t261
  store { i64, [21 x i64] } zeroinitializer, ptr %t273
  %t274 = getelementptr { i64, [21 x i64] }, ptr %t273, i32 0, i32 0
  store i64 0, ptr %t274
  %t275 = load %"compiler/source:Span", ptr %l130
  %t276 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t275, 0
  %t277 = load %"compiler/mir:Lvalue", ptr %l132
  %t278 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t276, %"compiler/mir:Lvalue" %t277, 1
  %t280 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t278, { i64, [15 x i64] } %t272, 2
  %t281 = getelementptr { i64, [21 x i64] }, ptr %t273, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t280, ptr %t281
  %t282 = load { i64, [21 x i64] }, ptr %t273
  %t284 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t282, ptr %t284
  %t285 = load ptr, ptr %l129, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %v2, ptr %v3, ptr %t285, ptr %t284)
  br label %bb44
bb44:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i32, ptr %l2, !tbaa !23
  %t291 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopySlots(ptr %v0, ptr %v3, ptr %t287, i32 %t288, i64 -1)
  store i64 %t291, ptr %l142
  br label %bb45
bb45:
  %t292 = load i64, ptr %l142, !tbaa !24
  store i64 %t292, ptr %l12, !tbaa !24
  %t293 = load i64, ptr %l12, !tbaa !24
  %t295 = icmp sge i64 %t293, 0
  br i1 %t295, label %bb46, label %bb47
bb46:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i64, ptr %l12, !tbaa !24
  %t299 = load { i64, [1 x i64] }, ptr %l3
  %t300 = load %"compiler/source:Span", ptr %l4
  %t305 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslotsOf(ptr %v0, ptr %v3, ptr %v2, ptr %t297, i64 %t298, { i64, [1 x i64] } %t299, %"compiler/source:Span" %t300)
  store { i64, [1 x i64] } %t305, ptr %l150
  br label %bb48
bb47:
  %t306 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t306, ptr %l145
  br label %bb49
bb48:
  %t308 = load { i64, [1 x i64] }, ptr %l150
  store { i64, [1 x i64] } %t308, ptr %l145
  br label %bb49
bb49:
  %t309 = load { i64, [1 x i64] }, ptr %l145
  store { i64, [1 x i64] } %t309, ptr %l13
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l152, !tbaa !29
  %t311 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t311, ptr %l153
  %t312 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t312, ptr %l154
  %t313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t313, ptr %l155, !tbaa !29
  %t314 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t314, ptr %l156
  %t316 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v0, ptr %l156)
  store %"compiler/lower:pl" %t316, ptr %l158
  br label %bb50
bb50:
  %t317 = load i32, ptr %l11, !tbaa !23
  %t318 = load i64, ptr %l12, !tbaa !24
  %t319 = load %"compiler/source:Span", ptr %l4
  %t320 = load i32, ptr %l9, !tbaa !23
  %t321 = load { i64, [1 x i64] }, ptr %l3
  %t322 = load { i64, [1 x i64] }, ptr %l13
  %t323 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr null, i32 1
  %t324 = ptrtoint ptr %t323 to i64
  %t325 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t324, i64 8)
  %t326 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 0
  %t327 = load ptr, ptr %l155, !tbaa !29
  store ptr %t327, ptr %t326, !tbaa !28
  %t328 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 1
  %t329 = load %"compiler/lower:pl", ptr %l158
  store %"compiler/lower:pl" %t329, ptr %t328, !tbaa !28
  %t330 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 2
  store i32 %t317, ptr %t330, !tbaa !28
  %t332 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 3
  store i64 %t318, ptr %t332, !tbaa !28
  %t334 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 4
  store %"compiler/source:Span" %t319, ptr %t334, !tbaa !28
  %t336 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 5
  store i32 %t320, ptr %t336, !tbaa !28
  %t338 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 6
  store { i64, [1 x i64] } %t321, ptr %t338, !tbaa !28
  %t340 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 7
  store { i64, [1 x i64] } %t322, ptr %t340, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t342 = call ptr @__olang_scope_hold(ptr %v0)
  %t343 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 8
  store ptr %t342, ptr %t343, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t344 = call ptr @__olang_scope_hold(ptr %v1)
  %t345 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %t325, i32 0, i32 9
  store ptr %t344, ptr %t345, !tbaa !28
  %t346 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_17, 0
  %t347 = insertvalue { ptr, ptr } %t346, ptr %t325, 1
  %t348 = load ptr, ptr %l152, !tbaa !29
  %t349 = load { i64, [4 x i64] }, ptr %l153
  %t350 = load %"compiler/source:Span", ptr %l154
  %t352 = extractvalue { ptr, ptr } %t347, 0
  %t353 = extractvalue { ptr, ptr } %t347, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t348, { i64, [4 x i64] } %t349, %"compiler/source:Span" %t350, ptr %t352, ptr %t353)
  br label %bb51
bb51:
  %t354 = load i32, ptr %l11, !tbaa !23
  %t356 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t354)
  store %"compiler/mir:Lvalue" %t356, ptr %l167
  br label %bb52
bb52:
  store { i64, [4 x i64] } zeroinitializer, ptr %t357
  %t358 = getelementptr { i64, [4 x i64] }, ptr %t357, i32 0, i32 0
  store i64 1, ptr %t358
  %t359 = load %"compiler/mir:Lvalue", ptr %l167
  %t360 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t359, 0
  %t361 = getelementptr { i64, [4 x i64] }, ptr %t357, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t360, ptr %t361
  %t362 = load { i64, [4 x i64] }, ptr %t357
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t362, ptr %rv
  br label %ret
bb53:
  %t364 = load i1, ptr %l5, !tbaa !21
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s6
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l171, !tbaa !29
  store i32 4, ptr %l172
  %t369 = load i32, ptr %l2, !tbaa !23
  store i32 %t369, ptr %l173, !tbaa !23
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l174, !tbaa !29
  %t371 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t371, ptr %l175
  %t373 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s6, ptr %l175)
  store %"compiler/lower:pl" %t373, ptr %l177
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t374 = load i32, ptr %l2, !tbaa !23
  %t375 = load %"compiler/source:Span", ptr %l4
  %t376 = load ptr, ptr %l174, !tbaa !29
  %t377 = load %"compiler/lower:pl", ptr %l177
  %t380 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %s6, ptr %v2, ptr %v3, ptr %t376, %"compiler/lower:pl" %t377, i32 %t374, %"compiler/source:Span" %t375)
  store { i64, [4 x i64] } %t380, ptr %l180
  br label %bb57
bb57:
  %t381 = mul i64 1, 40
  %t382 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t381)
  %t383 = insertvalue { i64, ptr } undef, i64 1, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  store { i64, ptr } %t384, ptr %l181, !tbaa !27
  %t385 = load { i64, [4 x i64] }, ptr %l180
  %t386 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr { i64, [4 x i64] }, ptr %t387, i64 0
  store { i64, [4 x i64] } %t385, ptr %t388
  %t389 = load { i64, [1 x i64] }, ptr %l3
  %t390 = mul i64 1, 16
  %t391 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t390)
  %t392 = insertvalue { i64, ptr } undef, i64 1, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t391, 1
  store { i64, ptr } %t393, ptr %l183, !tbaa !27
  %t395 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr { i64, [1 x i64] }, ptr %t396, i64 0
  store { i64, [1 x i64] } %t389, ptr %t397
  %t398 = load i32, ptr %l2, !tbaa !23
  %t399 = load %"compiler/source:Span", ptr %l4
  %t400 = load ptr, ptr %l171, !tbaa !29
  %t401 = load i32, ptr %l172, !range !{i32 0, i32 10}
  %t402 = load i32, ptr %l173, !tbaa !23
  %t403 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t404 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t407 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %s6, ptr %s6, ptr %v3, ptr %v2, ptr %t400, i32 %t401, i32 %t402, { i64, ptr } %t403, { i64, ptr } %t404, i32 %t398, %"compiler/source:Span" %t399)
  store { i64, [4 x i64] } %t407, ptr %l186
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t408 = load { i64, [4 x i64] }, ptr %l186
  store { i64, [4 x i64] } %t408, ptr %rv
  br label %ret
bb59:
  %t409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t409, ptr %l187, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l188, !tbaa !29
  %t411 = load i32, ptr %l2, !tbaa !23
  store i32 %t411, ptr %l189, !tbaa !23
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l190, !tbaa !29
  %t413 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t413, ptr %l191
  %t415 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l191)
  store %"compiler/lower:pl" %t415, ptr %l193
  br label %bb60
bb60:
  %t416 = load ptr, ptr %l190, !tbaa !29
  %t417 = load %"compiler/lower:pl", ptr %l193
  %t418 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v3, ptr %t416, %"compiler/lower:pl" %t417)
  store %"compiler/mir:Lvalue" %t418, ptr %l194
  br label %bb61
bb61:
  store { i64, [4 x i64] } zeroinitializer, ptr %t419
  %t420 = getelementptr { i64, [4 x i64] }, ptr %t419, i32 0, i32 0
  store i64 1, ptr %t420
  %t421 = load %"compiler/mir:Lvalue", ptr %l194
  %t422 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t421, 0
  %t423 = getelementptr { i64, [4 x i64] }, ptr %t419, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t422, ptr %t423
  %t424 = load { i64, [4 x i64] }, ptr %t419
  store { i64, [15 x i64] } zeroinitializer, ptr %t425
  %t426 = getelementptr { i64, [15 x i64] }, ptr %t425, i32 0, i32 0
  store i64 0, ptr %t426
  %t428 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t424, 0
  %t429 = getelementptr { i64, [15 x i64] }, ptr %t425, i32 0, i32 1
  store { { i64, [4 x i64] } } %t428, ptr %t429
  %t430 = load { i64, [15 x i64] }, ptr %t425
  %t431 = load %"compiler/source:Span", ptr %l4
  %t432 = load ptr, ptr %l188, !tbaa !29
  %t433 = load i32, ptr %l189, !tbaa !23
  %t436 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v3, ptr %t432, i32 %t433, { i64, [15 x i64] } %t430, %"compiler/source:Span" %t431)
  store { i64, [4 x i64] } %t436, ptr %l198
  br label %bb62
bb62:
  %t437 = load i32, ptr %l2, !tbaa !23
  %t438 = load %"compiler/source:Span", ptr %l4
  %t439 = load ptr, ptr %l187, !tbaa !29
  %t440 = load { i64, [4 x i64] }, ptr %l198
  %t443 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v2, ptr %v3, ptr %t439, { i64, [4 x i64] } %t440, i32 %t437, %"compiler/source:Span" %t438)
  store i32 %t443, ptr %l201
  br label %bb63
bb63:
  %t444 = load i32, ptr %l201, !tbaa !23
  store i32 %t444, ptr %l14, !tbaa !23
  %t445 = load i32, ptr %l14, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t446
  %t447 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 0
  store i64 1, ptr %t447
  %t449 = insertvalue { i32 } undef, i32 %t445, 0
  %t450 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 1
  store { i32 } %t449, ptr %t450
  %t451 = load { i64, [2 x i64] }, ptr %t446
  %t453 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t451)
  store %"compiler/lower:pl" %t453, ptr %l204
  br label %bb64
bb64:
  %t454 = load %"compiler/lower:pl", ptr %l204
  store %"compiler/lower:pl" %t454, ptr %l15
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/lower:lowering", ptr %t455, i32 0, i32 2
  %t458 = load ptr, ptr %t457, !tbaa !29
  store ptr %t458, ptr %l206, !tbaa !29
  %t459 = load i32, ptr %l2, !tbaa !23
  %t460 = load ptr, ptr %l206, !tbaa !29
  %t461 = call ptr @__olang_scope_or(ptr %v2, ptr %t460)
  %t462 = call ptr @__olang_scope_hold(ptr %t461)
  %t463 = ptrtoint ptr %t462 to i64
  %t465 = inttoptr i64 %t463 to ptr
  %t466 = load ptr, ptr %l206, !tbaa !29
  %t468 = call i1 @compiler_2fmir_2eHasFields(ptr %t465, ptr %t466, i32 %t459)
  store i1 %t468, ptr %l209
  br label %bb65
bb65:
  %t469 = load i1, ptr %l209, !tbaa !21
  br i1 %t469, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s7
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i32, ptr %l2, !tbaa !23
  %t474 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %s7, ptr %v2, ptr %t470, i32 %t471)
  store { i64, ptr } %t474, ptr %l212
  br label %bb68
bb67:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/lower:lowering", ptr %t475, i32 0, i32 2
  %t478 = load ptr, ptr %t477, !tbaa !29
  store ptr %t478, ptr %l271, !tbaa !29
  %t479 = load i32, ptr %l2, !tbaa !23
  %t480 = load ptr, ptr %l271, !tbaa !29
  %t481 = call ptr @__olang_scope_or(ptr %v2, ptr %t480)
  %t482 = call ptr @__olang_scope_hold(ptr %t481)
  %t483 = ptrtoint ptr %t482 to i64
  %t485 = inttoptr i64 %t483 to ptr
  %t486 = load ptr, ptr %l271, !tbaa !29
  %t488 = call i1 @compiler_2fmir_2eHasCases(ptr %t485, ptr %t486, i32 %t479)
  store i1 %t488, ptr %l274
  br label %bb90
bb68:
  %t489 = load { i64, ptr }, ptr %l212, !tbaa !27
  store { i64, ptr } %t489, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t490 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t490, 0
  store i64 %t492, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t494 = load i64, ptr %l18, !tbaa !24
  %t495 = load i64, ptr %l17, !tbaa !24
  %t498 = icmp sgt i64 %t494, %t495
  br i1 %t498, label %bb69, label %bb70
bb69:
  %t500 = load i64, ptr %l19, !tbaa !24
  %t502 = icmp sgt i64 %t500, 0
  br i1 %t502, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l218, !tbaa !24
  br label %bb74
bb71:
  %t504 = load i64, ptr %l18, !tbaa !24
  %t505 = load i64, ptr %l17, !tbaa !24
  %t508 = sub i64 %t504, %t505
  %t509 = load i64, ptr %l19, !tbaa !24
  %t512 = add i64 %t508, %t509
  %t514 = sub i64 %t512, 1
  %t515 = load i64, ptr %l19, !tbaa !24
  %t518 = sdiv i64 %t514, %t515
  store i64 %t518, ptr %l221, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb73
bb73:
  %t520 = load i64, ptr %l221, !tbaa !24
  store i64 %t520, ptr %l218, !tbaa !24
  br label %bb74
bb74:
  %t521 = load i64, ptr %l218, !tbaa !24
  store i64 %t521, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s9
  %t522 = load i64, ptr %l21, !tbaa !24
  %t523 = load i64, ptr %l20, !tbaa !24
  %t526 = icmp slt i64 %t522, %t523
  %t528 = xor i1 %t526, true
  br i1 %t528, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s9)
  br label %bb89
bb77:
  br label %bb78
bb78:
  %t530 = load i64, ptr %l17, !tbaa !24
  %t531 = load i64, ptr %l21, !tbaa !24
  %t532 = load i64, ptr %l19, !tbaa !24
  %t535 = mul i64 %t531, %t532
  %t538 = add i64 %t530, %t535
  store i64 %t538, ptr %l22, !tbaa !24
  %t540 = load ptr, ptr %l0, !tbaa !29
  store ptr %t540, ptr %l239, !tbaa !29
  %t541 = load %"compiler/lower:pl", ptr %l15
  store %"compiler/lower:pl" %t541, ptr %l240
  %t543 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s9, ptr %l240)
  store %"compiler/lower:pl" %t543, ptr %l242
  br label %bb79
bb79:
  %t544 = load i64, ptr %l22, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t545
  %t546 = getelementptr { i64, [1 x i64] }, ptr %t545, i32 0, i32 0
  store i64 0, ptr %t546
  %t548 = insertvalue { i64 } undef, i64 %t544, 0
  %t549 = getelementptr { i64, [1 x i64] }, ptr %t545, i32 0, i32 1
  store { i64 } %t548, ptr %t549
  %t550 = load { i64, [1 x i64] }, ptr %t545
  %t551 = load ptr, ptr %l239, !tbaa !29
  %t552 = load %"compiler/lower:pl", ptr %l242
  %t554 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s9, ptr %s9, ptr %t551, %"compiler/lower:pl" %t552, { i64, [1 x i64] } %t550)
  store %"compiler/lower:pl" %t554, ptr %l245
  br label %bb80
bb80:
  %t555 = load %"compiler/lower:pl", ptr %l245
  store %"compiler/lower:pl" %t555, ptr %l23
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load i32, ptr %l2, !tbaa !23
  %t558 = load i64, ptr %l22, !tbaa !24
  %t562 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopySlots(ptr %v0, ptr %v3, ptr %t556, i32 %t557, i64 %t558)
  store i64 %t562, ptr %l249
  br label %bb81
bb81:
  %t563 = load i64, ptr %l249, !tbaa !24
  store i64 %t563, ptr %l24, !tbaa !24
  %t564 = load i64, ptr %l24, !tbaa !24
  %t566 = icmp sge i64 %t564, 0
  br i1 %t566, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s10
  %t568 = load ptr, ptr %l0, !tbaa !29
  store ptr %t568, ptr %l252, !tbaa !29
  %t569 = load %"compiler/lower:pl", ptr %l23
  store %"compiler/lower:pl" %t569, ptr %l253
  %t571 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s10, ptr %l253)
  store %"compiler/lower:pl" %t571, ptr %l255
  br label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s11
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load %"compiler/lower:pl", ptr %l23
  %t574 = load i64, ptr %l22, !tbaa !24
  %t576 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr i32, ptr %t577, i64 %t574
  %t579 = load i32, ptr %t578, !tbaa !33
  %t580 = load { i64, [1 x i64] }, ptr %l3
  %t581 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %s11, ptr %v2, ptr %v3, ptr %t572, %"compiler/lower:pl" %t573, i32 %t579, { i64, [1 x i64] } %t580, %"compiler/source:Span" %t581)
  br label %bb86
bb84:
  %t587 = load i64, ptr %l22, !tbaa !24
  %t589 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = getelementptr i32, ptr %t590, i64 %t587
  %t592 = load i32, ptr %t591, !tbaa !33
  %t593 = load i64, ptr %l24, !tbaa !24
  %t594 = load { i64, [1 x i64] }, ptr %l3
  %t595 = load %"compiler/source:Span", ptr %l4
  %t596 = load ptr, ptr %l252, !tbaa !29
  %t597 = load %"compiler/lower:pl", ptr %l255
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etextSlotCopy(ptr %v0, ptr %s10, ptr %v3, ptr %v2, ptr %t596, %"compiler/lower:pl" %t597, i32 %t592, i64 %t593, { i64, [1 x i64] } %t594, %"compiler/source:Span" %t595)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s10)
  br label %bb87
bb86:
  call void @__olang_scope_close(ptr %s11)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s9)
  br label %bb88
bb88:
  %t602 = load i64, ptr %l21, !tbaa !24
  %t605 = add i64 %t602, 1
  store i64 %t605, ptr %l21, !tbaa !24
  br label %bb75
bb89:
  call void @__olang_scope_close(ptr %s7)
  br label %bb111
bb90:
  %t607 = load i1, ptr %l274, !tbaa !21
  br i1 %t607, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s14
  %t608 = load ptr, ptr %l0, !tbaa !29
  store ptr %t608, ptr %l275, !tbaa !29
  %t609 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t609, ptr %l276, !tbaa !23
  %t610 = load ptr, ptr %l0, !tbaa !29
  store ptr %t610, ptr %l277, !tbaa !29
  %t611 = load %"compiler/lower:pl", ptr %l15
  store %"compiler/lower:pl" %t611, ptr %l278
  %t613 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s14, ptr %l278)
  store %"compiler/lower:pl" %t613, ptr %l280
  br label %bb93
bb92:
  %t614 = load ptr, ptr %l7, !tbaa !29
  store ptr %t614, ptr %l299, !tbaa !29
  %t615 = load i32, ptr %l8, !tbaa !23
  %t616 = load ptr, ptr %l299, !tbaa !29
  %t617 = call ptr @__olang_scope_or(ptr %v2, ptr %t616)
  %t618 = call ptr @__olang_scope_hold(ptr %t617)
  %t619 = ptrtoint ptr %t618 to i64
  %t621 = inttoptr i64 %t619 to ptr
  %t622 = load ptr, ptr %l299, !tbaa !29
  %t624 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t621, ptr %t622, i32 %t615)
  store i32 %t624, ptr %l302
  br label %bb99
bb93:
  %t625 = load ptr, ptr %l277, !tbaa !29
  %t626 = load %"compiler/lower:pl", ptr %l280
  %t627 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s14, ptr %v3, ptr %t625, %"compiler/lower:pl" %t626)
  store %"compiler/mir:Lvalue" %t627, ptr %l281
  br label %bb94
bb94:
  store { i64, [15 x i64] } zeroinitializer, ptr %t628
  %t629 = getelementptr { i64, [15 x i64] }, ptr %t628, i32 0, i32 0
  store i64 5, ptr %t629
  %t630 = load %"compiler/mir:Lvalue", ptr %l281
  %t631 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t630, 0
  %t632 = getelementptr { i64, [15 x i64] }, ptr %t628, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t631, ptr %t632
  %t633 = load { i64, [15 x i64] }, ptr %t628
  %t634 = load %"compiler/source:Span", ptr %l4
  %t635 = load ptr, ptr %l275, !tbaa !29
  %t636 = load i32, ptr %l276, !tbaa !23
  %t639 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v3, ptr %t635, i32 %t636, { i64, [15 x i64] } %t633, %"compiler/source:Span" %t634)
  store { i64, [4 x i64] } %t639, ptr %l284
  br label %bb95
bb95:
  %t640 = load { i64, [4 x i64] }, ptr %l284
  store { i64, [4 x i64] } %t640, ptr %l25
  %t641 = load ptr, ptr %l0, !tbaa !29
  store ptr %t641, ptr %l285, !tbaa !29
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load i32, ptr %l2, !tbaa !23
  %t646 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %s14, ptr %v2, ptr %t642, i32 %t643)
  store { i64, ptr } %t646, ptr %l288
  br label %bb96
bb96:
  %t647 = load { i64, ptr }, ptr %l288, !tbaa !27
  store { i64, ptr } %t647, ptr %l289, !tbaa !27
  %t648 = load { i64, [4 x i64] }, ptr %l25
  store { i64, [4 x i64] } %t648, ptr %l290
  %t649 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t649, ptr %l291
  %t650 = load ptr, ptr %l0, !tbaa !29
  store ptr %t650, ptr %l292, !tbaa !29
  %t651 = load %"compiler/lower:pl", ptr %l15
  store %"compiler/lower:pl" %t651, ptr %l293
  %t653 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s14, ptr %l293)
  store %"compiler/lower:pl" %t653, ptr %l295
  br label %bb97
bb97:
  %t654 = load { i64, [1 x i64] }, ptr %l3
  %t655 = load %"compiler/source:Span", ptr %l4
  %t656 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr null, i32 1
  %t657 = ptrtoint ptr %t656 to i64
  %t659 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t658, i32 0, i32 0
  %t660 = load ptr, ptr %l292, !tbaa !29
  store ptr %t660, ptr %t659, !tbaa !28
  %t661 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t658, i32 0, i32 1
  %t662 = load %"compiler/lower:pl", ptr %l295
  store %"compiler/lower:pl" %t662, ptr %t661, !tbaa !28
  %t663 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t658, i32 0, i32 2
  store { i64, [1 x i64] } %t654, ptr %t663, !tbaa !28
  %t665 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t658, i32 0, i32 3
  store %"compiler/source:Span" %t655, ptr %t665, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t667 = call ptr @__olang_scope_hold(ptr %v0)
  %t668 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t658, i32 0, i32 4
  store ptr %t667, ptr %t668, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t669 = call ptr @__olang_scope_hold(ptr %s0)
  %t670 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t658, i32 0, i32 5
  store ptr %t669, ptr %t670, !tbaa !28
  %t671 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_18, 0
  %t672 = insertvalue { ptr, ptr } %t671, ptr %t658, 1
  %t673 = load ptr, ptr %l285, !tbaa !29
  %t674 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t675 = load { i64, [4 x i64] }, ptr %l290
  %t676 = load %"compiler/source:Span", ptr %l291
  %t678 = extractvalue { ptr, ptr } %t672, 0
  %t679 = extractvalue { ptr, ptr } %t672, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epayloads(ptr %v0, ptr %s14, ptr %s14, ptr %v2, ptr %v3, ptr %t673, { i64, ptr } %t674, { i64, [4 x i64] } %t675, %"compiler/source:Span" %t676, ptr %t678, ptr %t679)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s14)
  br label %bb110
bb99:
  %t680 = load i32, ptr %l302, !range !{i32 0, i32 33}
  %t682 = trunc i64 19 to i32
  %t683 = icmp eq i32 %t680, %t682
  br i1 %t683, label %bb100, label %bb101
bb100:
  %t685 = load ptr, ptr %l7, !tbaa !29
  store ptr %t685, ptr %l305, !tbaa !29
  %t686 = load i32, ptr %l8, !tbaa !23
  %t687 = load ptr, ptr %l305, !tbaa !29
  %t688 = call ptr @__olang_scope_or(ptr %v2, ptr %t687)
  %t689 = call ptr @__olang_scope_hold(ptr %t688)
  %t690 = ptrtoint ptr %t689 to i64
  %t692 = inttoptr i64 %t690 to ptr
  %t693 = load ptr, ptr %l305, !tbaa !29
  %t695 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t692, ptr %t693, i32 %t686)
  store i32 %t695, ptr %l308
  br label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s17
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t697 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s17, ptr %v3, ptr %t696, %"compiler/source:Span" %t697, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb108
bb102:
  %t700 = load i32, ptr %l308, !tbaa !23
  store i32 %t700, ptr %l26, !tbaa !23
  %t701 = load ptr, ptr %l0, !tbaa !29
  store ptr %t701, ptr %l309, !tbaa !29
  %t702 = load ptr, ptr %l0, !tbaa !29
  store ptr %t702, ptr %l310, !tbaa !29
  %t703 = load ptr, ptr %l7, !tbaa !29
  store ptr %t703, ptr %l311, !tbaa !29
  %t704 = load ptr, ptr %l7, !tbaa !29
  store ptr %t704, ptr %l312, !tbaa !29
  %t705 = load i32, ptr %l8, !tbaa !23
  %t706 = load ptr, ptr %l312, !tbaa !29
  %t707 = call ptr @__olang_scope_or(ptr %v2, ptr %t706)
  %t708 = call ptr @__olang_scope_hold(ptr %t707)
  %t709 = ptrtoint ptr %t708 to i64
  %t711 = inttoptr i64 %t709 to ptr
  %t712 = load ptr, ptr %l312, !tbaa !29
  %t714 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t711, ptr %t712, i32 %t705)
  store i32 %t714, ptr %l315
  br label %bb103
bb103:
  %t715 = load ptr, ptr %l311, !tbaa !29
  %t716 = call ptr @__olang_scope_or(ptr %v2, ptr %t715)
  %t717 = call ptr @__olang_scope_hold(ptr %t716)
  %t718 = ptrtoint ptr %t717 to i64
  %t720 = inttoptr i64 %t718 to ptr
  %t721 = load ptr, ptr %l311, !tbaa !29
  %t722 = load i32, ptr %l315, !tbaa !23
  %t723 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %t720, ptr %t721, i32 %t722)
  store i64 %t723, ptr %l317
  br label %bb104
bb104:
  %t724 = load ptr, ptr %l310, !tbaa !29
  %t725 = load i64, ptr %l317, !tbaa !24
  %t726 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t724, i64 %t725)
  store { i64, [4 x i64] } %t726, ptr %l318
  br label %bb105
bb105:
  %t727 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t727, ptr %l319
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l320, !tbaa !29
  %t729 = load %"compiler/lower:pl", ptr %l15
  store %"compiler/lower:pl" %t729, ptr %l321
  %t731 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l321)
  store %"compiler/lower:pl" %t731, ptr %l323
  br label %bb106
bb106:
  %t732 = load i32, ptr %l26, !tbaa !23
  %t733 = load { i64, [1 x i64] }, ptr %l3
  %t734 = load %"compiler/source:Span", ptr %l4
  %t735 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr null, i32 1
  %t736 = ptrtoint ptr %t735 to i64
  %t737 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 %t736, i64 8)
  %t738 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t737, i32 0, i32 0
  %t739 = load ptr, ptr %l320, !tbaa !29
  store ptr %t739, ptr %t738, !tbaa !28
  %t740 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t737, i32 0, i32 1
  %t741 = load %"compiler/lower:pl", ptr %l323
  store %"compiler/lower:pl" %t741, ptr %t740, !tbaa !28
  %t742 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t737, i32 0, i32 2
  store i32 %t732, ptr %t742, !tbaa !28
  %t744 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t737, i32 0, i32 3
  store { i64, [1 x i64] } %t733, ptr %t744, !tbaa !28
  %t746 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t737, i32 0, i32 4
  store %"compiler/source:Span" %t734, ptr %t746, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t748 = call ptr @__olang_scope_hold(ptr %v0)
  %t749 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t737, i32 0, i32 5
  store ptr %t748, ptr %t749, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t750 = call ptr @__olang_scope_hold(ptr %s0)
  %t751 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %t737, i32 0, i32 6
  store ptr %t750, ptr %t751, !tbaa !28
  %t752 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_20, 0
  %t753 = insertvalue { ptr, ptr } %t752, ptr %t737, 1
  %t754 = load ptr, ptr %l309, !tbaa !29
  %t755 = load { i64, [4 x i64] }, ptr %l318
  %t756 = load %"compiler/source:Span", ptr %l319
  %t758 = extractvalue { ptr, ptr } %t753, 0
  %t759 = extractvalue { ptr, ptr } %t753, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t754, { i64, [4 x i64] } %t755, %"compiler/source:Span" %t756, ptr %t758, ptr %t759)
  br label %bb107
bb107:
  br label %bb109
bb108:
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb109:
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t760 = load i32, ptr %l14, !tbaa !23
  %t762 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t760)
  store %"compiler/mir:Lvalue" %t762, ptr %l331
  br label %bb112
bb112:
  store { i64, [4 x i64] } zeroinitializer, ptr %t763
  %t764 = getelementptr { i64, [4 x i64] }, ptr %t763, i32 0, i32 0
  store i64 1, ptr %t764
  %t765 = load %"compiler/mir:Lvalue", ptr %l331
  %t766 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t765, 0
  %t767 = getelementptr { i64, [4 x i64] }, ptr %t763, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t766, ptr %t767
  %t768 = load { i64, [4 x i64] }, ptr %t763
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t768, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/typed:Item"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, [4 x i64] }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i1
  %l42 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l57 = alloca i64
  %l65 = alloca %"compiler/lower:tryCtx"
  %l72 = alloca i64
  %l75 = alloca i64
  %l95 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l118 = alloca i64
  %l121 = alloca i64
  %l141 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l148 = alloca i32
  %l149 = alloca ptr
  %l152 = alloca i32
  %l154 = alloca i1
  %l163 = alloca i1
  %l180 = alloca { i64, ptr }
  %l182 = alloca { i64, [4 x i64] }
  %l191 = alloca { i64, ptr }
  %l193 = alloca { i64, [4 x i64] }
  %l206 = alloca { i64, ptr }
  %l208 = alloca { i64, [4 x i64] }
  %l211 = alloca { i64, [4 x i64] }
  %l218 = alloca { i64, ptr }
  %l220 = alloca { i64, [4 x i64] }
  %l226 = alloca i1
  %l230 = alloca i1
  %l240 = alloca i32
  %l243 = alloca i32
  %l264 = alloca ptr
  %l280 = alloca ptr
  %l288 = alloca ptr
  %l293 = alloca i32
  %l301 = alloca i64
  %l307 = alloca i32
  %l317 = alloca ptr
  %l319 = alloca %"compiler/mir:Lvalue"
  %l324 = alloca ptr
  %l327 = alloca { i64, ptr }
  %l330 = alloca i1
  %l333 = alloca i64
  %l340 = alloca ptr
  %l341 = alloca %"compiler/source:Span"
  %l349 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %t131 = alloca { i64, [4 x i64] }, align 8
  %t299 = alloca { i64, [4 x i64] }, align 8
  %t312 = alloca { i64, [4 x i64] }, align 8
  %t349 = alloca { i64, [4 x i64] }, align 8
  %t389 = alloca { i64, [4 x i64] }, align 8
  %t498 = alloca { i64, [8 x i64] }, align 8
  %t549 = alloca { i64, [21 x i64] }, align 8
  %t665 = alloca { i64, [4 x i64] }, align 8
  %t705 = alloca { i64, [4 x i64] }, align 8
  %t708 = alloca { i64, [8 x i64] }, align 8
  %t727 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l42, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load ptr, ptr %l42, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v1, ptr %t15)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t11 to ptr
  %t23 = inttoptr i64 %t19 to ptr
  %t24 = load ptr, ptr %l42, !tbaa !29
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t21, ptr %t23, ptr %t24, i32 %t7)
  store { i64, ptr } %t26, ptr %l48
  br label %bb1
bb1:
  %t27 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l50, !tbaa !24
  %t31 = load i64, ptr %l50, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  br i1 %t32, label %bb2, label %bb3
bb2:
  %t34 = load i64, ptr %l50, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l7, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l8, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/lower:lowering", ptr %t44, i32 0, i32 21
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l57
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_b0c77cc00353838c_f9addae603786cc8)
  unreachable
bb4:
  %t49 = load i64, ptr %l57, !tbaa !24
  %t50 = sub i64 %t49, 1
  store i64 %t50, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load i64, ptr %l9, !tbaa !24
  %t54 = icmp sge i64 %t52, 0
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb7:
  br label %bb8
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 21
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = call %"compiler/lower:tryCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store %"compiler/lower:tryCtx" %t64, ptr %l65
  br label %bb9
bb9:
  %t65 = getelementptr %"compiler/lower:tryCtx", ptr %l65, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t72 = load i64, ptr %l12, !tbaa !24
  %t73 = load i64, ptr %l11, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb10, label %bb11
bb10:
  %t78 = load i64, ptr %l13, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb15
bb12:
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l13, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l13, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l75, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb14
bb14:
  %t98 = load i64, ptr %l75, !tbaa !24
  store i64 %t98, ptr %l72, !tbaa !24
  br label %bb15
bb15:
  %t99 = load i64, ptr %l72, !tbaa !24
  store i64 %t99, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  %t100 = load i64, ptr %l15, !tbaa !24
  %t101 = load i64, ptr %l14, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb17, label %bb18
bb17:
  br label %bb92
bb18:
  br label %bb19
bb19:
  %t108 = load i64, ptr %l11, !tbaa !24
  %t109 = load i64, ptr %l15, !tbaa !24
  %t110 = load i64, ptr %l13, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l16, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/lower:lowering", ptr %t118, i32 0, i32 12
  %t121 = load i1, ptr %t120, !tbaa !21
  br i1 %t121, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  br label %bb22
bb22:
  %t123 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t123, ptr %l95, !tbaa !27
  %t124 = load i64, ptr %l16, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  store ptr %t129, ptr %l17, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 0
  store i64 0, ptr %t132
  %t133 = load { i64, [4 x i64] }, ptr %t131
  store { i64, [4 x i64] } %t133, ptr %l18
  %t135 = load ptr, ptr %l17, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Clause", ptr %t135, i32 0, i32 2
  %t138 = load i1, ptr %t137, !tbaa !21
  store i1 %t138, ptr %l19, !tbaa !21
  %t140 = load ptr, ptr %l17, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Clause", ptr %t140, i32 0, i32 1
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l22, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load i64, ptr %l21, !tbaa !24
  %t150 = load i64, ptr %l22, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb25:
  br label %bb26
bb26:
  %t157 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t157, ptr %l109, !tbaa !27
  %t158 = load i64, ptr %l21, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr %"compiler/typed:Item", ptr %t161, i64 %t158
  %t163 = load %"compiler/typed:Item", ptr %t162
  store %"compiler/typed:Item" %t163, ptr %l23
  %t165 = load i1, ptr %l19, !tbaa !21
  br i1 %t165, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb28:
  br label %bb29
bb29:
  store i64 -1, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t171 = load i64, ptr %l26, !tbaa !24
  %t172 = load i64, ptr %l25, !tbaa !24
  %t175 = icmp sgt i64 %t171, %t172
  br i1 %t175, label %bb30, label %bb31
bb30:
  %t177 = load i64, ptr %l27, !tbaa !24
  %t179 = icmp sgt i64 %t177, 0
  br i1 %t179, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb35
bb32:
  %t181 = load i64, ptr %l26, !tbaa !24
  %t182 = load i64, ptr %l25, !tbaa !24
  %t185 = sub i64 %t181, %t182
  %t186 = load i64, ptr %l27, !tbaa !24
  %t189 = add i64 %t185, %t186
  %t191 = sub i64 %t189, 1
  %t192 = load i64, ptr %l27, !tbaa !24
  %t195 = sdiv i64 %t191, %t192
  store i64 %t195, ptr %l121, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb34
bb34:
  %t197 = load i64, ptr %l121, !tbaa !24
  store i64 %t197, ptr %l118, !tbaa !24
  br label %bb35
bb35:
  %t198 = load i64, ptr %l118, !tbaa !24
  store i64 %t198, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb36
bb36:
  %t199 = load i64, ptr %l29, !tbaa !24
  %t200 = load i64, ptr %l28, !tbaa !24
  %t203 = icmp slt i64 %t199, %t200
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb37, label %bb38
bb37:
  br label %bb50
bb38:
  br label %bb39
bb39:
  %t207 = load i64, ptr %l25, !tbaa !24
  %t208 = load i64, ptr %l29, !tbaa !24
  %t209 = load i64, ptr %l27, !tbaa !24
  %t212 = mul i64 %t208, %t209
  %t215 = add i64 %t207, %t212
  store i64 %t215, ptr %l30, !tbaa !24
  %t217 = load i64, ptr %l24, !tbaa !24
  %t219 = icmp slt i64 %t217, 0
  br i1 %t219, label %bb40, label %bb41
bb40:
  %t221 = load ptr, ptr %l5, !tbaa !29
  store ptr %t221, ptr %l142, !tbaa !29
  %t222 = load ptr, ptr %l5, !tbaa !29
  store ptr %t222, ptr %l143, !tbaa !29
  %t223 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t223, ptr %l144, !tbaa !27
  %t224 = load i64, ptr %l30, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i32, ptr %t227, i64 %t224
  %t229 = load i32, ptr %t228, !tbaa !33
  %t230 = load ptr, ptr %l143, !tbaa !29
  %t231 = call ptr @__olang_scope_or(ptr %v1, ptr %t230)
  %t232 = call ptr @__olang_scope_hold(ptr %t231)
  %t233 = ptrtoint ptr %t232 to i64
  %t235 = inttoptr i64 %t233 to ptr
  %t236 = load ptr, ptr %l143, !tbaa !29
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t235, ptr %t236, i32 %t229)
  store i32 %t238, ptr %l148
  br label %bb42
bb41:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb45
bb42:
  %t239 = load ptr, ptr %l5, !tbaa !29
  store ptr %t239, ptr %l149, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Item", ptr %l23, i32 0, i32 0
  %t241 = load i32, ptr %t240, !tbaa !23
  %t242 = load ptr, ptr %l149, !tbaa !29
  %t243 = call ptr @__olang_scope_or(ptr %v1, ptr %t242)
  %t244 = call ptr @__olang_scope_hold(ptr %t243)
  %t245 = ptrtoint ptr %t244 to i64
  %t247 = inttoptr i64 %t245 to ptr
  %t248 = load ptr, ptr %l149, !tbaa !29
  %t250 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t247, ptr %t248, i32 %t241)
  store i32 %t250, ptr %l152
  br label %bb43
bb43:
  %t251 = load ptr, ptr %l142, !tbaa !29
  %t252 = call ptr @__olang_scope_or(ptr %v1, ptr %t251)
  %t253 = call ptr @__olang_scope_hold(ptr %t252)
  %t254 = ptrtoint ptr %t253 to i64
  %t256 = inttoptr i64 %t254 to ptr
  %t257 = load ptr, ptr %l142, !tbaa !29
  %t258 = load i32, ptr %l148, !tbaa !23
  %t259 = load i32, ptr %l152, !tbaa !23
  %t260 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t256, ptr %t257, i32 %t258, i32 %t259)
  store i1 %t260, ptr %l154
  br label %bb44
bb44:
  %t261 = load i1, ptr %l154, !tbaa !21
  store i1 %t261, ptr %l141, !tbaa !21
  br label %bb45
bb45:
  %t262 = load i1, ptr %l141, !tbaa !21
  br i1 %t262, label %bb46, label %bb47
bb46:
  %t263 = load i64, ptr %l30, !tbaa !24
  store i64 %t263, ptr %l24, !tbaa !24
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t265 = load i64, ptr %l29, !tbaa !24
  %t268 = add i64 %t265, 1
  store i64 %t268, ptr %l29, !tbaa !24
  br label %bb36
bb50:
  %t270 = load i64, ptr %l24, !tbaa !24
  %t272 = icmp slt i64 %t270, 0
  br i1 %t272, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb52:
  br label %bb53
bb53:
  %t274 = getelementptr %"compiler/typed:Item", ptr %l23, i32 0, i32 1
  %t275 = load i64, ptr %t274, !tbaa !24
  %t277 = icmp slt i64 %t275, 0
  br i1 %t277, label %bb54, label %bb55
bb54:
  %t279 = load i64, ptr %l24, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr i1, ptr %t282, i64 %t279
  %t284 = load i1, ptr %t283, !tbaa !31
  %t286 = xor i1 %t284, true
  store i1 %t286, ptr %l163, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb56
bb56:
  %t288 = load i1, ptr %l163, !tbaa !21
  br i1 %t288, label %bb57, label %bb58
bb57:
  %t289 = load i64, ptr %l24, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr i1, ptr %t292, i64 %t289
  store i1 true, ptr %t293, !tbaa !31
  %t294 = load i64, ptr %l8, !tbaa !24
  %t297 = sub i64 %t294, 1
  store i64 %t297, ptr %l8, !tbaa !24
  br label %bb59
bb58:
  br label %bb59
bb59:
  store { i64, [4 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [4 x i64] }, ptr %t299, i32 0, i32 0
  store i64 0, ptr %t300
  %t301 = load { i64, [4 x i64] }, ptr %t299
  store { i64, [4 x i64] } %t301, ptr %l31
  %t303 = getelementptr %"compiler/typed:Item", ptr %l23, i32 0, i32 1
  %t304 = load i64, ptr %t303, !tbaa !24
  %t306 = icmp slt i64 %t304, 0
  br i1 %t306, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s15
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t310 = load { i64, [4 x i64] }, ptr %l1
  %t311 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t312
  %t313 = getelementptr { i64, [4 x i64] }, ptr %t312, i32 0, i32 0
  store i64 2, ptr %t313
  %t315 = insertvalue { i32, i64 } undef, i32 %t311, 0
  %t316 = insertvalue { i32, i64 } %t315, i64 16, 1
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t312, i32 0, i32 1
  store { i32, i64 } %t316, ptr %t317
  %t318 = load { i64, [4 x i64] }, ptr %t312
  %t319 = mul i64 2, 40
  %t320 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t319)
  %t321 = insertvalue { i64, ptr } undef, i64 2, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l180, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr { i64, [4 x i64] }, ptr %t325, i64 0
  store { i64, [4 x i64] } %t310, ptr %t326
  %t328 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr { i64, [4 x i64] }, ptr %t329, i64 1
  store { i64, [4 x i64] } %t318, ptr %t330
  %t331 = load %"compiler/source:Span", ptr %l3
  %t335 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t337 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s15, ptr %v1, ptr %v2, ptr %t308, i32 9, i32 %t309, { i64, ptr } %t335, %"compiler/source:Span" %t331)
  store { i64, [4 x i64] } %t337, ptr %l182
  br label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s16
  %t338 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t339 = load i64, ptr %l24, !tbaa !24
  %t341 = add i64 %t339, 1
  %t343 = shl i64 %t341, 16
  %t344 = getelementptr %"compiler/typed:Item", ptr %l23, i32 0, i32 1
  %t345 = load i64, ptr %t344, !tbaa !24
  %t348 = or i64 %t343, %t345
  store { i64, [4 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 0
  store i64 2, ptr %t350
  %t352 = insertvalue { i32, i64 } undef, i32 %t338, 0
  %t354 = insertvalue { i32, i64 } %t352, i64 %t348, 1
  %t355 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 1
  store { i32, i64 } %t354, ptr %t355
  %t356 = load { i64, [4 x i64] }, ptr %t349
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t360 = load { i64, [4 x i64] }, ptr %l1
  %t362 = mul i64 2, 40
  %t363 = call ptr @__olang_scope_alloc_zeroed(ptr %s16, i64 %t362)
  %t364 = insertvalue { i64, ptr } undef, i64 2, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  store { i64, ptr } %t365, ptr %l206, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i64 0
  store { i64, [4 x i64] } %t360, ptr %t369
  %t371 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t372, i64 1
  store { i64, [4 x i64] } %t356, ptr %t373
  %t374 = load %"compiler/source:Span", ptr %l3
  %t378 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t380 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s16, ptr %v1, ptr %v2, ptr %t358, i32 13, i32 %t359, { i64, ptr } %t378, %"compiler/source:Span" %t374)
  store { i64, [4 x i64] } %t380, ptr %l208
  br label %bb64
bb62:
  %t381 = load { i64, [4 x i64] }, ptr %l182
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t385 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t386 = load i64, ptr %l24, !tbaa !24
  %t388 = add i64 %t386, 1
  store { i64, [4 x i64] } zeroinitializer, ptr %t389
  %t390 = getelementptr { i64, [4 x i64] }, ptr %t389, i32 0, i32 0
  store i64 2, ptr %t390
  %t392 = insertvalue { i32, i64 } undef, i32 %t385, 0
  %t394 = insertvalue { i32, i64 } %t392, i64 %t388, 1
  %t395 = getelementptr { i64, [4 x i64] }, ptr %t389, i32 0, i32 1
  store { i32, i64 } %t394, ptr %t395
  %t396 = load { i64, [4 x i64] }, ptr %t389
  %t397 = mul i64 2, 40
  %t398 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t397)
  %t399 = insertvalue { i64, ptr } undef, i64 2, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  store { i64, ptr } %t400, ptr %l191, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, [4 x i64] }, ptr %t403, i64 0
  store { i64, [4 x i64] } %t381, ptr %t404
  %t406 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr { i64, [4 x i64] }, ptr %t407, i64 1
  store { i64, [4 x i64] } %t396, ptr %t408
  %t409 = load %"compiler/source:Span", ptr %l3
  %t413 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t415 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s15, ptr %v1, ptr %v2, ptr %t382, i32 13, i32 %t383, { i64, ptr } %t413, %"compiler/source:Span" %t409)
  store { i64, [4 x i64] } %t415, ptr %l193
  br label %bb63
bb63:
  %t416 = load { i64, [4 x i64] }, ptr %l193
  store { i64, [4 x i64] } %t416, ptr %l31
  call void @__olang_scope_close(ptr %s15)
  br label %bb65
bb64:
  %t417 = load { i64, [4 x i64] }, ptr %l208
  store { i64, [4 x i64] } %t417, ptr %l31
  call void @__olang_scope_close(ptr %s16)
  br label %bb65
bb65:
  %t418 = load { i64, [4 x i64] }, ptr %l18
  %t420 = extractvalue { i64, [4 x i64] } %t418, 0
  %t421 = icmp eq i64 %t420, 0
  br i1 %t421, label %bb66, label %bb67
bb66:
  %t423 = load { i64, [4 x i64] }, ptr %l31
  store { i64, [4 x i64] } %t423, ptr %l211
  br label %bb69
bb67:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t427 = load { i64, [4 x i64] }, ptr %l18
  %t428 = load { i64, [4 x i64] }, ptr %l31
  %t429 = mul i64 2, 40
  %t430 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t429)
  %t431 = insertvalue { i64, ptr } undef, i64 2, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t430, 1
  store { i64, ptr } %t432, ptr %l218, !tbaa !27
  %t434 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = getelementptr { i64, [4 x i64] }, ptr %t435, i64 0
  store { i64, [4 x i64] } %t427, ptr %t436
  %t438 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr { i64, [4 x i64] }, ptr %t439, i64 1
  store { i64, [4 x i64] } %t428, ptr %t440
  %t441 = load %"compiler/source:Span", ptr %l3
  %t445 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t447 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %v1, ptr %v2, ptr %t425, i32 11, i32 %t426, { i64, ptr } %t445, %"compiler/source:Span" %t441)
  store { i64, [4 x i64] } %t447, ptr %l220
  br label %bb68
bb68:
  %t448 = load { i64, [4 x i64] }, ptr %l220
  store { i64, [4 x i64] } %t448, ptr %l211
  br label %bb69
bb69:
  %t449 = load { i64, [4 x i64] }, ptr %l211
  store { i64, [4 x i64] } %t449, ptr %l18
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb70:
  %t450 = load i64, ptr %l21, !tbaa !24
  %t453 = add i64 %t450, 1
  store i64 %t453, ptr %l21, !tbaa !24
  br label %bb23
bb71:
  %t455 = load i1, ptr %l19, !tbaa !21
  %t457 = xor i1 %t455, true
  br i1 %t457, label %bb72, label %bb73
bb72:
  %t459 = load { i64, [4 x i64] }, ptr %l18
  %t461 = extractvalue { i64, [4 x i64] } %t459, 0
  %t462 = icmp eq i64 %t461, 0
  store i1 %t462, ptr %l226, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb74
bb74:
  %t464 = load i1, ptr %l226, !tbaa !21
  br i1 %t464, label %bb75, label %bb76
bb75:
  br label %bb91
bb76:
  br label %bb77
bb77:
  %t465 = load i1, ptr %l19, !tbaa !21
  br i1 %t465, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l230, !tbaa !21
  br label %bb80
bb79:
  %t467 = load i64, ptr %l8, !tbaa !24
  %t469 = icmp eq i64 %t467, 0
  store i1 %t469, ptr %l230, !tbaa !21
  br label %bb80
bb80:
  %t471 = load i1, ptr %l230, !tbaa !21
  br i1 %t471, label %bb81, label %bb82
bb81:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i64, ptr %l9, !tbaa !24
  %t474 = load i64, ptr %l16, !tbaa !24
  %t475 = load { i64, [4 x i64] }, ptr %l1
  %t476 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t472, i64 %t473, i64 %t474, { i64, [4 x i64] } %t475, i32 %t476)
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb84:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/lower:lowering", ptr %t482, i32 0, i32 3
  %t486 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t484)
  store i32 %t486, ptr %l240
  br label %bb85
bb85:
  %t487 = load i32, ptr %l240, !tbaa !23
  store i32 %t487, ptr %l34, !tbaa !23
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr %"compiler/lower:lowering", ptr %t488, i32 0, i32 3
  %t492 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t490)
  store i32 %t492, ptr %l243
  br label %bb86
bb86:
  %t493 = load i32, ptr %l243, !tbaa !23
  store i32 %t493, ptr %l35, !tbaa !23
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load { i64, [4 x i64] }, ptr %l18
  %t496 = load i32, ptr %l34, !tbaa !23
  %t497 = load i32, ptr %l35, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t498
  %t499 = getelementptr { i64, [8 x i64] }, ptr %t498, i32 0, i32 0
  store i64 2, ptr %t499
  %t501 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t495, 0
  %t503 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t501, i32 %t496, 1
  %t505 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t503, i32 %t497, 2
  %t506 = getelementptr { i64, [8 x i64] }, ptr %t498, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t505, ptr %t506
  %t507 = load { i64, [8 x i64] }, ptr %t498
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t494, { i64, [8 x i64] } %t507)
  br label %bb87
bb87:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load i32, ptr %l34, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t510, i32 %t511)
  br label %bb88
bb88:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i64, ptr %l9, !tbaa !24
  %t516 = load i64, ptr %l16, !tbaa !24
  %t517 = load { i64, [4 x i64] }, ptr %l1
  %t518 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t514, i64 %t515, i64 %t516, { i64, [4 x i64] } %t517, i32 %t518)
  br label %bb89
bb89:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load i32, ptr %l35, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t524, i32 %t525)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t528 = load i64, ptr %l15, !tbaa !24
  %t531 = add i64 %t528, 1
  store i64 %t531, ptr %l15, !tbaa !24
  br label %bb16
bb92:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr %"compiler/lower:lowering", ptr %t533, i32 0, i32 21
  %t536 = load i64, ptr %l9, !tbaa !24
  %t539 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eRef_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %s2, ptr %t535, i64 %t536)
  store ptr %t539, ptr %l264
  br label %bb93
bb93:
  %t540 = load ptr, ptr %l264, !tbaa !29
  %t542 = getelementptr %"compiler/lower:tryCtx", ptr %t540, i32 0, i32 2
  %t543 = load i1, ptr %t542, !tbaa !21
  br i1 %t543, label %bb94, label %bb95
bb94:
  br i1 %a4, label %bb96, label %bb97
bb95:
  br label %bb101
bb96:
  store %olang.scope zeroinitializer, ptr %s22
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load %"compiler/source:Span", ptr %l3
  store { i64, [21 x i64] } zeroinitializer, ptr %t549
  %t550 = getelementptr { i64, [21 x i64] }, ptr %t549, i32 0, i32 0
  store i64 14, ptr %t550
  %t552 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t548, 0
  %t553 = getelementptr { i64, [21 x i64] }, ptr %t549, i32 0, i32 1
  store { %"compiler/source:Span" } %t552, ptr %t553
  %t554 = load { i64, [21 x i64] }, ptr %t549
  %t556 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 176, i64 8)
  store { i64, [21 x i64] } %t554, ptr %t556
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s22, ptr %v1, ptr %v2, ptr %t547, ptr %t556)
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s22)
  br label %bb99
bb99:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load { i64, [4 x i64] }, ptr %l1
  %t561 = load i32, ptr %l2, !tbaa !23
  %t562 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %v1, ptr %v2, ptr %t559, { i64, [4 x i64] } %t560, i32 %t561, %"compiler/source:Span" %t562, i32 14, i1 false)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb101:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = getelementptr %"compiler/lower:lowering", ptr %t568, i32 0, i32 21
  %t571 = load i64, ptr %l9, !tbaa !24
  %t574 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eRef_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %s2, ptr %t570, i64 %t571)
  store ptr %t574, ptr %l280
  br label %bb102
bb102:
  %t575 = load ptr, ptr %l280, !tbaa !29
  %t577 = getelementptr %"compiler/lower:tryCtx", ptr %t575, i32 0, i32 3
  %t578 = load i1, ptr %t577, !tbaa !21
  %t580 = xor i1 %t578, true
  br i1 %t580, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s2)
  br label %bb106
bb106:
  %t582 = load i64, ptr %l9, !tbaa !24
  %t585 = sub i64 %t582, 1
  store i64 %t585, ptr %l9, !tbaa !24
  br label %bb5
bb107:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t589 = getelementptr %"compiler/lower:lowering", ptr %t587, i32 0, i32 2
  %t590 = load ptr, ptr %t589, !tbaa !29
  store ptr %t590, ptr %l288, !tbaa !29
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/lower:lowering", ptr %t591, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !29
  %t596 = getelementptr %"compiler/typed:Body", ptr %t594, i32 0, i32 2
  %t597 = load i32, ptr %t596, !tbaa !23
  %t598 = load ptr, ptr %l288, !tbaa !29
  %t599 = call ptr @__olang_scope_or(ptr %v1, ptr %t598)
  %t600 = call ptr @__olang_scope_hold(ptr %t599)
  %t601 = ptrtoint ptr %t600 to i64
  %t603 = inttoptr i64 %t601 to ptr
  %t604 = load ptr, ptr %l288, !tbaa !29
  %t606 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t603, ptr %t604, i32 %t597)
  store i32 %t606, ptr %l293
  br label %bb108
bb108:
  %t607 = load i32, ptr %l293, !tbaa !23
  store i32 %t607, ptr %l36, !tbaa !23
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/lower:lowering", ptr %t608, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !29
  %t613 = getelementptr %"compiler/typed:Body", ptr %t611, i32 0, i32 1
  %t614 = load { i64, [2 x i64] }, ptr %t613
  %t618 = extractvalue { i64, [2 x i64] } %t614, 0
  %t619 = icmp eq i64 %t618, 5
  br i1 %t619, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb123
bb111:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = getelementptr %"compiler/lower:lowering", ptr %t621, i32 0, i32 21
  %t625 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t623)
  store i64 %t625, ptr %l301
  br label %bb112
bb112:
  %t626 = load i64, ptr %l301, !tbaa !24
  %t627 = icmp sgt i64 %t626, 0
  br i1 %t627, label %bb113, label %bb114
bb113:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load { i64, [4 x i64] }, ptr %l1
  %t631 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t632 = load %"compiler/source:Span", ptr %l3
  %t637 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v1, ptr %v2, ptr %t629, { i64, [4 x i64] } %t630, i32 %t631, %"compiler/source:Span" %t632)
  store i32 %t637, ptr %l307
  br label %bb115
bb114:
  br label %bb122
bb115:
  %t638 = load i32, ptr %l307, !tbaa !23
  store i32 %t638, ptr %l38, !tbaa !23
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = getelementptr %"compiler/lower:lowering", ptr %t639, i32 0, i32 28
  %t642 = load i1, ptr %t641, !tbaa !21
  store i1 %t642, ptr %l39, !tbaa !21
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t646 = getelementptr %"compiler/lower:lowering", ptr %t644, i32 0, i32 28
  store i1 true, ptr %t646, !tbaa !21
  %t647 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v3, ptr %v1, ptr %v2, ptr %v4, ptr %t647, i64 0)
  br label %bb116
bb116:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load i1, ptr %l39, !tbaa !21
  %t653 = getelementptr %"compiler/lower:lowering", ptr %t649, i32 0, i32 28
  store i1 %t650, ptr %t653, !tbaa !21
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = getelementptr %"compiler/lower:lowering", ptr %t654, i32 0, i32 12
  %t657 = load i1, ptr %t656, !tbaa !21
  %t659 = xor i1 %t657, true
  br i1 %t659, label %bb117, label %bb118
bb117:
  %t661 = load ptr, ptr %l0, !tbaa !29
  store ptr %t661, ptr %l317, !tbaa !29
  %t662 = load i32, ptr %l38, !tbaa !23
  %t664 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t662)
  store %"compiler/mir:Lvalue" %t664, ptr %l319
  br label %bb119
bb118:
  br label %bb121
bb119:
  store { i64, [4 x i64] } zeroinitializer, ptr %t665
  %t666 = getelementptr { i64, [4 x i64] }, ptr %t665, i32 0, i32 0
  store i64 1, ptr %t666
  %t667 = load %"compiler/mir:Lvalue", ptr %l319
  %t668 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t667, 0
  %t669 = getelementptr { i64, [4 x i64] }, ptr %t665, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t668, ptr %t669
  %t670 = load { i64, [4 x i64] }, ptr %t665
  %t671 = load i32, ptr %l2, !tbaa !23
  %t672 = load %"compiler/source:Span", ptr %l3
  %t673 = load ptr, ptr %l317, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %v1, ptr %v2, ptr %t673, { i64, [4 x i64] } %t670, i32 %t671, %"compiler/source:Span" %t672, i32 15, i1 true)
  br label %bb120
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb122:
  br label %bb128
bb123:
  br i1 true, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_1378acbf535452a2_3a9100f5c9d7e1f6)
  unreachable
bb128:
  %t678 = load ptr, ptr %l5, !tbaa !29
  store ptr %t678, ptr %l324, !tbaa !29
  %t679 = load i32, ptr %l36, !tbaa !23
  %t680 = load ptr, ptr %l324, !tbaa !29
  %t681 = call ptr @__olang_scope_or(ptr %v1, ptr %t680)
  %t682 = call ptr @__olang_scope_hold(ptr %t681)
  %t683 = ptrtoint ptr %t682 to i64
  %t685 = inttoptr i64 %t683 to ptr
  %t686 = load ptr, ptr %l324, !tbaa !29
  %t688 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t685, ptr %s0, ptr %t686, i32 %t679)
  store { i64, ptr } %t688, ptr %l327
  br label %bb129
bb129:
  %t689 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t690 = extractvalue { i64, ptr } %t689, 0
  %t692 = icmp eq i64 %t690, 0
  br i1 %t692, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l330, !tbaa !21
  br label %bb133
bb131:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = getelementptr %"compiler/lower:lowering", ptr %t694, i32 0, i32 21
  %t698 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %t696)
  store i64 %t698, ptr %l333
  br label %bb132
bb132:
  %t699 = load i64, ptr %l333, !tbaa !24
  %t700 = icmp eq i64 %t699, 0
  store i1 %t700, ptr %l330, !tbaa !21
  br label %bb133
bb133:
  %t702 = load i1, ptr %l330, !tbaa !21
  br i1 %t702, label %bb134, label %bb135
bb134:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t705
  %t706 = getelementptr { i64, [4 x i64] }, ptr %t705, i32 0, i32 0
  store i64 0, ptr %t706
  %t707 = load { i64, [4 x i64] }, ptr %t705
  store { i64, [8 x i64] } zeroinitializer, ptr %t708
  %t709 = getelementptr { i64, [8 x i64] }, ptr %t708, i32 0, i32 0
  store i64 9, ptr %t709
  %t711 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t704, 0
  %t713 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t711, i32 3, 1
  %t715 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t713, { i64, [4 x i64] } %t707, 2
  %t716 = getelementptr { i64, [8 x i64] }, ptr %t708, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t715, ptr %t716
  %t717 = load { i64, [8 x i64] }, ptr %t708
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v1, ptr %t703, { i64, [8 x i64] } %t717)
  br label %bb136
bb135:
  br label %bb137
bb136:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb137:
  %t720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t720, ptr %l340, !tbaa !29
  %t721 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t721, ptr %l341
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t724 = load { i64, [4 x i64] }, ptr %l1
  %t725 = load i32, ptr %l2, !tbaa !23
  %t726 = load i32, ptr %l36, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t727
  %t728 = getelementptr { i64, [15 x i64] }, ptr %t727, i32 0, i32 0
  store i64 11, ptr %t728
  %t730 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t724, 0
  %t732 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t730, i32 %t725, 1
  %t734 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t732, i32 %t726, 2
  %t735 = getelementptr { i64, [15 x i64] }, ptr %t727, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t734, ptr %t735
  %t736 = load { i64, [15 x i64] }, ptr %t727
  %t737 = load %"compiler/source:Span", ptr %l3
  %t742 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v2, ptr %t722, i32 %t723, { i64, [15 x i64] } %t736, %"compiler/source:Span" %t737)
  store { i64, [4 x i64] } %t742, ptr %l349
  br label %bb138
bb138:
  %t743 = load ptr, ptr %l340, !tbaa !29
  %t744 = load %"compiler/source:Span", ptr %l341
  %t745 = load { i64, [4 x i64] }, ptr %l349
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t743, %"compiler/source:Span" %t744, { i64, [4 x i64] } %t745, i1 true)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eelemCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l28 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca %"compiler/lower:pl"
  %l37 = alloca %"compiler/lower:pl"
  %l41 = alloca { i64, [4 x i64] }
  %l42 = alloca ptr
  %l43 = alloca %"compiler/lower:pl"
  %l45 = alloca %"compiler/lower:pl"
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca ptr
  %l54 = alloca i1
  %l56 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca %"compiler/lower:pl"
  %l64 = alloca %"compiler/lower:pl"
  %l68 = alloca { i64, [4 x i64] }
  %l69 = alloca ptr
  %l72 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca %"compiler/lower:pl"
  %l77 = alloca %"compiler/lower:pl"
  %l81 = alloca { i64, [4 x i64] }
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca %"compiler/lower:pl"
  %l88 = alloca %"compiler/lower:pl"
  %l89 = alloca %"compiler/mir:Lvalue"
  %l93 = alloca { i64, [4 x i64] }
  %l96 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i32
  %l105 = alloca %"compiler/lower:pl"
  %l108 = alloca { i64, ptr }
  %l111 = alloca %"compiler/mir:Lvalue"
  %l113 = alloca ptr
  %l116 = alloca %"compiler/lower:pl"
  %l121 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t182 = alloca { i64, [4 x i64] }, align 8
  %t188 = alloca { i64, [15 x i64] }, align 8
  %t222 = alloca { i64, [2 x i64] }, align 8
  %t250 = alloca { i64, [4 x i64] }, align 8
  %t259 = alloca { i64, [2 x i64] }, align 8
  %t278 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 12
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_17c5a608fc43bcc0_8499774d5e0fa2c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/lower:Lowerer", ptr %t14, i32 0, i32 12
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:lowering", ptr %t19, i32 0, i32 2
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = call ptr @__olang_scope_or(ptr %v2, ptr %t24)
  %t26 = call ptr @__olang_scope_hold(ptr %t25)
  %t27 = ptrtoint ptr %t26 to i64
  %t29 = inttoptr i64 %t27 to ptr
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t29, ptr %t30, i32 %t23)
  store i1 %t32, ptr %l20
  br label %bb4
bb4:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l6, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l23, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v2, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %t45, ptr %t46, i32 %t39, i32 0)
  store i32 %t48, ptr %l26
  br label %bb7
bb6:
  br label %bb17
bb7:
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = call ptr @__olang_scope_or(ptr %v3, ptr %t49)
  %t51 = call ptr @__olang_scope_hold(ptr %t50)
  %t52 = ptrtoint ptr %t51 to i64
  %t54 = inttoptr i64 %t52 to ptr
  %t55 = load ptr, ptr %l21, !tbaa !29
  %t56 = load i32, ptr %l26, !tbaa !23
  %t57 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eElemPlace(ptr %t54, ptr %t55, i32 %t56)
  store i64 %t57, ptr %l28
  br label %bb8
bb8:
  %t58 = load i64, ptr %l28, !tbaa !24
  store i64 %t58, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l6, !tbaa !29
  store ptr %t59, ptr %l29, !tbaa !29
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l29, !tbaa !29
  %t62 = call ptr @__olang_scope_or(ptr %v3, ptr %t61)
  %t63 = call ptr @__olang_scope_hold(ptr %t62)
  %t64 = ptrtoint ptr %t63 to i64
  %t66 = inttoptr i64 %t64 to ptr
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t69 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %t66, ptr %t67, i64 %t60)
  store i1 %t69, ptr %l32
  br label %bb9
bb9:
  %t70 = load i1, ptr %l32, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l34, !tbaa !29
  %t74 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t74, ptr %l35
  %t76 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l35)
  store %"compiler/lower:pl" %t76, ptr %l37
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t77 = load i32, ptr %l2, !tbaa !23
  %t78 = load { i64, [1 x i64] }, ptr %l3
  %t79 = load %"compiler/source:Span", ptr %l5
  %t80 = load ptr, ptr %l34, !tbaa !29
  %t81 = load %"compiler/lower:pl", ptr %l37
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyAt(ptr %v0, ptr %s2, ptr %v2, ptr %v3, ptr %t80, %"compiler/lower:pl" %t81, i32 %t77, { i64, [1 x i64] } %t78, %"compiler/source:Span" %t79, i1 false, i1 false)
  store { i64, [4 x i64] } %t85, ptr %l41
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t86 = load { i64, [4 x i64] }, ptr %l41
  store { i64, [4 x i64] } %t86, ptr %rv
  br label %ret
bb14:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l42, !tbaa !29
  %t88 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t88, ptr %l43
  %t90 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s1, ptr %l43)
  store %"compiler/lower:pl" %t90, ptr %l45
  br label %bb15
bb15:
  %t91 = load i32, ptr %l2, !tbaa !23
  %t92 = load i64, ptr %l7, !tbaa !24
  %t93 = load { i64, [1 x i64] }, ptr %l4
  %t94 = load %"compiler/source:Span", ptr %l5
  %t95 = load ptr, ptr %l42, !tbaa !29
  %t96 = load %"compiler/lower:pl", ptr %l45
  %t101 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eelemArrayCopy(ptr %v0, ptr %s1, ptr %v3, ptr %v2, ptr %t95, %"compiler/lower:pl" %t96, i32 %t91, i64 %t92, { i64, [1 x i64] } %t93, %"compiler/source:Span" %t94)
  store { i64, [4 x i64] } %t101, ptr %l50
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t102 = load { i64, [4 x i64] }, ptr %l50
  store { i64, [4 x i64] } %t102, ptr %rv
  br label %ret
bb17:
  %t103 = load ptr, ptr %l6, !tbaa !29
  store ptr %t103, ptr %l51, !tbaa !29
  %t104 = load i32, ptr %l2, !tbaa !23
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t106 = call ptr @__olang_scope_or(ptr %v3, ptr %t105)
  %t107 = call ptr @__olang_scope_hold(ptr %t106)
  %t108 = ptrtoint ptr %t107 to i64
  %t110 = inttoptr i64 %t108 to ptr
  %t111 = load ptr, ptr %l51, !tbaa !29
  %t113 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %t110, ptr %t111, i32 %t104)
  store i1 %t113, ptr %l54
  br label %bb18
bb18:
  %t114 = load i1, ptr %l54, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb19, label %bb20
bb19:
  %t117 = load ptr, ptr %l6, !tbaa !29
  store ptr %t117, ptr %l57, !tbaa !29
  %t118 = load i32, ptr %l2, !tbaa !23
  %t119 = load ptr, ptr %l57, !tbaa !29
  %t120 = call ptr @__olang_scope_or(ptr %v3, ptr %t119)
  %t121 = call ptr @__olang_scope_hold(ptr %t120)
  %t122 = ptrtoint ptr %t121 to i64
  %t124 = inttoptr i64 %t122 to ptr
  %t125 = load ptr, ptr %l57, !tbaa !29
  %t127 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eEntryOnly(ptr %t124, ptr %t125, i32 %t118)
  store i1 %t127, ptr %l60
  br label %bb21
bb20:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb22
bb21:
  %t128 = load i1, ptr %l60, !tbaa !21
  store i1 %t128, ptr %l56, !tbaa !21
  br label %bb22
bb22:
  %t129 = load i1, ptr %l56, !tbaa !21
  br i1 %t129, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l61, !tbaa !29
  %t131 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t131, ptr %l62
  %t133 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s3, ptr %l62)
  store %"compiler/lower:pl" %t133, ptr %l64
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t134 = load i32, ptr %l2, !tbaa !23
  %t135 = load { i64, [1 x i64] }, ptr %l4
  %t136 = load %"compiler/source:Span", ptr %l5
  %t137 = load ptr, ptr %l61, !tbaa !29
  %t138 = load %"compiler/lower:pl", ptr %l64
  %t142 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eentryCopy(ptr %v0, ptr %s3, ptr %v3, ptr %v2, ptr %t137, %"compiler/lower:pl" %t138, i32 %t134, { i64, [1 x i64] } %t135, %"compiler/source:Span" %t136)
  store { i64, [4 x i64] } %t142, ptr %l68
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t143 = load { i64, [4 x i64] }, ptr %l68
  store { i64, [4 x i64] } %t143, ptr %rv
  br label %ret
bb27:
  %t144 = load ptr, ptr %l6, !tbaa !29
  store ptr %t144, ptr %l69, !tbaa !29
  %t145 = load i32, ptr %l2, !tbaa !23
  %t146 = load ptr, ptr %l69, !tbaa !29
  %t147 = call ptr @__olang_scope_or(ptr %v3, ptr %t146)
  %t148 = call ptr @__olang_scope_hold(ptr %t147)
  %t149 = ptrtoint ptr %t148 to i64
  %t151 = inttoptr i64 %t149 to ptr
  %t152 = load ptr, ptr %l69, !tbaa !29
  %t154 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %t151, ptr %t152, i32 %t145)
  store i1 %t154, ptr %l72
  br label %bb28
bb28:
  %t155 = load i1, ptr %l72, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l74, !tbaa !29
  %t159 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t159, ptr %l75
  %t161 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s4, ptr %l75)
  store %"compiler/lower:pl" %t161, ptr %l77
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t162 = load i32, ptr %l2, !tbaa !23
  %t163 = load { i64, [1 x i64] }, ptr %l3
  %t164 = load %"compiler/source:Span", ptr %l5
  %t165 = load ptr, ptr %l74, !tbaa !29
  %t166 = load %"compiler/lower:pl", ptr %l77
  %t170 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyAt(ptr %v0, ptr %s4, ptr %v2, ptr %v3, ptr %t165, %"compiler/lower:pl" %t166, i32 %t162, { i64, [1 x i64] } %t163, %"compiler/source:Span" %t164, i1 false, i1 false)
  store { i64, [4 x i64] } %t170, ptr %l81
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t171 = load { i64, [4 x i64] }, ptr %l81
  store { i64, [4 x i64] } %t171, ptr %rv
  br label %ret
bb33:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l82, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l83, !tbaa !29
  %t174 = load i32, ptr %l2, !tbaa !23
  store i32 %t174, ptr %l84, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l85, !tbaa !29
  %t176 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t176, ptr %l86
  %t178 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l86)
  store %"compiler/lower:pl" %t178, ptr %l88
  br label %bb34
bb34:
  %t179 = load ptr, ptr %l85, !tbaa !29
  %t180 = load %"compiler/lower:pl", ptr %l88
  %t181 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s0, ptr %v3, ptr %t179, %"compiler/lower:pl" %t180)
  store %"compiler/mir:Lvalue" %t181, ptr %l89
  br label %bb35
bb35:
  store { i64, [4 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 0
  store i64 1, ptr %t183
  %t184 = load %"compiler/mir:Lvalue", ptr %l89
  %t185 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t184, 0
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t185, ptr %t186
  %t187 = load { i64, [4 x i64] }, ptr %t182
  store { i64, [15 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [15 x i64] }, ptr %t188, i32 0, i32 0
  store i64 0, ptr %t189
  %t191 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t187, 0
  %t192 = getelementptr { i64, [15 x i64] }, ptr %t188, i32 0, i32 1
  store { { i64, [4 x i64] } } %t191, ptr %t192
  %t193 = load { i64, [15 x i64] }, ptr %t188
  %t194 = load %"compiler/source:Span", ptr %l5
  %t195 = load ptr, ptr %l83, !tbaa !29
  %t196 = load i32, ptr %l84, !tbaa !23
  %t199 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v2, ptr %v3, ptr %t195, i32 %t196, { i64, [15 x i64] } %t193, %"compiler/source:Span" %t194)
  store { i64, [4 x i64] } %t199, ptr %l93
  br label %bb36
bb36:
  %t200 = load i32, ptr %l2, !tbaa !23
  %t201 = load %"compiler/source:Span", ptr %l5
  %t202 = load ptr, ptr %l82, !tbaa !29
  %t203 = load { i64, [4 x i64] }, ptr %l93
  %t206 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v2, ptr %v3, ptr %t202, { i64, [4 x i64] } %t203, i32 %t200, %"compiler/source:Span" %t201)
  store i32 %t206, ptr %l96
  br label %bb37
bb37:
  %t207 = load i32, ptr %l96, !tbaa !23
  store i32 %t207, ptr %l8, !tbaa !23
  %t208 = load ptr, ptr %l6, !tbaa !29
  store ptr %t208, ptr %l97, !tbaa !29
  %t209 = load i32, ptr %l2, !tbaa !23
  %t210 = load ptr, ptr %l97, !tbaa !29
  %t211 = call ptr @__olang_scope_or(ptr %v3, ptr %t210)
  %t212 = call ptr @__olang_scope_hold(ptr %t211)
  %t213 = ptrtoint ptr %t212 to i64
  %t215 = inttoptr i64 %t213 to ptr
  %t216 = load ptr, ptr %l97, !tbaa !29
  %t218 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSelfHolding(ptr %t215, ptr %t216, i32 %t209)
  store i1 %t218, ptr %l100
  br label %bb38
bb38:
  %t219 = load i1, ptr %l100, !tbaa !21
  br i1 %t219, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l101, !tbaa !29
  store i32 8, ptr %l102
  %t221 = load i32, ptr %l8, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [2 x i64] }, ptr %t222, i32 0, i32 0
  store i64 1, ptr %t223
  %t225 = insertvalue { i32 } undef, i32 %t221, 0
  %t226 = getelementptr { i64, [2 x i64] }, ptr %t222, i32 0, i32 1
  store { i32 } %t225, ptr %t226
  %t227 = load { i64, [2 x i64] }, ptr %t222
  %t229 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s5, { i64, [2 x i64] } %t227)
  store %"compiler/lower:pl" %t229, ptr %l105
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t230 = load i32, ptr %l2, !tbaa !23
  %t231 = load { i64, [1 x i64] }, ptr %l4
  %t232 = mul i64 1, 16
  %t233 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 1, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l108, !tbaa !27
  %t237 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr { i64, [1 x i64] }, ptr %t238, i64 0
  store { i64, [1 x i64] } %t231, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l5
  %t241 = load ptr, ptr %l101, !tbaa !29
  %t242 = load i32, ptr %l102, !range !{i32 0, i32 10}
  %t243 = load %"compiler/lower:pl", ptr %l105
  %t245 = load { i64, ptr }, ptr %l108, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eselfHelper(ptr %v0, ptr %s5, ptr %s5, ptr %v2, ptr %v3, ptr %t241, i32 %t242, %"compiler/lower:pl" %t243, i32 %t230, { i64, ptr } %t245, %"compiler/source:Span" %t240)
  br label %bb42
bb42:
  %t247 = load i32, ptr %l8, !tbaa !23
  %t249 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t247)
  store %"compiler/mir:Lvalue" %t249, ptr %l111
  br label %bb43
bb43:
  store { i64, [4 x i64] } zeroinitializer, ptr %t250
  %t251 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 0
  store i64 1, ptr %t251
  %t252 = load %"compiler/mir:Lvalue", ptr %l111
  %t253 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t252, 0
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t253, ptr %t254
  %t255 = load { i64, [4 x i64] }, ptr %t250
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t255, ptr %rv
  br label %ret
bb44:
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l113, !tbaa !29
  %t258 = load i32, ptr %l8, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [2 x i64] }, ptr %t259, i32 0, i32 0
  store i64 1, ptr %t260
  %t262 = insertvalue { i32 } undef, i32 %t258, 0
  %t263 = getelementptr { i64, [2 x i64] }, ptr %t259, i32 0, i32 1
  store { i32 } %t262, ptr %t263
  %t264 = load { i64, [2 x i64] }, ptr %t259
  %t266 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t264)
  store %"compiler/lower:pl" %t266, ptr %l116
  br label %bb45
bb45:
  %t267 = load i32, ptr %l2, !tbaa !23
  %t268 = load { i64, [1 x i64] }, ptr %l4
  %t269 = load %"compiler/source:Span", ptr %l5
  %t270 = load ptr, ptr %l113, !tbaa !29
  %t271 = load %"compiler/lower:pl", ptr %l116
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epartsCopied(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t270, %"compiler/lower:pl" %t271, i32 %t267, { i64, [1 x i64] } %t268, %"compiler/source:Span" %t269)
  br label %bb46
bb46:
  %t275 = load i32, ptr %l8, !tbaa !23
  %t277 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t275)
  store %"compiler/mir:Lvalue" %t277, ptr %l121
  br label %bb47
bb47:
  store { i64, [4 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [4 x i64] }, ptr %t278, i32 0, i32 0
  store i64 1, ptr %t279
  %t280 = load %"compiler/mir:Lvalue", ptr %l121
  %t281 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t280, 0
  %t282 = getelementptr { i64, [4 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t281, ptr %t282
  %t283 = load { i64, [4 x i64] }, ptr %t278
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2efreshCtor(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l5 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l16 = alloca ptr
  %l22 = alloca ptr
  %l33 = alloca i1
  %l39 = alloca i1
  %l51 = alloca ptr
  %l60 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l69 = alloca i64
  %l81 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t164 = alloca { ptr, ptr }, align 8
  %t184 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 29
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp slt i64 %t12, 0
  store i1 %t14, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/lower:Lowerer", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = call ptr @__olang_scope_or(ptr %v2, ptr %t26)
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lower:lowering", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = call ptr @__olang_scope_or(ptr %v2, ptr %t33)
  %t36 = call ptr @__olang_scope_hold(ptr %t35)
  %t37 = ptrtoint ptr %t36 to i64
  %t39 = inttoptr i64 %t29 to ptr
  %t41 = inttoptr i64 %t37 to ptr
  %t42 = load ptr, ptr %l16, !tbaa !29
  %t44 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %t39, ptr %t41, ptr %t42, i64 %t25)
  store ptr %t44, ptr %l22
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Body", ptr %t45, i32 0, i32 1
  %t48 = load { i64, [2 x i64] }, ptr %t47
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  %t53 = xor i1 %t51, true
  store i1 %t53, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t55 = load i1, ptr %l12, !tbaa !21
  br i1 %t55, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lower:lowering", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l3, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load i64, ptr %l2, !tbaa !24
  %t68 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emovedViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t62, ptr %t63, i64 %t64)
  store i1 %t68, ptr %l33
  br label %bb12
bb12:
  %t69 = load i1, ptr %l33, !tbaa !21
  br i1 %t69, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = getelementptr %"compiler/lower:Lowerer", ptr %t71, i32 0, i32 12
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = icmp eq ptr %t74, null
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb16, label %bb17
bb16:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/lower:Lowerer", ptr %t80, i32 0, i32 12
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb21
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6a3744415739a386_9143a8e3ed3639a2)
  unreachable
bb19:
  br label %bb20
bb20:
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t89 = getelementptr %"compiler/lower:Lowerer", ptr %t87, i32 0, i32 12
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t93 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 179
  %t94 = load i1, ptr %t93, !tbaa !21
  store i1 %t94, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t96 = load i1, ptr %l39, !tbaa !21
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t99 = getelementptr %"compiler/lower:Lowerer", ptr %t97, i32 0, i32 12
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb24, label %bb25
bb23:
  br label %bb28
bb24:
  call void @__olang_check_failed(ptr @olang_loc_6a3744415739a386_9143a8e3ed3639a2)
  unreachable
bb25:
  br label %bb26
bb26:
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = getelementptr %"compiler/lower:Lowerer", ptr %t104, i32 0, i32 12
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l51, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/lower:lowering", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = sext i32 %t114 to i64
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Call", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t123 = load ptr, ptr %l51, !tbaa !29
  %t124 = call ptr @__olang_scope_or(ptr %v2, ptr %t123)
  %t125 = call ptr @__olang_scope_hold(ptr %t124)
  %t126 = ptrtoint ptr %t125 to i64
  %t128 = inttoptr i64 %t126 to ptr
  %t129 = load ptr, ptr %l51, !tbaa !29
  %t132 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFreshCtorAt(ptr %t128, ptr %t129, i64 %t116, i64 %t122)
  store i1 %t132, ptr %l60
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t133 = load i1, ptr %l60, !tbaa !21
  store i1 %t133, ptr %rv
  br label %ret
bb28:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/lower:lowering", ptr %t134, i32 0, i32 38
  %t137 = load ptr, ptr %t136, !tbaa !29
  store ptr %t137, ptr %l62, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l63, !tbaa !29
  %t139 = load ptr, ptr %l3, !tbaa !29
  store ptr %t139, ptr %l64, !tbaa !29
  %t140 = load i64, ptr %l2, !tbaa !24
  %t142 = trunc i64 %t140 to i32
  %t144 = load ptr, ptr %l64, !tbaa !29
  %t145 = call ptr @__olang_scope_or(ptr %v2, ptr %t144)
  %t146 = call ptr @__olang_scope_hold(ptr %t145)
  %t147 = ptrtoint ptr %t146 to i64
  %t149 = inttoptr i64 %t147 to ptr
  %t150 = load ptr, ptr %l64, !tbaa !29
  %t152 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %t149, ptr %t150, i32 %t142)
  store i64 %t152, ptr %l69
  br label %bb29
bb29:
  %t153 = load ptr, ptr %l3, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/lower:lowering", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = call ptr @__olang_scope_or(ptr %v2, ptr %t157)
  %t160 = call ptr @__olang_scope_hold(ptr %t159)
  %t161 = ptrtoint ptr %t160 to i64
  %t162 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t163 = ptrtoint ptr %t162 to i64
  %t165 = getelementptr { ptr, ptr }, ptr %t164, i32 0, i32 0
  store ptr %t153, ptr %t165, !tbaa !28
  %t168 = inttoptr i64 %t161 to ptr
  call void @__olang_scope_escape(ptr %t168)
  %t169 = call ptr @__olang_scope_hold(ptr %t168)
  %t170 = getelementptr { ptr, ptr }, ptr %t164, i32 0, i32 1
  store ptr %t169, ptr %t170, !tbaa !28
  %t171 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_21, 0
  %t172 = insertvalue { ptr, ptr } %t171, ptr %t164, 1
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/lower:lowering", ptr %t174, i32 0, i32 0
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = call ptr @__olang_scope_or(ptr %v2, ptr %t177)
  %t180 = call ptr @__olang_scope_hold(ptr %t179)
  %t181 = ptrtoint ptr %t180 to i64
  %t182 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t183 = ptrtoint ptr %t182 to i64
  %t185 = getelementptr { ptr, ptr }, ptr %t184, i32 0, i32 0
  store ptr %t173, ptr %t185, !tbaa !28
  %t188 = inttoptr i64 %t181 to ptr
  call void @__olang_scope_escape(ptr %t188)
  %t189 = call ptr @__olang_scope_hold(ptr %t188)
  %t190 = getelementptr { ptr, ptr }, ptr %t184, i32 0, i32 1
  store ptr %t189, ptr %t190, !tbaa !28
  %t191 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_22, 0
  %t192 = insertvalue { ptr, ptr } %t191, ptr %t184, 1
  %t193 = load ptr, ptr %l62, !tbaa !29
  %t194 = call ptr @__olang_scope_or(ptr %v4, ptr %t193)
  %t195 = call ptr @__olang_scope_hold(ptr %t194)
  %t196 = ptrtoint ptr %t195 to i64
  %t198 = inttoptr i64 %t196 to ptr
  %t199 = load ptr, ptr %l62, !tbaa !29
  %t200 = load ptr, ptr %l63, !tbaa !29
  %t201 = load i64, ptr %l69, !tbaa !24
  %t203 = extractvalue { ptr, ptr } %t172, 0
  %t204 = extractvalue { ptr, ptr } %t172, 1
  %t206 = extractvalue { ptr, ptr } %t192, 0
  %t207 = extractvalue { ptr, ptr } %t192, 1
  %t208 = call i1 @compiler_2ftyped_2eFreshViews(ptr %t198, ptr %v1, ptr %s0, ptr %s0, ptr %t199, ptr %t200, i64 %t201, ptr %t203, ptr %t204, ptr %t206, ptr %t207)
  store i1 %t208, ptr %l81
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t209 = load i1, ptr %l81, !tbaa !21
  store i1 %t209, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, [4 x i64] } } @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistChecks(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, i64 }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/lower:hoistWalk"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca %"compiler/typed:LocalUses"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l21 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca ptr
  %l38 = alloca i1
  %l40 = alloca i1
  %l49 = alloca { i64, i64 }
  %l56 = alloca %"compiler/lower:hoistWalk"
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l70 = alloca i1
  %l74 = alloca ptr
  %l79 = alloca %"compiler/typed:BlockInfo"
  %l85 = alloca { i64, [4 x i64] }
  %l90 = alloca { i64, [4 x i64] }
  %l91 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i32
  %l94 = alloca { i64, [4 x i64] }
  %l96 = alloca { i64, [4 x i64] }
  %l97 = alloca { i64, ptr }
  %l99 = alloca { i64, [4 x i64] }
  %l100 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca { i64, [4 x i64] }
  %l106 = alloca { i64, [4 x i64] }
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, [4 x i64] }
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i32
  %l115 = alloca { i64, [4 x i64] }
  %l117 = alloca { i64, [4 x i64] }
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, [4 x i64] }
  %l124 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca %"compiler/typed:LocalUses"
  %l131 = alloca i64
  %l135 = alloca i64
  %l138 = alloca i64
  %l158 = alloca i1
  %l159 = alloca i1
  %l162 = alloca i1
  %l169 = alloca i64
  %l171 = alloca i64
  %l176 = alloca i64
  %l189 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l190 = alloca i64
  %l192 = alloca i64
  %l193 = alloca i32
  %l195 = alloca i1
  %l196 = alloca i1
  %l199 = alloca i1
  %l200 = alloca i32
  %l206 = alloca i1
  %l217 = alloca { i64, ptr }
  %l219 = alloca { i64, [4 x i64] }
  %l225 = alloca { i64, ptr }
  %l227 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, [4 x i64] } }
  %t73 = alloca %"compiler/lower:hoistWalk", align 8
  %t254 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 61
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l25, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l25, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb6
bb5:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  store i1 %t14, ptr %l28, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l28, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lower:lowering", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 19
  store ptr %t22, ptr %l34, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Block", ptr %t23, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = load ptr, ptr %l34, !tbaa !29
  %t28 = call ptr @__olang_scope_or(ptr %v3, ptr %t27)
  %t29 = call ptr @__olang_scope_hold(ptr %t28)
  %t30 = ptrtoint ptr %t29 to i64
  %t32 = inttoptr i64 %t30 to ptr
  %t33 = load ptr, ptr %l34, !tbaa !29
  %t35 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eHas_3ccompiler_2ftyped_3aBlockId_3e(ptr %t32, ptr %t33, i32 %t26)
  store i1 %t35, ptr %l38
  br label %bb9
bb9:
  %t36 = load i1, ptr %l38, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l31, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Block", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp eq i64 %t45, 0
  store i1 %t47, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l40, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t51 = insertvalue { i32, { i64, [4 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [4 x i64] } } %t51, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t58 = call { i64, i64 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecountedBy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t52, ptr %t53, ptr %t54)
  store { i64, i64 } %t58, ptr %l49
  br label %bb17
bb17:
  %t59 = load { i64, i64 }, ptr %l49
  store { i64, i64 } %t59, ptr %l3
  %t60 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 0
  %t61 = load i64, ptr %t60, !tbaa !24
  store i64 %t61, ptr %l4, !tbaa !24
  %t63 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 1
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = icmp slt i64 %t66, 0
  br i1 %t68, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t71 = insertvalue { i32, { i64, [4 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [4 x i64] } } %t71, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t72 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2flower_3ahoistWalk_2ector(ptr %t73, ptr %s0, i64 %t72)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t73, i64 424, i1 false)
  br label %bb21
bb21:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l56, i64 424, i1 false)
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Block", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %s0, ptr %v1, ptr %v4, ptr %v3, ptr %v5, ptr %v6, ptr %t75, ptr %l6, { i64, ptr } %t79)
  br label %bb22
bb22:
  %t83 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 2
  %t84 = load i1, ptr %t83, !tbaa !21
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb26
bb24:
  %t88 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 3
  %t89 = load i64, ptr %l4, !tbaa !24
  %t92 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %t88, i64 %t89)
  store i1 %t92, ptr %l66
  br label %bb25
bb25:
  %t93 = load i1, ptr %l66, !tbaa !21
  store i1 %t93, ptr %l63, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l63, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb30
bb28:
  %t95 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 3
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %t95, i64 %t96)
  store i1 %t99, ptr %l70
  br label %bb29
bb29:
  %t100 = load i1, ptr %l70, !tbaa !21
  store i1 %t100, ptr %l67, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l67, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t103 = insertvalue { i32, { i64, [4 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [4 x i64] } } %t103, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/lower:lowering", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Body", ptr %t107, i32 0, i32 8
  store ptr %t109, ptr %l74, !tbaa !29
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Block", ptr %t110, i32 0, i32 0
  %t113 = load i32, ptr %t112, !tbaa !23
  %t115 = sext i32 %t113 to i64
  %t116 = load ptr, ptr %l74, !tbaa !29
  %t117 = call ptr @__olang_scope_or(ptr %v3, ptr %t116)
  %t118 = call ptr @__olang_scope_hold(ptr %t117)
  %t119 = ptrtoint ptr %t118 to i64
  %t121 = inttoptr i64 %t119 to ptr
  %t122 = load ptr, ptr %l74, !tbaa !29
  %t124 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t121, ptr %t122, i64 %t115)
  store %"compiler/typed:BlockInfo" %t124, ptr %l79
  br label %bb34
bb34:
  %t125 = getelementptr %"compiler/typed:BlockInfo", ptr %l79, i32 0, i32 2
  %t126 = load %"compiler/source:Span", ptr %t125
  store %"compiler/source:Span" %t126, ptr %l7
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l5, !tbaa !24
  %t131 = trunc i64 %t129 to i32
  %t135 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %t128, i32 %t131)
  store { i64, [4 x i64] } %t135, ptr %l85
  br label %bb35
bb35:
  %t136 = load { i64, [4 x i64] }, ptr %l85
  store { i64, [4 x i64] } %t136, ptr %l8
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l4, !tbaa !24
  %t140 = trunc i64 %t138 to i32
  %t144 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %t137, i32 %t140)
  store { i64, [4 x i64] } %t144, ptr %l90
  br label %bb36
bb36:
  %t145 = load { i64, [4 x i64] }, ptr %l90
  %t146 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 8
  store { i64, [4 x i64] } %t145, ptr %t146
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l91, !tbaa !29
  store i32 4, ptr %l92
  %t148 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t148, ptr %l93, !tbaa !23
  %t149 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t149, ptr %l94
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t150, i64 1)
  store { i64, [4 x i64] } %t152, ptr %l96
  br label %bb37
bb37:
  %t153 = mul i64 2, 40
  %t154 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 2, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l97, !tbaa !27
  %t157 = load { i64, [4 x i64] }, ptr %l94
  %t158 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t159, i64 0
  store { i64, [4 x i64] } %t157, ptr %t160
  %t161 = load { i64, [4 x i64] }, ptr %l96
  %t162 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t163, i64 1
  store { i64, [4 x i64] } %t161, ptr %t164
  %t165 = load %"compiler/source:Span", ptr %l7
  %t166 = load ptr, ptr %l91, !tbaa !29
  %t167 = load i32, ptr %l92, !range !{i32 0, i32 54}
  %t168 = load i32, ptr %l93, !tbaa !23
  %t169 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t171 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v4, ptr %v5, ptr %t166, i32 %t167, i32 %t168, { i64, ptr } %t169, %"compiler/source:Span" %t165)
  store { i64, [4 x i64] } %t171, ptr %l99
  br label %bb38
bb38:
  %t172 = load { i64, [4 x i64] }, ptr %l99
  %t173 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 9
  store { i64, [4 x i64] } %t172, ptr %t173
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l100, !tbaa !29
  store i32 15, ptr %l101
  %t175 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t175, ptr %l102, !tbaa !23
  %t176 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t176, ptr %l103
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = shl i64 1, 31
  %t181 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t177, i64 %t178)
  store { i64, [4 x i64] } %t181, ptr %l106
  br label %bb39
bb39:
  %t182 = mul i64 2, 40
  %t183 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 2, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l107, !tbaa !27
  %t186 = load { i64, [4 x i64] }, ptr %l103
  %t187 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t188, i64 0
  store { i64, [4 x i64] } %t186, ptr %t189
  %t190 = load { i64, [4 x i64] }, ptr %l106
  %t191 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t192, i64 1
  store { i64, [4 x i64] } %t190, ptr %t193
  %t194 = load %"compiler/source:Span", ptr %l7
  %t195 = load ptr, ptr %l100, !tbaa !29
  %t196 = load i32, ptr %l101, !range !{i32 0, i32 54}
  %t197 = load i32, ptr %l102, !tbaa !23
  %t198 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t200 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v4, ptr %v5, ptr %t195, i32 %t196, i32 %t197, { i64, ptr } %t198, %"compiler/source:Span" %t194)
  store { i64, [4 x i64] } %t200, ptr %l109
  br label %bb40
bb40:
  %t201 = load { i64, [4 x i64] }, ptr %l109
  %t202 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 7
  store { i64, [4 x i64] } %t201, ptr %t202
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l110, !tbaa !29
  store ptr %l6, ptr %l111, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l112, !tbaa !29
  store i32 18, ptr %l113
  %t205 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t205, ptr %l114, !tbaa !23
  %t206 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 8
  %t207 = load { i64, [4 x i64] }, ptr %t206
  store { i64, [4 x i64] } %t207, ptr %l115
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t208, i64 0)
  store { i64, [4 x i64] } %t210, ptr %l117
  br label %bb41
bb41:
  %t211 = mul i64 2, 40
  %t212 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t211)
  %t213 = insertvalue { i64, ptr } undef, i64 2, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  store { i64, ptr } %t214, ptr %l118, !tbaa !27
  %t215 = load { i64, [4 x i64] }, ptr %l115
  %t216 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, [4 x i64] }, ptr %t217, i64 0
  store { i64, [4 x i64] } %t215, ptr %t218
  %t219 = load { i64, [4 x i64] }, ptr %l117
  %t220 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t221, i64 1
  store { i64, [4 x i64] } %t219, ptr %t222
  %t223 = load %"compiler/source:Span", ptr %l7
  %t224 = load ptr, ptr %l112, !tbaa !29
  %t225 = load i32, ptr %l113, !range !{i32 0, i32 54}
  %t226 = load i32, ptr %l114, !tbaa !23
  %t227 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t229 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v4, ptr %v5, ptr %t224, i32 %t225, i32 %t226, { i64, ptr } %t227, %"compiler/source:Span" %t223)
  store { i64, [4 x i64] } %t229, ptr %l120
  br label %bb42
bb42:
  %t230 = load %"compiler/source:Span", ptr %l7
  %t231 = load ptr, ptr %l110, !tbaa !29
  %t232 = load ptr, ptr %l111, !tbaa !29
  %t233 = load { i64, [4 x i64] }, ptr %l120
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistAll(ptr %v0, ptr %s0, ptr %v4, ptr %v5, ptr %t231, ptr %t232, { i64, [4 x i64] } %t233, %"compiler/source:Span" %t230)
  br label %bb43
bb43:
  %t235 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 1
  store i1 true, ptr %t235, !tbaa !21
  %t236 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %s0, ptr %t236)
  br label %bb44
bb44:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/lower:lowering", ptr %t238, i32 0, i32 2
  %t241 = load ptr, ptr %t240, !tbaa !29
  store ptr %t241, ptr %l124, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/lower:lowering", ptr %t242, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !29
  store ptr %t245, ptr %l126, !tbaa !29
  %t246 = load ptr, ptr %l124, !tbaa !29
  %t247 = call ptr @__olang_scope_or(ptr %v4, ptr %t246)
  %t248 = call ptr @__olang_scope_hold(ptr %t247)
  %t249 = ptrtoint ptr %t248 to i64
  %t250 = load ptr, ptr %l126, !tbaa !29
  %t251 = call ptr @__olang_scope_or(ptr %v3, ptr %t250)
  %t252 = call ptr @__olang_scope_hold(ptr %t251)
  %t253 = ptrtoint ptr %t252 to i64
  %t256 = inttoptr i64 %t249 to ptr
  %t258 = inttoptr i64 %t253 to ptr
  %t259 = load ptr, ptr %l124, !tbaa !29
  %t260 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t254, ptr %t256, ptr %t258, ptr %s0, ptr %t259, ptr %t260)
  call void @llvm.memmove.p0.p0.i64(ptr %l129, ptr %t254, i64 1640, i1 false)
  br label %bb45
bb45:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l129, i64 1640, i1 false)
  store i64 0, ptr %l10, !tbaa !24
  %t261 = getelementptr %"compiler/typed:LocalUses", ptr %l9, i32 0, i32 7
  %t263 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %s0, ptr %t261)
  store i64 %t263, ptr %l131
  br label %bb46
bb46:
  %t264 = load i64, ptr %l131, !tbaa !24
  store i64 %t264, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t265 = load i64, ptr %l11, !tbaa !24
  %t266 = load i64, ptr %l10, !tbaa !24
  %t269 = icmp sgt i64 %t265, %t266
  br i1 %t269, label %bb47, label %bb48
bb47:
  %t271 = load i64, ptr %l12, !tbaa !24
  %t273 = icmp sgt i64 %t271, 0
  br i1 %t273, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l135, !tbaa !24
  br label %bb52
bb49:
  %t275 = load i64, ptr %l11, !tbaa !24
  %t276 = load i64, ptr %l10, !tbaa !24
  %t279 = sub i64 %t275, %t276
  %t280 = load i64, ptr %l12, !tbaa !24
  %t283 = add i64 %t279, %t280
  %t285 = sub i64 %t283, 1
  %t286 = load i64, ptr %l12, !tbaa !24
  %t289 = sdiv i64 %t285, %t286
  store i64 %t289, ptr %l138, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb51
bb51:
  %t291 = load i64, ptr %l138, !tbaa !24
  store i64 %t291, ptr %l135, !tbaa !24
  br label %bb52
bb52:
  %t292 = load i64, ptr %l135, !tbaa !24
  store i64 %t292, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb53
bb53:
  %t293 = load i64, ptr %l14, !tbaa !24
  %t294 = load i64, ptr %l13, !tbaa !24
  %t297 = icmp slt i64 %t293, %t294
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb54, label %bb55
bb54:
  br label %bb67
bb55:
  br label %bb56
bb56:
  %t301 = load i64, ptr %l10, !tbaa !24
  %t302 = load i64, ptr %l14, !tbaa !24
  %t303 = load i64, ptr %l12, !tbaa !24
  %t306 = mul i64 %t302, %t303
  %t309 = add i64 %t301, %t306
  store i64 %t309, ptr %l15, !tbaa !24
  %t311 = getelementptr %"compiler/typed:LocalUses", ptr %l9, i32 0, i32 7
  %t312 = load i64, ptr %l15, !tbaa !24
  %t315 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t311, i64 %t312)
  store i1 %t315, ptr %l158
  br label %bb57
bb57:
  %t316 = load i1, ptr %l158, !tbaa !21
  br i1 %t316, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb61
bb59:
  %t317 = getelementptr %"compiler/typed:LocalUses", ptr %l9, i32 0, i32 2
  %t318 = load i64, ptr %l15, !tbaa !24
  %t321 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t317, i64 %t318)
  store i1 %t321, ptr %l162
  br label %bb60
bb60:
  %t322 = load i1, ptr %l162, !tbaa !21
  store i1 %t322, ptr %l159, !tbaa !21
  br label %bb61
bb61:
  %t323 = load i1, ptr %l159, !tbaa !21
  br i1 %t323, label %bb62, label %bb63
bb62:
  %t324 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 6
  %t325 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %t324, i64 %t325, i1 true)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t328 = load i64, ptr %l14, !tbaa !24
  %t331 = add i64 %t328, 1
  store i64 %t331, ptr %l14, !tbaa !24
  br label %bb53
bb67:
  %t333 = getelementptr %"compiler/typed:LocalUses", ptr %l9, i32 0, i32 19
  store ptr %t333, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb68
bb68:
  %t335 = load i64, ptr %l17, !tbaa !24
  store i64 %t335, ptr %l169, !tbaa !24
  %t336 = load ptr, ptr %l16, !tbaa !29
  %t338 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t336)
  store i64 %t338, ptr %l171
  br label %bb69
bb69:
  %t339 = load i64, ptr %l169, !tbaa !24
  %t340 = load i64, ptr %l171, !tbaa !24
  %t341 = icmp slt i64 %t339, %t340
  %t343 = xor i1 %t341, true
  br i1 %t343, label %bb70, label %bb71
bb70:
  br label %bb79
bb71:
  br label %bb72
bb72:
  %t345 = load ptr, ptr %l16, !tbaa !29
  %t346 = load i64, ptr %l17, !tbaa !24
  %t349 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t345, i64 %t346)
  store i64 %t349, ptr %l176
  br label %bb73
bb73:
  %t350 = load i64, ptr %l176, !tbaa !24
  store i64 %t350, ptr %l18, !tbaa !24
  %t351 = load i64, ptr %l18, !tbaa !24
  %t353 = icmp sge i64 %t351, 0
  br i1 %t353, label %bb74, label %bb75
bb74:
  %t355 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 6
  %t356 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %t355, i64 %t356, i1 true)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t359 = load i64, ptr %l17, !tbaa !24
  %t362 = add i64 %t359, 1
  store i64 %t362, ptr %l17, !tbaa !24
  br label %bb68
bb79:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr %"compiler/typed:Block", ptr %t365, i32 0, i32 1
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %s0, ptr %v1, ptr %v4, ptr %v3, ptr %v5, ptr %v6, ptr %t364, ptr %l6, { i64, ptr } %t368)
  br label %bb80
bb80:
  store i1 false, ptr %l19, !tbaa !21
  %t372 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 5
  %t374 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %s0, ptr %s0, ptr %t372)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t374, ptr %l189
  br label %bb81
bb81:
  %t375 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l189
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t375, ptr %l20
  br label %bb82
bb82:
  %t377 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20)
  %t378 = extractvalue { i32, i64 } %t377, 1
  %t379 = extractvalue { i32, i64 } %t377, 0
  store i32 %t379, ptr %l193
  %t380 = icmp ne i32 %t379, 0
  br i1 %t380, label %bb84, label %ok.381, !prof !99
ok.381:
  store i64 %t378, ptr %l192
  br label %bb83
bb83:
  %t382 = load i64, ptr %l192, !tbaa !24
  store i64 %t382, ptr %l190, !tbaa !24
  br label %bb86
bb84:
  %t383 = load i32, ptr %l193, !tbaa !23
  %t384 = ashr i32 %t383, 16
  %t386 = icmp eq i32 %t384, 1
  store i1 %t386, ptr %l195, !tbaa !21
  br label %bb85
bb85:
  br label %bb96
bb86:
  %t387 = load i64, ptr %l190, !tbaa !24
  store i64 %t387, ptr %l21, !tbaa !24
  %t388 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 5
  %t389 = load i64, ptr %l21, !tbaa !24
  %t392 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %s0, ptr %t388, i64 %t389)
  %t393 = extractvalue { i32, i1 } %t392, 1
  %t394 = extractvalue { i32, i1 } %t392, 0
  store i32 %t394, ptr %l200
  %t395 = icmp ne i32 %t394, 0
  br i1 %t395, label %bb88, label %ok.396, !prof !99
ok.396:
  store i1 %t393, ptr %l199
  br label %bb87
bb87:
  %t397 = load i1, ptr %l199, !tbaa !21
  store i1 %t397, ptr %l196, !tbaa !21
  br label %bb90
bb88:
  br label %bb89
bb89:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb90
bb90:
  %t398 = load i1, ptr %l196, !tbaa !21
  br i1 %t398, label %bb91, label %bb92
bb91:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/lower:lowering", ptr %t399, i32 0, i32 60
  %t402 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t401, i64 %t402, i1 true)
  br label %bb93
bb92:
  br label %bb94
bb93:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %bb82
bb96:
  %t405 = load i1, ptr %l19, !tbaa !21
  %t407 = xor i1 %t405, true
  br i1 %t407, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb99
bb98:
  %t409 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 2
  %t410 = load i1, ptr %t409, !tbaa !21
  %t412 = xor i1 %t410, true
  store i1 %t412, ptr %l206, !tbaa !21
  br label %bb99
bb99:
  %t414 = load i1, ptr %l206, !tbaa !21
  br i1 %t414, label %bb100, label %bb101
bb100:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/lower:lowering", ptr %t415, i32 0, i32 60
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t417)
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t420 = insertvalue { i32, { i64, [4 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [4 x i64] } } %t420, ptr %rv
  br label %ret
bb103:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t423 = load { i64, [4 x i64] }, ptr %l8
  %t424 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 8
  %t425 = load { i64, [4 x i64] }, ptr %t424
  %t426 = mul i64 2, 40
  %t427 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t426)
  %t428 = insertvalue { i64, ptr } undef, i64 2, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t427, 1
  store { i64, ptr } %t429, ptr %l217, !tbaa !27
  %t431 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr { i64, [4 x i64] }, ptr %t432, i64 0
  store { i64, [4 x i64] } %t423, ptr %t433
  %t435 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr { i64, [4 x i64] }, ptr %t436, i64 1
  store { i64, [4 x i64] } %t425, ptr %t437
  %t438 = load %"compiler/source:Span", ptr %l7
  %t442 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t444 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v4, ptr %v5, ptr %t421, i32 16, i32 %t422, { i64, ptr } %t442, %"compiler/source:Span" %t438)
  store { i64, [4 x i64] } %t444, ptr %l219
  br label %bb104
bb104:
  %t445 = load { i64, [4 x i64] }, ptr %l219
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t449 = getelementptr %"compiler/lower:hoistWalk", ptr %l6, i32 0, i32 7
  %t450 = load { i64, [4 x i64] }, ptr %t449
  %t451 = mul i64 2, 40
  %t452 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t451)
  %t453 = insertvalue { i64, ptr } undef, i64 2, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t452, 1
  store { i64, ptr } %t454, ptr %l225, !tbaa !27
  %t456 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr { i64, [4 x i64] }, ptr %t457, i64 0
  store { i64, [4 x i64] } %t445, ptr %t458
  %t460 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr { i64, [4 x i64] }, ptr %t461, i64 1
  store { i64, [4 x i64] } %t450, ptr %t462
  %t463 = load %"compiler/source:Span", ptr %l7
  %t467 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t469 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %v4, ptr %v5, ptr %t446, i32 11, i32 %t447, { i64, ptr } %t467, %"compiler/source:Span" %t463)
  store { i64, [4 x i64] } %t469, ptr %l227
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s0)
  %t470 = load { i64, [4 x i64] }, ptr %l227
  %t471 = insertvalue { i32, { i64, [4 x i64] } } zeroinitializer, { i64, [4 x i64] } %t470, 1
  store { i32, { i64, [4 x i64] } } %t471, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [4 x i64] } }, ptr %rv
  ret { i32, { i64, [4 x i64] } } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t95 = alloca { i64, [1 x i64] }, align 8
  %t107 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 29
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 6
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v1, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %t23, ptr %t24)
  store i64 %t25, ptr %l15
  br label %bb4
bb4:
  %t26 = load i64, ptr %l15, !tbaa !24
  store i64 %t26, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l22, !tbaa !24
  store i64 %t53, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l19, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l1, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l6, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/lower:lowering", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Body", ptr %t76, i32 0, i32 6
  store ptr %t78, ptr %l42, !tbaa !29
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v1, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l42, !tbaa !29
  %t88 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %t85, ptr %t86, i64 %t79)
  store { i64, [1 x i64] } %t88, ptr %l45
  br label %bb15
bb15:
  %t89 = load { i64, [1 x i64] }, ptr %l45
  %t91 = extractvalue { i64, [1 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 2
  br i1 %t92, label %bb16, label %bb17
bb16:
  %t94 = load i64, ptr %l6, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [1 x i64] }, ptr %t95, i32 0, i32 0
  store i64 1, ptr %t96
  %t98 = insertvalue { i64 } undef, i64 %t94, 0
  %t99 = getelementptr { i64, [1 x i64] }, ptr %t95, i32 0, i32 1
  store { i64 } %t98, ptr %t99
  %t100 = load { i64, [1 x i64] }, ptr %t95
  store { i64, [1 x i64] } %t100, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t105 = add i64 %t102, 1
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb11
bb20:
  store { i64, [1 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [1 x i64] }, ptr %t107, i32 0, i32 0
  store i64 2, ptr %t108
  %t109 = load { i64, [1 x i64] }, ptr %t107
  store { i64, [1 x i64] } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca i32
  %l44 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca i32
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i32 %a1, ptr %l3, !tbaa !23
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l16, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb31
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l9, !tbaa !24
  %t54 = load ptr, ptr %l2, !tbaa !29
  store ptr %t54, ptr %l37, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  store i32 %t55, ptr %l38, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  %t60 = load ptr, ptr %l40, !tbaa !29
  %t61 = call ptr @__olang_scope_or(ptr %v1, ptr %t60)
  %t62 = call ptr @__olang_scope_hold(ptr %t61)
  %t63 = ptrtoint ptr %t62 to i64
  %t65 = inttoptr i64 %t63 to ptr
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t67 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %t65, ptr %t66)
  store i32 %t67, ptr %l42
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = call ptr @__olang_scope_or(ptr %v2, ptr %t68)
  %t70 = call ptr @__olang_scope_hold(ptr %t69)
  %t71 = ptrtoint ptr %t70 to i64
  %t73 = inttoptr i64 %t71 to ptr
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load i32, ptr %l38, !tbaa !23
  %t76 = load i32, ptr %l42, !tbaa !23
  %t77 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t73, ptr %t74, i32 %t75, i32 %t76)
  store i1 %t77, ptr %l44
  br label %bb12
bb12:
  %t78 = load i1, ptr %l44, !tbaa !21
  br i1 %t78, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t80 = load ptr, ptr %l2, !tbaa !29
  store ptr %t80, ptr %l46, !tbaa !29
  %t81 = load i32, ptr %l3, !tbaa !23
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t83 = call ptr @__olang_scope_or(ptr %v2, ptr %t82)
  %t84 = call ptr @__olang_scope_hold(ptr %t83)
  %t85 = ptrtoint ptr %t84 to i64
  %t87 = inttoptr i64 %t85 to ptr
  %t88 = load ptr, ptr %l46, !tbaa !29
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t87, ptr %t88, i32 %t81)
  store i32 %t90, ptr %l49
  br label %bb16
bb16:
  %t91 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t93 = trunc i64 18 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l53, !tbaa !29
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l54, !tbaa !29
  %t98 = load i32, ptr %l3, !tbaa !23
  %t99 = load ptr, ptr %l54, !tbaa !29
  %t100 = call ptr @__olang_scope_or(ptr %v2, ptr %t99)
  %t101 = call ptr @__olang_scope_hold(ptr %t100)
  %t102 = ptrtoint ptr %t101 to i64
  %t104 = inttoptr i64 %t102 to ptr
  %t105 = load ptr, ptr %l54, !tbaa !29
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t104, ptr %t105, i32 %t98)
  store i32 %t107, ptr %l57
  br label %bb19
bb18:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb21
bb19:
  %t108 = load ptr, ptr %l53, !tbaa !29
  %t109 = call ptr @__olang_scope_or(ptr %v2, ptr %t108)
  %t110 = call ptr @__olang_scope_hold(ptr %t109)
  %t111 = ptrtoint ptr %t110 to i64
  %t113 = inttoptr i64 %t111 to ptr
  %t114 = load ptr, ptr %l53, !tbaa !29
  %t115 = load i32, ptr %l57, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %t113, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l59
  br label %bb20
bb20:
  %t117 = load i32, ptr %l59, !range !{i32 0, i32 6}
  %t119 = trunc i64 4 to i32
  %t120 = icmp eq i32 %t117, %t119
  store i1 %t120, ptr %l52, !tbaa !21
  br label %bb21
bb21:
  %t122 = load i1, ptr %l52, !tbaa !21
  br i1 %t122, label %bb22, label %bb23
bb22:
  %t123 = load ptr, ptr %l2, !tbaa !29
  store ptr %t123, ptr %l63, !tbaa !29
  %t124 = load i32, ptr %l3, !tbaa !23
  %t125 = load ptr, ptr %l63, !tbaa !29
  %t126 = call ptr @__olang_scope_or(ptr %v2, ptr %t125)
  %t127 = call ptr @__olang_scope_hold(ptr %t126)
  %t128 = ptrtoint ptr %t127 to i64
  %t130 = inttoptr i64 %t128 to ptr
  %t131 = load ptr, ptr %l63, !tbaa !29
  %t133 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t130, ptr %t131, i32 %t124)
  store i1 %t133, ptr %l66
  br label %bb24
bb23:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb25
bb24:
  %t134 = load i1, ptr %l66, !tbaa !21
  store i1 %t134, ptr %l62, !tbaa !21
  br label %bb25
bb25:
  %t135 = load i1, ptr %l62, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t139 = load ptr, ptr %l2, !tbaa !29
  store ptr %t139, ptr %l69, !tbaa !29
  %t140 = load i32, ptr %l3, !tbaa !23
  %t141 = load ptr, ptr %l69, !tbaa !29
  %t142 = call ptr @__olang_scope_or(ptr %v2, ptr %t141)
  %t143 = call ptr @__olang_scope_hold(ptr %t142)
  %t144 = ptrtoint ptr %t143 to i64
  %t146 = inttoptr i64 %t144 to ptr
  %t147 = load ptr, ptr %l69, !tbaa !29
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %t146, ptr %t147, i32 %t140)
  store i32 %t149, ptr %l72
  br label %bb29
bb29:
  %t150 = load i32, ptr %l72, !tbaa !23
  store i32 %t150, ptr %l3, !tbaa !23
  br label %bb30
bb30:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l8, !tbaa !24
  br label %bb7
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2emarkWalk(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, [7 x i64] } %a2, i32 %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [7 x i64] }
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l30 = alloca i64
  %l33 = alloca i64
  %l55 = alloca i1
  %l66 = alloca { i64, [1 x i64] }
  %l74 = alloca %"compiler/mir:ScopeInfo"
  %l78 = alloca i1
  %l81 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a2, ptr %l2
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [7 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  %t10 = extractvalue { i64, [2 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 0
  store i1 %t11, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_54c4e502471f1575_5d803130ca2c9231)
  unreachable
bb12:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l21, !tbaa !29
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = call ptr @__olang_scope_or(ptr %v1, ptr %t19)
  %t21 = call ptr @__olang_scope_hold(ptr %t20)
  %t22 = ptrtoint ptr %t21 to i64
  %t24 = inttoptr i64 %t22 to ptr
  %t25 = load ptr, ptr %l21, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %t24, ptr %s0, ptr %t25, i32 %a3)
  store { i64, ptr } %t27, ptr %l24
  br label %bb13
bb13:
  %t28 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb19
bb16:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l33, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb18
bb18:
  %t59 = load i64, ptr %l33, !tbaa !24
  store i64 %t59, ptr %l30, !tbaa !24
  br label %bb19
bb19:
  %t60 = load i64, ptr %l30, !tbaa !24
  store i64 %t60, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb21, label %bb22
bb21:
  br label %bb53
bb22:
  br label %bb23
bb23:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l11, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t79
  %t84 = load i64, ptr %t83, !tbaa !34
  %t85 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t88 = icmp ne i64 %t84, %t85
  br i1 %t88, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb26
bb25:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = sext i32 %t92 to i64
  %t97 = icmp sge i64 %t90, %t94
  store i1 %t97, ptr %l55, !tbaa !21
  br label %bb26
bb26:
  %t99 = load i1, ptr %l55, !tbaa !21
  br i1 %t99, label %bb27, label %bb28
bb27:
  br label %bb52
bb28:
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/lower:lowering", ptr %t100, i32 0, i32 3
  %t103 = getelementptr %"compiler/mir:Fn", ptr %t102, i32 0, i32 12
  %t104 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t114 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t103, i64 %t111)
  store { i64, [1 x i64] } %t114, ptr %l66
  br label %bb30
bb30:
  %t115 = load { i64, [1 x i64] }, ptr %l66
  store { i64, [1 x i64] } %t115, ptr %l12
  %t116 = load { i64, [1 x i64] }, ptr %l12
  %t118 = extractvalue { i64, [1 x i64] } %t116, 0
  %t119 = icmp eq i64 %t118, 0
  br i1 %t119, label %bb31, label %bb32
bb31:
  %t121 = getelementptr { i64, [1 x i64] }, ptr %l12, i32 0, i32 1
  %t122 = getelementptr { i32 }, ptr %t121, i32 0, i32 0
  %t123 = load i32, ptr %t122
  store i32 %t123, ptr %l13, !tbaa !23
  br label %bb33
bb32:
  br label %bb46
bb33:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lower:lowering", ptr %t125, i32 0, i32 3
  %t128 = getelementptr %"compiler/mir:Fn", ptr %t127, i32 0, i32 8
  %t129 = load i32, ptr %l13, !tbaa !23
  %t131 = sext i32 %t129 to i64
  %t134 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t128, i64 %t131)
  store %"compiler/mir:ScopeInfo" %t134, ptr %l74
  br label %bb34
bb34:
  %t135 = getelementptr %"compiler/mir:ScopeInfo", ptr %l74, i32 0, i32 0
  %t136 = load i32, ptr %t135, !range !{i32 0, i32 7}
  store i32 %t136, ptr %l14
  %t138 = load i32, ptr %l14, !range !{i32 0, i32 7}
  %t140 = trunc i64 1 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb37
bb36:
  %t143 = load i32, ptr %l14, !range !{i32 0, i32 7}
  %t145 = trunc i64 2 to i32
  %t146 = icmp eq i32 %t143, %t145
  store i1 %t146, ptr %l78, !tbaa !21
  br label %bb37
bb37:
  %t148 = load i1, ptr %l78, !tbaa !21
  br i1 %t148, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb40
bb39:
  %t149 = load i32, ptr %l14, !range !{i32 0, i32 7}
  %t151 = trunc i64 0 to i32
  %t152 = icmp eq i32 %t149, %t151
  store i1 %t152, ptr %l81, !tbaa !21
  br label %bb40
bb40:
  %t154 = load i1, ptr %l81, !tbaa !21
  br i1 %t154, label %bb41, label %bb42
bb41:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/lower:lowering", ptr %t155, i32 0, i32 3
  %t158 = getelementptr %"compiler/mir:Fn", ptr %t157, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t158, i32 %a1)
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/lower:lowering", ptr %t162, i32 0, i32 3
  %t165 = getelementptr %"compiler/mir:Fn", ptr %t164, i32 0, i32 29
  %t166 = load i32, ptr %l13, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t165, i32 %t166)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_237828d44636a984_bc321bec2b6d0e20)
  unreachable
bb51:
  br label %bb52
bb52:
  %t169 = load i64, ptr %l10, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l10, !tbaa !24
  br label %bb20
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromotedCond(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %lp16 = alloca ptr
  %l17 = alloca { i64, [4 x i64] }
  %l22 = alloca { i64, [4 x i64] }
  %l29 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i32
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i64
  %l48 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca i32
  %l74 = alloca ptr
  %l83 = alloca %"compiler/typed:Promote"
  %l88 = alloca { i64, [4 x i64] }
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/mir:Lvalue"
  %l108 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t16 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [8 x i64] }, align 8
  %t166 = alloca { i64, [15 x i64] }, align 8
  %t172 = alloca { i64, [21 x i64] }, align 8
  %t201 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Cond", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t1, ptr %t5)
  store { i64, [4 x i64] } %t9, ptr %l22
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t10, ptr %l5
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 12
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [4 x i64] }, ptr %t16
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l3, !tbaa !23
  %t22 = load %"compiler/source:Span", ptr %l4
  %t26 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t20, i32 %t21, %"compiler/source:Span" %t22)
  store i32 %t26, ptr %l29
  br label %bb5
bb5:
  %t27 = load i32, ptr %l29, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 3
  %t32 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l32
  br label %bb6
bb6:
  %t33 = load i32, ptr %l32, !tbaa !23
  store i32 %t33, ptr %l7, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 3
  %t38 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t36)
  store i32 %t38, ptr %l35
  br label %bb7
bb7:
  %t39 = load i32, ptr %l35, !tbaa !23
  store i32 %t39, ptr %l8, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, [4 x i64] }, ptr %l5
  %t42 = load i32, ptr %l7, !tbaa !23
  %t43 = load i32, ptr %l8, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [8 x i64] }, ptr %t44, i32 0, i32 0
  store i64 2, ptr %t45
  %t47 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t41, 0
  %t49 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t47, i32 %t42, 1
  %t51 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t49, i32 %t43, 2
  %t52 = getelementptr { i64, [8 x i64] }, ptr %t44, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t51, ptr %t52
  %t53 = load { i64, [8 x i64] }, ptr %t44
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v2, ptr %v3, ptr %t40, { i64, [8 x i64] } %t53)
  br label %bb8
bb8:
  %t56 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l41
  br label %bb9
bb9:
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  store i64 2, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t58 = load i64, ptr %l11, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb10, label %bb11
bb10:
  %t64 = load i64, ptr %l12, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb15
bb12:
  %t68 = load i64, ptr %l11, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = sub i64 %t68, %t69
  %t73 = load i64, ptr %l12, !tbaa !24
  %t76 = add i64 %t72, %t73
  %t78 = sub i64 %t76, 1
  %t79 = load i64, ptr %l12, !tbaa !24
  %t82 = sdiv i64 %t78, %t79
  store i64 %t82, ptr %l48, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb14
bb14:
  %t84 = load i64, ptr %l48, !tbaa !24
  store i64 %t84, ptr %l45, !tbaa !24
  br label %bb15
bb15:
  %t85 = load i64, ptr %l45, !tbaa !24
  store i64 %t85, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb16
bb16:
  %t86 = load i64, ptr %l14, !tbaa !24
  %t87 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb17, label %bb18
bb17:
  br label %bb39
bb18:
  br label %bb19
bb19:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l14, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t99 = mul i64 %t95, %t96
  %t102 = add i64 %t94, %t99
  store i64 %t102, ptr %l15, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l66, !tbaa !29
  %t105 = load i64, ptr %l15, !tbaa !24
  %t107 = icmp eq i64 %t105, 0
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load i32, ptr %l7, !tbaa !23
  store i32 %t109, ptr %l69, !tbaa !23
  br label %bb22
bb21:
  %t111 = load i32, ptr %l8, !tbaa !23
  store i32 %t111, ptr %l69, !tbaa !23
  br label %bb22
bb22:
  %t113 = load ptr, ptr %l66, !tbaa !29
  %t114 = load i32, ptr %l69, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t113, i32 %t114)
  br label %bb23
bb23:
  %t115 = load i64, ptr %l15, !tbaa !24
  %t117 = icmp eq i64 %t115, 0
  br i1 %t117, label %bb24, label %bb25
bb24:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Cond", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb26, label %bb27
bb25:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Cond", ptr %t126, i32 0, i32 2
  %t129 = load ptr, ptr %t128, !tbaa !29
  store ptr %t129, ptr %l74, !tbaa !29
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_40f2edcfdf80c59a_e6966279c0100e6)
  unreachable
bb27:
  br label %bb28
bb28:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Cond", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l74, !tbaa !29
  br label %bb29
bb29:
  %t137 = load ptr, ptr %l74, !tbaa !29
  %t139 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v1, ptr %v0, ptr %t137, i32 %a2)
  store %"compiler/typed:Promote" %t139, ptr %l83
  br label %bb30
bb30:
  %t140 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t140, ptr %lp16
  %t141 = load %"compiler/typed:Promote", ptr %l83
  %t142 = load ptr, ptr %lp16
  store %"compiler/typed:Promote" %t141, ptr %t142
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %lp16
  %t145 = load i32, ptr %l3, !tbaa !23
  %t146 = load %"compiler/source:Span", ptr %l4
  %t151 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v0, ptr %v3, ptr %v2, ptr %v4, ptr %v5, ptr %t143, ptr %t144, i32 %t145, %"compiler/source:Span" %t146)
  store { i64, [4 x i64] } %t151, ptr %l88
  br label %bb31
bb31:
  %t152 = load { i64, [4 x i64] }, ptr %l88
  store { i64, [4 x i64] } %t152, ptr %l17
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/lower:lowering", ptr %t153, i32 0, i32 12
  %t156 = load i1, ptr %t155, !tbaa !21
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l92, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t161, ptr %l93
  %t162 = load i32, ptr %l6, !tbaa !23
  %t164 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t162)
  store %"compiler/mir:Lvalue" %t164, ptr %l95
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t165 = load { i64, [4 x i64] }, ptr %l17
  store { i64, [15 x i64] } zeroinitializer, ptr %t166
  %t167 = getelementptr { i64, [15 x i64] }, ptr %t166, i32 0, i32 0
  store i64 0, ptr %t167
  %t169 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t165, 0
  %t170 = getelementptr { i64, [15 x i64] }, ptr %t166, i32 0, i32 1
  store { { i64, [4 x i64] } } %t169, ptr %t170
  %t171 = load { i64, [15 x i64] }, ptr %t166
  store { i64, [21 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [21 x i64] }, ptr %t172, i32 0, i32 0
  store i64 0, ptr %t173
  %t174 = load %"compiler/source:Span", ptr %l93
  %t175 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t174, 0
  %t176 = load %"compiler/mir:Lvalue", ptr %l95
  %t177 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t175, %"compiler/mir:Lvalue" %t176, 1
  %t179 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t177, { i64, [15 x i64] } %t171, 2
  %t180 = getelementptr { i64, [21 x i64] }, ptr %t172, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t179, ptr %t180
  %t181 = load { i64, [21 x i64] }, ptr %t172
  %t183 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 176, i64 8)
  store { i64, [21 x i64] } %t181, ptr %t183
  %t184 = load ptr, ptr %l92, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s4, ptr %v3, ptr %v2, ptr %t184, ptr %t183)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  %t186 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t186, ptr %l9)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t189 = load i64, ptr %l14, !tbaa !24
  %t192 = add i64 %t189, 1
  store i64 %t192, ptr %l14, !tbaa !24
  br label %bb16
bb39:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t194, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t195)
  br label %bb40
bb40:
  %t198 = load i32, ptr %l6, !tbaa !23
  %t200 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t198)
  store %"compiler/mir:Lvalue" %t200, ptr %l108
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t201
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 0
  store i64 1, ptr %t202
  %t203 = load %"compiler/mir:Lvalue", ptr %l108
  %t204 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t203, 0
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t204, ptr %t205
  %t206 = load { i64, [4 x i64] }, ptr %t201
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t206, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseOn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/lower:relPath"
  %l7 = alloca i32
  %l8 = alloca %"compiler/lower:pl"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"compiler/mir:Lvalue"
  %l17 = alloca { i64, [21 x i64] }
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca %"compiler/lower:relPath"
  %l27 = alloca %"compiler/lower:relPath"
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l40 = alloca i32
  %l44 = alloca i32
  %l46 = alloca %"compiler/lower:pl"
  %l48 = alloca %"compiler/lower:pl"
  %l56 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca %"compiler/lower:pl"
  %l62 = alloca %"compiler/lower:pl"
  %l65 = alloca %"compiler/lower:pl"
  %l71 = alloca ptr
  %l72 = alloca %"compiler/lower:pl"
  %l74 = alloca %"compiler/lower:pl"
  %l76 = alloca %"compiler/lower:relPath"
  %l77 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l93 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca %"compiler/lower:pl"
  %l101 = alloca %"compiler/lower:pl"
  %l102 = alloca %"compiler/mir:Lvalue"
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, [4 x i64] }
  %l107 = alloca ptr
  %l108 = alloca { i64, [4 x i64] }
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca %"compiler/lower:pl"
  %l114 = alloca %"compiler/lower:pl"
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca i32
  %l129 = alloca ptr
  %l130 = alloca %"compiler/lower:pl"
  %l132 = alloca %"compiler/lower:pl"
  %l133 = alloca %"compiler/mir:Lvalue"
  %l135 = alloca { i64, ptr }
  %l137 = alloca { i64, [4 x i64] }
  %l138 = alloca ptr
  %l139 = alloca { i64, [4 x i64] }
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca ptr
  %l142 = alloca %"compiler/lower:pl"
  %l144 = alloca %"compiler/lower:pl"
  %l146 = alloca %"compiler/lower:relPath"
  %l147 = alloca i64
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l156 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l157 = alloca i64
  %l159 = alloca i64
  %l160 = alloca { i64, ptr }
  %l161 = alloca i64
  %l164 = alloca %"compiler/lower:relPath"
  %l165 = alloca i64
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l169 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l184 = alloca %"compiler/lower:pl"
  %l186 = alloca %"compiler/lower:pl"
  %l187 = alloca %"compiler/mir:Lvalue"
  %l189 = alloca { i64, [21 x i64] }
  %l192 = alloca { i64, [21 x i64] }
  %l195 = alloca { i64, [21 x i64] }
  %l196 = alloca ptr
  %l198 = alloca ptr
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t116 = alloca { i64, [1 x i64] }, align 8
  %t218 = alloca { i64, [4 x i64] }, align 8
  %t300 = alloca { i64, [4 x i64] }, align 8
  %t531 = alloca { i64, [21 x i64] }, align 8
  %t541 = alloca { i64, [21 x i64] }, align 8
  %t555 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load i64, ptr %l5, !tbaa !24
  store i64 %t3, ptr %l19, !tbaa !24
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2eLen_3ccompiler_2flower_3arelPath_3e(ptr %v2, ptr %t4)
  store i64 %t6, ptr %l21
  br label %bb2
bb2:
  %t7 = load i64, ptr %l19, !tbaa !24
  %t8 = load i64, ptr %l21, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb110
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = call %"compiler/lower:relPath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2eAt_3ccompiler_2flower_3arelPath_3e(ptr %v2, ptr %v2, ptr %t13, i64 %t14)
  store %"compiler/lower:relPath" %t17, ptr %l26
  br label %bb6
bb6:
  %t18 = load %"compiler/lower:relPath", ptr %l26
  store %"compiler/lower:relPath" %t18, ptr %l27
  %t19 = call ptr @__olang_scope_hold(ptr %s2)
  %t20 = ptrtoint ptr %t19 to i64
  store i64 %t20, ptr %l28, !tbaa !24
  %t21 = load i1, ptr @olang_2esole_2ecompiler_2flower_3arelPath_2e1
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = call ptr @__olang_region_make_part(ptr %s2)
  %t24 = ptrtoint ptr %t23 to i64
  store i64 %t24, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t25 = getelementptr %"compiler/lower:relPath", ptr %l27, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l30, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l31, !tbaa !24
  %t29 = load i64, ptr %l31, !tbaa !24
  %t30 = mul i64 %t29, 8
  %t31 = load i64, ptr %l28
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call ptr @__olang_held_alloc(ptr %t32, i64 %t30)
  %t34 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l32, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l31, !tbaa !24
  %t41 = mul i64 %t40, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t37, ptr %t39, i64 %t41, i1 false)
  %t42 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t43 = getelementptr %"compiler/lower:relPath", ptr %l27, i32 0, i32 1
  store { i64, ptr } %t42, ptr %t43, !tbaa !27
  %t44 = load i1, ptr @olang_2esole_2ecompiler_2flower_3arelPath_2e1
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = getelementptr %"compiler/lower:relPath", ptr %l27, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t50 = icmp eq i64 %t48, 0
  br i1 %t50, label %bb11, label %bb12
bb10:
  %t52 = load %"compiler/lower:relPath", ptr %l27
  store %"compiler/lower:relPath" %t52, ptr %l6
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lower:lowering", ptr %t53, i32 0, i32 12
  %t56 = load i1, ptr %t55, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb11:
  %t58 = getelementptr %"compiler/lower:relPath", ptr %l27, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t58, !tbaa !27
  br label %bb12
bb12:
  %t59 = getelementptr %"compiler/lower:relPath", ptr %l27, i32 0, i32 1
  %t60 = load i64, ptr %l28
  %t61 = inttoptr i64 %t60 to ptr
  %t62 = load { i64, ptr }, ptr %t59
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = call ptr @__olang_region_or(ptr %t63, ptr null)
  %t65 = icmp ne ptr %t64, null
  %t66 = select i1 %t65, ptr %t64, ptr null
  call void @__olang_region_settle_in(ptr %t61, ptr %t66)
  br label %bb10
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t67 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 0
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load %"compiler/source:Span", ptr %l3
  %t79 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ewhenSole(ptr %v0, ptr %v3, ptr %v4, ptr %t72, i64 %t74, i1 true, %"compiler/source:Span" %t75)
  store i32 %t79, ptr %l44
  br label %bb18
bb17:
  %t80 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store i32 %t80, ptr %l40, !tbaa !23
  br label %bb19
bb18:
  %t82 = load i32, ptr %l44, !tbaa !23
  store i32 %t82, ptr %l40, !tbaa !23
  br label %bb19
bb19:
  %t83 = load i32, ptr %l40, !tbaa !23
  store i32 %t83, ptr %l7, !tbaa !23
  store %"compiler/lower:pl" %a1, ptr %l46
  %t86 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l46)
  store %"compiler/lower:pl" %t86, ptr %l48
  br label %bb20
bb20:
  %t87 = load %"compiler/lower:pl", ptr %l48
  store %"compiler/lower:pl" %t87, ptr %l8
  %t88 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 1
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l11, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t95 = load i64, ptr %l10, !tbaa !24
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb23:
  br label %bb24
bb24:
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t103, ptr %l56, !tbaa !27
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i64, ptr %t107, i64 %t104
  %t109 = load i64, ptr %t108, !tbaa !34
  store i64 %t109, ptr %l12, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l59, !tbaa !29
  %t112 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t112, ptr %l60
  %t114 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s5, ptr %l60)
  store %"compiler/lower:pl" %t114, ptr %l62
  br label %bb25
bb25:
  %t115 = load i64, ptr %l12, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [1 x i64] }, ptr %t116, i32 0, i32 0
  store i64 0, ptr %t117
  %t119 = insertvalue { i64 } undef, i64 %t115, 0
  %t120 = getelementptr { i64, [1 x i64] }, ptr %t116, i32 0, i32 1
  store { i64 } %t119, ptr %t120
  %t121 = load { i64, [1 x i64] }, ptr %t116
  %t122 = load ptr, ptr %l59, !tbaa !29
  %t123 = load %"compiler/lower:pl", ptr %l62
  %t125 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s5, ptr %s2, ptr %t122, %"compiler/lower:pl" %t123, { i64, [1 x i64] } %t121)
  store %"compiler/lower:pl" %t125, ptr %l65
  br label %bb26
bb26:
  %t126 = load %"compiler/lower:pl", ptr %l65
  store %"compiler/lower:pl" %t126, ptr %l8
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t127 = load i64, ptr %l10, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l10, !tbaa !24
  br label %bb21
bb28:
  %t132 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 4
  %t133 = load i64, ptr %t132, !tbaa !24
  %t135 = icmp sge i64 %t133, 0
  br i1 %t135, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l71, !tbaa !29
  %t138 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t138, ptr %l72
  %t140 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s7, ptr %l72)
  store %"compiler/lower:pl" %t140, ptr %l74
  br label %bb31
bb30:
  br label %bb43
bb31:
  %t141 = load %"compiler/lower:relPath", ptr %l6
  store %"compiler/lower:relPath" %t141, ptr %l76
  %t143 = call ptr @__olang_scope_hold(ptr %s7)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l77, !tbaa !24
  %t145 = load i1, ptr @olang_2esole_2ecompiler_2flower_3arelPath_2e1
  br i1 %t145, label %bb32, label %bb33
bb32:
  %t147 = call ptr @__olang_region_make_part(ptr %s7)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l77, !tbaa !24
  br label %bb33
bb33:
  %t149 = getelementptr %"compiler/lower:relPath", ptr %l76, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l79, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  store i64 %t152, ptr %l80, !tbaa !24
  %t153 = load i64, ptr %l80, !tbaa !24
  %t154 = mul i64 %t153, 8
  %t155 = load i64, ptr %l77
  %t156 = inttoptr i64 %t155 to ptr
  %t157 = call ptr @__olang_held_alloc(ptr %t156, i64 %t154)
  %t158 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l81, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l80, !tbaa !24
  %t165 = mul i64 %t164, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t161, ptr %t163, i64 %t165, i1 false)
  %t166 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t167 = getelementptr %"compiler/lower:relPath", ptr %l76, i32 0, i32 1
  store { i64, ptr } %t166, ptr %t167, !tbaa !27
  %t168 = load i1, ptr @olang_2esole_2ecompiler_2flower_3arelPath_2e1
  br i1 %t168, label %bb34, label %bb35
bb34:
  %t170 = getelementptr %"compiler/lower:relPath", ptr %l76, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t174 = icmp eq i64 %t172, 0
  br i1 %t174, label %bb36, label %bb37
bb35:
  %t176 = load %"compiler/source:Span", ptr %l3
  %t177 = load ptr, ptr %l71, !tbaa !29
  %t178 = load %"compiler/lower:pl", ptr %l74
  %t179 = load %"compiler/lower:relPath", ptr %l76
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etextWalk(ptr %v0, ptr %s7, ptr %s7, ptr %v4, ptr %v3, ptr %t177, %"compiler/lower:pl" %t178, %"compiler/lower:relPath" %t179, %"compiler/source:Span" %t176)
  br label %bb38
bb36:
  %t181 = getelementptr %"compiler/lower:relPath", ptr %l76, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t181, !tbaa !27
  br label %bb37
bb37:
  %t182 = getelementptr %"compiler/lower:relPath", ptr %l76, i32 0, i32 1
  %t183 = load i64, ptr %l77
  %t184 = inttoptr i64 %t183 to ptr
  %t185 = load { i64, ptr }, ptr %t182
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = call ptr @__olang_region_or(ptr %t186, ptr null)
  %t188 = icmp ne ptr %t187, null
  %t189 = select i1 %t188, ptr %t187, ptr null
  call void @__olang_region_settle_in(ptr %t184, ptr %t189)
  br label %bb35
bb38:
  %t190 = load i32, ptr %l7, !tbaa !23
  %t191 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t194 = icmp ne i32 %t190, %t191
  br i1 %t194, label %bb39, label %bb40
bb39:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v4, ptr %v3, ptr %t196, i32 %t197)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s2)
  br label %bb109
bb43:
  %t200 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 4
  %t201 = load i64, ptr %t200, !tbaa !24
  %t203 = icmp eq i64 %t201, -2
  br i1 %t203, label %bb44, label %bb45
bb44:
  %t205 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 2
  %t206 = load i1, ptr %t205, !tbaa !21
  store i1 %t206, ptr %l93, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb46
bb46:
  %t208 = load i1, ptr %l93, !tbaa !21
  br i1 %t208, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l95, !tbaa !29
  store i32 22, ptr %l96
  %t210 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t210, ptr %l97, !tbaa !23
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l98, !tbaa !29
  %t212 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t212, ptr %l99
  %t214 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s9, ptr %l99)
  store %"compiler/lower:pl" %t214, ptr %l101
  br label %bb49
bb48:
  br label %bb58
bb49:
  %t215 = load ptr, ptr %l98, !tbaa !29
  %t216 = load %"compiler/lower:pl", ptr %l101
  %t217 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s9, ptr %v4, ptr %t215, %"compiler/lower:pl" %t216)
  store %"compiler/mir:Lvalue" %t217, ptr %l102
  br label %bb50
bb50:
  store { i64, [4 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 0
  store i64 1, ptr %t219
  %t220 = load %"compiler/mir:Lvalue", ptr %l102
  %t221 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t220, 0
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t221, ptr %t222
  %t223 = load { i64, [4 x i64] }, ptr %t218
  %t224 = mul i64 1, 40
  %t225 = call ptr @__olang_scope_alloc_zeroed(ptr %s9, i64 %t224)
  %t226 = insertvalue { i64, ptr } undef, i64 1, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  store { i64, ptr } %t227, ptr %l104, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr { i64, [4 x i64] }, ptr %t230, i64 0
  store { i64, [4 x i64] } %t223, ptr %t231
  %t232 = load %"compiler/source:Span", ptr %l3
  %t233 = load ptr, ptr %l95, !tbaa !29
  %t234 = load i32, ptr %l96, !range !{i32 0, i32 54}
  %t235 = load i32, ptr %l97, !tbaa !23
  %t236 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t238 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s9, ptr %v3, ptr %v4, ptr %t233, i32 %t234, i32 %t235, { i64, ptr } %t236, %"compiler/source:Span" %t232)
  store { i64, [4 x i64] } %t238, ptr %l106
  br label %bb51
bb51:
  %t239 = load { i64, [4 x i64] }, ptr %l106
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l107, !tbaa !29
  store { i64, [4 x i64] } %t239, ptr %l108
  %t242 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t242, ptr %l109
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l110, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t244, ptr %l111
  %t245 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t245, ptr %l112
  %t247 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l112)
  store %"compiler/lower:pl" %t247, ptr %l114
  br label %bb52
bb52:
  %t248 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr null, i32 1
  %t249 = ptrtoint ptr %t248 to i64
  %t250 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 %t249, i64 8)
  %t251 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %t250, i32 0, i32 0
  %t252 = load ptr, ptr %l110, !tbaa !29
  store ptr %t252, ptr %t251, !tbaa !28
  %t253 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %t250, i32 0, i32 1
  %t254 = load %"compiler/source:Span", ptr %l111
  store %"compiler/source:Span" %t254, ptr %t253, !tbaa !28
  %t255 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %t250, i32 0, i32 2
  %t256 = load %"compiler/lower:pl", ptr %l114
  store %"compiler/lower:pl" %t256, ptr %t255, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t257 = call ptr @__olang_scope_hold(ptr %v0)
  %t258 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %t250, i32 0, i32 3
  store ptr %t257, ptr %t258, !tbaa !28
  call void @__olang_scope_escape(ptr %s2)
  %t259 = call ptr @__olang_scope_hold(ptr %s2)
  %t260 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %t250, i32 0, i32 4
  store ptr %t259, ptr %t260, !tbaa !28
  %t261 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_23, 0
  %t262 = insertvalue { ptr, ptr } %t261, ptr %t250, 1
  %t263 = load ptr, ptr %l107, !tbaa !29
  %t264 = load { i64, [4 x i64] }, ptr %l108
  %t265 = load %"compiler/source:Span", ptr %l109
  %t267 = extractvalue { ptr, ptr } %t262, 0
  %t268 = extractvalue { ptr, ptr } %t262, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %s2, ptr %v3, ptr %v4, ptr %t263, { i64, [4 x i64] } %t264, %"compiler/source:Span" %t265, ptr %t267, ptr %t268)
  br label %bb53
bb53:
  %t269 = load i32, ptr %l7, !tbaa !23
  %t270 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t273 = icmp ne i32 %t269, %t270
  br i1 %t273, label %bb54, label %bb55
bb54:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v4, ptr %v3, ptr %t275, i32 %t276)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  br label %bb109
bb58:
  %t279 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 4
  %t280 = load i64, ptr %t279, !tbaa !24
  %t282 = icmp eq i64 %t280, -2
  br i1 %t282, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 6
  %t286 = load i32, ptr %t285, !tbaa !23
  %t289 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2eelemReleases(ptr %v0, ptr %s11, ptr %v4, ptr %v3, ptr %t284, i32 %t286, i1 false)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t289, ptr %l125
  br label %bb61
bb60:
  br label %bb95
bb61:
  %t290 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t290, ptr %l14
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l126, !tbaa !29
  store i32 22, ptr %l127
  %t292 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t292, ptr %l128, !tbaa !23
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l129, !tbaa !29
  %t294 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t294, ptr %l130
  %t296 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s11, ptr %l130)
  store %"compiler/lower:pl" %t296, ptr %l132
  br label %bb62
bb62:
  %t297 = load ptr, ptr %l129, !tbaa !29
  %t298 = load %"compiler/lower:pl", ptr %l132
  %t299 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s11, ptr %v4, ptr %t297, %"compiler/lower:pl" %t298)
  store %"compiler/mir:Lvalue" %t299, ptr %l133
  br label %bb63
bb63:
  store { i64, [4 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [4 x i64] }, ptr %t300, i32 0, i32 0
  store i64 1, ptr %t301
  %t302 = load %"compiler/mir:Lvalue", ptr %l133
  %t303 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t302, 0
  %t304 = getelementptr { i64, [4 x i64] }, ptr %t300, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t303, ptr %t304
  %t305 = load { i64, [4 x i64] }, ptr %t300
  %t306 = mul i64 1, 40
  %t307 = call ptr @__olang_scope_alloc_zeroed(ptr %s11, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 1, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l135, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, [4 x i64] }, ptr %t312, i64 0
  store { i64, [4 x i64] } %t305, ptr %t313
  %t314 = load %"compiler/source:Span", ptr %l3
  %t315 = load ptr, ptr %l126, !tbaa !29
  %t316 = load i32, ptr %l127, !range !{i32 0, i32 54}
  %t317 = load i32, ptr %l128, !tbaa !23
  %t318 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t320 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s11, ptr %v3, ptr %v4, ptr %t315, i32 %t316, i32 %t317, { i64, ptr } %t318, %"compiler/source:Span" %t314)
  store { i64, [4 x i64] } %t320, ptr %l137
  br label %bb64
bb64:
  %t321 = load { i64, [4 x i64] }, ptr %l137
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l138, !tbaa !29
  store { i64, [4 x i64] } %t321, ptr %l139
  %t324 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t324, ptr %l140
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l141, !tbaa !29
  %t326 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t326, ptr %l142
  %t328 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s11, ptr %l142)
  store %"compiler/lower:pl" %t328, ptr %l144
  br label %bb65
bb65:
  %t329 = load %"compiler/lower:relPath", ptr %l6
  store %"compiler/lower:relPath" %t329, ptr %l146
  %t331 = call ptr @__olang_scope_hold(ptr %s11)
  %t332 = ptrtoint ptr %t331 to i64
  store i64 %t332, ptr %l147, !tbaa !24
  %t333 = load i1, ptr @olang_2esole_2ecompiler_2flower_3arelPath_2e1
  br i1 %t333, label %bb66, label %bb67
bb66:
  %t335 = call ptr @__olang_region_make_part(ptr %s11)
  %t336 = ptrtoint ptr %t335 to i64
  store i64 %t336, ptr %l147, !tbaa !24
  br label %bb67
bb67:
  %t337 = getelementptr %"compiler/lower:relPath", ptr %l146, i32 0, i32 1
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l149, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  store i64 %t340, ptr %l150, !tbaa !24
  %t341 = load i64, ptr %l150, !tbaa !24
  %t342 = mul i64 %t341, 8
  %t343 = load i64, ptr %l147
  %t344 = inttoptr i64 %t343 to ptr
  %t345 = call ptr @__olang_held_alloc(ptr %t344, i64 %t342)
  %t346 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  store { i64, ptr } %t347, ptr %l151, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = load i64, ptr %l150, !tbaa !24
  %t353 = mul i64 %t352, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t349, ptr %t351, i64 %t353, i1 false)
  %t354 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t355 = getelementptr %"compiler/lower:relPath", ptr %l146, i32 0, i32 1
  store { i64, ptr } %t354, ptr %t355, !tbaa !27
  %t356 = load i1, ptr @olang_2esole_2ecompiler_2flower_3arelPath_2e1
  br i1 %t356, label %bb68, label %bb69
bb68:
  %t358 = getelementptr %"compiler/lower:relPath", ptr %l146, i32 0, i32 1
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  %t362 = icmp eq i64 %t360, 0
  br i1 %t362, label %bb70, label %bb71
bb69:
  %t364 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t364, ptr %l156
  %t366 = call ptr @__olang_scope_hold(ptr %s11)
  %t367 = ptrtoint ptr %t366 to i64
  store i64 %t367, ptr %l157, !tbaa !24
  %t368 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2e0
  br i1 %t368, label %bb72, label %bb73
bb70:
  %t370 = getelementptr %"compiler/lower:relPath", ptr %l146, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t370, !tbaa !27
  br label %bb71
bb71:
  %t371 = getelementptr %"compiler/lower:relPath", ptr %l146, i32 0, i32 1
  %t372 = load i64, ptr %l147
  %t373 = inttoptr i64 %t372 to ptr
  %t374 = load { i64, ptr }, ptr %t371
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = call ptr @__olang_region_or(ptr %t375, ptr null)
  %t377 = icmp ne ptr %t376, null
  %t378 = select i1 %t377, ptr %t376, ptr null
  call void @__olang_region_settle_in(ptr %t373, ptr %t378)
  br label %bb69
bb72:
  %t379 = call ptr @__olang_region_make_part(ptr %s11)
  %t380 = ptrtoint ptr %t379 to i64
  store i64 %t380, ptr %l157, !tbaa !24
  br label %bb73
bb73:
  %t381 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156, i32 0, i32 0
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t382, 0
  store i64 %t383, ptr %l159, !tbaa !24
  %t384 = load i64, ptr %l159, !tbaa !24
  %t385 = mul i64 %t384, 64
  %t386 = load i64, ptr %l157
  %t387 = inttoptr i64 %t386 to ptr
  %t388 = call ptr @__olang_held_alloc(ptr %t387, i64 %t385)
  %t389 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  store { i64, ptr } %t390, ptr %l160, !tbaa !27
  store i64 0, ptr %l161, !tbaa !24
  br label %bb74
bb74:
  %t391 = load i64, ptr %l161, !tbaa !24
  %t392 = load i64, ptr %l159, !tbaa !24
  %t393 = icmp slt i64 %t391, %t392
  br i1 %t393, label %bb75, label %bb76
bb75:
  %t395 = load i64, ptr %l161, !tbaa !24
  %t396 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156, i32 0, i32 1
  %t397 = load i64, ptr %t396, !tbaa !24
  %t398 = icmp slt i64 %t395, %t397
  br i1 %t398, label %bb79, label %bb77
bb76:
  %t400 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t401 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156, i32 0, i32 0
  store { i64, ptr } %t400, ptr %t401, !tbaa !27
  %t402 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2e0
  br i1 %t402, label %bb86, label %bb87
bb77:
  %t404 = load i64, ptr %l161, !tbaa !24
  %t405 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = getelementptr %"compiler/lower:relPath", ptr %t406, i64 %t404
  store %"compiler/lower:relPath" zeroinitializer, ptr %t407
  br label %bb78
bb78:
  %t408 = load i64, ptr %l161, !tbaa !24
  %t409 = add i64 %t408, 1
  store i64 %t409, ptr %l161, !tbaa !24
  br label %bb74
bb79:
  %t410 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156, i32 0, i32 0
  %t411 = load i64, ptr %l161, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %t410, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr %"compiler/lower:relPath", ptr %t413, i64 %t411
  %t415 = load %"compiler/lower:relPath", ptr %t414
  store %"compiler/lower:relPath" %t415, ptr %l164
  %t416 = call ptr @__olang_scope_hold(ptr %s11)
  %t417 = ptrtoint ptr %t416 to i64
  store i64 %t417, ptr %l165, !tbaa !24
  %t418 = load i1, ptr @olang_2esole_2ecompiler_2flower_3arelPath_2e1
  br i1 %t418, label %bb80, label %bb81
bb80:
  %t420 = call ptr @__olang_region_make_part(ptr %s11)
  %t421 = ptrtoint ptr %t420 to i64
  store i64 %t421, ptr %l165, !tbaa !24
  br label %bb81
bb81:
  %t422 = getelementptr %"compiler/lower:relPath", ptr %l164, i32 0, i32 1
  %t423 = load { i64, ptr }, ptr %t422, !tbaa !27
  store { i64, ptr } %t423, ptr %l167, !tbaa !27
  %t424 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  store i64 %t425, ptr %l168, !tbaa !24
  %t426 = load i64, ptr %l168, !tbaa !24
  %t427 = mul i64 %t426, 8
  %t428 = load i64, ptr %l165
  %t429 = inttoptr i64 %t428 to ptr
  %t430 = call ptr @__olang_held_alloc(ptr %t429, i64 %t427)
  %t431 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t430, 1
  store { i64, ptr } %t432, ptr %l169, !tbaa !27
  %t433 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = load i64, ptr %l168, !tbaa !24
  %t438 = mul i64 %t437, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t434, ptr %t436, i64 %t438, i1 false)
  %t439 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t440 = getelementptr %"compiler/lower:relPath", ptr %l164, i32 0, i32 1
  store { i64, ptr } %t439, ptr %t440, !tbaa !27
  %t441 = load i1, ptr @olang_2esole_2ecompiler_2flower_3arelPath_2e1
  br i1 %t441, label %bb82, label %bb83
bb82:
  %t443 = getelementptr %"compiler/lower:relPath", ptr %l164, i32 0, i32 1
  %t444 = load { i64, ptr }, ptr %t443, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  %t447 = icmp eq i64 %t445, 0
  br i1 %t447, label %bb84, label %bb85
bb83:
  %t449 = load %"compiler/lower:relPath", ptr %l164
  %t450 = load i64, ptr %l161, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr %"compiler/lower:relPath", ptr %t452, i64 %t450
  store %"compiler/lower:relPath" %t449, ptr %t453
  br label %bb78
bb84:
  %t454 = getelementptr %"compiler/lower:relPath", ptr %l164, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t454, !tbaa !27
  br label %bb85
bb85:
  %t455 = getelementptr %"compiler/lower:relPath", ptr %l164, i32 0, i32 1
  %t456 = load i64, ptr %l165
  %t457 = inttoptr i64 %t456 to ptr
  %t458 = load { i64, ptr }, ptr %t455
  %t459 = extractvalue { i64, ptr } %t458, 1
  %t460 = call ptr @__olang_region_or(ptr %t459, ptr null)
  %t461 = icmp ne ptr %t460, null
  %t462 = select i1 %t461, ptr %t460, ptr null
  call void @__olang_region_settle_in(ptr %t457, ptr %t462)
  br label %bb83
bb86:
  %t463 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156, i32 0, i32 0
  %t464 = load { i64, ptr }, ptr %t463, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  %t467 = icmp eq i64 %t465, 0
  br i1 %t467, label %bb88, label %bb89
bb87:
  %t469 = load %"compiler/source:Span", ptr %l3
  %t470 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t471 = ptrtoint ptr %t470 to i64
  %t472 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 %t471, i64 8)
  %t473 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 0
  %t474 = load ptr, ptr %l141, !tbaa !29
  store ptr %t474, ptr %t473, !tbaa !28
  %t475 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 1
  %t476 = load %"compiler/lower:pl", ptr %l144
  store %"compiler/lower:pl" %t476, ptr %t475, !tbaa !28
  %t477 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 2
  %t478 = load %"compiler/lower:relPath", ptr %l146
  store %"compiler/lower:relPath" %t478, ptr %t477, !tbaa !28
  %t479 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 3
  %t480 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t480, ptr %t479, !tbaa !28
  %t481 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 4
  store %"compiler/source:Span" %t469, ptr %t481, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t483 = call ptr @__olang_scope_hold(ptr %v0)
  %t484 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 5
  store ptr %t483, ptr %t484, !tbaa !28
  call void @__olang_scope_escape(ptr %s2)
  %t485 = call ptr @__olang_scope_hold(ptr %s2)
  %t486 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 6
  store ptr %t485, ptr %t486, !tbaa !28
  call void @__olang_scope_escape(ptr %s2)
  %t487 = call ptr @__olang_scope_hold(ptr %s2)
  %t488 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 7
  store ptr %t487, ptr %t488, !tbaa !28
  call void @__olang_scope_escape(ptr %s11)
  %t489 = call ptr @__olang_scope_hold(ptr %s11)
  %t490 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %t472, i32 0, i32 8
  store ptr %t489, ptr %t490, !tbaa !28
  %t491 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_24, 0
  %t492 = insertvalue { ptr, ptr } %t491, ptr %t472, 1
  %t493 = load ptr, ptr %l138, !tbaa !29
  %t494 = load { i64, [4 x i64] }, ptr %l139
  %t495 = load %"compiler/source:Span", ptr %l140
  %t497 = extractvalue { ptr, ptr } %t492, 0
  %t498 = extractvalue { ptr, ptr } %t492, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %s11, ptr %v3, ptr %v4, ptr %t493, { i64, [4 x i64] } %t494, %"compiler/source:Span" %t495, ptr %t497, ptr %t498)
  br label %bb90
bb88:
  %t499 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t499, !tbaa !27
  br label %bb89
bb89:
  %t500 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156, i32 0, i32 0
  %t501 = load i64, ptr %l157
  %t502 = inttoptr i64 %t501 to ptr
  %t503 = load { i64, ptr }, ptr %t500
  %t504 = extractvalue { i64, ptr } %t503, 1
  %t505 = call ptr @__olang_region_or(ptr %t504, ptr null)
  %t506 = icmp ne ptr %t505, null
  %t507 = select i1 %t506, ptr %t505, ptr null
  call void @__olang_region_settle_in(ptr %t502, ptr %t507)
  br label %bb87
bb90:
  %t508 = load i32, ptr %l7, !tbaa !23
  %t509 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t512 = icmp ne i32 %t508, %t509
  br i1 %t512, label %bb91, label %bb92
bb91:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v4, ptr %v3, ptr %t514, i32 %t515)
  br label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s2)
  br label %bb109
bb95:
  %t518 = load ptr, ptr %l0, !tbaa !29
  store ptr %t518, ptr %l183, !tbaa !29
  %t519 = load %"compiler/lower:pl", ptr %l8
  store %"compiler/lower:pl" %t519, ptr %l184
  %t521 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l184)
  store %"compiler/lower:pl" %t521, ptr %l186
  br label %bb96
bb96:
  %t522 = load ptr, ptr %l183, !tbaa !29
  %t523 = load %"compiler/lower:pl", ptr %l186
  %t524 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %s2, ptr %v4, ptr %t522, %"compiler/lower:pl" %t523)
  store %"compiler/mir:Lvalue" %t524, ptr %l187
  br label %bb97
bb97:
  %t525 = load %"compiler/mir:Lvalue", ptr %l187
  store %"compiler/mir:Lvalue" %t525, ptr %l16
  %t526 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 3
  %t527 = load i1, ptr %t526, !tbaa !21
  br i1 %t527, label %bb98, label %bb99
bb98:
  %t529 = load %"compiler/source:Span", ptr %l3
  %t530 = load %"compiler/mir:Lvalue", ptr %l16
  store { i64, [21 x i64] } zeroinitializer, ptr %t531
  %t532 = getelementptr { i64, [21 x i64] }, ptr %t531, i32 0, i32 0
  store i64 8, ptr %t532
  %t534 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } undef, %"compiler/source:Span" %t529, 0
  %t536 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t534, %"compiler/mir:Lvalue" %t530, 1
  %t537 = getelementptr { i64, [21 x i64] }, ptr %t531, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t536, ptr %t537
  %t538 = load { i64, [21 x i64] }, ptr %t531
  store { i64, [21 x i64] } %t538, ptr %l192
  call void @llvm.memmove.p0.p0.i64(ptr %l189, ptr %l192, i64 176, i1 false)
  br label %bb100
bb99:
  %t539 = load %"compiler/source:Span", ptr %l3
  %t540 = load %"compiler/mir:Lvalue", ptr %l16
  store { i64, [21 x i64] } zeroinitializer, ptr %t541
  %t542 = getelementptr { i64, [21 x i64] }, ptr %t541, i32 0, i32 0
  store i64 6, ptr %t542
  %t544 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } undef, %"compiler/source:Span" %t539, 0
  %t546 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t544, %"compiler/mir:Lvalue" %t540, 1
  %t547 = getelementptr { i64, [21 x i64] }, ptr %t541, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t546, ptr %t547
  %t548 = load { i64, [21 x i64] }, ptr %t541
  store { i64, [21 x i64] } %t548, ptr %l195
  call void @llvm.memmove.p0.p0.i64(ptr %l189, ptr %l195, i64 176, i1 false)
  br label %bb100
bb100:
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %l189, i64 176, i1 false)
  %t549 = load ptr, ptr %l0, !tbaa !29
  store ptr %t549, ptr %l196, !tbaa !29
  %t550 = getelementptr %"compiler/lower:relPath", ptr %l6, i32 0, i32 2
  %t551 = load i1, ptr %t550, !tbaa !21
  br i1 %t551, label %bb101, label %bb102
bb101:
  %t553 = load %"compiler/source:Span", ptr %l3
  %t554 = load %"compiler/mir:Lvalue", ptr %l16
  store { i64, [21 x i64] } zeroinitializer, ptr %t555
  %t556 = getelementptr { i64, [21 x i64] }, ptr %t555, i32 0, i32 0
  store i64 7, ptr %t556
  %t558 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } undef, %"compiler/source:Span" %t553, 0
  %t560 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t558, %"compiler/mir:Lvalue" %t554, 1
  %t561 = getelementptr { i64, [21 x i64] }, ptr %t555, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t560, ptr %t561
  %t562 = load { i64, [21 x i64] }, ptr %t555
  %t564 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t562, ptr %t564
  store ptr %t564, ptr %l198, !tbaa !29
  br label %bb103
bb102:
  store ptr %l17, ptr %l198, !tbaa !29
  br label %bb103
bb103:
  %t567 = load ptr, ptr %l196, !tbaa !29
  %t568 = load ptr, ptr %l198, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %v3, ptr %v4, ptr %t567, ptr %t568)
  br label %bb104
bb104:
  %t569 = load i32, ptr %l7, !tbaa !23
  %t570 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t573 = icmp ne i32 %t569, %t570
  br i1 %t573, label %bb105, label %bb106
bb105:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v4, ptr %v3, ptr %t575, i32 %t576)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s2)
  br label %bb109
bb109:
  %t579 = load i64, ptr %l5, !tbaa !24
  %t582 = add i64 %t579, 1
  store i64 %t582, ptr %l5, !tbaa !24
  br label %bb1
bb110:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2esplitParts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, { i64, [1 x i64] } %a5, { i64, [1 x i64] } %a6, %"compiler/source:Span" %a7, { i64, ptr } %a8, i1 %a9) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca %"compiler/source:Span"
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/lower:pl"
  %l20 = alloca { i64, ptr }
  %l26 = alloca i64
  %l29 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca %"compiler/lower:pl"
  %l50 = alloca %"compiler/lower:pl"
  %l53 = alloca %"compiler/lower:pl"
  %l56 = alloca i1
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca %"compiler/lower:pl"
  %l68 = alloca %"compiler/lower:pl"
  %l78 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca %"compiler/lower:pl"
  %l83 = alloca %"compiler/lower:pl"
  %l93 = alloca ptr
  %l94 = alloca %"compiler/lower:pl"
  %l96 = alloca %"compiler/lower:pl"
  %l101 = alloca ptr
  %l102 = alloca %"compiler/lower:pl"
  %l104 = alloca i32
  %l105 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, [1 x i64] }
  %l109 = alloca { i64, [1 x i64] }
  %l110 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t62 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store { i64, [1 x i64] } %a5, ptr %l5
  store { i64, [1 x i64] } %a6, ptr %l6
  store %"compiler/source:Span" %a7, ptr %l7
  store i1 %a9, ptr %l9
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %s0, ptr %v3, ptr %t1, i32 %a2)
  store { i64, ptr } %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t6, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t11 = load i64, ptr %l12, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l13, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = load i64, ptr %l11, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l13, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l13, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l29, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l29, !tbaa !24
  store i64 %t37, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l26, !tbaa !24
  store i64 %t38, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l15, !tbaa !24
  %t40 = load i64, ptr %l14, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l11, !tbaa !24
  %t48 = load i64, ptr %l15, !tbaa !24
  %t49 = load i64, ptr %l13, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l16, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l47, !tbaa !29
  store %"compiler/lower:pl" %a1, ptr %l48
  %t60 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l48)
  store %"compiler/lower:pl" %t60, ptr %l50
  br label %bb12
bb12:
  %t61 = load i64, ptr %l16, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [1 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t65 = insertvalue { i64 } undef, i64 %t61, 0
  %t66 = getelementptr { i64, [1 x i64] }, ptr %t62, i32 0, i32 1
  store { i64 } %t65, ptr %t66
  %t67 = load { i64, [1 x i64] }, ptr %t62
  %t68 = load ptr, ptr %l47, !tbaa !29
  %t69 = load %"compiler/lower:pl", ptr %l50
  %t71 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s2, ptr %s2, ptr %t68, %"compiler/lower:pl" %t69, { i64, [1 x i64] } %t67)
  store %"compiler/lower:pl" %t71, ptr %l53
  br label %bb13
bb13:
  %t72 = load %"compiler/lower:pl", ptr %l53
  store %"compiler/lower:pl" %t72, ptr %l17
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp eq i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb14:
  %t78 = load i64, ptr %l16, !tbaa !24
  %t81 = call i1 @compiler_2flower_2eslottedField(ptr %s0, { i64, ptr } %a8, i64 %t78)
  store i1 %t81, ptr %l59
  br label %bb16
bb15:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb17
bb16:
  %t82 = load i1, ptr %l59, !tbaa !21
  store i1 %t82, ptr %l56, !tbaa !21
  br label %bb17
bb17:
  %t83 = load i1, ptr %l56, !tbaa !21
  br i1 %t83, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb19:
  br label %bb20
bb20:
  %t84 = load i64, ptr %l16, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t85, ptr %l61, !tbaa !27
  %t86 = load i64, ptr %l4, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i64, ptr %t89, i64 %t86
  %t91 = load i64, ptr %t90, !tbaa !34
  %t94 = icmp ne i64 %t84, %t91
  br i1 %t94, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l65, !tbaa !29
  %t97 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t97, ptr %l66
  %t99 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s4, ptr %l66)
  store %"compiler/lower:pl" %t99, ptr %l68
  br label %bb23
bb22:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t102 = add i64 %t100, 1
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t108 = icmp eq i64 %t102, %t105
  br i1 %t108, label %bb25, label %bb26
bb23:
  %t110 = load i64, ptr %l16, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  %t116 = load { i64, [1 x i64] }, ptr %l6
  %t117 = load %"compiler/source:Span", ptr %l7
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = load %"compiler/lower:pl", ptr %l68
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %s4, ptr %v3, ptr %v4, ptr %t118, %"compiler/lower:pl" %t119, i32 %t115, { i64, [1 x i64] } %t116, %"compiler/source:Span" %t117)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb25:
  %t123 = load i1, ptr %l9, !tbaa !21
  store i1 %t123, ptr %l78, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t125 = load i1, ptr %l78, !tbaa !21
  br i1 %t125, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l80, !tbaa !29
  %t127 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t127, ptr %l81
  %t129 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s6, ptr %l81)
  store %"compiler/lower:pl" %t129, ptr %l83
  br label %bb30
bb29:
  %t130 = load i64, ptr %l4, !tbaa !24
  %t132 = add i64 %t130, 1
  %t133 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t138 = icmp eq i64 %t132, %t135
  br i1 %t138, label %bb32, label %bb33
bb30:
  %t140 = load i64, ptr %l16, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i32, ptr %t143, i64 %t140
  %t145 = load i32, ptr %t144, !tbaa !33
  %t146 = load { i64, [1 x i64] }, ptr %l5
  %t147 = load %"compiler/source:Span", ptr %l7
  %t148 = load ptr, ptr %l80, !tbaa !29
  %t149 = load %"compiler/lower:pl", ptr %l83
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epartsCopied(ptr %v0, ptr %s6, ptr %v3, ptr %v4, ptr %t148, %"compiler/lower:pl" %t149, i32 %t145, { i64, [1 x i64] } %t146, %"compiler/source:Span" %t147)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l93, !tbaa !29
  %t154 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t154, ptr %l94
  %t156 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s8, ptr %l94)
  store %"compiler/lower:pl" %t156, ptr %l96
  br label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l101, !tbaa !29
  %t158 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t158, ptr %l102
  %t159 = load i64, ptr %l16, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  store i32 %t164, ptr %l104, !tbaa !23
  %t165 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t165, ptr %l105, !tbaa !27
  %t166 = load i64, ptr %l4, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l107, !tbaa !24
  %t169 = load { i64, [1 x i64] }, ptr %l5
  store { i64, [1 x i64] } %t169, ptr %l108
  %t170 = load { i64, [1 x i64] }, ptr %l6
  store { i64, [1 x i64] } %t170, ptr %l109
  %t171 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t171, ptr %l110
  %t172 = icmp sge i64 0, 0
  br i1 %t172, label %bb36, label %bb37
bb34:
  %t174 = load i64, ptr %l16, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i32, ptr %t177, i64 %t174
  %t179 = load i32, ptr %t178, !tbaa !33
  %t180 = load { i64, [1 x i64] }, ptr %l5
  %t181 = load %"compiler/source:Span", ptr %l7
  %t182 = load ptr, ptr %l93, !tbaa !29
  %t183 = load %"compiler/lower:pl", ptr %l96
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %s8, ptr %v3, ptr %v4, ptr %t182, %"compiler/lower:pl" %t183, i32 %t179, { i64, [1 x i64] } %t180, %"compiler/source:Span" %t181)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb36:
  %t187 = icmp sle i64 0, 1152921504606846975
  br i1 %t187, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a23d063b0bf9ea84_857e493ddc3bf8c8)
  unreachable
bb38:
  %t189 = mul i64 0, 8
  %t190 = insertvalue { i64, ptr } undef, i64 0, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t192 = load i1, ptr %l9, !tbaa !21
  %t193 = load ptr, ptr %l101, !tbaa !29
  %t194 = load %"compiler/lower:pl", ptr %l102
  %t195 = load i32, ptr %l104, !tbaa !23
  %t196 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t197 = load i64, ptr %l107, !tbaa !24
  %t198 = load { i64, [1 x i64] }, ptr %l108
  %t199 = load { i64, [1 x i64] }, ptr %l109
  %t200 = load %"compiler/source:Span", ptr %l110
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2esplitParts(ptr %v0, ptr %s9, ptr %v2, ptr %v3, ptr %v4, ptr %t193, %"compiler/lower:pl" %t194, i32 %t195, { i64, ptr } %t196, i64 %t197, { i64, [1 x i64] } %t198, { i64, [1 x i64] } %t199, %"compiler/source:Span" %t200, { i64, ptr } %t191, i1 %t192)
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_a23d063b0bf9ea84_857e493ddc3bf8c8)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb44:
  %t203 = load i64, ptr %l15, !tbaa !24
  %t206 = add i64 %t203, 1
  store i64 %t206, ptr %l15, !tbaa !24
  br label %bb8
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2estepType(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i32
  %l29 = alloca %"compiler/mir:Local"
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca ptr
  %l66 = alloca i32
  %l73 = alloca { i64, [1 x i64] }
  %l74 = alloca i32
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca i32
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l95 = alloca i32
  %l97 = alloca i32
  %l100 = alloca ptr
  %l103 = alloca i32
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l111 = alloca i32
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t7 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t7, ptr %l4
  %t9 = load { i64, [2 x i64] }, ptr %l4
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 1
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t15 = getelementptr { i32 }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 3
  %t21 = getelementptr %"compiler/mir:Fn", ptr %t20, i32 0, i32 7
  %t22 = load i32, ptr %l5, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t27 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t21, i64 %t24)
  store %"compiler/mir:Local" %t27, ptr %l29
  br label %bb4
bb4:
  %t28 = getelementptr %"compiler/mir:Local", ptr %l29, i32 0, i32 2
  %t29 = load i32, ptr %t28, !tbaa !23
  store i32 %t29, ptr %l21, !tbaa !23
  br label %bb14
bb5:
  %t31 = load { i64, [2 x i64] }, ptr %l4
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 2
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t37 = getelementptr { i64, i32, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l6, !tbaa !23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t40 = load i32, ptr %l6, !tbaa !23
  store i32 %t40, ptr %l21, !tbaa !23
  br label %bb14
bb9:
  %t42 = load { i64, [2 x i64] }, ptr %l4
  %t44 = extractvalue { i64, [2 x i64] } %t42, 0
  %t45 = icmp eq i64 %t44, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t47, ptr %l21, !tbaa !23
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a0544551fd9aba23_197859eb537d6a87)
  unreachable
bb14:
  %t49 = load i32, ptr %l21, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  store i64 0, ptr %l8, !tbaa !24
  store i64 %a2, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t58 = load i64, ptr %l10, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb20
bb17:
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l10, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l45, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb19
bb19:
  %t78 = load i64, ptr %l45, !tbaa !24
  store i64 %t78, ptr %l42, !tbaa !24
  br label %bb20
bb20:
  %t79 = load i64, ptr %l42, !tbaa !24
  store i64 %t79, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb21
bb21:
  %t80 = load i64, ptr %l12, !tbaa !24
  %t81 = load i64, ptr %l11, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb22, label %bb23
bb22:
  br label %bb54
bb23:
  br label %bb24
bb24:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l13, !tbaa !24
  %t98 = load ptr, ptr %l3, !tbaa !29
  store ptr %t98, ptr %l63, !tbaa !29
  %t99 = load i32, ptr %l7, !tbaa !23
  %t100 = load ptr, ptr %l63, !tbaa !29
  %t101 = call ptr @__olang_scope_or(ptr %v1, ptr %t100)
  %t102 = call ptr @__olang_scope_hold(ptr %t101)
  %t103 = ptrtoint ptr %t102 to i64
  %t105 = inttoptr i64 %t103 to ptr
  %t106 = load ptr, ptr %l63, !tbaa !29
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t105, ptr %t106, i32 %t99)
  store i32 %t108, ptr %l66
  br label %bb25
bb25:
  %t109 = load i32, ptr %l66, !tbaa !23
  store i32 %t109, ptr %l14, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/lower:lowering", ptr %t110, i32 0, i32 3
  %t113 = getelementptr %"compiler/mir:Fn", ptr %t112, i32 0, i32 10
  %t114 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t115 = getelementptr %"compiler/mir:Range", ptr %t114, i32 0, i32 0
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t125 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t113, i64 %t122)
  store { i64, [1 x i64] } %t125, ptr %l73
  br label %bb26
bb26:
  %t126 = load { i64, [1 x i64] }, ptr %l73
  store { i64, [1 x i64] } %t126, ptr %l15
  %t127 = load { i64, [1 x i64] }, ptr %l15
  %t129 = extractvalue { i64, [1 x i64] } %t127, 0
  %t130 = icmp eq i64 %t129, 0
  br i1 %t130, label %bb27, label %bb28
bb27:
  %t132 = getelementptr { i64, [1 x i64] }, ptr %l15, i32 0, i32 1
  %t133 = getelementptr { i64 }, ptr %t132, i32 0, i32 0
  %t134 = load i64, ptr %t133
  store i64 %t134, ptr %l16, !tbaa !24
  br label %bb29
bb28:
  br label %bb32
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t136 = load ptr, ptr %l3, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = load ptr, ptr %l3, !tbaa !29
  store ptr %t137, ptr %l79, !tbaa !29
  %t138 = load i32, ptr %l14, !tbaa !23
  %t139 = load ptr, ptr %l79, !tbaa !29
  %t140 = call ptr @__olang_scope_or(ptr %v1, ptr %t139)
  %t141 = call ptr @__olang_scope_hold(ptr %t140)
  %t142 = ptrtoint ptr %t141 to i64
  %t144 = inttoptr i64 %t142 to ptr
  %t145 = load ptr, ptr %l79, !tbaa !29
  %t147 = call i32 @compiler_2fmir_2eFieldsOf(ptr %t144, ptr %t145, i32 %t138)
  store i32 %t147, ptr %l82
  br label %bb30
bb30:
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t149 = call ptr @__olang_scope_or(ptr %v1, ptr %t148)
  %t150 = call ptr @__olang_scope_hold(ptr %t149)
  %t151 = ptrtoint ptr %t150 to i64
  %t153 = inttoptr i64 %t151 to ptr
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load i32, ptr %l82, !tbaa !23
  %t156 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t153, ptr %s6, ptr %t154, i32 %t155)
  store { i64, ptr } %t156, ptr %l84
  br label %bb31
bb31:
  %t157 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t157, ptr %l85, !tbaa !27
  %t158 = load i64, ptr %l16, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i32, ptr %t161, i64 %t158
  %t163 = load i32, ptr %t162, !tbaa !33
  store i32 %t163, ptr %l74, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb32:
  %t165 = load { i64, [1 x i64] }, ptr %l15
  %t167 = extractvalue { i64, [1 x i64] } %t165, 0
  %t168 = icmp eq i64 %t167, 1
  br i1 %t168, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t170 = load { i64, [1 x i64] }, ptr %l15
  %t172 = extractvalue { i64, [1 x i64] } %t170, 0
  %t173 = icmp eq i64 %t172, 2
  br i1 %t173, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t175 = load ptr, ptr %l3, !tbaa !29
  store ptr %t175, ptr %l92, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l14, !tbaa !23
  %t180 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v1, ptr %t176, i32 %t177)
  store i32 %t180, ptr %l95
  br label %bb38
bb38:
  %t181 = load ptr, ptr %l92, !tbaa !29
  %t182 = call ptr @__olang_scope_or(ptr %v1, ptr %t181)
  %t183 = call ptr @__olang_scope_hold(ptr %t182)
  %t184 = ptrtoint ptr %t183 to i64
  %t186 = inttoptr i64 %t184 to ptr
  %t187 = load ptr, ptr %l92, !tbaa !29
  %t188 = load i32, ptr %l95, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t186, ptr %t187, i32 %t188)
  store i32 %t189, ptr %l97
  br label %bb39
bb39:
  %t190 = load i32, ptr %l97, !tbaa !23
  store i32 %t190, ptr %l74, !tbaa !23
  br label %bb52
bb40:
  %t191 = load { i64, [1 x i64] }, ptr %l15
  %t193 = extractvalue { i64, [1 x i64] } %t191, 0
  %t194 = icmp eq i64 %t193, 3
  br i1 %t194, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t196 = load ptr, ptr %l3, !tbaa !29
  store ptr %t196, ptr %l100, !tbaa !29
  %t197 = load i32, ptr %l14, !tbaa !23
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = call ptr @__olang_scope_or(ptr %v1, ptr %t198)
  %t200 = call ptr @__olang_scope_hold(ptr %t199)
  %t201 = ptrtoint ptr %t200 to i64
  %t203 = inttoptr i64 %t201 to ptr
  %t204 = load ptr, ptr %l100, !tbaa !29
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t203, ptr %t204, i32 %t197)
  store i32 %t206, ptr %l103
  br label %bb44
bb44:
  %t207 = load i32, ptr %l103, !tbaa !23
  store i32 %t207, ptr %l74, !tbaa !23
  br label %bb52
bb45:
  %t208 = load { i64, [1 x i64] }, ptr %l15
  %t210 = extractvalue { i64, [1 x i64] } %t208, 0
  %t211 = icmp eq i64 %t210, 4
  br i1 %t211, label %bb46, label %bb47
bb46:
  %t213 = getelementptr { i64, [1 x i64] }, ptr %l15, i32 0, i32 1
  %t214 = getelementptr { i64 }, ptr %t213, i32 0, i32 0
  %t215 = load i64, ptr %t214
  store i64 %t215, ptr %l17, !tbaa !24
  br label %bb48
bb47:
  br label %bb51
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t217 = load ptr, ptr %l3, !tbaa !29
  store ptr %t217, ptr %l107, !tbaa !29
  %t218 = load ptr, ptr %l3, !tbaa !29
  store ptr %t218, ptr %l108, !tbaa !29
  %t219 = load i32, ptr %l14, !tbaa !23
  %t220 = load ptr, ptr %l108, !tbaa !29
  %t221 = call ptr @__olang_scope_or(ptr %v1, ptr %t220)
  %t222 = call ptr @__olang_scope_hold(ptr %t221)
  %t223 = ptrtoint ptr %t222 to i64
  %t225 = inttoptr i64 %t223 to ptr
  %t226 = load ptr, ptr %l108, !tbaa !29
  %t228 = call i32 @compiler_2fmir_2eCasesOf(ptr %t225, ptr %t226, i32 %t219)
  store i32 %t228, ptr %l111
  br label %bb49
bb49:
  %t229 = load ptr, ptr %l107, !tbaa !29
  %t230 = call ptr @__olang_scope_or(ptr %v1, ptr %t229)
  %t231 = call ptr @__olang_scope_hold(ptr %t230)
  %t232 = ptrtoint ptr %t231 to i64
  %t234 = inttoptr i64 %t232 to ptr
  %t235 = load ptr, ptr %l107, !tbaa !29
  %t236 = load i32, ptr %l111, !tbaa !23
  %t237 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t234, ptr %s9, ptr %t235, i32 %t236)
  store { i64, ptr } %t237, ptr %l113
  br label %bb50
bb50:
  %t238 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t238, ptr %l114, !tbaa !27
  %t239 = load i64, ptr %l17, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  store i32 %t244, ptr %l74, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_ecea37d4633e9922_e7ec56cda3c90b26)
  unreachable
bb52:
  %t246 = load i32, ptr %l74, !tbaa !23
  store i32 %t246, ptr %l7, !tbaa !23
  br label %bb53
bb53:
  %t247 = load i64, ptr %l12, !tbaa !24
  %t250 = add i64 %t247, 1
  store i64 %t250, ptr %l12, !tbaa !24
  br label %bb21
bb54:
  %t252 = load i32, ptr %l7, !tbaa !23
  store i32 %t252, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2estmtSpawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca i32
  %l42 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l55 = alloca i1
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca i32
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca ptr
  %l75 = alloca i32
  %l77 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l87 = alloca i32
  %l91 = alloca ptr
  %l92 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 17}
  %t13 = icmp eq i64 %t11, 14
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb41
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Spawn", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t21, ptr %t25)
  store i32 %t28, ptr %l29
  br label %bb6
bb6:
  %t29 = load i32, ptr %l29, !tbaa !23
  store i32 %t29, ptr %l5, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l33, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  store ptr %t37, ptr %l34, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t39 = load ptr, ptr %l34, !tbaa !29
  %t40 = call ptr @__olang_scope_or(ptr %v4, ptr %t39)
  %t41 = call ptr @__olang_scope_hold(ptr %t40)
  %t42 = ptrtoint ptr %t41 to i64
  %t44 = inttoptr i64 %t42 to ptr
  %t45 = load ptr, ptr %l34, !tbaa !29
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t44, ptr %t45, i32 %t38)
  store i32 %t47, ptr %l37
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l33, !tbaa !29
  %t49 = call ptr @__olang_scope_or(ptr %v4, ptr %t48)
  %t50 = call ptr @__olang_scope_hold(ptr %t49)
  %t51 = ptrtoint ptr %t50 to i64
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/lower:lowering", ptr %t52, i32 0, i32 2
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = call ptr @__olang_scope_or(ptr %v4, ptr %t55)
  %t58 = call ptr @__olang_scope_hold(ptr %t57)
  %t59 = ptrtoint ptr %t58 to i64
  %t61 = inttoptr i64 %t51 to ptr
  %t63 = inttoptr i64 %t59 to ptr
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t65 = load i32, ptr %l37, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t61, ptr %t63, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l42
  br label %bb11
bb11:
  %t67 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t67, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb13, label %bb14
bb13:
  br label %bb40
bb14:
  br label %bb15
bb15:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t80, ptr %l49, !tbaa !27
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i32, ptr %t84, i64 %t81
  %t86 = load i32, ptr %t85, !tbaa !33
  store i32 %t86, ptr %l9, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t90 = load i32, ptr %l9, !tbaa !23
  %t94 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eclausesTake(ptr %v0, ptr %v1, ptr %v4, ptr %t88, ptr %t89, i32 %t90)
  store i1 %t94, ptr %l55
  br label %bb16
bb16:
  %t95 = load i1, ptr %l55, !tbaa !21
  br i1 %t95, label %bb17, label %bb18
bb17:
  br label %bb39
bb18:
  br label %bb19
bb19:
  store i1 false, ptr %l10, !tbaa !21
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t98 = load i64, ptr %l12, !tbaa !24
  store i64 %t98, ptr %l57, !tbaa !24
  %t99 = load ptr, ptr %l11, !tbaa !29
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t99)
  store i64 %t101, ptr %l59
  br label %bb21
bb21:
  %t102 = load i64, ptr %l57, !tbaa !24
  %t103 = load i64, ptr %l59, !tbaa !24
  %t104 = icmp slt i64 %t102, %t103
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  br label %bb33
bb23:
  br label %bb24
bb24:
  %t108 = load ptr, ptr %l11, !tbaa !29
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t108, i64 %t109)
  store i32 %t112, ptr %l64
  br label %bb25
bb25:
  %t113 = load i32, ptr %l64, !tbaa !23
  store i32 %t113, ptr %l13, !tbaa !23
  %t114 = load i1, ptr %l10, !tbaa !21
  br i1 %t114, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb31
bb27:
  %t116 = load ptr, ptr %l3, !tbaa !29
  store ptr %t116, ptr %l67, !tbaa !29
  %t117 = load ptr, ptr %l3, !tbaa !29
  store ptr %t117, ptr %l68, !tbaa !29
  %t118 = load i32, ptr %l13, !tbaa !23
  %t119 = load ptr, ptr %l68, !tbaa !29
  %t120 = call ptr @__olang_scope_or(ptr %v4, ptr %t119)
  %t121 = call ptr @__olang_scope_hold(ptr %t120)
  %t122 = ptrtoint ptr %t121 to i64
  %t124 = inttoptr i64 %t122 to ptr
  %t125 = load ptr, ptr %l68, !tbaa !29
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t124, ptr %t125, i32 %t118)
  store i32 %t127, ptr %l71
  br label %bb28
bb28:
  %t128 = load ptr, ptr %l3, !tbaa !29
  store ptr %t128, ptr %l72, !tbaa !29
  %t129 = load i32, ptr %l9, !tbaa !23
  %t130 = load ptr, ptr %l72, !tbaa !29
  %t131 = call ptr @__olang_scope_or(ptr %v4, ptr %t130)
  %t132 = call ptr @__olang_scope_hold(ptr %t131)
  %t133 = ptrtoint ptr %t132 to i64
  %t135 = inttoptr i64 %t133 to ptr
  %t136 = load ptr, ptr %l72, !tbaa !29
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t135, ptr %t136, i32 %t129)
  store i32 %t138, ptr %l75
  br label %bb29
bb29:
  %t139 = load ptr, ptr %l67, !tbaa !29
  %t140 = call ptr @__olang_scope_or(ptr %v4, ptr %t139)
  %t141 = call ptr @__olang_scope_hold(ptr %t140)
  %t142 = ptrtoint ptr %t141 to i64
  %t144 = inttoptr i64 %t142 to ptr
  %t145 = load ptr, ptr %l67, !tbaa !29
  %t146 = load i32, ptr %l71, !tbaa !23
  %t147 = load i32, ptr %l75, !tbaa !23
  %t148 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %t144, ptr %t145, i32 %t146, i32 %t147)
  store i1 %t148, ptr %l77
  br label %bb30
bb30:
  %t149 = load i1, ptr %l77, !tbaa !21
  store i1 %t149, ptr %l66, !tbaa !21
  br label %bb31
bb31:
  %t150 = load i1, ptr %l66, !tbaa !21
  store i1 %t150, ptr %l10, !tbaa !21
  br label %bb32
bb32:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l12, !tbaa !24
  br label %bb20
bb33:
  %t156 = load i1, ptr %l10, !tbaa !21
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb34, label %bb35
bb34:
  %t160 = load ptr, ptr %l2, !tbaa !29
  store ptr %t160, ptr %l83, !tbaa !29
  %t161 = load ptr, ptr %l3, !tbaa !29
  store ptr %t161, ptr %l84, !tbaa !29
  %t162 = load i32, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l84, !tbaa !29
  %t164 = call ptr @__olang_scope_or(ptr %v4, ptr %t163)
  %t165 = call ptr @__olang_scope_hold(ptr %t164)
  %t166 = ptrtoint ptr %t165 to i64
  %t168 = inttoptr i64 %t166 to ptr
  %t169 = load ptr, ptr %l84, !tbaa !29
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t168, ptr %t169, i32 %t162)
  store i32 %t171, ptr %l87
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t172 = load ptr, ptr %l83, !tbaa !29
  %t173 = load i32, ptr %l87, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t172, i32 %t173)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t174 = load i64, ptr %l7, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l7, !tbaa !24
  br label %bb12
bb40:
  br label %bb69
bb41:
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t180 = load ptr, ptr %l91, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb42, label %bb43
bb42:
  %t183 = load ptr, ptr %l91, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 17}
  %t186 = icmp eq i64 %t184, 11
  store i1 %t186, ptr %l92, !tbaa !21
  br label %bb43
bb43:
  %t187 = load i1, ptr %l92, !tbaa !21
  br i1 %t187, label %bb44, label %bb45
bb44:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l14, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l14, !tbaa !29
  %t197 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t194, ptr %t195, ptr %t197)
  br label %bb47
bb47:
  br label %bb69
bb48:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t202 = load ptr, ptr %l101, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb49, label %bb50
bb49:
  %t205 = load ptr, ptr %l101, !tbaa !29
  %t206 = load i64, ptr %t205, !range !{i64 0, i64 17}
  %t208 = icmp eq i64 %t206, 3
  store i1 %t208, ptr %l102, !tbaa !21
  br label %bb50
bb50:
  %t209 = load i1, ptr %l102, !tbaa !21
  br i1 %t209, label %bb51, label %bb52
bb51:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr }, ptr %t212, i32 0, i32 1
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l15, !tbaa !29
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l15, !tbaa !29
  %t219 = getelementptr %"compiler/typed:If", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t216, ptr %t220, ptr %t222)
  br label %bb54
bb54:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load ptr, ptr %l15, !tbaa !29
  %t229 = getelementptr %"compiler/typed:If", ptr %t227, i32 0, i32 2
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t231 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t226, ptr %t230, ptr %t231)
  br label %bb55
bb55:
  br label %bb69
bb56:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t236 = load ptr, ptr %l116, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb57, label %bb58
bb57:
  %t239 = load ptr, ptr %l116, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 17}
  %t242 = icmp eq i64 %t240, 4
  store i1 %t242, ptr %l117, !tbaa !21
  br label %bb58
bb58:
  %t243 = load i1, ptr %l117, !tbaa !21
  br i1 %t243, label %bb59, label %bb60
bb59:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l16, !tbaa !29
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [3 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t252, i32 0, i32 2
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l17, !tbaa !29
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load ptr, ptr %l16, !tbaa !29
  %t259 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t256, ptr %t257, ptr %t259)
  br label %bb62
bb62:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l17, !tbaa !29
  %t265 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t263, ptr %t264, ptr %t265)
  br label %bb63
bb63:
  br label %bb69
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_7b1a9423057e34c5_261f06cd9be6d659)
  unreachable
bb69:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2etail(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { { i64, [7 x i64] }, i32 }
  %l6 = alloca { i64, [7 x i64] }
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca %"compiler/mir:Range"
  %l20 = alloca %"compiler/mir:Range"
  %l28 = alloca { { i64, [7 x i64] }, i32 }
  %l37 = alloca %"compiler/mir:Range"
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l49 = alloca { i64, ptr }
  %l52 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l87 = alloca { i64, [4 x i64] }
  %l88 = alloca i64
  %l93 = alloca { i64, [4 x i64] }
  %l95 = alloca { i64, ptr }
  %l101 = alloca { i64, [4 x i64] }
  %l109 = alloca %"compiler/mir:Range"
  %l115 = alloca %"compiler/mir:Range"
  %l118 = alloca ptr
  %l126 = alloca %"compiler/mir:Call"
  %l127 = alloca i32
  %s0 = alloca %olang.scope
  %t175 = alloca { i64, [15 x i64] }, align 8
  %t248 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Call", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  %t15 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t6, ptr %t10, %"compiler/source:Span" %t11, i32 -1)
  store { { i64, [7 x i64] }, i32 } %t15, ptr %l28
  br label %bb1
bb1:
  %t16 = load { { i64, [7 x i64] }, i32 }, ptr %l28
  store { { i64, [7 x i64] }, i32 } %t16, ptr %l5
  %t17 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 0
  %t18 = load { i64, [7 x i64] }, ptr %t17
  store { i64, [7 x i64] } %t18, ptr %l6
  %t20 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l7, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lower:lowering", ptr %t23, i32 0, i32 12
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load { i64, [7 x i64] }, ptr %l6
  %t31 = load i32, ptr %l7, !tbaa !23
  %t36 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %v4, ptr %v3, ptr %v2, ptr %v5, ptr %t28, ptr %t29, { i64, [7 x i64] } %t30, i32 %t31)
  store %"compiler/mir:Range" %t36, ptr %l37
  br label %bb5
bb5:
  %t37 = load %"compiler/mir:Range", ptr %l37
  store %"compiler/mir:Range" %t37, ptr %l8
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 12
  %t41 = load i1, ptr %t40, !tbaa !21
  br i1 %t41, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t43 = load ptr, ptr %l4, !tbaa !29
  store ptr %t43, ptr %l40, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  store ptr %t44, ptr %l41, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t46 = load ptr, ptr %l41, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v4, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %t51, ptr %t52, i32 %t45)
  store i32 %t54, ptr %l44
  br label %bb9
bb9:
  %t55 = load ptr, ptr %l40, !tbaa !29
  %t56 = call ptr @__olang_scope_or(ptr %v4, ptr %t55)
  %t57 = call ptr @__olang_scope_hold(ptr %t56)
  %t58 = ptrtoint ptr %t57 to i64
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = call ptr @__olang_scope_or(ptr %v4, ptr %t62)
  %t65 = call ptr @__olang_scope_hold(ptr %t64)
  %t66 = ptrtoint ptr %t65 to i64
  %t68 = inttoptr i64 %t58 to ptr
  %t70 = inttoptr i64 %t66 to ptr
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t72 = load i32, ptr %l44, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t68, ptr %t70, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l49
  br label %bb10
bb10:
  %t74 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t74, ptr %l9, !tbaa !27
  %t75 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  store i64 %t80, ptr %l52, !tbaa !24
  %t81 = load i64, ptr %l52, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb11, label %bb12
bb11:
  %t84 = load i64, ptr %l52, !tbaa !24
  %t85 = icmp sle i64 %t84, 230584300921369395
  br i1 %t85, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548)
  unreachable
bb13:
  %t87 = load i64, ptr %l52, !tbaa !24
  %t88 = mul i64 %t87, 40
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  store i64 %t93, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t95 = load i64, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548)
  unreachable
bb15:
  %t101 = load i64, ptr %l14, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb20
bb17:
  %t105 = load i64, ptr %l13, !tbaa !24
  %t106 = load i64, ptr %l12, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l63, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb19
bb19:
  %t121 = load i64, ptr %l63, !tbaa !24
  store i64 %t121, ptr %l60, !tbaa !24
  br label %bb20
bb20:
  %t122 = load i64, ptr %l60, !tbaa !24
  store i64 %t122, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  %t123 = load i64, ptr %l16, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t131 = load i64, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l16, !tbaa !24
  %t133 = load i64, ptr %l14, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l17, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/lower:lowering", ptr %t141, i32 0, i32 3
  %t144 = getelementptr %"compiler/mir:Fn", ptr %t143, i32 0, i32 11
  %t145 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t146 = load i32, ptr %t145, !tbaa !23
  %t148 = sext i32 %t146 to i64
  %t149 = load i64, ptr %l17, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t155 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t144, i64 %t152)
  store { i64, [4 x i64] } %t155, ptr %l87
  br label %bb25
bb25:
  %t156 = load { i64, [4 x i64] }, ptr %l87
  store { i64, [4 x i64] } %t156, ptr %l18
  %t157 = load i64, ptr %l17, !tbaa !24
  store i64 %t157, ptr %l88, !tbaa !24
  %t158 = load i64, ptr %l17, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t164 = icmp slt i64 %t158, %t161
  br i1 %t164, label %bb26, label %bb27
bb26:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t167, ptr %l95, !tbaa !27
  %t168 = load i64, ptr %l17, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i32, ptr %t171, i64 %t168
  %t173 = load i32, ptr %t172, !tbaa !33
  %t174 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [15 x i64] } zeroinitializer, ptr %t175
  %t176 = getelementptr { i64, [15 x i64] }, ptr %t175, i32 0, i32 0
  store i64 0, ptr %t176
  %t178 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t174, 0
  %t179 = getelementptr { i64, [15 x i64] }, ptr %t175, i32 0, i32 1
  store { { i64, [4 x i64] } } %t178, ptr %t179
  %t180 = load { i64, [15 x i64] }, ptr %t175
  %t181 = load %"compiler/source:Span", ptr %l1
  %t186 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v4, ptr %v3, ptr %t166, i32 %t173, { i64, [15 x i64] } %t180, %"compiler/source:Span" %t181)
  store { i64, [4 x i64] } %t186, ptr %l101
  br label %bb28
bb27:
  %t187 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t187, ptr %l93
  br label %bb29
bb28:
  %t189 = load { i64, [4 x i64] }, ptr %l101
  store { i64, [4 x i64] } %t189, ptr %l93
  br label %bb29
bb29:
  %t190 = load { i64, [4 x i64] }, ptr %l93
  %t191 = load i64, ptr %l88, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t193, i64 %t191
  store { i64, [4 x i64] } %t190, ptr %t194
  br label %bb30
bb30:
  %t195 = load i64, ptr %l16, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l16, !tbaa !24
  br label %bb21
bb31:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/lower:lowering", ptr %t200, i32 0, i32 3
  %t203 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t206 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t202, { i64, ptr } %t203)
  store %"compiler/mir:Range" %t206, ptr %l109
  br label %bb32
bb32:
  %t207 = load %"compiler/mir:Range", ptr %l109
  store %"compiler/mir:Range" %t207, ptr %l19
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load { i64, [7 x i64] }, ptr %l6
  %t210 = load i32, ptr %l7, !tbaa !23
  %t211 = load ptr, ptr %l2, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Call", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %t213, !tbaa !23
  %t219 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassedFor(ptr %v0, ptr %v4, ptr %v3, ptr %v2, ptr %v5, ptr %t208, { i64, [7 x i64] } %t209, i32 %t210, i32 %t214)
  store %"compiler/mir:Range" %t219, ptr %l115
  br label %bb33
bb33:
  %t220 = load %"compiler/mir:Range", ptr %l115
  store %"compiler/mir:Range" %t220, ptr %l20
  %t221 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v5, ptr %v4, ptr %v3, ptr %v2, ptr %t221, i64 0)
  br label %bb34
bb34:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/lower:lowering", ptr %t223, i32 0, i32 3
  store ptr %t225, ptr %l118, !tbaa !29
  %t226 = load { i64, [7 x i64] }, ptr %l6
  %t227 = load %"compiler/mir:Range", ptr %l19
  %t228 = load %"compiler/mir:Range", ptr %l20
  %t229 = load %"compiler/mir:Lvalue", ptr @G_2ecompiler_2fmir_2eNoPlace
  %t230 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t231 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t232 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t240 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t226, %"compiler/mir:Range" %t227, %"compiler/mir:Range" %t228, %"compiler/mir:Lvalue" %t229, i1 false, i32 %t230, i32 %t231, i32 %t232)
  store %"compiler/mir:Call" %t240, ptr %l126
  br label %bb35
bb35:
  %t241 = load ptr, ptr %l118, !tbaa !29
  %t242 = load %"compiler/mir:Call", ptr %l126
  %t243 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t241, %"compiler/mir:Call" %t242)
  store i32 %t243, ptr %l127
  br label %bb36
bb36:
  %t244 = load i32, ptr %l127, !tbaa !23
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l1
  store { i64, [8 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [8 x i64] }, ptr %t248, i32 0, i32 0
  store i64 6, ptr %t249
  %t251 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t246, 0
  %t253 = insertvalue { %"compiler/source:Span", i32 } %t251, i32 %t244, 1
  %t254 = getelementptr { i64, [8 x i64] }, ptr %t248, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t253, ptr %t254
  %t255 = load { i64, [8 x i64] }, ptr %t248
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v3, ptr %v4, ptr %t245, { i64, [8 x i64] } %t255)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:ViewWalk" @compiler_2flower_2ecompiler_2flower_3alowering_2eviewWalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca i32
  %l52 = alloca %"compiler/typed:Local"
  %l55 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l60 = alloca ptr
  %l63 = alloca i1
  %l67 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l94 = alloca %"compiler/typed:ViewWalk"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/typed:ViewWalk"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 5
  store ptr %t8, ptr %l14, !tbaa !29
  %t9 = load ptr, ptr %l14, !tbaa !29
  %t10 = call ptr @__olang_scope_or(ptr %v2, ptr %t9)
  %t11 = call ptr @__olang_scope_hold(ptr %t10)
  %t12 = ptrtoint ptr %t11 to i64
  %t14 = inttoptr i64 %t12 to ptr
  %t15 = load ptr, ptr %l14, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t14, ptr %t15)
  store i64 %t16, ptr %l16
  br label %bb1
bb1:
  %t17 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t18 = load i64, ptr %l16, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t18, i64 %t17)
  store i64 %t20, ptr %l18
  br label %bb2
bb2:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t48 = load i64, ptr %l25, !tbaa !24
  store i64 %t48, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t49 = load i64, ptr %l22, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Body", ptr %t68, i32 0, i32 3
  %t71 = load i64, ptr %t70, !tbaa !24
  store i64 %t71, ptr %l44, !tbaa !24
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l45, !tbaa !29
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t73, i32 0, i32 5
  store ptr %t75, ptr %l47, !tbaa !29
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t78 = call ptr @__olang_scope_or(ptr %v2, ptr %t77)
  %t79 = call ptr @__olang_scope_hold(ptr %t78)
  %t80 = ptrtoint ptr %t79 to i64
  %t82 = inttoptr i64 %t80 to ptr
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t85 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t82, ptr %t83, i64 %t76)
  store i32 %t85, ptr %l50
  br label %bb13
bb13:
  %t86 = load ptr, ptr %l45, !tbaa !29
  %t87 = call ptr @__olang_scope_or(ptr %v2, ptr %t86)
  %t88 = call ptr @__olang_scope_hold(ptr %t87)
  %t89 = ptrtoint ptr %t88 to i64
  %t91 = inttoptr i64 %t89 to ptr
  %t92 = load ptr, ptr %l45, !tbaa !29
  %t93 = load i32, ptr %l50, !tbaa !23
  %t94 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t91, ptr %t92, i32 %t93)
  store %"compiler/typed:Local" %t94, ptr %l52
  br label %bb14
bb14:
  %t95 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 1
  %t96 = getelementptr %"compiler/source:Span", ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t100 = load i64, ptr %l44, !tbaa !24
  %t102 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t100, i64 %t99)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t102, ptr %l55
  br label %bb15
bb15:
  %t103 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l55
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/lower:lowering", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/lower:Lowerer", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 5
  store ptr %t115, ptr %l60, !tbaa !29
  %t117 = load ptr, ptr %l60, !tbaa !29
  %t118 = call ptr @__olang_scope_or(ptr %v3, ptr %t117)
  %t119 = call ptr @__olang_scope_hold(ptr %t118)
  %t120 = ptrtoint ptr %t119 to i64
  %t122 = inttoptr i64 %t120 to ptr
  %t123 = load ptr, ptr %l60, !tbaa !29
  %t125 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %t122, ptr %t123, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t103)
  store i1 %t125, ptr %l63
  br label %bb16
bb16:
  %t126 = load i1, ptr %l63, !tbaa !21
  %t127 = xor i1 %t126, true
  br i1 %t127, label %bb17, label %bb18
bb17:
  %t129 = load i64, ptr %l1, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  store i64 %t131, ptr %l67, !tbaa !24
  %t132 = load i64, ptr %l67, !tbaa !24
  %t133 = load i64, ptr %l67, !tbaa !24
  %t134 = shl i64 1, %t133
  %t137 = or i64 %t129, %t134
  store i64 %t137, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t139 = load i64, ptr %l7, !tbaa !24
  %t142 = add i64 %t139, 1
  store i64 %t142, ptr %l7, !tbaa !24
  br label %bb9
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/lower:lowering", ptr %t144, i32 0, i32 0
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/lower:lowering", ptr %t149, i32 0, i32 2
  %t152 = load ptr, ptr %t151, !tbaa !29
  store ptr %t152, ptr %l76, !tbaa !29
  %t153 = load ptr, ptr %l2, !tbaa !29
  store ptr %t153, ptr %l77, !tbaa !29
  %t154 = load i64, ptr %l1, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/lower:lowering", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = call ptr @__olang_scope_or(ptr %v3, ptr %t158)
  %t161 = call ptr @__olang_scope_hold(ptr %t160)
  %t162 = ptrtoint ptr %t161 to i64
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/lower:lowering", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = call ptr @__olang_scope_or(ptr %v3, ptr %t167)
  %t170 = call ptr @__olang_scope_hold(ptr %t169)
  %t171 = ptrtoint ptr %t170 to i64
  %t172 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t173 = ptrtoint ptr %t172 to i64
  %t175 = inttoptr i64 %t162 to ptr
  %t176 = call ptr @__olang_scope_alloc_a(ptr %t175, i64 %t173, i64 8)
  %t177 = getelementptr { ptr, ptr }, ptr %t176, i32 0, i32 0
  store ptr %t147, ptr %t177, !tbaa !28
  %t180 = inttoptr i64 %t171 to ptr
  call void @__olang_scope_escape(ptr %t180)
  %t181 = call ptr @__olang_scope_hold(ptr %t180)
  %t182 = getelementptr { ptr, ptr }, ptr %t176, i32 0, i32 1
  store ptr %t181, ptr %t182, !tbaa !28
  %t183 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_25, 0
  %t184 = insertvalue { ptr, ptr } %t183, ptr %t176, 1
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t187 = ptrtoint ptr %t186 to i64
  %t188 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t187, i64 8)
  %t189 = getelementptr { ptr, ptr }, ptr %t188, i32 0, i32 0
  store ptr %t185, ptr %t189, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t191 = call ptr @__olang_scope_hold(ptr %v0)
  %t192 = getelementptr { ptr, ptr }, ptr %t188, i32 0, i32 1
  store ptr %t191, ptr %t192, !tbaa !28
  %t193 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_26, 0
  %t194 = insertvalue { ptr, ptr } %t193, ptr %t188, 1
  %t195 = load ptr, ptr %l76, !tbaa !29
  %t196 = call ptr @__olang_scope_or(ptr %v4, ptr %t195)
  %t197 = call ptr @__olang_scope_hold(ptr %t196)
  %t198 = ptrtoint ptr %t197 to i64
  %t199 = load ptr, ptr %l77, !tbaa !29
  %t200 = call ptr @__olang_scope_or(ptr %v2, ptr %t199)
  %t201 = call ptr @__olang_scope_hold(ptr %t200)
  %t202 = ptrtoint ptr %t201 to i64
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/lower:lowering", ptr %t203, i32 0, i32 0
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = call ptr @__olang_scope_or(ptr %v3, ptr %t206)
  %t209 = call ptr @__olang_scope_hold(ptr %t208)
  %t210 = ptrtoint ptr %t209 to i64
  %t212 = inttoptr i64 %t198 to ptr
  %t214 = inttoptr i64 %t202 to ptr
  %t216 = inttoptr i64 %t210 to ptr
  %t217 = load ptr, ptr %l76, !tbaa !29
  %t218 = load ptr, ptr %l77, !tbaa !29
  %t221 = extractvalue { ptr, ptr } %t184, 0
  %t222 = extractvalue { ptr, ptr } %t184, 1
  %t224 = extractvalue { ptr, ptr } %t194, 0
  %t225 = extractvalue { ptr, ptr } %t194, 1
  %t226 = call %"compiler/typed:ViewWalk" @compiler_2ftyped_3aViewWalk_2ector(ptr %t212, ptr %t214, ptr %t216, ptr %v0, ptr %v1, ptr %t217, ptr %t218, i64 %t154, ptr %t221, ptr %t222, ptr %t224, ptr %t225)
  store %"compiler/typed:ViewWalk" %t226, ptr %l94
  br label %bb22
bb22:
  %t227 = load %"compiler/typed:ViewWalk", ptr %l94
  store %"compiler/typed:ViewWalk" %t227, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:ViewWalk", ptr %rv
  ret %"compiler/typed:ViewWalk" %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ewithPayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l21 = alloca { i64, [4 x i64] }
  %l22 = alloca i32
  %l28 = alloca i64
  %l33 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l47 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l58 = alloca i32
  %l59 = alloca ptr
  %l62 = alloca i32
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca ptr
  %l85 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca i32
  %l90 = alloca i32
  %l93 = alloca ptr
  %l97 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca { i64, [1 x i64] }
  %l109 = alloca ptr
  %l115 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l137 = alloca i32
  %l138 = alloca ptr
  %l144 = alloca { i64, [4 x i64] }
  %l147 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l152 = alloca %"compiler/lower:pl"
  %l154 = alloca %"compiler/lower:pl"
  %l155 = alloca i64
  %l156 = alloca ptr
  %l157 = alloca ptr
  %l160 = alloca i32
  %l162 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l168 = alloca ptr
  %l170 = alloca ptr
  %l172 = alloca i32
  %l173 = alloca { i64, [1 x i64] }
  %l174 = alloca { i64, [1 x i64] }
  %l176 = alloca ptr
  %l178 = alloca i32
  %l181 = alloca { i64, [4 x i64] }
  %l187 = alloca ptr
  %l189 = alloca ptr
  %l191 = alloca i32
  %l194 = alloca i32
  %l202 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t189 = alloca { i64, [21 x i64] }, align 8
  %t202 = alloca { i64, [1 x i64] }, align 8
  %t310 = alloca { i64, [15 x i64] }, align 8
  %t333 = alloca { i64, [2 x i64] }, align 8
  %t341 = alloca { i64, [1 x i64] }, align 8
  %t399 = alloca { i64, [1 x i64] }, align 8
  %t414 = alloca { i64, [15 x i64] }, align 8
  %t434 = alloca { i64, [21 x i64] }, align 8
  %t473 = alloca { i64, [1 x i64] }, align 8
  %t478 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t14 = load { i64, [4 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [4 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 2
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i32, i64 }, ptr %t19, i32 0, i32 1
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t23 = load i64, ptr %l8, !tbaa !24
  store i64 %t23, ptr %l28, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f82a3f3df9ef67f1_af23eb46fab62c25)
  unreachable
bb9:
  %t25 = load i64, ptr %l28, !tbaa !24
  store i64 %t25, ptr %l9, !tbaa !24
  %t26 = load ptr, ptr %l6, !tbaa !29
  store ptr %t26, ptr %l33, !tbaa !29
  %t28 = load ptr, ptr %l33, !tbaa !29
  %t29 = call ptr @__olang_scope_or(ptr %v1, ptr %t28)
  %t30 = call ptr @__olang_scope_hold(ptr %t29)
  %t31 = ptrtoint ptr %t30 to i64
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lower:lowering", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = call ptr @__olang_scope_or(ptr %v1, ptr %t35)
  %t38 = call ptr @__olang_scope_hold(ptr %t37)
  %t39 = ptrtoint ptr %t38 to i64
  %t41 = inttoptr i64 %t31 to ptr
  %t43 = inttoptr i64 %t39 to ptr
  %t44 = load ptr, ptr %l33, !tbaa !29
  %t46 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t41, ptr %t43, ptr %t44, i32 %a3)
  store { i64, ptr } %t46, ptr %l39
  br label %bb10
bb10:
  %t47 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t47, ptr %l10, !tbaa !27
  %t48 = load i64, ptr %l9, !tbaa !24
  %t50 = ashr i64 %t48, 16
  %t52 = sub i64 %t50, 1
  store i64 %t52, ptr %l11, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t56 = and i64 %t54, 65535
  store i64 %t56, ptr %l12, !tbaa !24
  %t58 = load i64, ptr %l11, !tbaa !24
  %t60 = icmp slt i64 %t58, 0
  br i1 %t60, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb13
bb12:
  %t62 = load i64, ptr %l11, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp sge i64 %t62, %t65
  store i1 %t68, ptr %l47, !tbaa !21
  br label %bb13
bb13:
  %t70 = load i1, ptr %l47, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load { i64, [4 x i64] }, ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t71, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l6, !tbaa !29
  store ptr %t73, ptr %l53, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t74, ptr %l54, !tbaa !27
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t75
  %t80 = load i32, ptr %t79, !tbaa !33
  %t81 = load ptr, ptr %l53, !tbaa !29
  %t82 = call ptr @__olang_scope_or(ptr %v1, ptr %t81)
  %t83 = call ptr @__olang_scope_hold(ptr %t82)
  %t84 = ptrtoint ptr %t83 to i64
  %t86 = inttoptr i64 %t84 to ptr
  %t87 = load ptr, ptr %l53, !tbaa !29
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %t86, ptr %t87, i32 %t80)
  store i32 %t89, ptr %l58
  br label %bb17
bb17:
  %t90 = load i32, ptr %l58, !tbaa !23
  store i32 %t90, ptr %l13, !tbaa !23
  %t91 = load ptr, ptr %l7, !tbaa !29
  store ptr %t91, ptr %l59, !tbaa !29
  %t92 = load i32, ptr %l13, !tbaa !23
  %t93 = load ptr, ptr %l59, !tbaa !29
  %t94 = call ptr @__olang_scope_or(ptr %v2, ptr %t93)
  %t95 = call ptr @__olang_scope_hold(ptr %t94)
  %t96 = ptrtoint ptr %t95 to i64
  %t98 = inttoptr i64 %t96 to ptr
  %t99 = load ptr, ptr %l59, !tbaa !29
  %t101 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %t98, ptr %t99, i32 %t92)
  store i32 %t101, ptr %l62
  br label %bb18
bb18:
  %t102 = load i32, ptr %l62, !tbaa !23
  store i32 %t102, ptr %l14, !tbaa !23
  %t103 = load i32, ptr %l14, !tbaa !23
  %t104 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t107 = icmp eq i32 %t103, %t104
  br i1 %t107, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb23
bb20:
  %t109 = load ptr, ptr %l7, !tbaa !29
  store ptr %t109, ptr %l67, !tbaa !29
  %t110 = load ptr, ptr %l6, !tbaa !29
  store ptr %t110, ptr %l68, !tbaa !29
  %t111 = load i32, ptr %l13, !tbaa !23
  %t112 = load ptr, ptr %l68, !tbaa !29
  %t113 = call ptr @__olang_scope_or(ptr %v1, ptr %t112)
  %t114 = call ptr @__olang_scope_hold(ptr %t113)
  %t115 = ptrtoint ptr %t114 to i64
  %t117 = inttoptr i64 %t115 to ptr
  %t118 = load ptr, ptr %l68, !tbaa !29
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t117, ptr %t118, i32 %t111)
  store i32 %t120, ptr %l71
  br label %bb21
bb21:
  %t121 = load i64, ptr %l12, !tbaa !24
  %t122 = load ptr, ptr %l67, !tbaa !29
  %t123 = call ptr @__olang_scope_or(ptr %v2, ptr %t122)
  %t124 = call ptr @__olang_scope_hold(ptr %t123)
  %t125 = ptrtoint ptr %t124 to i64
  %t127 = inttoptr i64 %t125 to ptr
  %t128 = load ptr, ptr %l67, !tbaa !29
  %t129 = load i32, ptr %l71, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %t127, ptr %s0, ptr %t128, i32 %t129, i64 %t121)
  store { i64, ptr } %t131, ptr %l74
  br label %bb22
bb22:
  %t132 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  %t135 = icmp eq i64 %t133, 0
  store i1 %t135, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t137 = load i1, ptr %l66, !tbaa !21
  br i1 %t137, label %bb24, label %bb25
bb24:
  %t138 = load { i64, [4 x i64] }, ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t138, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t140 = load ptr, ptr %l6, !tbaa !29
  store ptr %t140, ptr %l78, !tbaa !29
  %t141 = load i32, ptr %l13, !tbaa !23
  %t142 = load ptr, ptr %l78, !tbaa !29
  %t143 = call ptr @__olang_scope_or(ptr %v1, ptr %t142)
  %t144 = call ptr @__olang_scope_hold(ptr %t143)
  %t145 = ptrtoint ptr %t144 to i64
  %t147 = inttoptr i64 %t145 to ptr
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t147, ptr %t148, i32 %t141)
  store i32 %t150, ptr %l81
  br label %bb27
bb27:
  %t151 = load i32, ptr %l81, !tbaa !23
  store i32 %t151, ptr %l15, !tbaa !23
  %t152 = load ptr, ptr %l6, !tbaa !29
  store ptr %t152, ptr %l82, !tbaa !29
  %t153 = load i32, ptr %l15, !tbaa !23
  %t154 = load ptr, ptr %l82, !tbaa !29
  %t155 = call ptr @__olang_scope_or(ptr %v1, ptr %t154)
  %t156 = call ptr @__olang_scope_hold(ptr %t155)
  %t157 = ptrtoint ptr %t156 to i64
  %t159 = inttoptr i64 %t157 to ptr
  %t160 = load ptr, ptr %l82, !tbaa !29
  %t162 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %t159, ptr %t160, i32 %t153)
  store i64 %t162, ptr %l85
  br label %bb28
bb28:
  %t163 = load i64, ptr %l85, !tbaa !24
  store i64 %t163, ptr %l16, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/lower:lowering", ptr %t164, i32 0, i32 3
  store ptr %t166, ptr %l87, !tbaa !29
  store i32 6, ptr %l88
  br i1 %a5, label %bb29, label %bb30
bb29:
  %t169 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  store i32 %t169, ptr %l90, !tbaa !23
  br label %bb32
bb30:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = call ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %s0, ptr %t171)
  store ptr %t173, ptr %l93
  br label %bb31
bb31:
  %t174 = load ptr, ptr %l93, !tbaa !29
  %t176 = getelementptr %"compiler/lower:level", ptr %t174, i32 0, i32 0
  %t177 = load i32, ptr %t176, !tbaa !23
  store i32 %t177, ptr %l90, !tbaa !23
  br label %bb32
bb32:
  %t179 = load %"compiler/source:Span", ptr %l4
  %t180 = load ptr, ptr %l87, !tbaa !29
  %t181 = load i32, ptr %l88, !range !{i32 0, i32 7}
  %t182 = load i32, ptr %l90, !tbaa !23
  %t184 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t180, i32 %t181, i32 %t182, i32 -1, %"compiler/source:Span" %t179, i32 0)
  store i32 %t184, ptr %l97
  br label %bb33
bb33:
  %t185 = load i32, ptr %l97, !tbaa !23
  store i32 %t185, ptr %l17, !tbaa !23
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l4
  %t188 = load i32, ptr %l17, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t189
  %t190 = getelementptr { i64, [21 x i64] }, ptr %t189, i32 0, i32 0
  store i64 3, ptr %t190
  %t192 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t187, 0
  %t194 = insertvalue { %"compiler/source:Span", i32 } %t192, i32 %t188, 1
  %t195 = getelementptr { i64, [21 x i64] }, ptr %t189, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t194, ptr %t195
  %t196 = load { i64, [21 x i64] }, ptr %t189
  %t198 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t196, ptr %t198
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t186, ptr %t198)
  br label %bb34
bb34:
  %t201 = load i32, ptr %l17, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [1 x i64] }, ptr %t202, i32 0, i32 0
  store i64 0, ptr %t203
  %t205 = insertvalue { i32 } undef, i32 %t201, 0
  %t206 = getelementptr { i64, [1 x i64] }, ptr %t202, i32 0, i32 1
  store { i32 } %t205, ptr %t206
  %t207 = load { i64, [1 x i64] }, ptr %t202
  store { i64, [1 x i64] } %t207, ptr %l18
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l105, !tbaa !29
  %t210 = load { i64, [1 x i64] }, ptr %l18
  store { i64, [1 x i64] } %t210, ptr %l106
  %t211 = load ptr, ptr %l7, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/load:Loader", ptr %t214, i32 0, i32 10
  store ptr %t216, ptr %l109, !tbaa !29
  %t217 = load i64, ptr %l16, !tbaa !24
  %t218 = load ptr, ptr %l109, !tbaa !29
  %t219 = call ptr @__olang_scope_or(ptr %v2, ptr %t218)
  %t220 = call ptr @__olang_scope_hold(ptr %t219)
  %t221 = ptrtoint ptr %t220 to i64
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/lower:lowering", ptr %t222, i32 0, i32 0
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = call ptr @__olang_scope_or(ptr %v2, ptr %t225)
  %t228 = call ptr @__olang_scope_hold(ptr %t227)
  %t229 = ptrtoint ptr %t228 to i64
  %t231 = inttoptr i64 %t221 to ptr
  %t233 = inttoptr i64 %t229 to ptr
  %t234 = load ptr, ptr %l109, !tbaa !29
  %t236 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %t231, ptr %t233, ptr %t234, i64 %t217)
  store ptr %t236, ptr %l115
  br label %bb35
bb35:
  %t237 = load ptr, ptr %l115, !tbaa !29
  %t239 = getelementptr %"compiler/load:Module", ptr %t237, i32 0, i32 2
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l117, !tbaa !27
  %t241 = load i64, ptr %l16, !tbaa !24
  %t242 = load ptr, ptr %l7, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 0
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/load:Loader", ptr %t245, i32 0, i32 12
  %t248 = load i64, ptr %t247, !tbaa !24
  %t251 = icmp eq i64 %t241, %t248
  %t252 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 1
  %t254 = call ptr @__olang_scope_or(ptr %v2, ptr %t253)
  %t255 = call ptr @__olang_scope_hold(ptr %t254)
  %t256 = ptrtoint ptr %t255 to i64
  %t258 = inttoptr i64 %t256 to ptr
  %t259 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t261 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %t258, ptr %s0, { i64, ptr } %t259, i1 %t251)
  store { i64, ptr } %t261, ptr %l124
  br label %bb36
bb36:
  %t262 = load ptr, ptr %l7, !tbaa !29
  store ptr %t262, ptr %l125, !tbaa !29
  %t263 = load i32, ptr %l15, !tbaa !23
  %t264 = load i64, ptr %l12, !tbaa !24
  %t265 = load ptr, ptr %l125, !tbaa !29
  %t266 = call ptr @__olang_scope_or(ptr %v2, ptr %t265)
  %t267 = call ptr @__olang_scope_hold(ptr %t266)
  %t268 = ptrtoint ptr %t267 to i64
  %t270 = inttoptr i64 %t268 to ptr
  %t271 = load ptr, ptr %l125, !tbaa !29
  %t274 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %t270, ptr %s0, ptr %t271, i32 %t263, i64 %t264)
  store { i64, ptr } %t274, ptr %l129
  br label %bb37
bb37:
  %t275 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = add i64 %t277, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t276, i64 %t277)
  %t283 = getelementptr i8, ptr %t282, i64 %t277
  call void @olang_textcopy(ptr %t283, ptr %t279, i64 %t280)
  %t284 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t282, 1
  %t287 = load %"compiler/source:Span", ptr %l4
  %t288 = load ptr, ptr %l105, !tbaa !29
  %t289 = load { i64, [1 x i64] }, ptr %l106
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t288, { i64, [1 x i64] } %t289, { i64, ptr } %t285, %"compiler/source:Span" %t287)
  br label %bb38
bb38:
  %t292 = load ptr, ptr %l6, !tbaa !29
  store ptr %t292, ptr %l133, !tbaa !29
  %t293 = load i32, ptr %l14, !tbaa !23
  %t294 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t295 = load ptr, ptr %l133, !tbaa !29
  %t296 = call ptr @__olang_scope_or(ptr %v1, ptr %t295)
  %t297 = call ptr @__olang_scope_hold(ptr %t296)
  %t298 = ptrtoint ptr %t297 to i64
  %t300 = inttoptr i64 %t298 to ptr
  %t301 = load ptr, ptr %l133, !tbaa !29
  %t304 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t300, ptr %t301, i32 %t293, i64 %t294)
  store i32 %t304, ptr %l137
  br label %bb39
bb39:
  %t305 = load i32, ptr %l137, !tbaa !23
  store i32 %t305, ptr %l19, !tbaa !23
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l138, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i32, ptr %l19, !tbaa !23
  %t309 = load i32, ptr %l19, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t310
  %t311 = getelementptr { i64, [15 x i64] }, ptr %t310, i32 0, i32 0
  store i64 22, ptr %t311
  %t313 = insertvalue { i32 } undef, i32 %t309, 0
  %t314 = getelementptr { i64, [15 x i64] }, ptr %t310, i32 0, i32 1
  store { i32 } %t313, ptr %t314
  %t315 = load { i64, [15 x i64] }, ptr %t310
  %t316 = load %"compiler/source:Span", ptr %l4
  %t321 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v2, ptr %t307, i32 %t308, { i64, [15 x i64] } %t315, %"compiler/source:Span" %t316)
  store { i64, [4 x i64] } %t321, ptr %l144
  br label %bb40
bb40:
  %t322 = load i32, ptr %l19, !tbaa !23
  %t323 = load %"compiler/source:Span", ptr %l4
  %t324 = load ptr, ptr %l138, !tbaa !29
  %t325 = load { i64, [4 x i64] }, ptr %l144
  %t328 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v1, ptr %v2, ptr %t324, { i64, [4 x i64] } %t325, i32 %t322, %"compiler/source:Span" %t323)
  store i32 %t328, ptr %l147
  br label %bb41
bb41:
  %t329 = load i32, ptr %l147, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l148, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l149, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t333
  %t334 = getelementptr { i64, [2 x i64] }, ptr %t333, i32 0, i32 0
  store i64 1, ptr %t334
  %t336 = insertvalue { i32 } undef, i32 %t329, 0
  %t337 = getelementptr { i64, [2 x i64] }, ptr %t333, i32 0, i32 1
  store { i32 } %t336, ptr %t337
  %t338 = load { i64, [2 x i64] }, ptr %t333
  %t340 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t338)
  store %"compiler/lower:pl" %t340, ptr %l152
  br label %bb42
bb42:
  store { i64, [1 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [1 x i64] }, ptr %t341, i32 0, i32 0
  store i64 3, ptr %t342
  %t343 = load { i64, [1 x i64] }, ptr %t341
  %t344 = load ptr, ptr %l149, !tbaa !29
  %t345 = load %"compiler/lower:pl", ptr %l152
  %t347 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %s0, ptr %s0, ptr %t344, %"compiler/lower:pl" %t345, { i64, [1 x i64] } %t343)
  store %"compiler/lower:pl" %t347, ptr %l154
  br label %bb43
bb43:
  %t348 = load i64, ptr %l12, !tbaa !24
  store i64 %t348, ptr %l155, !tbaa !24
  %t349 = load ptr, ptr %l6, !tbaa !29
  store ptr %t349, ptr %l156, !tbaa !29
  %t350 = load ptr, ptr %l6, !tbaa !29
  store ptr %t350, ptr %l157, !tbaa !29
  %t351 = load i32, ptr %l14, !tbaa !23
  %t352 = load ptr, ptr %l157, !tbaa !29
  %t353 = call ptr @__olang_scope_or(ptr %v1, ptr %t352)
  %t354 = call ptr @__olang_scope_hold(ptr %t353)
  %t355 = ptrtoint ptr %t354 to i64
  %t357 = inttoptr i64 %t355 to ptr
  %t358 = load ptr, ptr %l157, !tbaa !29
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %t357, ptr %t358, i32 %t351)
  store i32 %t360, ptr %l160
  br label %bb44
bb44:
  %t361 = load ptr, ptr %l156, !tbaa !29
  %t362 = call ptr @__olang_scope_or(ptr %v1, ptr %t361)
  %t363 = call ptr @__olang_scope_hold(ptr %t362)
  %t364 = ptrtoint ptr %t363 to i64
  %t366 = inttoptr i64 %t364 to ptr
  %t367 = load ptr, ptr %l156, !tbaa !29
  %t368 = load i32, ptr %l160, !tbaa !23
  %t369 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t366, ptr %s0, ptr %t367, i32 %t368)
  store { i64, ptr } %t369, ptr %l162
  br label %bb45
bb45:
  %t370 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t370, ptr %l163, !tbaa !27
  %t371 = load i64, ptr %l12, !tbaa !24
  %t373 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr i32, ptr %t374, i64 %t371
  %t376 = load i32, ptr %t375, !tbaa !33
  %t377 = load { i64, [1 x i64] }, ptr %l18
  %t378 = load %"compiler/source:Span", ptr %l4
  %t379 = load ptr, ptr %l148, !tbaa !29
  %t380 = load %"compiler/lower:pl", ptr %l154
  %t381 = load i64, ptr %l155, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderPayload(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t379, %"compiler/lower:pl" %t380, i64 %t381, i32 %t376, { i64, [1 x i64] } %t377, %"compiler/source:Span" %t378)
  br label %bb46
bb46:
  %t385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t385, ptr %l168, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/lower:lowering", ptr %t386, i32 0, i32 0
  %t389 = load ptr, ptr %t388, !tbaa !29
  store ptr %t389, ptr %l170, !tbaa !29
  %t390 = load ptr, ptr %l170, !tbaa !29
  %t391 = call ptr @__olang_scope_or(ptr %v2, ptr %t390)
  %t392 = call ptr @__olang_scope_hold(ptr %t391)
  %t393 = ptrtoint ptr %t392 to i64
  %t395 = inttoptr i64 %t393 to ptr
  %t396 = load ptr, ptr %l170, !tbaa !29
  %t397 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %t395, ptr %t396)
  store i32 %t397, ptr %l172
  br label %bb47
bb47:
  %t398 = load { i64, [1 x i64] }, ptr %l18
  store { i64, [1 x i64] } %t398, ptr %l173
  store { i64, [1 x i64] } zeroinitializer, ptr %t399
  %t400 = getelementptr { i64, [1 x i64] }, ptr %t399, i32 0, i32 0
  store i64 2, ptr %t400
  %t401 = load { i64, [1 x i64] }, ptr %t399
  store { i64, [1 x i64] } %t401, ptr %l174
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/lower:lowering", ptr %t402, i32 0, i32 0
  %t405 = load ptr, ptr %t404, !tbaa !29
  store ptr %t405, ptr %l176, !tbaa !29
  %t406 = load ptr, ptr %l176, !tbaa !29
  %t407 = call ptr @__olang_scope_or(ptr %v2, ptr %t406)
  %t408 = call ptr @__olang_scope_hold(ptr %t407)
  %t409 = ptrtoint ptr %t408 to i64
  %t411 = inttoptr i64 %t409 to ptr
  %t412 = load ptr, ptr %l176, !tbaa !29
  %t413 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %t411, ptr %t412)
  store i32 %t413, ptr %l178
  br label %bb48
bb48:
  store { i64, [15 x i64] } zeroinitializer, ptr %t414
  %t415 = getelementptr { i64, [15 x i64] }, ptr %t414, i32 0, i32 0
  store i64 12, ptr %t415
  %t416 = load { i64, [1 x i64] }, ptr %l173
  %t417 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %t416, 0
  %t418 = load { i64, [1 x i64] }, ptr %l174
  %t419 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t417, { i64, [1 x i64] } %t418, 1
  %t420 = load i32, ptr %l178, !tbaa !23
  %t421 = insertvalue { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t419, i32 %t420, 2
  %t422 = getelementptr { i64, [15 x i64] }, ptr %t414, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 } %t421, ptr %t422
  %t423 = load { i64, [15 x i64] }, ptr %t414
  %t424 = load %"compiler/source:Span", ptr %l4
  %t425 = load ptr, ptr %l168, !tbaa !29
  %t426 = load i32, ptr %l172, !tbaa !23
  %t429 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v2, ptr %t425, i32 %t426, { i64, [15 x i64] } %t423, %"compiler/source:Span" %t424)
  store { i64, [4 x i64] } %t429, ptr %l181
  br label %bb49
bb49:
  %t430 = load { i64, [4 x i64] }, ptr %l181
  store { i64, [4 x i64] } %t430, ptr %l21
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load %"compiler/source:Span", ptr %l4
  %t433 = load i32, ptr %l17, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t434
  %t435 = getelementptr { i64, [21 x i64] }, ptr %t434, i32 0, i32 0
  store i64 4, ptr %t435
  %t437 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t432, 0
  %t439 = insertvalue { %"compiler/source:Span", i32 } %t437, i32 %t433, 1
  %t440 = getelementptr { i64, [21 x i64] }, ptr %t434, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t439, ptr %t440
  %t441 = load { i64, [21 x i64] }, ptr %t434
  %t443 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t441, ptr %t443
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t431, ptr %t443)
  br label %bb50
bb50:
  %t446 = load ptr, ptr %l6, !tbaa !29
  store ptr %t446, ptr %l187, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/lower:lowering", ptr %t447, i32 0, i32 0
  %t450 = load ptr, ptr %t449, !tbaa !29
  store ptr %t450, ptr %l189, !tbaa !29
  %t451 = load ptr, ptr %l189, !tbaa !29
  %t452 = call ptr @__olang_scope_or(ptr %v2, ptr %t451)
  %t453 = call ptr @__olang_scope_hold(ptr %t452)
  %t454 = ptrtoint ptr %t453 to i64
  %t456 = inttoptr i64 %t454 to ptr
  %t457 = load ptr, ptr %l189, !tbaa !29
  %t458 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %t456, ptr %t457)
  store i32 %t458, ptr %l191
  br label %bb51
bb51:
  %t459 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t460 = load ptr, ptr %l187, !tbaa !29
  %t461 = call ptr @__olang_scope_or(ptr %v1, ptr %t460)
  %t462 = call ptr @__olang_scope_hold(ptr %t461)
  %t463 = ptrtoint ptr %t462 to i64
  %t465 = inttoptr i64 %t463 to ptr
  %t466 = load ptr, ptr %l187, !tbaa !29
  %t467 = load i32, ptr %l191, !tbaa !23
  %t469 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %t465, ptr %t466, i32 %t467, i64 %t459)
  store i32 %t469, ptr %l194
  br label %bb52
bb52:
  %t470 = load i32, ptr %l194, !tbaa !23
  store i32 %t470, ptr %l22, !tbaa !23
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load i32, ptr %l22, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t473
  %t474 = getelementptr { i64, [1 x i64] }, ptr %t473, i32 0, i32 0
  store i64 2, ptr %t474
  %t475 = load { i64, [1 x i64] }, ptr %t473
  %t476 = load { i64, [4 x i64] }, ptr %l21
  %t477 = load i32, ptr %l22, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t478
  %t479 = getelementptr { i64, [15 x i64] }, ptr %t478, i32 0, i32 0
  store i64 7, ptr %t479
  %t481 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t475, 0
  %t483 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t481, { i64, [4 x i64] } %t476, 1
  %t485 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t483, i32 %t477, 2
  %t486 = getelementptr { i64, [15 x i64] }, ptr %t478, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t485, ptr %t486
  %t487 = load { i64, [15 x i64] }, ptr %t478
  %t488 = load %"compiler/source:Span", ptr %l4
  %t493 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v2, ptr %t471, i32 %t472, { i64, [15 x i64] } %t487, %"compiler/source:Span" %t488)
  store { i64, [4 x i64] } %t493, ptr %l202
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t494 = load { i64, [4 x i64] }, ptr %l202
  store { i64, [4 x i64] } %t494, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2emarkLoop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, ptr %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l70 = alloca ptr
  %l73 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store i64 %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1, ptr %l21, !tbaa !27
  %t2 = load i64, ptr %l0, !tbaa !24
  %t3 = load i64, ptr %l0, !tbaa !24
  %t6 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr i64, ptr %t7, i64 %t2
  store i64 %t3, ptr %t8, !tbaa !34
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l24
  br label %bb1
bb1:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l7
  store i64 %a1, ptr %l8, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t13)
  store i64 %t15, ptr %l27
  br label %bb2
bb2:
  %t16 = load i64, ptr %l27, !tbaa !24
  store i64 %t16, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l9, !tbaa !24
  %t28 = load i64, ptr %l8, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l10, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l10, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l34, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l34, !tbaa !24
  store i64 %t43, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l31, !tbaa !24
  store i64 %t44, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l12, !tbaa !24
  %t46 = load i64, ptr %l11, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb25
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l12, !tbaa !24
  %t55 = load i64, ptr %l10, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l13, !tbaa !24
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t64 = load i64, ptr %l13, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l54
  br label %bb13
bb13:
  %t68 = load i64, ptr %l0, !tbaa !24
  %t69 = load i64, ptr %l54, !tbaa !24
  %t71 = icmp ne i64 %t69, %t68
  br i1 %t71, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb17
bb15:
  %t73 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t73, ptr %l58, !tbaa !27
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t75 = load i64, ptr %l13, !tbaa !24
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l61
  br label %bb16
bb16:
  %t79 = load i64, ptr %l61, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i64, ptr %t81, i64 %t79
  %t83 = load i64, ptr %t82, !tbaa !34
  %t84 = load i64, ptr %l0, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  store i1 %t87, ptr %l57, !tbaa !21
  br label %bb17
bb17:
  %t89 = load i1, ptr %l57, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t90, ptr %l65, !tbaa !27
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t92 = load i64, ptr %l13, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l68
  br label %bb21
bb21:
  %t96 = load i64, ptr %l0, !tbaa !24
  %t98 = load i64, ptr %l68, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i64, ptr %t100, i64 %t98
  store i64 %t96, ptr %t101, !tbaa !34
  store ptr %l7, ptr %l70, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l73
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l70, !tbaa !29
  %t108 = load i64, ptr %l73, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t107, i64 %t108)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l12, !tbaa !24
  br label %bb9
bb25:
  br label %bb26
bb26:
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t115, ptr %l78
  br label %bb27
bb27:
  %t116 = load i64, ptr %l78, !tbaa !24
  %t117 = icmp sgt i64 %t116, 0
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb28, label %bb29
bb28:
  br label %bb52
bb29:
  br label %bb30
bb30:
  %t122 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l7)
  %t123 = extractvalue { i32, i64 } %t122, 1
  %t124 = extractvalue { i32, i64 } %t122, 0
  store i32 %t124, ptr %l84
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb32, label %ok.126, !prof !99
ok.126:
  store i64 %t123, ptr %l83
  br label %bb31
bb31:
  %t127 = load i64, ptr %l83, !tbaa !24
  store i64 %t127, ptr %l81, !tbaa !24
  br label %bb34
bb32:
  br label %bb33
bb33:
  br label %bb52
bb34:
  %t128 = load i64, ptr %l81, !tbaa !24
  store i64 %t128, ptr %l14, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t129, ptr %l85, !tbaa !27
  %t130 = load i64, ptr %l14, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i64, ptr %t133, i64 %t130
  %t135 = load i64, ptr %t134, !tbaa !34
  store i64 %t135, ptr %l15, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t137, ptr %l88, !tbaa !27
  %t138 = load i64, ptr %l14, !tbaa !24
  %t140 = add i64 %t138, 1
  %t142 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i64, ptr %t143, i64 %t140
  %t145 = load i64, ptr %t144, !tbaa !34
  store i64 %t145, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t147 = load i64, ptr %l16, !tbaa !24
  %t148 = load i64, ptr %l15, !tbaa !24
  %t151 = icmp sgt i64 %t147, %t148
  br i1 %t151, label %bb35, label %bb36
bb35:
  %t153 = load i64, ptr %l17, !tbaa !24
  %t155 = icmp sgt i64 %t153, 0
  br i1 %t155, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb40
bb37:
  %t157 = load i64, ptr %l16, !tbaa !24
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = sub i64 %t157, %t158
  %t162 = load i64, ptr %l17, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = sub i64 %t165, 1
  %t168 = load i64, ptr %l17, !tbaa !24
  %t171 = sdiv i64 %t167, %t168
  store i64 %t171, ptr %l98, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb39
bb39:
  %t173 = load i64, ptr %l98, !tbaa !24
  store i64 %t173, ptr %l95, !tbaa !24
  br label %bb40
bb40:
  %t174 = load i64, ptr %l95, !tbaa !24
  store i64 %t174, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb41
bb41:
  %t175 = load i64, ptr %l19, !tbaa !24
  %t176 = load i64, ptr %l18, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb42, label %bb43
bb42:
  br label %bb50
bb43:
  br label %bb44
bb44:
  %t183 = load i64, ptr %l15, !tbaa !24
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l17, !tbaa !24
  %t188 = mul i64 %t184, %t185
  %t191 = add i64 %t183, %t188
  store i64 %t191, ptr %l20, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t193, ptr %l116, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t194, ptr %l117, !tbaa !27
  %t195 = load i64, ptr %l20, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr i64, ptr %t198, i64 %t195
  %t200 = load i64, ptr %t199, !tbaa !34
  %t202 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i64, ptr %t203, i64 %t200
  %t205 = load i64, ptr %t204, !tbaa !34
  %t206 = load i64, ptr %l0, !tbaa !24
  %t209 = icmp eq i64 %t205, %t206
  br i1 %t209, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t211 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t211, ptr %l123, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t212, ptr %l124, !tbaa !27
  %t213 = load i64, ptr %l20, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i64, ptr %t216, i64 %t213
  %t218 = load i64, ptr %t217, !tbaa !34
  %t219 = load i64, ptr %l0, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i64, ptr %t223, i64 %t218
  store i64 %t219, ptr %t224, !tbaa !34
  %t225 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t225, ptr %l129, !tbaa !27
  %t226 = load i64, ptr %l20, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i64, ptr %t229, i64 %t226
  %t231 = load i64, ptr %t230, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 %t231)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t234 = load i64, ptr %l19, !tbaa !24
  %t237 = add i64 %t234, 1
  store i64 %t237, ptr %l19, !tbaa !24
  br label %bb41
bb50:
  br label %bb51
bb51:
  br label %bb26
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2eplanHas(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef"
  %l41 = alloca { i64, [2 x i64] }
  %l43 = alloca { i64, [2 x i64] }
  %l45 = alloca i1
  %l46 = alloca i1
  %l50 = alloca %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H4f55ef78e9e24b109145d8f1cf8f3346(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l9, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = call %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H9d8ded0dc1fdd89425b004f66ec43476(ptr %v0, ptr %t53, i64 %t55)
  store %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" %t58, ptr %l40
  br label %bb12
bb12:
  %t59 = getelementptr %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef", ptr %l40, i32 0, i32 0
  %t60 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t60, ptr %l41
  store { i64, [2 x i64] } %a2, ptr %l43
  %t64 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aFnKey(ptr %l41, ptr %l43)
  store i1 %t64, ptr %l45
  br label %bb13
bb13:
  %t65 = load i1, ptr %l45, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = call %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H9d8ded0dc1fdd89425b004f66ec43476(ptr %v0, ptr %t66, i64 %t68)
  store %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" %t71, ptr %l50
  br label %bb16
bb15:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  %t72 = getelementptr %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef", ptr %l50, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  %t77 = icmp eq i64 %t73, %a3
  store i1 %t77, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t79 = load i1, ptr %l46, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb8
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2flower_2eslottedField(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l17 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = icmp slt i64 %t9, 2147483648
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  %t15 = and i1 %t10, %t12
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb1
bb1:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb2, label %bb3
bb2:
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t34 = ashr i64 %t30, 32
  %t38 = icmp eq i64 %t34, %a1
  br i1 %t38, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %l3, !tbaa !24
  br label %bb1
bb9:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/lower:CloneHand" @compiler_2flower_3aCloneHand_2ector(ptr %v0, i64 %a0, { i64, [2 x i64] } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/lower:CloneHand"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/lower:CloneHand" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/lower:CloneHand" %t10, { i64, [2 x i64] } %a1, 1
  %t14 = insertvalue %"compiler/lower:CloneHand" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/lower:CloneHand" %t14, i64 %a3, 3
  store %"compiler/lower:CloneHand" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:CloneHand", ptr %rv
  ret %"compiler/lower:CloneHand" %rr
}

define linkonce_odr %"compiler/lower:CloneSum" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3aCloneSum(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:CloneSum"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:CloneSum"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:CloneSum", ptr %a0
  store %"compiler/lower:CloneSum" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:CloneSum", ptr %l1, i32 0, i32 2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:CloneSum", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/lower:CloneSum", ptr %l1, i32 0, i32 3
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/lower:CloneSum", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = load %"compiler/lower:CloneSum", ptr %l1
  store %"compiler/lower:CloneSum" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:CloneSum", ptr %rv
  ret %"compiler/lower:CloneSum" %rr
}

@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ok " }>, align 8
@.c1 = private unnamed_addr constant [5 x i8] c"true\00"
@.c2 = private unnamed_addr constant [6 x i8] c"false\00"
@.d3 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" size " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" loop" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" hand " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"->" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aFnKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t8, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  %t13 = sext i32 %t11 to i64
  %t14 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %t13)
  call void @__olang_sb_add(ptr %v0, i64 %t15)
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t16, i64 %t17)
  br label %bb1
bb3:
  %t18 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t18, i64 %t19)
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i32, ptr %t24
  %t27 = sext i32 %t25 to i64
  %t28 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t27)
  call void @__olang_sb_add(ptr %v0, i64 %t29)
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t30, i64 %t31)
  br label %bb1
bb4:
  %t32 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t32, i64 %t33)
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t34, i64 %t35)
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 1
  %t38 = getelementptr { i32 }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  %t41 = sext i32 %t39 to i64
  %t42 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t41)
  call void @__olang_sb_add(ptr %v0, i64 %t43)
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t44, i64 %t45)
  br label %bb1
bb5:
  %t46 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t46, i64 %t47)
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t48, i64 %t49)
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %t52, i64 %a1)
  br label %bb9
bb6:
  %t55 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 1
  %t61 = getelementptr { i64 }, ptr %t60, i32 0, i32 0
  %t62 = load i64, ptr %t61
  %t64 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t65 = call i64 @__olang_fmt_i64(ptr %t64, i64 %t62)
  call void @__olang_sb_add(ptr %v0, i64 %t65)
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t66, i64 %t67)
  br label %bb1
bb7:
  %t68 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t68, i64 %t69)
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t70, i64 %t71)
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i64, i1 }, ptr %t73, i32 0, i32 0
  %t75 = load i64, ptr %t74
  %t77 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t78 = call i64 @__olang_fmt_i64(ptr %t77, i64 %t75)
  call void @__olang_sb_add(ptr %v0, i64 %t78)
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [2 x i64] }, ptr %t81, i32 0, i32 1
  %t83 = getelementptr { i64, i1 }, ptr %t82, i32 0, i32 1
  %t84 = load i1, ptr %t83
  %t86 = select i1 %t84, ptr @.c1, ptr @.c2
  %t87 = select i1 %t84, i64 4, i64 5
  call void @__olang_sb_put(ptr %v0, ptr %t86, i64 %t87)
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t88, i64 %t89)
  br label %bb1
bb8:
  %t90 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t90, i64 %t91)
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t92, i64 %t93)
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 1
  %t96 = getelementptr { i32, i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96
  %t99 = sext i32 %t97 to i64
  %t100 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t101 = call i64 @__olang_fmt_i64(ptr %t100, i64 %t99)
  call void @__olang_sb_add(ptr %v0, i64 %t101)
  %t102 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t102, i64 %t103)
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 1
  %t106 = getelementptr { i32, i64 }, ptr %t105, i32 0, i32 1
  %t107 = load i64, ptr %t106
  %t109 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t110 = call i64 @__olang_fmt_i64(ptr %t109, i64 %t107)
  call void @__olang_sb_add(ptr %v0, i64 %t110)
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t111, i64 %t112)
  br label %bb1
bb9:
  %t113 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t113, i64 %t114)
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr { i64, [2 x i64] }, ptr %t115, i32 0, i32 1
  %t117 = getelementptr { i32, i32 }, ptr %t116, i32 0, i32 1
  %t118 = load i32, ptr %t117
  %t120 = sext i32 %t118 to i64
  %t121 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t122 = call i64 @__olang_fmt_i64(ptr %t121, i64 %t120)
  call void @__olang_sb_add(ptr %v0, i64 %t122)
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t123, i64 %t124)
  br label %bb1
ret:
  ret void
}

@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" d" }>, align 8
declare void @__olang_sb_done(ptr)
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aFn(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:Fn"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 808, i1 false)
  %t2 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 4
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 6
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 7
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 8
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 9
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 10
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 11
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 12
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 13
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  %t52 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 14
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l23
  br label %bb11
bb11:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t56 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  %t57 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 15
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t57)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l25
  br label %bb12
bb12:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t61 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 16
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l27
  br label %bb13
bb13:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t66 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  %t67 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 17
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l29
  br label %bb14
bb14:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t71 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t71
  %t72 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 18
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t72)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l31
  br label %bb15
bb15:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t76 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t76
  %t77 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 19
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l33
  br label %bb16
bb16:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t81 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t81
  %t82 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 20
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t82)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l35
  br label %bb17
bb17:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  %t86 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %t86
  %t87 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 21
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %t87)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l37
  br label %bb18
bb18:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  %t91 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %t91
  %t92 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 22
  %t94 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t92)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l39
  br label %bb19
bb19:
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  %t96 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %t96
  %t97 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 23
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t97)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l41
  br label %bb20
bb20:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  %t101 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t101
  %t102 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 24
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t102)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l43
  br label %bb21
bb21:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t106 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %t106
  %t107 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 28
  %t109 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %t107)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l45
  br label %bb22
bb22:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t111 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t111
  %t112 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 29
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t112)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l47
  br label %bb23
bb23:
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t116 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %t116
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"gen" }>, align 8
@.d11 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"plain" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define internal i1 @olang_lambda_13(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" weak " }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
@.d15 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a constructor of a type that is no struct" }>, align 8
@.d16 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"unhandled error" }>, align 8
define linkonce_odr %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/lower:pl"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/lower:pl"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/lower:pl", ptr %a0
  store %"compiler/lower:pl" %t2, ptr %l1
  %t3 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/lower:pl", ptr %l1
  store %"compiler/lower:pl" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:pl", ptr %rv
  ret %"compiler/lower:pl" %rr
}

define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal void @olang_lambda_17(ptr %env, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca ptr
  %l3 = alloca %"compiler/lower:pl"
  %l5 = alloca %"compiler/lower:pl"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca %"compiler/lower:pl"
  %l14 = alloca %"compiler/lower:pl"
  %l17 = alloca %"compiler/lower:pl"
  %l18 = alloca ptr
  %l21 = alloca %"compiler/lower:pl"
  %l24 = alloca %"compiler/lower:pl"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca %"compiler/lower:pl"
  %l32 = alloca %"compiler/lower:pl"
  %l34 = alloca %"compiler/mir:Lvalue"
  %l35 = alloca ptr
  %l36 = alloca %"compiler/lower:pl"
  %l38 = alloca %"compiler/lower:pl"
  %l44 = alloca { i64, [4 x i64] }
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca ptr
  %l53 = alloca %"compiler/lower:pl"
  %l55 = alloca %"compiler/lower:pl"
  %l57 = alloca %"compiler/mir:Lvalue"
  %l61 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t6 = alloca { i64, [1 x i64] }, align 8
  %t19 = alloca { i64, [2 x i64] }, align 8
  %t28 = alloca { i64, [1 x i64] }, align 8
  %t71 = alloca { i64, [15 x i64] }, align 8
  %t77 = alloca { i64, [21 x i64] }, align 8
  %t113 = alloca { i64, [4 x i64] }, align 8
  %t119 = alloca { i64, [15 x i64] }, align 8
  %t125 = alloca { i64, [21 x i64] }, align 8
  store i32 %a0, ptr %l0
  %cp0 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %cp1 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/lower:pl", ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load i32, ptr %cp2, !tbaa !28
  %cp3 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load i64, ptr %cp3, !tbaa !28
  %cp4 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load %"compiler/source:Span", ptr %cp4, !tbaa !28
  store %"compiler/source:Span" %cv4, ptr %l7
  %cp5 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 5
  %cv5 = load i32, ptr %cp5, !tbaa !28
  store i32 %cv5, ptr %l8
  %cp6 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 6
  %cv6 = load { i64, [1 x i64] }, ptr %cp6, !tbaa !28
  %cp7 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 7
  %cv7 = load { i64, [1 x i64] }, ptr %cp7, !tbaa !28
  %vq0 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 8
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"compiler/lower:pl", i32, i64, %"compiler/source:Span", i32, { i64, [1 x i64] }, { i64, [1 x i64] }, ptr, ptr }, ptr %env, i32 0, i32 9
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store %"compiler/lower:pl" %cv1, ptr %l12
  %t4 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l12)
  store %"compiler/lower:pl" %t4, ptr %l14
  br label %bb1
bb1:
  %t5 = load i32, ptr %l0, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [1 x i64] }, ptr %t6, i32 0, i32 0
  store i64 1, ptr %t7
  %t9 = insertvalue { i32 } undef, i32 %t5, 0
  %t10 = getelementptr { i64, [1 x i64] }, ptr %t6, i32 0, i32 1
  store { i32 } %t9, ptr %t10
  %t11 = load { i64, [1 x i64] }, ptr %t6
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = load %"compiler/lower:pl", ptr %l14
  %t15 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s0, ptr %s0, ptr %t12, %"compiler/lower:pl" %t13, { i64, [1 x i64] } %t11)
  store %"compiler/lower:pl" %t15, ptr %l17
  br label %bb2
bb2:
  %t16 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t16, ptr %l3
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l18, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 1, ptr %t20
  %t22 = insertvalue { i32 } undef, i32 %cv2, 0
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 1
  store { i32 } %t22, ptr %t23
  %t24 = load { i64, [2 x i64] }, ptr %t19
  %t26 = call %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %s0, { i64, [2 x i64] } %t24)
  store %"compiler/lower:pl" %t26, ptr %l21
  br label %bb3
bb3:
  %t27 = load i32, ptr %l0, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t31 = insertvalue { i32 } undef, i32 %t27, 0
  %t32 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 1
  store { i32 } %t31, ptr %t32
  %t33 = load { i64, [1 x i64] }, ptr %t28
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = load %"compiler/lower:pl", ptr %l21
  %t37 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s0, ptr %s0, ptr %t34, %"compiler/lower:pl" %t35, { i64, [1 x i64] } %t33)
  store %"compiler/lower:pl" %t37, ptr %l24
  br label %bb4
bb4:
  %t38 = load %"compiler/lower:pl", ptr %l24
  store %"compiler/lower:pl" %t38, ptr %l5
  %t41 = icmp slt i64 %cv3, 0
  br i1 %t41, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t44, ptr %l28
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l29, !tbaa !29
  %t46 = load %"compiler/lower:pl", ptr %l5
  store %"compiler/lower:pl" %t46, ptr %l30
  %t48 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s1, ptr %l30)
  store %"compiler/lower:pl" %t48, ptr %l32
  br label %bb7
bb6:
  br label %bb12
bb7:
  %t50 = inttoptr i64 0 to ptr
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load %"compiler/lower:pl", ptr %l32
  %t53 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %vc0, ptr %s1, ptr %t50, ptr %t51, %"compiler/lower:pl" %t52)
  store %"compiler/mir:Lvalue" %t53, ptr %l34
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l35, !tbaa !29
  %t55 = load %"compiler/lower:pl", ptr %l3
  store %"compiler/lower:pl" %t55, ptr %l36
  %t57 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s1, ptr %l36)
  store %"compiler/lower:pl" %t57, ptr %l38
  br label %bb9
bb9:
  %t58 = load i32, ptr %l8, !tbaa !23
  %t60 = load %"compiler/source:Span", ptr %l7
  %t62 = inttoptr i64 0 to ptr
  %t64 = inttoptr i64 0 to ptr
  %t65 = load ptr, ptr %l35, !tbaa !29
  %t66 = load %"compiler/lower:pl", ptr %l38
  %t70 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyAt(ptr %vc0, ptr %s1, ptr %t62, ptr %t64, ptr %t65, %"compiler/lower:pl" %t66, i32 %t58, { i64, [1 x i64] } %cv6, %"compiler/source:Span" %t60, i1 false, i1 false)
  store { i64, [4 x i64] } %t70, ptr %l44
  br label %bb10
bb10:
  store { i64, [15 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [15 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %l44
  %t74 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t73, 0
  %t75 = getelementptr { i64, [15 x i64] }, ptr %t71, i32 0, i32 1
  store { { i64, [4 x i64] } } %t74, ptr %t75
  %t76 = load { i64, [15 x i64] }, ptr %t71
  store { i64, [21 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [21 x i64] }, ptr %t77, i32 0, i32 0
  store i64 0, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l28
  %t80 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t79, 0
  %t81 = load %"compiler/mir:Lvalue", ptr %l34
  %t82 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t80, %"compiler/mir:Lvalue" %t81, 1
  %t84 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t82, { i64, [15 x i64] } %t76, 2
  %t85 = getelementptr { i64, [21 x i64] }, ptr %t77, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t84, ptr %t85
  %t86 = load { i64, [21 x i64] }, ptr %t77
  %t88 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t86, ptr %t88
  %t90 = inttoptr i64 0 to ptr
  %t92 = inttoptr i64 0 to ptr
  %t93 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %vc0, ptr %s1, ptr %t90, ptr %t92, ptr %t93, ptr %t88)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l50, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t96, ptr %l51
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l52, !tbaa !29
  %t98 = load %"compiler/lower:pl", ptr %l5
  store %"compiler/lower:pl" %t98, ptr %l53
  %t100 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l53)
  store %"compiler/lower:pl" %t100, ptr %l55
  br label %bb13
bb13:
  %t102 = inttoptr i64 0 to ptr
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load %"compiler/lower:pl", ptr %l55
  %t105 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %vc0, ptr %s0, ptr %t102, ptr %t103, %"compiler/lower:pl" %t104)
  store %"compiler/mir:Lvalue" %t105, ptr %l57
  br label %bb14
bb14:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t107 = load %"compiler/lower:pl", ptr %l3
  %t109 = inttoptr i64 0 to ptr
  %t112 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %vc0, ptr %s0, ptr %t109, ptr %t106, %"compiler/lower:pl" %t107)
  store %"compiler/mir:Lvalue" %t112, ptr %l61
  br label %bb15
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t113
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 0
  store i64 1, ptr %t114
  %t115 = load %"compiler/mir:Lvalue", ptr %l61
  %t116 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t115, 0
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t116, ptr %t117
  %t118 = load { i64, [4 x i64] }, ptr %t113
  store { i64, [15 x i64] } zeroinitializer, ptr %t119
  %t120 = getelementptr { i64, [15 x i64] }, ptr %t119, i32 0, i32 0
  store i64 0, ptr %t120
  %t122 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t118, 0
  %t123 = getelementptr { i64, [15 x i64] }, ptr %t119, i32 0, i32 1
  store { { i64, [4 x i64] } } %t122, ptr %t123
  %t124 = load { i64, [15 x i64] }, ptr %t119
  store { i64, [21 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [21 x i64] }, ptr %t125, i32 0, i32 0
  store i64 0, ptr %t126
  %t127 = load %"compiler/source:Span", ptr %l51
  %t128 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t127, 0
  %t129 = load %"compiler/mir:Lvalue", ptr %l57
  %t130 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t128, %"compiler/mir:Lvalue" %t129, 1
  %t132 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t130, { i64, [15 x i64] } %t124, 2
  %t133 = getelementptr { i64, [21 x i64] }, ptr %t125, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t132, ptr %t133
  %t134 = load { i64, [21 x i64] }, ptr %t125
  %t136 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t134, ptr %t136
  %t138 = inttoptr i64 0 to ptr
  %t140 = inttoptr i64 0 to ptr
  %t141 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %vc0, ptr %s0, ptr %t138, ptr %t140, ptr %t141, ptr %t136)
  br label %bb16
bb16:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t144 = load %"compiler/lower:pl", ptr %l5
  %t145 = load i32, ptr %l8, !tbaa !23
  %t147 = load %"compiler/source:Span", ptr %l7
  %t149 = inttoptr i64 0 to ptr
  %t151 = inttoptr i64 0 to ptr
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2etextInto(ptr %vc0, ptr %s0, ptr %t149, ptr %t151, ptr %t143, %"compiler/lower:pl" %t144, i32 %t145, { i64, [1 x i64] } %cv7, %"compiler/source:Span" %t147)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define internal void @olang_lambda_18(ptr %env, i64 %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l20 = alloca i32
  %l22 = alloca { i64, ptr }
  %l28 = alloca i64
  %l31 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca %"compiler/lower:pl"
  %l54 = alloca %"compiler/lower:pl"
  %l57 = alloca %"compiler/lower:pl"
  %l60 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t83 = alloca { i64, [1 x i64] }, align 8
  %t94 = alloca { i64, [1 x i64] }, align 8
  %cp0 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %cp1 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/lower:pl", ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load { i64, [1 x i64] }, ptr %cp2, !tbaa !28
  %cp3 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load %"compiler/source:Span", ptr %cp3, !tbaa !28
  %vq0 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 4
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"compiler/lower:pl", { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 5
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/lower:lowering", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 2
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call ptr @__olang_scope_of(ptr %t10, ptr null)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t16, ptr %t5, i32 %a1)
  store i32 %t19, ptr %l20
  br label %bb1
bb1:
  %t21 = inttoptr i64 0 to ptr
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l20, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %vc0, ptr %s0, ptr %t21, ptr %t22, i32 %t23)
  store { i64, ptr } %t24, ptr %l22
  br label %bb2
bb2:
  %t25 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb3, label %bb4
bb3:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t56 = load i64, ptr %l31, !tbaa !24
  store i64 %t56, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t57 = load i64, ptr %l28, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l9, !tbaa !24
  %t76 = load ptr, ptr %l2, !tbaa !29
  store ptr %t76, ptr %l49, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  store ptr %t77, ptr %l50, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l51, !tbaa !29
  store %"compiler/lower:pl" %cv1, ptr %l52
  %t81 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s2, ptr %l52)
  store %"compiler/lower:pl" %t81, ptr %l54
  br label %bb13
bb13:
  store { i64, [1 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [1 x i64] }, ptr %t83, i32 0, i32 0
  store i64 4, ptr %t84
  %t86 = insertvalue { i64 } undef, i64 %a0, 0
  %t87 = getelementptr { i64, [1 x i64] }, ptr %t83, i32 0, i32 1
  store { i64 } %t86, ptr %t87
  %t88 = load { i64, [1 x i64] }, ptr %t83
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = load %"compiler/lower:pl", ptr %l54
  %t92 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s2, ptr %s2, ptr %t89, %"compiler/lower:pl" %t90, { i64, [1 x i64] } %t88)
  store %"compiler/lower:pl" %t92, ptr %l57
  br label %bb14
bb14:
  %t93 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [1 x i64] }, ptr %t94, i32 0, i32 0
  store i64 0, ptr %t95
  %t97 = insertvalue { i64 } undef, i64 %t93, 0
  %t98 = getelementptr { i64, [1 x i64] }, ptr %t94, i32 0, i32 1
  store { i64 } %t97, ptr %t98
  %t99 = load { i64, [1 x i64] }, ptr %t94
  %t100 = load ptr, ptr %l50, !tbaa !29
  %t101 = load %"compiler/lower:pl", ptr %l57
  %t103 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s2, ptr %s2, ptr %t100, %"compiler/lower:pl" %t101, { i64, [1 x i64] } %t99)
  store %"compiler/lower:pl" %t103, ptr %l60
  br label %bb15
bb15:
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t113 = inttoptr i64 0 to ptr
  %t115 = inttoptr i64 0 to ptr
  %t116 = load ptr, ptr %l49, !tbaa !29
  %t117 = load %"compiler/lower:pl", ptr %l60
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %vc0, ptr %s2, ptr %t113, ptr %t115, ptr %t116, %"compiler/lower:pl" %t117, i32 %t109, { i64, [1 x i64] } %cv2, %"compiler/source:Span" %cv3)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l8, !tbaa !24
  br label %bb9
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d19 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a Copy helper for a type with no parts" }>, align 8
define internal void @olang_lambda_20(ptr %env, i32 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/lower:pl"
  %l10 = alloca %"compiler/lower:pl"
  %l13 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %t7 = alloca { i64, [1 x i64] }, align 8
  %cp0 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %cp1 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/lower:pl", ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load i32, ptr %cp2, !tbaa !28
  %cp3 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load { i64, [1 x i64] }, ptr %cp3, !tbaa !28
  %cp4 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load %"compiler/source:Span", ptr %cp4, !tbaa !28
  %vq0 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 5
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"compiler/lower:pl", i32, { i64, [1 x i64] }, %"compiler/source:Span", ptr, ptr }, ptr %env, i32 0, i32 6
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l7, !tbaa !29
  store %"compiler/lower:pl" %cv1, ptr %l8
  %t5 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l8)
  store %"compiler/lower:pl" %t5, ptr %l10
  br label %bb1
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t7
  %t8 = getelementptr { i64, [1 x i64] }, ptr %t7, i32 0, i32 0
  store i64 1, ptr %t8
  %t10 = insertvalue { i32 } undef, i32 %a0, 0
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t7, i32 0, i32 1
  store { i32 } %t10, ptr %t11
  %t12 = load { i64, [1 x i64] }, ptr %t7
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load %"compiler/lower:pl", ptr %l10
  %t16 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s0, ptr %s0, ptr %t13, %"compiler/lower:pl" %t14, { i64, [1 x i64] } %t12)
  store %"compiler/lower:pl" %t16, ptr %l13
  br label %bb2
bb2:
  %t21 = inttoptr i64 0 to ptr
  %t23 = inttoptr i64 0 to ptr
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load %"compiler/lower:pl", ptr %l13
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %vc0, ptr %s0, ptr %t21, ptr %t23, ptr %t24, %"compiler/lower:pl" %t25, i32 %cv2, { i64, [1 x i64] } %cv3, %"compiler/source:Span" %cv4)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define internal i64 @olang_lambda_21(ptr %env, i32 %a0) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %vc0, ptr %cv0, i32 %a0)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define internal { i64, ptr } @olang_lambda_22(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/lower:Lowerer", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = sext i32 %a0 to i64
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %vc0, ptr %vc0, ptr %t10, i64 %t14)
  store ptr %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %t20, !tbaa !23
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %vc0, ptr %v0, ptr %t22, i32 %t21)
  store { i64, ptr } %t24, ptr %l13
  br label %bb2
bb2:
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@olang_2esole_2ecompiler_2flower_3arelPath_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
define internal void @olang_lambda_23(ptr %env, i32 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/lower:pl"
  %l10 = alloca %"compiler/lower:pl"
  %l13 = alloca %"compiler/lower:pl"
  %l15 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %t9 = alloca { i64, [1 x i64] }, align 8
  %t24 = alloca { i64, [21 x i64] }, align 8
  %cp0 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %cp1 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/source:Span", ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load %"compiler/lower:pl", ptr %cp2, !tbaa !28
  %vq0 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"compiler/source:Span", %"compiler/lower:pl", ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store %"compiler/source:Span" %cv1, ptr %l5
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  store %"compiler/lower:pl" %cv2, ptr %l8
  %t7 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l8)
  store %"compiler/lower:pl" %t7, ptr %l10
  br label %bb1
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [1 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i32 } undef, i32 %a0, 0
  %t13 = getelementptr { i64, [1 x i64] }, ptr %t9, i32 0, i32 1
  store { i32 } %t12, ptr %t13
  %t14 = load { i64, [1 x i64] }, ptr %t9
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load %"compiler/lower:pl", ptr %l10
  %t18 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s0, ptr %s0, ptr %t15, %"compiler/lower:pl" %t16, { i64, [1 x i64] } %t14)
  store %"compiler/lower:pl" %t18, ptr %l13
  br label %bb2
bb2:
  %t20 = inttoptr i64 0 to ptr
  %t21 = load ptr, ptr %l6, !tbaa !29
  %t22 = load %"compiler/lower:pl", ptr %l13
  %t23 = call %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %vc0, ptr %s0, ptr %t20, ptr %t21, %"compiler/lower:pl" %t22)
  store %"compiler/mir:Lvalue" %t23, ptr %l15
  br label %bb3
bb3:
  store { i64, [21 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 0
  store i64 7, ptr %t25
  %t26 = load %"compiler/source:Span", ptr %l5
  %t27 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } undef, %"compiler/source:Span" %t26, 0
  %t28 = load %"compiler/mir:Lvalue", ptr %l15
  %t29 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t27, %"compiler/mir:Lvalue" %t28, 1
  %t30 = getelementptr { i64, [21 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue" } %t29, ptr %t30
  %t31 = load { i64, [21 x i64] }, ptr %t24
  %t33 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t31, ptr %t33
  %t35 = inttoptr i64 0 to ptr
  %t37 = inttoptr i64 0 to ptr
  %t38 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %vc0, ptr %s0, ptr %t35, ptr %t37, ptr %t38, ptr %t33)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2e0 = weak hidden constant i1 false
define internal void @olang_lambda_24(ptr %env, i32 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"compiler/lower:relPath"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/lower:pl"
  %l10 = alloca %"compiler/lower:pl"
  %l13 = alloca %"compiler/lower:pl"
  %s0 = alloca %olang.scope
  %t7 = alloca { i64, [1 x i64] }, align 8
  %cp0 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %cp1 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/lower:pl", ptr %cp1, !tbaa !28
  %cp2 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load %"compiler/lower:relPath", ptr %cp2, !tbaa !28
  store %"compiler/lower:relPath" %cv2, ptr %l3
  %cp3 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %cp3, !tbaa !28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %cv3, ptr %l4
  %cp4 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load %"compiler/source:Span", ptr %cp4, !tbaa !28
  %vq0 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  %vq3 = getelementptr { ptr, %"compiler/lower:pl", %"compiler/lower:relPath", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 8
  %vr3 = load ptr, ptr %vq3, !tbaa !28
  %vc3 = call ptr @__olang_capture_scope(ptr %vr3)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l7, !tbaa !29
  store %"compiler/lower:pl" %cv1, ptr %l8
  %t5 = call %"compiler/lower:pl" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2flower_3apl(ptr %s0, ptr %l8)
  store %"compiler/lower:pl" %t5, ptr %l10
  br label %bb1
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t7
  %t8 = getelementptr { i64, [1 x i64] }, ptr %t7, i32 0, i32 0
  store i64 1, ptr %t8
  %t10 = insertvalue { i32 } undef, i32 %a0, 0
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t7, i32 0, i32 1
  store { i32 } %t10, ptr %t11
  %t12 = load { i64, [1 x i64] }, ptr %t7
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load %"compiler/lower:pl", ptr %l10
  %t16 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %vc0, ptr %s0, ptr %s0, ptr %t13, %"compiler/lower:pl" %t14, { i64, [1 x i64] } %t12)
  store %"compiler/lower:pl" %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = getelementptr %"compiler/lower:relPath", ptr %l3, i32 0, i32 6
  %t18 = load i32, ptr %t17, !tbaa !23
  %t21 = inttoptr i64 0 to ptr
  %t23 = inttoptr i64 0 to ptr
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load %"compiler/lower:pl", ptr %l13
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eelemRelease(ptr %vc0, ptr %s0, ptr %vc3, ptr %t21, ptr %t23, ptr %t24, %"compiler/lower:pl" %t25, i32 %t18, ptr %l4, %"compiler/source:Span" %cv4, i1 false)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@__olang_empty_array = external constant [16 x i64]
define internal i64 @olang_lambda_25(ptr %env, i32 %a0) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %vc0, ptr %cv0, i32 %a0)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define internal i64 @olang_lambda_26(ptr %env, i32 %a0) #0 {
entry:
  %l2 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %rv = alloca i64
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %cv0, i32 0, i32 67
  %t6 = sext i32 %a0 to i64
  %t9 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t3, i64 %t6)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l8
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aFnKey(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb22
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 0, label %bb4 i64 1, label %bb5 i64 2, label %bb6 i64 3, label %bb7 i64 4, label %bb8 i64 5, label %bb9 i64 6, label %bb10 ]
bb3:
  br label %bb22
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb11, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i32, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i32, ptr %t28
  %t32 = icmp eq i32 %t25, %t29
  br i1 %t32, label %bb12, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb13, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i32, i32 }, ptr %t47, i32 0, i32 0
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 1
  %t51 = getelementptr { i32, i32 }, ptr %t50, i32 0, i32 0
  %t54 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aHelperKind(ptr %t48, ptr %t51)
  store i1 %t54, ptr %l17
  br label %bb14
bb8:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 1
  %t57 = getelementptr { i64 }, ptr %t56, i32 0, i32 0
  %t58 = load i64, ptr %t57
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 1
  %t61 = getelementptr { i64 }, ptr %t60, i32 0, i32 0
  %t62 = load i64, ptr %t61
  %t65 = icmp eq i64 %t58, %t62
  br i1 %t65, label %bb17, label %bb1
bb9:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr { i64, [2 x i64] }, ptr %t67, i32 0, i32 1
  %t69 = getelementptr { i64, i1 }, ptr %t68, i32 0, i32 0
  %t70 = load i64, ptr %t69
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 1
  %t73 = getelementptr { i64, i1 }, ptr %t72, i32 0, i32 0
  %t74 = load i64, ptr %t73
  %t77 = icmp eq i64 %t70, %t74
  br i1 %t77, label %bb18, label %bb1
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 1
  %t81 = getelementptr { i32, i64 }, ptr %t80, i32 0, i32 0
  %t82 = load i32, ptr %t81
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [2 x i64] }, ptr %t83, i32 0, i32 1
  %t85 = getelementptr { i32, i64 }, ptr %t84, i32 0, i32 0
  %t86 = load i32, ptr %t85
  %t89 = icmp eq i32 %t82, %t86
  br i1 %t89, label %bb20, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  br label %bb3
bb14:
  %t91 = load i1, ptr %l17, !tbaa !21
  br i1 %t91, label %bb15, label %bb1
bb15:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr { i64, [2 x i64] }, ptr %t92, i32 0, i32 1
  %t94 = getelementptr { i32, i32 }, ptr %t93, i32 0, i32 1
  %t95 = load i32, ptr %t94
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t96, i32 0, i32 1
  %t98 = getelementptr { i32, i32 }, ptr %t97, i32 0, i32 1
  %t99 = load i32, ptr %t98
  %t102 = icmp eq i32 %t95, %t99
  br i1 %t102, label %bb16, label %bb1
bb16:
  br label %bb3
bb17:
  br label %bb3
bb18:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 1
  %t106 = getelementptr { i64, i1 }, ptr %t105, i32 0, i32 1
  %t107 = load i1, ptr %t106
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [2 x i64] }, ptr %t108, i32 0, i32 1
  %t110 = getelementptr { i64, i1 }, ptr %t109, i32 0, i32 1
  %t111 = load i1, ptr %t110
  %t114 = icmp eq i1 %t107, %t111
  br i1 %t114, label %bb19, label %bb1
bb19:
  br label %bb3
bb20:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t116, i32 0, i32 1
  %t118 = getelementptr { i32, i64 }, ptr %t117, i32 0, i32 1
  %t119 = load i64, ptr %t118
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 1
  %t122 = getelementptr { i32, i64 }, ptr %t121, i32 0, i32 1
  %t123 = load i64, ptr %t122
  %t126 = icmp eq i64 %t119, %t123
  br i1 %t126, label %bb21, label %bb1
bb21:
  br label %bb3
bb22:
  %t128 = load i1, ptr %l2, !tbaa !21
  store i1 %t128, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 48
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 48
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
@.d27 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"mir.FnKey.Body" }>, align 8
@.d28 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d29 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d30 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"mir.FnKey.Adapter" }>, align 8
@.d31 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"mir.FnKey.Copied" }>, align 8
@.d32 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"mir.FnKey.Helper" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 10}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
ret:
  ret void
}

@.d33 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"mir.FnKey.Init" }>, align 8
@.d34 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.FnKey.AnyRender" }>, align 8
@.d35 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d36 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"mir.FnKey.Twin" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 128
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 128
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 144
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 144
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 56
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 56
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aHelperKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 10}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 10}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d37 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"mir.HelperKind.Render" }>, align 8
@.d38 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Equal" }>, align 8
@.d39 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Hash" }>, align 8
@.d40 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Zero" }>, align 8
@.d41 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Copy" }>, align 8
@.d42 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Parts" }>, align 8
@.d43 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Drop" }>, align 8
@.d44 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Guard" }>, align 8
@.d45 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Split" }>, align 8
@.d46 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"mir.HelperKind.Release" }>, align 8
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/mir:BasicBlock"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 96
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/mir:BasicBlock", ptr %t14, i64 %t12
  %t17 = call %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %t15)
  store %"compiler/mir:BasicBlock" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/mir:BasicBlock", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/mir:BasicBlock", ptr %t22, i64 %t20
  store %"compiler/mir:BasicBlock" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
define linkonce_odr %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:BasicBlock"
  %l3 = alloca %"compiler/mir:StmtList"
  %rv = alloca %"compiler/mir:BasicBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:BasicBlock", ptr %a0
  store %"compiler/mir:BasicBlock" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  %t5 = call %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %t3)
  store %"compiler/mir:StmtList" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"compiler/mir:StmtList", ptr %l3
  %t7 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  store %"compiler/mir:StmtList" %t6, ptr %t7
  %t8 = load %"compiler/mir:BasicBlock", ptr %l1
  store %"compiler/mir:BasicBlock" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

declare ptr @__olang_scope_mine_slow(ptr) noinline
define linkonce_odr %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:StmtList"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/mir:StmtList"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:StmtList", ptr %a0
  store %"compiler/mir:StmtList" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 176
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 176
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/mir:StmtList", ptr %l1
  store %"compiler/mir:StmtList" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:StmtList", ptr %rv
  ret %"compiler/mir:StmtList" %rr
}

declare i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ecloneSum(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/lower:CloneSum" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneSum_3e_2eAt_3ccompiler_2flower_3aCloneSum_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e_2eLen__Hdac5394885c7d3b88563717d707df765(ptr %v0, ptr %a0)
declare %"compiler/lower:CloneHand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e_2eAt_3ccompiler_2flower_3aCloneHand_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_4e4c17ebfaf5d7b6_624a73934957b6f2 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare void @compiler_2flower_2estandIn(ptr %out, ptr %v0, i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare void @compiler_2flower_3alowering_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eadapterBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, i32 %a2, i32 %a3)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshRet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2efreshParam(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3993e9d21a27b6abd527556382000d9e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hc20348a7e3f4966d079d7d53957fcef1(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H25a1fa74df5469e35efe3ff4130517ef(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_c32f9218f06293f2_15f5ca50bc3801e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ehas(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ekeepsNoRef(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2epreserves(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [4 x i64] } @compiler_2flower_2eKnownOf(ptr %v0, { i64, [4 x i64] } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_1c8e237ef9fc0f77_d8ac58b856c76263 = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3bb6ecc05d6dab56_3c8834dd1d368462 = external constant [0 x i8]
declare i64 @compiler_2flower_2ewholeLocal({ i64, [4 x i64] } %a0)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e_2ePush_H85e09a50fcd8a8472d6e0741db5df478(ptr %v0, ptr %a0, %"compiler/lower:CloneHand" %a1)
@olang_loc_f74ed6c6f28c676d_f94a3fd07e079859 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aCloneHand_3e_2eToAr_Hf2705ae9b9c3665d2bce5131843165c9(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H4f55ef78e9e24b109145d8f1cf8f3346(ptr %v0, ptr %a0)
declare %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" @std_2fpair_3aPair_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %v0, { i64, [2 x i64] } %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H50aa64e76645cf352fa094d09391d67b(ptr %v0, ptr %a0, %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" %a1)
@G_2ecompiler_2flower_2eCloneDepth = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_Heb9f32f192b0b9cb232597ba4ed0fe11(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2flower_2eCloneSmall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2262f7260befbeda_ad33d1a86099f68e = external constant [0 x i8]
@olang_loc_78466967dd42e061_bdc585e3e8213235 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1)
@olang_loc_6143a96035d3ceac_ef612191f7538720 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i32 %a3)
@olang_loc_9919e1798def049b_eb223155b689b93f = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyLocal(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1)
@olang_loc_b4f44bfc4c4e49f2_17d18a81dcc1f1de = external constant [0 x i8]
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eownsStorage(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/mir:Lvalue" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2edeclaredCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4, i1 %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2ecopySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslotsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2, ptr %a3c, ptr %a3e)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare %"compiler/lower:pl" @compiler_2flower_3apl_2ector(ptr %v0, { i64, [2 x i64] } %a0)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2epartsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ecopyPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2etextSlotCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epayloads(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3, ptr %a4c, ptr %a4e)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eLen_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %a0)
@olang_loc_b0c77cc00353838c_f9addae603786cc8 = external constant [0 x i8]
declare %"compiler/lower:tryCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eAt_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2eRef_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_1378acbf535452a2_3a9100f5c9d7e1f6 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eraise(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, { i64, [4 x i64] } %a2, i1 %a3)
@olang_loc_17c5a608fc43bcc0_8499774d5e0fa2c = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eElemPlace(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eelemArrayCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, i64 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eEntryOnly(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eentryCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSelfHolding(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eselfHelper(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, %"compiler/lower:pl" %a2, i32 %a3, { i64, ptr } %a4, %"compiler/source:Span" %a5)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epartsCopied(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2emovedViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_6a3744415739a386_9143a8e3ed3639a2 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFreshCtorAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eViewsOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eFreshViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3c, ptr %a3e, ptr %a4c, ptr %a4e)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eHas_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, i64 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecountedBy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2flower_3ahoistWalk_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistStmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ehoistAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [4 x i64] } %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eKeys_3cI64_2c_20Bool_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2echar(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_54c4e502471f1575_5d803130ca2c9231 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_237828d44636a984_bc321bec2b6d0e20 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_40f2edcfdf80c59a_e6966279c0100e6 = external constant [0 x i8]
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2epromote(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2eLen_3ccompiler_2flower_3arelPath_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:relPath" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3arelPath_3e_2eAt_3ccompiler_2flower_3arelPath_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ewhenSole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i1 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2etextWalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, %"compiler/lower:relPath" %a2, %"compiler/source:Span" %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flower_2ecompiler_2flower_3alowering_2eelemReleases(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_a23d063b0bf9ea84_857e493ddc3bf8c8 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_a0544551fd9aba23_197859eb537d6a87 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ecea37d4633e9922_e7ec56cda3c90b26 = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2espawnErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_7b1a9423057e34c5_261f06cd9be6d659 = external constant [0 x i8]
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, [7 x i64] } %a2, i32 %a3)
@olang_loc_16ceb3f79d83ba4c_75eb4aa6518e3548 = external constant [0 x i8]
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassedFor(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2, i32 %a3)
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/typed:ViewWalk" @compiler_2ftyped_3aViewWalk_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2, ptr %a3c, ptr %a3e, ptr %a4c, ptr %a4e)
@olang_loc_f82a3f3df9ef67f1_af23eb46fab62c25 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderPayload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i64 %a2, i32 %a3, { i64, [1 x i64] } %a4, %"compiler/source:Span" %a5)
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2etext(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/pair:Pair.cd535570d3a02b648a091f4a8ee2ecef" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fmir_3aF_H9d8ded0dc1fdd89425b004f66ec43476(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2etextInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eelemRelease(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, ptr %a3, %"compiler/source:Span" %a4, i1 %a5)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
