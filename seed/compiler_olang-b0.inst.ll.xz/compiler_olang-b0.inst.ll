; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Listed" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, i1 }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/build:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
define dso_local i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/build:Program"
  %l18 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l25 = alloca i64
  %l27 = alloca i1
  %l29 = alloca i64
  %l33 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i1
  %l40 = alloca i32
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i32
  %l48 = alloca i1
  %l50 = alloca i32
  %l58 = alloca i32
  %l59 = alloca ptr
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l84 = alloca i1
  %l87 = alloca i32
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca { i64, [3 x i64] }
  %l93 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i32
  %l101 = alloca ptr
  %l104 = alloca i1
  %l106 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  %t200 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %v3)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t1, i64 280, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 280, i64 8)
  store ptr %t2, ptr %lp4
  %t3 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l7, i64 280, i1 false)
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 11
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  %t13 = getelementptr %"compiler/build:Config", ptr %t4, i32 0, i32 15
  store i1 %t10, ptr %t13, !tbaa !21
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load ptr, ptr %lp4
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v3, ptr %a0, { i64, ptr } %t15, i32 1, ptr %t16, ptr %t17, ptr %t18)
  store i32 %t25, ptr %l18
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb3, label %ok.27, !prof !99
ok.27:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = icmp eq i32 %t28, 65536
  br i1 %t29, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t31 = load i32, ptr %l18, !tbaa !23
  %t32 = icmp eq i32 %t31, 65537
  br i1 %t32, label %bb7, label %bb8
bb6:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t34)
  store i32 %t36, ptr %l22
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4cd8465f442ebc46_73c7e9f900a2458a)
  unreachable
bb9:
  %t37 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t37, ptr %l23
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i32, ptr %l23, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t40)
  store i64 %t42, ptr %l25
  br label %bb13
bb13:
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = icmp sgt i64 %t43, 0
  br i1 %t44, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb15:
  %t46 = load ptr, ptr %lp4
  %t47 = getelementptr %"compiler/build:Program", ptr %t46, i32 0, i32 0
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v3, ptr %t47)
  store i64 %t49, ptr %l29
  br label %bb16
bb16:
  %t50 = load i64, ptr %l29, !tbaa !24
  %t51 = icmp eq i64 %t50, 0
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %lp4
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2eUnspill(ptr %v3, ptr %t54)
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t56)
  store i32 %t58, ptr %l33
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load i32, ptr %l33, !tbaa !23
  store i32 %t59, ptr %rv
  br label %ret
bb22:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t64 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t60, ptr %t61)
  store i32 %t64, ptr %l36
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb24, label %ok.66, !prof !99
ok.66:
  br label %bb23
bb23:
  br label %bb27
bb24:
  %t67 = load i32, ptr %l36, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  store i1 %t70, ptr %l38, !tbaa !21
  br label %bb25
bb25:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t71)
  store i32 %t73, ptr %l40
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load i32, ptr %l40, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb27:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t76 = load ptr, ptr %lp4
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t81 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %v3, ptr %v3, ptr %v3, ptr %t75, ptr %t76, ptr %t77)
  %t82 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t81, 1
  %t83 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t81, 0
  store i32 %t83, ptr %l46
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb29, label %ok.85, !prof !99
ok.85:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l45
  br label %bb28
bb28:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l41
  br label %bb32
bb29:
  %t87 = load i32, ptr %l46, !tbaa !23
  %t88 = ashr i32 %t87, 16
  %t90 = icmp eq i32 %t88, 1
  store i1 %t90, ptr %l48, !tbaa !21
  br label %bb30
bb30:
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t91)
  store i32 %t93, ptr %l50
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load i32, ptr %l50, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb32:
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l5
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb33
bb33:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 11
  %t99 = load i1, ptr %t98, !tbaa !21
  br i1 %t99, label %bb34, label %bb35
bb34:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t102 = load ptr, ptr %lp4
  %t103 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t110 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v1, ptr %v3, ptr %v3, ptr %v2, ptr %v3, ptr %t101, ptr %t102, ptr %l5, { i64, ptr } %t103, ptr %t104)
  store i32 %t110, ptr %l58
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i32, ptr %l58, !tbaa !23
  store i32 %t111, ptr %rv
  br label %ret
bb37:
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l59, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/build:Config", ptr %t113, i32 0, i32 34
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t118, ptr %l62
  br label %bb38
bb38:
  %t119 = load i1, ptr %l62, !tbaa !21
  %t120 = xor i1 %t119, true
  br i1 %t120, label %bb39, label %bb40
bb39:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/build:Config", ptr %t122, i32 0, i32 34
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 1
  %t128 = extractvalue { i64, ptr } %t125, 0
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t127, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l64, !tbaa !27
  br label %bb44
bb40:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/build:Config", ptr %t134, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l70, !tbaa !27
  %t138 = load ptr, ptr %lp4
  %t140 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v3, ptr %s0, ptr %t138)
  store { i64, ptr } %t140, ptr %l72
  br label %bb41
bb41:
  %t141 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t143 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t141)
  store { i64, ptr } %t143, ptr %l74
  br label %bb42
bb42:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t144)
  store { i64, ptr } %t146, ptr %l76
  br label %bb43
bb43:
  %t147 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t153 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = add i64 %t152, %t155
  %t157 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = add i64 %t156, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t148, i64 %t149)
  %t162 = getelementptr i8, ptr %t161, i64 %t149
  call void @olang_textcopy(ptr %t162, ptr %t150, i64 %t151)
  %t163 = getelementptr i8, ptr %t162, i64 %t151
  call void @olang_textcopy(ptr %t163, ptr %t154, i64 %t155)
  %t164 = getelementptr i8, ptr %t163, i64 %t155
  call void @olang_textcopy(ptr %t164, ptr %t158, i64 %t159)
  %t165 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t161, 1
  store { i64, ptr } %t166, ptr %l64, !tbaa !27
  br label %bb44
bb44:
  %t169 = load ptr, ptr %l59, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t171 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eexe(ptr %v1, ptr %s0, ptr %v1, ptr %t169, { i64, ptr } %t170)
  store { i64, ptr } %t171, ptr %l79
  br label %bb45
bb45:
  %t172 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t172, ptr %lp6
  %t173 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t174 = load ptr, ptr %lp6
  store { i64, ptr } %t173, ptr %t174, !tbaa !27
  %t175 = load ptr, ptr %l1, !tbaa !29
  store ptr %t175, ptr %l80, !tbaa !29
  store ptr %l5, ptr %l81, !tbaa !29
  %t176 = load ptr, ptr %lp6
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  store { i64, ptr } %t177, ptr %l82, !tbaa !27
  %t178 = load ptr, ptr %lp4
  %t179 = getelementptr %"compiler/build:Program", ptr %t178, i32 0, i32 2
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t182 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t180, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t182, ptr %l84
  br label %bb46
bb46:
  %t183 = load i1, ptr %l84, !tbaa !21
  %t184 = xor i1 %t183, true
  %t185 = load ptr, ptr %lp4
  %t186 = getelementptr %"compiler/build:Program", ptr %t185, i32 0, i32 3
  %t187 = load ptr, ptr %l80, !tbaa !29
  %t188 = load ptr, ptr %l81, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t192 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %v3, ptr %v1, ptr %v3, ptr %s0, ptr %t187, ptr %t188, { i64, ptr } %t189, i1 %t184, ptr %t186, ptr null)
  store i32 %t192, ptr %l87
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb48, label %ok.194, !prof !99
ok.194:
  br label %bb47
bb47:
  br label %bb53
bb48:
  %t195 = load i32, ptr %l87, !tbaa !23
  %t196 = ashr i32 %t195, 16
  %t198 = icmp eq i32 %t196, 1
  store i1 %t198, ptr %l89, !tbaa !21
  br label %bb49
bb49:
  %t199 = load ptr, ptr %l3, !tbaa !29
  store ptr %t199, ptr %l90, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [3 x i64] }, ptr %t200, i32 0, i32 0
  store i64 0, ptr %t201
  %t202 = load { i64, [3 x i64] }, ptr %t200
  store { i64, [3 x i64] } %t202, ptr %l91
  %t203 = load ptr, ptr %lp6
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t206 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v1, ptr %v3, { i64, ptr } %t204)
  store %"compiler/diagmsg:Msg" %t206, ptr %l93
  br label %bb50
bb50:
  %t207 = load ptr, ptr %l90, !tbaa !29
  %t208 = load { i64, [3 x i64] }, ptr %l91
  %t209 = load %"compiler/diagmsg:Msg", ptr %l93
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v3, ptr %v3, ptr %t207, { i64, [3 x i64] } %t208, %"compiler/diagmsg:Msg" %t209)
  br label %bb51
bb51:
  %t210 = load ptr, ptr %l3, !tbaa !29
  %t212 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t210)
  store i32 %t212, ptr %l95
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t213 = load i32, ptr %l95, !tbaa !23
  store i32 %t213, ptr %rv
  br label %ret
bb53:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb54
bb54:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t215 = load ptr, ptr %lp6
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  %t219 = getelementptr %"compiler/build:Config", ptr %t214, i32 0, i32 35
  store { i64, ptr } %t216, ptr %t219, !tbaa !27
  call void @compiler_2fspin_2eEnd()
  br label %bb55
bb55:
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t222 = getelementptr %"compiler/build:Config", ptr %t220, i32 0, i32 33
  %t223 = load i1, ptr %t222, !tbaa !21
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l101, !tbaa !29
  %t228 = load ptr, ptr %l1, !tbaa !29
  %t230 = getelementptr %"compiler/build:Config", ptr %t228, i32 0, i32 34
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  %t233 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s10, { i64, ptr } %t231, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t233, ptr %l104
  br label %bb58
bb57:
  br label %bb65
bb58:
  %t234 = load i1, ptr %l104, !tbaa !21
  %t235 = xor i1 %t234, true
  br i1 %t235, label %bb59, label %bb60
bb59:
  %t237 = load ptr, ptr %lp6
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, ptr } %t238, ptr %l106, !tbaa !27
  br label %bb62
bb60:
  %t240 = load ptr, ptr %lp6
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t243 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s10, { i64, ptr } %t241)
  store { i64, ptr } %t243, ptr %l109
  br label %bb61
bb61:
  %t244 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t244, ptr %l106, !tbaa !27
  br label %bb62
bb62:
  %t245 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t247 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t245, i64 %t246)
  %t252 = getelementptr i8, ptr %t251, i64 %t246
  call void @olang_textcopy(ptr %t252, ptr %t248, i64 %t249)
  %t253 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  %t256 = load ptr, ptr %l101, !tbaa !29
  %t258 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t256, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } %t254)
  store { i64, ptr } %t258, ptr %l112
  br label %bb63
bb63:
  %t259 = load { i64, ptr }, ptr %l112, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t259)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Program"
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i32
  %l44 = alloca i1
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca i1
  %l61 = alloca { i64, ptr }
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l65 = alloca i32
  %l70 = alloca i32
  %l72 = alloca i1
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"compiler/diagmsg:Msg"
  %l80 = alloca i32
  %l90 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %v3)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t1, i64 280, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 280, i64 8)
  store ptr %t2, ptr %lp4
  %t3 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l8, i64 280, i1 false)
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t7 = load ptr, ptr %lp4
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t15 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v3, ptr %a0, { i64, ptr } %a2, i32 0, ptr %t6, ptr %t7, ptr %t8)
  store i32 %t15, ptr %l15
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb3, label %ok.17, !prof !99
ok.17:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = icmp eq i32 %t18, 65536
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l15, !tbaa !23
  %t22 = icmp eq i32 %t21, 65537
  br i1 %t22, label %bb7, label %bb8
bb6:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t24)
  store i32 %t26, ptr %l19
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_539f96ece49ac99_8ec4d6c22ed03845)
  unreachable
bb9:
  %t27 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t27, ptr %l20
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l19, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l20, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
bb12:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t30)
  store i64 %t32, ptr %l22
  br label %bb13
bb13:
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = icmp sgt i64 %t33, 0
  br i1 %t34, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t36 = load ptr, ptr %lp4
  %t37 = getelementptr %"compiler/build:Program", ptr %t36, i32 0, i32 0
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v3, ptr %t37)
  store i64 %t39, ptr %l26
  br label %bb16
bb16:
  %t40 = load i64, ptr %l26, !tbaa !24
  %t41 = icmp eq i64 %t40, 0
  store i1 %t41, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb18, label %bb19
bb18:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t44)
  store i32 %t46, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i32, ptr %l29, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t48, ptr %t49)
  store i32 %t52, ptr %l32
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb23, label %ok.54, !prof !99
ok.54:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t55 = load i32, ptr %l32, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  store i1 %t58, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t59)
  store i32 %t61, ptr %l36
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load i32, ptr %l36, !tbaa !23
  store i32 %t62, ptr %rv
  br label %ret
bb26:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load ptr, ptr %lp4
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t69 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %v3, ptr %v3, ptr %v3, ptr %t63, ptr %t64, ptr %t65)
  %t70 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t69, 1
  %t71 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t69, 0
  store i32 %t71, ptr %l42
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb28, label %ok.73, !prof !99
ok.73:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l41
  br label %bb27
bb27:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l37
  br label %bb31
bb28:
  %t75 = load i32, ptr %l42, !tbaa !23
  %t76 = ashr i32 %t75, 16
  %t78 = icmp eq i32 %t76, 1
  store i1 %t78, ptr %l44, !tbaa !21
  br label %bb29
bb29:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t79)
  store i32 %t81, ptr %l46
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t82 = load i32, ptr %l46, !tbaa !23
  store i32 %t82, ptr %rv
  br label %ret
bb31:
  %t83 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %l5
  %t85 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v3, ptr %v3, ptr %l5, i64 0)
  store { i64, ptr } %t85, ptr %l48
  br label %bb32
bb32:
  %t86 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t86, ptr %l6, !tbaa !27
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/build:Config", ptr %t87, i32 0, i32 34
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t90, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t92, ptr %l51
  br label %bb33
bb33:
  %t93 = load i1, ptr %l51, !tbaa !21
  %t94 = xor i1 %t93, true
  br i1 %t94, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t98 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v3, ptr %s6, { i64, ptr } %t96)
  %t99 = extractvalue { i32, { i64, ptr } } %t98, 1
  %t100 = extractvalue { i32, { i64, ptr } } %t98, 0
  store i32 %t100, ptr %l56
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb37, label %ok.102, !prof !99
ok.102:
  store { i64, ptr } %t99, ptr %l55
  br label %bb36
bb35:
  br label %bb54
bb36:
  %t103 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t103, ptr %l53, !tbaa !27
  br label %bb44
bb37:
  %t104 = load i32, ptr %l56, !tbaa !23
  %t105 = ashr i32 %t104, 16
  %t107 = icmp eq i32 %t105, 1
  store i1 %t107, ptr %l58, !tbaa !21
  %t108 = load i32, ptr %l56, !tbaa !23
  %t109 = ashr i32 %t108, 16
  %t111 = icmp eq i32 %t109, 1
  br i1 %t111, label %bb38, label %bb39
bb38:
  call void @__olang_errpay_pop()
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t113 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t113, ptr %l61, !tbaa !27
  %t114 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v3)
  store %"compiler/diagmsg:Msg" %t114, ptr %l62
  br label %bb41
bb41:
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t117 = load %"compiler/diagmsg:Msg", ptr %l62
  call void @compiler_2fbuild_2efileFatal(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t116, %"compiler/diagmsg:Msg" %t117, ptr %t115)
  br label %bb42
bb42:
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t121 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t119)
  store i32 %t121, ptr %l65
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t122 = load i32, ptr %l65, !tbaa !23
  store i32 %t122, ptr %rv
  br label %ret
bb44:
  %t123 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/build:Config", ptr %t124, i32 0, i32 34
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t132 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s6, { i64, ptr } %t127, { i64, ptr } %t123)
  store i32 %t132, ptr %l70
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb46, label %ok.134, !prof !99
ok.134:
  br label %bb45
bb45:
  br label %bb53
bb46:
  %t135 = load i32, ptr %l70, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  store i1 %t138, ptr %l72, !tbaa !21
  %t139 = load i32, ptr %l70, !tbaa !23
  %t140 = ashr i32 %t139, 16
  %t142 = icmp eq i32 %t140, 1
  br i1 %t142, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr %"compiler/build:Config", ptr %t144, i32 0, i32 34
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l76, !tbaa !27
  %t148 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v3)
  store %"compiler/diagmsg:Msg" %t148, ptr %l77
  br label %bb50
bb50:
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t150 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t151 = load %"compiler/diagmsg:Msg", ptr %l77
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %v3, ptr %v3, { i64, ptr } %t150, %"compiler/diagmsg:Msg" %t151, ptr %t149)
  br label %bb51
bb51:
  %t153 = load ptr, ptr %l3, !tbaa !29
  %t155 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t153)
  store i32 %t155, ptr %l80
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t156 = load i32, ptr %l80, !tbaa !23
  store i32 %t156, ptr %rv
  br label %ret
bb53:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/build:Config", ptr %t157, i32 0, i32 34
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb54:
  call void @compiler_2fspin_2eEnd()
  br label %bb55
bb55:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/build:Config", ptr %t162, i32 0, i32 33
  %t165 = load i1, ptr %t164, !tbaa !21
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t171 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t174 = extractvalue { i64, ptr } %t170, 1
  %t175 = extractvalue { i64, ptr } %t170, 0
  %t176 = add i64 %t172, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t171, i64 %t172)
  %t178 = getelementptr i8, ptr %t177, i64 %t172
  call void @olang_textcopy(ptr %t178, ptr %t174, i64 %t175)
  %t179 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t177, 1
  %t184 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s9, ptr %s9, ptr %s9, ptr %t169, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t180)
  store { i64, ptr } %t184, ptr %l90
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t185 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s9, { i64, ptr } %t185)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i32
  %l11 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca i64
  %l68 = alloca i32
  %l73 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i32
  %l95 = alloca i32
  %l97 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca { i64, [3 x i64] }
  %l102 = alloca %"compiler/diagmsg:Msg"
  %l104 = alloca i32
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  %t230 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 27
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t16 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %v4, ptr %t6, { i64, ptr } %t7, { i64, ptr } %t8, ptr %t9, ptr %t10)
  %t17 = extractvalue { i32, i32 } %t16, 1
  %t18 = extractvalue { i32, i32 } %t16, 0
  store i32 %t18, ptr %l18
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20, !prof !99
ok.20:
  store i32 %t17, ptr %l17
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t21 = load i32, ptr %l17, !tbaa !23
  store i32 %t21, ptr %l11, !tbaa !23
  br label %bb13
bb4:
  %t22 = load i32, ptr %l18, !tbaa !23
  %t23 = icmp eq i32 %t22, 65536
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t25 = load i32, ptr %l18, !tbaa !23
  %t26 = icmp eq i32 %t25, 65537
  br i1 %t26, label %bb8, label %bb9
bb7:
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t28)
  store i32 %t30, ptr %l22
  br label %bb11
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1)
  unreachable
bb10:
  %t31 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t31, ptr %l23
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i32, ptr %l22, !tbaa !23
  store i32 %t32, ptr %rv
  br label %ret
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i32, ptr %l23, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i32, ptr %l11, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
bb14:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 33
  store i1 true, ptr %t37, !tbaa !21
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = call { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %s0, ptr %v1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store { i64, ptr } %t39, ptr %l26
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = getelementptr %"compiler/build:Config", ptr %t42, i32 0, i32 0
  store { i64, ptr } %t40, ptr %t43, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v2, ptr %s0, { i64, ptr } %t44)
  %t47 = extractvalue { i32, { i64, ptr } } %t46, 1
  %t48 = extractvalue { i32, { i64, ptr } } %t46, 0
  store i32 %t48, ptr %l31
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb17, label %ok.50, !prof !99
ok.50:
  store { i64, ptr } %t47, ptr %l30
  br label %bb16
bb16:
  %t51 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t51, ptr %l28, !tbaa !27
  br label %bb21
bb17:
  %t52 = load i32, ptr %l31, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  br i1 %t55, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = extractvalue { i64, ptr } %t57, 0
  %t61 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t59, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l28, !tbaa !27
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l37
  br label %bb22
bb22:
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l6
  %t69 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t69)
  br label %bb23
bb23:
  store ptr %l6, ptr %l40, !tbaa !29
  %t72 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t73 = extractvalue { i32, { i64, ptr } } %t72, 1
  %t74 = extractvalue { i32, { i64, ptr } } %t72, 0
  store i32 %t74, ptr %l43
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb25, label %ok.76, !prof !99
ok.76:
  store { i64, ptr } %t73, ptr %l42
  br label %bb24
bb24:
  %t77 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t77, ptr %l41, !tbaa !27
  br label %bb29
bb25:
  %t78 = load i32, ptr %l43, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb29
bb29:
  %t83 = load ptr, ptr %l40, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l41, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t83, { i64, ptr } %t84)
  br label %bb30
bb30:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l46, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/build:Config", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l48, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v2, ptr %v2, { i64, ptr } %t90)
  store { i64, ptr } %t92, ptr %l50
  br label %bb31
bb31:
  %t93 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t94 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v2, ptr %s0, { i64, ptr } %t93)
  store { i64, ptr } %t94, ptr %l51
  br label %bb32
bb32:
  %t96 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t96, ptr %l53
  br label %bb33
bb33:
  %t97 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l54, !tbaa !24
  %t99 = icmp sge i64 0, 0
  br i1 %t99, label %bb34, label %bb35
bb34:
  %t101 = icmp sle i64 0, 16
  br i1 %t101, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb36:
  %t103 = load i64, ptr %l54, !tbaa !24
  %t104 = icmp sle i64 16, %t103
  br i1 %t104, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb38:
  %t106 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 0
  %t109 = sub i64 16, 0
  %t110 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  store { i64, ptr } %t111, ptr %l58, !tbaa !27
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t112)
  store { i64, ptr } %t114, ptr %l60
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb40:
  %t115 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t128 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = add i64 %t127, %t130
  %t132 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = add i64 %t131, %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t116, i64 %t117)
  %t137 = getelementptr i8, ptr %t136, i64 %t117
  call void @olang_textcopy(ptr %t137, ptr %t118, i64 %t119)
  %t138 = getelementptr i8, ptr %t137, i64 %t119
  call void @olang_textcopy(ptr %t138, ptr %t122, i64 %t123)
  %t139 = getelementptr i8, ptr %t138, i64 %t123
  call void @olang_textcopy(ptr %t139, ptr %t125, i64 %t126)
  %t140 = getelementptr i8, ptr %t139, i64 %t126
  call void @olang_textcopy(ptr %t140, ptr %t129, i64 %t130)
  %t141 = getelementptr i8, ptr %t140, i64 %t130
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t136, 1
  %t146 = load ptr, ptr %l46, !tbaa !29
  %t147 = getelementptr %"compiler/build:Config", ptr %t146, i32 0, i32 34
  store { i64, ptr } %t143, ptr %t147, !tbaa !27
  %t148 = call i64 @std_2ftime_2eNow()
  store i64 %t148, ptr %l63
  br label %bb41
bb41:
  %t149 = load i64, ptr %l63, !tbaa !24
  store i64 %t149, ptr %l7, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t158 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t150, ptr %t151, { i64, ptr } %t152, ptr %t153)
  store i32 %t158, ptr %l68
  br label %bb42
bb42:
  %t159 = load i32, ptr %l68, !tbaa !23
  store i32 %t159, ptr %l8, !tbaa !23
  %t160 = load i32, ptr %l8, !tbaa !23
  %t162 = icmp ne i32 %t160, 0
  br i1 %t162, label %bb43, label %bb44
bb43:
  %t164 = load i32, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t164, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t166 = load ptr, ptr %l4, !tbaa !29
  %t168 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %v4, ptr %s0, ptr %t166)
  store { i64, ptr } %t168, ptr %l73
  br label %bb46
bb46:
  %t169 = load { i64, ptr }, ptr %l73, !tbaa !27
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t169)
  br label %bb47
bb47:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr %"compiler/build:Config", ptr %t171, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/build:Config", ptr %t175, i32 0, i32 35
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t179 = load i64, ptr @G_2ecompiler_2fbuild_2eRunCacheCap, !tbaa !24
  call void @compiler_2fbuild_2ePrune(ptr %v1, ptr %v1, { i64, ptr } %t174, { i64, ptr } %t178, i64 %t179)
  br label %bb48
bb48:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/build:Config", ptr %t183, i32 0, i32 20
  %t186 = load i1, ptr %t185, !tbaa !21
  br i1 %t186, label %bb49, label %bb50
bb49:
  call void @compiler_2fspin_2eEnd()
  br label %bb51
bb50:
  br label %bb55
bb51:
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t188, ptr %l82, !tbaa !27
  %t189 = call i64 @std_2ftime_2eNow()
  store i64 %t189, ptr %l83
  br label %bb52
bb52:
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l83, !tbaa !24
  %t193 = sub i64 %t191, %t190
  store i64 %t193, ptr %l85, !tbaa !24
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/build:Config", ptr %t194, i32 0, i32 21
  %t197 = load i64, ptr %t196, !tbaa !24
  %t199 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t197, i64 1)
  store i64 %t199, ptr %l88
  br label %bb53
bb53:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr %"compiler/build:Config", ptr %t200, i32 0, i32 35
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t205 = load i64, ptr %l85, !tbaa !24
  %t206 = load i64, ptr %l88, !tbaa !24
  %t208 = call i32 @compiler_2fmeasure_2eMeasure(ptr %v3, ptr %v1, { i64, ptr } %t204, i64 %t205, i64 %t206, { i64, ptr } %t203)
  store i32 %t208, ptr %l91
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t209 = load i32, ptr %l91, !tbaa !23
  store i32 %t209, ptr %rv
  br label %ret
bb55:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr %"compiler/build:Config", ptr %t210, i32 0, i32 35
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t217 = call i32 @std_2fos_2eExecInPlace(ptr %v1, ptr %v3, { i64, ptr } %t213, { i64, ptr } %t214)
  store i32 %t217, ptr %l95
  %t218 = icmp ne i32 %t217, 0
  br i1 %t218, label %bb57, label %ok.219, !prof !99
ok.219:
  br label %bb56
bb56:
  br label %bb64
bb57:
  %t220 = load i32, ptr %l95, !tbaa !23
  %t221 = ashr i32 %t220, 16
  %t223 = icmp eq i32 %t221, 1
  store i1 %t223, ptr %l97, !tbaa !21
  %t224 = load i32, ptr %l95, !tbaa !23
  %t225 = ashr i32 %t224, 16
  %t227 = icmp eq i32 %t225, 1
  br i1 %t227, label %bb58, label %bb59
bb58:
  call void @__olang_errpay_pop()
  br label %bb59
bb59:
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s8
  %t229 = load ptr, ptr %l4, !tbaa !29
  store ptr %t229, ptr %l100, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t230
  %t231 = getelementptr { i64, [3 x i64] }, ptr %t230, i32 0, i32 0
  store i64 0, ptr %t231
  %t232 = load { i64, [3 x i64] }, ptr %t230
  store { i64, [3 x i64] } %t232, ptr %l101
  %t233 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s8, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t233, ptr %l102
  br label %bb61
bb61:
  %t234 = load ptr, ptr %l100, !tbaa !29
  %t235 = load { i64, [3 x i64] }, ptr %l101
  %t236 = load %"compiler/diagmsg:Msg", ptr %l102
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t234, { i64, [3 x i64] } %t235, %"compiler/diagmsg:Msg" %t236)
  br label %bb62
bb62:
  %t237 = load ptr, ptr %l4, !tbaa !29
  %t239 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t237)
  store i32 %t239, ptr %l104
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t240 = load i32, ptr %l104, !tbaa !23
  store i32 %t240, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_3e7cb8585e177347_844f5af656df9c9b)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/build:Listed" } @compiler_2fbuild_2eListed_2eListingCode_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i64
  %l31 = alloca i32
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/build:Listed"
  %l53 = alloca i32
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca i32
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/build:Listed" }
  store ptr %a1, ptr %l1
  store i1 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a2, i32 1, ptr %t3, ptr %t4, ptr %t5)
  store i32 %t12, ptr %l18
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14, !prof !99
ok.14:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t23, 0
  store { i32, %"compiler/build:Listed" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v4, ptr %t26)
  store i64 %t28, ptr %l21
  br label %bb4
bb4:
  %t29 = load i64, ptr %l21, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/build:Program", ptr %t32, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v3, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb7
bb7:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/build:Listed" } %t42, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t47 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v4, ptr %t43, ptr %t44)
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb13, label %ok.49, !prof !99
ok.49:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t50 = load i32, ptr %l31, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t58, 0
  store { i32, %"compiler/build:Listed" } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/build:Config", ptr %t61, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v3, ptr %s0, ptr %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t70 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l38
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t71)
  store { i64, ptr } %t73, ptr %l40
  br label %bb17
bb17:
  %t74 = load i1, ptr %l3, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb20
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb20
bb20:
  %t76 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t77, i64 %t78)
  %t95 = getelementptr i8, ptr %t94, i64 %t78
  call void @olang_textcopy(ptr %t95, ptr %t79, i64 %t80)
  %t96 = getelementptr i8, ptr %t95, i64 %t80
  call void @olang_textcopy(ptr %t96, ptr %t83, i64 %t84)
  %t97 = getelementptr i8, ptr %t96, i64 %t84
  call void @olang_textcopy(ptr %t97, ptr %t87, i64 %t88)
  %t98 = getelementptr i8, ptr %t97, i64 %t88
  call void @olang_textcopy(ptr %t98, ptr %t91, i64 %t92)
  %t99 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t94, 1
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t101, ptr %lp6
  %t103 = load ptr, ptr %lp6
  store { i64, ptr } %t100, ptr %t103, !tbaa !27
  %t104 = call %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v5)
  store %"compiler/build:Listed" %t104, ptr %l44
  br label %bb21
bb21:
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 64, i64 8)
  store ptr %t105, ptr %lp7
  %t106 = load %"compiler/build:Listed", ptr %l44
  %t107 = load ptr, ptr %lp7
  store %"compiler/build:Listed" %t106, ptr %t107
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/build:Config", ptr %t108, i32 0, i32 5
  %t111 = load i1, ptr %t110, !tbaa !21
  br i1 %t111, label %bb22, label %bb23
bb22:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t115 = load ptr, ptr %lp6
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = load i1, ptr %l3, !tbaa !21
  %t118 = load ptr, ptr %lp7
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t126 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %v4, ptr %t113, ptr %t114, { i64, ptr } %t116, i1 %t117, ptr %t118, ptr %t119)
  store i32 %t126, ptr %l53
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb25, label %ok.128, !prof !99
ok.128:
  br label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb26
bb25:
  %t129 = load i32, ptr %l53, !tbaa !23
  %t130 = lshr i32 %t129, 16
  %t131 = and i32 %t129, 65535
  %t132 = icmp eq i32 %t130, 1
  %t133 = select i1 %t132, i32 1, i32 0
  %t134 = icmp eq i32 %t129, 0
  %t135 = shl i32 %t133, 16
  %t136 = or i32 %t135, %t131
  %t137 = select i1 %t134, i32 0, i32 %t136
  call void @__olang_scope_close(ptr %s0)
  %t139 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t137, 0
  store { i32, %"compiler/build:Listed" } %t139, ptr %rv
  br label %ret
bb26:
  %t140 = load ptr, ptr %lp7
  %t141 = load %"compiler/build:Listed", ptr %t140
  call void @__olang_scope_close(ptr %s0)
  %t143 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, %"compiler/build:Listed" %t141, 1
  store { i32, %"compiler/build:Listed" } %t143, ptr %rv
  br label %ret
bb27:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t150 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %v3, ptr %v4, ptr %v4, ptr %t144, ptr %t145, ptr %t146)
  %t151 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t150, 1
  %t152 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t150, 0
  store i32 %t152, ptr %l61
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb29, label %ok.154, !prof !99
ok.154:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l60
  br label %bb28
bb28:
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %l56
  br label %bb30
bb29:
  %t156 = load i32, ptr %l61, !tbaa !23
  %t157 = lshr i32 %t156, 16
  %t158 = and i32 %t156, 65535
  %t159 = icmp eq i32 %t157, 1
  %t160 = select i1 %t159, i32 1, i32 0
  %t161 = icmp eq i32 %t156, 0
  %t162 = shl i32 %t160, 16
  %t163 = or i32 %t162, %t158
  %t164 = select i1 %t161, i32 0, i32 %t163
  call void @__olang_scope_close(ptr %s0)
  %t166 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t164, 0
  store { i32, %"compiler/build:Listed" } %t166, ptr %rv
  br label %ret
bb30:
  %t167 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %l8
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb31
bb31:
  store ptr %l8, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t169 = load i64, ptr %l10, !tbaa !24
  store i64 %t169, ptr %l64, !tbaa !24
  %t170 = load ptr, ptr %l9, !tbaa !29
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t170)
  store i64 %t172, ptr %l66
  br label %bb33
bb33:
  %t173 = load i64, ptr %l64, !tbaa !24
  %t174 = load i64, ptr %l66, !tbaa !24
  %t175 = icmp slt i64 %t173, %t174
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb35:
  br label %bb36
bb36:
  %t179 = load ptr, ptr %l9, !tbaa !29
  %t180 = load i64, ptr %l10, !tbaa !24
  %t183 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v4, ptr %v4, ptr %t179, i64 %t180)
  store { i64, ptr } %t183, ptr %l71
  br label %bb37
bb37:
  %t184 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t184, ptr %l11, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t187 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v4, ptr %s5, { i64, ptr } %t185)
  store { i64, ptr } %t187, ptr %l73
  br label %bb38
bb38:
  %t188 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t190 = call i1 @std_2fos_2eExists(ptr %s5, { i64, ptr } %t188)
  store i1 %t190, ptr %l75
  br label %bb39
bb39:
  %t191 = load i1, ptr %l75, !tbaa !21
  br i1 %t191, label %bb40, label %bb41
bb40:
  %t192 = load ptr, ptr %lp7
  %t193 = getelementptr %"compiler/build:Listed", ptr %t192, i32 0, i32 1
  store ptr %t193, ptr %l76, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t196 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v4, ptr %v5, { i64, ptr } %t194)
  store { i64, ptr } %t196, ptr %l78
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t197 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t198 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v5, ptr %v5, ptr %t198, { i64, ptr } %t197)
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  %t200 = load i64, ptr %l10, !tbaa !24
  %t203 = add i64 %t200, 1
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb32
bb46:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t206 = load ptr, ptr %l4, !tbaa !29
  %t207 = load ptr, ptr %lp6
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t209 = load i1, ptr %l3, !tbaa !21
  %t210 = load ptr, ptr %lp7
  %t211 = load ptr, ptr %l5, !tbaa !29
  %t219 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v1, ptr %v4, ptr %v3, ptr %v4, ptr %v5, ptr %v4, ptr %t205, ptr %l8, ptr %t206, { i64, ptr } %t208, i1 %t209, ptr %t210, ptr %t211)
  store i32 %t219, ptr %l90
  %t220 = icmp ne i32 %t219, 0
  br i1 %t220, label %bb48, label %ok.221, !prof !99
ok.221:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t222 = load i32, ptr %l90, !tbaa !23
  %t223 = lshr i32 %t222, 16
  %t224 = and i32 %t222, 65535
  %t225 = icmp eq i32 %t223, 1
  %t226 = select i1 %t225, i32 1, i32 0
  %t227 = icmp eq i32 %t222, 0
  %t228 = shl i32 %t226, 16
  %t229 = or i32 %t228, %t224
  %t230 = select i1 %t227, i32 0, i32 %t229
  call void @__olang_scope_close(ptr %s0)
  %t232 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t230, 0
  store { i32, %"compiler/build:Listed" } %t232, ptr %rv
  br label %ret
bb49:
  %t233 = load ptr, ptr %lp7
  %t234 = load %"compiler/build:Listed", ptr %t233
  call void @__olang_scope_close(ptr %s0)
  %t236 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, %"compiler/build:Listed" %t234, 1
  store { i32, %"compiler/build:Listed" } %t236, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/build:Listed" }, ptr %rv
  ret { i32, %"compiler/build:Listed" } %rr
}

define dso_local i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i32
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i32
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i64
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca i32
  %l107 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l115 = alloca { i64, ptr }
  %l123 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l163 = alloca i32
  %l165 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca { i64, [3 x i64] }
  %l170 = alloca %"compiler/diagmsg:Msg"
  %l172 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i32
  %t296 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 33
  store i1 true, ptr %t3, !tbaa !21
  %t4 = call i64 @std_2ftime_2eNow()
  store i64 %t4, ptr %l27
  br label %bb1
bb1:
  %t5 = load i64, ptr %l27, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %a0, ptr %t7, { i64, ptr } %t8, ptr %t9)
  store i32 %t14, ptr %l32
  br label %bb2
bb2:
  %t15 = load i32, ptr %l32, !tbaa !23
  store i32 %t15, ptr %l6, !tbaa !23
  call void @compiler_2fspin_2eEnd()
  br label %bb3
bb3:
  %t16 = load i32, ptr %l6, !tbaa !23
  %t18 = icmp ne i32 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t20, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t26 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v4, ptr %s0, ptr %t22, ptr %t23)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l40
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb8, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l39
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t31, ptr %l36, !tbaa !27
  br label %bb11
bb8:
  %t32 = load i32, ptr %l40, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t36)
  store i32 %t38, ptr %l44
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i32, ptr %l44, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t40, ptr %l7, !tbaa !27
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/build:Config", ptr %t41, i32 0, i32 20
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l47
  br label %bb14
bb13:
  br label %bb42
bb14:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l8
  %t48 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t48, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l11, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t62 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t62, ptr %l55, !tbaa !27
  %t63 = load i64, ptr %l10, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %t66, i64 %t63
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %s0, ptr %l8, { i64, ptr } %t68)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t73 = load i64, ptr %l10, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  store ptr %l8, ptr %l63, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t82 = icmp eq i64 %t80, 0
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t86, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l67, !tbaa !27
  br label %bb25
bb23:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/build:Config", ptr %t93, i32 0, i32 35
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t98 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s3, { i64, ptr } %t96)
  store { i64, ptr } %t98, ptr %l73
  br label %bb24
bb24:
  %t99 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t99, ptr %l67, !tbaa !27
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l63, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l67, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %s3, ptr %t101, { i64, ptr } %t102)
  br label %bb26
bb26:
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t103, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l15, !tbaa !24
  br label %bb27
bb27:
  %t109 = load i64, ptr %l14, !tbaa !24
  %t110 = load i64, ptr %l15, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t117 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t117, ptr %l82, !tbaa !27
  %t118 = load i64, ptr %l14, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %t121, i64 %t118
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %v3, ptr %l8, { i64, ptr } %t123)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t128 = load i64, ptr %l14, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l14, !tbaa !24
  br label %bb27
bb33:
  %t134 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s3, ptr %s3, ptr %l8)
  store { i64, ptr } %t134, ptr %l91
  br label %bb34
bb34:
  %t135 = call i64 @std_2ftime_2eNow()
  store i64 %t135, ptr %l92
  br label %bb35
bb35:
  %t136 = load i64, ptr %l5, !tbaa !24
  %t137 = load i64, ptr %l92, !tbaa !24
  %t139 = sub i64 %t137, %t136
  store i64 %t139, ptr %l94, !tbaa !24
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr %"compiler/build:Config", ptr %t140, i32 0, i32 21
  %t143 = load i64, ptr %t142, !tbaa !24
  %t145 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t143, i64 1)
  store i64 %t145, ptr %l97
  br label %bb36
bb36:
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t150 = icmp eq i64 %t148, 0
  br i1 %t150, label %bb37, label %bb38
bb37:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/build:Config", ptr %t152, i32 0, i32 35
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  %t157 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s3, { i64, ptr } %t155)
  store { i64, ptr } %t157, ptr %l104
  br label %bb39
bb38:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l101, !tbaa !27
  br label %bb40
bb39:
  %t158 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t158, ptr %l101, !tbaa !27
  br label %bb40
bb40:
  %t160 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t161 = load i64, ptr %l94, !tbaa !24
  %t162 = load i64, ptr %l97, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t164 = call i32 @compiler_2fmeasure_2eMeasure(ptr %s3, ptr %s3, { i64, ptr } %t160, i64 %t161, i64 %t162, { i64, ptr } %t163)
  store i32 %t164, ptr %l106
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t165 = load i32, ptr %l106, !tbaa !23
  store i32 %t165, ptr %rv
  br label %ret
bb42:
  %t166 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t166, ptr %l107
  br label %bb43
bb43:
  %t167 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l107
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %l17
  %t168 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t168, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  store i64 %t172, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  %t174 = load i64, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l20, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t182 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t182, ptr %l115, !tbaa !27
  %t183 = load i64, ptr %l19, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %t186, i64 %t183
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t188)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t193 = load i64, ptr %l19, !tbaa !24
  %t196 = add i64 %t193, 1
  store i64 %t196, ptr %l19, !tbaa !24
  br label %bb44
bb50:
  store ptr %l17, ptr %l123, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t202 = icmp eq i64 %t200, 0
  br i1 %t202, label %bb51, label %bb52
bb51:
  %t204 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = extractvalue { i64, ptr } %t204, 0
  %t208 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t206, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  store { i64, ptr } %t210, ptr %l127, !tbaa !27
  br label %bb54
bb52:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr %"compiler/build:Config", ptr %t213, i32 0, i32 35
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  %t218 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t216)
  store { i64, ptr } %t218, ptr %l133
  br label %bb53
bb53:
  %t219 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t219, ptr %l127, !tbaa !27
  br label %bb54
bb54:
  %t221 = load ptr, ptr %l123, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l127, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t221, { i64, ptr } %t222)
  br label %bb55
bb55:
  %t223 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t223, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t225 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t225, 0
  store i64 %t227, ptr %l24, !tbaa !24
  br label %bb56
bb56:
  %t229 = load i64, ptr %l23, !tbaa !24
  %t230 = load i64, ptr %l24, !tbaa !24
  %t233 = icmp slt i64 %t229, %t230
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t237 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t237, ptr %l142, !tbaa !27
  %t238 = load i64, ptr %l23, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr { i64, ptr }, ptr %t241, i64 %t238
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l17, { i64, ptr } %t243)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t248 = load i64, ptr %l23, !tbaa !24
  %t251 = add i64 %t248, 1
  store i64 %t251, ptr %l23, !tbaa !24
  br label %bb56
bb62:
  %t253 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t257 = icmp eq i64 %t255, 0
  br i1 %t257, label %bb63, label %bb64
bb63:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr %"compiler/build:Config", ptr %t259, i32 0, i32 35
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t264 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t262)
  store { i64, ptr } %t264, ptr %l156
  br label %bb65
bb64:
  %t265 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 0
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !37
  %t270 = extractvalue { i64, ptr } %t268, 1
  %t271 = extractvalue { i64, ptr } %t268, 0
  %t272 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t270, i64 %t271)
  %t273 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  store { i64, ptr } %t274, ptr %l153, !tbaa !27
  br label %bb66
bb65:
  %t277 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t277, ptr %l153, !tbaa !27
  br label %bb66
bb66:
  %t280 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l17)
  store { i64, ptr } %t280, ptr %l162
  br label %bb67
bb67:
  %t281 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t283 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s0, { i64, ptr } %t281, { i64, ptr } %t282)
  store i32 %t283, ptr %l163
  %t284 = icmp ne i32 %t283, 0
  br i1 %t284, label %bb69, label %ok.285, !prof !99
ok.285:
  br label %bb68
bb68:
  br label %bb76
bb69:
  %t286 = load i32, ptr %l163, !tbaa !23
  %t287 = ashr i32 %t286, 16
  %t289 = icmp eq i32 %t287, 1
  store i1 %t289, ptr %l165, !tbaa !21
  %t290 = load i32, ptr %l163, !tbaa !23
  %t291 = ashr i32 %t290, 16
  %t293 = icmp eq i32 %t291, 1
  br i1 %t293, label %bb70, label %bb71
bb70:
  call void @__olang_errpay_pop()
  br label %bb71
bb71:
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s19
  %t295 = load ptr, ptr %l4, !tbaa !29
  store ptr %t295, ptr %l168, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t296
  %t297 = getelementptr { i64, [3 x i64] }, ptr %t296, i32 0, i32 0
  store i64 0, ptr %t297
  %t298 = load { i64, [3 x i64] }, ptr %t296
  store { i64, [3 x i64] } %t298, ptr %l169
  %t299 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s19, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t299, ptr %l170
  br label %bb73
bb73:
  %t300 = load ptr, ptr %l168, !tbaa !29
  %t301 = load { i64, [3 x i64] }, ptr %l169
  %t302 = load %"compiler/diagmsg:Msg", ptr %l170
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t300, { i64, [3 x i64] } %t301, %"compiler/diagmsg:Msg" %t302)
  br label %bb74
bb74:
  %t303 = load ptr, ptr %l4, !tbaa !29
  %t305 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t303)
  store i32 %t305, ptr %l172
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t306 = load i32, ptr %l172, !tbaa !23
  store i32 %t306, ptr %rv
  br label %ret
bb76:
  call void @__olang_check_failed(ptr @olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/os:FileInfo"
  %l7 = alloca i1
  %lp8 = alloca ptr
  %l9 = alloca { i32, { i64, ptr } }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/build:Program"
  %l14 = alloca %"compiler/diag:Diagnostics"
  %l15 = alloca { i32, { i64, ptr } }
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/os:FileInfo"
  %l25 = alloca %"std/os:FileInfo"
  %l26 = alloca i32
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"compiler/diagmsg:Msg"
  %l50 = alloca i32
  %l52 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca %"compiler/build:Program"
  %l63 = alloca { i32, { i64, ptr } }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l72 = alloca i1
  %l74 = alloca i64
  %l79 = alloca { i64, ptr }
  %l83 = alloca %"compiler/build:Program"
  %l86 = alloca %"compiler/diag:Diagnostics"
  %l93 = alloca { i32, { i64, ptr } }
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l113 = alloca i32
  %l116 = alloca i1
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l141 = alloca i32
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l153 = alloca i32
  %l157 = alloca i32
  %l165 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  %t75 = alloca %"compiler/build:Program", align 8
  %t141 = alloca %"compiler/build:Program", align 8
  %t146 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = load i64, ptr %l22, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t3)
  %t6 = extractvalue { i32, %"std/os:FileInfo" } %t5, 1
  %t7 = extractvalue { i32, %"std/os:FileInfo" } %t5, 0
  store i32 %t7, ptr %l26
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store %"std/os:FileInfo" %t6, ptr %l25
  br label %bb2
bb2:
  %t10 = load %"std/os:FileInfo", ptr %l25
  store %"std/os:FileInfo" %t10, ptr %l23
  br label %bb9
bb3:
  %t11 = load i32, ptr %l26, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l28, !tbaa !21
  %t15 = load i32, ptr %l26, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l32, !tbaa !27
  %t22 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v3)
  store %"compiler/diagmsg:Msg" %t22, ptr %l33
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load ptr, ptr %l31, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t26 = load %"compiler/diagmsg:Msg", ptr %l33
  %t28 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t24, { i64, ptr } %t25, %"compiler/diagmsg:Msg" %t26, ptr %t23)
  store i32 %t28, ptr %l35
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l35, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
bb9:
  %t30 = load %"std/os:FileInfo", ptr %l23
  store %"std/os:FileInfo" %t30, ptr %l6
  %t31 = getelementptr %"std/os:FileInfo", ptr %l6, i32 0, i32 0
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 3}
  %t34 = trunc i64 1 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l38, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l39, !tbaa !27
  %t39 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v3)
  store %"compiler/diagmsg:Msg" %t39, ptr %l40
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t41 = load ptr, ptr %l38, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t43 = load %"compiler/diagmsg:Msg", ptr %l40
  %t45 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t41, { i64, ptr } %t42, %"compiler/diagmsg:Msg" %t43, ptr %t40)
  store i32 %t45, ptr %l42
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i32, ptr %l42, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
bb14:
  %t47 = getelementptr %"std/os:FileInfo", ptr %l6, i32 0, i32 0
  %t48 = load i32, ptr %t47, !range !{i32 0, i32 3}
  %t50 = trunc i64 0 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l46, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l47, !tbaa !27
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v3)
  store %"compiler/diagmsg:Msg" %t57, ptr %l48
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t59 = load ptr, ptr %l46, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t61 = load %"compiler/diagmsg:Msg", ptr %l48
  %t63 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t59, { i64, ptr } %t60, %"compiler/diagmsg:Msg" %t61, ptr %t58)
  store i32 %t63, ptr %l50
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load i32, ptr %l50, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = call i1 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2esplitsTests(ptr %v1, ptr %t65)
  store i1 %t67, ptr %l52
  br label %bb20
bb20:
  %t68 = load i1, ptr %l52, !tbaa !21
  store i1 %t68, ptr %l7, !tbaa !21
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l53, !tbaa !29
  %t70 = load i1, ptr %l7, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i64 1, ptr %l55, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb23
bb23:
  %t72 = load i64, ptr %l55, !tbaa !24
  %t73 = load ptr, ptr %l53, !tbaa !29
  %t74 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 29
  store i64 %t72, ptr %t74, !tbaa !24
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t75, ptr %v3)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t75, i64 280, i1 false)
  br label %bb24
bb24:
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 280, i64 8)
  store ptr %t76, ptr %lp8
  %t77 = load ptr, ptr %lp8
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %l56, i64 280, i1 false)
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t82 = load ptr, ptr %lp8
  %t83 = load i1, ptr %l7, !tbaa !21
  %t90 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestBinary_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %s0, ptr %t78, ptr %t79, { i64, ptr } %t80, ptr %t81, ptr %t82, i1 %t83)
  store { i32, { i64, ptr } } %t90, ptr %l63
  br label %bb25
bb25:
  %t91 = load { i32, { i64, ptr } }, ptr %l63
  store { i32, { i64, ptr } } %t91, ptr %l9
  %t92 = getelementptr { i32, { i64, ptr } }, ptr %l9, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  store i32 %t93, ptr %l10, !tbaa !23
  %t95 = getelementptr { i32, { i64, ptr } }, ptr %l9, i32 0, i32 1
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l65, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l66, !tbaa !24
  %t99 = load i64, ptr %l66, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l67, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l66, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t110, ptr %l11, !tbaa !27
  %t111 = load i32, ptr %l10, !tbaa !23
  %t113 = icmp sge i32 %t111, 0
  br i1 %t113, label %bb26, label %bb27
bb26:
  %t115 = load i32, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t115, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t117 = load i1, ptr %l7, !tbaa !21
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t119 = load ptr, ptr %lp8
  %t120 = getelementptr %"compiler/build:Program", ptr %t119, i32 0, i32 9
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v3, ptr %t120)
  store i64 %t122, ptr %l74
  br label %bb31
bb30:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb32
bb31:
  %t123 = load i64, ptr %l74, !tbaa !24
  %t124 = icmp sgt i64 %t123, 0
  store i1 %t124, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t126 = load i1, ptr %l72, !tbaa !21
  store i1 %t126, ptr %l7, !tbaa !21
  %t127 = load i1, ptr %l7, !tbaa !21
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb33, label %bb34
bb33:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr %"compiler/build:Config", ptr %t131, i32 0, i32 29
  store i64 0, ptr %t133, !tbaa !24
  br label %bb35
bb34:
  br label %bb35
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l79, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t134, ptr %l12, !tbaa !27
  %t136 = load i1, ptr %l7, !tbaa !21
  br i1 %t136, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/build:Config", ptr %t138, i32 0, i32 6
  store i1 true, ptr %t140, !tbaa !21
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t141, ptr %s6)
  call void @llvm.memmove.p0.p0.i64(ptr %l83, ptr %t141, i64 280, i1 false)
  br label %bb38
bb37:
  br label %bb44
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l83, i64 280, i1 false)
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/build:Config", ptr %t142, i32 0, i32 32
  %t145 = load i1, ptr %t144, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t146, ptr %s6, i1 %t145)
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t146, i64 704, i1 false)
  br label %bb39
bb39:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l86, i64 704, i1 false)
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t151 = load ptr, ptr %lp8
  %t152 = getelementptr %"compiler/build:Program", ptr %t151, i32 0, i32 9
  %t159 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eraceBinary_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %v0, ptr %v2, ptr %s6, ptr %s6, ptr %v3, ptr %s6, ptr %t148, ptr %t149, { i64, ptr } %t150, ptr %l14, ptr %l13, ptr %t152)
  store { i32, { i64, ptr } } %t159, ptr %l93
  br label %bb40
bb40:
  %t160 = load { i32, { i64, ptr } }, ptr %l93
  store { i32, { i64, ptr } } %t160, ptr %l15
  %t161 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t162 = load i32, ptr %t161, !tbaa !23
  store i32 %t162, ptr %l10, !tbaa !23
  %t164 = call ptr @__olang_region_make(ptr %s0)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l95, !tbaa !24
  %t166 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 1
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  store { i64, ptr } %t167, ptr %l96, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l97, !tbaa !24
  %t170 = load i64, ptr %l97, !tbaa !24
  %t171 = mul i64 %t170, 1
  %t172 = load i64, ptr %l95
  %t173 = inttoptr i64 %t172 to ptr
  %t174 = call ptr @__olang_held_alloc(ptr %t173, i64 %t171)
  %t175 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l98, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l97, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  %t183 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t183, ptr %l99, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t184, ptr %l12, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l99
  %t186 = extractvalue { i64, ptr } %t185, 1
  call void @__olang_region_release(ptr %t186)
  store { i64, ptr } zeroinitializer, ptr %l99
  %t187 = load i64, ptr %l95
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = load { i64, ptr }, ptr %l12
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = call ptr @__olang_region_or(ptr %t190, ptr null)
  %t192 = icmp ne ptr %t191, null
  %t193 = select i1 %t192, ptr %t191, ptr null
  call void @__olang_region_settle_in(ptr %t188, ptr %t193)
  %t194 = load i32, ptr %l10, !tbaa !23
  %t196 = icmp sge i32 %t194, 0
  br i1 %t196, label %bb41, label %bb42
bb41:
  %t198 = load i32, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t198, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb44:
  call void @compiler_2fspin_2eEnd()
  br label %bb45
bb45:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v1, ptr %v2, ptr %t200, { i64, ptr } %t201)
  br label %bb46
bb46:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t205 = load ptr, ptr %l3, !tbaa !29
  %t208 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v3, ptr %s0, ptr %t204, ptr %t205)
  %t209 = extractvalue { i32, { i64, ptr } } %t208, 1
  %t210 = extractvalue { i32, { i64, ptr } } %t208, 0
  store i32 %t210, ptr %l109
  %t211 = icmp ne i32 %t210, 0
  br i1 %t211, label %bb48, label %ok.212, !prof !99
ok.212:
  store { i64, ptr } %t209, ptr %l108
  br label %bb47
bb47:
  %t213 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t213, ptr %l105, !tbaa !27
  br label %bb51
bb48:
  %t214 = load i32, ptr %l109, !tbaa !23
  %t215 = ashr i32 %t214, 16
  %t217 = icmp eq i32 %t215, 1
  store i1 %t217, ptr %l111, !tbaa !21
  br label %bb49
bb49:
  %t218 = load ptr, ptr %l3, !tbaa !29
  %t220 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t218)
  store i32 %t220, ptr %l113
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t221 = load i32, ptr %l113, !tbaa !23
  store i32 %t221, ptr %rv
  br label %ret
bb51:
  %t222 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t222, ptr %l16, !tbaa !27
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr %"compiler/build:Config", ptr %t223, i32 0, i32 16
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t228 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t226, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t228, ptr %l116
  br label %bb52
bb52:
  %t229 = load i1, ptr %l116, !tbaa !21
  %t230 = xor i1 %t229, true
  br i1 %t230, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t232 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %l118
  br label %bb55
bb54:
  br label %bb66
bb55:
  %t233 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233, ptr %l17
  %t234 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t234, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  store i64 %t238, ptr %l20, !tbaa !24
  br label %bb56
bb56:
  %t240 = load i64, ptr %l19, !tbaa !24
  %t241 = load i64, ptr %l20, !tbaa !24
  %t244 = icmp slt i64 %t240, %t241
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t248 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t248, ptr %l126, !tbaa !27
  %t249 = load i64, ptr %l19, !tbaa !24
  %t251 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr { i64, ptr }, ptr %t252, i64 %t249
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s9, ptr %s0, ptr %l17, { i64, ptr } %t254)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t259 = load i64, ptr %l19, !tbaa !24
  %t262 = add i64 %t259, 1
  store i64 %t262, ptr %l19, !tbaa !24
  br label %bb56
bb62:
  store ptr %l17, ptr %l134, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t266 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s9, { i64, ptr } %t264)
  store { i64, ptr } %t266, ptr %l136
  br label %bb63
bb63:
  %t267 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t268 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s9, ptr %s9, ptr %t268, { i64, ptr } %t267)
  br label %bb64
bb64:
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t271 = load ptr, ptr %lp8
  %t275 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v1, ptr %s9, ptr %v3, ptr %t270, ptr %l17, ptr %t271)
  store i32 %t275, ptr %l141
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t276 = load i32, ptr %l141, !tbaa !23
  store i32 %t276, ptr %rv
  br label %ret
bb66:
  %t277 = load i1, ptr %l7, !tbaa !21
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s13
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l144, !tbaa !29
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l145, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t283, ptr %l146, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t284, ptr %l147, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t285, ptr %l148, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t286, ptr %l149, !tbaa !27
  %t287 = call i64 @std_2ftime_2eNow()
  store i64 %t287, ptr %l150
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t288 = load i64, ptr %l5, !tbaa !24
  %t289 = load i64, ptr %l150, !tbaa !24
  %t291 = sub i64 %t289, %t288
  %t292 = load ptr, ptr %l145, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t294 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t298 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v4, ptr %s13, ptr %t292, { i64, ptr } %t293, { i64, ptr } %t294, { i64, ptr } %t295, { i64, ptr } %t296, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, i64 %t291)
  store i32 %t298, ptr %l153
  br label %bb70
bb70:
  %t299 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t301 = load ptr, ptr %lp8
  %t302 = getelementptr %"compiler/build:Program", ptr %t301, i32 0, i32 8
  %t303 = load ptr, ptr %l144, !tbaa !29
  %t304 = load i32, ptr %l153, !tbaa !23
  %t308 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestsEnded(ptr %v1, ptr %v2, ptr %v4, ptr %v3, ptr %t303, i32 %t304, { i64, ptr } %t299, { i64, ptr } %t300, ptr %t302)
  store i32 %t308, ptr %l157
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load i32, ptr %l157, !tbaa !23
  store i32 %t309, ptr %rv
  br label %ret
bb72:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t311 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t313 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t316 = load ptr, ptr %lp8
  %t317 = getelementptr %"compiler/build:Program", ptr %t316, i32 0, i32 8
  %t325 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunParts(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %v2, ptr %v4, ptr %v3, ptr %t310, { i64, ptr } %t311, { i64, ptr } %t312, { i64, ptr } %t313, { i64, ptr } %t314, { i64, ptr } %t315, ptr %t317)
  store i32 %t325, ptr %l165
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t326 = load i32, ptr %l165, !tbaa !23
  store i32 %t326, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestBinary_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp7 = alloca ptr
  %l15 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i32, { i64, ptr } }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i32, { i64, ptr } }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l38 = alloca i1
  %l41 = alloca i64
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i32, { i64, ptr } }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i32, { i64, ptr } }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l73 = alloca i32
  %l75 = alloca i1
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i32, { i64, ptr } }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca i32
  %l91 = alloca i1
  %l93 = alloca i32
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i32, { i64, ptr } }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l117 = alloca i1
  %l121 = alloca i32
  %l123 = alloca i1
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l132 = alloca { i32, { i64, ptr } }
  %l133 = alloca { i64, ptr }
  %l134 = alloca i64
  %l135 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 15
  store i1 true, ptr %t3, !tbaa !21
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t15 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v1, ptr %v2, ptr %v0, ptr %v4, ptr %v3, ptr %a1, { i64, ptr } %t5, i32 2, ptr %t6, ptr %t7, ptr %t8)
  store i32 %t15, ptr %l15
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb2, label %ok.17, !prof !99
ok.17:
  br label %bb1
bb1:
  br label %bb11
bb2:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = icmp eq i32 %t18, 65536
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t21 = load i32, ptr %l15, !tbaa !23
  %t22 = icmp eq i32 %t21, 65537
  br i1 %t22, label %bb6, label %bb7
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v2, ptr %v3, ptr %t24, { i64, ptr } %t25, ptr %t26)
  store i32 %t30, ptr %l21
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d427f69e0d58601c_ef1499a0f9cee590)
  unreachable
bb8:
  %t31 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t31, ptr %l28
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = load i32, ptr %l21, !tbaa !23
  %t34 = insertvalue { i32, { i64, ptr } } undef, i32 %t33, 0
  %t36 = insertvalue { i32, { i64, ptr } } %t34, { i64, ptr } %t32, 1
  store { i32, { i64, ptr } } %t36, ptr %l24
  %t37 = getelementptr { i32, { i64, ptr } }, ptr %l24, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l25, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l26, !tbaa !24
  %t41 = load i64, ptr %l26, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t53 = getelementptr { i32, { i64, ptr } }, ptr %l24, i32 0, i32 1
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i32, { i64, ptr } }, ptr %l24
  store { i32, { i64, ptr } } %t54, ptr %rv
  br label %ret
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t56 = load i32, ptr %l28, !tbaa !23
  %t57 = insertvalue { i32, { i64, ptr } } undef, i32 %t56, 0
  %t59 = insertvalue { i32, { i64, ptr } } %t57, { i64, ptr } %t55, 1
  store { i32, { i64, ptr } } %t59, ptr %l31
  %t60 = getelementptr { i32, { i64, ptr } }, ptr %l31, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l33, !tbaa !24
  %t64 = load i64, ptr %l33, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l34, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l33, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t76 = getelementptr { i32, { i64, ptr } }, ptr %l31, i32 0, i32 1
  store { i64, ptr } %t75, ptr %t76, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t77 = load { i32, { i64, ptr } }, ptr %l31
  store { i32, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb11:
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t78)
  store i64 %t80, ptr %l36
  br label %bb12
bb12:
  %t81 = load i64, ptr %l36, !tbaa !24
  %t82 = icmp sgt i64 %t81, 0
  br i1 %t82, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb16
bb14:
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/build:Program", ptr %t84, i32 0, i32 0
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t86)
  store i64 %t88, ptr %l41
  br label %bb15
bb15:
  %t89 = load i64, ptr %l41, !tbaa !24
  %t90 = icmp eq i64 %t89, 0
  store i1 %t90, ptr %l38, !tbaa !21
  br label %bb16
bb16:
  %t92 = load i1, ptr %l38, !tbaa !21
  br i1 %t92, label %bb17, label %bb18
bb17:
  %t93 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2eUnspill(ptr %v4, ptr %t93)
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t101 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v2, ptr %v3, ptr %t95, { i64, ptr } %t96, ptr %t97)
  store i32 %t101, ptr %l47
  br label %bb20
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t103 = load i32, ptr %l47, !tbaa !23
  %t104 = insertvalue { i32, { i64, ptr } } undef, i32 %t103, 0
  %t106 = insertvalue { i32, { i64, ptr } } %t104, { i64, ptr } %t102, 1
  store { i32, { i64, ptr } } %t106, ptr %l50
  %t107 = getelementptr { i32, { i64, ptr } }, ptr %l50, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l51, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l52, !tbaa !24
  %t112 = mul i64 %t111, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l53, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l52, !tbaa !24
  %t121 = mul i64 %t120, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t117, ptr %t119, i64 %t121, i1 false)
  %t122 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t123 = getelementptr { i32, { i64, ptr } }, ptr %l50, i32 0, i32 1
  store { i64, ptr } %t122, ptr %t123, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t124 = load { i32, { i64, ptr } }, ptr %l50
  store { i32, { i64, ptr } } %t124, ptr %rv
  br label %ret
bb21:
  br i1 %a5, label %bb22, label %bb23
bb22:
  %t127 = load ptr, ptr %l4, !tbaa !29
  %t129 = getelementptr %"compiler/build:Program", ptr %t127, i32 0, i32 10
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = icmp eq i64 %t130, 0
  store i1 %t132, ptr %l55, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t134 = load i1, ptr %l55, !tbaa !21
  br i1 %t134, label %bb25, label %bb26
bb25:
  %t135 = load ptr, ptr %l4, !tbaa !29
  %t137 = getelementptr %"compiler/build:Program", ptr %t135, i32 0, i32 9
  %t139 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t137)
  store i64 %t139, ptr %l62
  br label %bb27
bb26:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb28
bb27:
  %t140 = load i64, ptr %l62, !tbaa !24
  %t141 = icmp sgt i64 %t140, 0
  store i1 %t141, ptr %l59, !tbaa !21
  br label %bb28
bb28:
  %t143 = load i1, ptr %l59, !tbaa !21
  br i1 %t143, label %bb29, label %bb30
bb29:
  %t144 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2eUnspill(ptr %v4, ptr %t144)
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l65, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t147 = insertvalue { i32, { i64, ptr } } undef, i32 -2, 0
  %t149 = insertvalue { i32, { i64, ptr } } %t147, { i64, ptr } %t146, 1
  store { i32, { i64, ptr } } %t149, ptr %l67
  %t150 = getelementptr { i32, { i64, ptr } }, ptr %l67, i32 0, i32 1
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  store { i64, ptr } %t151, ptr %l68, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  store i64 %t153, ptr %l69, !tbaa !24
  %t154 = load i64, ptr %l69, !tbaa !24
  %t155 = mul i64 %t154, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t155)
  %t157 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l70, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = load i64, ptr %l69, !tbaa !24
  %t164 = mul i64 %t163, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t160, ptr %t162, i64 %t164, i1 false)
  %t165 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t166 = getelementptr { i32, { i64, ptr } }, ptr %l67, i32 0, i32 1
  store { i64, ptr } %t165, ptr %t166, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t167 = load { i32, { i64, ptr } }, ptr %l67
  store { i32, { i64, ptr } } %t167, ptr %rv
  br label %ret
bb32:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l3, !tbaa !29
  %t172 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v3, ptr %t168, ptr %t169)
  store i32 %t172, ptr %l73
  %t173 = icmp ne i32 %t172, 0
  br i1 %t173, label %bb34, label %ok.174, !prof !99
ok.174:
  br label %bb33
bb33:
  br label %bb37
bb34:
  %t175 = load i32, ptr %l73, !tbaa !23
  %t176 = ashr i32 %t175, 16
  %t178 = icmp eq i32 %t176, 1
  store i1 %t178, ptr %l75, !tbaa !21
  br label %bb35
bb35:
  %t179 = load ptr, ptr %l3, !tbaa !29
  %t181 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t179)
  store i32 %t181, ptr %l77
  br label %bb36
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l78, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t183 = load i32, ptr %l77, !tbaa !23
  %t184 = insertvalue { i32, { i64, ptr } } undef, i32 %t183, 0
  %t186 = insertvalue { i32, { i64, ptr } } %t184, { i64, ptr } %t182, 1
  store { i32, { i64, ptr } } %t186, ptr %l80
  %t187 = getelementptr { i32, { i64, ptr } }, ptr %l80, i32 0, i32 1
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l81, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l82, !tbaa !24
  %t191 = load i64, ptr %l82, !tbaa !24
  %t192 = mul i64 %t191, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l83, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l82, !tbaa !24
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  %t202 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t203 = getelementptr { i32, { i64, ptr } }, ptr %l80, i32 0, i32 1
  store { i64, ptr } %t202, ptr %t203, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t204 = load { i32, { i64, ptr } }, ptr %l80
  store { i32, { i64, ptr } } %t204, ptr %rv
  br label %ret
bb37:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l4, !tbaa !29
  %t207 = load ptr, ptr %l3, !tbaa !29
  %t211 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v4, ptr %v3, ptr %v3, ptr %t205, ptr %t206, ptr %t207)
  %t212 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t211, 1
  %t213 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t211, 0
  store i32 %t213, ptr %l89
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb39, label %ok.215, !prof !99
ok.215:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %l88
  br label %bb38
bb38:
  %t216 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t216, ptr %l84
  br label %bb42
bb39:
  %t217 = load i32, ptr %l89, !tbaa !23
  %t218 = ashr i32 %t217, 16
  %t220 = icmp eq i32 %t218, 1
  store i1 %t220, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t221 = load ptr, ptr %l3, !tbaa !29
  %t223 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t221)
  store i32 %t223, ptr %l93
  br label %bb41
bb41:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t225 = load i32, ptr %l93, !tbaa !23
  %t226 = insertvalue { i32, { i64, ptr } } undef, i32 %t225, 0
  %t228 = insertvalue { i32, { i64, ptr } } %t226, { i64, ptr } %t224, 1
  store { i32, { i64, ptr } } %t228, ptr %l96
  %t229 = getelementptr { i32, { i64, ptr } }, ptr %l96, i32 0, i32 1
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  store { i64, ptr } %t230, ptr %l97, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l98, !tbaa !24
  %t233 = load i64, ptr %l98, !tbaa !24
  %t234 = mul i64 %t233, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t234)
  %t236 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  store { i64, ptr } %t237, ptr %l99, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = load i64, ptr %l98, !tbaa !24
  %t243 = mul i64 %t242, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t239, ptr %t241, i64 %t243, i1 false)
  %t244 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t245 = getelementptr { i32, { i64, ptr } }, ptr %l96, i32 0, i32 1
  store { i64, ptr } %t244, ptr %t245, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t246 = load { i32, { i64, ptr } }, ptr %l96
  store { i32, { i64, ptr } } %t246, ptr %rv
  br label %ret
bb42:
  %t247 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t247, ptr %l6
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb43
bb43:
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l100, !tbaa !29
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/build:Config", ptr %t249, i32 0, i32 0
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !27
  store { i64, ptr } %t252, ptr %l102, !tbaa !27
  %t253 = load ptr, ptr %l4, !tbaa !29
  %t255 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v4, ptr %s0, ptr %t253)
  store { i64, ptr } %t255, ptr %l104
  br label %bb44
bb44:
  %t256 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t258 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t256)
  store { i64, ptr } %t258, ptr %l106
  br label %bb45
bb45:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t259)
  store { i64, ptr } %t261, ptr %l108
  br label %bb46
bb46:
  %t262 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t267 = add i64 %t264, %t266
  %t268 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = add i64 %t267, %t270
  %t272 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t274 = add i64 %t271, %t273
  %t275 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = add i64 %t274, %t277
  %t279 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t278)
  call void @olang_textcopy(ptr %t279, ptr %t263, i64 %t264)
  %t280 = getelementptr i8, ptr %t279, i64 %t264
  call void @olang_textcopy(ptr %t280, ptr %t265, i64 %t266)
  %t281 = getelementptr i8, ptr %t280, i64 %t266
  call void @olang_textcopy(ptr %t281, ptr %t269, i64 %t270)
  %t282 = getelementptr i8, ptr %t281, i64 %t270
  call void @olang_textcopy(ptr %t282, ptr %t272, i64 %t273)
  %t283 = getelementptr i8, ptr %t282, i64 %t273
  call void @olang_textcopy(ptr %t283, ptr %t276, i64 %t277)
  %t284 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t279, 1
  %t287 = load ptr, ptr %l100, !tbaa !29
  %t289 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eexe(ptr %v0, ptr %s0, ptr %v5, ptr %t287, { i64, ptr } %t285)
  store { i64, ptr } %t289, ptr %l111
  br label %bb47
bb47:
  %t290 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 16, i64 8)
  store ptr %t290, ptr %lp7
  %t291 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t292 = load ptr, ptr %lp7
  store { i64, ptr } %t291, ptr %t292, !tbaa !27
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l112, !tbaa !29
  store ptr %l6, ptr %l113, !tbaa !29
  %t294 = load ptr, ptr %lp7
  %t295 = load { i64, ptr }, ptr %t294, !tbaa !27
  store { i64, ptr } %t295, ptr %l114, !tbaa !27
  %t296 = load ptr, ptr %l4, !tbaa !29
  %t298 = getelementptr %"compiler/build:Program", ptr %t296, i32 0, i32 2
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  %t301 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t299, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t301, ptr %l117
  br label %bb48
bb48:
  %t302 = load i1, ptr %l117, !tbaa !21
  %t303 = xor i1 %t302, true
  %t304 = load ptr, ptr %l4, !tbaa !29
  %t306 = getelementptr %"compiler/build:Program", ptr %t304, i32 0, i32 3
  %t307 = load ptr, ptr %l112, !tbaa !29
  %t308 = load ptr, ptr %l113, !tbaa !29
  %t309 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t312 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v3, ptr %v5, ptr %v4, ptr %s0, ptr %t307, ptr %t308, { i64, ptr } %t309, i1 %t303, ptr %t306, ptr null)
  store i32 %t312, ptr %l121
  %t313 = icmp ne i32 %t312, 0
  br i1 %t313, label %bb50, label %ok.314, !prof !99
ok.314:
  br label %bb49
bb49:
  br label %bb54
bb50:
  %t315 = load i32, ptr %l121, !tbaa !23
  %t316 = ashr i32 %t315, 16
  %t318 = icmp eq i32 %t316, 1
  store i1 %t318, ptr %l123, !tbaa !21
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 1
  %t323 = extractvalue { i64, ptr } %t320, 0
  %t324 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t326 = add i64 %t323, %t325
  %t327 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t326)
  call void @olang_textcopy(ptr %t327, ptr %t322, i64 %t323)
  %t328 = getelementptr i8, ptr %t327, i64 %t323
  call void @olang_textcopy(ptr %t328, ptr %t324, i64 %t325)
  %t329 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t327, 1
  %t334 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s8, ptr %s8, ptr %s8, ptr %t319, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, { i64, ptr } %t330)
  store { i64, ptr } %t334, ptr %l128
  br label %bb52
bb52:
  %t335 = load { i64, ptr }, ptr %l128, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s8, { i64, ptr } %t335)
  br label %bb53
bb53:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l130, !tbaa !27
  %t337 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t338 = insertvalue { i32, { i64, ptr } } undef, i32 1, 0
  %t340 = insertvalue { i32, { i64, ptr } } %t338, { i64, ptr } %t337, 1
  store { i32, { i64, ptr } } %t340, ptr %l132
  %t341 = getelementptr { i32, { i64, ptr } }, ptr %l132, i32 0, i32 1
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !27
  store { i64, ptr } %t342, ptr %l133, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  store i64 %t344, ptr %l134, !tbaa !24
  %t345 = load i64, ptr %l134, !tbaa !24
  %t346 = mul i64 %t345, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t346)
  %t348 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  store { i64, ptr } %t349, ptr %l135, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = load i64, ptr %l134, !tbaa !24
  %t355 = mul i64 %t354, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t351, ptr %t353, i64 %t355, i1 false)
  %t356 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t357 = getelementptr { i32, { i64, ptr } }, ptr %l132, i32 0, i32 1
  store { i64, ptr } %t356, ptr %t357, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t358 = load { i32, { i64, ptr } }, ptr %l132
  store { i32, { i64, ptr } } %t358, ptr %rv
  br label %ret
bb54:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb55
bb55:
  %t359 = load ptr, ptr %lp7
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  %t361 = insertvalue { i32, { i64, ptr } } undef, i32 -1, 0
  %t363 = insertvalue { i32, { i64, ptr } } %t361, { i64, ptr } %t360, 1
  call void @__olang_scope_close(ptr %s0)
  store { i32, { i64, ptr } } %t363, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2folang_2erunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca %"compiler/build:Config"
  %l4 = alloca %"compiler/olang:CommandLine"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %lp9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/diag:Diagnostics"
  %l16 = alloca %"compiler/build:Config"
  %l18 = alloca %"compiler/olang:CommandLine"
  %l22 = alloca %"compiler/olang:CommandLine"
  %l23 = alloca i32
  %l25 = alloca i1
  %l27 = alloca i32
  %l31 = alloca i1
  %l35 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca i1
  %l48 = alloca i32
  %l50 = alloca i32
  %l52 = alloca i1
  %l56 = alloca { i64, ptr }
  %l58 = alloca i1
  %l60 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca i32
  %l79 = alloca i1
  %l81 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca i1
  %l91 = alloca i32
  %l96 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l104 = alloca i32
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l113 = alloca i32
  %l115 = alloca i32
  %l120 = alloca i32
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l128 = alloca i1
  %l131 = alloca { i64, ptr }
  %l135 = alloca i1
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca i32
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l150 = alloca i32
  %l155 = alloca { i64, ptr }
  %l159 = alloca i32
  %l164 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l170 = alloca i32
  %l175 = alloca i32
  %l179 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca i32
  %l184 = alloca i1
  %l187 = alloca { i64, ptr }
  %l191 = alloca i32
  %l193 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l203 = alloca i32
  %l209 = alloca { i64, ptr }
  %l212 = alloca i32
  %l218 = alloca { i64, ptr }
  %l221 = alloca i32
  %l225 = alloca ptr
  %l226 = alloca ptr
  %l227 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l232 = alloca i32
  %l236 = alloca ptr
  %l237 = alloca ptr
  %l238 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l243 = alloca i32
  %l246 = alloca i32
  %l250 = alloca i1
  %l252 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l254 = alloca i32
  %l256 = alloca i1
  %l259 = alloca { i64, ptr }
  %l264 = alloca i32
  %l269 = alloca { i64, ptr }
  %l271 = alloca i32
  %l275 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l277 = alloca { i64, ptr }
  %l282 = alloca i64
  %l284 = alloca i64
  %l289 = alloca { i64, ptr }
  %l295 = alloca ptr
  %l296 = alloca ptr
  %l297 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l302 = alloca i32
  %l306 = alloca i1
  %l308 = alloca ptr
  %l309 = alloca ptr
  %l310 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l312 = alloca ptr
  %l314 = alloca { i64, ptr }
  %l315 = alloca i32
  %l319 = alloca ptr
  %l320 = alloca ptr
  %l321 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l323 = alloca ptr
  %l325 = alloca { i64, ptr }
  %l326 = alloca i32
  %l327 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l329 = alloca i32
  %l331 = alloca i1
  %l334 = alloca { i64, ptr }
  %l338 = alloca ptr
  %l339 = alloca { i64, ptr }
  %l341 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %l344 = alloca { i64, ptr }
  %l345 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t4 = alloca %"compiler/build:Config", align 8
  %t10 = alloca %"compiler/olang:CommandLine", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l14
  br label %bb1
bb1:
  %t3 = load i1, ptr %l14, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t2, i64 704, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l15, i64 704, i1 false)
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t4, i64 720, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l16, i64 720, i1 false)
  %t5 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 32
  store i1 %t6, ptr %t8, !tbaa !21
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i32 @compiler_2folang_2eCommandLine_2ePrepare(ptr %t10, ptr %v0, ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t9, ptr %l3, ptr %l2)
  store i32 %t14, ptr %l23
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t10, i64 248, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l22, i64 248, i1 false)
  br label %bb8
bb5:
  %t17 = load i32, ptr %l23, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t22 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t22, ptr %l27
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l27, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l18, i64 248, i1 false)
  %t24 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t29 = icmp eq i64 %t25, %t26
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb11
bb10:
  %t31 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t36 = icmp eq i64 %t32, %t33
  store i1 %t36, ptr %l31, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l31, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb14
bb13:
  %t39 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 16
  %t40 = load i1, ptr %t39, !tbaa !21
  store i1 %t40, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l35, !tbaa !21
  %t43 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 25
  store i1 %t42, ptr %t43, !tbaa !21
  %t44 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t49 = icmp eq i64 %t45, %t46
  br i1 %t49, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = call { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %s0, ptr %s2, ptr %l4, ptr %l2)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l44
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb18, label %ok.57, !prof !99
ok.57:
  store { i64, ptr } %t54, ptr %l43
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t58 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t58, ptr %l40, !tbaa !27
  br label %bb21
bb18:
  %t59 = load i32, ptr %l44, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  store i1 %t62, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t64 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t64, ptr %l48
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
bb21:
  %t66 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t69 = call i32 @compiler_2folang_2ewrite(ptr %s2, { i64, ptr } %t66)
  store i32 %t69, ptr %l50
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load i32, ptr %l50, !tbaa !23
  store i32 %t70, ptr %rv
  br label %ret
bb23:
  %t72 = call i1 @compiler_2folang_2ewaits(ptr %v0, ptr %l4)
  store i1 %t72, ptr %l52
  br label %bb24
bb24:
  %t73 = load i1, ptr %l52, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t74 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t79 = icmp eq i64 %t75, %t76
  br i1 %t79, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l56, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l56, !tbaa !27
  br label %bb29
bb29:
  %t81 = load { i64, ptr }, ptr %l56, !tbaa !27
  call void @compiler_2fspin_2eBegin(ptr %s4, { i64, ptr } %t81)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  %t83 = call i1 @compiler_2folang_2eanalyzes(ptr %v0, ptr %l4)
  store i1 %t83, ptr %l58
  br label %bb32
bb32:
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t85 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l60
  br label %bb35
bb34:
  br label %bb41
bb35:
  %t88 = load i64, ptr %l60, !tbaa !24
  %t89 = icmp sgt i64 %t88, 0
  br i1 %t89, label %bb36, label %bb37
bb36:
  %t91 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t93 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %s5, ptr %t91, i64 0)
  store { i64, ptr } %t93, ptr %l64
  br label %bb38
bb37:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb39
bb38:
  %t94 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t94, ptr %l62, !tbaa !27
  br label %bb39
bb39:
  %t95 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t96 = call { i64, ptr } @compiler_2fbuild_2eAnalysisDir(ptr %s5, ptr %s0, { i64, ptr } %t95)
  store { i64, ptr } %t96, ptr %l65
  br label %bb40
bb40:
  %t97 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t99 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 0
  store { i64, ptr } %t97, ptr %t99, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb41:
  %t100 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  br i1 %t105, label %bb42, label %bb43
bb42:
  %t107 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 11
  %t108 = load i1, ptr %t107, !tbaa !21
  store i1 %t108, ptr %l70, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb44
bb44:
  %t110 = load i1, ptr %l70, !tbaa !21
  br i1 %t110, label %bb45, label %bb46
bb45:
  %t111 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t113 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t111, i64 0)
  store { i64, ptr } %t113, ptr %l73
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t114 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t116 = call i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %s0, { i64, ptr } %t114, ptr %l3)
  store i32 %t116, ptr %l75
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t117 = load i32, ptr %l75, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb49:
  %t118 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t123 = icmp eq i64 %t119, %t120
  br i1 %t123, label %bb50, label %bb51
bb50:
  %t125 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 12
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t126, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t128, ptr %l81
  br label %bb52
bb51:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb53
bb52:
  %t129 = load i1, ptr %l81, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l79, !tbaa !21
  br label %bb53
bb53:
  %t132 = load i1, ptr %l79, !tbaa !21
  br i1 %t132, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s7
  %t133 = load ptr, ptr %l1, !tbaa !29
  store ptr %t133, ptr %l83, !tbaa !29
  store ptr %l3, ptr %l84, !tbaa !29
  %t134 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t136 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t134, i64 0)
  store { i64, ptr } %t136, ptr %l86
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t137 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l87, !tbaa !27
  %t139 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 12
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  %t142 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t140, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t142, ptr %l89
  br label %bb57
bb57:
  %t143 = load ptr, ptr %l83, !tbaa !29
  %t144 = load ptr, ptr %l84, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t147 = load i1, ptr %l89, !tbaa !21
  %t149 = call i32 @compiler_2flisting_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t143, ptr %t144, { i64, ptr } %t145, { i64, ptr } %t146, i1 %t147, ptr %l2)
  store i32 %t149, ptr %l91
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t150 = load i32, ptr %l91, !tbaa !23
  store i32 %t150, ptr %rv
  br label %ret
bb59:
  %t151 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t156 = icmp eq i64 %t152, %t153
  br i1 %t156, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s8
  %t158 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %t158)
  store i64 %t160, ptr %l96
  br label %bb62
bb61:
  br label %bb74
bb62:
  %t161 = load i64, ptr %l96, !tbaa !24
  %t162 = icmp eq i64 %t161, 1
  br i1 %t162, label %bb63, label %bb64
bb63:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l98, !tbaa !29
  store ptr %l3, ptr %l99, !tbaa !29
  %t165 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t167 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t165, i64 0)
  store { i64, ptr } %t167, ptr %l101
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t168 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  %t170 = load ptr, ptr %l98, !tbaa !29
  %t171 = load ptr, ptr %l99, !tbaa !29
  %t172 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t175 = call i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t170, ptr %t171, { i64, ptr } %t172, { i64, ptr } %t169, ptr %l2)
  store i32 %t175, ptr %l104
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t176 = load i32, ptr %l104, !tbaa !23
  store i32 %t176, ptr %rv
  br label %ret
bb67:
  %t177 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t181 = call { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %s0, ptr %s8, { i64, ptr } %t178, ptr %l2)
  %t182 = extractvalue { i32, { i64, ptr } } %t181, 1
  %t183 = extractvalue { i32, { i64, ptr } } %t181, 0
  store i32 %t183, ptr %l109
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb69, label %ok.185, !prof !99
ok.185:
  store { i64, ptr } %t182, ptr %l108
  br label %bb68
bb68:
  %t186 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t186, ptr %l105, !tbaa !27
  br label %bb72
bb69:
  %t187 = load i32, ptr %l109, !tbaa !23
  %t188 = ashr i32 %t187, 16
  %t190 = icmp eq i32 %t188, 1
  store i1 %t190, ptr %l111, !tbaa !21
  br label %bb70
bb70:
  %t192 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t192, ptr %l113
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t193 = load i32, ptr %l113, !tbaa !23
  store i32 %t193, ptr %rv
  br label %ret
bb72:
  %t194 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t197 = call i32 @compiler_2folang_2ewrite(ptr %s8, { i64, ptr } %t194)
  store i32 %t197, ptr %l115
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t198 = load i32, ptr %l115, !tbaa !23
  store i32 %t198, ptr %rv
  br label %ret
bb74:
  %t199 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t200 = load i64, ptr %t199, !tbaa !24
  %t201 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t204 = icmp eq i64 %t200, %t201
  br i1 %t204, label %bb75, label %bb76
bb75:
  %t207 = call i32 @compiler_2folang_2eformat(ptr %v0, ptr %l4)
  store i32 %t207, ptr %l120
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t208 = load i32, ptr %l120, !tbaa !23
  store i32 %t208, ptr %rv
  br label %ret
bb78:
  %t209 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t210 = load i64, ptr %t209, !tbaa !24
  %t211 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t214 = icmp eq i64 %t210, %t211
  br i1 %t214, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s12
  %t216 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s12, ptr %s12, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d44, i32 0, i32 1) })
  %t217 = extractvalue { i32, { i64, ptr } } %t216, 1
  %t218 = extractvalue { i32, { i64, ptr } } %t216, 0
  store i32 %t218, ptr %l126
  %t219 = icmp ne i32 %t218, 0
  br i1 %t219, label %bb82, label %ok.220, !prof !99
ok.220:
  store { i64, ptr } %t217, ptr %l125
  br label %bb81
bb80:
  br label %bb90
bb81:
  %t221 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t221, ptr %l124, !tbaa !27
  br label %bb86
bb82:
  %t222 = load i32, ptr %l126, !tbaa !23
  %t223 = ashr i32 %t222, 16
  %t225 = icmp eq i32 %t223, 1
  store i1 %t225, ptr %l128, !tbaa !21
  %t226 = load i32, ptr %l126, !tbaa !23
  %t227 = ashr i32 %t226, 16
  %t229 = icmp eq i32 %t227, 1
  br i1 %t229, label %bb83, label %bb84
bb83:
  call void @__olang_errpay_pop()
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t231 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t231, ptr %l131, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %t233, i64 0
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !37
  %t237 = extractvalue { i64, ptr } %t235, 1
  %t238 = extractvalue { i64, ptr } %t235, 0
  %t239 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t237, i64 %t238)
  %t240 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  store { i64, ptr } %t241, ptr %l124, !tbaa !27
  br label %bb86
bb86:
  %t244 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t244, ptr %l7, !tbaa !27
  %t245 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 9
  %t246 = load i1, ptr %t245, !tbaa !21
  store i1 %t246, ptr %l135, !tbaa !21
  %t247 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t249 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t247)
  store { i64, ptr } %t249, ptr %l137
  br label %bb87
bb87:
  %t250 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t250, ptr %l138, !tbaa !27
  %t251 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s12)
  store { i64, ptr } %t251, ptr %l139
  br label %bb88
bb88:
  %t252 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t253 = load i1, ptr %l135, !tbaa !21
  %t254 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t257 = call i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %s12, ptr %s12, i1 %t253, { i64, ptr } %t254, { i64, ptr } %t255, { i64, ptr } %t252)
  store i32 %t257, ptr %l141
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t258 = load i32, ptr %l141, !tbaa !23
  store i32 %t258, ptr %rv
  br label %ret
bb90:
  %t259 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t260 = load i64, ptr %t259, !tbaa !24
  %t261 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t264 = icmp eq i64 %t260, %t261
  br i1 %t264, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s14
  %t266 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t268 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t266, i64 0)
  store { i64, ptr } %t268, ptr %l146
  br label %bb93
bb92:
  br label %bb96
bb93:
  %t269 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  store { i64, ptr } %t270, ptr %l147, !tbaa !27
  %t271 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s14)
  store { i64, ptr } %t271, ptr %l148
  br label %bb94
bb94:
  %t272 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t276 = call i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v0, ptr %s14, { i64, ptr } %t273, { i64, ptr } %t274, { i64, ptr } %t272)
  store i32 %t276, ptr %l150
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t277 = load i32, ptr %l150, !tbaa !23
  store i32 %t277, ptr %rv
  br label %ret
bb96:
  %t278 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t279 = load i64, ptr %t278, !tbaa !24
  %t280 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t283 = icmp eq i64 %t279, %t280
  br i1 %t283, label %bb97, label %bb98
bb97:
  %t285 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t287 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t285)
  store { i64, ptr } %t287, ptr %l155
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t288 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !27
  %t290 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 10
  %t291 = load { i64, ptr }, ptr %t290, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t296 = call i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t292, { i64, ptr } %t289, { i64, ptr } %t291, ptr %l3)
  store i32 %t296, ptr %l159
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s0)
  %t297 = load i32, ptr %l159, !tbaa !23
  store i32 %t297, ptr %rv
  br label %ret
bb101:
  %t298 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t299 = load i64, ptr %t298, !tbaa !24
  %t300 = load i64, ptr @G_2ecompiler_2folang_2eApi, !tbaa !24
  %t303 = icmp eq i64 %t299, %t300
  br i1 %t303, label %bb102, label %bb103
bb102:
  %t305 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t307 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t305, i64 0)
  store { i64, ptr } %t307, ptr %l164
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t308 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t310 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t308, i64 1)
  store { i64, ptr } %t310, ptr %l166
  br label %bb105
bb105:
  %t311 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t313 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t311, i64 2)
  store { i64, ptr } %t313, ptr %l168
  br label %bb106
bb106:
  %t314 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t318 = call i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t314, { i64, ptr } %t315, { i64, ptr } %t316, ptr %l3)
  store i32 %t318, ptr %l170
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  %t319 = load i32, ptr %l170, !tbaa !23
  store i32 %t319, ptr %rv
  br label %ret
bb108:
  %t320 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t321 = load i64, ptr %t320, !tbaa !24
  %t322 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t325 = icmp eq i64 %t321, %t322
  br i1 %t325, label %bb109, label %bb110
bb109:
  %t328 = call i32 @compiler_2flsp_2eServe(ptr %s0, ptr %l3)
  store i32 %t328, ptr %l175
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_scope_close(ptr %s0)
  %t329 = load i32, ptr %l175, !tbaa !23
  store i32 %t329, ptr %rv
  br label %ret
bb112:
  %t330 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t331 = load i64, ptr %t330, !tbaa !24
  %t332 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t335 = icmp eq i64 %t331, %t332
  br i1 %t335, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %l3, ptr %l179, !tbaa !29
  %t337 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s18, ptr %s18, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d45, i32 0, i32 1) })
  %t338 = extractvalue { i32, { i64, ptr } } %t337, 1
  %t339 = extractvalue { i32, { i64, ptr } } %t337, 0
  store i32 %t339, ptr %l182
  %t340 = icmp ne i32 %t339, 0
  br i1 %t340, label %bb116, label %ok.341, !prof !99
ok.341:
  store { i64, ptr } %t338, ptr %l181
  br label %bb115
bb114:
  br label %bb122
bb115:
  %t342 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t342, ptr %l180, !tbaa !27
  br label %bb120
bb116:
  %t343 = load i32, ptr %l182, !tbaa !23
  %t344 = ashr i32 %t343, 16
  %t346 = icmp eq i32 %t344, 1
  store i1 %t346, ptr %l184, !tbaa !21
  %t347 = load i32, ptr %l182, !tbaa !23
  %t348 = ashr i32 %t347, 16
  %t350 = icmp eq i32 %t348, 1
  br i1 %t350, label %bb117, label %bb118
bb117:
  call void @__olang_errpay_pop()
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t352 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t352, ptr %l187, !tbaa !27
  %t353 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr { i64, ptr }, ptr %t354, i64 0
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !37
  %t358 = extractvalue { i64, ptr } %t356, 1
  %t359 = extractvalue { i64, ptr } %t356, 0
  %t360 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t359)
  call void @olang_textcopy(ptr %t360, ptr %t358, i64 %t359)
  %t361 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  store { i64, ptr } %t362, ptr %l180, !tbaa !27
  br label %bb120
bb120:
  %t365 = load ptr, ptr %l179, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t367 = call i32 @compiler_2fmcp_2eServe(ptr %s0, ptr %s18, ptr %t365, { i64, ptr } %t366)
  store i32 %t367, ptr %l191
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t368 = load i32, ptr %l191, !tbaa !23
  store i32 %t368, ptr %rv
  br label %ret
bb122:
  %t369 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t371 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t369)
  store { i64, ptr } %t371, ptr %l193
  br label %bb123
bb123:
  %t372 = load { i64, ptr }, ptr %l193, !tbaa !27
  store { i64, ptr } %t372, ptr %l8, !tbaa !27
  %t373 = insertvalue { ptr, ptr } undef, ptr @compiler_2folang_2ebuildCell_fv_fn_28std_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_2c_20Array_3_H1276486710fe3f33d55b88d9cfddba68, 0
  %t374 = insertvalue { ptr, ptr } %t373, ptr null, 1
  store { ptr, ptr } %t374, ptr @G_2ecompiler_2fcells_2eBuilder
  %t378 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 16
  %t379 = load i1, ptr %t378, !tbaa !21
  br i1 %t379, label %bb124, label %bb125
bb124:
  %t381 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t381, ptr %l199, !tbaa !27
  %t382 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr { i64, ptr }, ptr %t383, i64 0
  %t385 = load { i64, ptr }, ptr %t384, !tbaa !37
  %t386 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  %t388 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 15
  %t389 = load i1, ptr %t388, !tbaa !21
  %t394 = call i32 @compiler_2fnotebook_2eRun(ptr %s0, ptr %v0, ptr %v0, ptr %l3, { i64, ptr } %t385, { i64, ptr } %t387, i1 %t389)
  store i32 %t394, ptr %l203
  br label %bb126
bb125:
  br label %bb127
bb126:
  call void @__olang_scope_close(ptr %s0)
  %t395 = load i32, ptr %l203, !tbaa !23
  store i32 %t395, ptr %rv
  br label %ret
bb127:
  %t396 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t397 = load i64, ptr %t396, !tbaa !24
  %t398 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t401 = icmp eq i64 %t397, %t398
  br i1 %t401, label %bb128, label %bb129
bb128:
  %t403 = load ptr, ptr %l1, !tbaa !29
  %t404 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t404, ptr %l209, !tbaa !27
  %t405 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = getelementptr { i64, ptr }, ptr %t406, i64 0
  %t408 = load { i64, ptr }, ptr %t407, !tbaa !37
  %t413 = call i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %t403, ptr %l3, { i64, ptr } %t408, ptr %l2)
  store i32 %t413, ptr %l212
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s0)
  %t414 = load i32, ptr %l212, !tbaa !23
  store i32 %t414, ptr %rv
  br label %ret
bb131:
  %t415 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t416 = load i64, ptr %t415, !tbaa !24
  %t417 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t420 = icmp eq i64 %t416, %t417
  br i1 %t420, label %bb132, label %bb133
bb132:
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t423 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t423, ptr %l218, !tbaa !27
  %t424 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr { i64, ptr }, ptr %t425, i64 0
  %t427 = load { i64, ptr }, ptr %t426, !tbaa !37
  %t432 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %t422, ptr %l3, { i64, ptr } %t427, ptr %l2)
  store i32 %t432, ptr %l221
  br label %bb134
bb133:
  br label %bb135
bb134:
  call void @__olang_scope_close(ptr %s0)
  %t433 = load i32, ptr %l221, !tbaa !23
  store i32 %t433, ptr %rv
  br label %ret
bb135:
  %t434 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t435 = load i64, ptr %t434, !tbaa !24
  %t436 = load i64, ptr @G_2ecompiler_2folang_2eRunBuilt, !tbaa !24
  %t439 = icmp eq i64 %t435, %t436
  br i1 %t439, label %bb136, label %bb137
bb136:
  %t441 = load ptr, ptr %l1, !tbaa !29
  store ptr %t441, ptr %l225, !tbaa !29
  store ptr %l3, ptr %l226, !tbaa !29
  %t442 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t442, ptr %l227, !tbaa !27
  %t443 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr { i64, ptr }, ptr %t444, i64 0
  %t446 = load { i64, ptr }, ptr %t445, !tbaa !37
  store { i64, ptr } %t446, ptr %l228, !tbaa !27
  %t447 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t449 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t447)
  store { i64, ptr } %t449, ptr %l230
  br label %bb138
bb137:
  br label %bb140
bb138:
  %t450 = load ptr, ptr %l225, !tbaa !29
  %t451 = load ptr, ptr %l226, !tbaa !29
  %t452 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t453 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t455 = call i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t450, ptr %t451, { i64, ptr } %t452, { i64, ptr } %t453, ptr %l2)
  store i32 %t455, ptr %l232
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s0)
  %t456 = load i32, ptr %l232, !tbaa !23
  store i32 %t456, ptr %rv
  br label %ret
bb140:
  %t457 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t458 = load i64, ptr %t457, !tbaa !24
  %t459 = load i64, ptr @G_2ecompiler_2folang_2eProfile, !tbaa !24
  %t462 = icmp eq i64 %t458, %t459
  br i1 %t462, label %bb141, label %bb142
bb141:
  %t464 = load ptr, ptr %l1, !tbaa !29
  store ptr %t464, ptr %l236, !tbaa !29
  store ptr %l3, ptr %l237, !tbaa !29
  %t465 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t465, ptr %l238, !tbaa !27
  %t466 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !27
  %t468 = getelementptr { i64, ptr }, ptr %t467, i64 0
  %t469 = load { i64, ptr }, ptr %t468, !tbaa !37
  store { i64, ptr } %t469, ptr %l239, !tbaa !27
  %t470 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t472 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t470)
  store { i64, ptr } %t472, ptr %l241
  br label %bb143
bb142:
  br label %bb145
bb143:
  %t473 = load ptr, ptr %l236, !tbaa !29
  %t474 = load ptr, ptr %l237, !tbaa !29
  %t475 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t476 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t478 = call i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t473, ptr %t474, { i64, ptr } %t475, { i64, ptr } %t476, ptr %l2)
  store i32 %t478, ptr %l243
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s0)
  %t479 = load i32, ptr %l243, !tbaa !23
  store i32 %t479, ptr %rv
  br label %ret
bb145:
  %t480 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 13
  %t481 = load i1, ptr %t480, !tbaa !21
  br i1 %t481, label %bb146, label %bb147
bb146:
  %t484 = call i32 @compiler_2fprompt_2eRun(ptr %s0, ptr %l3)
  store i32 %t484, ptr %l246
  br label %bb148
bb147:
  br label %bb149
bb148:
  call void @__olang_scope_close(ptr %s0)
  %t485 = load i32, ptr %l246, !tbaa !23
  store i32 %t485, ptr %rv
  br label %ret
bb149:
  %t486 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t487 = load i64, ptr %t486, !tbaa !24
  %t488 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t491 = icmp eq i64 %t487, %t488
  br i1 %t491, label %bb150, label %bb151
bb150:
  %t493 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 14
  %t494 = load i1, ptr %t493, !tbaa !21
  store i1 %t494, ptr %l250, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l250, !tbaa !21
  br label %bb152
bb152:
  %t496 = load i1, ptr %l250, !tbaa !21
  br i1 %t496, label %bb153, label %bb154
bb153:
  store %olang.scope zeroinitializer, ptr %s26
  %t497 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s26, ptr %s26, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d46, i32 0, i32 1) })
  %t498 = extractvalue { i32, { i64, ptr } } %t497, 1
  %t499 = extractvalue { i32, { i64, ptr } } %t497, 0
  store i32 %t499, ptr %l254
  %t500 = icmp ne i32 %t499, 0
  br i1 %t500, label %bb156, label %ok.501, !prof !99
ok.501:
  store { i64, ptr } %t498, ptr %l253
  br label %bb155
bb154:
  br label %bb162
bb155:
  %t502 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t502, ptr %l252, !tbaa !27
  br label %bb160
bb156:
  %t503 = load i32, ptr %l254, !tbaa !23
  %t504 = ashr i32 %t503, 16
  %t506 = icmp eq i32 %t504, 1
  store i1 %t506, ptr %l256, !tbaa !21
  %t507 = load i32, ptr %l254, !tbaa !23
  %t508 = ashr i32 %t507, 16
  %t510 = icmp eq i32 %t508, 1
  br i1 %t510, label %bb157, label %bb158
bb157:
  call void @__olang_errpay_pop()
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t512 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t512, ptr %l259, !tbaa !27
  %t513 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = getelementptr { i64, ptr }, ptr %t514, i64 0
  %t516 = load { i64, ptr }, ptr %t515, !tbaa !37
  %t518 = extractvalue { i64, ptr } %t516, 1
  %t519 = extractvalue { i64, ptr } %t516, 0
  %t520 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t519)
  call void @olang_textcopy(ptr %t520, ptr %t518, i64 %t519)
  %t521 = insertvalue { i64, ptr } undef, i64 %t519, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  store { i64, ptr } %t522, ptr %l252, !tbaa !27
  br label %bb160
bb160:
  %t525 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t527 = call i32 @compiler_2fjupyter_2eInstall(ptr %s26, ptr %s0, { i64, ptr } %t525, ptr %l3)
  store i32 %t527, ptr %l264
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  %t528 = load i32, ptr %l264, !tbaa !23
  store i32 %t528, ptr %rv
  br label %ret
bb162:
  %t529 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t530 = load i64, ptr %t529, !tbaa !24
  %t531 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t534 = icmp eq i64 %t530, %t531
  br i1 %t534, label %bb163, label %bb164
bb163:
  %t536 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t536, ptr %l269, !tbaa !27
  %t537 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t538 = load ptr, ptr %t537, !tbaa !27
  %t539 = getelementptr { i64, ptr }, ptr %t538, i64 0
  %t540 = load { i64, ptr }, ptr %t539, !tbaa !37
  %t543 = call i32 @compiler_2fjupyter_2eServe(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t540)
  store i32 %t543, ptr %l271
  br label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_scope_close(ptr %s0)
  %t544 = load i32, ptr %l271, !tbaa !23
  store i32 %t544, ptr %rv
  br label %ret
bb166:
  %t545 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t546 = load i64, ptr %t545, !tbaa !24
  %t547 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t550 = icmp eq i64 %t546, %t547
  br i1 %t550, label %bb167, label %bb168
bb167:
  %t552 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t552, ptr %l275
  br label %bb169
bb168:
  br label %bb182
bb169:
  %t553 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store ptr %t553, ptr %lp9
  %t554 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l275
  %t555 = load ptr, ptr %lp9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t554, ptr %t555
  %t556 = load ptr, ptr %lp9
  %t557 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t557, ptr %l277, !tbaa !27
  %t558 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !27
  %t560 = getelementptr { i64, ptr }, ptr %t559, i64 0
  %t561 = load { i64, ptr }, ptr %t560, !tbaa !37
  %t563 = extractvalue { i64, ptr } %t561, 1
  %t564 = extractvalue { i64, ptr } %t561, 0
  %t565 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t564)
  call void @olang_textcopy(ptr %t565, ptr %t563, i64 %t564)
  %t566 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t567 = insertvalue { i64, ptr } %t566, ptr %t565, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t556, { i64, ptr } %t567)
  br label %bb170
bb170:
  %t571 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  store ptr %t571, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb171
bb171:
  %t573 = load i64, ptr %l11, !tbaa !24
  store i64 %t573, ptr %l282, !tbaa !24
  %t574 = load ptr, ptr %l10, !tbaa !29
  %t576 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %t574)
  store i64 %t576, ptr %l284
  br label %bb172
bb172:
  %t577 = load i64, ptr %l282, !tbaa !24
  %t578 = load i64, ptr %l284, !tbaa !24
  %t579 = icmp slt i64 %t577, %t578
  %t581 = xor i1 %t579, true
  br i1 %t581, label %bb173, label %bb174
bb173:
  br label %bb179
bb174:
  br label %bb175
bb175:
  %t583 = load ptr, ptr %l10, !tbaa !29
  %t584 = load i64, ptr %l11, !tbaa !24
  %t587 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t583, i64 %t584)
  store { i64, ptr } %t587, ptr %l289
  br label %bb176
bb176:
  %t588 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t589 = load ptr, ptr %lp9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t589, { i64, ptr } %t588)
  br label %bb177
bb177:
  br label %bb178
bb178:
  %t593 = load i64, ptr %l11, !tbaa !24
  %t596 = add i64 %t593, 1
  store i64 %t596, ptr %l11, !tbaa !24
  br label %bb171
bb179:
  %t598 = load ptr, ptr %l1, !tbaa !29
  store ptr %t598, ptr %l295, !tbaa !29
  store ptr %l3, ptr %l296, !tbaa !29
  %t599 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t599, ptr %l297, !tbaa !27
  %t600 = getelementptr { i64, ptr }, ptr %l297, i32 0, i32 1
  %t601 = load ptr, ptr %t600, !tbaa !27
  %t602 = getelementptr { i64, ptr }, ptr %t601, i64 0
  %t603 = load { i64, ptr }, ptr %t602, !tbaa !37
  store { i64, ptr } %t603, ptr %l298, !tbaa !27
  %t604 = load ptr, ptr %lp9
  %t606 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t604)
  store { i64, ptr } %t606, ptr %l300
  br label %bb180
bb180:
  %t607 = load ptr, ptr %l295, !tbaa !29
  %t608 = load ptr, ptr %l296, !tbaa !29
  %t609 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t610 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t612 = call i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %s0, ptr %t607, ptr %t608, { i64, ptr } %t609, { i64, ptr } %t610, ptr %l2)
  store i32 %t612, ptr %l302
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s0)
  %t613 = load i32, ptr %l302, !tbaa !23
  store i32 %t613, ptr %rv
  br label %ret
bb182:
  %t614 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t614, 0
  %t618 = icmp eq i64 %t616, 1
  br i1 %t618, label %bb183, label %bb184
bb183:
  %t620 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 27
  %t621 = load i1, ptr %t620, !tbaa !21
  store i1 %t621, ptr %l306, !tbaa !21
  br label %bb185
bb184:
  store i1 false, ptr %l306, !tbaa !21
  br label %bb185
bb185:
  %t623 = load i1, ptr %l306, !tbaa !21
  br i1 %t623, label %bb186, label %bb187
bb186:
  %t624 = load ptr, ptr %l1, !tbaa !29
  store ptr %t624, ptr %l308, !tbaa !29
  store ptr %l3, ptr %l309, !tbaa !29
  %t625 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t625, ptr %l310, !tbaa !27
  %t626 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !27
  %t628 = getelementptr { i64, ptr }, ptr %t627, i64 0
  %t629 = load { i64, ptr }, ptr %t628, !tbaa !37
  store { i64, ptr } %t629, ptr %l311, !tbaa !27
  store ptr %l2, ptr %l312, !tbaa !29
  %t630 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t632 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t630)
  store { i64, ptr } %t632, ptr %l314
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t633 = load ptr, ptr %l308, !tbaa !29
  %t634 = load ptr, ptr %l309, !tbaa !29
  %t635 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t636 = load ptr, ptr %l312, !tbaa !29
  %t637 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t638 = call i32 @compiler_2fbuild_2eInterpretTests_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %v0, ptr %t633, ptr %t634, { i64, ptr } %t635, ptr %t636, { i64, ptr } %t637)
  store i32 %t638, ptr %l315
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s0)
  %t639 = load i32, ptr %l315, !tbaa !23
  store i32 %t639, ptr %rv
  br label %ret
bb190:
  %t640 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t642 = extractvalue { i64, ptr } %t640, 0
  %t644 = icmp eq i64 %t642, 1
  br i1 %t644, label %bb191, label %bb192
bb191:
  %t646 = load ptr, ptr %l1, !tbaa !29
  store ptr %t646, ptr %l319, !tbaa !29
  store ptr %l3, ptr %l320, !tbaa !29
  %t647 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t647, ptr %l321, !tbaa !27
  %t648 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t649 = load ptr, ptr %t648, !tbaa !27
  %t650 = getelementptr { i64, ptr }, ptr %t649, i64 0
  %t651 = load { i64, ptr }, ptr %t650, !tbaa !37
  store { i64, ptr } %t651, ptr %l322, !tbaa !27
  store ptr %l2, ptr %l323, !tbaa !29
  %t652 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t654 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t652)
  store { i64, ptr } %t654, ptr %l325
  br label %bb193
bb192:
  br label %bb195
bb193:
  %t655 = load ptr, ptr %l319, !tbaa !29
  %t656 = load ptr, ptr %l320, !tbaa !29
  %t657 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t658 = load ptr, ptr %l323, !tbaa !29
  %t659 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t660 = call i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %v0, ptr %t655, ptr %t656, { i64, ptr } %t657, ptr %t658, { i64, ptr } %t659)
  store i32 %t660, ptr %l326
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s0)
  %t661 = load i32, ptr %l326, !tbaa !23
  store i32 %t661, ptr %rv
  br label %ret
bb195:
  %t662 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d47, i32 0, i32 1) })
  %t663 = extractvalue { i32, { i64, ptr } } %t662, 1
  %t664 = extractvalue { i32, { i64, ptr } } %t662, 0
  store i32 %t664, ptr %l329
  %t665 = icmp ne i32 %t664, 0
  br i1 %t665, label %bb197, label %ok.666, !prof !99
ok.666:
  store { i64, ptr } %t663, ptr %l328
  br label %bb196
bb196:
  %t667 = load { i64, ptr }, ptr %l328, !tbaa !27
  store { i64, ptr } %t667, ptr %l327, !tbaa !27
  br label %bb201
bb197:
  %t668 = load i32, ptr %l329, !tbaa !23
  %t669 = ashr i32 %t668, 16
  %t671 = icmp eq i32 %t669, 1
  store i1 %t671, ptr %l331, !tbaa !21
  %t672 = load i32, ptr %l329, !tbaa !23
  %t673 = ashr i32 %t672, 16
  %t675 = icmp eq i32 %t673, 1
  br i1 %t675, label %bb198, label %bb199
bb198:
  call void @__olang_errpay_pop()
  br label %bb199
bb199:
  br label %bb200
bb200:
  %t677 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t677, ptr %l334, !tbaa !27
  %t678 = getelementptr { i64, ptr }, ptr %l334, i32 0, i32 1
  %t679 = load ptr, ptr %t678, !tbaa !27
  %t680 = getelementptr { i64, ptr }, ptr %t679, i64 0
  %t681 = load { i64, ptr }, ptr %t680, !tbaa !37
  %t683 = extractvalue { i64, ptr } %t681, 1
  %t684 = extractvalue { i64, ptr } %t681, 0
  %t685 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t684)
  call void @olang_textcopy(ptr %t685, ptr %t683, i64 %t684)
  %t686 = insertvalue { i64, ptr } undef, i64 %t684, 0
  %t687 = insertvalue { i64, ptr } %t686, ptr %t685, 1
  store { i64, ptr } %t687, ptr %l327, !tbaa !27
  br label %bb201
bb201:
  %t690 = load { i64, ptr }, ptr %l327, !tbaa !27
  store ptr %l3, ptr %l338, !tbaa !29
  store { i64, ptr } %t690, ptr %l339, !tbaa !27
  %t692 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 6
  %t694 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t692)
  store { i64, ptr } %t694, ptr %l341
  br label %bb202
bb202:
  %t695 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t695, ptr %l342, !tbaa !27
  %t696 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t698 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t696)
  store { i64, ptr } %t698, ptr %l344
  br label %bb203
bb203:
  %t699 = load ptr, ptr %l338, !tbaa !29
  %t700 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t701 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t702 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t703 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t704 = call i32 @compiler_2fbuild_2eTestFiles(ptr %s0, ptr %s0, ptr %v0, ptr %v0, ptr %v0, ptr %t699, { i64, ptr } %t700, { i64, ptr } %t701, { i64, ptr } %t702, { i64, ptr } %t703)
  store i32 %t704, ptr %l345
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s0)
  %t705 = load i32, ptr %l345, !tbaa !23
  store i32 %t705, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca %"compiler/profile:Profile"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/profile:Places"
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca i32
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca { i64, [3 x i64] }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l49 = alloca i32
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i64
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l79 = alloca i32
  %l81 = alloca i1
  %l89 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca { i64, [3 x i64] }
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %l102 = alloca i1
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l112 = alloca %"compiler/profile:Profile"
  %l115 = alloca %"compiler/profile:Profile"
  %l116 = alloca i32
  %l118 = alloca i1
  %l123 = alloca { i64, ptr }
  %l126 = alloca %"compiler/profile:Places"
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca i32
  %l143 = alloca i1
  %l151 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  %t83 = alloca { i64, [3 x i64] }, align 8
  %t251 = alloca { i64, [3 x i64] }, align 8
  %t349 = alloca %"compiler/profile:Places", align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_region_make(ptr %s0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l16, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 34
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = load i64, ptr %l16
  %t11 = inttoptr i64 %t10 to ptr
  %t12 = call ptr @__olang_held_alloc(ptr %t11, i64 %t9)
  call void @olang_textcopy(ptr %t12, ptr %t8, i64 %t9)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l19, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t18 = icmp eq i64 %t16, 0
  br i1 %t18, label %bb1, label %bb2
bb1:
  store { i64, ptr } zeroinitializer, ptr %l19, !tbaa !27
  br label %bb2
bb2:
  %t20 = load i64, ptr %l16
  %t21 = inttoptr i64 %t20 to ptr
  %t22 = load { i64, ptr }, ptr %l19
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = icmp ne ptr %t24, null
  %t26 = select i1 %t25, ptr %t24, ptr null
  call void @__olang_region_settle_in(ptr %t21, ptr %t26)
  %t27 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/build:Config", ptr %t28, i32 0, i32 34
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t30, !tbaa !27
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/build:Config", ptr %t31, i32 0, i32 33
  store i1 true, ptr %t33, !tbaa !21
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/build:Config", ptr %t34, i32 0, i32 18
  store i1 true, ptr %t36, !tbaa !21
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t45 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %a0, ptr %t38, { i64, ptr } %t39, ptr %t40)
  store i32 %t45, ptr %l29
  br label %bb3
bb3:
  %t46 = load i32, ptr %l29, !tbaa !23
  store i32 %t46, ptr %l6, !tbaa !23
  call void @compiler_2fspin_2eEnd()
  br label %bb4
bb4:
  %t47 = load i32, ptr %l6, !tbaa !23
  %t49 = icmp ne i32 %t47, 0
  br i1 %t49, label %bb5, label %bb6
bb5:
  %t51 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t51, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/build:Config", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = extractvalue { i64, ptr } %t56, 0
  %t60 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = getelementptr i8, ptr %t63, i64 %t59
  call void @olang_textcopy(ptr %t64, ptr %t60, i64 %t61)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l7, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t70 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t68)
  store i32 %t70, ptr %l37
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb9, label %ok.72, !prof !99
ok.72:
  br label %bb8
bb8:
  br label %bb16
bb9:
  %t73 = load i32, ptr %l37, !tbaa !23
  %t74 = ashr i32 %t73, 16
  %t76 = icmp eq i32 %t74, 1
  store i1 %t76, ptr %l39, !tbaa !21
  %t77 = load i32, ptr %l37, !tbaa !23
  %t78 = ashr i32 %t77, 16
  %t80 = icmp eq i32 %t78, 1
  br i1 %t80, label %bb10, label %bb11
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load ptr, ptr %l4, !tbaa !29
  store ptr %t82, ptr %l42, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [3 x i64] }, ptr %t83, i32 0, i32 0
  store i64 0, ptr %t84
  %t85 = load { i64, [3 x i64] }, ptr %t83
  store { i64, [3 x i64] } %t85, ptr %l43
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t90 = extractvalue { i64, ptr } %t86, 1
  %t91 = extractvalue { i64, ptr } %t86, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = getelementptr i8, ptr %t97, i64 %t91
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  %t103 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s4, ptr %v4, { i64, ptr } %t100)
  store %"compiler/diagmsg:Msg" %t103, ptr %l47
  br label %bb13
bb13:
  %t104 = load ptr, ptr %l42, !tbaa !29
  %t105 = load { i64, [3 x i64] }, ptr %l43
  %t106 = load %"compiler/diagmsg:Msg", ptr %l47
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t104, { i64, [3 x i64] } %t105, %"compiler/diagmsg:Msg" %t106)
  br label %bb14
bb14:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t107)
  store i32 %t109, ptr %l49
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t110 = load i32, ptr %l49, !tbaa !23
  store i32 %t110, ptr %rv
  br label %ret
bb16:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/build:Config", ptr %t111, i32 0, i32 35
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t116 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %v1, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l52
  br label %bb17
bb17:
  %t117 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t117, ptr %l8, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t120 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t118, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) })
  %t121 = extractvalue { i32, i64 } %t120, 1
  %t122 = extractvalue { i32, i64 } %t120, 0
  store i32 %t122, ptr %l56
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb19, label %ok.124, !prof !99
ok.124:
  store i64 %t121, ptr %l55
  br label %bb18
bb18:
  %t125 = load i64, ptr %l55, !tbaa !24
  store i64 %t125, ptr %l53, !tbaa !24
  br label %bb21
bb19:
  br label %bb20
bb20:
  %t126 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l53, !tbaa !24
  br label %bb21
bb21:
  %t130 = load i64, ptr %l53, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t131, ptr %l59, !tbaa !27
  store i64 %t130, ptr %l60, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l61, !tbaa !24
  %t135 = icmp sge i64 0, 0
  br i1 %t135, label %bb22, label %bb23
bb22:
  %t137 = load i64, ptr %l60, !tbaa !24
  %t138 = icmp sle i64 0, %t137
  br i1 %t138, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb24:
  %t140 = load i64, ptr %l60, !tbaa !24
  %t141 = load i64, ptr %l61, !tbaa !24
  %t142 = icmp sle i64 %t140, %t141
  br i1 %t142, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb26:
  %t144 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l60, !tbaa !24
  %t147 = getelementptr i8, ptr %t145, i64 0
  %t148 = sub i64 %t146, 0
  %t149 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  store { i64, ptr } %t150, ptr %l8, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = extractvalue { i64, ptr } %t152, 0
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t161 = extractvalue { i64, ptr } %t153, 1
  %t162 = extractvalue { i64, ptr } %t153, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t155, i64 %t156)
  %t168 = getelementptr i8, ptr %t167, i64 %t156
  call void @olang_textcopy(ptr %t168, ptr %t157, i64 %t158)
  %t169 = getelementptr i8, ptr %t168, i64 %t158
  call void @olang_textcopy(ptr %t169, ptr %t161, i64 %t162)
  %t170 = getelementptr i8, ptr %t169, i64 %t162
  call void @olang_textcopy(ptr %t170, ptr %t164, i64 %t165)
  %t171 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t167, 1
  store { i64, ptr } %t172, ptr %l10, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t176 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t174, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t176, ptr %l70
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb28:
  %t177 = load i1, ptr %l70, !tbaa !21
  br i1 %t177, label %bb29, label %bb30
bb29:
  %t178 = call ptr @__olang_region_make(ptr %s0)
  %t179 = ptrtoint ptr %t178 to i64
  store i64 %t179, ptr %l71, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t180, 1
  %t184 = extractvalue { i64, ptr } %t180, 0
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t187 = add i64 %t184, %t186
  %t189 = extractvalue { i64, ptr } %t181, 1
  %t190 = extractvalue { i64, ptr } %t181, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t195 = load i64, ptr %l71
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = call ptr @__olang_held_alloc(ptr %t196, i64 %t194)
  call void @olang_textcopy(ptr %t197, ptr %t183, i64 %t184)
  %t198 = getelementptr i8, ptr %t197, i64 %t184
  call void @olang_textcopy(ptr %t198, ptr %t185, i64 %t186)
  %t199 = getelementptr i8, ptr %t198, i64 %t186
  call void @olang_textcopy(ptr %t199, ptr %t189, i64 %t190)
  %t200 = getelementptr i8, ptr %t199, i64 %t190
  call void @olang_textcopy(ptr %t200, ptr %t192, i64 %t193)
  %t201 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t197, 1
  store { i64, ptr } %t202, ptr %l74, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  %t206 = icmp eq i64 %t204, 0
  br i1 %t206, label %bb31, label %bb32
bb30:
  br label %bb33
bb31:
  store { i64, ptr } zeroinitializer, ptr %l74, !tbaa !27
  br label %bb32
bb32:
  %t208 = load i64, ptr %l71
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = load { i64, ptr }, ptr %l74
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = call ptr @__olang_region_or(ptr %t211, ptr null)
  %t213 = icmp ne ptr %t212, null
  %t214 = select i1 %t213, ptr %t212, ptr null
  call void @__olang_region_settle_in(ptr %t209, ptr %t214)
  %t215 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t215, ptr %l77, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t216, ptr %l5, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l77
  %t218 = extractvalue { i64, ptr } %t217, 1
  call void @__olang_region_release(ptr %t218)
  store { i64, ptr } zeroinitializer, ptr %l77
  br label %bb33
bb33:
  %t219 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t221 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t219)
  store i32 %t221, ptr %l79
  %t222 = icmp ne i32 %t221, 0
  br i1 %t222, label %bb35, label %ok.223, !prof !99
ok.223:
  br label %bb34
bb34:
  br label %bb39
bb35:
  %t224 = load i32, ptr %l79, !tbaa !23
  %t225 = ashr i32 %t224, 16
  %t227 = icmp eq i32 %t225, 1
  store i1 %t227, ptr %l81, !tbaa !21
  %t228 = load i32, ptr %l79, !tbaa !23
  %t229 = ashr i32 %t228, 16
  %t231 = icmp eq i32 %t229, 1
  br i1 %t231, label %bb36, label %bb37
bb36:
  call void @__olang_errpay_pop()
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr %"compiler/build:Config", ptr %t233, i32 0, i32 35
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t244 = call i32 @compiler_2fprofile_2erunProfiled(ptr %v1, ptr %v2, ptr %v3, ptr %s0, { i64, ptr } %t236, { i64, ptr } %t237, { i64, ptr } %a3, { i64, ptr } %t239)
  store i32 %t244, ptr %l89
  br label %bb40
bb40:
  %t245 = load i32, ptr %l89, !tbaa !23
  store i32 %t245, ptr %l11, !tbaa !23
  %t246 = load i32, ptr %l11, !tbaa !23
  %t248 = icmp slt i32 %t246, 0
  br i1 %t248, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t250 = load ptr, ptr %l4, !tbaa !29
  store ptr %t250, ptr %l92, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t251
  %t252 = getelementptr { i64, [3 x i64] }, ptr %t251, i32 0, i32 0
  store i64 0, ptr %t252
  %t253 = load { i64, [3 x i64] }, ptr %t251
  store { i64, [3 x i64] } %t253, ptr %l93
  %t254 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s10, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t254, ptr %l94
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t255 = load ptr, ptr %l92, !tbaa !29
  %t256 = load { i64, [3 x i64] }, ptr %l93
  %t257 = load %"compiler/diagmsg:Msg", ptr %l94
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t255, { i64, [3 x i64] } %t256, %"compiler/diagmsg:Msg" %t257)
  br label %bb44
bb44:
  %t258 = load ptr, ptr %l4, !tbaa !29
  %t260 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t258)
  store i32 %t260, ptr %l96
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t261 = load i32, ptr %l96, !tbaa !23
  store i32 %t261, ptr %rv
  br label %ret
bb46:
  %t262 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t264 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t262)
  %t265 = extractvalue { i32, { i64, ptr } } %t264, 1
  %t266 = extractvalue { i32, { i64, ptr } } %t264, 0
  store i32 %t266, ptr %l100
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb48, label %ok.268, !prof !99
ok.268:
  store { i64, ptr } %t265, ptr %l99
  br label %bb47
bb47:
  %t269 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t269, ptr %l97, !tbaa !27
  br label %bb54
bb48:
  %t270 = load i32, ptr %l100, !tbaa !23
  %t271 = ashr i32 %t270, 16
  %t273 = icmp eq i32 %t271, 1
  store i1 %t273, ptr %l102, !tbaa !21
  %t274 = load i32, ptr %l100, !tbaa !23
  %t275 = ashr i32 %t274, 16
  %t277 = icmp eq i32 %t275, 1
  br i1 %t277, label %bb49, label %bb50
bb49:
  call void @__olang_errpay_pop()
  br label %bb50
bb50:
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s11
  %t279 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t279, ptr %l105, !tbaa !27
  %t280 = load i32, ptr %l11, !tbaa !23
  %t282 = sub i32 %t280, 128
  %t284 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t282)
  store { i64, ptr } %t284, ptr %l108
  br label %bb52
bb52:
  %t285 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t286 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t287 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = add i64 %t286, %t289
  %t291 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t293 = add i64 %t290, %t292
  %t294 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 1
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t297 = add i64 %t293, %t296
  %t298 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t300 = add i64 %t297, %t299
  %t301 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t300)
  call void @olang_textcopy(ptr %t301, ptr %t285, i64 %t286)
  %t302 = getelementptr i8, ptr %t301, i64 %t286
  call void @olang_textcopy(ptr %t302, ptr %t288, i64 %t289)
  %t303 = getelementptr i8, ptr %t302, i64 %t289
  call void @olang_textcopy(ptr %t303, ptr %t291, i64 %t292)
  %t304 = getelementptr i8, ptr %t303, i64 %t292
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t298, i64 %t299)
  %t306 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t301, 1
  call void @compiler_2fprofile_2esay(ptr %s11, { i64, ptr } %t307)
  br label %bb53
bb53:
  %t310 = load i32, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t310, ptr %rv
  br label %ret
bb54:
  %t312 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t316 = call { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %s0, ptr %s0, { i64, ptr } %t312)
  %t317 = extractvalue { i32, %"compiler/profile:Profile" } %t316, 1
  %t318 = extractvalue { i32, %"compiler/profile:Profile" } %t316, 0
  store i32 %t318, ptr %l116
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb56, label %ok.320, !prof !99
ok.320:
  store %"compiler/profile:Profile" %t317, ptr %l115
  br label %bb55
bb55:
  %t321 = load %"compiler/profile:Profile", ptr %l115
  store %"compiler/profile:Profile" %t321, ptr %l112
  br label %bb59
bb56:
  %t322 = load i32, ptr %l116, !tbaa !23
  %t323 = ashr i32 %t322, 16
  %t325 = icmp eq i32 %t323, 1
  store i1 %t325, ptr %l118, !tbaa !21
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s13
  %t326 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t327 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t328 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t330 = extractvalue { i64, ptr } %t326, 1
  %t331 = extractvalue { i64, ptr } %t326, 0
  %t332 = add i64 %t328, %t331
  %t333 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t335 = add i64 %t332, %t334
  %t336 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t335)
  call void @olang_textcopy(ptr %t336, ptr %t327, i64 %t328)
  %t337 = getelementptr i8, ptr %t336, i64 %t328
  call void @olang_textcopy(ptr %t337, ptr %t330, i64 %t331)
  %t338 = getelementptr i8, ptr %t337, i64 %t331
  call void @olang_textcopy(ptr %t338, ptr %t333, i64 %t334)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t336, 1
  call void @compiler_2fprofile_2esay(ptr %s13, { i64, ptr } %t340)
  br label %bb58
bb58:
  %t343 = load i32, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t343, ptr %rv
  br label %ret
bb59:
  %t345 = load %"compiler/profile:Profile", ptr %l112
  store %"compiler/profile:Profile" %t345, ptr %l13
  %t346 = call { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %s0)
  store { i64, ptr } %t346, ptr %l123
  br label %bb60
bb60:
  %t347 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t347, ptr %l14, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2fprofile_2ePlaces_2eResolve(ptr %t349, ptr %s0, ptr %s0, ptr %s0, ptr %l13, { i64, ptr } %t348)
  call void @llvm.memmove.p0.p0.i64(ptr %l126, ptr %t349, i64 272, i1 false)
  br label %bb61
bb61:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l126, i64 272, i1 false)
  %t352 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t356 = call { i64, ptr } @compiler_2fprofile_2eReport(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t352, ptr %l13, ptr %l15)
  store { i64, ptr } %t356, ptr %l130
  br label %bb62
bb62:
  %t357 = load { i64, ptr }, ptr %l130, !tbaa !27
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t357)
  br label %bb63
bb63:
  %t359 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t361 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t359, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t361, ptr %l133
  br label %bb64
bb64:
  %t362 = load i1, ptr %l133, !tbaa !21
  br i1 %t362, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s15
  call void @compiler_2fprofile_2esay(ptr %s15, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_scope_close(ptr %s15)
  br label %bb68
bb68:
  %t363 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t363, ptr %l134, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t368 = call { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t364, ptr %l13, ptr %l15)
  store { i64, ptr } %t368, ptr %l138
  br label %bb69
bb69:
  %t369 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t372 = extractvalue { i64, ptr } %t369, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t377 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t379 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t377, { i64, ptr } %t376)
  store i32 %t379, ptr %l141
  %t380 = icmp ne i32 %t379, 0
  br i1 %t380, label %bb71, label %ok.381, !prof !99
ok.381:
  br label %bb70
bb70:
  br label %bb76
bb71:
  %t382 = load i32, ptr %l141, !tbaa !23
  %t383 = ashr i32 %t382, 16
  %t385 = icmp eq i32 %t383, 1
  store i1 %t385, ptr %l143, !tbaa !21
  %t386 = load i32, ptr %l141, !tbaa !23
  %t387 = ashr i32 %t386, 16
  %t389 = icmp eq i32 %t387, 1
  br i1 %t389, label %bb72, label %bb73
bb72:
  call void @__olang_errpay_pop()
  br label %bb73
bb73:
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s16
  %t391 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t392 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t393 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t395 = extractvalue { i64, ptr } %t391, 1
  %t396 = extractvalue { i64, ptr } %t391, 0
  %t397 = add i64 %t393, %t396
  %t398 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t399 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t400 = add i64 %t397, %t399
  %t401 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t400)
  call void @olang_textcopy(ptr %t401, ptr %t392, i64 %t393)
  %t402 = getelementptr i8, ptr %t401, i64 %t393
  call void @olang_textcopy(ptr %t402, ptr %t395, i64 %t396)
  %t403 = getelementptr i8, ptr %t402, i64 %t396
  call void @olang_textcopy(ptr %t403, ptr %t398, i64 %t399)
  %t404 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t401, 1
  call void @compiler_2fprofile_2esay(ptr %s16, { i64, ptr } %t405)
  br label %bb75
bb75:
  %t408 = load i32, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t408, ptr %rv
  br label %ret
bb76:
  %t410 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t412 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t410)
  store { i64, ptr } %t412, ptr %l151
  br label %bb77
bb77:
  %t413 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t414 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t415 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 1
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t418 = add i64 %t414, %t417
  %t419 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t420 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t421 = add i64 %t418, %t420
  %t422 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t421)
  call void @olang_textcopy(ptr %t422, ptr %t413, i64 %t414)
  %t423 = getelementptr i8, ptr %t422, i64 %t414
  call void @olang_textcopy(ptr %t423, ptr %t416, i64 %t417)
  %t424 = getelementptr i8, ptr %t423, i64 %t417
  call void @olang_textcopy(ptr %t424, ptr %t419, i64 %t420)
  %t425 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t422, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t426)
  br label %bb78
bb78:
  %t429 = load i32, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t429, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eroom_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/build:Code", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 56
  %t93 = mul i64 %t90, 56
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 56
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/build:Code", ptr %t132, i64 %t129
  %t134 = load %"compiler/build:Code", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/build:Code", ptr %t138, i64 %t136
  store %"compiler/build:Code" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"run" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d15 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ir" }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".asm" }>, align 8
@.d18 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/listing/" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_region_release(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d33 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_test" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": native compilation failed" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d39 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"running tools" }>, align 8
@.d40 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"compiling" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-ir" }>, align 8
@.d44 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d45 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
define linkonce_odr i32 @compiler_2folang_2ebuildCell_fv_fn_28std_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_2c_20Array_3_H1276486710fe3f33d55b88d9cfddba68(ptr %env, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7) #0 {
entry:
  %r = call i32 @compiler_2folang_2ebuildCell(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7)
  ret i32 %r
}

@.d46 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d47 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/profile" }>, align 8
@.d50 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"its profile's directory " }>, align 8
@.d51 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" cannot be made" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d54 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".samples" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d57 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d58 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d59 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d60 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" wrote no profile - it ended by a signal (" }>, align 8
@.d61 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d62 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d63 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" is not a profile this compiler writes\0A" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"olang profile: no llvm-symbolizer found beside clang or on PATH - functions named by their addresses\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d66 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d67 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be written\0A" }>, align 8
@.d68 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"flame graph: " }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_grow_in_place(ptr, i64, i64, i64) noinline
declare void @__olang_region_release_part(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare void @compiler_2fbuild_3aProgram_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eunbuilt()
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare void @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2eUnspill(ptr %v0, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eexe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare void @compiler_2fspin_2eEnd()
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/diagmsg:Msg" %a1, ptr %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_d52a764a2d9743a3_d3f0603066c4fb17 = external constant [0 x i8]
declare i64 @std_2ftime_2eNow()
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fbuild_2eRunCacheCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
declare void @compiler_2fbuild_2ePrune(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @compiler_2fmeasure_2eMeasure(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3e7cb8585e177347_844f5af656df9c9b = external constant [0 x i8]
declare %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, ptr %a6)
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/diagmsg:Msg" %a2, ptr %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0)
declare i1 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2esplitsTests(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eraceBinary_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, ptr %a5)
declare void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, i64 %a6)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestsEnded(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunParts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, ptr %a6)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_d427f69e0d58601c_ef1499a0f9cee590 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2eCommandLine_2ePrepare(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eJupyter = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0F\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eHelp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2folang_2ewaits(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eFix = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fspin_2eBegin(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2folang_2eanalyzes(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eAnalysisDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2folang_2eExplain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare i32 @compiler_2flisting_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, ptr %a5)
declare i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
declare { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@G_2ecompiler_2folang_2eFormat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@G_2ecompiler_2folang_2eBindgen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2folang_2eDoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eApi = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eLsp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eMcp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fcells_2eBuilder = external global { ptr, ptr }
declare i32 @compiler_2fnotebook_2eRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
@G_2ecompiler_2folang_2eCompile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eRunBuilt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eProfile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fprompt_2eRun(ptr %v0, ptr %a0)
declare i32 @compiler_2fjupyter_2eInstall(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare i32 @compiler_2fjupyter_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fbuild_2eInterpretTests_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4)
declare i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2eFinish(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2308270aeb54ce5f_1121c256bef46e33 = external constant [0 x i8]
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare void @compiler_2fprofile_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0)
declare void @compiler_2fprofile_2ePlaces_2eResolve(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
@olang_loc_42020986585537b2_4c4b240152eb3e56 = external constant [0 x i8]
declare i32 @compiler_2folang_2ebuildCell(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
