; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/doc:Entry" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/session:Use" = type { i64, i64, { i64, ptr } }
define dso_local void @std_2fprelude_2farray_2esortByPositions_3ccompiler_2fdoc_3aModule_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { ptr, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l26 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i1
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t170 = alloca { { ptr, ptr }, { i64, ptr }, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  store { ptr, ptr } %pg1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2estd_2fprelude_2farray_2esortRun, !tbaa !24
  %t9 = icmp sle i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load { ptr, ptr }, ptr %l1
  %t17 = extractvalue { ptr, ptr } %t13, 0
  %t18 = extractvalue { ptr, ptr } %t13, 1
  call void @std_2fprelude_2farray_2esortInsertion_3ccompiler_2fdoc_3aModule_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t11, i64 0, i64 %t12, ptr %t17, ptr %t18)
  br label %bb3
bb2:
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  store i64 %t25, ptr %l26, !tbaa !24
  br label %bb8
bb7:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l26, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = icmp sle i64 %t32, 1152921504606846975
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c022e58ec96da978_ec8311c98a19dd54)
  unreachable
bb11:
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = mul i64 %t35, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_c022e58ec96da978_ec8311c98a19dd54)
  unreachable
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb15:
  br label %bb16
bb16:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t61 = load i64, ptr %l2, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = sub i64 %t63, %t64
  store i64 %t67, ptr %l45, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l46, !tbaa !24
  %t70 = icmp sge i64 0, 0
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load i64, ptr %l45, !tbaa !24
  %t73 = icmp sle i64 0, %t72
  br i1 %t73, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_58e30339dc525c65_8ff29672c8905379)
  unreachable
bb22:
  %t75 = load i64, ptr %l45, !tbaa !24
  %t76 = load i64, ptr %l46, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_58e30339dc525c65_8ff29672c8905379)
  unreachable
bb24:
  %t79 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l45, !tbaa !24
  %t82 = getelementptr i64, ptr %t80, i64 0
  %t83 = sub i64 %t81, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sub i64 %t87, %t88
  store i64 %t91, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_58e30339dc525c65_8ff29672c8905379)
  unreachable
bb26:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb31
bb28:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l60, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb30
bb30:
  %t119 = load i64, ptr %l60, !tbaa !24
  store i64 %t119, ptr %l57, !tbaa !24
  br label %bb31
bb31:
  %t120 = load i64, ptr %l57, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t121 = load i64, ptr %l10, !tbaa !24
  %t122 = sub i64 %t121, 1
  store i64 %t122, ptr %l69, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = icmp slt i64 %t123, 2147483648
  %t125 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sge i64 %t125, 0
  %t129 = and i1 %t124, %t126
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l9, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l12, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t148, ptr %l82, !tbaa !27
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l4, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t157 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i64, ptr %t158, i64 %t149
  store i64 %t154, ptr %t159, !tbaa !34
  br label %bb36
bb36:
  %t160 = load i64, ptr %l11, !tbaa !24
  %t163 = add i64 %t160, 1
  store i64 %t163, ptr %l11, !tbaa !24
  br label %bb32
bb37:
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = load { ptr, ptr }, ptr %l1
  %t167 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t168 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr null, i32 1
  %t169 = ptrtoint ptr %t168 to i64
  %t171 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 0
  store { ptr, ptr } %t166, ptr %t171, !tbaa !28
  %t173 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 1
  store { i64, ptr } %t167, ptr %t173, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t175 = call ptr @__olang_scope_hold(ptr %v1)
  %t176 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 2
  store ptr %t175, ptr %t176, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t177 = call ptr @__olang_scope_hold(ptr %v0)
  %t178 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 3
  store ptr %t177, ptr %t178, !tbaa !28
  %t179 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t180 = insertvalue { ptr, ptr } %t179, ptr %t170, 1
  %t183 = extractvalue { ptr, ptr } %t180, 0
  %t184 = extractvalue { ptr, ptr } %t180, 1
  call void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e_clone1_olang_lambda_17278(ptr %s0, ptr %s2, { i64, ptr } %t165, ptr %t183, ptr %t184)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t186 = load i64, ptr %l4, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2farray_2esortPermute_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %s0, { i64, ptr } %t185, i64 %t186, { i64, ptr } %t187)
  br label %bb40
bb40:
  %t191 = load i64, ptr %l5, !tbaa !24
  store i64 %t191, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  br label %bb13
bb42:
  %t193 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  store i64 %t193, ptr %l13, !tbaa !24
  br label %bb43
bb43:
  %t195 = load i64, ptr %l13, !tbaa !24
  %t196 = load i64, ptr %l2, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb44, label %bb45
bb44:
  br label %bb59
bb45:
  br label %bb46
bb46:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb47
bb47:
  %t203 = load i64, ptr %l4, !tbaa !24
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = add i64 %t203, %t204
  %t208 = load i64, ptr %l2, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb48, label %bb49
bb48:
  br label %bb57
bb49:
  br label %bb50
bb50:
  %t215 = load i64, ptr %l4, !tbaa !24
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = mul i64 2, %t216
  %t221 = add i64 %t215, %t218
  store i64 %t221, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l14, !tbaa !24
  %t224 = load i64, ptr %l2, !tbaa !24
  %t227 = icmp sgt i64 %t223, %t224
  br i1 %t227, label %bb51, label %bb52
bb51:
  %t229 = load i64, ptr %l2, !tbaa !24
  store i64 %t229, ptr %l14, !tbaa !24
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t231 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t232 = load i64, ptr %l4, !tbaa !24
  %t233 = load i64, ptr %l4, !tbaa !24
  %t234 = load i64, ptr %l13, !tbaa !24
  %t237 = add i64 %t233, %t234
  %t238 = load i64, ptr %l14, !tbaa !24
  %t239 = load { ptr, ptr }, ptr %l1
  %t245 = extractvalue { ptr, ptr } %t239, 0
  %t246 = extractvalue { ptr, ptr } %t239, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2fdoc_3aModule_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t231, i64 %t232, i64 %t237, i64 %t238, ptr %t245, ptr %t246)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t247 = load i64, ptr %l14, !tbaa !24
  store i64 %t247, ptr %l4, !tbaa !24
  br label %bb56
bb56:
  br label %bb47
bb57:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t252 = mul i64 %t249, 2
  store i64 %t252, ptr %l13, !tbaa !24
  br label %bb58
bb58:
  br label %bb43
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortInsert_3ccompiler_2fdoc_3aModule_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, ptr %a3c, ptr %a3e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca %"compiler/doc:Module"
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { ptr, ptr }
  %l17 = alloca %"compiler/doc:Module"
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca %"compiler/doc:Entry"
  %l28 = alloca { i64, ptr }
  %l32 = alloca %"compiler/doc:Module"
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca %"compiler/doc:Entry"
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l57 = alloca %"compiler/doc:Module"
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca %"compiler/doc:Entry"
  %s1 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store i64 %a2, ptr %l2
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr %"compiler/doc:Module", ptr %t5, i64 %t2
  %t7 = load %"compiler/doc:Module", ptr %t6
  store %"compiler/doc:Module" zeroinitializer, ptr %t6
  store %"compiler/doc:Module" %t7, ptr %l4
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t11, %a1
  br i1 %t15, label %bb2, label %bb3
bb2:
  store { ptr, ptr } %pg3, ptr %l15
  %t18 = load %"compiler/doc:Module", ptr %l4
  store %"compiler/doc:Module" %t18, ptr %l17
  %t20 = call ptr @__olang_region_make_part(ptr %s1)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l18, !tbaa !24
  %t22 = getelementptr %"compiler/doc:Module", ptr %l17, i32 0, i32 3
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = mul i64 %t26, 152
  %t28 = load i64, ptr %l18
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = call ptr @__olang_held_alloc(ptr %t29, i64 %t27)
  %t31 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb24
bb4:
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = load i64, ptr %l21, !tbaa !24
  %t38 = getelementptr %"compiler/doc:Module", ptr %l17, i32 0, i32 3
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t38, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = icmp slt i64 %t37, %t40
  br i1 %t41, label %bb9, label %bb7
bb6:
  %t43 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t44 = getelementptr %"compiler/doc:Module", ptr %l17, i32 0, i32 3
  %t45 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 0
  store { i64, ptr } %t43, ptr %t45, !tbaa !27
  %t46 = getelementptr %"compiler/doc:Module", ptr %l17, i32 0, i32 3
  %t47 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb11, label %bb12
bb7:
  %t53 = load i64, ptr %l21, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr %"compiler/doc:Entry", ptr %t55, i64 %t53
  call void @llvm.memset.p0.i64(ptr %t56, i8 0, i64 152, i1 false)
  br label %bb8
bb8:
  %t57 = load i64, ptr %l21, !tbaa !24
  %t58 = add i64 %t57, 1
  store i64 %t58, ptr %l21, !tbaa !24
  br label %bb4
bb9:
  %t59 = getelementptr %"compiler/doc:Module", ptr %l17, i32 0, i32 3
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %l21, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr %"compiler/doc:Entry", ptr %t63, i64 %t61
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t64, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s1, ptr %l24)
  br label %bb10
bb10:
  %t66 = load i64, ptr %l21, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/doc:Entry", ptr %t68, i64 %t66
  call void @llvm.memmove.p0.p0.i64(ptr %t69, ptr %l24, i64 152, i1 false)
  br label %bb8
bb11:
  %t70 = getelementptr %"compiler/doc:Module", ptr %l17, i32 0, i32 3
  %t71 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t70, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t71, !tbaa !27
  br label %bb12
bb12:
  %t72 = getelementptr %"compiler/doc:Module", ptr %l17, i32 0, i32 3
  %t73 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t72, i32 0, i32 0
  %t74 = load i64, ptr %l18
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = load { i64, ptr }, ptr %t73
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = call ptr @__olang_region_or(ptr %t77, ptr null)
  %t79 = icmp ne ptr %t78, null
  %t80 = select i1 %t79, ptr %t78, ptr null
  call void @__olang_region_settle_in(ptr %t75, ptr %t80)
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t81, ptr %l28, !tbaa !27
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = sub i64 %t82, 1
  %t86 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr %"compiler/doc:Module", ptr %t87, i64 %t84
  %t89 = load %"compiler/doc:Module", ptr %t88
  store %"compiler/doc:Module" %t89, ptr %l32
  %t91 = call ptr @__olang_region_make_part(ptr %s1)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l33, !tbaa !24
  %t93 = getelementptr %"compiler/doc:Module", ptr %l32, i32 0, i32 3
  %t94 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t93, i32 0, i32 0
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l34, !tbaa !24
  %t97 = load i64, ptr %l34, !tbaa !24
  %t98 = mul i64 %t97, 152
  %t99 = load i64, ptr %l33
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = call ptr @__olang_held_alloc(ptr %t100, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  br label %bb13
bb13:
  %t104 = load i64, ptr %l36, !tbaa !24
  %t105 = load i64, ptr %l34, !tbaa !24
  %t106 = icmp slt i64 %t104, %t105
  br i1 %t106, label %bb14, label %bb15
bb14:
  %t108 = load i64, ptr %l36, !tbaa !24
  %t109 = getelementptr %"compiler/doc:Module", ptr %l32, i32 0, i32 3
  %t110 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t109, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = icmp slt i64 %t108, %t111
  br i1 %t112, label %bb18, label %bb16
bb15:
  %t114 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t115 = getelementptr %"compiler/doc:Module", ptr %l32, i32 0, i32 3
  %t116 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t114, ptr %t116, !tbaa !27
  %t117 = getelementptr %"compiler/doc:Module", ptr %l32, i32 0, i32 3
  %t118 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t117, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t122 = icmp eq i64 %t120, 0
  br i1 %t122, label %bb20, label %bb21
bb16:
  %t124 = load i64, ptr %l36, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr %"compiler/doc:Entry", ptr %t126, i64 %t124
  call void @llvm.memset.p0.i64(ptr %t127, i8 0, i64 152, i1 false)
  br label %bb17
bb17:
  %t128 = load i64, ptr %l36, !tbaa !24
  %t129 = add i64 %t128, 1
  store i64 %t129, ptr %l36, !tbaa !24
  br label %bb13
bb18:
  %t130 = getelementptr %"compiler/doc:Module", ptr %l32, i32 0, i32 3
  %t131 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t130, i32 0, i32 0
  %t132 = load i64, ptr %l36, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"compiler/doc:Entry", ptr %t134, i64 %t132
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t135, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s1, ptr %l39)
  br label %bb19
bb19:
  %t137 = load i64, ptr %l36, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr %"compiler/doc:Entry", ptr %t139, i64 %t137
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %l39, i64 152, i1 false)
  br label %bb17
bb20:
  %t141 = getelementptr %"compiler/doc:Module", ptr %l32, i32 0, i32 3
  %t142 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t141, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t142, !tbaa !27
  br label %bb21
bb21:
  %t143 = getelementptr %"compiler/doc:Module", ptr %l32, i32 0, i32 3
  %t144 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t143, i32 0, i32 0
  %t145 = load i64, ptr %l33
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = load { i64, ptr }, ptr %t144
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = call ptr @__olang_region_or(ptr %t148, ptr null)
  %t150 = icmp ne ptr %t149, null
  %t151 = select i1 %t150, ptr %t149, ptr null
  call void @__olang_region_settle_in(ptr %t146, ptr %t151)
  %t152 = load { ptr, ptr }, ptr %l15
  %t153 = extractvalue { ptr, ptr } %t152, 0
  %t154 = extractvalue { ptr, ptr } %t152, 1
  %t155 = load %"compiler/doc:Module", ptr %l17
  %t156 = load %"compiler/doc:Module", ptr %l32
  %t157 = call i1 %t153(ptr %t154, ptr %s1, ptr %s1, %"compiler/doc:Module" %t155, %"compiler/doc:Module" %t156)
  store i1 %t157, ptr %l43
  br label %bb22
bb22:
  %t158 = load i1, ptr %l43, !tbaa !21
  store i1 %t158, ptr %l14, !tbaa !21
  br label %bb23
bb23:
  %t159 = load i1, ptr %l14, !tbaa !21
  store i1 %t159, ptr %l13, !tbaa !21
  br label %bb24
bb24:
  %t160 = load i1, ptr %l13, !tbaa !21
  %t161 = xor i1 %t160, true
  br i1 %t161, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s1)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t163 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t163, ptr %l45, !tbaa !27
  %t164 = load i64, ptr %l5, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t165, ptr %l47, !tbaa !27
  %t166 = load i64, ptr %l5, !tbaa !24
  %t168 = sub i64 %t166, 1
  %t170 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr %"compiler/doc:Module", ptr %t171, i64 %t168
  %t173 = load %"compiler/doc:Module", ptr %t172
  store %"compiler/doc:Module" zeroinitializer, ptr %t172
  %t176 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr %"compiler/doc:Module", ptr %t177, i64 %t164
  store %"compiler/doc:Module" %t173, ptr %t178
  %t179 = load i64, ptr %l5, !tbaa !24
  %t182 = sub i64 %t179, 1
  store i64 %t182, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb28:
  br label %bb1
bb29:
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l54, !tbaa !27
  %t185 = load i64, ptr %l5, !tbaa !24
  store i64 %t185, ptr %l55, !tbaa !24
  %t186 = load %"compiler/doc:Module", ptr %l4
  store %"compiler/doc:Module" %t186, ptr %l57
  %t188 = call ptr @__olang_region_make_part(ptr %v0)
  %t189 = ptrtoint ptr %t188 to i64
  store i64 %t189, ptr %l58, !tbaa !24
  %t190 = getelementptr %"compiler/doc:Module", ptr %l57, i32 0, i32 3
  %t191 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t190, i32 0, i32 0
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l59, !tbaa !24
  %t194 = load i64, ptr %l59, !tbaa !24
  %t195 = mul i64 %t194, 152
  %t196 = load i64, ptr %l58
  %t197 = inttoptr i64 %t196 to ptr
  %t198 = call ptr @__olang_held_alloc(ptr %t197, i64 %t195)
  %t199 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l60, !tbaa !27
  store i64 0, ptr %l61, !tbaa !24
  br label %bb30
bb30:
  %t201 = load i64, ptr %l61, !tbaa !24
  %t202 = load i64, ptr %l59, !tbaa !24
  %t203 = icmp slt i64 %t201, %t202
  br i1 %t203, label %bb31, label %bb32
bb31:
  %t205 = load i64, ptr %l61, !tbaa !24
  %t206 = getelementptr %"compiler/doc:Module", ptr %l57, i32 0, i32 3
  %t207 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t206, i32 0, i32 1
  %t208 = load i64, ptr %t207, !tbaa !24
  %t209 = icmp slt i64 %t205, %t208
  br i1 %t209, label %bb35, label %bb33
bb32:
  %t211 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t212 = getelementptr %"compiler/doc:Module", ptr %l57, i32 0, i32 3
  %t213 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t212, i32 0, i32 0
  store { i64, ptr } %t211, ptr %t213, !tbaa !27
  %t214 = getelementptr %"compiler/doc:Module", ptr %l57, i32 0, i32 3
  %t215 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t214, i32 0, i32 0
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  %t219 = icmp eq i64 %t217, 0
  br i1 %t219, label %bb37, label %bb38
bb33:
  %t221 = load i64, ptr %l61, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr %"compiler/doc:Entry", ptr %t223, i64 %t221
  call void @llvm.memset.p0.i64(ptr %t224, i8 0, i64 152, i1 false)
  br label %bb34
bb34:
  %t225 = load i64, ptr %l61, !tbaa !24
  %t226 = add i64 %t225, 1
  store i64 %t226, ptr %l61, !tbaa !24
  br label %bb30
bb35:
  %t227 = getelementptr %"compiler/doc:Module", ptr %l57, i32 0, i32 3
  %t228 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t227, i32 0, i32 0
  %t229 = load i64, ptr %l61, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr %"compiler/doc:Entry", ptr %t231, i64 %t229
  call void @llvm.memmove.p0.p0.i64(ptr %l64, ptr %t232, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %l64)
  br label %bb36
bb36:
  %t234 = load i64, ptr %l61, !tbaa !24
  %t235 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr %"compiler/doc:Entry", ptr %t236, i64 %t234
  call void @llvm.memmove.p0.p0.i64(ptr %t237, ptr %l64, i64 152, i1 false)
  br label %bb34
bb37:
  %t238 = getelementptr %"compiler/doc:Module", ptr %l57, i32 0, i32 3
  %t239 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t238, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t239, !tbaa !27
  br label %bb38
bb38:
  %t240 = getelementptr %"compiler/doc:Module", ptr %l57, i32 0, i32 3
  %t241 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t240, i32 0, i32 0
  %t242 = load i64, ptr %l58
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = load { i64, ptr }, ptr %t241
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = call ptr @__olang_region_or(ptr %t245, ptr null)
  %t247 = icmp ne ptr %t246, null
  %t248 = select i1 %t247, ptr %t246, ptr null
  call void @__olang_region_settle_in(ptr %t243, ptr %t248)
  %t249 = load %"compiler/doc:Module", ptr %l57
  %t250 = load i64, ptr %l55, !tbaa !24
  %t251 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr %"compiler/doc:Module", ptr %t252, i64 %t250
  store %"compiler/doc:Module" %t249, ptr %t253
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortMerge_3ccompiler_2fdoc_3aModule_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l39 = alloca i1
  %l40 = alloca { ptr, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca %"compiler/doc:Module"
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l51 = alloca %"compiler/doc:Entry"
  %l55 = alloca { i64, ptr }
  %l58 = alloca %"compiler/doc:Module"
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca %"compiler/doc:Entry"
  %l69 = alloca i1
  %l79 = alloca i64
  %l82 = alloca i64
  %l121 = alloca i1
  %l122 = alloca { ptr, ptr }
  %l123 = alloca { i64, ptr }
  %l126 = alloca %"compiler/doc:Module"
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l133 = alloca %"compiler/doc:Entry"
  %l137 = alloca { i64, ptr }
  %l140 = alloca %"compiler/doc:Module"
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l144 = alloca i64
  %l147 = alloca %"compiler/doc:Entry"
  %l151 = alloca i1
  %l194 = alloca i1
  %l195 = alloca { ptr, ptr }
  %l196 = alloca { i64, ptr }
  %l201 = alloca %"compiler/doc:Module"
  %l202 = alloca i64
  %l203 = alloca i64
  %l204 = alloca { i64, ptr }
  %l205 = alloca i64
  %l208 = alloca %"compiler/doc:Entry"
  %l212 = alloca { i64, ptr }
  %l215 = alloca %"compiler/doc:Module"
  %l216 = alloca i64
  %l217 = alloca i64
  %l218 = alloca { i64, ptr }
  %l219 = alloca i64
  %l222 = alloca %"compiler/doc:Entry"
  %l226 = alloca i1
  %l237 = alloca i1
  %l248 = alloca i1
  %l260 = alloca i1
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t1, %t2
  %t7 = icmp eq i64 %t5, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb3
bb2:
  br label %bb45
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb5:
  br label %bb6
bb6:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sdiv i64 %t25, 2
  store i64 %t27, ptr %l7, !tbaa !24
  %t29 = load { ptr, ptr }, ptr %l4
  store { ptr, ptr } %t29, ptr %l40
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l41, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/doc:Module", ptr %t34, i64 %t31
  %t36 = load %"compiler/doc:Module", ptr %t35
  store %"compiler/doc:Module" %t36, ptr %l44
  %t38 = call ptr @__olang_region_make_part(ptr %s2)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l45, !tbaa !24
  %t40 = getelementptr %"compiler/doc:Module", ptr %l44, i32 0, i32 3
  %t41 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 0
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l46, !tbaa !24
  %t44 = load i64, ptr %l46, !tbaa !24
  %t45 = mul i64 %t44, 152
  %t46 = load i64, ptr %l45
  %t47 = inttoptr i64 %t46 to ptr
  %t48 = call ptr @__olang_held_alloc(ptr %t47, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l48, !tbaa !24
  %t52 = load i64, ptr %l46, !tbaa !24
  %t53 = icmp slt i64 %t51, %t52
  br i1 %t53, label %bb8, label %bb9
bb8:
  %t55 = load i64, ptr %l48, !tbaa !24
  %t56 = getelementptr %"compiler/doc:Module", ptr %l44, i32 0, i32 3
  %t57 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t56, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = icmp slt i64 %t55, %t58
  br i1 %t59, label %bb12, label %bb10
bb9:
  %t61 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t62 = getelementptr %"compiler/doc:Module", ptr %l44, i32 0, i32 3
  %t63 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 0
  store { i64, ptr } %t61, ptr %t63, !tbaa !27
  %t64 = getelementptr %"compiler/doc:Module", ptr %l44, i32 0, i32 3
  %t65 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t64, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t69 = icmp eq i64 %t67, 0
  br i1 %t69, label %bb14, label %bb15
bb10:
  %t71 = load i64, ptr %l48, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/doc:Entry", ptr %t73, i64 %t71
  call void @llvm.memset.p0.i64(ptr %t74, i8 0, i64 152, i1 false)
  br label %bb11
bb11:
  %t75 = load i64, ptr %l48, !tbaa !24
  %t76 = add i64 %t75, 1
  store i64 %t76, ptr %l48, !tbaa !24
  br label %bb7
bb12:
  %t77 = getelementptr %"compiler/doc:Module", ptr %l44, i32 0, i32 3
  %t78 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t77, i32 0, i32 0
  %t79 = load i64, ptr %l48, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr %"compiler/doc:Entry", ptr %t81, i64 %t79
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr %t82, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s2, ptr %l51)
  br label %bb13
bb13:
  %t84 = load i64, ptr %l48, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr %"compiler/doc:Entry", ptr %t86, i64 %t84
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %l51, i64 152, i1 false)
  br label %bb11
bb14:
  %t88 = getelementptr %"compiler/doc:Module", ptr %l44, i32 0, i32 3
  %t89 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t88, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t89, !tbaa !27
  br label %bb15
bb15:
  %t90 = getelementptr %"compiler/doc:Module", ptr %l44, i32 0, i32 3
  %t91 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t90, i32 0, i32 0
  %t92 = load i64, ptr %l45
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = load { i64, ptr }, ptr %t91
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = call ptr @__olang_region_or(ptr %t95, ptr null)
  %t97 = icmp ne ptr %t96, null
  %t98 = select i1 %t97, ptr %t96, ptr null
  call void @__olang_region_settle_in(ptr %t93, ptr %t98)
  %t99 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr %"compiler/doc:Module", ptr %t103, i64 %t100
  %t105 = load %"compiler/doc:Module", ptr %t104
  store %"compiler/doc:Module" %t105, ptr %l58
  %t107 = call ptr @__olang_region_make_part(ptr %s2)
  %t108 = ptrtoint ptr %t107 to i64
  store i64 %t108, ptr %l59, !tbaa !24
  %t109 = getelementptr %"compiler/doc:Module", ptr %l58, i32 0, i32 3
  %t110 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t109, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l60, !tbaa !24
  %t113 = load i64, ptr %l60, !tbaa !24
  %t114 = mul i64 %t113, 152
  %t115 = load i64, ptr %l59
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = call ptr @__olang_held_alloc(ptr %t116, i64 %t114)
  %t118 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l61, !tbaa !27
  store i64 0, ptr %l62, !tbaa !24
  br label %bb16
bb16:
  %t120 = load i64, ptr %l62, !tbaa !24
  %t121 = load i64, ptr %l60, !tbaa !24
  %t122 = icmp slt i64 %t120, %t121
  br i1 %t122, label %bb17, label %bb18
bb17:
  %t124 = load i64, ptr %l62, !tbaa !24
  %t125 = getelementptr %"compiler/doc:Module", ptr %l58, i32 0, i32 3
  %t126 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t125, i32 0, i32 1
  %t127 = load i64, ptr %t126, !tbaa !24
  %t128 = icmp slt i64 %t124, %t127
  br i1 %t128, label %bb21, label %bb19
bb18:
  %t130 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t131 = getelementptr %"compiler/doc:Module", ptr %l58, i32 0, i32 3
  %t132 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t131, i32 0, i32 0
  store { i64, ptr } %t130, ptr %t132, !tbaa !27
  %t133 = getelementptr %"compiler/doc:Module", ptr %l58, i32 0, i32 3
  %t134 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t133, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t138 = icmp eq i64 %t136, 0
  br i1 %t138, label %bb23, label %bb24
bb19:
  %t140 = load i64, ptr %l62, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr %"compiler/doc:Entry", ptr %t142, i64 %t140
  call void @llvm.memset.p0.i64(ptr %t143, i8 0, i64 152, i1 false)
  br label %bb20
bb20:
  %t144 = load i64, ptr %l62, !tbaa !24
  %t145 = add i64 %t144, 1
  store i64 %t145, ptr %l62, !tbaa !24
  br label %bb16
bb21:
  %t146 = getelementptr %"compiler/doc:Module", ptr %l58, i32 0, i32 3
  %t147 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t146, i32 0, i32 0
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"compiler/doc:Entry", ptr %t150, i64 %t148
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t151, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s2, ptr %l65)
  br label %bb22
bb22:
  %t153 = load i64, ptr %l62, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr %"compiler/doc:Entry", ptr %t155, i64 %t153
  call void @llvm.memmove.p0.p0.i64(ptr %t156, ptr %l65, i64 152, i1 false)
  br label %bb20
bb23:
  %t157 = getelementptr %"compiler/doc:Module", ptr %l58, i32 0, i32 3
  %t158 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t157, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t158, !tbaa !27
  br label %bb24
bb24:
  %t159 = getelementptr %"compiler/doc:Module", ptr %l58, i32 0, i32 3
  %t160 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t159, i32 0, i32 0
  %t161 = load i64, ptr %l59
  %t162 = inttoptr i64 %t161 to ptr
  %t163 = load { i64, ptr }, ptr %t160
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = call ptr @__olang_region_or(ptr %t164, ptr null)
  %t166 = icmp ne ptr %t165, null
  %t167 = select i1 %t166, ptr %t165, ptr null
  call void @__olang_region_settle_in(ptr %t162, ptr %t167)
  %t168 = load { ptr, ptr }, ptr %l40
  %t169 = extractvalue { ptr, ptr } %t168, 0
  %t170 = extractvalue { ptr, ptr } %t168, 1
  %t171 = load %"compiler/doc:Module", ptr %l44
  %t172 = load %"compiler/doc:Module", ptr %l58
  %t173 = call i1 %t169(ptr %t170, ptr %s2, ptr %s2, %"compiler/doc:Module" %t171, %"compiler/doc:Module" %t172)
  store i1 %t173, ptr %l69
  br label %bb25
bb25:
  %t174 = load i1, ptr %l69, !tbaa !21
  store i1 %t174, ptr %l39, !tbaa !21
  br label %bb26
bb26:
  %t175 = load i1, ptr %l39, !tbaa !21
  br i1 %t175, label %bb27, label %bb28
bb27:
  %t176 = load i64, ptr %l7, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l5, !tbaa !24
  br label %bb29
bb28:
  %t180 = load i64, ptr %l7, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  br label %bb3
bb31:
  %t182 = load i64, ptr %l1, !tbaa !24
  store i64 %t182, ptr %l8, !tbaa !24
  %t184 = load i64, ptr %l5, !tbaa !24
  %t186 = sub i64 %t184, 1
  store i64 %t186, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t188 = load i64, ptr %l9, !tbaa !24
  %t189 = load i64, ptr %l8, !tbaa !24
  %t192 = icmp sgt i64 %t188, %t189
  br i1 %t192, label %bb32, label %bb33
bb32:
  %t194 = load i64, ptr %l10, !tbaa !24
  %t196 = icmp sgt i64 %t194, 0
  br i1 %t196, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb37
bb34:
  %t198 = load i64, ptr %l9, !tbaa !24
  %t199 = load i64, ptr %l8, !tbaa !24
  %t202 = sub i64 %t198, %t199
  %t203 = load i64, ptr %l10, !tbaa !24
  %t206 = add i64 %t202, %t203
  %t208 = sub i64 %t206, 1
  %t209 = load i64, ptr %l10, !tbaa !24
  %t212 = sdiv i64 %t208, %t209
  store i64 %t212, ptr %l82, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb36
bb36:
  %t214 = load i64, ptr %l82, !tbaa !24
  store i64 %t214, ptr %l79, !tbaa !24
  br label %bb37
bb37:
  %t215 = load i64, ptr %l79, !tbaa !24
  store i64 %t215, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  %t216 = load i64, ptr %l12, !tbaa !24
  %t217 = load i64, ptr %l11, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t224 = load i64, ptr %l8, !tbaa !24
  %t225 = load i64, ptr %l12, !tbaa !24
  %t226 = load i64, ptr %l10, !tbaa !24
  %t229 = mul i64 %t225, %t226
  %t232 = add i64 %t224, %t229
  store i64 %t232, ptr %l13, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t235 = load i64, ptr %l13, !tbaa !24
  %t236 = load i64, ptr %l13, !tbaa !24
  %t238 = add i64 %t236, 1
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fdoc_3aModule_3e(ptr %v0, { i64, ptr } %t234, i64 %t235, i64 %t238)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t242 = load i64, ptr %l12, !tbaa !24
  %t245 = add i64 %t242, 1
  store i64 %t245, ptr %l12, !tbaa !24
  br label %bb38
bb44:
  br label %ret
bb45:
  %t247 = load i64, ptr %l3, !tbaa !24
  %t248 = load i64, ptr %l2, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t253 = icmp eq i64 %t251, 1
  br i1 %t253, label %bb46, label %bb47
bb46:
  %t255 = load i64, ptr %l1, !tbaa !24
  store i64 %t255, ptr %l14, !tbaa !24
  %t257 = load i64, ptr %l2, !tbaa !24
  store i64 %t257, ptr %l15, !tbaa !24
  br label %bb48
bb47:
  br label %bb84
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t259 = load i64, ptr %l14, !tbaa !24
  %t260 = load i64, ptr %l15, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb76
bb50:
  br label %bb51
bb51:
  %t267 = load i64, ptr %l14, !tbaa !24
  %t268 = load i64, ptr %l15, !tbaa !24
  %t271 = add i64 %t267, %t268
  %t273 = sdiv i64 %t271, 2
  store i64 %t273, ptr %l16, !tbaa !24
  %t275 = load { ptr, ptr }, ptr %l4
  store { ptr, ptr } %t275, ptr %l122
  %t276 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t276, ptr %l123, !tbaa !27
  %t277 = load i64, ptr %l2, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr %"compiler/doc:Module", ptr %t280, i64 %t277
  %t282 = load %"compiler/doc:Module", ptr %t281
  store %"compiler/doc:Module" %t282, ptr %l126
  %t284 = call ptr @__olang_region_make_part(ptr %s9)
  %t285 = ptrtoint ptr %t284 to i64
  store i64 %t285, ptr %l127, !tbaa !24
  %t286 = getelementptr %"compiler/doc:Module", ptr %l126, i32 0, i32 3
  %t287 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t286, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t288, 0
  store i64 %t289, ptr %l128, !tbaa !24
  %t290 = load i64, ptr %l128, !tbaa !24
  %t291 = mul i64 %t290, 152
  %t292 = load i64, ptr %l127
  %t293 = inttoptr i64 %t292 to ptr
  %t294 = call ptr @__olang_held_alloc(ptr %t293, i64 %t291)
  %t295 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  store { i64, ptr } %t296, ptr %l129, !tbaa !27
  store i64 0, ptr %l130, !tbaa !24
  br label %bb52
bb52:
  %t297 = load i64, ptr %l130, !tbaa !24
  %t298 = load i64, ptr %l128, !tbaa !24
  %t299 = icmp slt i64 %t297, %t298
  br i1 %t299, label %bb53, label %bb54
bb53:
  %t301 = load i64, ptr %l130, !tbaa !24
  %t302 = getelementptr %"compiler/doc:Module", ptr %l126, i32 0, i32 3
  %t303 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t302, i32 0, i32 1
  %t304 = load i64, ptr %t303, !tbaa !24
  %t305 = icmp slt i64 %t301, %t304
  br i1 %t305, label %bb57, label %bb55
bb54:
  %t307 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t308 = getelementptr %"compiler/doc:Module", ptr %l126, i32 0, i32 3
  %t309 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t308, i32 0, i32 0
  store { i64, ptr } %t307, ptr %t309, !tbaa !27
  %t310 = getelementptr %"compiler/doc:Module", ptr %l126, i32 0, i32 3
  %t311 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t310, i32 0, i32 0
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t312, 0
  %t315 = icmp eq i64 %t313, 0
  br i1 %t315, label %bb59, label %bb60
bb55:
  %t317 = load i64, ptr %l130, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr %"compiler/doc:Entry", ptr %t319, i64 %t317
  call void @llvm.memset.p0.i64(ptr %t320, i8 0, i64 152, i1 false)
  br label %bb56
bb56:
  %t321 = load i64, ptr %l130, !tbaa !24
  %t322 = add i64 %t321, 1
  store i64 %t322, ptr %l130, !tbaa !24
  br label %bb52
bb57:
  %t323 = getelementptr %"compiler/doc:Module", ptr %l126, i32 0, i32 3
  %t324 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t323, i32 0, i32 0
  %t325 = load i64, ptr %l130, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr %"compiler/doc:Entry", ptr %t327, i64 %t325
  call void @llvm.memmove.p0.p0.i64(ptr %l133, ptr %t328, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s9, ptr %l133)
  br label %bb58
bb58:
  %t330 = load i64, ptr %l130, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr %"compiler/doc:Entry", ptr %t332, i64 %t330
  call void @llvm.memmove.p0.p0.i64(ptr %t333, ptr %l133, i64 152, i1 false)
  br label %bb56
bb59:
  %t334 = getelementptr %"compiler/doc:Module", ptr %l126, i32 0, i32 3
  %t335 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t334, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t335, !tbaa !27
  br label %bb60
bb60:
  %t336 = getelementptr %"compiler/doc:Module", ptr %l126, i32 0, i32 3
  %t337 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t336, i32 0, i32 0
  %t338 = load i64, ptr %l127
  %t339 = inttoptr i64 %t338 to ptr
  %t340 = load { i64, ptr }, ptr %t337
  %t341 = extractvalue { i64, ptr } %t340, 1
  %t342 = call ptr @__olang_region_or(ptr %t341, ptr null)
  %t343 = icmp ne ptr %t342, null
  %t344 = select i1 %t343, ptr %t342, ptr null
  call void @__olang_region_settle_in(ptr %t339, ptr %t344)
  %t345 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t345, ptr %l137, !tbaa !27
  %t346 = load i64, ptr %l16, !tbaa !24
  %t348 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr %"compiler/doc:Module", ptr %t349, i64 %t346
  %t351 = load %"compiler/doc:Module", ptr %t350
  store %"compiler/doc:Module" %t351, ptr %l140
  %t353 = call ptr @__olang_region_make_part(ptr %s9)
  %t354 = ptrtoint ptr %t353 to i64
  store i64 %t354, ptr %l141, !tbaa !24
  %t355 = getelementptr %"compiler/doc:Module", ptr %l140, i32 0, i32 3
  %t356 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t355, i32 0, i32 0
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 0
  store i64 %t358, ptr %l142, !tbaa !24
  %t359 = load i64, ptr %l142, !tbaa !24
  %t360 = mul i64 %t359, 152
  %t361 = load i64, ptr %l141
  %t362 = inttoptr i64 %t361 to ptr
  %t363 = call ptr @__olang_held_alloc(ptr %t362, i64 %t360)
  %t364 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  store { i64, ptr } %t365, ptr %l143, !tbaa !27
  store i64 0, ptr %l144, !tbaa !24
  br label %bb61
bb61:
  %t366 = load i64, ptr %l144, !tbaa !24
  %t367 = load i64, ptr %l142, !tbaa !24
  %t368 = icmp slt i64 %t366, %t367
  br i1 %t368, label %bb62, label %bb63
bb62:
  %t370 = load i64, ptr %l144, !tbaa !24
  %t371 = getelementptr %"compiler/doc:Module", ptr %l140, i32 0, i32 3
  %t372 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t371, i32 0, i32 1
  %t373 = load i64, ptr %t372, !tbaa !24
  %t374 = icmp slt i64 %t370, %t373
  br i1 %t374, label %bb66, label %bb64
bb63:
  %t376 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t377 = getelementptr %"compiler/doc:Module", ptr %l140, i32 0, i32 3
  %t378 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t377, i32 0, i32 0
  store { i64, ptr } %t376, ptr %t378, !tbaa !27
  %t379 = getelementptr %"compiler/doc:Module", ptr %l140, i32 0, i32 3
  %t380 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t379, i32 0, i32 0
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 0
  %t384 = icmp eq i64 %t382, 0
  br i1 %t384, label %bb68, label %bb69
bb64:
  %t386 = load i64, ptr %l144, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr %"compiler/doc:Entry", ptr %t388, i64 %t386
  call void @llvm.memset.p0.i64(ptr %t389, i8 0, i64 152, i1 false)
  br label %bb65
bb65:
  %t390 = load i64, ptr %l144, !tbaa !24
  %t391 = add i64 %t390, 1
  store i64 %t391, ptr %l144, !tbaa !24
  br label %bb61
bb66:
  %t392 = getelementptr %"compiler/doc:Module", ptr %l140, i32 0, i32 3
  %t393 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t392, i32 0, i32 0
  %t394 = load i64, ptr %l144, !tbaa !24
  %t395 = getelementptr { i64, ptr }, ptr %t393, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr %"compiler/doc:Entry", ptr %t396, i64 %t394
  call void @llvm.memmove.p0.p0.i64(ptr %l147, ptr %t397, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s9, ptr %l147)
  br label %bb67
bb67:
  %t399 = load i64, ptr %l144, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr %"compiler/doc:Entry", ptr %t401, i64 %t399
  call void @llvm.memmove.p0.p0.i64(ptr %t402, ptr %l147, i64 152, i1 false)
  br label %bb65
bb68:
  %t403 = getelementptr %"compiler/doc:Module", ptr %l140, i32 0, i32 3
  %t404 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t403, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t404, !tbaa !27
  br label %bb69
bb69:
  %t405 = getelementptr %"compiler/doc:Module", ptr %l140, i32 0, i32 3
  %t406 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t405, i32 0, i32 0
  %t407 = load i64, ptr %l141
  %t408 = inttoptr i64 %t407 to ptr
  %t409 = load { i64, ptr }, ptr %t406
  %t410 = extractvalue { i64, ptr } %t409, 1
  %t411 = call ptr @__olang_region_or(ptr %t410, ptr null)
  %t412 = icmp ne ptr %t411, null
  %t413 = select i1 %t412, ptr %t411, ptr null
  call void @__olang_region_settle_in(ptr %t408, ptr %t413)
  %t414 = load { ptr, ptr }, ptr %l122
  %t415 = extractvalue { ptr, ptr } %t414, 0
  %t416 = extractvalue { ptr, ptr } %t414, 1
  %t417 = load %"compiler/doc:Module", ptr %l126
  %t418 = load %"compiler/doc:Module", ptr %l140
  %t419 = call i1 %t415(ptr %t416, ptr %s9, ptr %s9, %"compiler/doc:Module" %t417, %"compiler/doc:Module" %t418)
  store i1 %t419, ptr %l151
  br label %bb70
bb70:
  %t420 = load i1, ptr %l151, !tbaa !21
  store i1 %t420, ptr %l121, !tbaa !21
  br label %bb71
bb71:
  %t421 = load i1, ptr %l121, !tbaa !21
  %t422 = xor i1 %t421, true
  br i1 %t422, label %bb72, label %bb73
bb72:
  %t424 = load i64, ptr %l16, !tbaa !24
  %t426 = add i64 %t424, 1
  store i64 %t426, ptr %l14, !tbaa !24
  br label %bb74
bb73:
  %t428 = load i64, ptr %l16, !tbaa !24
  store i64 %t428, ptr %l15, !tbaa !24
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s9)
  br label %bb75
bb75:
  br label %bb48
bb76:
  %t430 = load i64, ptr %l2, !tbaa !24
  store i64 %t430, ptr %l17, !tbaa !24
  br label %bb77
bb77:
  %t432 = load i64, ptr %l17, !tbaa !24
  %t433 = load i64, ptr %l14, !tbaa !24
  %t436 = icmp sgt i64 %t432, %t433
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb78, label %bb79
bb78:
  br label %bb83
bb79:
  br label %bb80
bb80:
  %t440 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t441 = load i64, ptr %l17, !tbaa !24
  %t442 = load i64, ptr %l17, !tbaa !24
  %t444 = sub i64 %t442, 1
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fdoc_3aModule_3e(ptr %v0, { i64, ptr } %t440, i64 %t441, i64 %t444)
  br label %bb81
bb81:
  %t448 = load i64, ptr %l17, !tbaa !24
  %t451 = sub i64 %t448, 1
  store i64 %t451, ptr %l17, !tbaa !24
  br label %bb82
bb82:
  br label %bb77
bb83:
  br label %ret
bb84:
  %t453 = load i64, ptr %l1, !tbaa !24
  %t454 = load i64, ptr %l3, !tbaa !24
  %t457 = add i64 %t453, %t454
  %t459 = sdiv i64 %t457, 2
  store i64 %t459, ptr %l18, !tbaa !24
  %t461 = load i64, ptr %l18, !tbaa !24
  %t462 = load i64, ptr %l2, !tbaa !24
  %t465 = add i64 %t461, %t462
  store i64 %t465, ptr %l19, !tbaa !24
  %t467 = load i64, ptr %l1, !tbaa !24
  store i64 %t467, ptr %l20, !tbaa !24
  %t469 = load i64, ptr %l2, !tbaa !24
  store i64 %t469, ptr %l21, !tbaa !24
  %t471 = load i64, ptr %l2, !tbaa !24
  %t472 = load i64, ptr %l18, !tbaa !24
  %t475 = icmp sgt i64 %t471, %t472
  br i1 %t475, label %bb85, label %bb86
bb85:
  %t477 = load i64, ptr %l19, !tbaa !24
  %t478 = load i64, ptr %l3, !tbaa !24
  %t481 = sub i64 %t477, %t478
  store i64 %t481, ptr %l20, !tbaa !24
  %t483 = load i64, ptr %l18, !tbaa !24
  store i64 %t483, ptr %l21, !tbaa !24
  br label %bb87
bb86:
  br label %bb87
bb87:
  %t485 = load i64, ptr %l19, !tbaa !24
  %t487 = sub i64 %t485, 1
  store i64 %t487, ptr %l22, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s14
  %t489 = load i64, ptr %l20, !tbaa !24
  %t490 = load i64, ptr %l21, !tbaa !24
  %t493 = icmp slt i64 %t489, %t490
  %t495 = xor i1 %t493, true
  br i1 %t495, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb90:
  br label %bb91
bb91:
  %t497 = load i64, ptr %l20, !tbaa !24
  %t498 = load i64, ptr %l21, !tbaa !24
  %t501 = add i64 %t497, %t498
  %t503 = sdiv i64 %t501, 2
  store i64 %t503, ptr %l23, !tbaa !24
  %t505 = load { ptr, ptr }, ptr %l4
  store { ptr, ptr } %t505, ptr %l195
  %t506 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t506, ptr %l196, !tbaa !27
  %t507 = load i64, ptr %l22, !tbaa !24
  %t508 = load i64, ptr %l23, !tbaa !24
  %t511 = sub i64 %t507, %t508
  %t513 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = getelementptr %"compiler/doc:Module", ptr %t514, i64 %t511
  %t516 = load %"compiler/doc:Module", ptr %t515
  store %"compiler/doc:Module" %t516, ptr %l201
  %t518 = call ptr @__olang_region_make_part(ptr %s14)
  %t519 = ptrtoint ptr %t518 to i64
  store i64 %t519, ptr %l202, !tbaa !24
  %t520 = getelementptr %"compiler/doc:Module", ptr %l201, i32 0, i32 3
  %t521 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t520, i32 0, i32 0
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 0
  store i64 %t523, ptr %l203, !tbaa !24
  %t524 = load i64, ptr %l203, !tbaa !24
  %t525 = mul i64 %t524, 152
  %t526 = load i64, ptr %l202
  %t527 = inttoptr i64 %t526 to ptr
  %t528 = call ptr @__olang_held_alloc(ptr %t527, i64 %t525)
  %t529 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  store { i64, ptr } %t530, ptr %l204, !tbaa !27
  store i64 0, ptr %l205, !tbaa !24
  br label %bb92
bb92:
  %t531 = load i64, ptr %l205, !tbaa !24
  %t532 = load i64, ptr %l203, !tbaa !24
  %t533 = icmp slt i64 %t531, %t532
  br i1 %t533, label %bb93, label %bb94
bb93:
  %t535 = load i64, ptr %l205, !tbaa !24
  %t536 = getelementptr %"compiler/doc:Module", ptr %l201, i32 0, i32 3
  %t537 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t536, i32 0, i32 1
  %t538 = load i64, ptr %t537, !tbaa !24
  %t539 = icmp slt i64 %t535, %t538
  br i1 %t539, label %bb97, label %bb95
bb94:
  %t541 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t542 = getelementptr %"compiler/doc:Module", ptr %l201, i32 0, i32 3
  %t543 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t542, i32 0, i32 0
  store { i64, ptr } %t541, ptr %t543, !tbaa !27
  %t544 = getelementptr %"compiler/doc:Module", ptr %l201, i32 0, i32 3
  %t545 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t544, i32 0, i32 0
  %t546 = load { i64, ptr }, ptr %t545, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 0
  %t549 = icmp eq i64 %t547, 0
  br i1 %t549, label %bb99, label %bb100
bb95:
  %t551 = load i64, ptr %l205, !tbaa !24
  %t552 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !27
  %t554 = getelementptr %"compiler/doc:Entry", ptr %t553, i64 %t551
  call void @llvm.memset.p0.i64(ptr %t554, i8 0, i64 152, i1 false)
  br label %bb96
bb96:
  %t555 = load i64, ptr %l205, !tbaa !24
  %t556 = add i64 %t555, 1
  store i64 %t556, ptr %l205, !tbaa !24
  br label %bb92
bb97:
  %t557 = getelementptr %"compiler/doc:Module", ptr %l201, i32 0, i32 3
  %t558 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t557, i32 0, i32 0
  %t559 = load i64, ptr %l205, !tbaa !24
  %t560 = getelementptr { i64, ptr }, ptr %t558, i32 0, i32 1
  %t561 = load ptr, ptr %t560, !tbaa !27
  %t562 = getelementptr %"compiler/doc:Entry", ptr %t561, i64 %t559
  call void @llvm.memmove.p0.p0.i64(ptr %l208, ptr %t562, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s14, ptr %l208)
  br label %bb98
bb98:
  %t564 = load i64, ptr %l205, !tbaa !24
  %t565 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t566 = load ptr, ptr %t565, !tbaa !27
  %t567 = getelementptr %"compiler/doc:Entry", ptr %t566, i64 %t564
  call void @llvm.memmove.p0.p0.i64(ptr %t567, ptr %l208, i64 152, i1 false)
  br label %bb96
bb99:
  %t568 = getelementptr %"compiler/doc:Module", ptr %l201, i32 0, i32 3
  %t569 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t568, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t569, !tbaa !27
  br label %bb100
bb100:
  %t570 = getelementptr %"compiler/doc:Module", ptr %l201, i32 0, i32 3
  %t571 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t570, i32 0, i32 0
  %t572 = load i64, ptr %l202
  %t573 = inttoptr i64 %t572 to ptr
  %t574 = load { i64, ptr }, ptr %t571
  %t575 = extractvalue { i64, ptr } %t574, 1
  %t576 = call ptr @__olang_region_or(ptr %t575, ptr null)
  %t577 = icmp ne ptr %t576, null
  %t578 = select i1 %t577, ptr %t576, ptr null
  call void @__olang_region_settle_in(ptr %t573, ptr %t578)
  %t579 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t579, ptr %l212, !tbaa !27
  %t580 = load i64, ptr %l23, !tbaa !24
  %t582 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t583 = load ptr, ptr %t582, !tbaa !27
  %t584 = getelementptr %"compiler/doc:Module", ptr %t583, i64 %t580
  %t585 = load %"compiler/doc:Module", ptr %t584
  store %"compiler/doc:Module" %t585, ptr %l215
  %t587 = call ptr @__olang_region_make_part(ptr %s14)
  %t588 = ptrtoint ptr %t587 to i64
  store i64 %t588, ptr %l216, !tbaa !24
  %t589 = getelementptr %"compiler/doc:Module", ptr %l215, i32 0, i32 3
  %t590 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t589, i32 0, i32 0
  %t591 = load { i64, ptr }, ptr %t590, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t591, 0
  store i64 %t592, ptr %l217, !tbaa !24
  %t593 = load i64, ptr %l217, !tbaa !24
  %t594 = mul i64 %t593, 152
  %t595 = load i64, ptr %l216
  %t596 = inttoptr i64 %t595 to ptr
  %t597 = call ptr @__olang_held_alloc(ptr %t596, i64 %t594)
  %t598 = insertvalue { i64, ptr } undef, i64 %t593, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t597, 1
  store { i64, ptr } %t599, ptr %l218, !tbaa !27
  store i64 0, ptr %l219, !tbaa !24
  br label %bb101
bb101:
  %t600 = load i64, ptr %l219, !tbaa !24
  %t601 = load i64, ptr %l217, !tbaa !24
  %t602 = icmp slt i64 %t600, %t601
  br i1 %t602, label %bb102, label %bb103
bb102:
  %t604 = load i64, ptr %l219, !tbaa !24
  %t605 = getelementptr %"compiler/doc:Module", ptr %l215, i32 0, i32 3
  %t606 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t605, i32 0, i32 1
  %t607 = load i64, ptr %t606, !tbaa !24
  %t608 = icmp slt i64 %t604, %t607
  br i1 %t608, label %bb106, label %bb104
bb103:
  %t610 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t611 = getelementptr %"compiler/doc:Module", ptr %l215, i32 0, i32 3
  %t612 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t611, i32 0, i32 0
  store { i64, ptr } %t610, ptr %t612, !tbaa !27
  %t613 = getelementptr %"compiler/doc:Module", ptr %l215, i32 0, i32 3
  %t614 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t613, i32 0, i32 0
  %t615 = load { i64, ptr }, ptr %t614, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 0
  %t618 = icmp eq i64 %t616, 0
  br i1 %t618, label %bb108, label %bb109
bb104:
  %t620 = load i64, ptr %l219, !tbaa !24
  %t621 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = getelementptr %"compiler/doc:Entry", ptr %t622, i64 %t620
  call void @llvm.memset.p0.i64(ptr %t623, i8 0, i64 152, i1 false)
  br label %bb105
bb105:
  %t624 = load i64, ptr %l219, !tbaa !24
  %t625 = add i64 %t624, 1
  store i64 %t625, ptr %l219, !tbaa !24
  br label %bb101
bb106:
  %t626 = getelementptr %"compiler/doc:Module", ptr %l215, i32 0, i32 3
  %t627 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t626, i32 0, i32 0
  %t628 = load i64, ptr %l219, !tbaa !24
  %t629 = getelementptr { i64, ptr }, ptr %t627, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = getelementptr %"compiler/doc:Entry", ptr %t630, i64 %t628
  call void @llvm.memmove.p0.p0.i64(ptr %l222, ptr %t631, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s14, ptr %l222)
  br label %bb107
bb107:
  %t633 = load i64, ptr %l219, !tbaa !24
  %t634 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t635 = load ptr, ptr %t634, !tbaa !27
  %t636 = getelementptr %"compiler/doc:Entry", ptr %t635, i64 %t633
  call void @llvm.memmove.p0.p0.i64(ptr %t636, ptr %l222, i64 152, i1 false)
  br label %bb105
bb108:
  %t637 = getelementptr %"compiler/doc:Module", ptr %l215, i32 0, i32 3
  %t638 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t637, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t638, !tbaa !27
  br label %bb109
bb109:
  %t639 = getelementptr %"compiler/doc:Module", ptr %l215, i32 0, i32 3
  %t640 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t639, i32 0, i32 0
  %t641 = load i64, ptr %l216
  %t642 = inttoptr i64 %t641 to ptr
  %t643 = load { i64, ptr }, ptr %t640
  %t644 = extractvalue { i64, ptr } %t643, 1
  %t645 = call ptr @__olang_region_or(ptr %t644, ptr null)
  %t646 = icmp ne ptr %t645, null
  %t647 = select i1 %t646, ptr %t645, ptr null
  call void @__olang_region_settle_in(ptr %t642, ptr %t647)
  %t648 = load { ptr, ptr }, ptr %l195
  %t649 = extractvalue { ptr, ptr } %t648, 0
  %t650 = extractvalue { ptr, ptr } %t648, 1
  %t651 = load %"compiler/doc:Module", ptr %l201
  %t652 = load %"compiler/doc:Module", ptr %l215
  %t653 = call i1 %t649(ptr %t650, ptr %s14, ptr %s14, %"compiler/doc:Module" %t651, %"compiler/doc:Module" %t652)
  store i1 %t653, ptr %l226
  br label %bb110
bb110:
  %t654 = load i1, ptr %l226, !tbaa !21
  store i1 %t654, ptr %l194, !tbaa !21
  br label %bb111
bb111:
  %t655 = load i1, ptr %l194, !tbaa !21
  %t656 = xor i1 %t655, true
  br i1 %t656, label %bb112, label %bb113
bb112:
  %t658 = load i64, ptr %l23, !tbaa !24
  %t660 = add i64 %t658, 1
  store i64 %t660, ptr %l20, !tbaa !24
  br label %bb114
bb113:
  %t662 = load i64, ptr %l23, !tbaa !24
  store i64 %t662, ptr %l21, !tbaa !24
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s14)
  br label %bb115
bb115:
  br label %bb88
bb116:
  %t664 = load i64, ptr %l19, !tbaa !24
  %t665 = load i64, ptr %l20, !tbaa !24
  %t668 = sub i64 %t664, %t665
  store i64 %t668, ptr %l24, !tbaa !24
  %t670 = load i64, ptr %l20, !tbaa !24
  %t671 = load i64, ptr %l2, !tbaa !24
  %t674 = icmp slt i64 %t670, %t671
  br i1 %t674, label %bb117, label %bb118
bb117:
  %t676 = load i64, ptr %l2, !tbaa !24
  %t677 = load i64, ptr %l24, !tbaa !24
  %t680 = icmp slt i64 %t676, %t677
  store i1 %t680, ptr %l237, !tbaa !21
  br label %bb119
bb118:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb119
bb119:
  %t682 = load i1, ptr %l237, !tbaa !21
  br i1 %t682, label %bb120, label %bb121
bb120:
  %t683 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t684 = load i64, ptr %l20, !tbaa !24
  %t685 = load i64, ptr %l2, !tbaa !24
  %t686 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2farray_2esortRotate_3ccompiler_2fdoc_3aModule_3e(ptr %v0, { i64, ptr } %t683, i64 %t684, i64 %t685, i64 %t686)
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb123
bb123:
  %t691 = load i64, ptr %l1, !tbaa !24
  %t692 = load i64, ptr %l20, !tbaa !24
  %t695 = icmp slt i64 %t691, %t692
  br i1 %t695, label %bb124, label %bb125
bb124:
  %t697 = load i64, ptr %l20, !tbaa !24
  %t698 = load i64, ptr %l18, !tbaa !24
  %t701 = icmp slt i64 %t697, %t698
  store i1 %t701, ptr %l248, !tbaa !21
  br label %bb126
bb125:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb126
bb126:
  %t703 = load i1, ptr %l248, !tbaa !21
  br i1 %t703, label %bb127, label %bb128
bb127:
  %t704 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t705 = load i64, ptr %l1, !tbaa !24
  %t706 = load i64, ptr %l20, !tbaa !24
  %t707 = load i64, ptr %l18, !tbaa !24
  %t708 = load { ptr, ptr }, ptr %l4
  %t714 = extractvalue { ptr, ptr } %t708, 0
  %t715 = extractvalue { ptr, ptr } %t708, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2fdoc_3aModule_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t704, i64 %t705, i64 %t706, i64 %t707, ptr %t714, ptr %t715)
  br label %bb129
bb128:
  br label %bb131
bb129:
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t716 = load i64, ptr %l18, !tbaa !24
  %t717 = load i64, ptr %l24, !tbaa !24
  %t720 = icmp slt i64 %t716, %t717
  br i1 %t720, label %bb132, label %bb133
bb132:
  %t722 = load i64, ptr %l24, !tbaa !24
  %t723 = load i64, ptr %l3, !tbaa !24
  %t726 = icmp slt i64 %t722, %t723
  store i1 %t726, ptr %l260, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb134
bb134:
  %t728 = load i1, ptr %l260, !tbaa !21
  br i1 %t728, label %bb135, label %bb136
bb135:
  %t729 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t730 = load i64, ptr %l18, !tbaa !24
  %t731 = load i64, ptr %l24, !tbaa !24
  %t732 = load i64, ptr %l3, !tbaa !24
  %t733 = load { ptr, ptr }, ptr %l4
  %t739 = extractvalue { ptr, ptr } %t733, 0
  %t740 = extractvalue { ptr, ptr } %t733, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2fdoc_3aModule_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t729, i64 %t730, i64 %t731, i64 %t732, ptr %t739, ptr %t740)
  br label %bb137
bb136:
  br label %bb139
bb137:
  br label %bb138
bb138:
  br label %bb139
bb139:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortPermute_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/doc:Module"
  %l10 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l69 = alloca %"compiler/doc:Module"
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca %"compiler/doc:Entry"
  %l80 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l20, !tbaa !24
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l17, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb30
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t51, ptr %l38, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t52
  %t57 = load i64, ptr %t56, !tbaa !34
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t65 = icmp eq i64 %t57, %t62
  br i1 %t65, label %bb11, label %bb12
bb11:
  br label %bb29
bb12:
  br label %bb13
bb13:
  %t67 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t67, ptr %l45, !tbaa !27
  %t68 = load i64, ptr %l1, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr %"compiler/doc:Module", ptr %t75, i64 %t72
  %t77 = load %"compiler/doc:Module", ptr %t76
  store %"compiler/doc:Module" zeroinitializer, ptr %t76
  store %"compiler/doc:Module" %t77, ptr %l9
  %t79 = load i64, ptr %l8, !tbaa !24
  store i64 %t79, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t81 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t81, ptr %l51, !tbaa !27
  %t82 = load i64, ptr %l10, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t82
  %t87 = load i64, ptr %t86, !tbaa !34
  store i64 %t87, ptr %l11, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t89, ptr %l54, !tbaa !27
  %t90 = load i64, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l1, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t98 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i64, ptr %t99, i64 %t90
  store i64 %t95, ptr %t100, !tbaa !34
  %t101 = load i64, ptr %l11, !tbaa !24
  %t102 = load i64, ptr %l1, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t109 = icmp eq i64 %t101, %t106
  br i1 %t109, label %bb15, label %bb16
bb15:
  %t111 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t111, ptr %l64, !tbaa !27
  %t112 = load i64, ptr %l1, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = add i64 %t112, %t113
  store i64 %t116, ptr %l67, !tbaa !24
  %t117 = load %"compiler/doc:Module", ptr %l9
  store %"compiler/doc:Module" %t117, ptr %l69
  %t119 = call ptr @__olang_region_make_part(ptr %v0)
  %t120 = ptrtoint ptr %t119 to i64
  store i64 %t120, ptr %l70, !tbaa !24
  %t121 = getelementptr %"compiler/doc:Module", ptr %l69, i32 0, i32 3
  %t122 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l71, !tbaa !24
  %t125 = load i64, ptr %l71, !tbaa !24
  %t126 = mul i64 %t125, 152
  %t127 = load i64, ptr %l70
  %t128 = inttoptr i64 %t127 to ptr
  %t129 = call ptr @__olang_held_alloc(ptr %t128, i64 %t126)
  %t130 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l72, !tbaa !27
  store i64 0, ptr %l73, !tbaa !24
  br label %bb17
bb16:
  br label %bb26
bb17:
  %t132 = load i64, ptr %l73, !tbaa !24
  %t133 = load i64, ptr %l71, !tbaa !24
  %t134 = icmp slt i64 %t132, %t133
  br i1 %t134, label %bb18, label %bb19
bb18:
  %t136 = load i64, ptr %l73, !tbaa !24
  %t137 = getelementptr %"compiler/doc:Module", ptr %l69, i32 0, i32 3
  %t138 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t137, i32 0, i32 1
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = icmp slt i64 %t136, %t139
  br i1 %t140, label %bb22, label %bb20
bb19:
  %t142 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t143 = getelementptr %"compiler/doc:Module", ptr %l69, i32 0, i32 3
  %t144 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t143, i32 0, i32 0
  store { i64, ptr } %t142, ptr %t144, !tbaa !27
  %t145 = getelementptr %"compiler/doc:Module", ptr %l69, i32 0, i32 3
  %t146 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t145, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t150 = icmp eq i64 %t148, 0
  br i1 %t150, label %bb24, label %bb25
bb20:
  %t152 = load i64, ptr %l73, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr %"compiler/doc:Entry", ptr %t154, i64 %t152
  call void @llvm.memset.p0.i64(ptr %t155, i8 0, i64 152, i1 false)
  br label %bb21
bb21:
  %t156 = load i64, ptr %l73, !tbaa !24
  %t157 = add i64 %t156, 1
  store i64 %t157, ptr %l73, !tbaa !24
  br label %bb17
bb22:
  %t158 = getelementptr %"compiler/doc:Module", ptr %l69, i32 0, i32 3
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  %t160 = load i64, ptr %l73, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr %"compiler/doc:Entry", ptr %t162, i64 %t160
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t163, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %l76)
  br label %bb23
bb23:
  %t165 = load i64, ptr %l73, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr %"compiler/doc:Entry", ptr %t167, i64 %t165
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %l76, i64 152, i1 false)
  br label %bb21
bb24:
  %t169 = getelementptr %"compiler/doc:Module", ptr %l69, i32 0, i32 3
  %t170 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t169, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t170, !tbaa !27
  br label %bb25
bb25:
  %t171 = getelementptr %"compiler/doc:Module", ptr %l69, i32 0, i32 3
  %t172 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t171, i32 0, i32 0
  %t173 = load i64, ptr %l70
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = load { i64, ptr }, ptr %t172
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = call ptr @__olang_region_or(ptr %t176, ptr null)
  %t178 = icmp ne ptr %t177, null
  %t179 = select i1 %t178, ptr %t177, ptr null
  call void @__olang_region_settle_in(ptr %t174, ptr %t179)
  %t180 = load %"compiler/doc:Module", ptr %l69
  %t181 = load i64, ptr %l67, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr %"compiler/doc:Module", ptr %t183, i64 %t181
  store %"compiler/doc:Module" %t180, ptr %t184
  br label %bb28
bb26:
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t185, ptr %l80, !tbaa !27
  %t186 = load i64, ptr %l1, !tbaa !24
  %t187 = load i64, ptr %l10, !tbaa !24
  %t190 = add i64 %t186, %t187
  %t191 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t191, ptr %l84, !tbaa !27
  %t192 = load i64, ptr %l11, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr %"compiler/doc:Module", ptr %t195, i64 %t192
  %t197 = load %"compiler/doc:Module", ptr %t196
  store %"compiler/doc:Module" zeroinitializer, ptr %t196
  %t200 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr %"compiler/doc:Module", ptr %t201, i64 %t190
  store %"compiler/doc:Module" %t197, ptr %t202
  %t203 = load i64, ptr %l11, !tbaa !24
  %t204 = load i64, ptr %l1, !tbaa !24
  %t207 = sub i64 %t203, %t204
  store i64 %t207, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  br label %bb14
bb28:
  br label %bb29
bb29:
  %t209 = load i64, ptr %l7, !tbaa !24
  %t212 = add i64 %t209, 1
  store i64 %t212, ptr %l7, !tbaa !24
  br label %bb7
bb30:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortRotate_3ccompiler_2fdoc_3aModule_3e(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l82 = alloca i64
  %l85 = alloca i64
  %l127 = alloca i64
  %l130 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t5 = sub i64 %t1, %a1
  store i64 %t5, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = sub i64 %a3, %t8
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp ne i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb35
bb3:
  br label %bb4
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i64 0, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l12, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  store i64 %t35, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb20, label %bb21
bb7:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l44, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l41, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l11, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = load i64, ptr %l2, !tbaa !24
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t93 = load i64, ptr %l2, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = add i64 %t93, %t94
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fdoc_3aModule_3e(ptr %v0, { i64, ptr } %t83, i64 %t92, i64 %t97)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l10, !tbaa !24
  br label %bb13
bb19:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t106, %t108
  store i64 %t111, ptr %l4, !tbaa !24
  br label %bb33
bb20:
  %t113 = load i64, ptr %l14, !tbaa !24
  %t115 = icmp sgt i64 %t113, 0
  br i1 %t115, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb25
bb22:
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sub i64 %t117, %t118
  %t122 = load i64, ptr %l14, !tbaa !24
  %t125 = add i64 %t121, %t122
  %t127 = sub i64 %t125, 1
  %t128 = load i64, ptr %l14, !tbaa !24
  %t131 = sdiv i64 %t127, %t128
  store i64 %t131, ptr %l85, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb24
bb24:
  %t133 = load i64, ptr %l85, !tbaa !24
  store i64 %t133, ptr %l82, !tbaa !24
  br label %bb25
bb25:
  %t134 = load i64, ptr %l82, !tbaa !24
  store i64 %t134, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb26
bb26:
  %t135 = load i64, ptr %l16, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t143 = load i64, ptr %l12, !tbaa !24
  %t144 = load i64, ptr %l16, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = mul i64 %t144, %t145
  %t151 = add i64 %t143, %t148
  store i64 %t151, ptr %l17, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t154 = load i64, ptr %l2, !tbaa !24
  %t155 = load i64, ptr %l4, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l17, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t163 = load i64, ptr %l2, !tbaa !24
  %t164 = load i64, ptr %l5, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t168 = load i64, ptr %l4, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t172 = load i64, ptr %l17, !tbaa !24
  %t175 = add i64 %t171, %t172
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fdoc_3aModule_3e(ptr %v0, { i64, ptr } %t153, i64 %t162, i64 %t175)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l16, !tbaa !24
  br label %bb26
bb32:
  %t184 = load i64, ptr %l5, !tbaa !24
  %t186 = load i64, ptr %l4, !tbaa !24
  %t189 = sub i64 %t184, %t186
  store i64 %t189, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb1
bb35:
  store i64 0, ptr %l18, !tbaa !24
  %t191 = load i64, ptr %l4, !tbaa !24
  store i64 %t191, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t193 = load i64, ptr %l19, !tbaa !24
  %t194 = load i64, ptr %l18, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb36, label %bb37
bb36:
  %t199 = load i64, ptr %l20, !tbaa !24
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb41
bb38:
  %t203 = load i64, ptr %l19, !tbaa !24
  %t204 = load i64, ptr %l18, !tbaa !24
  %t207 = sub i64 %t203, %t204
  %t208 = load i64, ptr %l20, !tbaa !24
  %t211 = add i64 %t207, %t208
  %t213 = sub i64 %t211, 1
  %t214 = load i64, ptr %l20, !tbaa !24
  %t217 = sdiv i64 %t213, %t214
  store i64 %t217, ptr %l130, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb40
bb40:
  %t219 = load i64, ptr %l130, !tbaa !24
  store i64 %t219, ptr %l127, !tbaa !24
  br label %bb41
bb41:
  %t220 = load i64, ptr %l127, !tbaa !24
  store i64 %t220, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb42
bb42:
  %t221 = load i64, ptr %l22, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t229 = load i64, ptr %l18, !tbaa !24
  %t230 = load i64, ptr %l22, !tbaa !24
  %t231 = load i64, ptr %l20, !tbaa !24
  %t234 = mul i64 %t230, %t231
  %t237 = add i64 %t229, %t234
  store i64 %t237, ptr %l23, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t240 = load i64, ptr %l2, !tbaa !24
  %t241 = load i64, ptr %l4, !tbaa !24
  %t244 = sub i64 %t240, %t241
  %t245 = load i64, ptr %l23, !tbaa !24
  %t248 = add i64 %t244, %t245
  %t249 = load i64, ptr %l2, !tbaa !24
  %t250 = load i64, ptr %l23, !tbaa !24
  %t253 = add i64 %t249, %t250
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fdoc_3aModule_3e(ptr %v0, { i64, ptr } %t239, i64 %t248, i64 %t253)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t257 = load i64, ptr %l22, !tbaa !24
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %l22, !tbaa !24
  br label %bb42
bb48:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eToArray_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"compiler/doc:Module"
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l23 = alloca %"compiler/doc:Module"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l30 = alloca %"compiler/doc:Entry"
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l65 = alloca %"compiler/doc:Module"
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca %"compiler/doc:Entry"
  %l76 = alloca %"compiler/doc:Module"
  %l77 = alloca i64
  %rv = alloca { i64, ptr }
  %t37 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t10 = icmp sle i64 0, 115292150460684697
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_71b15b09f79ee26d_302669a3f0377e79)
  unreachable
bb5:
  %t12 = mul i64 0, 80
  %t13 = insertvalue { i64, ptr } undef, i64 0, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_71b15b09f79ee26d_302669a3f0377e79)
  unreachable
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l15, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t20, i32 0, i32 0
  %t23 = getelementptr { i64, ptr }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/doc:Module", ptr %t24, i64 0
  %t26 = load %"compiler/doc:Module", ptr %t25
  store %"compiler/doc:Module" %t26, ptr %l17
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = icmp sge i64 %t27, 0
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load i64, ptr %l15, !tbaa !24
  %t31 = icmp sle i64 %t30, 115292150460684697
  br i1 %t31, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c29104ce98cd7d40_f96243c7193eaec)
  unreachable
bb10:
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = mul i64 %t33, 80
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = load %"compiler/doc:Module", ptr %l17
  store i64 0, ptr %t37
  br label %fill.38
fill.38:
  %t41 = load i64, ptr %t37
  %t42 = icmp slt i64 %t41, %t33
  br i1 %t42, label %fillb.39, label %filld.40
fillb.39:
  %t43 = getelementptr %"compiler/doc:Module", ptr %t35, i64 %t41
  store %"compiler/doc:Module" %t36, ptr %t43
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %t37
  br label %fill.38
filld.40:
  %t45 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t35, 1
  store { i64, ptr } %t46, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c29104ce98cd7d40_f96243c7193eaec)
  unreachable
bb12:
  %t47 = load i64, ptr %l21, !tbaa !24
  %t48 = load i64, ptr %l15, !tbaa !24
  %t49 = icmp slt i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load %"compiler/doc:Module", ptr %l17
  store %"compiler/doc:Module" %t51, ptr %l23
  %t52 = call ptr @__olang_region_make_part(ptr %v1)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l24, !tbaa !24
  %t54 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t54, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l25, !tbaa !24
  %t58 = load i64, ptr %l25, !tbaa !24
  %t59 = mul i64 %t58, 152
  %t60 = load i64, ptr %l24
  %t61 = inttoptr i64 %t60 to ptr
  %t62 = call ptr @__olang_held_alloc(ptr %t61, i64 %t59)
  %t63 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  br label %bb15
bb14:
  %t65 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t65, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t66, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb24, label %bb25
bb15:
  %t77 = load i64, ptr %l27, !tbaa !24
  %t78 = load i64, ptr %l25, !tbaa !24
  %t79 = icmp slt i64 %t77, %t78
  br i1 %t79, label %bb16, label %bb17
bb16:
  %t81 = load i64, ptr %l27, !tbaa !24
  %t82 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t83 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = icmp slt i64 %t81, %t84
  br i1 %t85, label %bb20, label %bb18
bb17:
  %t87 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t88 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t89 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t91 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t90, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t95 = icmp eq i64 %t93, 0
  br i1 %t95, label %bb22, label %bb23
bb18:
  %t97 = load i64, ptr %l27, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"compiler/doc:Entry", ptr %t99, i64 %t97
  call void @llvm.memset.p0.i64(ptr %t100, i8 0, i64 152, i1 false)
  br label %bb19
bb19:
  %t101 = load i64, ptr %l27, !tbaa !24
  %t102 = add i64 %t101, 1
  store i64 %t102, ptr %l27, !tbaa !24
  br label %bb15
bb20:
  %t103 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t104 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t103, i32 0, i32 0
  %t105 = load i64, ptr %l27, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr %"compiler/doc:Entry", ptr %t107, i64 %t105
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t108, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v1, ptr %l30)
  br label %bb21
bb21:
  %t110 = load i64, ptr %l27, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr %"compiler/doc:Entry", ptr %t112, i64 %t110
  call void @llvm.memmove.p0.p0.i64(ptr %t113, ptr %l30, i64 152, i1 false)
  br label %bb19
bb22:
  %t114 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t115 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t114, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t115, !tbaa !27
  br label %bb23
bb23:
  %t116 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t117 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t116, i32 0, i32 0
  %t118 = load i64, ptr %l24
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = load { i64, ptr }, ptr %t117
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = icmp ne ptr %t122, null
  %t124 = select i1 %t123, ptr %t122, ptr null
  call void @__olang_region_settle_in(ptr %t119, ptr %t124)
  %t125 = load %"compiler/doc:Module", ptr %l23
  %t126 = load i64, ptr %l21, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr %"compiler/doc:Module", ptr %t128, i64 %t126
  store %"compiler/doc:Module" %t125, ptr %t129
  %t130 = load i64, ptr %l21, !tbaa !24
  %t131 = add i64 %t130, 1
  store i64 %t131, ptr %l21, !tbaa !24
  br label %bb12
bb24:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t134 = icmp sgt i64 %t132, 0
  br i1 %t134, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb29
bb26:
  %t136 = load i64, ptr %l3, !tbaa !24
  %t137 = load i64, ptr %l2, !tbaa !24
  %t140 = sub i64 %t136, %t137
  %t141 = load i64, ptr %l4, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = sub i64 %t144, 1
  %t147 = load i64, ptr %l4, !tbaa !24
  %t150 = sdiv i64 %t146, %t147
  store i64 %t150, ptr %l42, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb28
bb28:
  %t152 = load i64, ptr %l42, !tbaa !24
  store i64 %t152, ptr %l39, !tbaa !24
  br label %bb29
bb29:
  %t153 = load i64, ptr %l39, !tbaa !24
  store i64 %t153, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb30
bb30:
  %t154 = load i64, ptr %l6, !tbaa !24
  %t155 = load i64, ptr %l5, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb31, label %bb32
bb31:
  br label %bb48
bb32:
  br label %bb33
bb33:
  %t162 = load i64, ptr %l2, !tbaa !24
  %t163 = load i64, ptr %l6, !tbaa !24
  %t164 = load i64, ptr %l4, !tbaa !24
  %t167 = mul i64 %t163, %t164
  %t170 = add i64 %t162, %t167
  store i64 %t170, ptr %l7, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t172, ptr %l60, !tbaa !27
  %t173 = load i64, ptr %l7, !tbaa !24
  store i64 %t173, ptr %l61, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i64, ptr %l7, !tbaa !24
  %t177 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t174, i32 0, i32 0
  %t179 = getelementptr { i64, ptr }, ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr %"compiler/doc:Module", ptr %t180, i64 %t175
  %t182 = load %"compiler/doc:Module", ptr %t181
  store %"compiler/doc:Module" %t182, ptr %l65
  %t184 = call ptr @__olang_region_make_part(ptr %v1)
  %t185 = ptrtoint ptr %t184 to i64
  store i64 %t185, ptr %l66, !tbaa !24
  %t186 = getelementptr %"compiler/doc:Module", ptr %l65, i32 0, i32 3
  %t187 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t186, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l67, !tbaa !24
  %t190 = load i64, ptr %l67, !tbaa !24
  %t191 = mul i64 %t190, 152
  %t192 = load i64, ptr %l66
  %t193 = inttoptr i64 %t192 to ptr
  %t194 = call ptr @__olang_held_alloc(ptr %t193, i64 %t191)
  %t195 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l68, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  br label %bb34
bb34:
  %t197 = load i64, ptr %l69, !tbaa !24
  %t198 = load i64, ptr %l67, !tbaa !24
  %t199 = icmp slt i64 %t197, %t198
  br i1 %t199, label %bb35, label %bb36
bb35:
  %t201 = load i64, ptr %l69, !tbaa !24
  %t202 = getelementptr %"compiler/doc:Module", ptr %l65, i32 0, i32 3
  %t203 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t202, i32 0, i32 1
  %t204 = load i64, ptr %t203, !tbaa !24
  %t205 = icmp slt i64 %t201, %t204
  br i1 %t205, label %bb39, label %bb37
bb36:
  %t207 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t208 = getelementptr %"compiler/doc:Module", ptr %l65, i32 0, i32 3
  %t209 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t208, i32 0, i32 0
  store { i64, ptr } %t207, ptr %t209, !tbaa !27
  %t210 = getelementptr %"compiler/doc:Module", ptr %l65, i32 0, i32 3
  %t211 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t210, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t215 = icmp eq i64 %t213, 0
  br i1 %t215, label %bb41, label %bb42
bb37:
  %t217 = load i64, ptr %l69, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr %"compiler/doc:Entry", ptr %t219, i64 %t217
  call void @llvm.memset.p0.i64(ptr %t220, i8 0, i64 152, i1 false)
  br label %bb38
bb38:
  %t221 = load i64, ptr %l69, !tbaa !24
  %t222 = add i64 %t221, 1
  store i64 %t222, ptr %l69, !tbaa !24
  br label %bb34
bb39:
  %t223 = getelementptr %"compiler/doc:Module", ptr %l65, i32 0, i32 3
  %t224 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t223, i32 0, i32 0
  %t225 = load i64, ptr %l69, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr %"compiler/doc:Entry", ptr %t227, i64 %t225
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t228, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v1, ptr %l72)
  br label %bb40
bb40:
  %t230 = load i64, ptr %l69, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr %"compiler/doc:Entry", ptr %t232, i64 %t230
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %l72, i64 152, i1 false)
  br label %bb38
bb41:
  %t234 = getelementptr %"compiler/doc:Module", ptr %l65, i32 0, i32 3
  %t235 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t234, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t235, !tbaa !27
  br label %bb42
bb42:
  %t236 = getelementptr %"compiler/doc:Module", ptr %l65, i32 0, i32 3
  %t237 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t236, i32 0, i32 0
  %t238 = load i64, ptr %l66
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = load { i64, ptr }, ptr %t237
  %t241 = extractvalue { i64, ptr } %t240, 1
  %t242 = call ptr @__olang_region_or(ptr %t241, ptr null)
  %t243 = icmp ne ptr %t242, null
  %t244 = select i1 %t243, ptr %t242, ptr null
  call void @__olang_region_settle_in(ptr %t239, ptr %t244)
  %t245 = load i64, ptr %l61, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr %"compiler/doc:Module", ptr %t247, i64 %t245
  %t249 = load %"compiler/doc:Module", ptr %t248
  store %"compiler/doc:Module" %t249, ptr %l76
  %t250 = load %"compiler/doc:Module", ptr %l65
  %t251 = load i64, ptr %l61, !tbaa !24
  %t252 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr %"compiler/doc:Module", ptr %t253, i64 %t251
  store %"compiler/doc:Module" %t250, ptr %t254
  store i64 0, ptr %l77, !tbaa !24
  br label %bb43
bb43:
  %t255 = load i64, ptr %l77, !tbaa !24
  %t256 = getelementptr %"compiler/doc:Module", ptr %l76, i32 0, i32 3
  %t257 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t256, i32 0, i32 1
  %t258 = load i64, ptr %t257, !tbaa !24
  %t259 = icmp slt i64 %t255, %t258
  br i1 %t259, label %bb44, label %bb45
bb44:
  %t261 = getelementptr %"compiler/doc:Module", ptr %l76, i32 0, i32 3
  %t262 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t261, i32 0, i32 0
  %t263 = load i64, ptr %l77, !tbaa !24
  %t264 = getelementptr { i64, ptr }, ptr %t262, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr %"compiler/doc:Entry", ptr %t265, i64 %t263
  call void @olang_2emir_2eHelperKind_2eRelease_2ecompiler_2fdoc_3aEntry(ptr %t266)
  br label %bb46
bb45:
  %t268 = getelementptr %"compiler/doc:Module", ptr %l76, i32 0, i32 3
  %t269 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t268, i32 0, i32 0
  %t270 = load { i64, ptr }, ptr %t269
  %t271 = extractvalue { i64, ptr } %t270, 0
  %t272 = extractvalue { i64, ptr } %t270, 1
  call void @__olang_region_release_part(ptr %t272, i64 %t271)
  store { i64, ptr } zeroinitializer, ptr %t269
  br label %bb47
bb46:
  %t273 = load i64, ptr %l77, !tbaa !24
  %t274 = add i64 %t273, 1
  store i64 %t274, ptr %l77, !tbaa !24
  br label %bb43
bb47:
  %t275 = load i64, ptr %l6, !tbaa !24
  %t278 = add i64 %t275, 1
  store i64 %t278, ptr %l6, !tbaa !24
  br label %bb30
bb48:
  %t280 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t280, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2eroom_3ccompiler_2fsession_3aUse_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b14bf40ea480b614_26de4cf54edeeb08)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b14bf40ea480b614_26de4cf54edeeb08)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/session:Use", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b14bf40ea480b614_26de4cf54edeeb08)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/session:Use", ptr %t132, i64 %t129
  %t134 = load %"compiler/session:Use", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/session:Use", ptr %t138, i64 %t136
  store %"compiler/session:Use" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { ptr, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca %"compiler/doc:Module"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca %"compiler/doc:Entry"
  %l20 = alloca { i64, ptr }
  %l23 = alloca %"compiler/doc:Module"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l30 = alloca %"compiler/doc:Entry"
  %l34 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { ptr, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  store { i64, ptr } %cv1, ptr %l3
  %vq0 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { ptr, ptr } %cv0, ptr %l5
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l6, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/doc:Module", ptr %t6, i64 %a0
  %t8 = load %"compiler/doc:Module", ptr %t7
  store %"compiler/doc:Module" %t8, ptr %l9
  %t10 = call ptr @__olang_region_make_part(ptr %s0)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = getelementptr %"compiler/doc:Module", ptr %l9, i32 0, i32 3
  %t13 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l11, !tbaa !24
  %t16 = load i64, ptr %l11, !tbaa !24
  %t17 = mul i64 %t16, 152
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  %t21 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  br label %bb1
bb1:
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = getelementptr %"compiler/doc:Module", ptr %l9, i32 0, i32 3
  %t29 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t28, i32 0, i32 1
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = icmp slt i64 %t27, %t30
  br i1 %t31, label %bb6, label %bb4
bb3:
  %t33 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t34 = getelementptr %"compiler/doc:Module", ptr %l9, i32 0, i32 3
  %t35 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t34, i32 0, i32 0
  store { i64, ptr } %t33, ptr %t35, !tbaa !27
  %t36 = getelementptr %"compiler/doc:Module", ptr %l9, i32 0, i32 3
  %t37 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t36, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb8, label %bb9
bb4:
  %t43 = load i64, ptr %l13, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr %"compiler/doc:Entry", ptr %t45, i64 %t43
  call void @llvm.memset.p0.i64(ptr %t46, i8 0, i64 152, i1 false)
  br label %bb5
bb5:
  %t47 = load i64, ptr %l13, !tbaa !24
  %t48 = add i64 %t47, 1
  store i64 %t48, ptr %l13, !tbaa !24
  br label %bb1
bb6:
  %t49 = getelementptr %"compiler/doc:Module", ptr %l9, i32 0, i32 3
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t49, i32 0, i32 0
  %t51 = load i64, ptr %l13, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr %"compiler/doc:Entry", ptr %t53, i64 %t51
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t54, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s0, ptr %l16)
  br label %bb7
bb7:
  %t56 = load i64, ptr %l13, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/doc:Entry", ptr %t58, i64 %t56
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %l16, i64 152, i1 false)
  br label %bb5
bb8:
  %t60 = getelementptr %"compiler/doc:Module", ptr %l9, i32 0, i32 3
  %t61 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t61, !tbaa !27
  br label %bb9
bb9:
  %t62 = getelementptr %"compiler/doc:Module", ptr %l9, i32 0, i32 3
  %t63 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %l10
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = load { i64, ptr }, ptr %t63
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = call ptr @__olang_region_or(ptr %t67, ptr null)
  %t69 = icmp ne ptr %t68, null
  %t70 = select i1 %t69, ptr %t68, ptr null
  call void @__olang_region_settle_in(ptr %t65, ptr %t70)
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l20, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr %"compiler/doc:Module", ptr %t75, i64 %a1
  %t77 = load %"compiler/doc:Module", ptr %t76
  store %"compiler/doc:Module" %t77, ptr %l23
  %t79 = call ptr @__olang_region_make_part(ptr %s0)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l24, !tbaa !24
  %t81 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t82 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t81, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l25, !tbaa !24
  %t85 = load i64, ptr %l25, !tbaa !24
  %t86 = mul i64 %t85, 152
  %t87 = load i64, ptr %l24
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = call ptr @__olang_held_alloc(ptr %t88, i64 %t86)
  %t90 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t92 = load i64, ptr %l27, !tbaa !24
  %t93 = load i64, ptr %l25, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  br i1 %t94, label %bb11, label %bb12
bb11:
  %t96 = load i64, ptr %l27, !tbaa !24
  %t97 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = icmp slt i64 %t96, %t99
  br i1 %t100, label %bb15, label %bb13
bb12:
  %t102 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t103 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t104 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t103, i32 0, i32 0
  store { i64, ptr } %t102, ptr %t104, !tbaa !27
  %t105 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t106 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t105, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t110 = icmp eq i64 %t108, 0
  br i1 %t110, label %bb17, label %bb18
bb13:
  %t112 = load i64, ptr %l27, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr %"compiler/doc:Entry", ptr %t114, i64 %t112
  call void @llvm.memset.p0.i64(ptr %t115, i8 0, i64 152, i1 false)
  br label %bb14
bb14:
  %t116 = load i64, ptr %l27, !tbaa !24
  %t117 = add i64 %t116, 1
  store i64 %t117, ptr %l27, !tbaa !24
  br label %bb10
bb15:
  %t118 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t119 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t120 = load i64, ptr %l27, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/doc:Entry", ptr %t122, i64 %t120
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t123, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %s0, ptr %l30)
  br label %bb16
bb16:
  %t125 = load i64, ptr %l27, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr %"compiler/doc:Entry", ptr %t127, i64 %t125
  call void @llvm.memmove.p0.p0.i64(ptr %t128, ptr %l30, i64 152, i1 false)
  br label %bb14
bb17:
  %t129 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t130 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t129, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t130, !tbaa !27
  br label %bb18
bb18:
  %t131 = getelementptr %"compiler/doc:Module", ptr %l23, i32 0, i32 3
  %t132 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t131, i32 0, i32 0
  %t133 = load i64, ptr %l24
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = load { i64, ptr }, ptr %t132
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = call ptr @__olang_region_or(ptr %t136, ptr null)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr null
  call void @__olang_region_settle_in(ptr %t134, ptr %t139)
  %t140 = load { ptr, ptr }, ptr %l5
  %t141 = extractvalue { ptr, ptr } %t140, 0
  %t142 = extractvalue { ptr, ptr } %t140, 1
  %t143 = load %"compiler/doc:Module", ptr %l9
  %t144 = load %"compiler/doc:Module", ptr %l23
  %t145 = call i1 %t141(ptr %t142, ptr %s0, ptr %s0, %"compiler/doc:Module" %t143, %"compiler/doc:Module" %t144)
  store i1 %t145, ptr %l34
  br label %bb19
bb19:
  %t146 = load i1, ptr %l34, !tbaa !21
  store i1 %t146, ptr %l4, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load i1, ptr %l4, !tbaa !21
  store i1 %t147, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca %"compiler/doc:Entry"
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make_part(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/doc:Entry", ptr %t7, i32 0, i32 5
  %t9 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t8, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = mul i64 %t12, 152
  %t14 = load i64, ptr %l1
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  %t17 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/doc:Entry", ptr %t24, i32 0, i32 5
  %t26 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t25, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = icmp slt i64 %t23, %t27
  br i1 %t28, label %bb8, label %bb6
bb5:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/doc:Entry", ptr %t31, i32 0, i32 5
  %t33 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t32, i32 0, i32 0
  store { i64, ptr } %t30, ptr %t33, !tbaa !27
  %t34 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t34, label %bb10, label %bb11
bb6:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr %"compiler/doc:Entry", ptr %t38, i64 %t36
  call void @llvm.memset.p0.i64(ptr %t39, i8 0, i64 152, i1 false)
  br label %bb7
bb7:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = add i64 %t40, 1
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb3
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/doc:Entry", ptr %t42, i32 0, i32 5
  %t44 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 0
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/doc:Entry", ptr %t47, i64 %t45
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t48, i64 152, i1 false)
  call void @olang_2emir_2eHelperKind_2eSplit_2ecompiler_2fdoc_3aEntry(ptr %v0, ptr %l8)
  br label %bb9
bb9:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr %"compiler/doc:Entry", ptr %t52, i64 %t50
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %l8, i64 152, i1 false)
  br label %bb7
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/doc:Entry", ptr %t54, i32 0, i32 5
  %t56 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t55, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t60 = icmp eq i64 %t58, 0
  br i1 %t60, label %bb12, label %bb13
bb11:
  %t62 = call ptr @__olang_scope_hold(ptr %v0)
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l13, !tbaa !24
  %t64 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t64, label %bb14, label %bb15
bb12:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/doc:Entry", ptr %t66, i32 0, i32 5
  %t68 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t67, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t68, !tbaa !27
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/doc:Entry", ptr %t69, i32 0, i32 5
  %t71 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %l1
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = load { i64, ptr }, ptr %t71
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = call ptr @__olang_region_or(ptr %t75, ptr null)
  %t77 = icmp ne ptr %t76, null
  %t78 = select i1 %t77, ptr %t76, ptr null
  call void @__olang_region_settle_in(ptr %t73, ptr %t78)
  br label %bb11
bb14:
  %t79 = call ptr @__olang_region_make_part(ptr %v0)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l13, !tbaa !24
  br label %bb15
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/doc:Entry", ptr %t81, i32 0, i32 7
  %t83 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 32
  %t89 = load i64, ptr %l13
  %t90 = inttoptr i64 %t89 to ptr
  %t91 = call ptr @__olang_held_alloc(ptr %t90, i64 %t88)
  %t92 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l17, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l16, !tbaa !24
  %t99 = mul i64 %t98, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %t97, i64 %t99, i1 false)
  %t100 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/doc:Entry", ptr %t101, i32 0, i32 7
  %t103 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t102, i32 0, i32 0
  store { i64, ptr } %t100, ptr %t103, !tbaa !27
  %t104 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t104, label %bb16, label %bb17
bb16:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/doc:Entry", ptr %t106, i32 0, i32 7
  %t108 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t107, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb18, label %bb19
bb17:
  br label %ret
bb18:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/doc:Entry", ptr %t114, i32 0, i32 7
  %t116 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t115, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t116, !tbaa !27
  br label %bb19
bb19:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/doc:Entry", ptr %t117, i32 0, i32 7
  %t119 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t120 = load i64, ptr %l13
  %t121 = inttoptr i64 %t120 to ptr
  %t122 = load { i64, ptr }, ptr %t119
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = icmp ne ptr %t124, null
  %t126 = select i1 %t125, ptr %t124, ptr null
  call void @__olang_region_settle_in(ptr %t121, ptr %t126)
  br label %bb17
ret:
  ret void
}

declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr void @olang_2emir_2eHelperKind_2eRelease_2ecompiler_2fdoc_3aEntry(ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e5
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/doc:Entry", ptr %t3, i32 0, i32 5
  %t5 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = call ptr @__olang_region_or(ptr %t7, ptr null)
  %t9 = call ptr @__olang_region_home(ptr %t8)
  %t10 = icmp ne ptr %t9, null
  %t11 = select i1 %t10, ptr %t9, ptr null
  call void @__olang_region_drop(ptr %t11)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t4
  br label %bb2
bb2:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aEntry_2e7
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/doc:Entry", ptr %t14, i32 0, i32 7
  %t16 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  call void @__olang_region_drop(ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t15
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/doc:Entry", ptr %t24, i32 0, i32 5
  %t26 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t25, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = icmp slt i64 %t23, %t27
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/doc:Entry", ptr %t30, i32 0, i32 5
  %t32 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/doc:Entry", ptr %t35, i64 %t33
  call void @olang_2emir_2eHelperKind_2eRelease_2ecompiler_2fdoc_3aEntry(ptr %t36)
  br label %bb8
bb7:
  %t38 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0
  br i1 %t38, label %bb9, label %bb10
bb8:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t40, 1
  store i64 %t41, ptr %l3, !tbaa !24
  br label %bb5
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/doc:Entry", ptr %t42, i32 0, i32 5
  %t44 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  call void @__olang_region_release_part(ptr %t47, i64 %t46)
  store { i64, ptr } zeroinitializer, ptr %t44
  br label %bb10
bb10:
  %t48 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/doc:Entry", ptr %t50, i32 0, i32 7
  %t52 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t51, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52
  %t54 = extractvalue { i64, ptr } %t53, 0
  %t55 = extractvalue { i64, ptr } %t53, 1
  call void @__olang_region_release_part(ptr %t55, i64 %t54)
  store { i64, ptr } zeroinitializer, ptr %t52
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

declare void @__olang_region_release_part(ptr, i64) noinline
declare ptr @__olang_grow_in_place(ptr, i64, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aEntry_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2e0 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2ecompiler_2fdoc_3aEntry_2e7 = weak hidden constant i1 false
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare ptr @__olang_scope_mine_slow(ptr) noinline
@G_2estd_2fprelude_2farray_2esortRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2farray_2esortInsertion_3ccompiler_2fdoc_3aModule_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, ptr %a3c, ptr %a3e)
@G_2estd_2fprelude_2farray_2esortBlock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\30\00\00\00\00\00\00" }>, align 8
@olang_loc_c022e58ec96da978_ec8311c98a19dd54 = external constant [0 x i8]
@olang_loc_58e30339dc525c65_8ff29672c8905379 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e_clone1_olang_lambda_17278(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fdoc_3aModule_3e(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_71b15b09f79ee26d_302669a3f0377e79 = external constant [0 x i8]
@olang_loc_c29104ce98cd7d40_f96243c7193eaec = external constant [0 x i8]
@olang_loc_b14bf40ea480b614_26de4cf54edeeb08 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
