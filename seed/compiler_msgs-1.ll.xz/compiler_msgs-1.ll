; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAlreadyDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 654, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 567, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 186, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyMethodObligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 181, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l10 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t3, 1
  %t20 = extractvalue { i64, ptr } %t3, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t4, 1
  %t27 = extractvalue { i64, ptr } %t4, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 180, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d15, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l10
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l10
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNoCopy(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 183, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNoMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 182, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 189, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmetMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 178, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d28, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eApiNoFiles(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 831, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eApiNoSide(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 830, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t7 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t20 = add i64 %t17, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t4, i64 %t5)
  %t22 = getelementptr i8, ptr %t21, i64 %t5
  %t23 = call i64 @__olang_fmt_i64(ptr %t22, i64 %a0)
  %t24 = getelementptr i8, ptr %t22, i64 %t7
  call void @olang_textcopy(ptr %t24, ptr %t9, i64 %t10)
  %t25 = getelementptr i8, ptr %t24, i64 %t10
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %a1)
  %t27 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t27, ptr %t15, i64 %t16)
  %t28 = getelementptr i8, ptr %t27, i64 %t16
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t21, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 328, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 485, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  call void @olang_textcopy(ptr %t7, ptr %t2, i64 %t3)
  %t8 = getelementptr i8, ptr %t7, i64 %t3
  %t9 = call i64 @__olang_fmt_i64(ptr %t8, i64 %a0)
  %t10 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t7, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 156, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArraySizeMismatch(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t3, i64 %t4)
  %t18 = getelementptr i8, ptr %t17, i64 %t4
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a0)
  %t20 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t20, ptr %t8, i64 %t9)
  %t21 = getelementptr i8, ptr %t20, i64 %t9
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %a1)
  %t23 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t17, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 297, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTypeHoldsItself(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 147, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d51, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 152, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d52, i32 0, i32 1) }, { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 675, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseWritten(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 134, ptr getelementptr inbounds (<{ i64, [134 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 134, ptr getelementptr inbounds (<{ i64, [134 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 676, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgReturns(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 677, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d59, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t5 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t9 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t5, i64 %t6)
  %t14 = getelementptr i8, ptr %t13, i64 %t6
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %a1)
  %t16 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t11, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 538, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d61, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 492, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d63, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 512, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 362, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrNotBuilt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 807, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d70, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrPlace(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 803, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d71, i32 0, i32 1) }, { i64, ptr } { i64 140, ptr getelementptr inbounds (<{ i64, [140 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrPun(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 804, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d75, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBadEscape(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 68, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 838}
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d78, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 526, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d79, i32 0, i32 1) }, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 719, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d83, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeErrors(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 718, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeMemory(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 717, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d88, i32 0, i32 1) }, { i64, ptr } { i64 158, ptr getelementptr inbounds (<{ i64, [158 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeNotCall(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 715, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeOutside(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 712, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d95, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeTry(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 714, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, { i64, ptr } { i64 99, ptr getelementptr inbounds (<{ i64, [99 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBinDigit(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 72, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 838}
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBinNoDigits(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 70, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) }, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t3, i64 %t4)
  %t16 = getelementptr i8, ptr %t15, i64 %t4
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %a0)
  %t18 = getelementptr i8, ptr %t16, i64 %t6
  call void @olang_textcopy(ptr %t18, ptr %t8, i64 %t9)
  %t19 = getelementptr i8, ptr %t18, i64 %t9
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t15, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 77, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d105, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBorrowSplitScopes(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 331, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } { i64 136, ptr getelementptr inbounds (<{ i64, [136 x i8] }>, ptr @.d107, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBorrowSplitValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 333, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d108, i32 0, i32 1) }, { i64, ptr } { i64 114, ptr getelementptr inbounds (<{ i64, [114 x i8] }>, ptr @.d109, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBoundTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 566, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d111, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBreakOutsideLoop(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 656, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d113, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 129, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d115, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t5, i64 %t6)
  %t33 = getelementptr i8, ptr %t32, i64 %t6
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t11, i64 %t12)
  %t35 = getelementptr i8, ptr %t34, i64 %t12
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t18, i64 %t19)
  %t37 = getelementptr i8, ptr %t36, i64 %t19
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t25, i64 %t26)
  %t39 = getelementptr i8, ptr %t38, i64 %t26
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 132, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d120, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildIntoUnknownScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 322, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d121, i32 0, i32 1) }, { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuiltinTypeRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 127, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d124, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCFileNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 220, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d126, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCNoForm(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 222, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d129, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerReadOnly(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 223, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d132, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallDoesNothing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 476, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d135, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t6, i64 %t7)
  %t30 = getelementptr i8, ptr %t29, i64 %t7
  call void @olang_textcopy(ptr %t30, ptr %t8, i64 %t9)
  %t31 = getelementptr i8, ptr %t30, i64 %t9
  call void @olang_textcopy(ptr %t31, ptr %t12, i64 %t13)
  %t32 = getelementptr i8, ptr %t31, i64 %t13
  call void @olang_textcopy(ptr %t32, ptr %t15, i64 %t16)
  %t33 = getelementptr i8, ptr %t32, i64 %t16
  call void @olang_textcopy(ptr %t33, ptr %t19, i64 %t20)
  %t34 = getelementptr i8, ptr %t33, i64 %t20
  call void @olang_textcopy(ptr %t34, ptr %t22, i64 %t23)
  %t35 = getelementptr i8, ptr %t34, i64 %t23
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t29, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  %t47 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 648, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d139, i32 0, i32 1) }, { i64, ptr } %t44)
  store %"compiler/msgs:Msg" %t47, ptr %l11
  br label %bb1
bb1:
  %t48 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 142, ptr getelementptr inbounds (<{ i64, [142 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 142, ptr getelementptr inbounds (<{ i64, [142 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 647, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d141, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallbackNotExport(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 210, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d142, i32 0, i32 1) }, { i64, ptr } { i64 111, ptr getelementptr inbounds (<{ i64, [111 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 18, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d145, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaptureReadOnly(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 384, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) }, { i64, ptr } { i64 84, ptr getelementptr inbounds (<{ i64, [84 x i8] }>, ptr @.d147, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCarriageReturn(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 59, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d148, i32 0, i32 1) }, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d149, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseAfterWildcard(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 582, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 115, ptr getelementptr inbounds (<{ i64, [115 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 115, ptr getelementptr inbounds (<{ i64, [115 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 584, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestNotEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 472, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d155, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestOther(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 473, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d158, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTypeArgsNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l19 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 504, ptr %l2
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = add i64 %t6, 1
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t9, 0
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l8, !tbaa !24
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  br i1 %t20, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_78fb4d3249708b2_e3f9318f90ab6b26)
  unreachable
bb3:
  %t22 = load i64, ptr %l11, !tbaa !24
  %t23 = load i64, ptr %l12, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_78fb4d3249708b2_e3f9318f90ab6b26)
  unreachable
bb5:
  %t26 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l8, !tbaa !24
  %t29 = load i64, ptr %l11, !tbaa !24
  %t30 = getelementptr i8, ptr %t27, i64 %t28
  %t31 = sub i64 %t29, %t28
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  %t34 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = extractvalue { i64, ptr } %t33, 1
  %t52 = extractvalue { i64, ptr } %t33, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t34, i64 %t35)
  %t58 = getelementptr i8, ptr %t57, i64 %t35
  call void @olang_textcopy(ptr %t58, ptr %t37, i64 %t38)
  %t59 = getelementptr i8, ptr %t58, i64 %t38
  call void @olang_textcopy(ptr %t59, ptr %t40, i64 %t41)
  %t60 = getelementptr i8, ptr %t59, i64 %t41
  call void @olang_textcopy(ptr %t60, ptr %t44, i64 %t45)
  %t61 = getelementptr i8, ptr %t60, i64 %t45
  call void @olang_textcopy(ptr %t61, ptr %t47, i64 %t48)
  %t62 = getelementptr i8, ptr %t61, i64 %t48
  call void @olang_textcopy(ptr %t62, ptr %t51, i64 %t52)
  %t63 = getelementptr i8, ptr %t62, i64 %t52
  call void @olang_textcopy(ptr %t63, ptr %t54, i64 %t55)
  %t64 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t57, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } %t65, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load i32, ptr %l2, !range !{i32 0, i32 838}
  %t75 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d163, i32 0, i32 1) }, { i64, ptr } %t72)
  store %"compiler/msgs:Msg" %t75, ptr %l19
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_78fb4d3249708b2_e3f9318f90ab6b26)
  unreachable
bb7:
  %t76 = load %"compiler/msgs:Msg", ptr %l19
  store %"compiler/msgs:Msg" %t76, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 746, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d166, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNameUnused(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 744, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d168, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNotProduced(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 658, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d170, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchWordNotProduced(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 614, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d173, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtAssigned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 747, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d176, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 781, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d177, i32 0, i32 1) }, { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d178, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 780, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d181, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtComparedToCaught(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 753, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d182, i32 0, i32 1) }, { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d183, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchBlock(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 779, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d184, i32 0, i32 1) }, { i64, ptr } { i64 139, ptr getelementptr inbounds (<{ i64, [139 x i8] }>, ptr @.d185, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 755, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d188, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCharNewline(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d189, i32 0, i32 1) }, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d190, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCharNoPad(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 499, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d194, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d196, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eClauseLastValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 522, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d199, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesClash(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 241, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d205, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 239, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d208, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComprehensionReferences(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 529, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d209, i32 0, i32 1) }, { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d210, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForElem(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 813, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d213, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForSource(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 812, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d216, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTooMany(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t3, i64 %t4)
  %t18 = getelementptr i8, ptr %t17, i64 %t4
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a0)
  %t20 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t20, ptr %t8, i64 %t9)
  %t21 = getelementptr i8, ptr %t20, i64 %t9
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %a1)
  %t23 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t17, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 815, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d220, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTry(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 811, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d221, i32 0, i32 1) }, { i64, ptr } { i64 126, ptr getelementptr inbounds (<{ i64, [126 x i8] }>, ptr @.d222, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeNotBaked(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 810, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d224, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondCycle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 91, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d226, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondMutable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 89, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 93, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d230, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTooDeep(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t2, i64 %t3)
  %t11 = getelementptr i8, ptr %t10, i64 %t3
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t5
  call void @olang_textcopy(ptr %t13, ptr %t7, i64 %t8)
  %t14 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t10, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 689, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d233, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUndecidable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 704, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d235, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnknownBuild(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 706, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d237, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnseen(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 705, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d238, i32 0, i32 1) }, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d239, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintDisagrees(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 135, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d241, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 133, ptr getelementptr inbounds (<{ i64, [133 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 133, ptr getelementptr inbounds (<{ i64, [133 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 159, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d243, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 136, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d246, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintUnmetHash(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 144, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d250, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eContainerScopeUnbuildable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 551, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d251, i32 0, i32 1) }, { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d252, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractNeedsArgumentError(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 737, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d254, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCopyOnWhat(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 248, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d257, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCopyShape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %t1, 1
  %t8 = extractvalue { i64, ptr } %t1, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t2, 1
  %t15 = extractvalue { i64, ptr } %t2, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %t3, 1
  %t22 = extractvalue { i64, ptr } %t3, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 247, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d262, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l7
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNoValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 196, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d265, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 346, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d269, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorTypeArgsNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 343, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d273, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeclaredTwice(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 193, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d275, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultArgNotAllowed(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 501, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d276, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d277, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t3, i64 %t4)
  %t15 = getelementptr i8, ptr %t14, i64 %t4
  %t16 = call i64 @__olang_fmt_i64(ptr %t15, i64 %a0)
  %t17 = getelementptr i8, ptr %t15, i64 %t6
  call void @olang_textcopy(ptr %t17, ptr %t8, i64 %t9)
  %t18 = getelementptr i8, ptr %t17, i64 %t9
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a1)
  %t20 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t14, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 514, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d280, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 673, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d282, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotTrailing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 197, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d284, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultOutsideTrait(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 272, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d287, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 502, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d288, i32 0, i32 1) }, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d289, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 657, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d291, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 47, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d293, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineFloatRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 46, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d297, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNegRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 45, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d301, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineShape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 40, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d304, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 369, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d307, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNoDestructor(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 365, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d310, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotLocal(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 364, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d311, i32 0, i32 1) }, { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d312, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotSole(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 366, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d316, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 539, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d317, i32 0, i32 1) }, { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d318, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotUnique(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 266, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d322, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructRunArray(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t1, 1
  %t6 = extractvalue { i64, ptr } %t1, 0
  %t7 = extractvalue { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 166, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d326, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l7
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructTypeByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t3, 1
  %t20 = extractvalue { i64, ptr } %t3, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t4, 1
  %t27 = extractvalue { i64, ptr } %t4, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 164, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d331, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l9
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDigitSeparator(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d332, i32 0, i32 1) }, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d333, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDivideByZero(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 427, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d334, i32 0, i32 1) }, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d335, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t2, 1
  %t15 = extractvalue { i64, ptr } %t2, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %t3, 1
  %t22 = extractvalue { i64, ptr } %t3, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 34, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d340, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l8
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eDoubleReferenceMarker(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 163, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d341, i32 0, i32 1) }, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d342, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 544, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d343, i32 0, i32 1) }, { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d344, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemsNotSeq(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d346, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d346, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 452, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d347, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemsType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t2, 1
  %t15 = extractvalue { i64, ptr } %t2, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %t3, 1
  %t22 = extractvalue { i64, ptr } %t3, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 453, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d352, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l8
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedNotRead(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d353, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d353, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 506, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d355, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmbedPathUnknown(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 503, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d356, i32 0, i32 1) }, { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d357, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyDestructor(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 660, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d358, i32 0, i32 1) }, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d359, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 751, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d361, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrPatternBindAlts(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 771, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d362, i32 0, i32 1) }, { i64, ptr } { i64 99, ptr getelementptr inbounds (<{ i64, [99 x i8] }>, ptr @.d363, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrValueNoOp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 749, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d366, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrValueNotHeld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 752, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d371, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 86, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d372, i32 0, i32 1) }, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d373, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorMethodGiven(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d374, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d374, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a0, 1
  %t14 = extractvalue { i64, ptr } %a0, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 768, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d377, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordInUse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d378, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d378, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d379, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d379, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 232, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d380, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 613, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d383, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExpected(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d385, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d385, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 76, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d386, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 29, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d387, i32 0, i32 1) }, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d388, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportObligation(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 209, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d391, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 163, ptr getelementptr inbounds (<{ i64, [163 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 163, ptr getelementptr inbounds (<{ i64, [163 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 207, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d393, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 188, ptr getelementptr inbounds (<{ i64, [188 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 188, ptr getelementptr inbounds (<{ i64, [188 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 203, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d395, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFactOfGeneric(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t1, 1
  %t6 = extractvalue { i64, ptr } %t1, 0
  %t7 = extractvalue { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a1, 1
  %t19 = extractvalue { i64, ptr } %a1, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 827, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d399, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l8
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d401, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d401, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 194, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d402, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 475, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d406, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l8
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFlagAmongResults(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 772, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d407, i32 0, i32 1) }, { i64, ptr } { i64 133, ptr getelementptr inbounds (<{ i64, [133 x i8] }>, ptr @.d408, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 430, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d410, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInNeedsTry(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 560, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d411, i32 0, i32 1) }, { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d412, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForInTryNothing(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 561, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d413, i32 0, i32 1) }, { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d414, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForeignBuilt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t1, 1
  %t5 = extractvalue { i64, ptr } %t1, 0
  %t6 = extractvalue { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %t2, 1
  %t11 = extractvalue { i64, ptr } %t2, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 212, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d417, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l6
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eForeignByValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t1, 1
  %t6 = extractvalue { i64, ptr } %t1, 0
  %t7 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d418, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d418, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d419, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d419, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 213, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d421, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l7
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFormatterBuild(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 20, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d424, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFormatterMissing(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d426, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromPayload(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d429, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d429, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 734, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d430, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncDeclBare(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t1, 1
  %t6 = extractvalue { i64, ptr } %t1, 0
  %t7 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %t2, 1
  %t12 = extractvalue { i64, ptr } %t2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 173, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d434, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l7
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncDeclMismatch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d435, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d435, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 174, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d439, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncTypeBare(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 172, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d443, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncTypeErrsUnwritten(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 123, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d444, i32 0, i32 1) }, { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d445, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuncValueObligations(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 137, ptr getelementptr inbounds (<{ i64, [137 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 137, ptr getelementptr inbounds (<{ i64, [137 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 644, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d448, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzNoTest(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 10, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d451, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzTimeNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d454, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenContractNeedsArgumentError(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 141, ptr getelementptr inbounds (<{ i64, [141 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 141, ptr getelementptr inbounds (<{ i64, [141 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 738, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d456, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldShorter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 137, ptr getelementptr inbounds (<{ i64, [137 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 137, ptr getelementptr inbounds (<{ i64, [137 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 600, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d459, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNeeds(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t1, 1
  %t8 = extractvalue { i64, ptr } %t1, 0
  %t9 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d460, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d460, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d461, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d461, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %t3, 1
  %t21 = extractvalue { i64, ptr } %t3, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d462, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d462, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %t4, 1
  %t28 = extractvalue { i64, ptr } %t4, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %t5, 1
  %t35 = extractvalue { i64, ptr } %t5, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t7, i64 %t8)
  %t41 = getelementptr i8, ptr %t40, i64 %t8
  call void @olang_textcopy(ptr %t41, ptr %t9, i64 %t10)
  %t42 = getelementptr i8, ptr %t41, i64 %t10
  call void @olang_textcopy(ptr %t42, ptr %t13, i64 %t14)
  %t43 = getelementptr i8, ptr %t42, i64 %t14
  call void @olang_textcopy(ptr %t43, ptr %t16, i64 %t17)
  %t44 = getelementptr i8, ptr %t43, i64 %t17
  call void @olang_textcopy(ptr %t44, ptr %t20, i64 %t21)
  %t45 = getelementptr i8, ptr %t44, i64 %t21
  call void @olang_textcopy(ptr %t45, ptr %t23, i64 %t24)
  %t46 = getelementptr i8, ptr %t45, i64 %t24
  call void @olang_textcopy(ptr %t46, ptr %t27, i64 %t28)
  %t47 = getelementptr i8, ptr %t46, i64 %t28
  call void @olang_textcopy(ptr %t47, ptr %t30, i64 %t31)
  %t48 = getelementptr i8, ptr %t47, i64 %t31
  call void @olang_textcopy(ptr %t48, ptr %t34, i64 %t35)
  %t49 = getelementptr i8, ptr %t48, i64 %t35
  call void @olang_textcopy(ptr %t49, ptr %t37, i64 %t38)
  %t50 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t40, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t61 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 825, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d465, i32 0, i32 1) }, { i64, ptr } %t58)
  store %"compiler/msgs:Msg" %t61, ptr %l11
  br label %bb1
bb1:
  %t62 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 535, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d469, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalAborts(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d470, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d470, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 682, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d471, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 549, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d472, i32 0, i32 1) }, { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d473, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalStale(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 688, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d475, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalsCycle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d476, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d476, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 709, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d477, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eGuardNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d478, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d478, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 572, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d479, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d480, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d481, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eHexDigit(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 71, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d482, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d482, i32 0, i32 1) }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d483, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d483, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 838}
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d484, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eHexNoDigits(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 69, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d485, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d486, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImmutable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 387, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d488, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d489, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d489, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 104, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d491, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d492, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d492, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 97, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d494, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 100, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d496, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 101, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d497, i32 0, i32 1) }, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d498, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d499, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d499, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 108, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d501, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d502, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d502, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 98, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d504, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 99, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d505, i32 0, i32 1) }, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d506, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 103, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d507, i32 0, i32 1) }, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d508, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIncdecNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d509, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d509, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 383, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d510, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d511, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d511, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 375, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d512, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexOutOfRange(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d513, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d513, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d514, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d514, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d515, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d515, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t3, i64 %t4)
  %t18 = getelementptr i8, ptr %t17, i64 %t4
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a0)
  %t20 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t20, ptr %t8, i64 %t9)
  %t21 = getelementptr i8, ptr %t20, i64 %t9
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %a1)
  %t23 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t17, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 376, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d516, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceNotReferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d517, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d517, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d518, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d518, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 161, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d519, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesArg(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l5 = alloca { i64, ptr }
  %l11 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 548, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d520, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d521, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d521, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d522, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d522, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t8, i64 %t9)
  %t18 = getelementptr i8, ptr %t17, i64 %t9
  call void @olang_textcopy(ptr %t18, ptr %t11, i64 %t12)
  %t19 = getelementptr i8, ptr %t18, i64 %t12
  call void @olang_textcopy(ptr %t19, ptr %t14, i64 %t15)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d523, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb4
bb4:
  %t30 = extractvalue { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d524, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d524, i32 0, i32 1) }, 0
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t30, i64 %t31)
  %t37 = getelementptr i8, ptr %t36, i64 %t31
  call void @olang_textcopy(ptr %t37, ptr %t33, i64 %t34)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } %t39, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load i32, ptr %l1, !range !{i32 0, i32 838}
  %t49 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t47, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d525, i32 0, i32 1) }, { i64, ptr } %t46)
  store %"compiler/msgs:Msg" %t49, ptr %l11
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t50, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eInterpLink(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d526, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d526, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d527, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d527, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 215, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d529, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsAsNotEnum(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d530, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d530, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 490, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d531, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPiece(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d532, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d532, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d533, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d533, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 82, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d534, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d535, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d535, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 79, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d536, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d537, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d537, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d538, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d538, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d539, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d539, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t25 = call i64 @__olang_fmt_i64(ptr null, i64 %a3)
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t6, i64 %t7)
  %t28 = getelementptr i8, ptr %t27, i64 %t7
  call void @olang_textcopy(ptr %t28, ptr %t8, i64 %t9)
  %t29 = getelementptr i8, ptr %t28, i64 %t9
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %a1)
  %t31 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t31, ptr %t14, i64 %t15)
  %t32 = getelementptr i8, ptr %t31, i64 %t15
  call void @olang_textcopy(ptr %t32, ptr %t18, i64 %t19)
  %t33 = getelementptr i8, ptr %t32, i64 %t19
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  %t35 = call i64 @__olang_fmt_i64(ptr %t34, i64 %a3)
  %t36 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t27, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  %t47 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 651, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d540, i32 0, i32 1) }, { i64, ptr } %t44)
  store %"compiler/msgs:Msg" %t47, ptr %l11
  br label %bb1
bb1:
  %t48 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t48, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaValueRelates(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 646, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d541, i32 0, i32 1) }, { i64, ptr } { i64 153, ptr getelementptr inbounds (<{ i64, [153 x i8] }>, ptr @.d542, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d543, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d543, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 822, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d544, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneReferences(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 820, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d545, i32 0, i32 1) }, { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d546, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLenShape(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d547, i32 0, i32 1) }, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d548, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLengthsNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d549, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d549, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d550, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d550, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 536, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d551, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLessNotBool(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 244, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d552, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d553, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralCtorFails(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d554, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d554, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d555, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d555, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 661, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d556, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralDoesNotMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d557, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d557, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d558, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d558, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d559, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d559, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d560, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d560, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 425, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d561, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprNoValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 423, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d562, i32 0, i32 1) }, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d563, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralNeedsCtor(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d564, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d564, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d565, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d565, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d566, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d566, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 304, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d567, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralNoOwnType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 162, ptr getelementptr inbounds (<{ i64, [162 x i8] }>, ptr @.d568, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 162, ptr getelementptr inbounds (<{ i64, [162 x i8] }>, ptr @.d568, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 424, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d569, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d570, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d570, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 299, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d571, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eLongChar(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 67, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d572, i32 0, i32 1) }, { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d573, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchLengthUncovered(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d574, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d574, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d575, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d575, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d576, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d576, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 448, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d577, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d578, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d578, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d579, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d579, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d580, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d580, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 578, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d581, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNone(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 576, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d582, i32 0, i32 1) }, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d583, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 580, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d584, i32 0, i32 1) }, { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d585, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNeedsTry(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d586, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d586, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 441, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d587, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d588, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d588, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d589, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d589, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d590, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d590, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 439, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d591, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCalledAsFunction(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d592, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d592, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d593, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d593, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 290, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d594, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d595, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d595, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 243, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d596, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodClashesInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d597, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d597, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d598, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d598, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 275, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d599, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodClashesSupplied(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d600, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d600, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d601, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d601, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d602, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d602, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 277, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d603, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d604, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d604, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d605, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d605, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 534, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d606, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d607, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d607, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d608, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d608, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 511, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d609, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodOnForeignType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d610, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d610, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d611, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d611, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 273, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d612, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodOverlap(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d613, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d613, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d614, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d614, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d615, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d615, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 276, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d616, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d617, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d617, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d618, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d618, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 655, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d619, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d620, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d620, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d621, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnLocal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d622, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d622, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d623, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d623, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 552, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d624, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d625, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d625, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d626, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d626, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 228, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d627, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d628, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d628, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d629, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d629, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 226, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d630, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d631, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d631, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d632, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d632, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 353, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d633, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgNotHere(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 356, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d634, i32 0, i32 1) }, { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d635, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d636, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d636, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d637, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d637, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 351, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d638, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d639, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d639, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d640, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d640, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d641, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d641, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 350, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d642, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowNeedsType(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 154, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d643, i32 0, i32 1) }, { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d644, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local i1 @compiler_2fmsgs_2eNear(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l8 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = add i64 %t4, 2
  %t8 = sdiv i64 %t6, 3
  %t11 = icmp sle i64 %t1, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp slt i64 %t13, %t16
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l8, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 84, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d645, i32 0, i32 1) }, { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d646, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNegLiteralTooLarge(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d647, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d647, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d648, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d648, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 418, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d649, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNesting(ptr %v0, i64 %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d650, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d650, i32 0, i32 1) }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d651, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d651, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t2, i64 %t3)
  %t11 = getelementptr i8, ptr %t10, i64 %t3
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t5
  call void @olang_textcopy(ptr %t13, ptr %t7, i64 %t8)
  %t14 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t10, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 78, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d652, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d653, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d653, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d654, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d654, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 52, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d655, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoLimit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d656, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d656, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d657, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d657, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 711, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d658, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoMain(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 51, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d659, i32 0, i32 1) }, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d660, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d661, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d661, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 37, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d662, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d663, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d663, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 432, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d664, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchErrorWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d665, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d665, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t15 = extractvalue { i64, ptr } %a2, 1
  %t16 = extractvalue { i64, ptr } %a2, 0
  %t17 = add i64 %t13, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t5, i64 %t6)
  %t19 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t19, ptr %t7, i64 %t8)
  %t20 = getelementptr i8, ptr %t19, i64 %t8
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t15, i64 %t16)
  %t22 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t18, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 431, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d666, i32 0, i32 1) }, { i64, ptr } %t30)
  store %"compiler/msgs:Msg" %t33, ptr %l9
  br label %bb1
bb1:
  %t34 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t34, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d667, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d667, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d668, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d668, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 379, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d669, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d670, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d670, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 663, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d671, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNonAscii(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 58, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d672, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d672, i32 0, i32 1) }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d673, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d673, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 838}
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d674, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnErrors(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 606, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d675, i32 0, i32 1) }, { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d676, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnFallsOff(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 605, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d677, i32 0, i32 1) }, { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d678, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAnErrorType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d679, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d679, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 741, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d680, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAssignable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 381, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d681, i32 0, i32 1) }, { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d682, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotInModule(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d683, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d683, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t15 = extractvalue { i64, ptr } %a2, 1
  %t16 = extractvalue { i64, ptr } %a2, 0
  %t17 = add i64 %t13, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t5, i64 %t6)
  %t19 = getelementptr i8, ptr %t18, i64 %t6
  call void @olang_textcopy(ptr %t19, ptr %t7, i64 %t8)
  %t20 = getelementptr i8, ptr %t19, i64 %t8
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t15, i64 %t16)
  %t22 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t18, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 291, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d684, i32 0, i32 1) }, { i64, ptr } %t30)
  store %"compiler/msgs:Msg" %t33, ptr %l9
  br label %bb1
bb1:
  %t34 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t34, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d685, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d685, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d686, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d686, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d687, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d687, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a3, 1
  %t28 = extractvalue { i64, ptr } %a3, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d688, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d688, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %a4, 1
  %t35 = extractvalue { i64, ptr } %a4, 0
  %t36 = add i64 %t32, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t7, i64 %t8)
  %t38 = getelementptr i8, ptr %t37, i64 %t8
  call void @olang_textcopy(ptr %t38, ptr %t9, i64 %t10)
  %t39 = getelementptr i8, ptr %t38, i64 %t10
  call void @olang_textcopy(ptr %t39, ptr %t13, i64 %t14)
  %t40 = getelementptr i8, ptr %t39, i64 %t14
  call void @olang_textcopy(ptr %t40, ptr %t16, i64 %t17)
  %t41 = getelementptr i8, ptr %t40, i64 %t17
  call void @olang_textcopy(ptr %t41, ptr %t20, i64 %t21)
  %t42 = getelementptr i8, ptr %t41, i64 %t21
  call void @olang_textcopy(ptr %t42, ptr %t23, i64 %t24)
  %t43 = getelementptr i8, ptr %t42, i64 %t24
  call void @olang_textcopy(ptr %t43, ptr %t27, i64 %t28)
  %t44 = getelementptr i8, ptr %t43, i64 %t28
  call void @olang_textcopy(ptr %t44, ptr %t30, i64 %t31)
  %t45 = getelementptr i8, ptr %t44, i64 %t31
  call void @olang_textcopy(ptr %t45, ptr %t34, i64 %t35)
  %t46 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t37, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 236, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d689, i32 0, i32 1) }, { i64, ptr } %t54)
  store %"compiler/msgs:Msg" %t57, ptr %l13
  br label %bb1
bb1:
  %t58 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteBindingWhere(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d690, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d690, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d691, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d691, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d692, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d692, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 695, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d693, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWritable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d694, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d694, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d695, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d695, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d696, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d696, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d697, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d697, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 412, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d698, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d699, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d699, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 411, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d700, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyHere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d701, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d701, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d702, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d702, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 371, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d703, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t17 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 370, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d704, i32 0, i32 1) }, { i64, ptr } %t14)
  store %"compiler/msgs:Msg" %t17, ptr %l5
  br label %bb1
bb1:
  %t18 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteGenericNeeds(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d705, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d705, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d706, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d706, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 826, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d707, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHeldIndexWhere(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d708, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d708, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d709, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d709, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 699, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d710, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 390, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d711, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d712, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 398, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d713, i32 0, i32 1) }, { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d714, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInstanceRef(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 162, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d715, i32 0, i32 1) }, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d716, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d717, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d717, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d718, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d718, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d719, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d719, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d720, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d720, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d721, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d721, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 413, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d722, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l13 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d723, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d723, i32 0, i32 1) }, 0
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d724, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d724, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d725, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d725, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %a2, 1
  %t24 = extractvalue { i64, ptr } %a2, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d726, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d726, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %a3, 1
  %t31 = extractvalue { i64, ptr } %a3, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d727, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d727, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %a4, 1
  %t38 = extractvalue { i64, ptr } %a4, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d728, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d728, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t6, i64 %t7)
  %t44 = getelementptr i8, ptr %t43, i64 %t7
  call void @olang_textcopy(ptr %t44, ptr %t9, i64 %t10)
  %t45 = getelementptr i8, ptr %t44, i64 %t10
  call void @olang_textcopy(ptr %t45, ptr %t12, i64 %t13)
  %t46 = getelementptr i8, ptr %t45, i64 %t13
  call void @olang_textcopy(ptr %t46, ptr %t16, i64 %t17)
  %t47 = getelementptr i8, ptr %t46, i64 %t17
  call void @olang_textcopy(ptr %t47, ptr %t19, i64 %t20)
  %t48 = getelementptr i8, ptr %t47, i64 %t20
  call void @olang_textcopy(ptr %t48, ptr %t23, i64 %t24)
  %t49 = getelementptr i8, ptr %t48, i64 %t24
  call void @olang_textcopy(ptr %t49, ptr %t26, i64 %t27)
  %t50 = getelementptr i8, ptr %t49, i64 %t27
  call void @olang_textcopy(ptr %t50, ptr %t30, i64 %t31)
  %t51 = getelementptr i8, ptr %t50, i64 %t31
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t37, i64 %t38)
  %t53 = getelementptr i8, ptr %t52, i64 %t38
  call void @olang_textcopy(ptr %t53, ptr %t40, i64 %t41)
  %t54 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t43, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t65 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, i32 414, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d729, i32 0, i32 1) }, { i64, ptr } %t62)
  store %"compiler/msgs:Msg" %t65, ptr %l13
  br label %bb1
bb1:
  %t66 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d730, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d730, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 185, ptr getelementptr inbounds (<{ i64, [185 x i8] }>, ptr @.d731, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 185, ptr getelementptr inbounds (<{ i64, [185 x i8] }>, ptr @.d731, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 697, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d732, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteObligationOrigin(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 691, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d733, i32 0, i32 1) }, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d734, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d735, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d735, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d736, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d736, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 408, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d737, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteParamCopy(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d738, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d738, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d739, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d739, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d738, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d738, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 696, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d740, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteProtocolSpelling(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d741, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d741, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d742, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d742, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d743, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d743, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d744, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d744, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 410, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d745, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d746, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d746, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d747, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d747, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d748, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d748, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a2, 1
  %t23 = extractvalue { i64, ptr } %a2, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d749, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d749, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a3, 1
  %t30 = extractvalue { i64, ptr } %a3, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d750, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d750, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 318, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d751, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l11
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteRefillKept(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d752, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d752, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d753, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d753, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d754, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d754, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 693, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d755, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteSliceOfTemporary(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 701, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d756, i32 0, i32 1) }, { i64, ptr } { i64 119, ptr getelementptr inbounds (<{ i64, [119 x i8] }>, ptr @.d757, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 396, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d758, i32 0, i32 1) }, { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d759, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteUnassignedClause(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 406, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d760, i32 0, i32 1) }, { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d761, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d762, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d762, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d763, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d763, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d764, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d764, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t4, i64 %t5)
  %t25 = getelementptr i8, ptr %t24, i64 %t5
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t10, i64 %t11)
  %t27 = getelementptr i8, ptr %t26, i64 %t11
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t17, i64 %t18)
  %t29 = getelementptr i8, ptr %t28, i64 %t18
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 393, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d765, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d766, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d766, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 394, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d767, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteViewRefusedBy(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 698, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d768, i32 0, i32 1) }, { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d769, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroByReference(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d770, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d770, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d771, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d771, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 399, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d772, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullCompared(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d773, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d773, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d774, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d774, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d775, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d775, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 474, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d776, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d777, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d777, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 479, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d778, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullableMeetsNoTrait(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d779, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d779, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a2, 1
  %t13 = extractvalue { i64, ptr } %a2, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d780, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d780, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d781, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d781, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d782, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d782, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 341, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d783, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d784, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d784, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 419, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d785, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d786, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d786, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d787, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d787, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 429, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d788, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d789, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d789, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d790, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d790, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d791, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d792, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d792, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d793, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d793, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 15, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d794, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d795, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d795, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 271, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d796, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnFromBareRefParam(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 296, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d797, i32 0, i32 1) }, { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d798, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatFieldBothWays(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d799, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d799, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d800, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d800, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 458, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d801, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d802, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d802, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d803, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d803, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 487, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d804, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 546, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d805, i32 0, i32 1) }, { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d806, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadWordBare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d807, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d807, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %t2, 1
  %t13 = extractvalue { i64, ptr } %t2, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d808, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d808, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t3, 1
  %t20 = extractvalue { i64, ptr } %t3, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d809, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d809, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t4, 1
  %t27 = extractvalue { i64, ptr } %t4, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d810, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d810, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 762, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d811, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l9
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePointNoDigit(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 74, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d812, i32 0, i32 1) }, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d813, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePowNone(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d814, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d814, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d815, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d815, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 447, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d816, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2ePrimCtorNotPrimitive(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 229, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d817, i32 0, i32 1) }, { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d818, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolBothSpellings(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l11 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d819, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d819, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d820, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d820, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d821, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d821, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %a3, 1
  %t27 = extractvalue { i64, ptr } %a3, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d822, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d822, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, i32 269, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d823, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l11
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eQuickAlone(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d824, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d824, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d825, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d825, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 7, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d826, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaiseNearError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d827, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d827, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d828, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d828, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d829, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d829, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 760, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d830, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaisedFieldUnnamed(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 766, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d831, i32 0, i32 1) }, { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d832, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRawNoFit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d833, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d833, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d834, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d834, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 729, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d835, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRawNotLiteral(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d836, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d836, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 728, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d837, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRawRepeated(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d838, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d838, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d839, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d839, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d840, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d840, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d841, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d841, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 730, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d842, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRawType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d843, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d843, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 727, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d844, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRawWithoutType(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 731, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d845, i32 0, i32 1) }, { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d846, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d847, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d847, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d848, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d848, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d849, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d849, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 307, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d850, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d851, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d851, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 312, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d852, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyRef(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 314, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d853, i32 0, i32 1) }, { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d854, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d855, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d855, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d856, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d856, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d857, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d857, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 309, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d858, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d859, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d859, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d860, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d860, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 308, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d861, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyWrite(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 313, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d862, i32 0, i32 1) }, { i64, ptr } { i64 117, ptr getelementptr inbounds (<{ i64, [117 x i8] }>, ptr @.d863, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefWrite(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 385, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d864, i32 0, i32 1) }, { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d865, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRefTypevarNotAggregate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d866, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d866, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d867, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d867, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 339, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d868, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowedLocal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d869, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d869, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d870, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d870, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 337, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d871, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowedReturned(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 338, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d872, i32 0, i32 1) }, { i64, ptr } { i64 158, ptr getelementptr inbounds (<{ i64, [158 x i8] }>, ptr @.d873, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflArgCompr(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 800, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d874, i32 0, i32 1) }, { i64, ptr } { i64 160, ptr getelementptr inbounds (<{ i64, [160 x i8] }>, ptr @.d875, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 791, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d876, i32 0, i32 1) }, { i64, ptr } { i64 139, ptr getelementptr inbounds (<{ i64, [139 x i8] }>, ptr @.d877, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflIndexRange(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d878, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d878, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d879, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d879, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t3, i64 %t4)
  %t15 = getelementptr i8, ptr %t14, i64 %t4
  %t16 = call i64 @__olang_fmt_i64(ptr %t15, i64 %a0)
  %t17 = getelementptr i8, ptr %t15, i64 %t6
  call void @olang_textcopy(ptr %t17, ptr %t8, i64 %t9)
  %t18 = getelementptr i8, ptr %t17, i64 %t9
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a1)
  %t20 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t14, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 790, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d880, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflListValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 158, ptr getelementptr inbounds (<{ i64, [158 x i8] }>, ptr @.d881, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 158, ptr getelementptr inbounds (<{ i64, [158 x i8] }>, ptr @.d881, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 788, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d882, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflMatchSubject(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 802, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d883, i32 0, i32 1) }, { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d884, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 125, ptr getelementptr inbounds (<{ i64, [125 x i8] }>, ptr @.d885, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 125, ptr getelementptr inbounds (<{ i64, [125 x i8] }>, ptr @.d885, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 784, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d886, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d887, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d887, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d888, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d888, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 786, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d889, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d890, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d890, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 785, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d891, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d892, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d892, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d893, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d893, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 783, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d894, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d895, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d895, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d896, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d896, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d897, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d897, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t4, i64 %t5)
  %t25 = getelementptr i8, ptr %t24, i64 %t5
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t10, i64 %t11)
  %t27 = getelementptr i8, ptr %t26, i64 %t11
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t17, i64 %t18)
  %t29 = getelementptr i8, ptr %t28, i64 %t18
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 801, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d898, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNotList(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a1, 1
  %t6 = extractvalue { i64, ptr } %a1, 0
  %t7 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d899, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d899, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d900, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d900, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a2, 1
  %t19 = extractvalue { i64, ptr } %a2, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t5, i64 %t6)
  %t22 = getelementptr i8, ptr %t21, i64 %t6
  call void @olang_textcopy(ptr %t22, ptr %t7, i64 %t8)
  %t23 = getelementptr i8, ptr %t22, i64 %t8
  call void @olang_textcopy(ptr %t23, ptr %t11, i64 %t12)
  %t24 = getelementptr i8, ptr %t23, i64 %t12
  call void @olang_textcopy(ptr %t24, ptr %t14, i64 %t15)
  %t25 = getelementptr i8, ptr %t24, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t21, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 787, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d901, i32 0, i32 1) }, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l9
  br label %bb1
bb1:
  %t38 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d902, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d902, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d903, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d903, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 795, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d904, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTryList(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 792, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d905, i32 0, i32 1) }, { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d906, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReraiseUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d907, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d907, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d908, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d908, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 757, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d909, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eRestTwice(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 450, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d910, i32 0, i32 1) }, { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d911, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInNoreturn(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 604, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d912, i32 0, i32 1) }, { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d913, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnNeedsValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d914, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d914, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d915, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d915, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 610, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d916, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d917, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d917, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d918, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d918, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 326, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d919, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnValueInVoid(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 609, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d920, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d921, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgProgram(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d922, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d922, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 321, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d923, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 294, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d924, i32 0, i32 1) }, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d925, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSetatResult(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 242, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d926, i32 0, i32 1) }, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d927, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSetatUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d928, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d928, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 493, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d929, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d930, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d930, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 286, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d931, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d932, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d932, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 284, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d933, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShiftOutOfRange(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d934, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d934, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d935, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d935, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d936, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d936, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d937, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d937, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t4, i64 %t5)
  %t26 = getelementptr i8, ptr %t25, i64 %t5
  call void @olang_textcopy(ptr %t26, ptr %t7, i64 %t8)
  %t27 = getelementptr i8, ptr %t26, i64 %t8
  call void @olang_textcopy(ptr %t27, ptr %t10, i64 %t11)
  %t28 = getelementptr i8, ptr %t27, i64 %t11
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a1)
  %t30 = getelementptr i8, ptr %t28, i64 %t14
  call void @olang_textcopy(ptr %t30, ptr %t16, i64 %t17)
  %t31 = getelementptr i8, ptr %t30, i64 %t17
  %t32 = call i64 @__olang_fmt_i64(ptr %t31, i64 %a2)
  %t33 = getelementptr i8, ptr %t31, i64 %t20
  call void @olang_textcopy(ptr %t33, ptr %t22, i64 %t23)
  %t34 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t25, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 426, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d938, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eShiftUnadapted(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 293, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d939, i32 0, i32 1) }, { i64, ptr } { i64 116, ptr getelementptr inbounds (<{ i64, [116 x i8] }>, ptr @.d940, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceBoundNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d941, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d941, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 378, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d942, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d943, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d943, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d944, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d944, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 491, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d945, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnAtElement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 621, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d946, i32 0, i32 1) }, { i64, ptr } { i64 173, ptr getelementptr inbounds (<{ i64, [173 x i8] }>, ptr @.d947, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 623, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d948, i32 0, i32 1) }, { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d949, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 619, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d950, i32 0, i32 1) }, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d951, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 618, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d952, i32 0, i32 1) }, { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d953, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 622, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d954, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d955, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 620, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d956, i32 0, i32 1) }, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d957, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultTooShort(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 642, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d958, i32 0, i32 1) }, { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d959, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d960, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d960, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d961, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d961, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d962, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d962, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 640, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d963, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultVoid(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 639, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d964, i32 0, i32 1) }, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d965, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 624, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d966, i32 0, i32 1) }, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d967, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadAlone(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 466, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d968, i32 0, i32 1) }, { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d969, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadCount(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 329, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d970, i32 0, i32 1) }, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d971, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadNotHere(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 465, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d972, i32 0, i32 1) }, { i64, ptr } { i64 115, ptr getelementptr inbounds (<{ i64, [115 x i8] }>, ptr @.d973, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d974, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d974, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 500, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d975, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 542, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d976, i32 0, i32 1) }, { i64, ptr } { i64 114, ptr getelementptr inbounds (<{ i64, [114 x i8] }>, ptr @.d977, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 389, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d978, i32 0, i32 1) }, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d979, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrShape(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 267, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d980, i32 0, i32 1) }, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d981, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStructPatPositional(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d982, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d982, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d983, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d983, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 455, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d984, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eStructPatType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d985, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d985, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d986, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d986, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 456, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d987, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTagUnknownScope(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d988, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d988, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d989, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d989, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d990, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d990, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 324, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d991, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d992, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d992, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 531, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d993, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d994, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d994, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d995, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d995, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 25, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d996, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d997, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d997, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d998, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 102, ptr getelementptr inbounds (<{ i64, [102 x i8] }>, ptr @.d998, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 24, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d999, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d1000, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d1000, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 144, ptr getelementptr inbounds (<{ i64, [144 x i8] }>, ptr @.d1001, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 144, ptr getelementptr inbounds (<{ i64, [144 x i8] }>, ptr @.d1001, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 26, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1002, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d1003, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d1003, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d1004, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d1004, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 23, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1005, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 627, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1006, i32 0, i32 1) }, { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d1007, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d1008, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d1008, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 626, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1009, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 628, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1010, i32 0, i32 1) }, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d1011, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 629, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1012, i32 0, i32 1) }, { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d1013, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTestTargetUnknownMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d1014, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d1014, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d1015, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d1015, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1016, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1016, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 358, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1017, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTextMutRef(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 253, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d1018, i32 0, i32 1) }, { i64, ptr } { i64 143, ptr getelementptr inbounds (<{ i64, [143 x i8] }>, ptr @.d1019, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTextWrite(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 251, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d1020, i32 0, i32 1) }, { i64, ptr } { i64 146, ptr getelementptr inbounds (<{ i64, [146 x i8] }>, ptr @.d1021, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 39)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store ptr %l1, ptr %l18, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s2, i8 %t24)
  store { i64, ptr } %t28, ptr %l20
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t36, { i64, ptr } %t35)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb3
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 39)
  br label %bb11
bb11:
  %t44 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t44, ptr %l26
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopAssertFalse(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 721, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1022, i32 0, i32 1) }, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d1023, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetCondReads(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1024, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1024, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d1025, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d1025, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 672, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1026, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetHasValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1027, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1027, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 118, ptr getelementptr inbounds (<{ i64, [118 x i8] }>, ptr @.d1028, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 118, ptr getelementptr inbounds (<{ i64, [118 x i8] }>, ptr @.d1028, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 668, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1029, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetPlace(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 666, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1030, i32 0, i32 1) }, { i64, ptr } { i64 139, ptr getelementptr inbounds (<{ i64, [139 x i8] }>, ptr @.d1031, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1032, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1032, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d1033, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d1033, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 667, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1034, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 124, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1035, i32 0, i32 1) }, { i64, ptr } { i64 84, ptr getelementptr inbounds (<{ i64, [84 x i8] }>, ptr @.d1036, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d1037, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d1037, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 141, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1038, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d1039, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d1039, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 140, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1040, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l10 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d1041, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d1041, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %a1, 1
  %t13 = extractvalue { i64, ptr } %a1, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1042, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1042, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d1043, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d1043, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t4, 1
  %t27 = extractvalue { i64, ptr } %t4, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1044, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1044, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t6, i64 %t7)
  %t33 = getelementptr i8, ptr %t32, i64 %t7
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t12, i64 %t13)
  %t35 = getelementptr i8, ptr %t34, i64 %t13
  call void @olang_textcopy(ptr %t35, ptr %t15, i64 %t16)
  %t36 = getelementptr i8, ptr %t35, i64 %t16
  call void @olang_textcopy(ptr %t36, ptr %t19, i64 %t20)
  %t37 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t37, ptr %t22, i64 %t23)
  %t38 = getelementptr i8, ptr %t37, i64 %t23
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 143, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1045, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l10
  br label %bb1
bb1:
  %t52 = load %"compiler/msgs:Msg", ptr %l10
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d1046, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d1046, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 142, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1047, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMethodGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1048, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1048, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d1049, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d1049, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 195, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1050, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 169, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1051, i32 0, i32 1) })
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1052, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1053, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb4
bb4:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d1054, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d1054, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = add i64 %t12, %t15
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1055, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1055, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t8, i64 %t9)
  %t25 = getelementptr i8, ptr %t24, i64 %t9
  call void @olang_textcopy(ptr %t25, ptr %t10, i64 %t11)
  %t26 = getelementptr i8, ptr %t25, i64 %t11
  call void @olang_textcopy(ptr %t26, ptr %t14, i64 %t15)
  %t27 = getelementptr i8, ptr %t26, i64 %t15
  call void @olang_textcopy(ptr %t27, ptr %t18, i64 %t19)
  %t28 = getelementptr i8, ptr %t27, i64 %t19
  call void @olang_textcopy(ptr %t28, ptr %t21, i64 %t22)
  %t29 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t24, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t38 = load i32, ptr %l1, !range !{i32 0, i32 838}
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t38, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1056, i32 0, i32 1) }, { i64, ptr } %t37)
  store %"compiler/msgs:Msg" %t40, ptr %l9
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d1057, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d1057, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 508, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1058, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNeedsQuestion(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 147, ptr getelementptr inbounds (<{ i64, [147 x i8] }>, ptr @.d1059, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 147, ptr getelementptr inbounds (<{ i64, [147 x i8] }>, ptr @.d1059, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 775, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1060, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 507, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1061, i32 0, i32 1) }, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d1062, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryOnCaught(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1063, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1063, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } %t1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d1064, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d1064, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t2, 1
  %t14 = extractvalue { i64, ptr } %t2, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1063, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1063, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 756, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1065, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l6
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryParens(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 153, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1066, i32 0, i32 1) }, { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d1067, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1068, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1068, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d1069, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d1069, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 340, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1070, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d1071, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d1071, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 150, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1072, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchGuard(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 574, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1073, i32 0, i32 1) }, { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d1074, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchUncovered(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d1075, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d1075, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d1076, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d1076, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 575, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1077, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchValueCase(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d1078, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d1078, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 157, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1079, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1080, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1080, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1081, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1081, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t3, i64 %t4)
  %t17 = getelementptr i8, ptr %t16, i64 %t4
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 301, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1082, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarAsValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d1083, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d1083, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 155, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1084, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNotErrorSet(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d1085, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d1085, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 200, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1086, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d1087, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d1087, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1088, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1088, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t2, 1
  %t15 = extractvalue { i64, ptr } %t2, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d1089, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d1089, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %t3, 1
  %t22 = extractvalue { i64, ptr } %t3, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d1090, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d1090, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 199, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1091, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l8
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypedHole(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l13 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 117, ptr %l2
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d1092, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb3
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1093, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1093, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t8, 1
  %t13 = extractvalue { i64, ptr } %t8, 0
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t9, i64 %t10)
  %t16 = getelementptr i8, ptr %t15, i64 %t10
  call void @olang_textcopy(ptr %t16, ptr %t12, i64 %t13)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t15, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = extractvalue { i64, ptr } %t18, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l7, !tbaa !27
  br label %bb3
bb3:
  %t27 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d1094, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d1094, i32 0, i32 1) }, 0
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t27, i64 %t28)
  %t38 = getelementptr i8, ptr %t37, i64 %t28
  call void @olang_textcopy(ptr %t38, ptr %t30, i64 %t31)
  %t39 = getelementptr i8, ptr %t38, i64 %t31
  call void @olang_textcopy(ptr %t39, ptr %t34, i64 %t35)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = load i32, ptr %l2, !range !{i32 0, i32 838}
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t49, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1095, i32 0, i32 1) }, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t51, ptr %l13
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load %"compiler/msgs:Msg", ptr %l13
  store %"compiler/msgs:Msg" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnclosedComment(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 61, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1096, i32 0, i32 1) }, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d1097, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnclosedString(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 62, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1098, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d1099, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 280, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1100, i32 0, i32 1) }, { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d1101, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 445, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1102, i32 0, i32 1) }, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d1103, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUniqueCopy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d1104, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d1104, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 257, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d1105, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUniqueFill(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1106, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1106, i32 0, i32 1) }, 0
  %t9 = extractvalue { i64, ptr } %t1, 1
  %t10 = extractvalue { i64, ptr } %t1, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d1107, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d1107, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t2, 1
  %t17 = extractvalue { i64, ptr } %t2, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d1108, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d1108, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %t3, 1
  %t24 = extractvalue { i64, ptr } %t3, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1109, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1109, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %t4, 1
  %t31 = extractvalue { i64, ptr } %t4, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d1110, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d1110, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %t5, 1
  %t38 = extractvalue { i64, ptr } %t5, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1111, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1111, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t6, i64 %t7)
  %t44 = getelementptr i8, ptr %t43, i64 %t7
  call void @olang_textcopy(ptr %t44, ptr %t9, i64 %t10)
  %t45 = getelementptr i8, ptr %t44, i64 %t10
  call void @olang_textcopy(ptr %t45, ptr %t12, i64 %t13)
  %t46 = getelementptr i8, ptr %t45, i64 %t13
  call void @olang_textcopy(ptr %t46, ptr %t16, i64 %t17)
  %t47 = getelementptr i8, ptr %t46, i64 %t17
  call void @olang_textcopy(ptr %t47, ptr %t19, i64 %t20)
  %t48 = getelementptr i8, ptr %t47, i64 %t20
  call void @olang_textcopy(ptr %t48, ptr %t23, i64 %t24)
  %t49 = getelementptr i8, ptr %t48, i64 %t24
  call void @olang_textcopy(ptr %t49, ptr %t26, i64 %t27)
  %t50 = getelementptr i8, ptr %t49, i64 %t27
  call void @olang_textcopy(ptr %t50, ptr %t30, i64 %t31)
  %t51 = getelementptr i8, ptr %t50, i64 %t31
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t37, i64 %t38)
  %t53 = getelementptr i8, ptr %t52, i64 %t38
  call void @olang_textcopy(ptr %t53, ptr %t40, i64 %t41)
  %t54 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t43, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t65 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 260, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1112, i32 0, i32 1) }, { i64, ptr } %t62)
  store %"compiler/msgs:Msg" %t65, ptr %l9
  br label %bb1
bb1:
  %t66 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUniqueImmutPart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t1, 1
  %t6 = extractvalue { i64, ptr } %t1, 0
  %t7 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d1113, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d1113, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d1114, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d1114, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %t3, 1
  %t19 = extractvalue { i64, ptr } %t3, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1115, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1115, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t5, i64 %t6)
  %t25 = getelementptr i8, ptr %t24, i64 %t6
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t11, i64 %t12)
  %t27 = getelementptr i8, ptr %t26, i64 %t12
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t18, i64 %t19)
  %t29 = getelementptr i8, ptr %t28, i64 %t19
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 256, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1116, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l8
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUniqueLentHere(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1117, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1117, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %t1, 1
  %t8 = extractvalue { i64, ptr } %t1, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d1118, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d1118, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d1119, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d1119, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %t3, 1
  %t22 = extractvalue { i64, ptr } %t3, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d1120, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d1120, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 261, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1121, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l8
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownChar(ptr %v0, i8 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 55, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %s0, i8 %a0)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1122, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1122, i32 0, i32 1) }, 0
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1123, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1123, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load i32, ptr %l1, !range !{i32 0, i32 838}
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t25, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1124, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l6
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/msgs:Msg", ptr %l6
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownErrorType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1125, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1125, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t3, i64 %t4)
  %t14 = getelementptr i8, ptr %t13, i64 %t4
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 122, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1126, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1127, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1127, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1128, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1128, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a2, 1
  %t15 = extractvalue { i64, ptr } %a2, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d1129, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d1129, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t4, i64 %t5)
  %t25 = getelementptr i8, ptr %t24, i64 %t5
  call void @olang_textcopy(ptr %t25, ptr %t7, i64 %t8)
  %t26 = getelementptr i8, ptr %t25, i64 %t8
  call void @olang_textcopy(ptr %t26, ptr %t10, i64 %t11)
  %t27 = getelementptr i8, ptr %t26, i64 %t11
  call void @olang_textcopy(ptr %t27, ptr %t14, i64 %t15)
  %t28 = getelementptr i8, ptr %t27, i64 %t15
  call void @olang_textcopy(ptr %t28, ptr %t17, i64 %t18)
  %t29 = getelementptr i8, ptr %t28, i64 %t18
  call void @olang_textcopy(ptr %t29, ptr %t21, i64 %t22)
  %t30 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t24, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1130, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFunction(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d1131, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d1131, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 120, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1132, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownImportStd(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d1133, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d1133, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1134, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1134, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 107, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1135, i32 0, i32 1) }, { i64, ptr } %t28)
  store %"compiler/msgs:Msg" %t31, ptr %l7
  br label %bb1
bb1:
  %t32 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNameMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1136, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1136, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1137, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1137, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1138, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1138, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 116, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1139, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownType(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1140, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1140, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 112, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1141, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVacateNotPlace(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 363, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1142, i32 0, i32 1) }, { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d1143, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueCaseBlock(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 570, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1144, i32 0, i32 1) }, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d1145, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d1146, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d1146, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 217, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1147, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d1148, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d1148, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 292, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1149, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarListCount(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t5 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d1150, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d1150, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t9 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  %t12 = call i64 @__olang_fmt_i64(ptr %t11, i64 %a0)
  %t13 = getelementptr i8, ptr %t11, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t5, i64 %t6)
  %t14 = getelementptr i8, ptr %t13, i64 %t6
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %a1)
  %t16 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t11, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 85, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1151, i32 0, i32 1) }, { i64, ptr } %t24)
  store %"compiler/msgs:Msg" %t27, ptr %l7
  br label %bb1
bb1:
  %t28 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVariadicArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d1152, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d1152, i32 0, i32 1) }, 0
  %t7 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1153, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1153, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1154, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1154, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t4, i64 %t5)
  %t23 = getelementptr i8, ptr %t22, i64 %t5
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a0)
  %t25 = getelementptr i8, ptr %t23, i64 %t7
  call void @olang_textcopy(ptr %t25, ptr %t9, i64 %t10)
  %t26 = getelementptr i8, ptr %t25, i64 %t10
  call void @olang_textcopy(ptr %t26, ptr %t13, i64 %t14)
  %t27 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %a2)
  %t30 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t22, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 467, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1155, i32 0, i32 1) }, { i64, ptr } %t38)
  store %"compiler/msgs:Msg" %t41, ptr %l9
  br label %bb1
bb1:
  %t42 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVariadicDefault(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 464, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1156, i32 0, i32 1) }, { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d1157, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVariadicNotLast(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 462, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1158, i32 0, i32 1) }, { i64, ptr } { i64 140, ptr getelementptr inbounds (<{ i64, [140 x i8] }>, ptr @.d1159, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1160, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d1160, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1161, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1161, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1162, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1162, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 684, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1163, i32 0, i32 1) }, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t35, ptr %l7
  br label %bb1
bb1:
  %t36 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1164, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1164, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1165, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1165, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %a1, 1
  %t15 = extractvalue { i64, ptr } %a1, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1166, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1166, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a2, 1
  %t22 = extractvalue { i64, ptr } %a2, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1167, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1167, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t4, i64 %t5)
  %t28 = getelementptr i8, ptr %t27, i64 %t5
  call void @olang_textcopy(ptr %t28, ptr %t7, i64 %t8)
  %t29 = getelementptr i8, ptr %t28, i64 %t8
  call void @olang_textcopy(ptr %t29, ptr %t10, i64 %t11)
  %t30 = getelementptr i8, ptr %t29, i64 %t11
  call void @olang_textcopy(ptr %t30, ptr %t14, i64 %t15)
  %t31 = getelementptr i8, ptr %t30, i64 %t15
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t21, i64 %t22)
  %t33 = getelementptr i8, ptr %t32, i64 %t22
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t27, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t45 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, i32 683, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1168, i32 0, i32 1) }, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t45, ptr %l9
  br label %bb1
bb1:
  %t46 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eViewReturned(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d1169, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d1169, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d1170, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d1170, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 587, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1171, i32 0, i32 1) }, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t25, ptr %l5
  br label %bb1
bb1:
  %t26 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWholeCaseNamed(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1172, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1172, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %t1, 1
  %t9 = extractvalue { i64, ptr } %t1, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1173, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1173, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %t2, 1
  %t16 = extractvalue { i64, ptr } %t2, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d1174, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d1174, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %t3, 1
  %t23 = extractvalue { i64, ptr } %t3, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1175, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1175, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %t4, 1
  %t30 = extractvalue { i64, ptr } %t4, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d1176, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d1176, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t5, i64 %t6)
  %t36 = getelementptr i8, ptr %t35, i64 %t6
  call void @olang_textcopy(ptr %t36, ptr %t8, i64 %t9)
  %t37 = getelementptr i8, ptr %t36, i64 %t9
  call void @olang_textcopy(ptr %t37, ptr %t11, i64 %t12)
  %t38 = getelementptr i8, ptr %t37, i64 %t12
  call void @olang_textcopy(ptr %t38, ptr %t15, i64 %t16)
  %t39 = getelementptr i8, ptr %t38, i64 %t16
  call void @olang_textcopy(ptr %t39, ptr %t18, i64 %t19)
  %t40 = getelementptr i8, ptr %t39, i64 %t19
  call void @olang_textcopy(ptr %t40, ptr %t22, i64 %t23)
  %t41 = getelementptr i8, ptr %t40, i64 %t23
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t35, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, i32 461, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1177, i32 0, i32 1) }, { i64, ptr } %t52)
  store %"compiler/msgs:Msg" %t55, ptr %l9
  br label %bb1
bb1:
  %t56 = load %"compiler/msgs:Msg", ptr %l9
  store %"compiler/msgs:Msg" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWildcardNotAlone(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 581, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1178, i32 0, i32 1) }, { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d1179, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteIntoCallValue(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 386, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1180, i32 0, i32 1) }, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d1181, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtBuilds(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 495, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1182, i32 0, i32 1) }, { i64, ptr } { i64 148, ptr getelementptr inbounds (<{ i64, [148 x i8] }>, ptr @.d1183, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInDefer(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 592, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1184, i32 0, i32 1) }, { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d1185, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInJoin(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 593, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1186, i32 0, i32 1) }, { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d1187, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOutside(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 590, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1188, i32 0, i32 1) }, { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d1189, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOwnStorage(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 598, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1190, i32 0, i32 1) }, { i64, ptr } { i64 139, ptr getelementptr inbounds (<{ i64, [139 x i8] }>, ptr @.d1191, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldPastHeld(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v0, ptr %v0, i32 595, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1192, i32 0, i32 1) }, { i64, ptr } { i64 179, ptr getelementptr inbounds (<{ i64, [179 x i8] }>, ptr @.d1193, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t2, ptr %l1
  br label %bb1
bb1:
  %t3 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_2eZeroValueShared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca %"compiler/msgs:Msg"
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d1194, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d1194, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, i32 662, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1195, i32 0, i32 1) }, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t21, ptr %l5
  br label %bb1
bb1:
  %t22 = load %"compiler/msgs:Msg", ptr %l5
  store %"compiler/msgs:Msg" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/msgs:Nearest", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/msgs:Nearest", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t14 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1196, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1196, i32 0, i32 1) }, 0
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } %t13, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1197, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1197, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = getelementptr i8, ptr %t23, i64 %t15
  call void @olang_textcopy(ptr %t24, ptr %t17, i64 %t18)
  %t25 = getelementptr i8, ptr %t24, i64 %t18
  call void @olang_textcopy(ptr %t25, ptr %t20, i64 %t21)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1198, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  br label %bb3
bb3:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l11, !tbaa !24
  %t33 = load i64, ptr %l11, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l12, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l11, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t44, ptr %l5, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/msgs:Msg"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/msgs:Msg" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/msgs:Msg" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/msgs:Msg" %t10, { i64, ptr } %a2, 2
  store %"compiler/msgs:Msg" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

@.d0 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is already declared here" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" is bound as " }>, align 8
@.d3 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c" by an earlier alternative - split the case" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13c" }>, align 8
@.d5 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c" is matched by an earlier clause - this one is never reached" }>, align 8
@.d6 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T34" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d8 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c" ties where what it is given lives to what it keeps or gives back, which a call through an 'any " }>, align 8
@.d9 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"&' cannot check - call it directly, or through generic code" }>, align 8
@.d10 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T32a, T22a" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d12 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" says where its references live as " }>, align 8
@.d13 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"'s signature does not - it cannot be called through an 'any " }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&'" }>, align 8
@.d15 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"T32a, T22" }>, align 8
@.d16 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c" keeps a copy of the value it is called on, and an " }>, align 8
@.d17 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c" has none - call it on the instance's own type" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T32" }>, align 8
@.d19 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" has no method " }>, align 8
@.d20 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c" - an 'any' is used through its trait's methods alone" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T32b" }>, align 8
@.d22 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"a task calls a function or a function value, never through an 'any''s table - write 'spawn fn() { " }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" }'" }>, align 8
@.d24 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"T32b, P1" }>, align 8
@.d25 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be an 'any " }>, align 8
@.d26 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"&': it has no method " }>, align 8
@.d27 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" that fits" }>, align 8
@.d28 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"T32a, T31" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d30 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"' names no .olang file on either side" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B21" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d33 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"' is neither a path nor a commit of the repository here" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B21" }>, align 8
@.d35 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d37 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" arguments, found " }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E14" }>, align 8
@.d39 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"an array written '&' is never null - test whether it is empty: write '" }>, align 8
@.d40 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"', or '?&' where it may be null" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d42 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"an array's length is from 0 to the largest whose bytes fit an I64, found " }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T7c" }>, align 8
@.d44 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"an array of " }>, align 8
@.d45 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" elements stored where " }>, align 8
@.d46 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c" are laid out - fixed storage takes an array of its own length" }>, align 8
@.d47 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T7d" }>, align 8
@.d48 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c" holds itself through the array it is declared over - hold the array in a struct: 'type " }>, align 8
@.d49 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" struct(items " }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"&)'" }>, align 8
@.d51 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T29" }>, align 8
@.d52 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E32" }>, align 8
@.d53 = private constant <{ i64, [105 x i8] }> <{ i64 0, [105 x i8] c"'as' fails where the value holds another case - write 'try' before it and catch CaseError, or '(x as C)!'" }>, align 8
@.d54 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"this assertion is false, evaluated while compiling: " }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S18c" }>, align 8
@.d56 = private constant <{ i64, [134 x i8] }> <{ i64 0, [134 x i8] c"this assertion is false, evaluated while compiling; its message reads what only the running program knows, so it is shown as written: " }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S18c" }>, align 8
@.d58 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c" message may not return - it is evaluated only where it is used, and gives text" }>, align 8
@.d59 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S17" }>, align 8
@.d60 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" targets need as many values, found " }>, align 8
@.d61 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S4c" }>, align 8
@.d62 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c" declares SetAt but not At, which reading x[i] calls" }>, align 8
@.d63 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d64 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"the atomic operations are methods of the integer types, and " }>, align 8
@.d65 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is none" }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P9" }>, align 8
@.d67 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P9" }>, align 8
@.d68 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"this atomic operation writes its place, which must be writable" }>, align 8
@.d69 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"an attribute's value is built while compiling, and this one cannot be: " }>, align 8
@.d70 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G39" }>, align 8
@.d71 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G39" }>, align 8
@.d72 = private constant <{ i64, [140 x i8] }> <{ i64 0, [140 x i8] c"an attribute is written before a type, a function or a method, an enum's case, a constructor's field or a parameter - nothing here takes one" }>, align 8
@.d73 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"field '" }>, align 8
@.d74 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c"' is a pun of its parameter, and has the parameter's attributes - write the attribute on the parameter" }>, align 8
@.d75 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G39" }>, align 8
@.d76 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unknown escape '\5C" }>, align 8
@.d77 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"' - the escapes are \5Cn \5Ct \5Cr \5C0 \5C\5C \5C' \5C\22" }>, align 8
@.d78 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L15" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d79 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E35" }>, align 8
@.d80 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"nothing here can fail - write it without '!'" }>, align 8
@.d81 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"'become' closes this function's scopes before the call, and " }>, align 8
@.d82 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c" whose destructor would run then, before the call - write 'return' and the call" }>, align 8
@.d83 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S21" }>, align 8
@.d84 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"'become' makes the callee's failure this function's own, and this one fails with " }>, align 8
@.d85 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", the callee with " }>, align 8
@.d86 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c" - give them one error set, in one order, or write 'return try' and the call" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S21" }>, align 8
@.d88 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S21" }>, align 8
@.d89 = private constant <{ i64, [158 x i8] }> <{ i64 0, [158 x i8] c"'become' cannot jump where a parameter or the result is over 128 bytes, passed through memory the function's frame holds - pass a reference, or write 'return'" }>, align 8
@.d90 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"'become' takes a call of a function or a method declared with fn, and this is " }>, align 8
@.d91 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" - write 'return' instead" }>, align 8
@.d92 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S21" }>, align 8
@.d93 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"'become' ends a function declared with fn, never " }>, align 8
@.d94 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" - write 'return' and the call" }>, align 8
@.d95 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S21" }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S21" }>, align 8
@.d97 = private constant <{ i64, [99 x i8] }> <{ i64 0, [99 x i8] c"'become' takes the call alone - what it fails with is the function's own, so write it without 'try'" }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d99 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"' is not a binary digit" }>, align 8
@.d100 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L10c" }>, align 8
@.d101 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L10c" }>, align 8
@.d102 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"'0b' needs binary digits" }>, align 8
@.d103 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"the block opened on line " }>, align 8
@.d104 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" has no '}' - found " }>, align 8
@.d105 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d106 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O17" }>, align 8
@.d107 = private constant <{ i64, [136 x i8] }> <{ i64 0, [136 x i8] c"this value's references live where its own storage does not, and the callee can store through it - declare it a reference ('x T& = ...')" }>, align 8
@.d108 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O17a" }>, align 8
@.d109 = private constant <{ i64, [114 x i8] }> <{ i64 0, [114 x i8] c"this value's references live where its own storage does not, so it is not held by reference - use the value itself" }>, align 8
@.d110 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" is bound twice in one alternative" }>, align 8
@.d111 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13c" }>, align 8
@.d112 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c" acts on the innermost loop, and there is none here" }>, align 8
@.d113 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S11" }>, align 8
@.d114 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" is a build constant - choose another name" }>, align 8
@.d115 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d116 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-define " }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d118 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" does not fit " }>, align 8
@.d119 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", which is " }>, align 8
@.d120 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B10c" }>, align 8
@.d121 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"O11, O12" }>, align 8
@.d122 = private constant <{ i64, [113 x i8] }> <{ i64 0, [113 x i8] c"where this reference's referent lives is not known here, and the callee may build there - give it one known scope" }>, align 8
@.d123 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c" is a built-in type's name - choose another" }>, align 8
@.d124 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D3a" }>, align 8
@.d125 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"no C file at " }>, align 8
@.d126 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X17" }>, align 8
@.d127 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"the C import has no olang form of '" }>, align 8
@.d128 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"': " }>, align 8
@.d129 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X19" }>, align 8
@.d130 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"C may write through this pointer, and " }>, align 8
@.d131 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c" is read-only - pass a writable one ('mut')" }>, align 8
@.d132 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X22" }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d134 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c"' gives a value and does nothing else - use the value (assign it, pass it on), or leave the call out" }>, align 8
@.d135 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"S3" }>, align 8
@.d136 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"'s Call fails with " }>, align 8
@.d137 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" where the function type says " }>, align 8
@.d138 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c" - the same errors in the same order: " }>, align 8
@.d139 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"T22, E31" }>, align 8
@.d140 = private constant <{ i64, [142 x i8] }> <{ i64 0, [142 x i8] c"'s Call ties where what it is given lives to what it keeps or gives back, which a call through a function value cannot check - call it by name" }>, align 8
@.d141 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"T22a, E31" }>, align 8
@.d142 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X13" }>, align 8
@.d143 = private constant <{ i64, [111 x i8] }> <{ i64 0, [111 x i8] c"a C function is given a function by the name of an export fn - declare one with 'export fn' and pass it by name" }>, align 8
@.d144 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the program cannot be run: " }>, align 8
@.d145 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B3g" }>, align 8
@.d146 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D16c" }>, align 8
@.d147 = private constant <{ i64, [84 x i8] }> <{ i64 0, [84 x i8] c"a lambda's captures are read-only - capture a reference to change what is outside it" }>, align 8
@.d148 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"L3" }>, align 8
@.d149 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"carriage return - save the file with LF line endings" }>, align 8
@.d150 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13f" }>, align 8
@.d151 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"no value reaches this - an earlier 'case _' with no guard takes every one" }>, align 8
@.d152 = private constant <{ i64, [115 x i8] }> <{ i64 0, [115 x i8] c" is the value being matched, so this compares it with itself - to take any value and test it, write 'case _ if ...'" }>, align 8
@.d153 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13f" }>, align 8
@.d154 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" is a case of an enum, and this is " }>, align 8
@.d155 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E32" }>, align 8
@.d156 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is no case of " }>, align 8
@.d157 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c", the type this tests" }>, align 8
@.d158 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E32" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d159 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"the type arguments of " }>, align 8
@.d160 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" cannot be inferred from this case - write them, '" }>, align 8
@.d161 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"<...>." }>, align 8
@.d162 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"', or give it a type to land in" }>, align 8
@.d163 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10c" }>, align 8
@.d164 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"a spawned call's clause runs on the task's thread and names no error - leave " }>, align 8
@.d165 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c" off, or catch it where the join fails" }>, align 8
@.d166 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d167 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c" names the error this clause took, and nothing uses it - leave the name off" }>, align 8
@.d168 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d169 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"the call does not fail with " }>, align 8
@.d170 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R14" }>, align 8
@.d171 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"the call does not fail with " }>, align 8
@.d172 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - it fails with " }>, align 8
@.d173 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R14" }>, align 8
@.d174 = private constant <{ i64, [113 x i8] }> <{ i64 0, [113 x i8] c" names the error this clause took and is never assigned - hold a value that changes in a local of its own ('x := " }>, align 8
@.d175 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"')" }>, align 8
@.d176 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d177 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d178 = private constant <{ i64, [80 x i8] }> <{ i64 0, [80 x i8] c"a case of an error value names an error word, an error type, a named set or null" }>, align 8
@.d179 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"this case is never reached: the cases before it take every error " }>, align 8
@.d180 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" can be" }>, align 8
@.d181 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d182 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T20" }>, align 8
@.d183 = private constant <{ i64, [80 x i8] }> <{ i64 0, [80 x i8] c"two error types are never compared - compare an error value with each ('e == T')" }>, align 8
@.d184 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d185 = private constant <{ i64, [139 x i8] }> <{ i64 0, [139 x i8] c"a match on an error value used as a value gives a value in every clause, 'case P: v' - a clause that leaves is written in a match statement" }>, align 8
@.d186 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" is never " }>, align 8
@.d187 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" here - it is " }>, align 8
@.d188 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d189 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L13" }>, align 8
@.d190 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"character literal not closed on its line" }>, align 8
@.d191 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"Char has no method " }>, align 8
@.d192 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" - a character is padded as text: '($c)." }>, align 8
@.d193 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(n)'" }>, align 8
@.d194 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"M19, T29f" }>, align 8
@.d195 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"clang could not compile " }>, align 8
@.d196 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d197 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"a block's last value is not the clause's value - write '} default " }>, align 8
@.d198 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"' after the block" }>, align 8
@.d199 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R11" }>, align 8
@.d200 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"with 'commutes' here, " }>, align 8
@.d201 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" between " }>, align 8
@.d202 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d203 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" would call this method or " }>, align 8
@.d204 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" - remove 'commutes'" }>, align 8
@.d205 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E31c" }>, align 8
@.d206 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"'commutes' is written only on a Plus, Mul, BitAnd, BitOr or BitXor of one parameter, and " }>, align 8
@.d207 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" is none - remove it" }>, align 8
@.d208 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E31c" }>, align 8
@.d209 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E27" }>, align 8
@.d210 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"a comprehension's elements may not be or hold references yet - build the array with a loop" }>, align 8
@.d211 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"a comptime for's elements are integers, Bool or Char, found " }>, align 8
@.d212 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c" - walk its positions: 'comptime for i in range xs.Len()'" }>, align 8
@.d213 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"K3a" }>, align 8
@.d214 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a comptime for walks a range or an array, found " }>, align 8
@.d215 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" - give it an array: 'comptime for x in xs.View()'" }>, align 8
@.d216 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"K3a" }>, align 8
@.d217 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"this comptime for unrolls into " }>, align 8
@.d218 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" copies, at most " }>, align 8
@.d219 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" - walk it at run time: drop 'comptime'" }>, align 8
@.d220 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"K3a" }>, align 8
@.d221 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"K3a" }>, align 8
@.d222 = private constant <{ i64, [126 x i8] }> <{ i64 0, [126 x i8] c"a comptime for's elements are computed while compiling, so nothing of its walk fails at run time - write 'comptime for x in e'" }>, align 8
@.d223 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"a comptime is computed while compiling, and this one cannot be: " }>, align 8
@.d224 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"K3" }>, align 8
@.d225 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" is defined in terms of itself" }>, align 8
@.d226 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B9a" }>, align 8
@.d227 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c" is mutable, so a top-level condition cannot read it" }>, align 8
@.d228 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B9a" }>, align 8
@.d229 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c": these numbers' types do not meet - convert one, as I64(n)" }>, align 8
@.d230 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T6b" }>, align 8
@.d231 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"conditions decide branches holding further conditions more than " }>, align 8
@.d232 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" levels deep" }>, align 8
@.d233 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B9c" }>, align 8
@.d234 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"this top-level condition cannot be decided while compiling: " }>, align 8
@.d235 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B9c" }>, align 8
@.d236 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown name " }>, align 8
@.d237 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d238 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B9c" }>, align 8
@.d239 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"this top-level condition uses what exists only in the branches it decides, or does not check" }>, align 8
@.d240 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c" is constrained differently elsewhere in this declaration - one constraint per variable" }>, align 8
@.d241 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G19" }>, align 8
@.d242 = private constant <{ i64, [133 x i8] }> <{ i64 0, [133 x i8] c" is not a trait, so it cannot constrain a type variable - a type parameter's constraint is a trait, and a length is no parameter (T7)" }>, align 8
@.d243 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"G6, G19" }>, align 8
@.d244 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d245 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d246 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G19" }>, align 8
@.d247 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d248 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d249 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c": it has no Hash - declare 'Hash() I64', agreeing with '=='" }>, align 8
@.d250 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"G19, E10b" }>, align 8
@.d251 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O25a" }>, align 8
@.d252 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"this container's scope cannot be built into from here - write through the global itself" }>, align 8
@.d253 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" has conditions, so a call fails with ArgumentError where one is false - add it after '?'" }>, align 8
@.d254 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D17" }>, align 8
@.d255 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"only a struct or an enum the program declares has a Copy of its own, not " }>, align 8
@.d256 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" - its supplied Copy is the one" }>, align 8
@.d257 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E31d" }>, align 8
@.d258 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"Copy takes nothing but its receiver, read through a read-only reference, gives a new " }>, align 8
@.d259 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" and cannot fail - write 'fn (x " }>, align 8
@.d260 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"&) Copy() " }>, align 8
@.d261 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d262 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E31d" }>, align 8
@.d263 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"field " }>, align 8
@.d264 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c" names no parameter of the constructor - give it a value, with '=' or ':='" }>, align 8
@.d265 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"C4" }>, align 8
@.d266 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"field " }>, align 8
@.d267 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c" takes its type from ':=', and the constructor introduces " }>, align 8
@.d268 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c", so its body is checked per call - write the field's type" }>, align 8
@.d269 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10d" }>, align 8
@.d270 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"the type arguments of " }>, align 8
@.d271 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c" cannot be inferred from these arguments - write them: " }>, align 8
@.d272 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"<...>(...)" }>, align 8
@.d273 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10c" }>, align 8
@.d274 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" is declared twice" }>, align 8
@.d275 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d276 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E14a" }>, align 8
@.d277 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"'default' stands only for a parameter's declared default, in a call" }>, align 8
@.d278 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
@.d279 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" defaults, one per result, found " }>, align 8
@.d280 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R11" }>, align 8
@.d281 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"a default is computed while compiling, and this one cannot be: " }>, align 8
@.d282 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8a" }>, align 8
@.d283 = private constant <{ i64, [80 x i8] }> <{ i64 0, [80 x i8] c" has no default, but a parameter before it does - defaulted parameters come last" }>, align 8
@.d284 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8a" }>, align 8
@.d285 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"a default of trait " }>, align 8
@.d286 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" is declared in that trait's module" }>, align 8
@.d287 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19e" }>, align 8
@.d288 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S19b" }>, align 8
@.d289 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"an error may not leave deferred code - catch it here" }>, align 8
@.d290 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c" may not leave deferred code - it runs while its block is left" }>, align 8
@.d291 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S19b" }>, align 8
@.d292 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"-define cannot redefine the built-in constant " }>, align 8
@.d293 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B10a" }>, align 8
@.d294 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-define " }>, align 8
@.d295 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d296 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": beyond F64's range" }>, align 8
@.d297 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d298 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-define " }>, align 8
@.d299 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d300 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c": below I64's minimum" }>, align 8
@.d301 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d302 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"-define takes Name=value, found '" }>, align 8
@.d303 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d304 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B10" }>, align 8
@.d305 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"the compiler supplies Destroy() for " }>, align 8
@.d306 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c", which declares a destructor - choose another name" }>, align 8
@.d307 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C9b" }>, align 8
@.d308 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"Destroy() runs a destructor, and " }>, align 8
@.d309 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" declares none" }>, align 8
@.d310 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C9b" }>, align 8
@.d311 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C9b" }>, align 8
@.d312 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"Destroy() is called on a local - a variable of this function holding the instance" }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d314 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c".Destroy()' needs '" }>, align 8
@.d315 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"' to be the only way left to reach its instance" }>, align 8
@.d316 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C9b" }>, align 8
@.d317 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8c" }>, align 8
@.d318 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c"':=' declares each target, so each is a name or '_' - use '=' to assign into places" }>, align 8
@.d319 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a destructor releases what one value holds, so " }>, align 8
@.d320 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" is unique - declare it 'type " }>, align 8
@.d321 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" unique struct(...)'" }>, align 8
@.d322 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"C11, T13b" }>, align 8
@.d323 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c" has a destructor to run, and an array of a run-time length ends none of its elements - keep them in a Vec<" }>, align 8
@.d324 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c">, or hold " }>, align 8
@.d325 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"& ones" }>, align 8
@.d326 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C11" }>, align 8
@.d327 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" has a destructor to run, and " }>, align 8
@.d328 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c" keeps values of it where no holder ends them - write " }>, align 8
@.d329 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"&, or keep them in a Vec<" }>, align 8
@.d330 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d331 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C11" }>, align 8
@.d332 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L10b" }>, align 8
@.d333 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"'_' in a number must stand between two digits" }>, align 8
@.d334 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E6a" }>, align 8
@.d335 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"division by zero" }>, align 8
@.d336 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d337 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"' is no item of " }>, align 8
@.d338 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" - 'olang doc " }>, align 8
@.d339 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"' lists them" }>, align 8
@.d340 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B14" }>, align 8
@.d341 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T24" }>, align 8
@.d342 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a type takes at most one reference marker" }>, align 8
@.d343 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O25c" }>, align 8
@.d344 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c"this element can be stored through, so it lives exactly where the array is put - build it there" }>, align 8
@.d345 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"an array pattern matches an array, text or a type declaring At and Len - " }>, align 8
@.d346 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" is none of them" }>, align 8
@.d347 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13h" }>, align 8
@.d348 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"this array pattern's elements are " }>, align 8
@.d349 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c", and what is matched holds " }>, align 8
@.d350 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" - write '" }>, align 8
@.d351 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"[...]'" }>, align 8
@.d352 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13h" }>, align 8
@.d353 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"embed " }>, align 8
@.d354 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" reads no file: " }>, align 8
@.d355 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E38" }>, align 8
@.d356 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E38" }>, align 8
@.d357 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"an embed's path is text known while compiling - a literal, or what reads no local" }>, align 8
@.d358 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C7a" }>, align 8
@.d359 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"this destructor does nothing - remove it" }>, align 8
@.d360 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c" holds an error here, never null - a caught error, a word written or a value a test says is not null" }>, align 8
@.d361 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T20" }>, align 8
@.d362 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T19b, S13b" }>, align 8
@.d363 = private constant <{ i64, [99 x i8] }> <{ i64 0, [99 x i8] c"a payload pattern binding a name stands alone in its case - give each alternative a case of its own" }>, align 8
@.d364 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d365 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c": an error value is no number - it is compared with '==' and '!=', and rendered with '$'" }>, align 8
@.d366 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T20" }>, align 8
@.d367 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
@.d368 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d369 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c", which can be " }>, align 8
@.d370 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c" - test it first ('if e == T'), or hold it in a set that has it" }>, align 8
@.d371 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T20" }>, align 8
@.d372 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R1a" }>, align 8
@.d373 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"'?' alone is what the body can fail with - write '?', or name the types: '? io.Error'" }>, align 8
@.d374 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"an error value's " }>, align 8
@.d375 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" is the language's (T20) - " }>, align 8
@.d376 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" cannot declare one; choose another name" }>, align 8
@.d377 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T20" }>, align 8
@.d378 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"error word " }>, align 8
@.d379 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" is already declared" }>, align 8
@.d380 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T19" }>, align 8
@.d381 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"this function's '?' names " }>, align 8
@.d382 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c", not this word - add it after '?'" }>, align 8
@.d383 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"R3" }>, align 8
@.d384 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
@.d385 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d386 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d387 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B11a" }>, align 8
@.d388 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"explain takes one rule, as 'olang explain B1'" }>, align 8
@.d389 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"an export fn's caller is C, which nothing holds to what its body requires (" }>, align 8
@.d390 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c") - keep what it is given only for the call" }>, align 8
@.d391 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X12" }>, align 8
@.d392 = private constant <{ i64, [163 x i8] }> <{ i64 0, [163 x i8] c" cannot come from C - an export fn's parameter is a number, a Bool, an extern type's reference, a plain-data struct or a reference to one, or an array by reference" }>, align 8
@.d393 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X12" }>, align 8
@.d394 = private constant <{ i64, [188 x i8] }> <{ i64 0, [188 x i8] c" cannot cross the C boundary - an extern parameter is a number of the twelve primitives, a Bool, an extern type's reference, a plain-data struct or a reference to one, or an array of these" }>, align 8
@.d395 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"X2" }>, align 8
@.d396 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c" is generic, and each of its instances has facts of its own - name one with its type arguments: '" }>, align 8
@.d397 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"<T>." }>, align 8
@.d398 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d399 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G42" }>, align 8
@.d400 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"field " }>, align 8
@.d401 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c" has a parameter's name - write it bare to take the parameter's value, or name it apart" }>, align 8
@.d402 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C2a" }>, align 8
@.d403 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" is an enum - its payload's '" }>, align 8
@.d404 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"' is read where a test narrows a local or a parameter to the case, 'if e == Case { e." }>, align 8
@.d405 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" }', until it is assigned" }>, align 8
@.d406 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S8d" }>, align 8
@.d407 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R23" }>, align 8
@.d408 = private constant <{ i64, [133 x i8] }> <{ i64 0, [133 x i8] c"a Bool among several results is a flag beside a value - what can fail says so with '? E' and raises an error instead (error NotFound)" }>, align 8
@.d409 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" is beyond F64's range" }>, align 8
@.d410 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L12b" }>, align 8
@.d411 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S9e" }>, align 8
@.d412 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"this loop's own calls can fail - write 'for x in try c', with catch clauses after the body" }>, align 8
@.d413 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S9e" }>, align 8
@.d414 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"nothing this loop calls by itself can fail - drop the 'try'" }>, align 8
@.d415 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c" is an extern type: only C makes one - declare the C function that does, as 'extern fn open() " }>, align 8
@.d416 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&'" }>, align 8
@.d417 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X10" }>, align 8
@.d418 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c" is an extern type, held only by reference - write '" }>, align 8
@.d419 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"&', or '" }>, align 8
@.d420 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"?&' where it may be null" }>, align 8
@.d421 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X10" }>, align 8
@.d422 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"the formatter could not be built - " }>, align 8
@.d423 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" says why" }>, align 8
@.d424 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B13" }>, align 8
@.d425 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"the formatter's source is not beside this compiler: " }>, align 8
@.d426 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B13" }>, align 8
@.d427 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"'From' makes a case from its raw value alone, and " }>, align 8
@.d428 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"'s case '" }>, align 8
@.d429 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"' carries a payload" }>, align 8
@.d430 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d431 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c" is a function type, held only by reference - write '" }>, align 8
@.d432 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"&', or '" }>, align 8
@.d433 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"?&' where it may be null" }>, align 8
@.d434 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T21b" }>, align 8
@.d435 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
@.d436 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d437 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c" - a declared function type is a type of its own: write '" }>, align 8
@.d438 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"(f)' to make one the other" }>, align 8
@.d439 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"T21b, T29" }>, align 8
@.d440 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"a function type is held only by reference - write 'fn&" }>, align 8
@.d441 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"', or 'fn?&" }>, align 8
@.d442 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"' where it may be null" }>, align 8
@.d443 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T21" }>, align 8
@.d444 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R1b" }>, align 8
@.d445 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c"a function type writes its error set - '? io.Error' - since no body says what it is" }>, align 8
@.d446 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d447 = private constant <{ i64, [137 x i8] }> <{ i64 0, [137 x i8] c"' ties where what it is given lives to what it keeps or gives back, which a call through a function value cannot check - call it directly" }>, align 8
@.d448 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T22a" }>, align 8
@.d449 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-fuzz " }>, align 8
@.d450 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c" names no test of this file - give a test's target, its target's type or a word of its description" }>, align 8
@.d451 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B19" }>, align 8
@.d452 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"-fuzztime takes a whole number of seconds, at least 1, and '" }>, align 8
@.d453 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"' is none" }>, align 8
@.d454 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B19" }>, align 8
@.d455 = private constant <{ i64, [141 x i8] }> <{ i64 0, [141 x i8] c" has conditions, so its first Next fails with ArgumentError where one is false - add it to its result's errors, 'Iterator<T ? ArgumentError>'" }>, align 8
@.d456 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"D18, D17" }>, align 8
@.d457 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"this generator's elements live " }>, align 8
@.d458 = private constant <{ i64, [137 x i8] }> <{ i64 0, [137 x i8] c", and this value is not shown to last as long - yield a part of what lives there, or values ('Iterator<T>') and a copy ('$x', 'x.Copy()')" }>, align 8
@.d459 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"D18c, S20" }>, align 8
@.d460 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" needs " }>, align 8
@.d461 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", and " }>, align 8
@.d462 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" has none - declare it for " }>, align 8
@.d463 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", or call " }>, align 8
@.d464 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" with a type that has it" }>, align 8
@.d465 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G18" }>, align 8
@.d466 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"generic function '" }>, align 8
@.d467 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"' is not a value - call it, or name an instance by its type arguments, as '" }>, align 8
@.d468 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"<I64>'" }>, align 8
@.d469 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G12" }>, align 8
@.d470 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"this global's initializer aborts the program, evaluated while compiling: " }>, align 8
@.d471 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"K2" }>, align 8
@.d472 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O1b" }>, align 8
@.d473 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"a global holds only what lives as long as the program - store something built here, or another global's" }>, align 8
@.d474 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"evaluated while compiling, this global's initializer stops on a stale view: " }>, align 8
@.d475 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"K2, K1" }>, align 8
@.d476 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"these globals' initializers read each other, so none can be set first: " }>, align 8
@.d477 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B5a" }>, align 8
@.d478 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a guard is a Bool, found " }>, align 8
@.d479 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13e" }>, align 8
@.d480 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d481 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"help takes at most one mode" }>, align 8
@.d482 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d483 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"' is not a hexadecimal digit" }>, align 8
@.d484 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L10a" }>, align 8
@.d485 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L10a" }>, align 8
@.d486 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"'0x' needs hexadecimal digits" }>, align 8
@.d487 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c" cannot be written - only a local, a parameter or a 'mut' global can" }>, align 8
@.d488 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"S6" }>, align 8
@.d489 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d490 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"' is no identifier, so it cannot be this import's alias - write one: import Name \22...\22" }>, align 8
@.d491 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"M4" }>, align 8
@.d492 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"could not fetch " }>, align 8
@.d493 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c" with git - check the path and the connection" }>, align 8
@.d494 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M23a" }>, align 8
@.d495 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"no .olang file at " }>, align 8
@.d496 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M23" }>, align 8
@.d497 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M23" }>, align 8
@.d498 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"an import names its file without '.olang'" }>, align 8
@.d499 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d500 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c" is private to its module - only a capitalized alias is re-exported" }>, align 8
@.d501 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M14" }>, align 8
@.d502 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"could not fetch the commit olang.lock names for " }>, align 8
@.d503 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" - delete its line, or build with -update" }>, align 8
@.d504 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"M23b, M23c" }>, align 8
@.d505 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M23" }>, align 8
@.d506 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"this import path is too long to name a file" }>, align 8
@.d507 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M23" }>, align 8
@.d508 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"a remote import names a file in the repository: host/owner/repo[@ref]/path" }>, align 8
@.d509 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" takes a number, found " }>, align 8
@.d510 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S3a" }>, align 8
@.d511 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"an index is an integer, found " }>, align 8
@.d512 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E16" }>, align 8
@.d513 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"index " }>, align 8
@.d514 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" is outside the array's " }>, align 8
@.d515 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" elements" }>, align 8
@.d516 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E16" }>, align 8
@.d517 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" gives a reference here, and " }>, align 8
@.d518 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c" cannot be one - only a struct, an enum or an array can: read the value instead (as 'x[i]' does)" }>, align 8
@.d519 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T24" }>, align 8
@.d520 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d521 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c", hold it by value in a field, or give it a copy (" }>, align 8
@.d522 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d523 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", or hold it by value in a field" }>, align 8
@.d524 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"this instance holds a reference to an argument it would outlive - make the argument where the instance goes" }>, align 8
@.d525 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C2d" }>, align 8
@.d526 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"the library '" }>, align 8
@.d527 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"' a link names cannot be loaded into interpret: " }>, align 8
@.d528 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" - build the program instead" }>, align 8
@.d529 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B3e" }>, align 8
@.d530 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"'as' asks for an enum value's payload, and this is " }>, align 8
@.d531 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E32" }>, align 8
@.d532 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"a join piece is a text literal or a '$' rendering - write '$" }>, align 8
@.d533 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d534 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E11b" }>, align 8
@.d535 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" is a keyword, not a name - choose another" }>, align 8
@.d536 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"L9" }>, align 8
@.d537 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" takes " }>, align 8
@.d538 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" parameter" }>, align 8
@.d539 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", and this lambda " }>, align 8
@.d540 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D16a" }>, align 8
@.d541 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T22a" }>, align 8
@.d542 = private constant <{ i64, [153 x i8] }> <{ i64 0, [153 x i8] c"this lambda ties where what it is given lives to what it keeps or gives back - its captures included - which a call through a function value cannot check" }>, align 8
@.d543 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" takes lanes of Bool, found " }>, align 8
@.d544 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E39" }>, align 8
@.d545 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E39" }>, align 8
@.d546 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"lane operators give elements that may not be or hold references - build the array with a loop" }>, align 8
@.d547 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d548 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"Len gives an I64" }>, align 8
@.d549 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d550 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"' takes an array by value, an instance per length (G29), so it is no value - pass a lambda calling it" }>, align 8
@.d551 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G12" }>, align 8
@.d552 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d553 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"Less, which '<' calls, gives a Bool" }>, align 8
@.d554 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"this literal enters " }>, align 8
@.d555 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c" through its constructor, which does not run on it while compiling: " }>, align 8
@.d556 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T29d" }>, align 8
@.d557 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"this literal does not fit " }>, align 8
@.d558 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", and " }>, align 8
@.d559 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" does not flow into " }>, align 8
@.d560 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" - convert one" }>, align 8
@.d561 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E6d" }>, align 8
@.d562 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E4a" }>, align 8
@.d563 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"this literal expression has no value - no integer type holds it, from I128's least to U128's greatest" }>, align 8
@.d564 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"a value of " }>, align 8
@.d565 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" is made by its constructor - write " }>, align 8
@.d566 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(...)" }>, align 8
@.d567 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T29d" }>, align 8
@.d568 = private constant <{ i64, [162 x i8] }> <{ i64 0, [162 x i8] c" needs more than 64 bits, and a literal's own type is at most U64 - give it the type it should have, as 'x U128 = ...', or convert an operand, as 'U128(1) << 100'" }>, align 8
@.d569 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"T6a, E4a" }>, align 8
@.d570 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" does not fit " }>, align 8
@.d571 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"T6" }>, align 8
@.d572 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L13" }>, align 8
@.d573 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"character literal holds more than one character - text is written in \22\22" }>, align 8
@.d574 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a match over " }>, align 8
@.d575 = private constant <{ i64, [80 x i8] }> <{ i64 0, [80 x i8] c" gives a value only when its cases cover every value - none matches an array of " }>, align 8
@.d576 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"; add a case for it, or 'case _: v'" }>, align 8
@.d577 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13h" }>, align 8
@.d578 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d579 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d580 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" is not covered - add it, or 'case _ { }'" }>, align 8
@.d581 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13a" }>, align 8
@.d582 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G30" }>, align 8
@.d583 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"no clause of this match gives a value at this instance's length - add one, or 'case _'" }>, align 8
@.d584 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"S12b, D8c" }>, align 8
@.d585 = private constant <{ i64, [113 x i8] }> <{ i64 0, [113 x i8] c"a match gives one value - to give several, return them from each case of a match statement: 'case P: return a, b'" }>, align 8
@.d586 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" can fail here - write 'try x in c'" }>, align 8
@.d587 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E29" }>, align 8
@.d588 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"'x in c' calls " }>, align 8
@.d589 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", and " }>, align 8
@.d590 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" has none" }>, align 8
@.d591 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E29" }>, align 8
@.d592 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" is a method - call it on its receiver: x." }>, align 8
@.d593 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(...)" }>, align 8
@.d594 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M19" }>, align 8
@.d595 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c" cannot fail - the operation calling it has nowhere to handle an error" }>, align 8
@.d596 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d597 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" inherits a method " }>, align 8
@.d598 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" from its base - choose another name" }>, align 8
@.d599 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T29e" }>, align 8
@.d600 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"the compiler supplies " }>, align 8
@.d601 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d602 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" - choose another name" }>, align 8
@.d603 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"E23, E33, E37, P9, T17e" }>, align 8
@.d604 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"method " }>, align 8
@.d605 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is private to its module" }>, align 8
@.d606 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"M6" }>, align 8
@.d607 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" declares no " }>, align 8
@.d608 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c", and does not extend its base, which has one - declare it with 'extends'" }>, align 8
@.d609 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T29f" }>, align 8
@.d610 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"a method of " }>, align 8
@.d611 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" is declared in that type's module" }>, align 8
@.d612 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M19" }>, align 8
@.d613 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d614 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"' is declared twice for " }>, align 8
@.d615 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" - declare one per instance" }>, align 8
@.d616 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M21" }>, align 8
@.d617 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"the end can be reached without returning " }>, align 8
@.d618 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c" - return on every path, or end it with 'unreachable'" }>, align 8
@.d619 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D10a" }>, align 8
@.d620 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" needs a file" }>, align 8
@.d621 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d622 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"a local is always writable - 'mut' is for a reference, and " }>, align 8
@.d623 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is none" }>, align 8
@.d624 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D11a" }>, align 8
@.d625 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"a field is writable wherever its instance is - 'mut' is for a reference, and " }>, align 8
@.d626 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is none" }>, align 8
@.d627 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"C3" }>, align 8
@.d628 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"'mut' makes a reference writable, and " }>, align 8
@.d629 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" is no reference" }>, align 8
@.d630 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25b" }>, align 8
@.d631 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d632 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" is given by position already" }>, align 8
@.d633 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E14b" }>, align 8
@.d634 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E14b" }>, align 8
@.d635 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c"an argument by name gives a function's, a method's or a constructor's defaulted parameter, in a call" }>, align 8
@.d636 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d637 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c" declares no default, so it is given by position, not by name" }>, align 8
@.d638 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E14b" }>, align 8
@.d639 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" names no parameter of " }>, align 8
@.d640 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d641 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d642 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E14b" }>, align 8
@.d643 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E26b" }>, align 8
@.d644 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"'Narrow' names the type it converts to - write 'x.Narrow<I32>()'" }>, align 8
@.d645 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L18c" }>, align 8
@.d646 = private constant <{ i64, [113 x i8] }> <{ i64 0, [113 x i8] c"parentheses group only a function type holding a comma of its own, as an item of a list - write this without them" }>, align 8
@.d647 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d648 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" is below I64's minimum" }>, align 8
@.d649 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L10" }>, align 8
@.d650 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"nested more than " }>, align 8
@.d651 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c" levels deep - split it into locals or functions" }>, align 8
@.d652 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L21" }>, align 8
@.d653 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"clang not found on PATH - install clang-20 (the IR is in " }>, align 8
@.d654 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d655 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d656 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" has no limit '" }>, align 8
@.d657 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d658 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E36" }>, align 8
@.d659 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B4" }>, align 8
@.d660 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"no main function - a program starts at 'fn main() { }'" }>, align 8
@.d661 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"no specification at " }>, align 8
@.d662 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B11a" }>, align 8
@.d663 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" has no case " }>, align 8
@.d664 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T17" }>, align 8
@.d665 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" has no word " }>, align 8
@.d666 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T19" }>, align 8
@.d667 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" has no member '" }>, align 8
@.d668 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d669 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d670 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c" has no zero value, so this needs one - its constructor does not run on zeros while compiling: " }>, align 8
@.d671 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D13c" }>, align 8
@.d672 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"non-ASCII byte '" }>, align 8
@.d673 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"' - olang source is ASCII" }>, align 8
@.d674 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"L1" }>, align 8
@.d675 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8e" }>, align 8
@.d676 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"a 'noreturn' function never returns to its caller, so it fails with nothing - drop the '?'" }>, align 8
@.d677 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8e" }>, align 8
@.d678 = private constant <{ i64, [109 x i8] }> <{ i64 0, [109 x i8] c"a 'noreturn' function may not reach its end - end every path with a noreturn call, 'unreachable' or 'for { }'" }>, align 8
@.d679 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c" is no error type - an error set names error types, their words and named sets" }>, align 8
@.d680 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"R1" }>, align 8
@.d681 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"S4" }>, align 8
@.d682 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"this cannot be written - a variable, an element or a member can" }>, align 8
@.d683 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" declares no " }>, align 8
@.d684 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d685 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d686 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" takes " }>, align 8
@.d687 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c" besides its receiver - an ordinary method, not the one " }>, align 8
@.d688 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" calls, which takes " }>, align 8
@.d689 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d690 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d691 = private constant <{ i64, [109 x i8] }> <{ i64 0, [109 x i8] c"' is bound here to what the matched value holds, which lives in a block that closes first - make that where '" }>, align 8
@.d692 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"' lives" }>, align 8
@.d693 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d694 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d695 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"' is declared read-only here - declare it '" }>, align 8
@.d696 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" mut " }>, align 8
@.d697 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"' to write through it" }>, align 8
@.d698 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d699 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" is declared here" }>, align 8
@.d700 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d701 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d702 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c".Destroy()' is here; give it a new local if it is needed again" }>, align 8
@.d703 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d704 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d705 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" needs " }>, align 8
@.d706 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" here" }>, align 8
@.d707 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d708 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"the index is held here, for both the read and the write, in a block that closes first - make it where '" }>, align 8
@.d709 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"' lives first, then index with it" }>, align 8
@.d710 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d711 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d712 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"here" }>, align 8
@.d713 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d714 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"in the standard library's code, here" }>, align 8
@.d715 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d716 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"the reference it would give is written here" }>, align 8
@.d717 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d718 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"' is " }>, align 8
@.d719 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c", its literal's own type - declare the type it should have, '" }>, align 8
@.d720 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d721 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" = ...'" }>, align 8
@.d722 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d723 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the range's literals make '" }>, align 8
@.d724 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"' " }>, align 8
@.d725 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" - write '" }>, align 8
@.d726 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d727 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c")' here for " }>, align 8
@.d728 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" values" }>, align 8
@.d729 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d730 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d731 = private constant <{ i64, [185 x i8] }> <{ i64 0, [185 x i8] c"' is the loop's copy of an element, in the loop's block - a call it is lent to by reference ties what it builds to that copy: take that parameter by value, or build from its fields here" }>, align 8
@.d732 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d733 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d734 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"the callee requires it because of this statement" }>, align 8
@.d735 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d736 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"' is declared here, with another signature" }>, align 8
@.d737 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d738 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d739 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c"' is the call's own copy of its argument - take it by reference to give back what the caller passed: '" }>, align 8
@.d740 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d741 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d742 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"' is " }>, align 8
@.d743 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'s private spelling with " }>, align 8
@.d744 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"'s parameters, so it is held to its shape" }>, align 8
@.d745 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d746 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d747 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' copies '" }>, align 8
@.d748 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"', reached read-only, so it is read-only - '" }>, align 8
@.d749 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d750 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c".Clone()' would be one of its own" }>, align 8
@.d751 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d752 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"or refill the one kept - '" }>, align 8
@.d753 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c".Clear()', then put the elements in: one made where '" }>, align 8
@.d754 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"' lives stays there, beside every one made before it, until that scope closes" }>, align 8
@.d755 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d756 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d757 = private constant <{ i64, [119 x i8] }> <{ i64 0, [119 x i8] c"this borrows a value made here, which lives only in this block - keep a copy of what the slice shows ('$x', 'x.Copy()')" }>, align 8
@.d758 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d759 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"built here, where the receiver's part it was handed lives" }>, align 8
@.d760 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d761 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"this clause runs when the try fails, which may be before the assignment" }>, align 8
@.d762 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d763 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"' may grow here, in " }>, align 8
@.d764 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c" - take the view or the reference after it, or " }>, align 8
@.d765 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d766 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" may grow it here" }>, align 8
@.d767 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d768 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d769 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"the callee is no view of the element because of this statement" }>, align 8
@.d770 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d771 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"' holds it by reference, whose zero value is null" }>, align 8
@.d772 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d773 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"null is tested with 'is', never compared - write '" }>, align 8
@.d774 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d775 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d776 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E10c" }>, align 8
@.d777 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c" is never null - a reference that may be is written " }>, align 8
@.d778 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d779 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c" may be null, so it meets no trait - " }>, align 8
@.d780 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" must meet " }>, align 8
@.d781 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" here: write " }>, align 8
@.d782 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", which never is" }>, align 8
@.d783 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d784 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" takes a Bool, found " }>, align 8
@.d785 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"E7" }>, align 8
@.d786 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" takes operands of one type, found " }>, align 8
@.d787 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d788 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d789 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" applies to " }>, align 8
@.d790 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", not to " }>, align 8
@.d791 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d792 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-output " }>, align 8
@.d793 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" is a directory - name the file to write" }>, align 8
@.d794 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B3h" }>, align 8
@.d795 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c" does not have the signature of the default it overrides - match it, or choose another name" }>, align 8
@.d796 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19e" }>, align 8
@.d797 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"O10d" }>, align 8
@.d798 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"this value lives in this function's own scope, so it cannot satisfy anything longer-lived" }>, align 8
@.d799 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"field '" }>, align 8
@.d800 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"' is matched by position and again by name" }>, align 8
@.d801 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13b" }>, align 8
@.d802 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a pattern here names a case of " }>, align 8
@.d803 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d804 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13b" }>, align 8
@.d805 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17c" }>, align 8
@.d806 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"this value's payload refers to storage the value would outlive - make that storage where the value is kept" }>, align 8
@.d807 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" carries " }>, align 8
@.d808 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" - give them: '" }>, align 8
@.d809 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d810 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")'" }>, align 8
@.d811 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T19b" }>, align 8
@.d812 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L12" }>, align 8
@.d813 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a decimal point needs a digit after it" }>, align 8
@.d814 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"'**' calls Pow, which " }>, align 8
@.d815 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" has none of" }>, align 8
@.d816 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E5a" }>, align 8
@.d817 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T29d" }>, align 8
@.d818 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"only a type over a primitive has a constructor written this way - a struct writes 'struct(params) { ... }'" }>, align 8
@.d819 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" declares " }>, align 8
@.d820 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" twice, public and private - keep one: " }>, align 8
@.d821 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", or " }>, align 8
@.d822 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" for its own module only" }>, align 8
@.d823 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M6b" }>, align 8
@.d824 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"-quick and " }>, align 8
@.d825 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" each say how much to optimize - give one" }>, align 8
@.d826 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B2g" }>, align 8
@.d827 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"no error of this module is named " }>, align 8
@.d828 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" - did you mean " }>, align 8
@.d829 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"? To raise a new error of that name, name it after this function's '?'" }>, align 8
@.d830 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R3b" }>, align 8
@.d831 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"R3b, T19b" }>, align 8
@.d832 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"a field an error raised by name carries is named by the raise: a bare name, or 'name = value'" }>, align 8
@.d833 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"the raw value " }>, align 8
@.d834 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" does not fit " }>, align 8
@.d835 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d836 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"a raw value is a literal of the raw type " }>, align 8
@.d837 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d838 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d839 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"' has the raw value " }>, align 8
@.d840 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", which '" }>, align 8
@.d841 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"' has already - raw values are distinct" }>, align 8
@.d842 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d843 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"an enum's raw type is String or an integer type, found " }>, align 8
@.d844 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d845 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17e" }>, align 8
@.d846 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c"a raw value needs the enum's raw type, written after 'enum': 'enum String {' or 'enum U8 {'" }>, align 8
@.d847 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a mutable global holds no copy of a read-only " }>, align 8
@.d848 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" - give it one of its own, made " }>, align 8
@.d849 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", or drop its 'mut'" }>, align 8
@.d850 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d851 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"a read-only copy cannot be passed where it may be written - pass one of its own, made " }>, align 8
@.d852 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d853 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d854 = private constant <{ i64, [109 x i8] }> <{ i64 0, [109 x i8] c"a reference a read-only copy holds is read-only - it cannot be passed or kept where it may be written through" }>, align 8
@.d855 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"a copy of a read-only " }>, align 8
@.d856 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c" cannot be returned as a writable value - return one of its own, made " }>, align 8
@.d857 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c", or a read-only reference" }>, align 8
@.d858 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d859 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"a copy of a read-only " }>, align 8
@.d860 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c" cannot be stored where it can be written - store one of its own, made " }>, align 8
@.d861 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d862 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d863 = private constant <{ i64, [117 x i8] }> <{ i64 0, [117 x i8] c"this writes through a reference a read-only copy holds - a copy of a place reached read-only writes nothing it shares" }>, align 8
@.d864 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25b" }>, align 8
@.d865 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"this writes through a read-only reference - one with no 'mut' in its type" }>, align 8
@.d866 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" cannot be held through '" }>, align 8
@.d867 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"&' - only a struct, an enum or an array can" }>, align 8
@.d868 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G11" }>, align 8
@.d869 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"a reference never narrows - '" }>, align 8
@.d870 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"' lives in a block that closes first, and this keeps it longer" }>, align 8
@.d871 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O25" }>, align 8
@.d872 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"O25, O26a" }>, align 8
@.d873 = private constant <{ i64, [158 x i8] }> <{ i64 0, [158 x i8] c"this local flows into what the function returns, so it lives where the result goes - and its value lives elsewhere: make it here, or keep it out of the result" }>, align 8
@.d874 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G37" }>, align 8
@.d875 = private constant <{ i64, [160 x i8] }> <{ i64 0, [160 x i8] c"a comprehension written as a call's arguments walks a list known while compiling - 'T.Params', 'T.Fields' ...; another is written in brackets, 'T[e for x in c]'" }>, align 8
@.d876 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G33" }>, align 8
@.d877 = private constant <{ i64, [139 x i8] }> <{ i64 0, [139 x i8] c"a comprehension over a list known while compiling keeps an element by a filter decided while compiling - this one is known only at run time" }>, align 8
@.d878 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"index " }>, align 8
@.d879 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" is outside the list, which holds " }>, align 8
@.d880 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G33" }>, align 8
@.d881 = private constant <{ i64, [158 x i8] }> <{ i64 0, [158 x i8] c" is a list known while compiling, no value - walk it with 'for', count it with '.Len()', index it with a constant, or make an array of it with a comprehension" }>, align 8
@.d882 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G33" }>, align 8
@.d883 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G13" }>, align 8
@.d884 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"'match' on a type takes a type known while compiling - a type variable, or a type a reflected member names" }>, align 8
@.d885 = private constant <{ i64, [125 x i8] }> <{ i64 0, [125 x i8] c" has no TypeKind - only a struct, an enum, a number, Bool, an array, a reference, a function type and an error value have one" }>, align 8
@.d886 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G32" }>, align 8
@.d887 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" has no " }>, align 8
@.d888 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c" - it is not laid out (a trait, an error type, an extern type)" }>, align 8
@.d889 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G32" }>, align 8
@.d890 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c" has no Length - only an array whose length is known while compiling has one" }>, align 8
@.d891 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G32" }>, align 8
@.d892 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" has no reflected member '" }>, align 8
@.d893 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"' - a type's are Name, Kind, Base, Fields, Cases, Params, Results, Element, Length, Target, Size and Align" }>, align 8
@.d894 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G32" }>, align 8
@.d895 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d896 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"' of " }>, align 8
@.d897 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d898 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G38" }>, align 8
@.d899 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" has no " }>, align 8
@.d900 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d901 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G33" }>, align 8
@.d902 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"this field is " }>, align 8
@.d903 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"'s, and the value is " }>, align 8
@.d904 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G34" }>, align 8
@.d905 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G33" }>, align 8
@.d906 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c"a list known while compiling is walked with no call that can fail - write 'for x in ...' without 'try'" }>, align 8
@.d907 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"the error raised again can be " }>, align 8
@.d908 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c", which this function does not declare - add it after '?', or test the error first" }>, align 8
@.d909 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R3a" }>, align 8
@.d910 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13h" }>, align 8
@.d911 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"an array pattern has one '...', for the elements its other items do not name" }>, align 8
@.d912 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8e" }>, align 8
@.d913 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"a 'noreturn' function never returns - end this path with a noreturn call or 'unreachable'" }>, align 8
@.d914 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"this function returns " }>, align 8
@.d915 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c", so 'return' needs a value" }>, align 8
@.d916 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"D8" }>, align 8
@.d917 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"this function returns " }>, align 8
@.d918 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d919 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"D8" }>, align 8
@.d920 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"D8" }>, align 8
@.d921 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"this function returns no value" }>, align 8
@.d922 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c" lives in the program's scope, which a result reaches by being stored there, not by a scope argument" }>, align 8
@.d923 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"E25, O1b" }>, align 8
@.d924 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O10" }>, align 8
@.d925 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"this reference lives in a scope that may not outlive where it is put" }>, align 8
@.d926 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d927 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"SetAt gives no result" }>, align 8
@.d928 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c" declares At but not SetAt, which x[i] = v calls" }>, align 8
@.d929 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d930 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" is a build constant - choose another name" }>, align 8
@.d931 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D3a" }>, align 8
@.d932 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c" is already declared in this module - a name means one thing in it" }>, align 8
@.d933 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D3a" }>, align 8
@.d934 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"shifting " }>, align 8
@.d935 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" by " }>, align 8
@.d936 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is outside its width of " }>, align 8
@.d937 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" bits" }>, align 8
@.d938 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E8a" }>, align 8
@.d939 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"E8a, E4a" }>, align 8
@.d940 = private constant <{ i64, [116 x i8] }> <{ i64 0, [116 x i8] c"this shift is past its literal's width, and nothing adapts it to a wider type - convert the literal, as I64(1) << 40" }>, align 8
@.d941 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"a slice's bounds are integers, found " }>, align 8
@.d942 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E16a" }>, align 8
@.d943 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a slice with no end runs to Len(), and " }>, align 8
@.d944 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" has none" }>, align 8
@.d945 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d946 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"E31b, P2" }>, align 8
@.d947 = private constant <{ i64, [173 x i8] }> <{ i64 0, [173 x i8] c"a task is not handed x[i]: the element is copied here, and the copy would not last until the join - spawn a function that takes the collection and calls 'x[i].M(...)' itself" }>, align 8
@.d948 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P4" }>, align 8
@.d949 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"this call can fail - write 'spawn try', and what its clauses do not take reaches the join" }>, align 8
@.d950 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"S19b, P1a" }>, align 8
@.d951 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"a spawn in deferred code needs a join written in the deferred code" }>, align 8
@.d952 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D16e" }>, align 8
@.d953 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"a spawned lambda takes no parameters - it captures what it needs" }>, align 8
@.d954 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P1" }>, align 8
@.d955 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"'spawn' takes a call" }>, align 8
@.d956 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P1" }>, align 8
@.d957 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"'spawn' is written inside a 'join' block, which waits for the task" }>, align 8
@.d958 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P1g" }>, align 8
@.d959 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"this target closes before the join does - declare it at the join's level or wider" }>, align 8
@.d960 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a spawn target has exactly the call's type " }>, align 8
@.d961 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d962 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" - convert after the join" }>, align 8
@.d963 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P1g" }>, align 8
@.d964 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P1g" }>, align 8
@.d965 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"this call returns nothing to bind - drop the target" }>, align 8
@.d966 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"P4" }>, align 8
@.d967 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"this task cannot fail - drop the 'try'" }>, align 8
@.d968 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8g" }>, align 8
@.d969 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c"'...a' passes an array on as all of a variadic parameter's arguments - alone, with no others beside it" }>, align 8
@.d970 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8d" }>, align 8
@.d971 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"these results are passed as the arguments, so there must be as many - destructure them first: 'a, b := g()'" }>, align 8
@.d972 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8g" }>, align 8
@.d973 = private constant <{ i64, [115 x i8] }> <{ i64 0, [115 x i8] c"'...a' passes an array on as a variadic parameter's arguments, and stands nowhere else - pass the array itself, 'a'" }>, align 8
@.d974 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c"'++' and '--' step a number, or a type declaring Inc (Dec) or Plus (Minus) - found " }>, align 8
@.d975 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"S3a, E31" }>, align 8
@.d976 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O20" }>, align 8
@.d977 = private constant <{ i64, [114 x i8] }> <{ i64 0, [114 x i8] c"the container outlives what this refers to - build it where the container lives, or keep a copy ('$x', 'x.Copy()')" }>, align 8
@.d978 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"E11c, T25c" }>, align 8
@.d979 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"'$' renders read-only values too, so Str only reads its receiver - pass on what it holds read-only" }>, align 8
@.d980 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E11c" }>, align 8
@.d981 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"Str gives a String" }>, align 8
@.d982 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"a struct pattern names the fields it matches - write 'field = pattern' or a field's name: the order of " }>, align 8
@.d983 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"'s fields is no part of it" }>, align 8
@.d984 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13i" }>, align 8
@.d985 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"the value matched here is " }>, align 8
@.d986 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c", and this struct pattern matches " }>, align 8
@.d987 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13i" }>, align 8
@.d988 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"where " }>, align 8
@.d989 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c" lives is not known here, so nothing is declared to live there - read it through " }>, align 8
@.d990 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", or declare the local with ':='" }>, align 8
@.d991 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O12" }>, align 8
@.d992 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" takes no arguments" }>, align 8
@.d993 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E14" }>, align 8
@.d994 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" runs on this machine, and '-target " }>, align 8
@.d995 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"' is another architecture or system - build, compile and test build for it" }>, align 8
@.d996 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B12a" }>, align 8
@.d997 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"'-target " }>, align 8
@.d998 = private constant <{ i64, [102 x i8] }> <{ i64 0, [102 x i8] c"': native is this machine's CPU - name the other architecture's CPU after ':', or none for its default" }>, align 8
@.d999 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B12" }>, align 8
@.d1000 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"this clang cannot build for '" }>, align 8
@.d1001 = private constant <{ i64, [144 x i8] }> <{ i64 0, [144 x i8] c"': its back end for that architecture cannot generate the BF16 code the runtime holds - clang 19 or newer can (OLANG_CLANG names the one to use)" }>, align 8
@.d1002 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B12a" }>, align 8
@.d1003 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"olang does not build for '" }>, align 8
@.d1004 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"' - it builds for x86_64 and aarch64 Linux with the GNU C library" }>, align 8
@.d1005 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B12" }>, align 8
@.d1006 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4a" }>, align 8
@.d1007 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"an error may not leave a task's clause - catch it here; the task lets through what its clauses do not take" }>, align 8
@.d1008 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c" may not leave a task's clause - it runs on the task, outside the spawner's loops" }>, align 8
@.d1009 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4a" }>, align 8
@.d1010 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4a" }>, align 8
@.d1011 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"this clause takes an error the targets would get no value for - end it with 'default v', or end the process" }>, align 8
@.d1012 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P4a" }>, align 8
@.d1013 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"a spawn without targets gives no value, so its clauses take no default" }>, align 8
@.d1014 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"a test names a function, a type or Type.Method of its file, and '" }>, align 8
@.d1015 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' is none - did you mean '" }>, align 8
@.d1016 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d1017 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"B7a" }>, align 8
@.d1018 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T13a, T29c" }>, align 8
@.d1019 = private constant <{ i64, [143 x i8] }> <{ i64 0, [143 x i8] c"'mut' makes a reference writable, and a String never changes once it is made - write text through 'mut Array<Char>&', read it through 'String&'" }>, align 8
@.d1020 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T13a, T29c" }>, align 8
@.d1021 = private constant <{ i64, [146 x i8] }> <{ i64 0, [146 x i8] c"a String never changes once it is made - write the text as an Array<Char> and make the String with String(chars), or build it with a StringBuilder" }>, align 8
@.d1022 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S17a" }>, align 8
@.d1023 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"this top-level assert is false, decided while compiling" }>, align 8
@.d1024 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"this condition reads '" }>, align 8
@.d1025 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"', which its 'if' assigns - a condition cannot decide the value it reads" }>, align 8
@.d1026 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D13e" }>, align 8
@.d1027 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d1028 = private constant <{ i64, [118 x i8] }> <{ i64 0, [118 x i8] c"' has a value in its declaration - a global is given its value once: declare it with no value, or drop this assignment" }>, align 8
@.d1029 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D13e" }>, align 8
@.d1030 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D13e" }>, align 8
@.d1031 = private constant <{ i64, [139 x i8] }> <{ i64 0, [139 x i8] c"an assignment at the top level is a global's initializer, written only inside a top-level 'if' - give the value in the global's declaration" }>, align 8
@.d1032 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d1033 = private constant <{ i64, [108 x i8] }> <{ i64 0, [108 x i8] c"' is no global of this module declared above with no value - only such a global is assigned at the top level" }>, align 8
@.d1034 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D13e" }>, align 8
@.d1035 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R1b" }>, align 8
@.d1036 = private constant <{ i64, [84 x i8] }> <{ i64 0, [84 x i8] c"a trait's method writes its error set - '? io.Error' - since no body says what it is" }>, align 8
@.d1037 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c" extends itself through the traits it extends" }>, align 8
@.d1038 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T30a" }>, align 8
@.d1039 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c" is not a trait, so a trait cannot extend it - a type takes a trait's methods by declaring them" }>, align 8
@.d1040 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T30a" }>, align 8
@.d1041 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" is listed by " }>, align 8
@.d1042 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" but has no method " }>, align 8
@.d1043 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" that fits - declare it, or leave " }>, align 8
@.d1044 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" out" }>, align 8
@.d1045 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T31a" }>, align 8
@.d1046 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c" is an open trait, so it lists no types to take in - list types, or closed traits" }>, align 8
@.d1047 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T31a" }>, align 8
@.d1048 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"trait method " }>, align 8
@.d1049 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" may not be generic in a type of its own" }>, align 8
@.d1050 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T35" }>, align 8
@.d1051 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d1052 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1053 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d1054 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" is a trait - a constraint on a type variable; a value of any type meeting it is an 'any " }>, align 8
@.d1055 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d1056 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"T30, T32" }>, align 8
@.d1057 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c" can escape here, and this function does not declare it - add it after '?', or catch it" }>, align 8
@.d1058 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"R9" }>, align 8
@.d1059 = private constant <{ i64, [147 x i8] }> <{ i64 0, [147 x i8] c" can escape here, and this function writes no '?' - a function that can fail says so: write '?' after its result (its errors inferred), or catch it" }>, align 8
@.d1060 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R1d" }>, align 8
@.d1061 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"R13" }>, align 8
@.d1062 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"an error tried here has nowhere to go - catch every one it can be" }>, align 8
@.d1063 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d1064 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"' is an error already caught, not a call - raise it again with 'error " }>, align 8
@.d1065 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"R11b" }>, align 8
@.d1066 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E24" }>, align 8
@.d1067 = private constant <{ i64, [104 x i8] }> <{ i64 0, [104 x i8] c"these parentheses group nothing - a 'try' covers the whole expression after it, so write it without them" }>, align 8
@.d1068 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"the type arguments of " }>, align 8
@.d1069 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" cannot be inferred from these arguments" }>, align 8
@.d1070 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G9" }>, align 8
@.d1071 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c" is not generic, so it takes no type arguments" }>, align 8
@.d1072 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G7" }>, align 8
@.d1073 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13e" }>, align 8
@.d1074 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c"a type match chooses its case while compiling, so it takes no guard - test the value inside the case" }>, align 8
@.d1075 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"no case covers " }>, align 8
@.d1076 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c", which this generic is instantiated with - add one, or 'case _'" }>, align 8
@.d1077 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G15" }>, align 8
@.d1078 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c" is a type variable, so its cases are types" }>, align 8
@.d1079 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G13" }>, align 8
@.d1080 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
@.d1081 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d1082 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E12" }>, align 8
@.d1083 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" is a type variable, not a value" }>, align 8
@.d1084 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G8b" }>, align 8
@.d1085 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c" is a type variable, not an error set - an error-set parameter is written after '?' in its list, '<T ? E>'" }>, align 8
@.d1086 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G1a" }>, align 8
@.d1087 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"type variable " }>, align 8
@.d1088 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d1089 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c" appears in no parameter's type, so the call writes it - " }>, align 8
@.d1090 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"<...>(...)" }>, align 8
@.d1091 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G4" }>, align 8
@.d1092 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" - nothing in scope has that type" }>, align 8
@.d1093 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" - in scope: " }>, align 8
@.d1094 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"'_' holds the place of a value of type " }>, align 8
@.d1095 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E41" }>, align 8
@.d1096 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L4a" }>, align 8
@.d1097 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"unterminated block comment - '##' closes it" }>, align 8
@.d1098 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L14" }>, align 8
@.d1099 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"unterminated string literal" }>, align 8
@.d1100 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8c" }>, align 8
@.d1101 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"'_' discards a value and names nothing, so it cannot be declared" }>, align 8
@.d1102 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E15" }>, align 8
@.d1103 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"this call can fail - write 'try', and catch or pass on its errors" }>, align 8
@.d1104 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c" is unique, so it is never copied and has no Copy - make a new one with a function or its constructor" }>, align 8
@.d1105 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T13b, E31d" }>, align 8
@.d1106 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d1107 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c">(n, fill) copies its fill into every element, and " }>, align 8
@.d1108 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c" is unique - make each element with a comprehension ('" }>, align 8
@.d1109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d1110 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"(...) for i in range n]'), or hold references ('Array<" }>, align 8
@.d1111 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&>')" }>, align 8
@.d1112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d1113 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" is unique, so it is no part of " }>, align 8
@.d1114 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c", which is immut - an immut value is copied freely, a unique one never; hold a reference, '" }>, align 8
@.d1115 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&'" }>, align 8
@.d1116 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d1117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d1118 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"' is handed on here while the same call also reaches it, and " }>, align 8
@.d1119 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c" is unique - one value would be in two places: give the call '" }>, align 8
@.d1120 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"' once, or hand it on in a call of its own" }>, align 8
@.d1121 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d1122 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"unexpected character '" }>, align 8
@.d1123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d1124 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L16" }>, align 8
@.d1125 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"unknown error type " }>, align 8
@.d1126 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"R1" }>, align 8
@.d1127 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"unknown option '" }>, align 8
@.d1128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d1129 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c" - 'olang help' lists the options of " }>, align 8
@.d1130 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"B1" }>, align 8
@.d1131 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"unknown function or type " }>, align 8
@.d1132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1133 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c" is no import here - std has it: 'import \22std/" }>, align 8
@.d1134 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22'" }>, align 8
@.d1135 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M10" }>, align 8
@.d1136 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown name " }>, align 8
@.d1137 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d1138 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d1139 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1140 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown type " }>, align 8
@.d1141 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1142 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19d" }>, align 8
@.d1143 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"vacate() empties a place - a writable variable, field or element" }>, align 8
@.d1144 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S12b" }>, align 8
@.d1145 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"a block gives no value - a clause of a match used as a value is 'case P: v', or 'case P: return x' to leave" }>, align 8
@.d1146 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c" cannot be a C variable argument - no C type of olang's holds it; convert it, 'I64(x)' or 'U64(x)'" }>, align 8
@.d1147 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X21" }>, align 8
@.d1148 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" is private to its module" }>, align 8
@.d1149 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"M6" }>, align 8
@.d1150 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" names need as many values, found " }>, align 8
@.d1151 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D12b" }>, align 8
@.d1152 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"expected at least " }>, align 8
@.d1153 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" argument" }>, align 8
@.d1154 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d1155 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E14" }>, align 8
@.d1156 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8g" }>, align 8
@.d1157 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"a variadic parameter takes no default - a call giving it no argument gives it the empty array" }>, align 8
@.d1158 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D8g" }>, align 8
@.d1159 = private constant <{ i64, [140 x i8] }> <{ i64 0, [140 x i8] c"a variadic parameter is the last one but defaulted ones - one variadic parameter, and only parameters with a default after it, given by name" }>, align 8
@.d1160 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"this reads a view of '" }>, align 8
@.d1161 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"' taken before '" }>, align 8
@.d1162 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"' may have grown" }>, align 8
@.d1163 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19g" }>, align 8
@.d1164 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d1165 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"' holds a view of '" }>, align 8
@.d1166 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"' taken before '" }>, align 8
@.d1167 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"' may have grown" }>, align 8
@.d1168 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19g" }>, align 8
@.d1169 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"this returns a view of '" }>, align 8
@.d1170 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"', which this function builds - return the value (a result written without '&' copies it), or a copy: '$x'" }>, align 8
@.d1171 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O27" }>, align 8
@.d1172 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d1173 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" carries one whole " }>, align 8
@.d1174 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c" and has no field names - match its fields with a struct pattern, '" }>, align 8
@.d1175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d1176 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"(field = ...))'" }>, align 8
@.d1177 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13b" }>, align 8
@.d1178 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13f" }>, align 8
@.d1179 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"'_' matches every value, so it is its case's only alternative" }>, align 8
@.d1180 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d1181 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"this writes into a value a call gave back, a copy no one holds - store the whole element: x[i] = v" }>, align 8
@.d1182 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"E31, O17" }>, align 8
@.d1183 = private constant <{ i64, [148 x i8] }> <{ i64 0, [148 x i8] c"x[i] gives a copy, and the call can build into what it holds where the copy is - hold the elements by reference, or take it in place ('x.RefMut(i)')" }>, align 8
@.d1184 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"S19b, S20" }>, align 8
@.d1185 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"deferred code may not yield - it runs while its block is left" }>, align 8
@.d1186 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S20" }>, align 8
@.d1187 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"a join block may not yield - its tasks are waited for before it is left" }>, align 8
@.d1188 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"D18, S20" }>, align 8
@.d1189 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"'yield' is a generator's - a function whose result is written 'Iterator<T>'" }>, align 8
@.d1190 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"S20, O26" }>, align 8
@.d1191 = private constant <{ i64, [139 x i8] }> <{ i64 0, [139 x i8] c"this value refers to the generator's own storage, which its walk goes on with - yield a copy, built where the value goes ('x.Copy()', '$x')" }>, align 8
@.d1192 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"S20, O15" }>, align 8
@.d1193 = private constant <{ i64, [179 x i8] }> <{ i64 0, [179 x i8] c"a yield while a variable around it holds a value with a destructor - a walk stopped there would never run it; hold the value in a block that ends before the yield, or by reference" }>, align 8
@.d1194 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"'s zero value holds references, which a fill would share - give a fill, or build the elements" }>, align 8
@.d1195 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D13c" }>, align 8
@.d1196 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d1197 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d1198 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %v0, i8 %a0)
@olang_loc_78fb4d3249708b2_e3f9318f90ab6b26 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
