; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/bench:Measurement" = type { i64, i64, i64, i64, i64 }
%"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" = type { { i64, ptr }, i64 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/bench:Comparison" = type { %"std/bench:Series", %"std/bench:Series", { i64, ptr } }
%"std/bench:Series" = type { { i64, ptr } }
@G_2estd_2fbench_2eDefaultBudget = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\CA\9A\3B\00\00\00\00" }>, align 8
@G_2estd_2fbench_2eDefaultRuns = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2estd_2fbench_2eMaxOps = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\CA\9A\3B\00\00\00\00" }>, align 8
define dso_local double @std_2fbench_2eMedian(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l17 = alloca double
  %s0 = alloca %olang.scope
  %rv = alloca double
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store double 0x0000000000000000, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = mul i64 %t14, 8
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = mul i64 %t23, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %l2, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t28 = insertvalue { ptr, ptr } %t27, ptr null, 1
  %t31 = extractvalue { ptr, ptr } %t28, 0
  %t32 = extractvalue { ptr, ptr } %t28, 1
  call void @std_2fprelude_2farray_2eArray_3cF64_3e_2eSort_3cF64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t26, ptr %t31, ptr %t32)
  br label %bb4
bb4:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = srem i64 %t33, 2
  %t37 = icmp eq i64 %t35, 1
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = sdiv i64 %t39, 2
  %t43 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr double, ptr %t44, i64 %t41
  %t46 = load double, ptr %t45, !tbaa !36
  store double %t46, ptr %l17, !tbaa !26
  br label %bb7
bb6:
  %t48 = load i64, ptr %l1, !tbaa !24
  %t50 = sdiv i64 %t48, 2
  %t52 = sub i64 %t50, 1
  %t54 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr double, ptr %t55, i64 %t52
  %t57 = load double, ptr %t56, !tbaa !36
  %t58 = load i64, ptr %l1, !tbaa !24
  %t60 = sdiv i64 %t58, 2
  %t62 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr double, ptr %t63, i64 %t60
  %t65 = load double, ptr %t64, !tbaa !36
  %t68 = fadd double %t57, %t65
  %t70 = fdiv double %t68, 0x4000000000000000
  store double %t70, ptr %l17, !tbaa !26
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load double, ptr %l17, !tbaa !26
  store double %t72, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local i1 @std_2fbench_2eOn() #0 {
entry:
  %l0 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @__olang_bench_on()
  store i64 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp ne i64 %t2, 0
  store i1 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local double @std_2fbench_2eSpread(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca double
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca double
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l24 = alloca double
  %l28 = alloca double
  %s0 = alloca %olang.scope
  %rv = alloca double
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call double @std_2fbench_2eMedian(ptr %v0, { i64, ptr } %t1)
  store double %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load double, ptr %l7, !tbaa !26
  store double %t4, ptr %l1, !tbaa !26
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = mul i64 %t11, 8
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l18, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr double, ptr %t29, i64 %t26
  %t31 = load double, ptr %t30, !tbaa !36
  %t34 = load double, ptr %l1, !tbaa !26
  %t37 = fsub double %t31, %t34
  %t39 = call double @std_2fprelude_2fnumber_2eF64_2eAbs_3cF64_3e(double %t37)
  store double %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load double, ptr %l24, !tbaa !26
  %t41 = load i64, ptr %l13, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr double, ptr %t43, i64 %t41
  store double %t40, ptr %t44, !tbaa !36
  %t45 = load i64, ptr %l13, !tbaa !24
  %t46 = add i64 %t45, 1
  store i64 %t46, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t52 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t53 = call double @std_2fbench_2eMedian(ptr %s0, { i64, ptr } %t52)
  store double %t53, ptr %l28
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load double, ptr %l28, !tbaa !26
  store double %t54, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local { i64, ptr } @std_2fbench_2enanos(ptr %v0, double %a0) #0 {
entry:
  %l0 = alloca double
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store double %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load double, ptr %l0, !tbaa !26
  %t3 = fcmp oge double %t1, 0x4059000000000000
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load double, ptr %l0, !tbaa !26
  %t7 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %t5, i64 0)
  store { i64, ptr } %t7, ptr %l4
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load double, ptr %l0, !tbaa !26
  %t11 = fcmp oge double %t9, 0x4024000000000000
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = load double, ptr %l0, !tbaa !26
  %t15 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %t13, i64 1)
  store { i64, ptr } %t15, ptr %l8
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %rv
  br label %ret
bb8:
  %t17 = load double, ptr %l0, !tbaa !26
  %t19 = fcmp oge double %t17, 0x3ff0000000000000
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t21 = load double, ptr %l0, !tbaa !26
  %t23 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %t21, i64 2)
  store { i64, ptr } %t23, ptr %l12
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t24 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb12:
  %t25 = load double, ptr %l0, !tbaa !26
  %t27 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %t25, i64 3)
  store { i64, ptr } %t27, ptr %l14
  br label %bb13
bb13:
  %t28 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fbench_2enextOps(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/bench:Measurement", ptr %t2, i32 0, i32 0
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = mul i64 %a1, %t5
  store i64 %t8, ptr %l6, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/bench:Measurement", ptr %t9, i32 0, i32 1
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t12, i64 1)
  store i64 %t14, ptr %l9
  br label %bb1
bb1:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = sdiv i64 %t15, %t16
  store i64 %t17, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l11, !tbaa !24
  %t23 = sdiv i64 %t21, 5
  %t26 = add i64 %t20, %t23
  store i64 %t26, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"std/bench:Measurement", ptr %t29, i32 0, i32 0
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = mul i64 100, %t32
  %t37 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t28, i64 %t34)
  store i64 %t37, ptr %l20
  br label %bb2
bb2:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/bench:Measurement", ptr %t38, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = add i64 %t41, 1
  %t44 = load i64, ptr %l20, !tbaa !24
  %t46 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t44, i64 %t43)
  store i64 %t46, ptr %l24
  br label %bb3
bb3:
  %t47 = load i64, ptr @G_2estd_2fbench_2eMaxOps, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t48, i64 %t47)
  store i64 %t50, ptr %l26
  br label %bb4
bb4:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @std_2fbench_2erunning(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %lp1 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = mul i64 0, 1
  %t4 = insertvalue { i64, ptr } undef, i64 0, 0
  %t5 = insertvalue { i64, ptr } %t4, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = call i64 @__olang_test_running(ptr %t7, i64 0)
  store i64 %t9, ptr %l4
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_590cb66873c2c3f3_59ce3f902ad3bbf)
  unreachable
bb3:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l0, !tbaa !24
  %t11 = load i64, ptr %l0, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l9, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l10, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l9, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t31 = load i64, ptr %l0, !tbaa !24
  store i64 %t31, ptr %l11, !tbaa !24
  %t32 = load i64, ptr %l11, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t40, ptr %lp1
  %t42 = load ptr, ptr %lp1
  store { i64, ptr } %t39, ptr %t42, !tbaa !27
  %t43 = load ptr, ptr %lp1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l0, !tbaa !24
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = extractvalue { i64, ptr } %t44, 0
  %t50 = call i64 @__olang_test_running(ptr %t47, i64 %t45)
  store i64 %t50, ptr %l16
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_81530fe1491cf4be_4f813e5d1e4ab0ea)
  unreachable
bb9:
  %t51 = load ptr, ptr %lp1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fbench_2erunsOnce() #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t15 = alloca { ptr, ptr }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = load ptr, ptr @__olang_prog_scope
  %t3 = call %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2farray_2eArray_3cI64_3e_2eIter_3cI64_3e(ptr %t1, ptr %t2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i64] }>, ptr @.d2, i32 0, i32 1) })
  store %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381", ptr %l1
  %t5 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" %t4, ptr %t5
  %t6 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2eVec_2eFromIter_3cI64_2c_20std_2fprelude_2farray_3aArrayIter_3cI64_3e_2c_20_3f_3e(ptr %t6, ptr %s0, ptr %t5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  br label %bb2
bb2:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t10 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %t10
  store ptr %t10, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = getelementptr { ptr, ptr }, ptr %t15, i32 0, i32 0
  store ptr %t12, ptr %t16, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t18 = call ptr @__olang_scope_hold(ptr %s0)
  %t19 = getelementptr { ptr, ptr }, ptr %t15, i32 0, i32 1
  store ptr %t18, ptr %t19, !tbaa !28
  %t20 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_3, 0
  %t21 = insertvalue { ptr, ptr } %t20, ptr %t15, 1
  %t22 = load i64, ptr @G_2estd_2fbench_2eDefaultBudget, !tbaa !24
  %t23 = load i64, ptr @G_2estd_2fbench_2eDefaultRuns, !tbaa !24
  %t25 = extractvalue { ptr, ptr } %t21, 0
  %t26 = extractvalue { ptr, ptr } %t21, 1
  call void @std_2fbench_2eRun_3c_3f_3e(ptr %s0, ptr %s0, ptr %t25, ptr %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, i64 %t22, i64 %t23)
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t29, i64 0)
  store i64 %t31, ptr %l10
  br label %bb4
bb4:
  %t32 = load i64, ptr %l10, !tbaa !24
  call void @std_2fbench_2eKeep_3cI64_3e(i64 %t32)
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t33, i64 0)
  store i64 %t35, ptr %l12
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i64, ptr %l12, !tbaa !24
  store i64 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local double @std_2fbench_2estd_2fbench_3aComparison_2eRatio(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca double
  %rv = alloca double
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/bench:Comparison", ptr %a0, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call double @std_2fbench_2eMedian(ptr %v0, { i64, ptr } %t4)
  store double %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load double, ptr %l3, !tbaa !26
  store double %t7, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local double @std_2fbench_2estd_2fbench_3aComparison_2eRatioSpread(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca double
  %rv = alloca double
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/bench:Comparison", ptr %a0, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call double @std_2fbench_2eSpread(ptr %v0, { i64, ptr } %t4)
  store double %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load double, ptr %l3, !tbaa !26
  store double %t7, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local double @std_2fbench_2estd_2fbench_3aMeasurement_2eNanosPerOp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca double
  %l6 = alloca i64
  %rv = alloca double
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/bench:Measurement", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sitofp i64 %t4 to double
  store double %t6, ptr %l3, !tbaa !26
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/bench:Measurement", ptr %t7, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t10, i64 1)
  store i64 %t12, ptr %l6
  br label %bb1
bb1:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = sitofp i64 %t13 to double
  %t15 = load double, ptr %l3, !tbaa !26
  %t17 = fdiv double %t15, %t14
  store double %t17, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local { i64, ptr } @std_2fbench_2estd_2fbench_3aMeasurement_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca double
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/bench:Measurement", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call double @std_2fbench_2estd_2fbench_3aMeasurement_2eNanosPerOp(ptr %v0, ptr %t5)
  store double %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load double, ptr %l4, !tbaa !26
  %t9 = call { i64, ptr } @std_2fbench_2enanos(ptr %s0, double %t8)
  store { i64, ptr } %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i64, ptr } @std_2fbench_2estd_2fbench_3aMeasurement_2ecounts(ptr %v0, ptr %s0, ptr %t10)
  store { i64, ptr } %t12, ptr %l7
  br label %bb3
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t13)
  %t15 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t13)
  %t31 = getelementptr i8, ptr %t29, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t15, i64 %t16)
  %t32 = getelementptr i8, ptr %t31, i64 %t16
  call void @olang_textcopy(ptr %t32, ptr %t19, i64 %t20)
  %t33 = getelementptr i8, ptr %t32, i64 %t20
  call void @olang_textcopy(ptr %t33, ptr %t22, i64 %t23)
  %t34 = getelementptr i8, ptr %t33, i64 %t23
  call void @olang_textcopy(ptr %t34, ptr %t26, i64 %t27)
  %t35 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t29, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fbench_2estd_2fbench_3aSeries_2eLine(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/bench:Measurement"
  %l3 = alloca %"std/bench:Measurement"
  %l5 = alloca double
  %l7 = alloca double
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/bench:Measurement" @std_2fbench_2estd_2fbench_3aSeries_2eTypical(ptr %v0, ptr %t1)
  store %"std/bench:Measurement" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/bench:Measurement", ptr %l3
  store %"std/bench:Measurement" %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call double @std_2fbench_2estd_2fbench_3aSeries_2eMedian(ptr %v0, ptr %t5)
  store double %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call double @std_2fbench_2estd_2fbench_3aSeries_2eSpread(ptr %v0, ptr %t8)
  store double %t10, ptr %l7
  br label %bb3
bb3:
  %t11 = load double, ptr %l5, !tbaa !26
  %t12 = load double, ptr %l7, !tbaa !26
  %t13 = call { i64, ptr } @std_2fbench_2eHuman(ptr %s0, double %t11, double %t12)
  store { i64, ptr } %t13, ptr %l8
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"std/bench:Series", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = getelementptr %"std/bench:Measurement", ptr %l1, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = call i64 @__olang_fmt_i64(ptr null, i64 %t19)
  %t30 = add i64 %t27, %t29
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t21)
  %t36 = add i64 %t33, %t35
  %t37 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t23, i64 %t24)
  %t41 = getelementptr i8, ptr %t40, i64 %t24
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t19)
  %t44 = getelementptr i8, ptr %t42, i64 %t29
  call void @olang_textcopy(ptr %t44, ptr %t31, i64 %t32)
  %t45 = getelementptr i8, ptr %t44, i64 %t32
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t21)
  %t47 = getelementptr i8, ptr %t45, i64 %t35
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t40, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local double @std_2fbench_2estd_2fbench_3aSeries_2eMedian(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca double
  %s0 = alloca %olang.scope
  %rv = alloca double
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fbench_2estd_2fbench_3aSeries_2ePerOp(ptr %v0, ptr %s0, ptr %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = call double @std_2fbench_2eMedian(ptr %s0, { i64, ptr } %t4)
  store double %t6, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load double, ptr %l4, !tbaa !26
  store double %t7, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local { i64, ptr } @std_2fbench_2estd_2fbench_3aSeries_2ePerOp(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/bench:Measurement"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca double
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/bench:Series", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = mul i64 %t10, 8
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l16, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr %"std/bench:Measurement", ptr %t28, i64 %t25
  %t30 = load %"std/bench:Measurement", ptr %t29
  store %"std/bench:Measurement" %t30, ptr %l4
  %t33 = call double @std_2fbench_2estd_2fbench_3aMeasurement_2eNanosPerOp(ptr %s2, ptr %l4)
  store double %t33, ptr %l20
  br label %bb5
bb5:
  %t34 = load double, ptr %l20, !tbaa !26
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr double, ptr %t37, i64 %t35
  store double %t34, ptr %t38, !tbaa !36
  %t39 = load i64, ptr %l11, !tbaa !24
  %t40 = add i64 %t39, 1
  store i64 %t40, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb1
bb7:
  %t46 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local double @std_2fbench_2estd_2fbench_3aSeries_2eSpread(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca double
  %s0 = alloca %olang.scope
  %rv = alloca double
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fbench_2estd_2fbench_3aSeries_2ePerOp(ptr %v0, ptr %s0, ptr %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = call double @std_2fbench_2eSpread(ptr %s0, { i64, ptr } %t4)
  store double %t6, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load double, ptr %l4, !tbaa !26
  store double %t7, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local %"std/bench:Measurement" @std_2fbench_2estd_2fbench_3aSeries_2eTypical(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca double
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/bench:Measurement"
  %l9 = alloca double
  %l19 = alloca { i64, ptr }
  %l23 = alloca double
  %l26 = alloca double
  %l30 = alloca double
  %l33 = alloca double
  %s2 = alloca %olang.scope
  %rv = alloca %"std/bench:Measurement"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call double @std_2fbench_2estd_2fbench_3aSeries_2eMedian(ptr %v0, ptr %t1)
  store double %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load double, ptr %l9, !tbaa !26
  store double %t4, ptr %l1, !tbaa !26
  store i64 0, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/bench:Series", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l6, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr %"std/bench:Measurement", ptr %t28, i64 %t25
  %t30 = load %"std/bench:Measurement", ptr %t29
  store %"std/bench:Measurement" %t30, ptr %l7
  %t33 = call double @std_2fbench_2estd_2fbench_3aMeasurement_2eNanosPerOp(ptr %s2, ptr %l7)
  store double %t33, ptr %l23
  br label %bb6
bb6:
  %t34 = load double, ptr %l1, !tbaa !26
  %t35 = load double, ptr %l23, !tbaa !26
  %t37 = fsub double %t35, %t34
  %t39 = call double @std_2fprelude_2fnumber_2eF64_2eAbs_3cF64_3e(double %t37)
  store double %t39, ptr %l26
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = getelementptr %"std/bench:Series", ptr %t40, i32 0, i32 0
  %t45 = getelementptr { i64, ptr }, ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr %"std/bench:Measurement", ptr %t46, i64 %t41
  %t49 = call double @std_2fbench_2estd_2fbench_3aMeasurement_2eNanosPerOp(ptr %v0, ptr %t47)
  store double %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load double, ptr %l1, !tbaa !26
  %t51 = load double, ptr %l30, !tbaa !26
  %t53 = fsub double %t51, %t50
  %t55 = call double @std_2fprelude_2fnumber_2eF64_2eAbs_3cF64_3e(double %t53)
  store double %t55, ptr %l33
  br label %bb9
bb9:
  %t56 = load double, ptr %l26, !tbaa !26
  %t57 = load double, ptr %l33, !tbaa !26
  %t58 = fcmp olt double %t56, %t57
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t62, 1
  store i64 %t65, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t70 = getelementptr %"std/bench:Series", ptr %t67, i32 0, i32 0
  %t72 = getelementptr { i64, ptr }, ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"std/bench:Measurement", ptr %t73, i64 %t68
  %t75 = load %"std/bench:Measurement", ptr %t74
  store %"std/bench:Measurement" %t75, ptr %rv
  br label %ret
ret:
  %rr = load %"std/bench:Measurement", ptr %rv
  ret %"std/bench:Measurement" %rr
}

define dso_local %"std/bench:Comparison" @std_2fbench_3aComparison_2ector(ptr %v0, ptr %v1, ptr %v2, %"std/bench:Series" %a0, %"std/bench:Series" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"std/bench:Comparison"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"std/bench:Comparison" undef, %"std/bench:Series" %a0, 0
  %t10 = insertvalue %"std/bench:Comparison" %t8, %"std/bench:Series" %a1, 1
  %t12 = insertvalue %"std/bench:Comparison" %t10, { i64, ptr } %a2, 2
  store %"std/bench:Comparison" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/bench:Comparison", ptr %rv
  ret %"std/bench:Comparison" %rr
}

define dso_local %"std/bench:Measurement" @std_2fbench_3aMeasurement_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"std/bench:Measurement"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"std/bench:Measurement" undef, i64 %a0, 0
  %t14 = insertvalue %"std/bench:Measurement" %t12, i64 %a1, 1
  %t16 = insertvalue %"std/bench:Measurement" %t14, i64 %a2, 2
  %t18 = insertvalue %"std/bench:Measurement" %t16, i64 %a3, 3
  %t20 = insertvalue %"std/bench:Measurement" %t18, i64 %a4, 4
  store %"std/bench:Measurement" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/bench:Measurement", ptr %rv
  ret %"std/bench:Measurement" %rr
}

define dso_local %"std/bench:Series" @std_2fbench_3aSeries_2ector(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca %"std/bench:Series"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"std/bench:Series" undef, { i64, ptr } %a0, 0
  store %"std/bench:Series" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/bench:Series", ptr %rv
  ret %"std/bench:Series" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define internal i1 @olang_lambda_0(ptr %env, double %a0, double %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = fcmp olt double %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare i64 @__olang_bench_on()
@__olang_empty_array = external constant [16 x i64]
declare i64 @__olang_test_running(ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d2 = private constant <{ i64, [1 x i64] }> <{ i64 0, [1 x i64] [i64 0] }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal void @olang_lambda_3(ptr %env) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l0
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 1, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i64, ptr %l1, !tbaa !24
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %vc0, ptr %t1, i64 %t3)
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load i64, ptr %l7, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = add i64 %t8, %t10
  store i64 %t13, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %vc0, ptr %t15, i64 %t17, i64 %t18)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" ops  " }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" ns/op" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d7 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" per call (median of " }>, align 8
@.d8 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" runs \C3\97 " }>, align 8
@.d9 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" calls)" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare void @std_2fprelude_2farray_2eArray_3cF64_3e_2eSort_3cF64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare double @std_2fprelude_2fnumber_2eF64_2eAbs_3cF64_3e(double %a0)
declare { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_590cb66873c2c3f3_59ce3f902ad3bbf = external constant [0 x i8]
@olang_loc_81530fe1491cf4be_4f813e5d1e4ab0ea = external constant [0 x i8]
declare %"std/prelude/array:ArrayIter.ef37386b9f0625afbaa73bd3cf091381" @std_2fprelude_2farray_2eArray_3cI64_3e_2eIter_3cI64_3e(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2eVec_2eFromIter_3cI64_2c_20std_2fprelude_2farray_3aArrayIter_3cI64_3e_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fbench_2eRun_3c_3f_3e(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fbench_2eKeep_3cI64_3e(i64 %a0)
declare { i64, ptr } @std_2fbench_2estd_2fbench_3aMeasurement_2ecounts(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fbench_2eHuman(ptr %v0, double %a0, double %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
