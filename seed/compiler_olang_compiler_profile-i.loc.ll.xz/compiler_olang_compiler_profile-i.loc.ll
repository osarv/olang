; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_233a93dc1fef0f55_caff5c35e8739a59 = weak_odr constant [56 x i8] c"std/prelude/array.olang:241: slice bounds out of range\0A\00"
@olang_loc_3150a4f8e5690956_2cf50342ae21ea7a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_4be946c2bdf59b0e_c04b844d9359e0e2 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_500261f4356e5220_d6cc16d3800b96ac = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_82f0012b48dfaebb_4cb9a81b523f39a7 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_c1f06282eec31e9b_199c37b049f92267 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_c1f1e329ebb7c352_d224fbf370d92b06 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:199: slice bounds out of range\0A\00"
@olang_loc_ea25b389a5392f42_84b591b19a77ef9e = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_efbd93d927e307c8_518766935672dd34 = weak_odr constant [56 x i8] c"std/prelude/array.olang:236: array length out of range\0A\00"
