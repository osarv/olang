; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"<fcntl.h>:f_owner_ex" = type { i32, i32 }
%"<fcntl.h>:file_handle" = type { i32, i32, [0 x i8] }
%"<fcntl.h>:flock64" = type { i16, i16, i64, i64, i32 }
%"<fcntl.h>:flock" = type { i16, i16, i64, i64, i32 }
%"<fcntl.h>:iovec" = type { ptr, i64 }
%"<fcntl.h>:timespec" = type { i64, i64 }
%"<fcntl.h>:stat64" = type { i64, i64, i64, i32, i32, i32, i32, i64, i64, i64, i64, %"<fcntl.h>:timespec", %"<fcntl.h>:timespec", %"<fcntl.h>:timespec", [3 x i64] }
%"<fcntl.h>:stat" = type { i64, i64, i64, i32, i32, i32, i32, i64, i64, i64, i64, %"<fcntl.h>:timespec", %"<fcntl.h>:timespec", %"<fcntl.h>:timespec", [3 x i64] }
@G_2e_3cfcntl_2eh_3e_2eAT__EACCESS = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\02\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__EMPTY__PATH = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__FDCWD = constant <{ [4 x i8] }> <{ [4 x i8] c"\9C\FF\FF\FF" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__HANDLE__FID = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\02\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__NO__AUTOMOUNT = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\08\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__RECURSIVE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\80\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__REMOVEDIR = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\02\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__STATX__DONT__SYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\40\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__STATX__FORCE__SYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\20\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__STATX__SYNC__AS__STAT = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__STATX__SYNC__TYPE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\60\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__SYMLINK__FOLLOW = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eAT__SYMLINK__NOFOLLOW = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\01\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eDN__ACCESS = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eDN__ATTRIB = constant <{ [4 x i8] }> <{ [4 x i8] c"\20\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eDN__CREATE = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eDN__DELETE = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eDN__MODIFY = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eDN__MULTISHOT = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\80\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eDN__RENAME = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__ALLOCATE__RANGE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__COLLAPSE__RANGE = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__INSERT__RANGE = constant <{ [4 x i8] }> <{ [4 x i8] c"\20\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__KEEP__SIZE = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__NO__HIDE__STALE = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__PUNCH__HOLE = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__UNSHARE__RANGE = constant <{ [4 x i8] }> <{ [4 x i8] c"\40\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__ZERO__RANGE = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFAPPEND = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFASYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\20\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFD__CLOEXEC = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFFSYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\10\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFNDELAY = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\08\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eFNONBLOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\08\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__ADD__SEALS = constant <{ [4 x i8] }> <{ [4 x i8] c"\09\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__DUPFD = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__DUPFD__CLOEXEC = constant <{ [4 x i8] }> <{ [4 x i8] c"\06\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__EXLCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETFD = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETFL = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETLEASE = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETLK = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETLK64 = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETOWN = constant <{ [4 x i8] }> <{ [4 x i8] c"\09\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETOWN__EX = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETPIPE__SZ = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GETSIG = constant <{ [4 x i8] }> <{ [4 x i8] c"\0B\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GET__FILE__RW__HINT = constant <{ [4 x i8] }> <{ [4 x i8] c"\0D\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GET__RW__HINT = constant <{ [4 x i8] }> <{ [4 x i8] c"\0B\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__GET__SEALS = constant <{ [4 x i8] }> <{ [4 x i8] c"\0A\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__LOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__NOTIFY = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__OFD__GETLK = constant <{ [4 x i8] }> <{ [4 x i8] c"\24\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__OFD__SETLK = constant <{ [4 x i8] }> <{ [4 x i8] c"\25\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__OFD__SETLKW = constant <{ [4 x i8] }> <{ [4 x i8] c"\26\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__OK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__OWNER__GID = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__OWNER__PGRP = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__OWNER__PID = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__OWNER__TID = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__RDLCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SEAL__EXEC = constant <{ [4 x i8] }> <{ [4 x i8] c"\20\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SEAL__FUTURE__WRITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SEAL__GROW = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SEAL__SEAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SEAL__SHRINK = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SEAL__WRITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETFD = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETFL = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETLEASE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETLK = constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETLK64 = constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETLKW = constant <{ [4 x i8] }> <{ [4 x i8] c"\07\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETLKW64 = constant <{ [4 x i8] }> <{ [4 x i8] c"\07\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETOWN = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETOWN__EX = constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETPIPE__SZ = constant <{ [4 x i8] }> <{ [4 x i8] c"\07\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SETSIG = constant <{ [4 x i8] }> <{ [4 x i8] c"\0A\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SET__FILE__RW__HINT = constant <{ [4 x i8] }> <{ [4 x i8] c"\0E\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SET__RW__HINT = constant <{ [4 x i8] }> <{ [4 x i8] c"\0C\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__SHLCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__TEST = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__TLOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__ULOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__UNLCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eF__WRLCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eLOCK__EX = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eLOCK__MAND = constant <{ [4 x i8] }> <{ [4 x i8] c"\20\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eLOCK__NB = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eLOCK__READ = constant <{ [4 x i8] }> <{ [4 x i8] c"\40\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eLOCK__RW = constant <{ [4 x i8] }> <{ [4 x i8] c"\C0\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eLOCK__SH = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eLOCK__UN = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eLOCK__WRITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\80\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eMAX__HANDLE__SZ = constant <{ [4 x i8] }> <{ [4 x i8] c"\80\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__ACCMODE = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__APPEND = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__ASYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\20\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__CLOEXEC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\08\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__CREAT = constant <{ [4 x i8] }> <{ [4 x i8] c"\40\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__DIRECT = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\40\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__DIRECTORY = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\01\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__DSYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__EXCL = constant <{ [4 x i8] }> <{ [4 x i8] c"\80\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__FSYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\10\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__LARGEFILE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__NDELAY = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\08\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__NOATIME = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\04\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__NOCTTY = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\01\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__NOFOLLOW = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\02\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__NONBLOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\08\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__PATH = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\20\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__RDONLY = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__RDWR = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__RSYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\10\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__SYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\10\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__TMPFILE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\41\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__TRUNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\02\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eO__WRONLY = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__DONTNEED = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__NOREUSE = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__NORMAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__RANDOM = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__SEQUENTIAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__WILLNEED = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eRWF__WRITE__LIFE__NOT__SET = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__EXTREME = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__LONG = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__MEDIUM = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__NONE = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__NOT__SET = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__SHORT = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eR__OK = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSEEK__CUR = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSEEK__END = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSEEK__SET = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSPLICE__F__GIFT = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSPLICE__F__MORE = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSPLICE__F__MOVE = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSPLICE__F__NONBLOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WAIT__AFTER = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WAIT__BEFORE = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WRITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WRITE__AND__WAIT = constant <{ [4 x i8] }> <{ [4 x i8] c"\07\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IFBLK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\60\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IFCHR = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\20\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IFDIR = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\40\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IFIFO = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IFLNK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\A0\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IFMT = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\F0\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IFREG = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\80\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IFSOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\C0\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IRGRP = constant <{ [4 x i8] }> <{ [4 x i8] c"\20\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IROTH = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IRUSR = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\01\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IRWXG = constant <{ [4 x i8] }> <{ [4 x i8] c"\38\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IRWXO = constant <{ [4 x i8] }> <{ [4 x i8] c"\07\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IRWXU = constant <{ [4 x i8] }> <{ [4 x i8] c"\C0\01\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__ISGID = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\04\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__ISUID = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\08\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__ISVTX = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\02\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IWGRP = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IWOTH = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IWUSR = constant <{ [4 x i8] }> <{ [4 x i8] c"\80\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IXGRP = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IXOTH = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eS__IXUSR = constant <{ [4 x i8] }> <{ [4 x i8] c"\40\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eUTIME__NOW = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\3F" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eUTIME__OMIT = constant <{ [4 x i8] }> <{ [4 x i8] c"\FE\FF\FF\3F" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eW__OK = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cfcntl_2eh_3e_2eX__OK = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
define dso_local void @_3cfcntl_2eh_3e_2eAT__EACCESS_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 512, ptr @G_2e_3cfcntl_2eh_3e_2eAT__EACCESS, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__EMPTY__PATH_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4096, ptr @G_2e_3cfcntl_2eh_3e_2eAT__EMPTY__PATH, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__FDCWD_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 -100, ptr @G_2e_3cfcntl_2eh_3e_2eAT__FDCWD, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__HANDLE__FID_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 512, ptr @G_2e_3cfcntl_2eh_3e_2eAT__HANDLE__FID, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__NO__AUTOMOUNT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2048, ptr @G_2e_3cfcntl_2eh_3e_2eAT__NO__AUTOMOUNT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__RECURSIVE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32768, ptr @G_2e_3cfcntl_2eh_3e_2eAT__RECURSIVE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__REMOVEDIR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 512, ptr @G_2e_3cfcntl_2eh_3e_2eAT__REMOVEDIR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__STATX__DONT__SYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16384, ptr @G_2e_3cfcntl_2eh_3e_2eAT__STATX__DONT__SYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__STATX__FORCE__SYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8192, ptr @G_2e_3cfcntl_2eh_3e_2eAT__STATX__FORCE__SYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__STATX__SYNC__AS__STAT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eAT__STATX__SYNC__AS__STAT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__STATX__SYNC__TYPE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 24576, ptr @G_2e_3cfcntl_2eh_3e_2eAT__STATX__SYNC__TYPE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__SYMLINK__FOLLOW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1024, ptr @G_2e_3cfcntl_2eh_3e_2eAT__SYMLINK__FOLLOW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eAT__SYMLINK__NOFOLLOW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 256, ptr @G_2e_3cfcntl_2eh_3e_2eAT__SYMLINK__NOFOLLOW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eDN__ACCESS_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eDN__ACCESS, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eDN__ATTRIB_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32, ptr @G_2e_3cfcntl_2eh_3e_2eDN__ATTRIB, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eDN__CREATE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eDN__CREATE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eDN__DELETE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cfcntl_2eh_3e_2eDN__DELETE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eDN__MODIFY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eDN__MODIFY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eDN__MULTISHOT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2147483648, ptr @G_2e_3cfcntl_2eh_3e_2eDN__MULTISHOT, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eDN__RENAME_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2e_3cfcntl_2eh_3e_2eDN__RENAME, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFALLOC__FL__ALLOCATE__RANGE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__ALLOCATE__RANGE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFALLOC__FL__COLLAPSE__RANGE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__COLLAPSE__RANGE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFALLOC__FL__INSERT__RANGE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32, ptr @G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__INSERT__RANGE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFALLOC__FL__KEEP__SIZE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__KEEP__SIZE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFALLOC__FL__NO__HIDE__STALE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__NO__HIDE__STALE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFALLOC__FL__PUNCH__HOLE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__PUNCH__HOLE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFALLOC__FL__UNSHARE__RANGE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 64, ptr @G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__UNSHARE__RANGE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFALLOC__FL__ZERO__RANGE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2e_3cfcntl_2eh_3e_2eFALLOC__FL__ZERO__RANGE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFAPPEND_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1024, ptr @G_2e_3cfcntl_2eh_3e_2eFAPPEND, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFASYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8192, ptr @G_2e_3cfcntl_2eh_3e_2eFASYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFD__CLOEXEC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eFD__CLOEXEC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFFSYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1052672, ptr @G_2e_3cfcntl_2eh_3e_2eFFSYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFNDELAY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2048, ptr @G_2e_3cfcntl_2eh_3e_2eFNDELAY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eFNONBLOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2048, ptr @G_2e_3cfcntl_2eh_3e_2eFNONBLOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__ADD__SEALS_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1033, ptr @G_2e_3cfcntl_2eh_3e_2eF__ADD__SEALS, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__DUPFD_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eF__DUPFD, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__DUPFD__CLOEXEC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1030, ptr @G_2e_3cfcntl_2eh_3e_2eF__DUPFD__CLOEXEC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__EXLCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eF__EXLCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETFD_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETFD, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETFL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETFL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETLEASE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1025, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETLEASE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETLK64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 5, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETLK64, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETLK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 5, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETLK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETOWN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 9, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETOWN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETOWN__EX_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETOWN__EX, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETPIPE__SZ_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1032, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETPIPE__SZ, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GETSIG_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 11, ptr @G_2e_3cfcntl_2eh_3e_2eF__GETSIG, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GET__FILE__RW__HINT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1037, ptr @G_2e_3cfcntl_2eh_3e_2eF__GET__FILE__RW__HINT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GET__RW__HINT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1035, ptr @G_2e_3cfcntl_2eh_3e_2eF__GET__RW__HINT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__GET__SEALS_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1034, ptr @G_2e_3cfcntl_2eh_3e_2eF__GET__SEALS, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__LOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eF__LOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__NOTIFY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1026, ptr @G_2e_3cfcntl_2eh_3e_2eF__NOTIFY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__OFD__GETLK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 36, ptr @G_2e_3cfcntl_2eh_3e_2eF__OFD__GETLK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__OFD__SETLKW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 38, ptr @G_2e_3cfcntl_2eh_3e_2eF__OFD__SETLKW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__OFD__SETLK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 37, ptr @G_2e_3cfcntl_2eh_3e_2eF__OFD__SETLK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__OK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eF__OK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__OWNER__GID_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eF__OWNER__GID, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__OWNER__PGRP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eF__OWNER__PGRP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__OWNER__PID_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eF__OWNER__PID, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__OWNER__TID_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eF__OWNER__TID, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__RDLCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eF__RDLCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SEAL__EXEC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32, ptr @G_2e_3cfcntl_2eh_3e_2eF__SEAL__EXEC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SEAL__FUTURE__WRITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2e_3cfcntl_2eh_3e_2eF__SEAL__FUTURE__WRITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SEAL__GROW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eF__SEAL__GROW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SEAL__SEAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eF__SEAL__SEAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SEAL__SHRINK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eF__SEAL__SHRINK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SEAL__WRITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cfcntl_2eh_3e_2eF__SEAL__WRITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETFD_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETFD, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETFL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETFL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETLEASE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1024, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETLEASE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETLK64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 6, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETLK64, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETLKW64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 7, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETLKW64, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETLKW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 7, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETLKW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETLK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 6, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETLK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETOWN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETOWN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETOWN__EX_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 15, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETOWN__EX, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETPIPE__SZ_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1031, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETPIPE__SZ, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SETSIG_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 10, ptr @G_2e_3cfcntl_2eh_3e_2eF__SETSIG, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SET__FILE__RW__HINT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1038, ptr @G_2e_3cfcntl_2eh_3e_2eF__SET__FILE__RW__HINT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SET__RW__HINT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1036, ptr @G_2e_3cfcntl_2eh_3e_2eF__SET__RW__HINT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__SHLCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cfcntl_2eh_3e_2eF__SHLCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__TEST_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cfcntl_2eh_3e_2eF__TEST, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__TLOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eF__TLOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__ULOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eF__ULOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__UNLCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eF__UNLCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eF__WRLCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eF__WRLCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eLOCK__EX_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eLOCK__EX, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eLOCK__MAND_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32, ptr @G_2e_3cfcntl_2eh_3e_2eLOCK__MAND, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eLOCK__NB_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eLOCK__NB, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eLOCK__READ_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 64, ptr @G_2e_3cfcntl_2eh_3e_2eLOCK__READ, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eLOCK__RW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 192, ptr @G_2e_3cfcntl_2eh_3e_2eLOCK__RW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eLOCK__SH_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eLOCK__SH, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eLOCK__UN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cfcntl_2eh_3e_2eLOCK__UN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eLOCK__WRITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 128, ptr @G_2e_3cfcntl_2eh_3e_2eLOCK__WRITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eMAX__HANDLE__SZ_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 128, ptr @G_2e_3cfcntl_2eh_3e_2eMAX__HANDLE__SZ, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__ACCMODE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cfcntl_2eh_3e_2eO__ACCMODE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__APPEND_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1024, ptr @G_2e_3cfcntl_2eh_3e_2eO__APPEND, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__ASYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8192, ptr @G_2e_3cfcntl_2eh_3e_2eO__ASYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__CLOEXEC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 524288, ptr @G_2e_3cfcntl_2eh_3e_2eO__CLOEXEC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__CREAT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 64, ptr @G_2e_3cfcntl_2eh_3e_2eO__CREAT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__DIRECTORY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 65536, ptr @G_2e_3cfcntl_2eh_3e_2eO__DIRECTORY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__DIRECT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16384, ptr @G_2e_3cfcntl_2eh_3e_2eO__DIRECT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__DSYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4096, ptr @G_2e_3cfcntl_2eh_3e_2eO__DSYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__EXCL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 128, ptr @G_2e_3cfcntl_2eh_3e_2eO__EXCL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__FSYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1052672, ptr @G_2e_3cfcntl_2eh_3e_2eO__FSYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__LARGEFILE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eO__LARGEFILE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__NDELAY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2048, ptr @G_2e_3cfcntl_2eh_3e_2eO__NDELAY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__NOATIME_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 262144, ptr @G_2e_3cfcntl_2eh_3e_2eO__NOATIME, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__NOCTTY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 256, ptr @G_2e_3cfcntl_2eh_3e_2eO__NOCTTY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__NOFOLLOW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 131072, ptr @G_2e_3cfcntl_2eh_3e_2eO__NOFOLLOW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__NONBLOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2048, ptr @G_2e_3cfcntl_2eh_3e_2eO__NONBLOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__PATH_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2097152, ptr @G_2e_3cfcntl_2eh_3e_2eO__PATH, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__RDONLY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eO__RDONLY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__RDWR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eO__RDWR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__RSYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1052672, ptr @G_2e_3cfcntl_2eh_3e_2eO__RSYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__SYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1052672, ptr @G_2e_3cfcntl_2eh_3e_2eO__SYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__TMPFILE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4259840, ptr @G_2e_3cfcntl_2eh_3e_2eO__TMPFILE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__TRUNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 512, ptr @G_2e_3cfcntl_2eh_3e_2eO__TRUNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eO__WRONLY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eO__WRONLY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2ePOSIX__FADV__DONTNEED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__DONTNEED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2ePOSIX__FADV__NOREUSE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 5, ptr @G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__NOREUSE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2ePOSIX__FADV__NORMAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__NORMAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2ePOSIX__FADV__RANDOM_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__RANDOM, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2ePOSIX__FADV__SEQUENTIAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__SEQUENTIAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2ePOSIX__FADV__WILLNEED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cfcntl_2eh_3e_2ePOSIX__FADV__WILLNEED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eRWF__WRITE__LIFE__NOT__SET_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eRWF__WRITE__LIFE__NOT__SET, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__EXTREME_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 5, ptr @G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__EXTREME, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__LONG_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__LONG, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__MEDIUM_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__MEDIUM, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__NONE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__NONE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__NOT__SET_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__NOT__SET, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__SHORT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__SHORT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eR__OK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eR__OK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSEEK__CUR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eSEEK__CUR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSEEK__END_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eSEEK__END, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSEEK__SET_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cfcntl_2eh_3e_2eSEEK__SET, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSPLICE__F__GIFT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cfcntl_2eh_3e_2eSPLICE__F__GIFT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSPLICE__F__MORE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eSPLICE__F__MORE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSPLICE__F__MOVE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eSPLICE__F__MOVE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSPLICE__F__NONBLOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eSPLICE__F__NONBLOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WAIT__AFTER_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WAIT__AFTER, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WAIT__BEFORE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WAIT__BEFORE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WRITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WRITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WRITE__AND__WAIT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 7, ptr @G_2e_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WRITE__AND__WAIT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IFBLK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 24576, ptr @G_2e_3cfcntl_2eh_3e_2eS__IFBLK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IFCHR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8192, ptr @G_2e_3cfcntl_2eh_3e_2eS__IFCHR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IFDIR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16384, ptr @G_2e_3cfcntl_2eh_3e_2eS__IFDIR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IFIFO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4096, ptr @G_2e_3cfcntl_2eh_3e_2eS__IFIFO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IFLNK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 40960, ptr @G_2e_3cfcntl_2eh_3e_2eS__IFLNK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IFMT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 61440, ptr @G_2e_3cfcntl_2eh_3e_2eS__IFMT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IFREG_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32768, ptr @G_2e_3cfcntl_2eh_3e_2eS__IFREG, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IFSOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 49152, ptr @G_2e_3cfcntl_2eh_3e_2eS__IFSOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IRGRP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32, ptr @G_2e_3cfcntl_2eh_3e_2eS__IRGRP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IROTH_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cfcntl_2eh_3e_2eS__IROTH, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IRUSR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 256, ptr @G_2e_3cfcntl_2eh_3e_2eS__IRUSR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IRWXG_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 56, ptr @G_2e_3cfcntl_2eh_3e_2eS__IRWXG, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IRWXO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 7, ptr @G_2e_3cfcntl_2eh_3e_2eS__IRWXO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IRWXU_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 448, ptr @G_2e_3cfcntl_2eh_3e_2eS__IRWXU, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__ISGID_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1024, ptr @G_2e_3cfcntl_2eh_3e_2eS__ISGID, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__ISUID_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2048, ptr @G_2e_3cfcntl_2eh_3e_2eS__ISUID, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__ISVTX_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 512, ptr @G_2e_3cfcntl_2eh_3e_2eS__ISVTX, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IWGRP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2e_3cfcntl_2eh_3e_2eS__IWGRP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IWOTH_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eS__IWOTH, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IWUSR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 128, ptr @G_2e_3cfcntl_2eh_3e_2eS__IWUSR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IXGRP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cfcntl_2eh_3e_2eS__IXGRP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IXOTH_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eS__IXOTH, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eS__IXUSR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 64, ptr @G_2e_3cfcntl_2eh_3e_2eS__IXUSR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eUTIME__NOW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1073741823, ptr @G_2e_3cfcntl_2eh_3e_2eUTIME__NOW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eUTIME__OMIT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1073741822, ptr @G_2e_3cfcntl_2eh_3e_2eUTIME__OMIT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eW__OK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cfcntl_2eh_3e_2eW__OK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_2eX__OK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cfcntl_2eh_3e_2eX__OK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local %"<fcntl.h>:f_owner_ex" @_3cfcntl_2eh_3e_3af__owner__ex_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<fcntl.h>:f_owner_ex"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<fcntl.h>:f_owner_ex" undef, i32 0, 0
  %t4 = insertvalue %"<fcntl.h>:f_owner_ex" %t2, i32 0, 1
  store %"<fcntl.h>:f_owner_ex" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"<fcntl.h>:f_owner_ex", ptr %rv
  ret %"<fcntl.h>:f_owner_ex" %rr
}

define dso_local %"<fcntl.h>:file_handle" @_3cfcntl_2eh_3e_3afile__handle_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<fcntl.h>:file_handle"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = insertvalue %"<fcntl.h>:file_handle" undef, i32 0, 0
  %t5 = insertvalue %"<fcntl.h>:file_handle" %t3, i32 0, 1
  %t7 = insertvalue %"<fcntl.h>:file_handle" %t5, [0 x i8] zeroinitializer, 2
  store %"<fcntl.h>:file_handle" %t7, ptr %rv
  br label %ret
ret:
  %rr = load %"<fcntl.h>:file_handle", ptr %rv
  ret %"<fcntl.h>:file_handle" %rr
}

define dso_local %"<fcntl.h>:flock64" @_3cfcntl_2eh_3e_3aflock64_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<fcntl.h>:flock64"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<fcntl.h>:flock64" undef, i16 0, 0
  %t4 = insertvalue %"<fcntl.h>:flock64" %t2, i16 0, 1
  %t6 = insertvalue %"<fcntl.h>:flock64" %t4, i64 0, 2
  %t8 = insertvalue %"<fcntl.h>:flock64" %t6, i64 0, 3
  %t10 = insertvalue %"<fcntl.h>:flock64" %t8, i32 0, 4
  store %"<fcntl.h>:flock64" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"<fcntl.h>:flock64", ptr %rv
  ret %"<fcntl.h>:flock64" %rr
}

define dso_local %"<fcntl.h>:flock" @_3cfcntl_2eh_3e_3aflock_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<fcntl.h>:flock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<fcntl.h>:flock" undef, i16 0, 0
  %t4 = insertvalue %"<fcntl.h>:flock" %t2, i16 0, 1
  %t6 = insertvalue %"<fcntl.h>:flock" %t4, i64 0, 2
  %t8 = insertvalue %"<fcntl.h>:flock" %t6, i64 0, 3
  %t10 = insertvalue %"<fcntl.h>:flock" %t8, i32 0, 4
  store %"<fcntl.h>:flock" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"<fcntl.h>:flock", ptr %rv
  ret %"<fcntl.h>:flock" %rr
}

define dso_local %"<fcntl.h>:iovec" @_3cfcntl_2eh_3e_3aiovec_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<fcntl.h>:iovec"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<fcntl.h>:iovec" undef, ptr null, 0
  %t4 = insertvalue %"<fcntl.h>:iovec" %t2, i64 0, 1
  store %"<fcntl.h>:iovec" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"<fcntl.h>:iovec", ptr %rv
  ret %"<fcntl.h>:iovec" %rr
}

define dso_local void @_3cfcntl_2eh_3e_3astat64_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"<fcntl.h>:timespec"
  %l12 = alloca %"<fcntl.h>:timespec"
  %l15 = alloca %"<fcntl.h>:timespec"
  %l16 = alloca %"<fcntl.h>:timespec"
  %l17 = alloca %"<fcntl.h>:timespec"
  %l19 = alloca %"<fcntl.h>:stat64"
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !65
  store i64 0, ptr %l1, !tbaa !65
  store i64 0, ptr %l2, !tbaa !65
  store i32 0, ptr %l3, !tbaa !64
  store i32 0, ptr %l4, !tbaa !64
  store i32 0, ptr %l5, !tbaa !64
  store i32 0, ptr %l6, !tbaa !23
  store i64 0, ptr %l7, !tbaa !65
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t1 = call %"<fcntl.h>:timespec" @olang_2eHelperKind_2eZero_2e_3cfcntl_2eh_3e_3atimespec()
  store %"<fcntl.h>:timespec" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"<fcntl.h>:timespec", ptr %l15
  store %"<fcntl.h>:timespec" %t2, ptr %l11
  %t3 = call %"<fcntl.h>:timespec" @olang_2eHelperKind_2eZero_2e_3cfcntl_2eh_3e_3atimespec()
  store %"<fcntl.h>:timespec" %t3, ptr %l16
  br label %bb2
bb2:
  %t4 = load %"<fcntl.h>:timespec", ptr %l16
  store %"<fcntl.h>:timespec" %t4, ptr %l12
  %t5 = call %"<fcntl.h>:timespec" @olang_2eHelperKind_2eZero_2e_3cfcntl_2eh_3e_3atimespec()
  store %"<fcntl.h>:timespec" %t5, ptr %l17
  br label %bb3
bb3:
  %t6 = load %"<fcntl.h>:timespec", ptr %l17
  %t7 = insertvalue [3 x i64] undef, i64 0, 0
  %t8 = insertvalue [3 x i64] %t7, i64 0, 1
  %t9 = insertvalue [3 x i64] %t8, i64 0, 2
  %t11 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 0
  %t12 = load i64, ptr %l0, !tbaa !65
  store i64 %t12, ptr %t11, !tbaa !65
  %t13 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !65
  store i64 %t14, ptr %t13, !tbaa !65
  %t15 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 2
  %t16 = load i64, ptr %l2, !tbaa !65
  store i64 %t16, ptr %t15, !tbaa !65
  %t17 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 3
  %t18 = load i32, ptr %l3, !tbaa !64
  store i32 %t18, ptr %t17, !tbaa !64
  %t19 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 4
  %t20 = load i32, ptr %l4, !tbaa !64
  store i32 %t20, ptr %t19, !tbaa !64
  %t21 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 5
  %t22 = load i32, ptr %l5, !tbaa !64
  store i32 %t22, ptr %t21, !tbaa !64
  %t23 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 6
  %t24 = load i32, ptr %l6, !tbaa !23
  store i32 %t24, ptr %t23, !tbaa !23
  %t25 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 7
  %t26 = load i64, ptr %l7, !tbaa !65
  store i64 %t26, ptr %t25, !tbaa !65
  %t27 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 8
  %t28 = load i64, ptr %l8, !tbaa !24
  store i64 %t28, ptr %t27, !tbaa !24
  %t29 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 9
  %t30 = load i64, ptr %l9, !tbaa !24
  store i64 %t30, ptr %t29, !tbaa !24
  %t31 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 10
  %t32 = load i64, ptr %l10, !tbaa !24
  store i64 %t32, ptr %t31, !tbaa !24
  %t33 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 11
  %t34 = load %"<fcntl.h>:timespec", ptr %l11
  store %"<fcntl.h>:timespec" %t34, ptr %t33
  %t35 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 12
  %t36 = load %"<fcntl.h>:timespec", ptr %l12
  store %"<fcntl.h>:timespec" %t36, ptr %t35
  %t37 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 13
  store %"<fcntl.h>:timespec" %t6, ptr %t37
  %t39 = getelementptr %"<fcntl.h>:stat64", ptr %l19, i32 0, i32 14
  store [3 x i64] %t9, ptr %t39
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l19, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @_3cfcntl_2eh_3e_3astat_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"<fcntl.h>:timespec"
  %l12 = alloca %"<fcntl.h>:timespec"
  %l15 = alloca %"<fcntl.h>:timespec"
  %l16 = alloca %"<fcntl.h>:timespec"
  %l17 = alloca %"<fcntl.h>:timespec"
  %l19 = alloca %"<fcntl.h>:stat"
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !65
  store i64 0, ptr %l1, !tbaa !65
  store i64 0, ptr %l2, !tbaa !65
  store i32 0, ptr %l3, !tbaa !64
  store i32 0, ptr %l4, !tbaa !64
  store i32 0, ptr %l5, !tbaa !64
  store i32 0, ptr %l6, !tbaa !23
  store i64 0, ptr %l7, !tbaa !65
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t1 = call %"<fcntl.h>:timespec" @olang_2eHelperKind_2eZero_2e_3cfcntl_2eh_3e_3atimespec()
  store %"<fcntl.h>:timespec" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"<fcntl.h>:timespec", ptr %l15
  store %"<fcntl.h>:timespec" %t2, ptr %l11
  %t3 = call %"<fcntl.h>:timespec" @olang_2eHelperKind_2eZero_2e_3cfcntl_2eh_3e_3atimespec()
  store %"<fcntl.h>:timespec" %t3, ptr %l16
  br label %bb2
bb2:
  %t4 = load %"<fcntl.h>:timespec", ptr %l16
  store %"<fcntl.h>:timespec" %t4, ptr %l12
  %t5 = call %"<fcntl.h>:timespec" @olang_2eHelperKind_2eZero_2e_3cfcntl_2eh_3e_3atimespec()
  store %"<fcntl.h>:timespec" %t5, ptr %l17
  br label %bb3
bb3:
  %t6 = load %"<fcntl.h>:timespec", ptr %l17
  %t7 = insertvalue [3 x i64] undef, i64 0, 0
  %t8 = insertvalue [3 x i64] %t7, i64 0, 1
  %t9 = insertvalue [3 x i64] %t8, i64 0, 2
  %t11 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 0
  %t12 = load i64, ptr %l0, !tbaa !65
  store i64 %t12, ptr %t11, !tbaa !65
  %t13 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !65
  store i64 %t14, ptr %t13, !tbaa !65
  %t15 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 2
  %t16 = load i64, ptr %l2, !tbaa !65
  store i64 %t16, ptr %t15, !tbaa !65
  %t17 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 3
  %t18 = load i32, ptr %l3, !tbaa !64
  store i32 %t18, ptr %t17, !tbaa !64
  %t19 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 4
  %t20 = load i32, ptr %l4, !tbaa !64
  store i32 %t20, ptr %t19, !tbaa !64
  %t21 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 5
  %t22 = load i32, ptr %l5, !tbaa !64
  store i32 %t22, ptr %t21, !tbaa !64
  %t23 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 6
  %t24 = load i32, ptr %l6, !tbaa !23
  store i32 %t24, ptr %t23, !tbaa !23
  %t25 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 7
  %t26 = load i64, ptr %l7, !tbaa !65
  store i64 %t26, ptr %t25, !tbaa !65
  %t27 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 8
  %t28 = load i64, ptr %l8, !tbaa !24
  store i64 %t28, ptr %t27, !tbaa !24
  %t29 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 9
  %t30 = load i64, ptr %l9, !tbaa !24
  store i64 %t30, ptr %t29, !tbaa !24
  %t31 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 10
  %t32 = load i64, ptr %l10, !tbaa !24
  store i64 %t32, ptr %t31, !tbaa !24
  %t33 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 11
  %t34 = load %"<fcntl.h>:timespec", ptr %l11
  store %"<fcntl.h>:timespec" %t34, ptr %t33
  %t35 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 12
  %t36 = load %"<fcntl.h>:timespec", ptr %l12
  store %"<fcntl.h>:timespec" %t36, ptr %t35
  %t37 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 13
  store %"<fcntl.h>:timespec" %t6, ptr %t37
  %t39 = getelementptr %"<fcntl.h>:stat", ptr %l19, i32 0, i32 14
  store [3 x i64] %t9, ptr %t39
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l19, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<fcntl.h>:timespec"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<fcntl.h>:timespec" undef, i64 0, 0
  %t4 = insertvalue %"<fcntl.h>:timespec" %t2, i64 0, 1
  store %"<fcntl.h>:timespec" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"<fcntl.h>:timespec", ptr %rv
  ret %"<fcntl.h>:timespec" %rr
}

define dso_local void @olang_2einit_2e_3cfcntl_2eh_3e() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @_3cfcntl_2eh_3e_2eF__OWNER__TID_2einit()
  br label %bb1
bb1:
  call void @_3cfcntl_2eh_3e_2eF__OWNER__PID_2einit()
  br label %bb2
bb2:
  call void @_3cfcntl_2eh_3e_2eF__OWNER__PGRP_2einit()
  br label %bb3
bb3:
  call void @_3cfcntl_2eh_3e_2eF__OWNER__GID_2einit()
  br label %bb4
bb4:
  call void @_3cfcntl_2eh_3e_2eF__GETLK64_2einit()
  br label %bb5
bb5:
  call void @_3cfcntl_2eh_3e_2eF__SETLK64_2einit()
  br label %bb6
bb6:
  call void @_3cfcntl_2eh_3e_2eF__SETLKW64_2einit()
  br label %bb7
bb7:
  call void @_3cfcntl_2eh_3e_2eO__ACCMODE_2einit()
  br label %bb8
bb8:
  call void @_3cfcntl_2eh_3e_2eO__RDONLY_2einit()
  br label %bb9
bb9:
  call void @_3cfcntl_2eh_3e_2eO__WRONLY_2einit()
  br label %bb10
bb10:
  call void @_3cfcntl_2eh_3e_2eO__RDWR_2einit()
  br label %bb11
bb11:
  call void @_3cfcntl_2eh_3e_2eO__CREAT_2einit()
  br label %bb12
bb12:
  call void @_3cfcntl_2eh_3e_2eO__EXCL_2einit()
  br label %bb13
bb13:
  call void @_3cfcntl_2eh_3e_2eO__NOCTTY_2einit()
  br label %bb14
bb14:
  call void @_3cfcntl_2eh_3e_2eO__TRUNC_2einit()
  br label %bb15
bb15:
  call void @_3cfcntl_2eh_3e_2eO__APPEND_2einit()
  br label %bb16
bb16:
  call void @_3cfcntl_2eh_3e_2eO__NONBLOCK_2einit()
  br label %bb17
bb17:
  call void @_3cfcntl_2eh_3e_2eO__NDELAY_2einit()
  br label %bb18
bb18:
  call void @_3cfcntl_2eh_3e_2eO__SYNC_2einit()
  br label %bb19
bb19:
  call void @_3cfcntl_2eh_3e_2eO__FSYNC_2einit()
  br label %bb20
bb20:
  call void @_3cfcntl_2eh_3e_2eO__ASYNC_2einit()
  br label %bb21
bb21:
  call void @_3cfcntl_2eh_3e_2eF__GETLK_2einit()
  br label %bb22
bb22:
  call void @_3cfcntl_2eh_3e_2eF__SETLK_2einit()
  br label %bb23
bb23:
  call void @_3cfcntl_2eh_3e_2eF__SETLKW_2einit()
  br label %bb24
bb24:
  call void @_3cfcntl_2eh_3e_2eF__OFD__GETLK_2einit()
  br label %bb25
bb25:
  call void @_3cfcntl_2eh_3e_2eF__OFD__SETLK_2einit()
  br label %bb26
bb26:
  call void @_3cfcntl_2eh_3e_2eF__OFD__SETLKW_2einit()
  br label %bb27
bb27:
  call void @_3cfcntl_2eh_3e_2eO__LARGEFILE_2einit()
  br label %bb28
bb28:
  call void @_3cfcntl_2eh_3e_2eO__DIRECTORY_2einit()
  br label %bb29
bb29:
  call void @_3cfcntl_2eh_3e_2eO__NOFOLLOW_2einit()
  br label %bb30
bb30:
  call void @_3cfcntl_2eh_3e_2eO__CLOEXEC_2einit()
  br label %bb31
bb31:
  call void @_3cfcntl_2eh_3e_2eO__DIRECT_2einit()
  br label %bb32
bb32:
  call void @_3cfcntl_2eh_3e_2eO__NOATIME_2einit()
  br label %bb33
bb33:
  call void @_3cfcntl_2eh_3e_2eO__PATH_2einit()
  br label %bb34
bb34:
  call void @_3cfcntl_2eh_3e_2eO__TMPFILE_2einit()
  br label %bb35
bb35:
  call void @_3cfcntl_2eh_3e_2eO__DSYNC_2einit()
  br label %bb36
bb36:
  call void @_3cfcntl_2eh_3e_2eO__RSYNC_2einit()
  br label %bb37
bb37:
  call void @_3cfcntl_2eh_3e_2eF__DUPFD_2einit()
  br label %bb38
bb38:
  call void @_3cfcntl_2eh_3e_2eF__GETFD_2einit()
  br label %bb39
bb39:
  call void @_3cfcntl_2eh_3e_2eF__SETFD_2einit()
  br label %bb40
bb40:
  call void @_3cfcntl_2eh_3e_2eF__GETFL_2einit()
  br label %bb41
bb41:
  call void @_3cfcntl_2eh_3e_2eF__SETFL_2einit()
  br label %bb42
bb42:
  call void @_3cfcntl_2eh_3e_2eF__SETOWN_2einit()
  br label %bb43
bb43:
  call void @_3cfcntl_2eh_3e_2eF__GETOWN_2einit()
  br label %bb44
bb44:
  call void @_3cfcntl_2eh_3e_2eF__SETSIG_2einit()
  br label %bb45
bb45:
  call void @_3cfcntl_2eh_3e_2eF__GETSIG_2einit()
  br label %bb46
bb46:
  call void @_3cfcntl_2eh_3e_2eF__SETOWN__EX_2einit()
  br label %bb47
bb47:
  call void @_3cfcntl_2eh_3e_2eF__GETOWN__EX_2einit()
  br label %bb48
bb48:
  call void @_3cfcntl_2eh_3e_2eF__SETLEASE_2einit()
  br label %bb49
bb49:
  call void @_3cfcntl_2eh_3e_2eF__GETLEASE_2einit()
  br label %bb50
bb50:
  call void @_3cfcntl_2eh_3e_2eF__NOTIFY_2einit()
  br label %bb51
bb51:
  call void @_3cfcntl_2eh_3e_2eF__SETPIPE__SZ_2einit()
  br label %bb52
bb52:
  call void @_3cfcntl_2eh_3e_2eF__GETPIPE__SZ_2einit()
  br label %bb53
bb53:
  call void @_3cfcntl_2eh_3e_2eF__ADD__SEALS_2einit()
  br label %bb54
bb54:
  call void @_3cfcntl_2eh_3e_2eF__GET__SEALS_2einit()
  br label %bb55
bb55:
  call void @_3cfcntl_2eh_3e_2eF__GET__RW__HINT_2einit()
  br label %bb56
bb56:
  call void @_3cfcntl_2eh_3e_2eF__SET__RW__HINT_2einit()
  br label %bb57
bb57:
  call void @_3cfcntl_2eh_3e_2eF__GET__FILE__RW__HINT_2einit()
  br label %bb58
bb58:
  call void @_3cfcntl_2eh_3e_2eF__SET__FILE__RW__HINT_2einit()
  br label %bb59
bb59:
  call void @_3cfcntl_2eh_3e_2eF__DUPFD__CLOEXEC_2einit()
  br label %bb60
bb60:
  call void @_3cfcntl_2eh_3e_2eFD__CLOEXEC_2einit()
  br label %bb61
bb61:
  call void @_3cfcntl_2eh_3e_2eF__RDLCK_2einit()
  br label %bb62
bb62:
  call void @_3cfcntl_2eh_3e_2eF__WRLCK_2einit()
  br label %bb63
bb63:
  call void @_3cfcntl_2eh_3e_2eF__UNLCK_2einit()
  br label %bb64
bb64:
  call void @_3cfcntl_2eh_3e_2eF__EXLCK_2einit()
  br label %bb65
bb65:
  call void @_3cfcntl_2eh_3e_2eF__SHLCK_2einit()
  br label %bb66
bb66:
  call void @_3cfcntl_2eh_3e_2eLOCK__SH_2einit()
  br label %bb67
bb67:
  call void @_3cfcntl_2eh_3e_2eLOCK__EX_2einit()
  br label %bb68
bb68:
  call void @_3cfcntl_2eh_3e_2eLOCK__NB_2einit()
  br label %bb69
bb69:
  call void @_3cfcntl_2eh_3e_2eLOCK__UN_2einit()
  br label %bb70
bb70:
  call void @_3cfcntl_2eh_3e_2eLOCK__MAND_2einit()
  br label %bb71
bb71:
  call void @_3cfcntl_2eh_3e_2eLOCK__READ_2einit()
  br label %bb72
bb72:
  call void @_3cfcntl_2eh_3e_2eLOCK__WRITE_2einit()
  br label %bb73
bb73:
  call void @_3cfcntl_2eh_3e_2eLOCK__RW_2einit()
  br label %bb74
bb74:
  call void @_3cfcntl_2eh_3e_2eDN__ACCESS_2einit()
  br label %bb75
bb75:
  call void @_3cfcntl_2eh_3e_2eDN__MODIFY_2einit()
  br label %bb76
bb76:
  call void @_3cfcntl_2eh_3e_2eDN__CREATE_2einit()
  br label %bb77
bb77:
  call void @_3cfcntl_2eh_3e_2eDN__DELETE_2einit()
  br label %bb78
bb78:
  call void @_3cfcntl_2eh_3e_2eDN__RENAME_2einit()
  br label %bb79
bb79:
  call void @_3cfcntl_2eh_3e_2eDN__ATTRIB_2einit()
  br label %bb80
bb80:
  call void @_3cfcntl_2eh_3e_2eDN__MULTISHOT_2einit()
  br label %bb81
bb81:
  call void @_3cfcntl_2eh_3e_2eF__SEAL__SEAL_2einit()
  br label %bb82
bb82:
  call void @_3cfcntl_2eh_3e_2eF__SEAL__SHRINK_2einit()
  br label %bb83
bb83:
  call void @_3cfcntl_2eh_3e_2eF__SEAL__GROW_2einit()
  br label %bb84
bb84:
  call void @_3cfcntl_2eh_3e_2eF__SEAL__WRITE_2einit()
  br label %bb85
bb85:
  call void @_3cfcntl_2eh_3e_2eF__SEAL__FUTURE__WRITE_2einit()
  br label %bb86
bb86:
  call void @_3cfcntl_2eh_3e_2eF__SEAL__EXEC_2einit()
  br label %bb87
bb87:
  call void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__NOT__SET_2einit()
  br label %bb88
bb88:
  call void @_3cfcntl_2eh_3e_2eRWF__WRITE__LIFE__NOT__SET_2einit()
  br label %bb89
bb89:
  call void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__NONE_2einit()
  br label %bb90
bb90:
  call void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__SHORT_2einit()
  br label %bb91
bb91:
  call void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__MEDIUM_2einit()
  br label %bb92
bb92:
  call void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__LONG_2einit()
  br label %bb93
bb93:
  call void @_3cfcntl_2eh_3e_2eRWH__WRITE__LIFE__EXTREME_2einit()
  br label %bb94
bb94:
  call void @_3cfcntl_2eh_3e_2eFAPPEND_2einit()
  br label %bb95
bb95:
  call void @_3cfcntl_2eh_3e_2eFFSYNC_2einit()
  br label %bb96
bb96:
  call void @_3cfcntl_2eh_3e_2eFASYNC_2einit()
  br label %bb97
bb97:
  call void @_3cfcntl_2eh_3e_2eFNONBLOCK_2einit()
  br label %bb98
bb98:
  call void @_3cfcntl_2eh_3e_2eFNDELAY_2einit()
  br label %bb99
bb99:
  call void @_3cfcntl_2eh_3e_2ePOSIX__FADV__NORMAL_2einit()
  br label %bb100
bb100:
  call void @_3cfcntl_2eh_3e_2ePOSIX__FADV__RANDOM_2einit()
  br label %bb101
bb101:
  call void @_3cfcntl_2eh_3e_2ePOSIX__FADV__SEQUENTIAL_2einit()
  br label %bb102
bb102:
  call void @_3cfcntl_2eh_3e_2ePOSIX__FADV__WILLNEED_2einit()
  br label %bb103
bb103:
  call void @_3cfcntl_2eh_3e_2ePOSIX__FADV__DONTNEED_2einit()
  br label %bb104
bb104:
  call void @_3cfcntl_2eh_3e_2ePOSIX__FADV__NOREUSE_2einit()
  br label %bb105
bb105:
  call void @_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WAIT__BEFORE_2einit()
  br label %bb106
bb106:
  call void @_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WRITE_2einit()
  br label %bb107
bb107:
  call void @_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WAIT__AFTER_2einit()
  br label %bb108
bb108:
  call void @_3cfcntl_2eh_3e_2eSYNC__FILE__RANGE__WRITE__AND__WAIT_2einit()
  br label %bb109
bb109:
  call void @_3cfcntl_2eh_3e_2eSPLICE__F__MOVE_2einit()
  br label %bb110
bb110:
  call void @_3cfcntl_2eh_3e_2eSPLICE__F__NONBLOCK_2einit()
  br label %bb111
bb111:
  call void @_3cfcntl_2eh_3e_2eSPLICE__F__MORE_2einit()
  br label %bb112
bb112:
  call void @_3cfcntl_2eh_3e_2eSPLICE__F__GIFT_2einit()
  br label %bb113
bb113:
  call void @_3cfcntl_2eh_3e_2eFALLOC__FL__ALLOCATE__RANGE_2einit()
  br label %bb114
bb114:
  call void @_3cfcntl_2eh_3e_2eFALLOC__FL__KEEP__SIZE_2einit()
  br label %bb115
bb115:
  call void @_3cfcntl_2eh_3e_2eFALLOC__FL__PUNCH__HOLE_2einit()
  br label %bb116
bb116:
  call void @_3cfcntl_2eh_3e_2eFALLOC__FL__NO__HIDE__STALE_2einit()
  br label %bb117
bb117:
  call void @_3cfcntl_2eh_3e_2eFALLOC__FL__COLLAPSE__RANGE_2einit()
  br label %bb118
bb118:
  call void @_3cfcntl_2eh_3e_2eFALLOC__FL__ZERO__RANGE_2einit()
  br label %bb119
bb119:
  call void @_3cfcntl_2eh_3e_2eFALLOC__FL__INSERT__RANGE_2einit()
  br label %bb120
bb120:
  call void @_3cfcntl_2eh_3e_2eFALLOC__FL__UNSHARE__RANGE_2einit()
  br label %bb121
bb121:
  call void @_3cfcntl_2eh_3e_2eMAX__HANDLE__SZ_2einit()
  br label %bb122
bb122:
  call void @_3cfcntl_2eh_3e_2eAT__HANDLE__FID_2einit()
  br label %bb123
bb123:
  call void @_3cfcntl_2eh_3e_2eUTIME__NOW_2einit()
  br label %bb124
bb124:
  call void @_3cfcntl_2eh_3e_2eUTIME__OMIT_2einit()
  br label %bb125
bb125:
  call void @_3cfcntl_2eh_3e_2eS__IFMT_2einit()
  br label %bb126
bb126:
  call void @_3cfcntl_2eh_3e_2eS__IFDIR_2einit()
  br label %bb127
bb127:
  call void @_3cfcntl_2eh_3e_2eS__IFCHR_2einit()
  br label %bb128
bb128:
  call void @_3cfcntl_2eh_3e_2eS__IFBLK_2einit()
  br label %bb129
bb129:
  call void @_3cfcntl_2eh_3e_2eS__IFREG_2einit()
  br label %bb130
bb130:
  call void @_3cfcntl_2eh_3e_2eS__IFIFO_2einit()
  br label %bb131
bb131:
  call void @_3cfcntl_2eh_3e_2eS__IFLNK_2einit()
  br label %bb132
bb132:
  call void @_3cfcntl_2eh_3e_2eS__IFSOCK_2einit()
  br label %bb133
bb133:
  call void @_3cfcntl_2eh_3e_2eS__ISUID_2einit()
  br label %bb134
bb134:
  call void @_3cfcntl_2eh_3e_2eS__ISGID_2einit()
  br label %bb135
bb135:
  call void @_3cfcntl_2eh_3e_2eS__ISVTX_2einit()
  br label %bb136
bb136:
  call void @_3cfcntl_2eh_3e_2eS__IRUSR_2einit()
  br label %bb137
bb137:
  call void @_3cfcntl_2eh_3e_2eS__IWUSR_2einit()
  br label %bb138
bb138:
  call void @_3cfcntl_2eh_3e_2eS__IXUSR_2einit()
  br label %bb139
bb139:
  call void @_3cfcntl_2eh_3e_2eS__IRWXU_2einit()
  br label %bb140
bb140:
  call void @_3cfcntl_2eh_3e_2eS__IRGRP_2einit()
  br label %bb141
bb141:
  call void @_3cfcntl_2eh_3e_2eS__IWGRP_2einit()
  br label %bb142
bb142:
  call void @_3cfcntl_2eh_3e_2eS__IXGRP_2einit()
  br label %bb143
bb143:
  call void @_3cfcntl_2eh_3e_2eS__IRWXG_2einit()
  br label %bb144
bb144:
  call void @_3cfcntl_2eh_3e_2eS__IROTH_2einit()
  br label %bb145
bb145:
  call void @_3cfcntl_2eh_3e_2eS__IWOTH_2einit()
  br label %bb146
bb146:
  call void @_3cfcntl_2eh_3e_2eS__IXOTH_2einit()
  br label %bb147
bb147:
  call void @_3cfcntl_2eh_3e_2eS__IRWXO_2einit()
  br label %bb148
bb148:
  call void @_3cfcntl_2eh_3e_2eR__OK_2einit()
  br label %bb149
bb149:
  call void @_3cfcntl_2eh_3e_2eW__OK_2einit()
  br label %bb150
bb150:
  call void @_3cfcntl_2eh_3e_2eX__OK_2einit()
  br label %bb151
bb151:
  call void @_3cfcntl_2eh_3e_2eF__OK_2einit()
  br label %bb152
bb152:
  call void @_3cfcntl_2eh_3e_2eSEEK__SET_2einit()
  br label %bb153
bb153:
  call void @_3cfcntl_2eh_3e_2eSEEK__CUR_2einit()
  br label %bb154
bb154:
  call void @_3cfcntl_2eh_3e_2eSEEK__END_2einit()
  br label %bb155
bb155:
  call void @_3cfcntl_2eh_3e_2eAT__FDCWD_2einit()
  br label %bb156
bb156:
  call void @_3cfcntl_2eh_3e_2eAT__SYMLINK__NOFOLLOW_2einit()
  br label %bb157
bb157:
  call void @_3cfcntl_2eh_3e_2eAT__REMOVEDIR_2einit()
  br label %bb158
bb158:
  call void @_3cfcntl_2eh_3e_2eAT__SYMLINK__FOLLOW_2einit()
  br label %bb159
bb159:
  call void @_3cfcntl_2eh_3e_2eAT__NO__AUTOMOUNT_2einit()
  br label %bb160
bb160:
  call void @_3cfcntl_2eh_3e_2eAT__EMPTY__PATH_2einit()
  br label %bb161
bb161:
  call void @_3cfcntl_2eh_3e_2eAT__STATX__SYNC__TYPE_2einit()
  br label %bb162
bb162:
  call void @_3cfcntl_2eh_3e_2eAT__STATX__SYNC__AS__STAT_2einit()
  br label %bb163
bb163:
  call void @_3cfcntl_2eh_3e_2eAT__STATX__FORCE__SYNC_2einit()
  br label %bb164
bb164:
  call void @_3cfcntl_2eh_3e_2eAT__STATX__DONT__SYNC_2einit()
  br label %bb165
bb165:
  call void @_3cfcntl_2eh_3e_2eAT__RECURSIVE_2einit()
  br label %bb166
bb166:
  call void @_3cfcntl_2eh_3e_2eAT__EACCESS_2einit()
  br label %bb167
bb167:
  call void @_3cfcntl_2eh_3e_2eF__ULOCK_2einit()
  br label %bb168
bb168:
  call void @_3cfcntl_2eh_3e_2eF__LOCK_2einit()
  br label %bb169
bb169:
  call void @_3cfcntl_2eh_3e_2eF__TLOCK_2einit()
  br label %bb170
bb170:
  call void @_3cfcntl_2eh_3e_2eF__TEST_2einit()
  br label %bb171
bb171:
  br label %ret
ret:
  ret void
}

define linkonce_odr %"<fcntl.h>:timespec" @olang_2eHelperKind_2eZero_2e_3cfcntl_2eh_3e_3atimespec() #0 {
entry:
  %l0 = alloca %"<fcntl.h>:timespec"
  %rv = alloca %"<fcntl.h>:timespec"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %t1)
  store %"<fcntl.h>:timespec" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<fcntl.h>:timespec", ptr %l0
  store %"<fcntl.h>:timespec" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<fcntl.h>:timespec", ptr %rv
  ret %"<fcntl.h>:timespec" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
