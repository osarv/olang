; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, { i64, ptr }, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/emit:laneTags" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range", i64, i64, %"compiler/mir:Range" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"compiler/emit:laneDotForm" = type { i64, i64, i64, i1, i1, i1, { i64, ptr }, %"compiler/emit:laneTags" }
define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i1 %a2, i64 %a3, i64 %a4, ptr %a5, i64 %a6, ptr %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca i1
  %l31 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l32 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l33 = alloca i64
  %l34 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca %"std/prelude/text:StringBuilder"
  %l52 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i64
  %l104 = alloca i64
  %l108 = alloca i1
  %l110 = alloca i1
  %l114 = alloca i1
  %l117 = alloca i1
  %l120 = alloca i64
  %l123 = alloca i1
  %l126 = alloca i1
  %l129 = alloca i64
  %l132 = alloca i1
  %l136 = alloca i64
  %l147 = alloca { i64, ptr }
  %l151 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l152 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l160 = alloca { i64, ptr }
  %l170 = alloca %"std/prelude/text:StringBuilder"
  %l171 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l172 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l174 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l176 = alloca i1
  %l180 = alloca i1
  %l183 = alloca i64
  %l188 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l189 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l191 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l192 = alloca i32
  %l194 = alloca i1
  %l195 = alloca ptr
  %l196 = alloca i64
  %l197 = alloca i64
  %l202 = alloca { i64, ptr }
  %l205 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l206 = alloca i64
  %l208 = alloca i64
  %l213 = alloca i64
  %l218 = alloca i1
  %l222 = alloca i1
  %l223 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i32
  %l232 = alloca i1
  %l236 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l238 = alloca i64
  %l239 = alloca i64
  %l250 = alloca i1
  %l252 = alloca i1
  %l255 = alloca i1
  %l259 = alloca ptr
  %l263 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l268 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l283 = alloca i64
  %l286 = alloca i64
  %l304 = alloca { i64, ptr }
  %l305 = alloca { i64, ptr }
  %l308 = alloca i64
  %l309 = alloca { i64, ptr }
  %l312 = alloca i64
  %l313 = alloca i64
  %l318 = alloca { i64, ptr }
  %l322 = alloca i64
  %l326 = alloca i64
  %l327 = alloca i32
  %l330 = alloca i1
  %l333 = alloca i1
  %l341 = alloca i64
  %l343 = alloca i1
  %l346 = alloca i64
  %l350 = alloca i64
  %l351 = alloca i32
  %l355 = alloca i1
  %l358 = alloca i1
  %l359 = alloca i1
  %l362 = alloca i1
  %l366 = alloca i64
  %l370 = alloca i1
  %l381 = alloca ptr
  %l382 = alloca i64
  %l383 = alloca i64
  %l388 = alloca { i64, ptr }
  %l389 = alloca { i64, ptr }
  %l398 = alloca ptr
  %l402 = alloca { i64, ptr }
  %l403 = alloca ptr
  %l407 = alloca { i64, ptr }
  %l413 = alloca i1
  %l417 = alloca ptr
  %l418 = alloca i64
  %l423 = alloca { i64, ptr }
  %l429 = alloca i1
  %l438 = alloca %"std/prelude/text:StringBuilder"
  %l439 = alloca ptr
  %l441 = alloca { i64, ptr }
  %l447 = alloca i64
  %l449 = alloca i64
  %l454 = alloca i64
  %l455 = alloca ptr
  %l459 = alloca { i64, ptr }
  %l463 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l465 = alloca i64
  %l467 = alloca i64
  %l472 = alloca i64
  %l474 = alloca i1
  %l478 = alloca i1
  %l479 = alloca i64
  %l483 = alloca i64
  %l484 = alloca i32
  %l488 = alloca i1
  %l490 = alloca ptr
  %l491 = alloca { i64, ptr }
  %l494 = alloca { i64, ptr }
  %l495 = alloca i32
  %l496 = alloca { i64, ptr }
  %l500 = alloca { i64, ptr }
  %l501 = alloca i32
  %l502 = alloca ptr
  %l506 = alloca { i64, ptr }
  %l507 = alloca { i64, ptr }
  %l511 = alloca { i64, ptr }
  %l517 = alloca { i64, ptr }
  %l519 = alloca i64
  %l521 = alloca i1
  %l523 = alloca i1
  %l529 = alloca { i64, ptr }
  %l535 = alloca i64
  %l538 = alloca i64
  %l556 = alloca { i64, ptr }
  %l560 = alloca i64
  %l561 = alloca { i64, ptr }
  %l562 = alloca { i64, ptr }
  %l566 = alloca i64
  %l567 = alloca { i64, ptr }
  %l570 = alloca i64
  %l571 = alloca i64
  %l575 = alloca { i64, ptr }
  %l576 = alloca i64
  %l577 = alloca i32
  %l578 = alloca i64
  %l579 = alloca i32
  %l582 = alloca ptr
  %l583 = alloca { i64, ptr }
  %l584 = alloca i64
  %l585 = alloca { i64, ptr }
  %l588 = alloca i64
  %l589 = alloca i64
  %l594 = alloca ptr
  %l597 = alloca i64
  %l600 = alloca { i64, ptr }
  %l604 = alloca { i64, ptr }
  %l608 = alloca { i64, ptr }
  %l609 = alloca { i64, ptr }
  %l612 = alloca i64
  %l613 = alloca { i64, ptr }
  %l616 = alloca i64
  %l617 = alloca i64
  %l624 = alloca i64
  %l627 = alloca i1
  %l630 = alloca i1
  %l632 = alloca ptr
  %l633 = alloca { i64, ptr }
  %l634 = alloca i64
  %l635 = alloca { i64, ptr }
  %l638 = alloca i64
  %l639 = alloca i64
  %l644 = alloca ptr
  %l645 = alloca { i64, ptr }
  %l648 = alloca { i64, ptr }
  %l649 = alloca i32
  %l650 = alloca ptr
  %l651 = alloca { i64, ptr }
  %l655 = alloca { i64, ptr }
  %l656 = alloca i64
  %l659 = alloca i64
  %l660 = alloca i64
  %l665 = alloca { i64, ptr }
  %l672 = alloca ptr
  %l673 = alloca { i64, ptr }
  %l674 = alloca i64
  %l677 = alloca i64
  %l678 = alloca i64
  %l686 = alloca ptr
  %l688 = alloca { i64, ptr }
  %l693 = alloca i1
  %l697 = alloca i1
  %l698 = alloca ptr
  %l702 = alloca i64
  %l703 = alloca { i64, ptr }
  %l705 = alloca ptr
  %l707 = alloca { i64, ptr }
  %l710 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t143 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a5, ptr %l5
  store i64 %a6, ptr %l6
  store ptr %a7, ptr %l7
  store i64 %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l73
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:Emitter", ptr %t3, i32 0, i32 22
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l76
  br label %bb2
bb2:
  %t8 = load i64, ptr %l76, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l12, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l10, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l12, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l12, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l83, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l83, !tbaa !24
  store i64 %t35, ptr %l80, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l80, !tbaa !24
  store i64 %t36, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l14, !tbaa !24
  %t38 = load i64, ptr %l13, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb43
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l14, !tbaa !24
  %t47 = load i64, ptr %l12, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l15, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/emit:Emitter", ptr %t55, i32 0, i32 24
  %t58 = load i64, ptr %l15, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l104
  br label %bb13
bb13:
  %t62 = load i64, ptr %l104, !tbaa !24
  store i64 %t62, ptr %l16, !tbaa !24
  %t63 = load i64, ptr %l16, !tbaa !24
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb19
bb15:
  %t69 = load i1, ptr %l2, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = load i64, ptr %l16, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t75 = icmp eq i64 %t71, %t72
  store i1 %t75, ptr %l110, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l110, !tbaa !21
  store i1 %t77, ptr %l108, !tbaa !21
  br label %bb19
bb19:
  %t78 = load i1, ptr %l108, !tbaa !21
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb26
bb22:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb25
bb23:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l15, !tbaa !24
  %t87 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l120
  br label %bb24
bb24:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l120, !tbaa !24
  %t91 = icmp eq i64 %t89, %t88
  store i1 %t91, ptr %l117, !tbaa !21
  br label %bb25
bb25:
  %t93 = load i1, ptr %l117, !tbaa !21
  store i1 %t93, ptr %l114, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l114, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb33
bb29:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb32
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i64, ptr %l15, !tbaa !24
  %t103 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t99, i64 %t100)
  store i64 %t103, ptr %l129
  br label %bb31
bb31:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l129, !tbaa !24
  %t107 = icmp eq i64 %t105, %t104
  store i1 %t107, ptr %l126, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l126, !tbaa !21
  store i1 %t109, ptr %l123, !tbaa !21
  br label %bb33
bb33:
  %t110 = load i1, ptr %l123, !tbaa !21
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i64, ptr %l15, !tbaa !24
  %t117 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epartOf(ptr %v0, ptr %t111, i64 %t112, i64 %a4)
  store i64 %t117, ptr %l136
  br label %bb36
bb35:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb37
bb36:
  %t119 = load i64, ptr %l136, !tbaa !24
  %t121 = icmp eq i64 %t119, %a3
  store i1 %t121, ptr %l132, !tbaa !21
  br label %bb37
bb37:
  %t123 = load i1, ptr %l132, !tbaa !21
  br i1 %t123, label %bb38, label %bb39
bb38:
  %t124 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t124)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l14, !tbaa !24
  br label %bb9
bb43:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/emit:Emitter", ptr %t132, i32 0, i32 22
  store ptr %t134, ptr %l17, !tbaa !29
  %t137 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t137, ptr %l147
  br label %bb44
bb44:
  %t138 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t138, ptr %l18, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t140 = load ptr, ptr %l17, !tbaa !29
  %t141 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t142 = ptrtoint ptr %t141 to i64
  %t144 = getelementptr { ptr, ptr }, ptr %t143, i32 0, i32 0
  store ptr %t140, ptr %t144, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t146 = call ptr @__olang_scope_hold(ptr %v0)
  %t147 = getelementptr { ptr, ptr }, ptr %t143, i32 0, i32 1
  store ptr %t146, ptr %t147, !tbaa !28
  %t148 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t149 = insertvalue { ptr, ptr } %t148, ptr %t143, 1
  %t152 = extractvalue { ptr, ptr } %t149, 0
  %t153 = extractvalue { ptr, ptr } %t149, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t139, ptr %t152, ptr %t153)
  br label %bb45
bb45:
  %t154 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l151
  br label %bb46
bb46:
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l151
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %l19
  %t156 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t156, ptr %l152
  br label %bb47
bb47:
  %t157 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l152
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t157, ptr %l20
  %t158 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t158, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  %t164 = load i64, ptr %l22, !tbaa !24
  %t165 = load i64, ptr %l23, !tbaa !24
  %t168 = icmp slt i64 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb49, label %bb50
bb49:
  br label %bb55
bb50:
  br label %bb51
bb51:
  %t172 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t172, ptr %l160, !tbaa !27
  %t173 = load i64, ptr %l22, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i64, ptr %t176, i64 %t173
  %t178 = load i64, ptr %t177, !tbaa !34
  store i64 %t178, ptr %l24, !tbaa !24
  %t180 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l19, i64 %t180)
  br label %bb52
bb52:
  %t183 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20, i64 %t183, i1 true)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t186 = load i64, ptr %l22, !tbaa !24
  %t189 = add i64 %t186, 1
  store i64 %t189, ptr %l22, !tbaa !24
  br label %bb48
bb55:
  %t191 = call %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t191, ptr %l170
  br label %bb56
bb56:
  %t192 = load %"std/prelude/text:StringBuilder", ptr %l170
  store %"std/prelude/text:StringBuilder" %t192, ptr %l25
  %t193 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t193, ptr %l171
  br label %bb57
bb57:
  %t194 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l171
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t194, ptr %l26
  %t195 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t195, ptr %l172
  br label %bb58
bb58:
  %t196 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l172
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %l27
  %t197 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t197, ptr %l173
  br label %bb59
bb59:
  %t198 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t198, ptr %l28
  %t199 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t199, ptr %l174
  br label %bb60
bb60:
  %t200 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t200, ptr %l29
  %t201 = load i1, ptr %l2, !tbaa !21
  br i1 %t201, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb63
bb62:
  %t203 = load i64, ptr %l1, !tbaa !24
  %t204 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t207 = icmp eq i64 %t203, %t204
  store i1 %t207, ptr %l176, !tbaa !21
  br label %bb63
bb63:
  %t209 = load i1, ptr %l176, !tbaa !21
  br i1 %t209, label %bb64, label %bb65
bb64:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/emit:Emitter", ptr %t210, i32 0, i32 85
  %t214 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t212)
  store i64 %t214, ptr %l183
  br label %bb66
bb65:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb67
bb66:
  %t215 = load i64, ptr %l183, !tbaa !24
  %t216 = icmp sgt i64 %t215, 0
  store i1 %t216, ptr %l180, !tbaa !21
  br label %bb67
bb67:
  %t218 = load i1, ptr %l180, !tbaa !21
  store i1 %t218, ptr %l30, !tbaa !21
  %t219 = load i1, ptr %l30, !tbaa !21
  br i1 %t219, label %bb68, label %bb69
bb68:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/emit:Emitter", ptr %t221, i32 0, i32 85
  %t225 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t223)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t225, ptr %l188
  br label %bb70
bb69:
  br label %bb82
bb70:
  %t226 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l188
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t226, ptr %l31
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s10
  %t228 = call { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %l31)
  %t229 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t228, 1
  %t230 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t228, 0
  store i32 %t230, ptr %l192
  %t231 = icmp ne i32 %t230, 0
  br i1 %t231, label %bb73, label %ok.232, !prof !99
ok.232:
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t229, ptr %l191
  br label %bb72
bb72:
  %t233 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l191
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t233, ptr %l189
  br label %bb75
bb73:
  %t234 = load i32, ptr %l192, !tbaa !23
  %t235 = ashr i32 %t234, 16
  %t237 = icmp eq i32 %t235, 1
  store i1 %t237, ptr %l194, !tbaa !21
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb81
bb75:
  %t238 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l189
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t238, ptr %l32
  store ptr %l29, ptr %l195, !tbaa !29
  %t239 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l32, i32 0, i32 0
  %t240 = load i64, ptr %t239, !tbaa !24
  store i64 %t240, ptr %l196, !tbaa !24
  %t241 = call ptr @__olang_scope_hold(ptr %s0)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l197, !tbaa !24
  %t243 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1
  br i1 %t243, label %bb76, label %bb77
bb76:
  %t245 = call ptr @__olang_region_make(ptr %s0)
  %t246 = ptrtoint ptr %t245 to i64
  store i64 %t246, ptr %l197, !tbaa !24
  br label %bb77
bb77:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/emit:Emitter", ptr %t247, i32 0, i32 22
  %t250 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l32, i32 0, i32 1
  %t251 = load i64, ptr %t250, !tbaa !24
  %t254 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s10, ptr %t249, i64 %t251)
  store { i64, ptr } %t254, ptr %l202
  br label %bb78
bb78:
  %t255 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = load i64, ptr %l197
  %t259 = inttoptr i64 %t258 to ptr
  %t260 = call ptr @__olang_held_alloc(ptr %t259, i64 %t257)
  call void @olang_textcopy(ptr %t260, ptr %t256, i64 %t257)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t264 = load ptr, ptr %l195, !tbaa !29
  %t265 = load i64, ptr %l196, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %s0, ptr %s0, ptr %t264, i64 %t265, { i64, ptr } %t262)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s10)
  br label %bb80
bb80:
  br label %bb71
bb81:
  br label %bb82
bb82:
  store i64 0, ptr %l33, !tbaa !24
  %t267 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t267, ptr %l205
  br label %bb83
bb83:
  %t268 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l205
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t268, ptr %l34
  store i64 0, ptr %l35, !tbaa !24
  br label %bb84
bb84:
  %t269 = load i64, ptr %l35, !tbaa !24
  store i64 %t269, ptr %l206, !tbaa !24
  %t271 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t271, ptr %l208
  br label %bb85
bb85:
  %t272 = load i64, ptr %l206, !tbaa !24
  %t273 = load i64, ptr %l208, !tbaa !24
  %t274 = icmp slt i64 %t272, %t273
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb86, label %bb87
bb86:
  br label %bb220
bb87:
  br label %bb88
bb88:
  %t278 = load i64, ptr %l35, !tbaa !24
  %t281 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t278)
  store i64 %t281, ptr %l213
  br label %bb89
bb89:
  %t282 = load i64, ptr %l213, !tbaa !24
  store i64 %t282, ptr %l36, !tbaa !24
  %t283 = load i64, ptr %l35, !tbaa !24
  %t286 = add i64 %t283, 1
  store i64 %t286, ptr %l35, !tbaa !24
  %t288 = load i1, ptr %l30, !tbaa !21
  br i1 %t288, label %bb90, label %bb91
bb90:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/emit:Emitter", ptr %t290, i32 0, i32 85
  %t293 = load i64, ptr %l36, !tbaa !24
  %t296 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t292, i64 %t293)
  store i1 %t296, ptr %l222
  br label %bb92
bb91:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb93
bb92:
  %t297 = load i1, ptr %l222, !tbaa !21
  store i1 %t297, ptr %l218, !tbaa !21
  br label %bb93
bb93:
  %t298 = load i1, ptr %l218, !tbaa !21
  br i1 %t298, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s13
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/emit:Emitter", ptr %t299, i32 0, i32 85
  %t302 = load i64, ptr %l36, !tbaa !24
  %t305 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t301, i64 %t302)
  %t306 = extractvalue { i32, i64 } %t305, 1
  %t307 = extractvalue { i32, i64 } %t305, 0
  store i32 %t307, ptr %l228
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb97, label %ok.309, !prof !99
ok.309:
  store i64 %t306, ptr %l227
  br label %bb96
bb95:
  br label %bb122
bb96:
  %t310 = load i64, ptr %l227, !tbaa !24
  store i64 %t310, ptr %l223, !tbaa !24
  br label %bb99
bb97:
  br label %bb98
bb98:
  %t311 = load i64, ptr %l36, !tbaa !24
  store i64 %t311, ptr %l223, !tbaa !24
  br label %bb99
bb99:
  %t313 = load i64, ptr %l223, !tbaa !24
  store i64 %t313, ptr %l37, !tbaa !24
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load i64, ptr %l36, !tbaa !24
  %t318 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %t314, i64 %t315)
  store i1 %t318, ptr %l232
  br label %bb100
bb100:
  %t319 = load i1, ptr %l232, !tbaa !21
  br i1 %t319, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s13)
  br label %bb219
bb102:
  br label %bb103
bb103:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i64, ptr %l36, !tbaa !24
  %t322 = load i64, ptr %l37, !tbaa !24
  %t326 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewrapper(ptr %v0, ptr %s13, ptr %t320, i64 %t321, i64 %t322)
  store { i64, ptr } %t326, ptr %l236
  br label %bb104
bb104:
  %t327 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t327, ptr %l38, !tbaa !27
  store ptr %l34, ptr %l237, !tbaa !29
  %t328 = load i64, ptr %l36, !tbaa !24
  store i64 %t328, ptr %l238, !tbaa !24
  %t329 = call ptr @__olang_scope_hold(ptr %s0)
  %t330 = ptrtoint ptr %t329 to i64
  store i64 %t330, ptr %l239, !tbaa !24
  %t331 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1
  br i1 %t331, label %bb105, label %bb106
bb105:
  %t333 = call ptr @__olang_region_make(ptr %s0)
  %t334 = ptrtoint ptr %t333 to i64
  store i64 %t334, ptr %l239, !tbaa !24
  br label %bb106
bb106:
  %t335 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = extractvalue { i64, ptr } %t335, 0
  %t339 = load i64, ptr %l239
  %t340 = inttoptr i64 %t339 to ptr
  %t341 = call ptr @__olang_held_alloc(ptr %t340, i64 %t338)
  call void @olang_textcopy(ptr %t341, ptr %t337, i64 %t338)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  %t345 = load ptr, ptr %l237, !tbaa !29
  %t346 = load i64, ptr %l238, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %s0, ptr %s0, ptr %t345, i64 %t346, { i64, ptr } %t343)
  br label %bb107
bb107:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypesNamedIn(ptr %v0, ptr %s13, ptr %s0, ptr %s0, ptr %t348, { i64, ptr } %t349, ptr %l27, ptr %l28)
  br label %bb108
bb108:
  %t354 = load i64, ptr %l37, !tbaa !24
  %t357 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20, i64 %t354)
  store i1 %t357, ptr %l250
  br label %bb109
bb109:
  %t358 = load i1, ptr %l250, !tbaa !21
  %t359 = xor i1 %t358, true
  br i1 %t359, label %bb110, label %bb111
bb110:
  %t361 = load i64, ptr %l37, !tbaa !24
  %t364 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l26, i64 %t361)
  store i1 %t364, ptr %l255
  br label %bb112
bb111:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb113
bb112:
  %t365 = load i1, ptr %l255, !tbaa !21
  %t366 = xor i1 %t365, true
  store i1 %t366, ptr %l252, !tbaa !21
  br label %bb113
bb113:
  %t368 = load i1, ptr %l252, !tbaa !21
  br i1 %t368, label %bb114, label %bb115
bb114:
  %t369 = load i64, ptr %l37, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l26, i64 %t369, i1 true)
  br label %bb116
bb115:
  br label %bb121
bb116:
  store ptr %l25, ptr %l259, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/emit:Emitter", ptr %t372, i32 0, i32 25
  %t375 = load i64, ptr %l37, !tbaa !24
  %t378 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t374, i64 %t375)
  store { i64, ptr } %t378, ptr %l263
  br label %bb117
bb117:
  %t379 = load ptr, ptr %l259, !tbaa !29
  %t380 = load { i64, ptr }, ptr %l263, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t379, { i64, ptr } %t380)
  br label %bb118
bb118:
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l264, !tbaa !29
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/emit:Emitter", ptr %t382, i32 0, i32 25
  %t385 = load i64, ptr %l37, !tbaa !24
  %t388 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t384, i64 %t385)
  store { i64, ptr } %t388, ptr %l268
  br label %bb119
bb119:
  %t389 = load ptr, ptr %l264, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l268, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclTypes(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t389, { i64, ptr } %t390, ptr %l27, ptr %l28)
  br label %bb120
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s13)
  br label %bb219
bb122:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = getelementptr %"compiler/emit:Emitter", ptr %t393, i32 0, i32 23
  %t396 = load i64, ptr %l36, !tbaa !24
  %t399 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t395, i64 %t396)
  store { i64, ptr } %t399, ptr %l274
  br label %bb123
bb123:
  %t400 = load { i64, ptr }, ptr %l274, !tbaa !27
  store { i64, ptr } %t400, ptr %l39, !tbaa !27
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i64, ptr %l36, !tbaa !24
  %t405 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %v0, ptr %t401, i64 %t402)
  store { i64, ptr } %t405, ptr %l277
  br label %bb124
bb124:
  %t406 = load { i64, ptr }, ptr %l277, !tbaa !27
  store { i64, ptr } %t406, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t407 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t407, 0
  store i64 %t409, ptr %l42, !tbaa !24
  store i64 3, ptr %l43, !tbaa !24
  %t411 = load i64, ptr %l42, !tbaa !24
  %t412 = load i64, ptr %l41, !tbaa !24
  %t415 = icmp sgt i64 %t411, %t412
  br i1 %t415, label %bb125, label %bb126
bb125:
  %t417 = load i64, ptr %l43, !tbaa !24
  %t419 = icmp sgt i64 %t417, 0
  br i1 %t419, label %bb127, label %bb128
bb126:
  store i64 0, ptr %l283, !tbaa !24
  br label %bb130
bb127:
  %t421 = load i64, ptr %l42, !tbaa !24
  %t422 = load i64, ptr %l41, !tbaa !24
  %t425 = sub i64 %t421, %t422
  %t426 = load i64, ptr %l43, !tbaa !24
  %t429 = add i64 %t425, %t426
  %t431 = sub i64 %t429, 1
  %t432 = load i64, ptr %l43, !tbaa !24
  %t435 = sdiv i64 %t431, %t432
  store i64 %t435, ptr %l286, !tbaa !24
  br label %bb129
bb128:
  store i64 0, ptr %l286, !tbaa !24
  br label %bb129
bb129:
  %t437 = load i64, ptr %l286, !tbaa !24
  store i64 %t437, ptr %l283, !tbaa !24
  br label %bb130
bb130:
  %t438 = load i64, ptr %l283, !tbaa !24
  store i64 %t438, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb131
bb131:
  %t439 = load i64, ptr %l45, !tbaa !24
  %t440 = load i64, ptr %l44, !tbaa !24
  %t443 = icmp slt i64 %t439, %t440
  %t445 = xor i1 %t443, true
  br i1 %t445, label %bb132, label %bb133
bb132:
  br label %bb218
bb133:
  br label %bb134
bb134:
  %t447 = load i64, ptr %l41, !tbaa !24
  %t448 = load i64, ptr %l45, !tbaa !24
  %t449 = load i64, ptr %l43, !tbaa !24
  %t452 = mul i64 %t448, %t449
  %t455 = add i64 %t447, %t452
  store i64 %t455, ptr %l46, !tbaa !24
  %t457 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t457, ptr %l304, !tbaa !27
  %t458 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t458, ptr %l305, !tbaa !27
  %t459 = load i64, ptr %l46, !tbaa !24
  %t461 = add i64 %t459, 1
  %t463 = getelementptr { i64, ptr }, ptr %l305, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr i64, ptr %t464, i64 %t461
  %t466 = load i64, ptr %t465, !tbaa !34
  store i64 %t466, ptr %l308, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t467, ptr %l309, !tbaa !27
  %t468 = load i64, ptr %l46, !tbaa !24
  %t470 = add i64 %t468, 2
  %t472 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !27
  %t474 = getelementptr i64, ptr %t473, i64 %t470
  %t475 = load i64, ptr %t474, !tbaa !34
  store i64 %t475, ptr %l312, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 0
  store i64 %t477, ptr %l313, !tbaa !24
  %t478 = load i64, ptr %l308, !tbaa !24
  %t479 = icmp sge i64 %t478, 0
  br i1 %t479, label %bb135, label %bb136
bb135:
  %t481 = load i64, ptr %l308, !tbaa !24
  %t482 = load i64, ptr %l312, !tbaa !24
  %t483 = icmp sle i64 %t481, %t482
  br i1 %t483, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_ad9436b5748221a9_385739db7a2b20ed)
  unreachable
bb137:
  %t485 = load i64, ptr %l312, !tbaa !24
  %t486 = load i64, ptr %l313, !tbaa !24
  %t487 = icmp sle i64 %t485, %t486
  br i1 %t487, label %bb139, label %bb140
bb138:
  call void @__olang_check_failed(ptr @olang_loc_ad9436b5748221a9_385739db7a2b20ed)
  unreachable
bb139:
  %t489 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = load i64, ptr %l308, !tbaa !24
  %t492 = load i64, ptr %l312, !tbaa !24
  %t493 = getelementptr i8, ptr %t490, i64 %t491
  %t494 = sub i64 %t492, %t491
  %t495 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t493, 1
  store { i64, ptr } %t496, ptr %l47, !tbaa !27
  %t498 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t498, ptr %l318, !tbaa !27
  %t499 = load i64, ptr %l46, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l318, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr i64, ptr %t502, i64 %t499
  %t504 = load i64, ptr %t503, !tbaa !34
  %t506 = icmp eq i64 %t504, 1
  br i1 %t506, label %bb141, label %bb142
bb140:
  call void @__olang_check_failed(ptr @olang_loc_ad9436b5748221a9_385739db7a2b20ed)
  unreachable
bb141:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = getelementptr %"compiler/emit:Emitter", ptr %t508, i32 0, i32 60
  %t511 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t514 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t510, { i64, ptr } %t511)
  %t515 = extractvalue { i32, i64 } %t514, 1
  %t516 = extractvalue { i32, i64 } %t514, 0
  store i32 %t516, ptr %l327
  %t517 = icmp ne i32 %t516, 0
  br i1 %t517, label %bb144, label %ok.518, !prof !99
ok.518:
  store i64 %t515, ptr %l326
  br label %bb143
bb142:
  br label %bb155
bb143:
  %t519 = load i64, ptr %l326, !tbaa !24
  store i64 %t519, ptr %l322, !tbaa !24
  br label %bb146
bb144:
  br label %bb145
bb145:
  store i64 -1, ptr %l322, !tbaa !24
  br label %bb146
bb146:
  %t520 = load i64, ptr %l322, !tbaa !24
  store i64 %t520, ptr %l48, !tbaa !24
  %t521 = load i64, ptr %l48, !tbaa !24
  %t523 = icmp sge i64 %t521, 0
  br i1 %t523, label %bb147, label %bb148
bb147:
  %t525 = load i64, ptr %l48, !tbaa !24
  %t528 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l28, i64 %t525)
  store i1 %t528, ptr %l333
  br label %bb149
bb148:
  store i1 false, ptr %l330, !tbaa !21
  br label %bb150
bb149:
  %t529 = load i1, ptr %l333, !tbaa !21
  %t530 = xor i1 %t529, true
  store i1 %t530, ptr %l330, !tbaa !21
  br label %bb150
bb150:
  %t532 = load i1, ptr %l330, !tbaa !21
  br i1 %t532, label %bb151, label %bb152
bb151:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i64, ptr %l48, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %s0, ptr %s0, ptr %t533, i64 %t534, ptr %l27, ptr %l28)
  br label %bb153
bb152:
  br label %bb154
bb153:
  br label %bb154
bb154:
  br label %bb217
bb155:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t543 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitemNamed(ptr %v0, ptr %v0, ptr %t539, { i64, ptr } %t540)
  store i64 %t543, ptr %l341
  br label %bb156
bb156:
  %t544 = load i64, ptr %l341, !tbaa !24
  store i64 %t544, ptr %l49, !tbaa !24
  %t545 = load i1, ptr %l30, !tbaa !21
  br i1 %t545, label %bb157, label %bb158
bb157:
  %t547 = load i64, ptr %l49, !tbaa !24
  %t549 = icmp sge i64 %t547, 0
  store i1 %t549, ptr %l343, !tbaa !21
  br label %bb159
bb158:
  store i1 false, ptr %l343, !tbaa !21
  br label %bb159
bb159:
  %t551 = load i1, ptr %l343, !tbaa !21
  br i1 %t551, label %bb160, label %bb161
bb160:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t554 = getelementptr %"compiler/emit:Emitter", ptr %t552, i32 0, i32 85
  %t555 = load i64, ptr %l49, !tbaa !24
  %t558 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t554, i64 %t555)
  %t559 = extractvalue { i32, i64 } %t558, 1
  %t560 = extractvalue { i32, i64 } %t558, 0
  store i32 %t560, ptr %l351
  %t561 = icmp ne i32 %t560, 0
  br i1 %t561, label %bb163, label %ok.562, !prof !99
ok.562:
  store i64 %t559, ptr %l350
  br label %bb162
bb161:
  br label %bb166
bb162:
  %t563 = load i64, ptr %l350, !tbaa !24
  store i64 %t563, ptr %l346, !tbaa !24
  br label %bb165
bb163:
  br label %bb164
bb164:
  %t564 = load i64, ptr %l49, !tbaa !24
  store i64 %t564, ptr %l346, !tbaa !24
  br label %bb165
bb165:
  %t566 = load i64, ptr %l346, !tbaa !24
  store i64 %t566, ptr %l49, !tbaa !24
  br label %bb166
bb166:
  %t567 = load i64, ptr %l49, !tbaa !24
  %t569 = icmp slt i64 %t567, 0
  br i1 %t569, label %bb167, label %bb168
bb167:
  store i1 true, ptr %l355, !tbaa !21
  br label %bb170
bb168:
  %t571 = load i64, ptr %l49, !tbaa !24
  %t574 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20, i64 %t571)
  store i1 %t574, ptr %l358
  br label %bb169
bb169:
  %t575 = load i1, ptr %l358, !tbaa !21
  store i1 %t575, ptr %l355, !tbaa !21
  br label %bb170
bb170:
  %t576 = load i1, ptr %l355, !tbaa !21
  br i1 %t576, label %bb171, label %bb172
bb171:
  store i1 true, ptr %l359, !tbaa !21
  br label %bb174
bb172:
  %t577 = load i64, ptr %l49, !tbaa !24
  %t580 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l26, i64 %t577)
  store i1 %t580, ptr %l362
  br label %bb173
bb173:
  %t581 = load i1, ptr %l362, !tbaa !21
  store i1 %t581, ptr %l359, !tbaa !21
  br label %bb174
bb174:
  %t582 = load i1, ptr %l359, !tbaa !21
  br i1 %t582, label %bb175, label %bb176
bb175:
  br label %bb217
bb176:
  br label %bb177
bb177:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t585 = getelementptr %"compiler/emit:Emitter", ptr %t583, i32 0, i32 24
  %t586 = load i64, ptr %l49, !tbaa !24
  %t589 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t585, i64 %t586)
  store i64 %t589, ptr %l366
  br label %bb178
bb178:
  %t590 = load i64, ptr %l366, !tbaa !24
  store i64 %t590, ptr %l50, !tbaa !24
  %t591 = load i64, ptr %l50, !tbaa !24
  %t592 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t595 = icmp eq i64 %t591, %t592
  br i1 %t595, label %bb179, label %bb180
bb179:
  store i1 true, ptr %l370, !tbaa !21
  br label %bb181
bb180:
  %t597 = load i64, ptr %l50, !tbaa !24
  %t598 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  %t601 = icmp eq i64 %t597, %t598
  store i1 %t601, ptr %l370, !tbaa !21
  br label %bb181
bb181:
  %t603 = load i1, ptr %l370, !tbaa !21
  br i1 %t603, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s23
  %t604 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20, i64 %t604, i1 true)
  br label %bb184
bb183:
  br label %bb194
bb184:
  %t607 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l19, i64 %t607)
  br label %bb185
bb185:
  %t610 = load i64, ptr %l50, !tbaa !24
  %t611 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  %t614 = icmp ne i64 %t610, %t611
  br i1 %t614, label %bb186, label %bb187
bb186:
  call void @__olang_scope_close(ptr %s23)
  br label %bb217
bb187:
  br label %bb188
bb188:
  store ptr %l29, ptr %l381, !tbaa !29
  %t616 = load i64, ptr %l49, !tbaa !24
  store i64 %t616, ptr %l382, !tbaa !24
  %t617 = call ptr @__olang_scope_hold(ptr %s0)
  %t618 = ptrtoint ptr %t617 to i64
  store i64 %t618, ptr %l383, !tbaa !24
  %t619 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1
  br i1 %t619, label %bb189, label %bb190
bb189:
  %t621 = call ptr @__olang_region_make(ptr %s0)
  %t622 = ptrtoint ptr %t621 to i64
  store i64 %t622, ptr %l383, !tbaa !24
  br label %bb190
bb190:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = getelementptr %"compiler/emit:Emitter", ptr %t623, i32 0, i32 22
  %t626 = load i64, ptr %l49, !tbaa !24
  %t629 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t625, i64 %t626)
  store { i64, ptr } %t629, ptr %l388
  br label %bb191
bb191:
  %t630 = load { i64, ptr }, ptr %l388, !tbaa !27
  %t631 = call { i64, ptr } @compiler_2femit_2eprefixOf(ptr %v0, ptr %s23, { i64, ptr } %t630)
  store { i64, ptr } %t631, ptr %l389
  br label %bb192
bb192:
  %t632 = load i64, ptr %l33, !tbaa !24
  %t633 = load { i64, ptr }, ptr %l389, !tbaa !27
  %t634 = extractvalue { i64, ptr } %t633, 1
  %t635 = extractvalue { i64, ptr } %t633, 0
  %t637 = call i64 @__olang_fmt_i64(ptr null, i64 %t632)
  %t638 = add i64 %t635, %t637
  %t639 = load i64, ptr %l383
  %t640 = inttoptr i64 %t639 to ptr
  %t641 = call ptr @__olang_held_alloc(ptr %t640, i64 %t638)
  call void @olang_textcopy(ptr %t641, ptr %t634, i64 %t635)
  %t642 = getelementptr i8, ptr %t641, i64 %t635
  %t643 = call i64 @__olang_fmt_i64(ptr %t642, i64 %t632)
  %t644 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t645 = insertvalue { i64, ptr } %t644, ptr %t641, 1
  %t647 = load ptr, ptr %l381, !tbaa !29
  %t648 = load i64, ptr %l382, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %s0, ptr %s0, ptr %t647, i64 %t648, { i64, ptr } %t645)
  br label %bb193
bb193:
  %t650 = load i64, ptr %l33, !tbaa !24
  %t653 = add i64 %t650, 1
  store i64 %t653, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb217
bb194:
  %t655 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l26, i64 %t655, i1 true)
  br label %bb195
bb195:
  store ptr %l25, ptr %l398, !tbaa !29
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr %"compiler/emit:Emitter", ptr %t658, i32 0, i32 25
  %t661 = load i64, ptr %l49, !tbaa !24
  %t664 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t660, i64 %t661)
  store { i64, ptr } %t664, ptr %l402
  br label %bb196
bb196:
  %t665 = load ptr, ptr %l398, !tbaa !29
  %t666 = load { i64, ptr }, ptr %l402, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t665, { i64, ptr } %t666)
  br label %bb197
bb197:
  %t667 = load ptr, ptr %l0, !tbaa !29
  store ptr %t667, ptr %l403, !tbaa !29
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t670 = getelementptr %"compiler/emit:Emitter", ptr %t668, i32 0, i32 25
  %t671 = load i64, ptr %l49, !tbaa !24
  %t674 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t670, i64 %t671)
  store { i64, ptr } %t674, ptr %l407
  br label %bb198
bb198:
  %t675 = load ptr, ptr %l403, !tbaa !29
  %t676 = load { i64, ptr }, ptr %l407, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclTypes(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t675, { i64, ptr } %t676, ptr %l27, ptr %l28)
  br label %bb199
bb199:
  %t679 = load i64, ptr %l50, !tbaa !24
  %t680 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t683 = icmp eq i64 %t679, %t680
  br i1 %t683, label %bb200, label %bb201
bb200:
  %t685 = load ptr, ptr %l5, !tbaa !29
  %t687 = icmp eq ptr %t685, null
  %t689 = xor i1 %t687, true
  store i1 %t689, ptr %l413, !tbaa !21
  br label %bb202
bb201:
  store i1 false, ptr %l413, !tbaa !21
  br label %bb202
bb202:
  %t691 = load i1, ptr %l413, !tbaa !21
  br i1 %t691, label %bb203, label %bb204
bb203:
  store %olang.scope zeroinitializer, ptr %s26
  %t692 = load ptr, ptr %l5, !tbaa !29
  store ptr %t692, ptr %l417, !tbaa !29
  %t693 = call ptr @__olang_scope_hold(ptr %v1)
  %t694 = ptrtoint ptr %t693 to i64
  store i64 %t694, ptr %l418, !tbaa !24
  %t695 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t695, label %bb205, label %bb206
bb204:
  br label %bb209
bb205:
  %t697 = call ptr @__olang_region_make(ptr %v1)
  %t698 = ptrtoint ptr %t697 to i64
  store i64 %t698, ptr %l418, !tbaa !24
  br label %bb206
bb206:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t701 = getelementptr %"compiler/emit:Emitter", ptr %t699, i32 0, i32 22
  %t702 = load i64, ptr %l49, !tbaa !24
  %t705 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s26, ptr %t701, i64 %t702)
  store { i64, ptr } %t705, ptr %l423
  br label %bb207
bb207:
  %t706 = load { i64, ptr }, ptr %l423, !tbaa !27
  %t707 = extractvalue { i64, ptr } %t706, 1
  %t708 = extractvalue { i64, ptr } %t706, 0
  %t709 = load i64, ptr %l418
  %t710 = inttoptr i64 %t709 to ptr
  %t711 = call ptr @__olang_held_alloc(ptr %t710, i64 %t708)
  call void @olang_textcopy(ptr %t711, ptr %t707, i64 %t708)
  %t712 = insertvalue { i64, ptr } undef, i64 %t708, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t711, 1
  %t715 = load ptr, ptr %l417, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t715, { i64, ptr } %t713)
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s26)
  br label %bb209
bb209:
  %t717 = load i64, ptr %l50, !tbaa !24
  %t718 = load i64, ptr @G_2ecompiler_2femit_2eHomeLoc, !tbaa !24
  %t721 = icmp eq i64 %t717, %t718
  br i1 %t721, label %bb210, label %bb211
bb210:
  %t723 = load ptr, ptr %l7, !tbaa !29
  %t725 = icmp eq ptr %t723, null
  %t727 = xor i1 %t725, true
  store i1 %t727, ptr %l429, !tbaa !21
  br label %bb212
bb211:
  store i1 false, ptr %l429, !tbaa !21
  br label %bb212
bb212:
  %t729 = load i1, ptr %l429, !tbaa !21
  br i1 %t729, label %bb213, label %bb214
bb213:
  %t730 = load ptr, ptr %l7, !tbaa !29
  %t731 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v2, ptr %t730, i64 %t731, i1 true)
  br label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb216
bb216:
  br label %bb217
bb217:
  %t734 = load i64, ptr %l45, !tbaa !24
  %t737 = add i64 %t734, 1
  store i64 %t737, ptr %l45, !tbaa !24
  br label %bb131
bb218:
  br label %bb219
bb219:
  br label %bb84
bb220:
  %t739 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t739, ptr %l438
  br label %bb221
bb221:
  %t740 = load %"std/prelude/text:StringBuilder", ptr %l438
  store %"std/prelude/text:StringBuilder" %t740, ptr %l51
  store ptr %l51, ptr %l439, !tbaa !29
  %t741 = load ptr, ptr %l0, !tbaa !29
  %t743 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %s0, ptr %t741)
  store { i64, ptr } %t743, ptr %l441
  br label %bb222
bb222:
  %t744 = load { i64, ptr }, ptr %l441, !tbaa !27
  %t745 = load ptr, ptr %l439, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t745, { i64, ptr } %t744)
  br label %bb223
bb223:
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/emit:Emitter", ptr %t747, i32 0, i32 74
  %t750 = load { i64, ptr }, ptr %t749, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l51, { i64, ptr } %t750)
  br label %bb224
bb224:
  store ptr %l27, ptr %l52, !tbaa !29
  store i64 0, ptr %l53, !tbaa !24
  br label %bb225
bb225:
  %t754 = load i64, ptr %l53, !tbaa !24
  store i64 %t754, ptr %l447, !tbaa !24
  %t755 = load ptr, ptr %l52, !tbaa !29
  %t757 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t755)
  store i64 %t757, ptr %l449
  br label %bb226
bb226:
  %t758 = load i64, ptr %l447, !tbaa !24
  %t759 = load i64, ptr %l449, !tbaa !24
  %t760 = icmp slt i64 %t758, %t759
  %t762 = xor i1 %t760, true
  br i1 %t762, label %bb227, label %bb228
bb227:
  br label %bb234
bb228:
  br label %bb229
bb229:
  %t764 = load ptr, ptr %l52, !tbaa !29
  %t765 = load i64, ptr %l53, !tbaa !24
  %t768 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t764, i64 %t765)
  store i64 %t768, ptr %l454
  br label %bb230
bb230:
  %t769 = load i64, ptr %l454, !tbaa !24
  store ptr %l51, ptr %l455, !tbaa !29
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t772 = getelementptr %"compiler/emit:Emitter", ptr %t770, i32 0, i32 59
  %t776 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t772, i64 %t769)
  store { i64, ptr } %t776, ptr %l459
  br label %bb231
bb231:
  %t777 = load ptr, ptr %l455, !tbaa !29
  %t778 = load { i64, ptr }, ptr %l459, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t777, { i64, ptr } %t778)
  br label %bb232
bb232:
  br label %bb233
bb233:
  %t779 = load i64, ptr %l53, !tbaa !24
  %t782 = add i64 %t779, 1
  store i64 %t782, ptr %l53, !tbaa !24
  br label %bb225
bb234:
  %t784 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t784, ptr %l463
  br label %bb235
bb235:
  %t785 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l463
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t785, ptr %l55
  store ptr %l19, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb236
bb236:
  %t787 = load i64, ptr %l57, !tbaa !24
  store i64 %t787, ptr %l465, !tbaa !24
  %t788 = load ptr, ptr %l56, !tbaa !29
  %t790 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t788)
  store i64 %t790, ptr %l467
  br label %bb237
bb237:
  %t791 = load i64, ptr %l465, !tbaa !24
  %t792 = load i64, ptr %l467, !tbaa !24
  %t793 = icmp slt i64 %t791, %t792
  %t795 = xor i1 %t793, true
  br i1 %t795, label %bb238, label %bb239
bb238:
  br label %bb364
bb239:
  br label %bb240
bb240:
  %t797 = load ptr, ptr %l56, !tbaa !29
  %t798 = load i64, ptr %l57, !tbaa !24
  %t801 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t797, i64 %t798)
  store i64 %t801, ptr %l472
  br label %bb241
bb241:
  %t802 = load i64, ptr %l472, !tbaa !24
  store i64 %t802, ptr %l58, !tbaa !24
  %t803 = load i1, ptr %l30, !tbaa !21
  br i1 %t803, label %bb242, label %bb243
bb242:
  %t805 = load ptr, ptr %l0, !tbaa !29
  %t807 = getelementptr %"compiler/emit:Emitter", ptr %t805, i32 0, i32 85
  %t808 = load i64, ptr %l58, !tbaa !24
  %t811 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t807, i64 %t808)
  store i1 %t811, ptr %l478
  br label %bb244
bb243:
  store i1 false, ptr %l474, !tbaa !21
  br label %bb245
bb244:
  %t812 = load i1, ptr %l478, !tbaa !21
  store i1 %t812, ptr %l474, !tbaa !21
  br label %bb245
bb245:
  %t813 = load i1, ptr %l474, !tbaa !21
  br i1 %t813, label %bb246, label %bb247
bb246:
  store %olang.scope zeroinitializer, ptr %s35
  %t814 = load ptr, ptr %l0, !tbaa !29
  %t816 = getelementptr %"compiler/emit:Emitter", ptr %t814, i32 0, i32 85
  %t817 = load i64, ptr %l58, !tbaa !24
  %t820 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t816, i64 %t817)
  %t821 = extractvalue { i32, i64 } %t820, 1
  %t822 = extractvalue { i32, i64 } %t820, 0
  store i32 %t822, ptr %l484
  %t823 = icmp ne i32 %t822, 0
  br i1 %t823, label %bb249, label %ok.824, !prof !99
ok.824:
  store i64 %t821, ptr %l483
  br label %bb248
bb247:
  br label %bb268
bb248:
  %t825 = load i64, ptr %l483, !tbaa !24
  store i64 %t825, ptr %l479, !tbaa !24
  br label %bb251
bb249:
  br label %bb250
bb250:
  %t826 = load i64, ptr %l58, !tbaa !24
  store i64 %t826, ptr %l479, !tbaa !24
  br label %bb251
bb251:
  %t828 = load i64, ptr %l479, !tbaa !24
  store i64 %t828, ptr %l59, !tbaa !24
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load i64, ptr %l58, !tbaa !24
  %t833 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %t829, i64 %t830)
  store i1 %t833, ptr %l488
  br label %bb252
bb252:
  %t834 = load i1, ptr %l488, !tbaa !21
  %t835 = xor i1 %t834, true
  br i1 %t835, label %bb253, label %bb254
bb253:
  store ptr %l51, ptr %l490, !tbaa !29
  %t837 = load i64, ptr %l58, !tbaa !24
  %t840 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %s0, ptr %s0, ptr %l34, i64 %t837)
  %t841 = extractvalue { i32, { i64, ptr } } %t840, 1
  %t842 = extractvalue { i32, { i64, ptr } } %t840, 0
  store i32 %t842, ptr %l495
  %t843 = icmp ne i32 %t842, 0
  br i1 %t843, label %bb256, label %ok.844, !prof !99
ok.844:
  store { i64, ptr } %t841, ptr %l494
  br label %bb255
bb254:
  br label %bb260
bb255:
  %t845 = load { i64, ptr }, ptr %l494, !tbaa !27
  store { i64, ptr } %t845, ptr %l491, !tbaa !27
  br label %bb258
bb256:
  br label %bb257
bb257:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l491, !tbaa !27
  br label %bb258
bb258:
  %t846 = load ptr, ptr %l490, !tbaa !29
  %t847 = load { i64, ptr }, ptr %l491, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t846, { i64, ptr } %t847)
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s35)
  br label %bb363
bb260:
  %t848 = load ptr, ptr %l0, !tbaa !29
  %t850 = getelementptr %"compiler/emit:Emitter", ptr %t848, i32 0, i32 86
  %t851 = load i64, ptr %l58, !tbaa !24
  %t854 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t850, i64 %t851)
  %t855 = extractvalue { i32, { i64, ptr } } %t854, 1
  %t856 = extractvalue { i32, { i64, ptr } } %t854, 0
  store i32 %t856, ptr %l501
  %t857 = icmp ne i32 %t856, 0
  br i1 %t857, label %bb262, label %ok.858, !prof !99
ok.858:
  store { i64, ptr } %t855, ptr %l500
  br label %bb261
bb261:
  %t859 = load { i64, ptr }, ptr %l500, !tbaa !27
  store { i64, ptr } %t859, ptr %l496, !tbaa !27
  br label %bb264
bb262:
  br label %bb263
bb263:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l496, !tbaa !27
  br label %bb264
bb264:
  %t860 = load { i64, ptr }, ptr %l496, !tbaa !27
  store { i64, ptr } %t860, ptr %l60, !tbaa !27
  store ptr %l51, ptr %l502, !tbaa !29
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t863 = getelementptr %"compiler/emit:Emitter", ptr %t861, i32 0, i32 22
  %t864 = load i64, ptr %l58, !tbaa !24
  %t867 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s35, ptr %t863, i64 %t864)
  store { i64, ptr } %t867, ptr %l506
  br label %bb265
bb265:
  %t868 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t868, ptr %l507, !tbaa !27
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t871 = getelementptr %"compiler/emit:Emitter", ptr %t869, i32 0, i32 22
  %t872 = load i64, ptr %l59, !tbaa !24
  %t875 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s35, ptr %t871, i64 %t872)
  store { i64, ptr } %t875, ptr %l511
  br label %bb266
bb266:
  %t876 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t877 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t878 = load { i64, ptr }, ptr %l506, !tbaa !27
  %t879 = extractvalue { i64, ptr } %t878, 1
  %t880 = extractvalue { i64, ptr } %t878, 0
  %t881 = add i64 %t877, %t880
  %t882 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t883 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t884 = add i64 %t881, %t883
  %t885 = load { i64, ptr }, ptr %l507, !tbaa !27
  %t886 = extractvalue { i64, ptr } %t885, 1
  %t887 = extractvalue { i64, ptr } %t885, 0
  %t888 = add i64 %t884, %t887
  %t889 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t890 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t891 = add i64 %t888, %t890
  %t892 = load { i64, ptr }, ptr %l511, !tbaa !27
  %t893 = extractvalue { i64, ptr } %t892, 1
  %t894 = extractvalue { i64, ptr } %t892, 0
  %t895 = add i64 %t891, %t894
  %t896 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t897 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t898 = add i64 %t895, %t897
  %t899 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t898)
  call void @olang_textcopy(ptr %t899, ptr %t876, i64 %t877)
  %t900 = getelementptr i8, ptr %t899, i64 %t877
  call void @olang_textcopy(ptr %t900, ptr %t879, i64 %t880)
  %t901 = getelementptr i8, ptr %t900, i64 %t880
  call void @olang_textcopy(ptr %t901, ptr %t882, i64 %t883)
  %t902 = getelementptr i8, ptr %t901, i64 %t883
  call void @olang_textcopy(ptr %t902, ptr %t886, i64 %t887)
  %t903 = getelementptr i8, ptr %t902, i64 %t887
  call void @olang_textcopy(ptr %t903, ptr %t889, i64 %t890)
  %t904 = getelementptr i8, ptr %t903, i64 %t890
  call void @olang_textcopy(ptr %t904, ptr %t893, i64 %t894)
  %t905 = getelementptr i8, ptr %t904, i64 %t894
  call void @olang_textcopy(ptr %t905, ptr %t896, i64 %t897)
  %t906 = insertvalue { i64, ptr } undef, i64 %t898, 0
  %t907 = insertvalue { i64, ptr } %t906, ptr %t899, 1
  %t909 = load ptr, ptr %l502, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s35, ptr %t909, { i64, ptr } %t907)
  br label %bb267
bb267:
  call void @__olang_scope_close(ptr %s35)
  br label %bb363
bb268:
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t913 = getelementptr %"compiler/emit:Emitter", ptr %t911, i32 0, i32 23
  %t914 = load i64, ptr %l58, !tbaa !24
  %t917 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t913, i64 %t914)
  store { i64, ptr } %t917, ptr %l517
  br label %bb269
bb269:
  %t918 = load { i64, ptr }, ptr %l517, !tbaa !27
  store { i64, ptr } %t918, ptr %l61, !tbaa !27
  %t920 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H0211835ad1df5edc8086b9b7bc878d6e(ptr %s0, ptr %l29)
  store i64 %t920, ptr %l519
  br label %bb270
bb270:
  %t921 = load i64, ptr %l519, !tbaa !24
  %t922 = icmp eq i64 %t921, 0
  br i1 %t922, label %bb271, label %bb272
bb271:
  %t924 = load ptr, ptr %l0, !tbaa !29
  %t926 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbg(ptr %v0, ptr %t924)
  store i1 %t926, ptr %l523
  br label %bb273
bb272:
  store i1 false, ptr %l521, !tbaa !21
  br label %bb274
bb273:
  %t927 = load i1, ptr %l523, !tbaa !21
  %t928 = xor i1 %t927, true
  store i1 %t928, ptr %l521, !tbaa !21
  br label %bb274
bb274:
  %t930 = load i1, ptr %l521, !tbaa !21
  br i1 %t930, label %bb275, label %bb276
bb275:
  %t931 = load { i64, ptr }, ptr %l61, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l51, { i64, ptr } %t931)
  br label %bb277
bb276:
  br label %bb278
bb277:
  br label %bb363
bb278:
  store i64 0, ptr %l62, !tbaa !24
  %t934 = load ptr, ptr %l0, !tbaa !29
  %t935 = load i64, ptr %l58, !tbaa !24
  %t938 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %v0, ptr %t934, i64 %t935)
  store { i64, ptr } %t938, ptr %l529
  br label %bb279
bb279:
  %t939 = load { i64, ptr }, ptr %l529, !tbaa !27
  store { i64, ptr } %t939, ptr %l63, !tbaa !27
  store i64 0, ptr %l64, !tbaa !24
  %t940 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t942 = extractvalue { i64, ptr } %t940, 0
  store i64 %t942, ptr %l65, !tbaa !24
  store i64 3, ptr %l66, !tbaa !24
  %t944 = load i64, ptr %l65, !tbaa !24
  %t945 = load i64, ptr %l64, !tbaa !24
  %t948 = icmp sgt i64 %t944, %t945
  br i1 %t948, label %bb280, label %bb281
bb280:
  %t950 = load i64, ptr %l66, !tbaa !24
  %t952 = icmp sgt i64 %t950, 0
  br i1 %t952, label %bb282, label %bb283
bb281:
  store i64 0, ptr %l535, !tbaa !24
  br label %bb285
bb282:
  %t954 = load i64, ptr %l65, !tbaa !24
  %t955 = load i64, ptr %l64, !tbaa !24
  %t958 = sub i64 %t954, %t955
  %t959 = load i64, ptr %l66, !tbaa !24
  %t962 = add i64 %t958, %t959
  %t964 = sub i64 %t962, 1
  %t965 = load i64, ptr %l66, !tbaa !24
  %t968 = sdiv i64 %t964, %t965
  store i64 %t968, ptr %l538, !tbaa !24
  br label %bb284
bb283:
  store i64 0, ptr %l538, !tbaa !24
  br label %bb284
bb284:
  %t970 = load i64, ptr %l538, !tbaa !24
  store i64 %t970, ptr %l535, !tbaa !24
  br label %bb285
bb285:
  %t971 = load i64, ptr %l535, !tbaa !24
  store i64 %t971, ptr %l67, !tbaa !24
  store i64 0, ptr %l68, !tbaa !24
  br label %bb286
bb286:
  store %olang.scope zeroinitializer, ptr %s40
  %t972 = load i64, ptr %l68, !tbaa !24
  %t973 = load i64, ptr %l67, !tbaa !24
  %t976 = icmp slt i64 %t972, %t973
  %t978 = xor i1 %t976, true
  br i1 %t978, label %bb287, label %bb288
bb287:
  call void @__olang_scope_close(ptr %s40)
  br label %bb355
bb288:
  br label %bb289
bb289:
  %t980 = load i64, ptr %l64, !tbaa !24
  %t981 = load i64, ptr %l68, !tbaa !24
  %t982 = load i64, ptr %l66, !tbaa !24
  %t985 = mul i64 %t981, %t982
  %t988 = add i64 %t980, %t985
  store i64 %t988, ptr %l69, !tbaa !24
  %t990 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t990, ptr %l556, !tbaa !27
  %t991 = load i64, ptr %l69, !tbaa !24
  %t993 = getelementptr { i64, ptr }, ptr %l556, i32 0, i32 1
  %t994 = load ptr, ptr %t993, !tbaa !27
  %t995 = getelementptr i64, ptr %t994, i64 %t991
  %t996 = load i64, ptr %t995, !tbaa !34
  %t998 = icmp eq i64 %t996, 2
  br i1 %t998, label %bb290, label %bb291
bb290:
  store %olang.scope zeroinitializer, ptr %s41
  %t1000 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1000, ptr %l561, !tbaa !27
  %t1001 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1001, ptr %l562, !tbaa !27
  %t1002 = load i64, ptr %l69, !tbaa !24
  %t1004 = add i64 %t1002, 1
  %t1006 = getelementptr { i64, ptr }, ptr %l562, i32 0, i32 1
  %t1007 = load ptr, ptr %t1006, !tbaa !27
  %t1008 = getelementptr i64, ptr %t1007, i64 %t1004
  %t1009 = load i64, ptr %t1008, !tbaa !34
  %t1011 = add i64 %t1009, 1
  store i64 %t1011, ptr %l566, !tbaa !24
  %t1012 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1012, ptr %l567, !tbaa !27
  %t1013 = load i64, ptr %l69, !tbaa !24
  %t1015 = add i64 %t1013, 2
  %t1017 = getelementptr { i64, ptr }, ptr %l567, i32 0, i32 1
  %t1018 = load ptr, ptr %t1017, !tbaa !27
  %t1019 = getelementptr i64, ptr %t1018, i64 %t1015
  %t1020 = load i64, ptr %t1019, !tbaa !34
  store i64 %t1020, ptr %l570, !tbaa !24
  %t1021 = load { i64, ptr }, ptr %l561, !tbaa !27
  %t1022 = extractvalue { i64, ptr } %t1021, 0
  store i64 %t1022, ptr %l571, !tbaa !24
  %t1023 = load i64, ptr %l566, !tbaa !24
  %t1024 = icmp sge i64 %t1023, 0
  br i1 %t1024, label %bb292, label %bb293
bb291:
  br label %bb316
bb292:
  %t1026 = load i64, ptr %l566, !tbaa !24
  %t1027 = load i64, ptr %l570, !tbaa !24
  %t1028 = icmp sle i64 %t1026, %t1027
  br i1 %t1028, label %bb294, label %bb295
bb293:
  call void @__olang_check_failed(ptr @olang_loc_4635f1a318b549bc_759936c3a7928310)
  unreachable
bb294:
  %t1030 = load i64, ptr %l570, !tbaa !24
  %t1031 = load i64, ptr %l571, !tbaa !24
  %t1032 = icmp sle i64 %t1030, %t1031
  br i1 %t1032, label %bb296, label %bb297
bb295:
  call void @__olang_check_failed(ptr @olang_loc_4635f1a318b549bc_759936c3a7928310)
  unreachable
bb296:
  %t1034 = getelementptr { i64, ptr }, ptr %l561, i32 0, i32 1
  %t1035 = load ptr, ptr %t1034, !tbaa !27
  %t1036 = load i64, ptr %l566, !tbaa !24
  %t1037 = load i64, ptr %l570, !tbaa !24
  %t1038 = getelementptr i8, ptr %t1035, i64 %t1036
  %t1039 = sub i64 %t1037, %t1036
  %t1040 = insertvalue { i64, ptr } undef, i64 %t1039, 0
  %t1041 = insertvalue { i64, ptr } %t1040, ptr %t1038, 1
  store { i64, ptr } %t1041, ptr %l575, !tbaa !27
  %t1042 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s41, i64 10)
  %t1043 = extractvalue { i32, i64 } %t1042, 1
  %t1044 = extractvalue { i32, i64 } %t1042, 0
  store i32 %t1044, ptr %l577
  %t1045 = icmp ne i32 %t1044, 0
  br i1 %t1045, label %bb299, label %ok.1046, !prof !99
ok.1046:
  store i64 %t1043, ptr %l576
  br label %bb298
bb297:
  call void @__olang_check_failed(ptr @olang_loc_4635f1a318b549bc_759936c3a7928310)
  unreachable
bb298:
  %t1047 = load { i64, ptr }, ptr %l575, !tbaa !27
  %t1048 = load i64, ptr %l576, !tbaa !24
  %t1049 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t1047, i64 %t1048)
  %t1050 = extractvalue { i32, i64 } %t1049, 1
  %t1051 = extractvalue { i32, i64 } %t1049, 0
  store i32 %t1051, ptr %l579
  %t1052 = icmp ne i32 %t1051, 0
  br i1 %t1052, label %bb302, label %ok.1053, !prof !99
ok.1053:
  store i64 %t1050, ptr %l578
  br label %bb301
bb299:
  br label %bb300
bb300:
  store i64 0, ptr %l560, !tbaa !24
  br label %bb303
bb301:
  %t1054 = load i64, ptr %l578, !tbaa !24
  store i64 %t1054, ptr %l560, !tbaa !24
  br label %bb303
bb302:
  br label %bb300
bb303:
  %t1055 = load i64, ptr %l560, !tbaa !24
  store i64 %t1055, ptr %l70, !tbaa !24
  %t1056 = load i64, ptr %l70, !tbaa !24
  %t1058 = icmp slt i64 %t1056, 1000
  br i1 %t1058, label %bb304, label %bb305
bb304:
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb305:
  br label %bb306
bb306:
  store ptr %l51, ptr %l582, !tbaa !29
  %t1060 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1060, ptr %l583, !tbaa !27
  %t1061 = load i64, ptr %l62, !tbaa !24
  store i64 %t1061, ptr %l584, !tbaa !24
  %t1062 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1062, ptr %l585, !tbaa !27
  %t1063 = load i64, ptr %l69, !tbaa !24
  %t1065 = add i64 %t1063, 1
  %t1067 = getelementptr { i64, ptr }, ptr %l585, i32 0, i32 1
  %t1068 = load ptr, ptr %t1067, !tbaa !27
  %t1069 = getelementptr i64, ptr %t1068, i64 %t1065
  %t1070 = load i64, ptr %t1069, !tbaa !34
  store i64 %t1070, ptr %l588, !tbaa !24
  %t1071 = load { i64, ptr }, ptr %l583, !tbaa !27
  %t1072 = extractvalue { i64, ptr } %t1071, 0
  store i64 %t1072, ptr %l589, !tbaa !24
  %t1073 = load i64, ptr %l584, !tbaa !24
  %t1074 = icmp sge i64 %t1073, 0
  br i1 %t1074, label %bb307, label %bb308
bb307:
  %t1076 = load i64, ptr %l584, !tbaa !24
  %t1077 = load i64, ptr %l588, !tbaa !24
  %t1078 = icmp sle i64 %t1076, %t1077
  br i1 %t1078, label %bb309, label %bb310
bb308:
  call void @__olang_check_failed(ptr @olang_loc_2968b987139e6167_76a7d58ddfcdba8b)
  unreachable
bb309:
  %t1080 = load i64, ptr %l588, !tbaa !24
  %t1081 = load i64, ptr %l589, !tbaa !24
  %t1082 = icmp sle i64 %t1080, %t1081
  br i1 %t1082, label %bb311, label %bb312
bb310:
  call void @__olang_check_failed(ptr @olang_loc_2968b987139e6167_76a7d58ddfcdba8b)
  unreachable
bb311:
  %t1084 = getelementptr { i64, ptr }, ptr %l583, i32 0, i32 1
  %t1085 = load ptr, ptr %t1084, !tbaa !27
  %t1086 = load i64, ptr %l584, !tbaa !24
  %t1087 = load i64, ptr %l588, !tbaa !24
  %t1088 = getelementptr i8, ptr %t1085, i64 %t1086
  %t1089 = sub i64 %t1087, %t1086
  %t1090 = insertvalue { i64, ptr } undef, i64 %t1089, 0
  %t1091 = insertvalue { i64, ptr } %t1090, ptr %t1088, 1
  %t1092 = load ptr, ptr %l582, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t1092, { i64, ptr } %t1091)
  br label %bb313
bb312:
  call void @__olang_check_failed(ptr @olang_loc_2968b987139e6167_76a7d58ddfcdba8b)
  unreachable
bb313:
  store ptr %l51, ptr %l594, !tbaa !29
  %t1094 = load i64, ptr %l70, !tbaa !24
  %t1097 = call i64 @compiler_2femit_2emetaNumber(ptr %s0, ptr %l55, i64 %t1094)
  store i64 %t1097, ptr %l597
  br label %bb314
bb314:
  %t1098 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t1099 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t1100 = load i64, ptr %l597, !tbaa !24
  %t1101 = call i64 @__olang_fmt_i64(ptr null, i64 %t1100)
  %t1102 = add i64 %t1099, %t1101
  %t1103 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1102)
  call void @olang_textcopy(ptr %t1103, ptr %t1098, i64 %t1099)
  %t1104 = getelementptr i8, ptr %t1103, i64 %t1099
  %t1105 = call i64 @__olang_fmt_i64(ptr %t1104, i64 %t1100)
  %t1106 = insertvalue { i64, ptr } undef, i64 %t1102, 0
  %t1107 = insertvalue { i64, ptr } %t1106, ptr %t1103, 1
  %t1109 = load ptr, ptr %l594, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s41, ptr %t1109, { i64, ptr } %t1107)
  br label %bb315
bb315:
  %t1111 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1111, ptr %l600, !tbaa !27
  %t1112 = load i64, ptr %l69, !tbaa !24
  %t1114 = add i64 %t1112, 2
  %t1116 = getelementptr { i64, ptr }, ptr %l600, i32 0, i32 1
  %t1117 = load ptr, ptr %t1116, !tbaa !27
  %t1118 = getelementptr i64, ptr %t1117, i64 %t1114
  %t1119 = load i64, ptr %t1118, !tbaa !34
  store i64 %t1119, ptr %l62, !tbaa !24
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb316:
  %t1121 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1121, ptr %l604, !tbaa !27
  %t1122 = load i64, ptr %l69, !tbaa !24
  %t1124 = getelementptr { i64, ptr }, ptr %l604, i32 0, i32 1
  %t1125 = load ptr, ptr %t1124, !tbaa !27
  %t1126 = getelementptr i64, ptr %t1125, i64 %t1122
  %t1127 = load i64, ptr %t1126, !tbaa !34
  %t1129 = icmp ne i64 %t1127, 0
  br i1 %t1129, label %bb317, label %bb318
bb317:
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb318:
  br label %bb319
bb319:
  %t1131 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1131, ptr %l608, !tbaa !27
  %t1132 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1132, ptr %l609, !tbaa !27
  %t1133 = load i64, ptr %l69, !tbaa !24
  %t1135 = add i64 %t1133, 1
  %t1137 = getelementptr { i64, ptr }, ptr %l609, i32 0, i32 1
  %t1138 = load ptr, ptr %t1137, !tbaa !27
  %t1139 = getelementptr i64, ptr %t1138, i64 %t1135
  %t1140 = load i64, ptr %t1139, !tbaa !34
  store i64 %t1140, ptr %l612, !tbaa !24
  %t1141 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1141, ptr %l613, !tbaa !27
  %t1142 = load i64, ptr %l69, !tbaa !24
  %t1144 = add i64 %t1142, 2
  %t1146 = getelementptr { i64, ptr }, ptr %l613, i32 0, i32 1
  %t1147 = load ptr, ptr %t1146, !tbaa !27
  %t1148 = getelementptr i64, ptr %t1147, i64 %t1144
  %t1149 = load i64, ptr %t1148, !tbaa !34
  store i64 %t1149, ptr %l616, !tbaa !24
  %t1150 = load { i64, ptr }, ptr %l608, !tbaa !27
  %t1151 = extractvalue { i64, ptr } %t1150, 0
  store i64 %t1151, ptr %l617, !tbaa !24
  %t1152 = load i64, ptr %l612, !tbaa !24
  %t1153 = icmp sge i64 %t1152, 0
  br i1 %t1153, label %bb320, label %bb321
bb320:
  %t1155 = load i64, ptr %l612, !tbaa !24
  %t1156 = load i64, ptr %l616, !tbaa !24
  %t1157 = icmp sle i64 %t1155, %t1156
  br i1 %t1157, label %bb322, label %bb323
bb321:
  call void @__olang_check_failed(ptr @olang_loc_493930ee087ace8a_eb37955c75d36e8e)
  unreachable
bb322:
  %t1159 = load i64, ptr %l616, !tbaa !24
  %t1160 = load i64, ptr %l617, !tbaa !24
  %t1161 = icmp sle i64 %t1159, %t1160
  br i1 %t1161, label %bb324, label %bb325
bb323:
  call void @__olang_check_failed(ptr @olang_loc_493930ee087ace8a_eb37955c75d36e8e)
  unreachable
bb324:
  %t1163 = getelementptr { i64, ptr }, ptr %l608, i32 0, i32 1
  %t1164 = load ptr, ptr %t1163, !tbaa !27
  %t1165 = load i64, ptr %l612, !tbaa !24
  %t1166 = load i64, ptr %l616, !tbaa !24
  %t1167 = getelementptr i8, ptr %t1164, i64 %t1165
  %t1168 = sub i64 %t1166, %t1165
  %t1169 = insertvalue { i64, ptr } undef, i64 %t1168, 0
  %t1170 = insertvalue { i64, ptr } %t1169, ptr %t1167, 1
  store { i64, ptr } %t1170, ptr %l71, !tbaa !27
  %t1172 = load ptr, ptr %l0, !tbaa !29
  %t1173 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t1176 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitemNamed(ptr %v0, ptr %v0, ptr %t1172, { i64, ptr } %t1173)
  store i64 %t1176, ptr %l624
  br label %bb326
bb325:
  call void @__olang_check_failed(ptr @olang_loc_493930ee087ace8a_eb37955c75d36e8e)
  unreachable
bb326:
  %t1177 = load i64, ptr %l624, !tbaa !24
  store i64 %t1177, ptr %l72, !tbaa !24
  %t1178 = load i64, ptr %l72, !tbaa !24
  %t1180 = icmp slt i64 %t1178, 0
  br i1 %t1180, label %bb327, label %bb328
bb327:
  store i1 true, ptr %l627, !tbaa !21
  br label %bb330
bb328:
  %t1182 = load i64, ptr %l72, !tbaa !24
  %t1185 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H86f724e2dc8b3b4d675d56b45c81e2ce(ptr %s0, ptr %l29, i64 %t1182)
  store i1 %t1185, ptr %l630
  br label %bb329
bb329:
  %t1186 = load i1, ptr %l630, !tbaa !21
  %t1187 = xor i1 %t1186, true
  store i1 %t1187, ptr %l627, !tbaa !21
  br label %bb330
bb330:
  %t1189 = load i1, ptr %l627, !tbaa !21
  br i1 %t1189, label %bb331, label %bb332
bb331:
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb332:
  br label %bb333
bb333:
  store ptr %l51, ptr %l632, !tbaa !29
  %t1190 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1190, ptr %l633, !tbaa !27
  %t1191 = load i64, ptr %l62, !tbaa !24
  store i64 %t1191, ptr %l634, !tbaa !24
  %t1192 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1192, ptr %l635, !tbaa !27
  %t1193 = load i64, ptr %l69, !tbaa !24
  %t1195 = add i64 %t1193, 1
  %t1197 = getelementptr { i64, ptr }, ptr %l635, i32 0, i32 1
  %t1198 = load ptr, ptr %t1197, !tbaa !27
  %t1199 = getelementptr i64, ptr %t1198, i64 %t1195
  %t1200 = load i64, ptr %t1199, !tbaa !34
  store i64 %t1200, ptr %l638, !tbaa !24
  %t1201 = load { i64, ptr }, ptr %l633, !tbaa !27
  %t1202 = extractvalue { i64, ptr } %t1201, 0
  store i64 %t1202, ptr %l639, !tbaa !24
  %t1203 = load i64, ptr %l634, !tbaa !24
  %t1204 = icmp sge i64 %t1203, 0
  br i1 %t1204, label %bb334, label %bb335
bb334:
  %t1206 = load i64, ptr %l634, !tbaa !24
  %t1207 = load i64, ptr %l638, !tbaa !24
  %t1208 = icmp sle i64 %t1206, %t1207
  br i1 %t1208, label %bb336, label %bb337
bb335:
  call void @__olang_check_failed(ptr @olang_loc_82b9110c3ab34805_cdca7d87f9ba97f1)
  unreachable
bb336:
  %t1210 = load i64, ptr %l638, !tbaa !24
  %t1211 = load i64, ptr %l639, !tbaa !24
  %t1212 = icmp sle i64 %t1210, %t1211
  br i1 %t1212, label %bb338, label %bb339
bb337:
  call void @__olang_check_failed(ptr @olang_loc_82b9110c3ab34805_cdca7d87f9ba97f1)
  unreachable
bb338:
  %t1214 = getelementptr { i64, ptr }, ptr %l633, i32 0, i32 1
  %t1215 = load ptr, ptr %t1214, !tbaa !27
  %t1216 = load i64, ptr %l634, !tbaa !24
  %t1217 = load i64, ptr %l638, !tbaa !24
  %t1218 = getelementptr i8, ptr %t1215, i64 %t1216
  %t1219 = sub i64 %t1217, %t1216
  %t1220 = insertvalue { i64, ptr } undef, i64 %t1219, 0
  %t1221 = insertvalue { i64, ptr } %t1220, ptr %t1218, 1
  %t1222 = load ptr, ptr %l632, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t1222, { i64, ptr } %t1221)
  br label %bb340
bb339:
  call void @__olang_check_failed(ptr @olang_loc_82b9110c3ab34805_cdca7d87f9ba97f1)
  unreachable
bb340:
  store ptr %l51, ptr %l644, !tbaa !29
  %t1224 = load i64, ptr %l72, !tbaa !24
  %t1227 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %s0, ptr %s0, ptr %l29, i64 %t1224)
  %t1228 = extractvalue { i32, { i64, ptr } } %t1227, 1
  %t1229 = extractvalue { i32, { i64, ptr } } %t1227, 0
  store i32 %t1229, ptr %l649
  %t1230 = icmp ne i32 %t1229, 0
  br i1 %t1230, label %bb342, label %ok.1231, !prof !99
ok.1231:
  store { i64, ptr } %t1228, ptr %l648
  br label %bb341
bb341:
  %t1232 = load { i64, ptr }, ptr %l648, !tbaa !27
  store { i64, ptr } %t1232, ptr %l645, !tbaa !27
  br label %bb344
bb342:
  br label %bb343
bb343:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l645, !tbaa !27
  br label %bb344
bb344:
  %t1233 = load ptr, ptr %l644, !tbaa !29
  %t1234 = load { i64, ptr }, ptr %l645, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t1233, { i64, ptr } %t1234)
  br label %bb345
bb345:
  store ptr %l51, ptr %l650, !tbaa !29
  %t1235 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t1235, ptr %l651, !tbaa !27
  %t1236 = load ptr, ptr %l0, !tbaa !29
  %t1238 = getelementptr %"compiler/emit:Emitter", ptr %t1236, i32 0, i32 22
  %t1239 = load i64, ptr %l72, !tbaa !24
  %t1242 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s40, ptr %t1238, i64 %t1239)
  store { i64, ptr } %t1242, ptr %l655
  br label %bb346
bb346:
  %t1243 = load { i64, ptr }, ptr %l655, !tbaa !27
  %t1244 = extractvalue { i64, ptr } %t1243, 0
  store i64 %t1244, ptr %l656, !tbaa !24
  %t1245 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t1248 = extractvalue { i64, ptr } %t1245, 0
  store i64 %t1248, ptr %l659, !tbaa !24
  %t1249 = load { i64, ptr }, ptr %l651, !tbaa !27
  %t1250 = extractvalue { i64, ptr } %t1249, 0
  store i64 %t1250, ptr %l660, !tbaa !24
  %t1251 = load i64, ptr %l656, !tbaa !24
  %t1252 = icmp sge i64 %t1251, 0
  br i1 %t1252, label %bb347, label %bb348
bb347:
  %t1254 = load i64, ptr %l656, !tbaa !24
  %t1255 = load i64, ptr %l659, !tbaa !24
  %t1256 = icmp sle i64 %t1254, %t1255
  br i1 %t1256, label %bb349, label %bb350
bb348:
  call void @__olang_check_failed(ptr @olang_loc_20b52d6bf9b06c28_18043bf0e12df584)
  unreachable
bb349:
  %t1258 = load i64, ptr %l659, !tbaa !24
  %t1259 = load i64, ptr %l660, !tbaa !24
  %t1260 = icmp sle i64 %t1258, %t1259
  br i1 %t1260, label %bb351, label %bb352
bb350:
  call void @__olang_check_failed(ptr @olang_loc_20b52d6bf9b06c28_18043bf0e12df584)
  unreachable
bb351:
  %t1262 = getelementptr { i64, ptr }, ptr %l651, i32 0, i32 1
  %t1263 = load ptr, ptr %t1262, !tbaa !27
  %t1264 = load i64, ptr %l656, !tbaa !24
  %t1265 = load i64, ptr %l659, !tbaa !24
  %t1266 = getelementptr i8, ptr %t1263, i64 %t1264
  %t1267 = sub i64 %t1265, %t1264
  %t1268 = insertvalue { i64, ptr } undef, i64 %t1267, 0
  %t1269 = insertvalue { i64, ptr } %t1268, ptr %t1266, 1
  %t1270 = load ptr, ptr %l650, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t1270, { i64, ptr } %t1269)
  br label %bb353
bb352:
  call void @__olang_check_failed(ptr @olang_loc_20b52d6bf9b06c28_18043bf0e12df584)
  unreachable
bb353:
  %t1272 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1272, ptr %l665, !tbaa !27
  %t1273 = load i64, ptr %l69, !tbaa !24
  %t1275 = add i64 %t1273, 2
  %t1277 = getelementptr { i64, ptr }, ptr %l665, i32 0, i32 1
  %t1278 = load ptr, ptr %t1277, !tbaa !27
  %t1279 = getelementptr i64, ptr %t1278, i64 %t1275
  %t1280 = load i64, ptr %t1279, !tbaa !34
  store i64 %t1280, ptr %l62, !tbaa !24
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb354:
  %t1282 = load i64, ptr %l68, !tbaa !24
  %t1285 = add i64 %t1282, 1
  store i64 %t1285, ptr %l68, !tbaa !24
  br label %bb286
bb355:
  store ptr %l51, ptr %l672, !tbaa !29
  %t1287 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1287, ptr %l673, !tbaa !27
  %t1288 = load i64, ptr %l62, !tbaa !24
  store i64 %t1288, ptr %l674, !tbaa !24
  %t1289 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t1292 = extractvalue { i64, ptr } %t1289, 0
  store i64 %t1292, ptr %l677, !tbaa !24
  %t1293 = load { i64, ptr }, ptr %l673, !tbaa !27
  %t1294 = extractvalue { i64, ptr } %t1293, 0
  store i64 %t1294, ptr %l678, !tbaa !24
  %t1295 = load i64, ptr %l674, !tbaa !24
  %t1296 = icmp sge i64 %t1295, 0
  br i1 %t1296, label %bb356, label %bb357
bb356:
  %t1298 = load i64, ptr %l674, !tbaa !24
  %t1299 = load i64, ptr %l677, !tbaa !24
  %t1300 = icmp sle i64 %t1298, %t1299
  br i1 %t1300, label %bb358, label %bb359
bb357:
  call void @__olang_check_failed(ptr @olang_loc_9bd48c53dce2a143_9d318240a700faef)
  unreachable
bb358:
  %t1302 = load i64, ptr %l677, !tbaa !24
  %t1303 = load i64, ptr %l678, !tbaa !24
  %t1304 = icmp sle i64 %t1302, %t1303
  br i1 %t1304, label %bb360, label %bb361
bb359:
  call void @__olang_check_failed(ptr @olang_loc_9bd48c53dce2a143_9d318240a700faef)
  unreachable
bb360:
  %t1306 = getelementptr { i64, ptr }, ptr %l673, i32 0, i32 1
  %t1307 = load ptr, ptr %t1306, !tbaa !27
  %t1308 = load i64, ptr %l674, !tbaa !24
  %t1309 = load i64, ptr %l677, !tbaa !24
  %t1310 = getelementptr i8, ptr %t1307, i64 %t1308
  %t1311 = sub i64 %t1309, %t1308
  %t1312 = insertvalue { i64, ptr } undef, i64 %t1311, 0
  %t1313 = insertvalue { i64, ptr } %t1312, ptr %t1310, 1
  %t1314 = load ptr, ptr %l672, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t1314, { i64, ptr } %t1313)
  br label %bb362
bb361:
  call void @__olang_check_failed(ptr @olang_loc_9bd48c53dce2a143_9d318240a700faef)
  unreachable
bb362:
  br label %bb363
bb363:
  %t1316 = load i64, ptr %l57, !tbaa !24
  %t1319 = add i64 %t1316, 1
  store i64 %t1319, ptr %l57, !tbaa !24
  br label %bb236
bb364:
  store ptr %l51, ptr %l686, !tbaa !29
  %t1322 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l25)
  store { i64, ptr } %t1322, ptr %l688
  br label %bb365
bb365:
  %t1323 = load { i64, ptr }, ptr %l688, !tbaa !27
  %t1324 = load ptr, ptr %l686, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t1324, { i64, ptr } %t1323)
  br label %bb366
bb366:
  %t1326 = load ptr, ptr %l0, !tbaa !29
  %t1328 = getelementptr %"compiler/emit:Emitter", ptr %t1326, i32 0, i32 78
  %t1329 = load i64, ptr %t1328, !tbaa !24
  %t1331 = icmp sge i64 %t1329, 0
  br i1 %t1331, label %bb367, label %bb368
bb367:
  %t1333 = load ptr, ptr %l0, !tbaa !29
  %t1335 = getelementptr %"compiler/emit:Emitter", ptr %t1333, i32 0, i32 78
  %t1336 = load i64, ptr %t1335, !tbaa !24
  %t1339 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l55, i64 %t1336)
  store i1 %t1339, ptr %l697
  br label %bb369
bb368:
  store i1 false, ptr %l693, !tbaa !21
  br label %bb370
bb369:
  %t1340 = load i1, ptr %l697, !tbaa !21
  store i1 %t1340, ptr %l693, !tbaa !21
  br label %bb370
bb370:
  %t1341 = load i1, ptr %l693, !tbaa !21
  br i1 %t1341, label %bb371, label %bb372
bb371:
  store %olang.scope zeroinitializer, ptr %s48
  store ptr %l51, ptr %l698, !tbaa !29
  %t1342 = load ptr, ptr %l0, !tbaa !29
  %t1344 = getelementptr %"compiler/emit:Emitter", ptr %t1342, i32 0, i32 78
  %t1345 = load i64, ptr %t1344, !tbaa !24
  %t1348 = call i64 @compiler_2femit_2emetaNumber(ptr %s0, ptr %l55, i64 %t1345)
  store i64 %t1348, ptr %l702
  br label %bb373
bb372:
  br label %bb376
bb373:
  %t1349 = load i64, ptr %l702, !tbaa !24
  %t1350 = call { i64, ptr } @compiler_2femit_2edbgTail(ptr %s48, i64 %t1349)
  store { i64, ptr } %t1350, ptr %l703
  br label %bb374
bb374:
  %t1351 = load { i64, ptr }, ptr %l703, !tbaa !27
  %t1352 = load ptr, ptr %l698, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s48, ptr %t1352, { i64, ptr } %t1351)
  br label %bb375
bb375:
  call void @__olang_scope_close(ptr %s48)
  br label %bb376
bb376:
  store ptr %l51, ptr %l705, !tbaa !29
  %t1354 = load ptr, ptr %l0, !tbaa !29
  %t1356 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eattributes(ptr %v0, ptr %s0, ptr %t1354)
  store { i64, ptr } %t1356, ptr %l707
  br label %bb377
bb377:
  %t1357 = load { i64, ptr }, ptr %l707, !tbaa !27
  %t1358 = load ptr, ptr %l705, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t1358, { i64, ptr } %t1357)
  br label %bb378
bb378:
  %t1361 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l51)
  store { i64, ptr } %t1361, ptr %l710
  br label %bb379
bb379:
  call void @__olang_scope_close(ptr %s0)
  %t1362 = load { i64, ptr }, ptr %l710, !tbaa !27
  store { i64, ptr } %t1362, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/cabi:Way"
  %l4 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l31 = alloca %"compiler/cabi:Way"
  %l33 = alloca { i64, ptr }
  %l37 = alloca i1
  %l39 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l23
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/emit:Emitter", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l25, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiArch(ptr %v0, ptr %s0, ptr %t51)
  store { i64, ptr } %t53, ptr %l27
  br label %bb9
bb9:
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t55 = load i32, ptr %l2, !tbaa !23
  %t57 = inttoptr i64 0 to ptr
  %t58 = load ptr, ptr %l25, !tbaa !29
  %t61 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %s0, ptr %s0, ptr %t57, ptr %t58, { i64, ptr } %t54, i32 %t55)
  store %"compiler/cabi:Way" %t61, ptr %l31
  br label %bb10
bb10:
  %t62 = load %"compiler/cabi:Way", ptr %l31
  store %"compiler/cabi:Way" %t62, ptr %l3
  %t63 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t64 = load i32, ptr %t63, !range !{i32 0, i32 5}
  store i32 %t64, ptr %l4
  %t66 = load i32, ptr %l4, !range !{i32 0, i32 5}
  %t68 = trunc i64 0 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb19
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t71 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 4
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t74, ptr %l37
  br label %bb14
bb14:
  %t75 = load i1, ptr %l37, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb15, label %bb16
bb15:
  %t78 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 4
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t81, i64 %t82)
  %t87 = getelementptr i8, ptr %t86, i64 %t82
  call void @olang_textcopy(ptr %t87, ptr %t83, i64 %t84)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  store { i64, ptr } %t89, ptr %l39, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb17
bb17:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  %t96 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s2, ptr %t92, i32 %t93)
  store { i64, ptr } %t96, ptr %l45
  br label %bb18
bb18:
  %t97 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb19:
  %t109 = load i32, ptr %l4, !range !{i32 0, i32 5}
  %t111 = trunc i64 1 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t115 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t115, ptr %l50
  br label %bb23
bb23:
  %t116 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t116, ptr %l33, !tbaa !27
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t117, ptr %l33, !tbaa !27
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_6aada305a3873fb6_c16c54d6f05c33ea)
  unreachable
bb29:
  %t119 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l53, !tbaa !24
  %t121 = load i64, ptr %l53, !tbaa !24
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l54, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l53, !tbaa !24
  %t131 = mul i64 %t130, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t132, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t133 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t133, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgName(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb42
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/emit:Emitter", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t21, i64 %t25)
  store ptr %t28, ptr %l20
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 1
  %t32 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t32, ptr %l4
  %t34 = load { i64, [2 x i64] }, ptr %l4
  %t36 = extractvalue { i64, [2 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 0
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t40 = getelementptr { i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb11
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/emit:Emitter", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/emit:Emitter", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t51, i64 %t52)
  store i64 %t55, ptr %l33
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t56, i64 %t57)
  store ptr %t58, ptr %l34
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l34, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s2, ptr %t63, i32 %t62)
  store { i64, ptr } %t65, ptr %l37
  br label %bb10
bb10:
  %t66 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t67, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb11:
  %t73 = load { i64, [2 x i64] }, ptr %l4
  %t75 = extractvalue { i64, [2 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 1
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t79 = getelementptr { i32, i32 }, ptr %t78, i32 0, i32 0
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load i32, ptr %l6, !tbaa !23
  %t85 = inttoptr i64 0 to ptr
  %t88 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s4, ptr %t85, ptr %t82, i32 %t83)
  store { i64, ptr } %t88, ptr %l45
  br label %bb15
bb15:
  %t89 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t90, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb16:
  %t96 = load { i64, [2 x i64] }, ptr %l4
  %t98 = extractvalue { i64, [2 x i64] } %t96, 0
  %t99 = icmp eq i64 %t98, 3
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t102 = getelementptr { i32 }, ptr %t101, i32 0, i32 0
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t108 = inttoptr i64 0 to ptr
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t108, ptr %t105, i32 %t106)
  store { i64, ptr } %t111, ptr %l53
  br label %bb20
bb20:
  %t112 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t113, i64 %t114)
  %t119 = getelementptr i8, ptr %t118, i64 %t114
  call void @olang_textcopy(ptr %t119, ptr %t115, i64 %t116)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  store { i64, ptr } %t121, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb21:
  %t123 = load { i64, [2 x i64] }, ptr %l4
  %t125 = extractvalue { i64, [2 x i64] } %t123, 0
  %t126 = icmp eq i64 %t125, 4
  br i1 %t126, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t128, ptr %l23, !tbaa !27
  br label %bb41
bb25:
  %t130 = load { i64, [2 x i64] }, ptr %l4
  %t132 = extractvalue { i64, [2 x i64] } %t130, 0
  %t133 = icmp eq i64 %t132, 5
  br i1 %t133, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb30
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l3, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t141 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestName(ptr %v0, ptr %s9, ptr %t135, i64 %t138)
  store { i64, ptr } %t141, ptr %l64
  br label %bb29
bb29:
  %t142 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t144 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t142, i64 %t143)
  %t149 = getelementptr i8, ptr %t148, i64 %t143
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  store { i64, ptr } %t151, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb30:
  %t153 = load { i64, [2 x i64] }, ptr %l4
  %t155 = extractvalue { i64, [2 x i64] } %t153, 0
  %t156 = icmp eq i64 %t155, 6
  br i1 %t156, label %bb31, label %bb32
bb31:
  %t158 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t159 = getelementptr { i64, i32 }, ptr %t158, i32 0, i32 1
  %t160 = load i32, ptr %t159
  store i32 %t160, ptr %l8, !tbaa !23
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s11
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l8, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s11, ptr %t162, i32 %t163)
  store { i64, ptr } %t166, ptr %l71
  br label %bb34
bb34:
  %t167 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t168, i64 %t169)
  %t174 = getelementptr i8, ptr %t173, i64 %t169
  call void @olang_textcopy(ptr %t174, ptr %t170, i64 %t171)
  %t175 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t173, 1
  store { i64, ptr } %t176, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb41
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, [2 x i64] }, ptr %l1
  %t182 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t178, { i64, [2 x i64] } %t179)
  store { i64, ptr } %t182, ptr %l75
  br label %bb39
bb39:
  %t183 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t183, ptr %l23, !tbaa !27
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_18f6acb4865fb5f2_de2c0e3f26126f06)
  unreachable
bb41:
  %t184 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  store i64 %t185, ptr %l76, !tbaa !24
  %t186 = load i64, ptr %l76, !tbaa !24
  %t187 = mul i64 %t186, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t187)
  %t189 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  store { i64, ptr } %t190, ptr %l77, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = load i64, ptr %l76, !tbaa !24
  %t196 = mul i64 %t195, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t192, ptr %t194, i64 %t196, i1 false)
  %t197 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t197, ptr %l23, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t198, ptr %rv
  br label %ret
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load { i64, [2 x i64] }, ptr %l1
  %t203 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t199, { i64, [2 x i64] } %t200)
  store { i64, ptr } %t203, ptr %l80
  br label %bb46
bb46:
  %t204 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t204, ptr %rv
  br label %ret
bb47:
  call void @__olang_check_failed(ptr @olang_loc_795f0ceaa031aa73_92815be2925279e7)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclTypes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i32
  %l65 = alloca i1
  %l68 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2erefsIn(ptr %v1, ptr %s0, { i64, ptr } %t1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t6, ptr %l15
  br label %bb2
bb2:
  %t7 = load i64, ptr %l15, !tbaa !24
  store i64 %t7, ptr %l6, !tbaa !24
  store i64 3, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l7, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  br label %bb38
bb11:
  br label %bb12
bb12:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t54)
  store i64 %t57, ptr %l42
  br label %bb13
bb13:
  %t58 = load i64, ptr %l42, !tbaa !24
  %t59 = icmp ne i64 %t58, 1
  br i1 %t59, label %bb14, label %bb15
bb14:
  br label %bb37
bb15:
  br label %bb16
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/emit:Emitter", ptr %t61, i32 0, i32 60
  store ptr %t63, ptr %l46, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t64, ptr %l47, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = add i64 %t65, 1
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t67)
  store i64 %t70, ptr %l51
  br label %bb17
bb17:
  %t71 = load i64, ptr %l10, !tbaa !24
  %t73 = add i64 %t71, 2
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t73)
  store i64 %t76, ptr %l55
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l56, !tbaa !24
  %t79 = load i64, ptr %l51, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load i64, ptr %l51, !tbaa !24
  %t83 = load i64, ptr %l55, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_84dc5702af008bfa_68e8ae64d289b3ce)
  unreachable
bb21:
  %t86 = load i64, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l56, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_84dc5702af008bfa_68e8ae64d289b3ce)
  unreachable
bb23:
  %t90 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l51, !tbaa !24
  %t93 = load i64, ptr %l55, !tbaa !24
  %t94 = getelementptr i8, ptr %t91, i64 %t92
  %t95 = sub i64 %t93, %t92
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  %t98 = load ptr, ptr %l46, !tbaa !29
  %t100 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t98, { i64, ptr } %t97)
  %t101 = extractvalue { i32, i64 } %t100, 1
  %t102 = extractvalue { i32, i64 } %t100, 0
  store i32 %t102, ptr %l62
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb26, label %ok.104, !prof !99
ok.104:
  store i64 %t101, ptr %l61
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_84dc5702af008bfa_68e8ae64d289b3ce)
  unreachable
bb25:
  %t105 = load i64, ptr %l61, !tbaa !24
  store i64 %t105, ptr %l44, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l44, !tbaa !24
  br label %bb28
bb28:
  %t106 = load i64, ptr %l44, !tbaa !24
  store i64 %t106, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = icmp sge i64 %t107, 0
  br i1 %t109, label %bb29, label %bb30
bb29:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v3, ptr %t111, i64 %t112)
  store i1 %t115, ptr %l68
  br label %bb31
bb30:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb32
bb31:
  %t116 = load i1, ptr %l68, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l65, !tbaa !21
  br label %bb32
bb32:
  %t119 = load i1, ptr %l65, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v2, ptr %v3, ptr %t120, i64 %t121, ptr %a2, ptr %t123)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb9
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclareSetjmp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 31
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load i1, ptr %l3, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s1, ptr %s1, ptr %t8, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s2, ptr %s2, ptr %t10, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDropFn(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca { i64, [2 x i64] }
  %l40 = alloca i32
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/mir:Fn"
  %l45 = alloca %"compiler/emit:fnEm"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i64
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l115 = alloca i64
  %l118 = alloca i64
  %l121 = alloca i64
  %l123 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t58 = alloca { i64, [2 x i64] }, align 8
  %t68 = alloca %"compiler/mir:Fn", align 8
  %t74 = alloca %"compiler/emit:fnEm", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = inttoptr i64 0 to ptr
  %t12 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t9, ptr %t4, i32 %t7)
  store { i64, ptr } %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t15 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = add i64 %t14, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = getelementptr i8, ptr %t19, i64 %t14
  call void @olang_textcopy(ptr %t20, ptr %t16, i64 %t17)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t19, 1
  %t25 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s0, ptr %v1, { i64, ptr } %t22)
  store { i64, ptr } %t25, ptr %l24
  br label %bb2
bb2:
  %t26 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/emit:Emitter", ptr %t27, i32 0, i32 76
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %t29, { i64, ptr } %t30)
  store i1 %t33, ptr %l28
  br label %bb3
bb3:
  %t34 = load i1, ptr %l28, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t35, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/emit:Emitter", ptr %t37, i32 0, i32 76
  store ptr %t39, ptr %l31, !tbaa !29
  %t40 = call ptr @__olang_scope_hold(ptr %v0)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l32, !tbaa !24
  %t42 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = call ptr @__olang_region_make(ptr %v0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = extractvalue { i64, ptr } %t46, 0
  %t50 = load i64, ptr %l32
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = call ptr @__olang_held_alloc(ptr %t51, i64 %t49)
  call void @olang_textcopy(ptr %t52, ptr %t48, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t56, { i64, ptr } %t54, i1 true)
  br label %bb9
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 0
  store i64 4, ptr %t59
  %t60 = insertvalue { i64 } undef, i64 0, 0
  %t61 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  store { i64 } %t60, ptr %t61
  %t62 = load { i64, [2 x i64] }, ptr %t58
  store { i64, [2 x i64] } %t62, ptr %l4
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  %t65 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t65, ptr %l39
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t66, ptr %l40, !tbaa !23
  %t67 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t67, ptr %l41
  br label %bb10
bb10:
  %t69 = load { i64, [2 x i64] }, ptr %l39
  %t70 = load i32, ptr %l40, !tbaa !23
  %t71 = load %"compiler/source:Span", ptr %l41
  call void @compiler_2fmir_3aFn_2ector(ptr %t68, ptr %s0, { i64, [2 x i64] } %t69, i32 %t70, i64 0, %"compiler/source:Span" %t71)
  call void @llvm.memmove.p0.p0.i64(ptr %l42, ptr %t68, i64 808, i1 false)
  br label %bb11
bb11:
  %t72 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 808, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %l42, i64 808, i1 false)
  %t73 = load { i64, [2 x i64] }, ptr %l4
  %t75 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2femit_3afnEm_2ector(ptr %t74, ptr %v0, ptr %s0, ptr %s0, ptr %t75, ptr %t72, { i64, [2 x i64] } %t73)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t74, i64 1104, i1 false)
  br label %bb12
bb12:
  %t78 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 1104, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %l45, i64 1104, i1 false)
  store ptr %t78, ptr %l5, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/emit:fnEm", ptr %t80, i32 0, i32 31
  store i1 true, ptr %t82, !tbaa !21
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t84 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %s0, ptr %s0, ptr %s0, ptr %v0, ptr %t83, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d24, i32 0, i32 1) }, i32 %t84, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, i1 false)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t88 = load i32, ptr %l1, !tbaa !23
  %t91 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3afnEm_2egenLeaves(ptr %s0, ptr %s0, ptr %v0, ptr %t87, i32 %t88)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l52
  br label %bb14
bb14:
  %t92 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l6
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %l6)
  store i64 %t94, ptr %l54
  br label %bb15
bb15:
  %t95 = load i64, ptr %l54, !tbaa !24
  %t96 = icmp sgt i64 %t95, 0
  br i1 %t96, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t98 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s4, ptr %t98, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store i64 0, ptr %l7, !tbaa !24
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %l6)
  store i64 %t101, ptr %l58
  br label %bb20
bb20:
  %t102 = load i64, ptr %l58, !tbaa !24
  store i64 %t102, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = icmp sgt i64 %t103, %t104
  br i1 %t107, label %bb21, label %bb22
bb21:
  %t109 = load i64, ptr %l9, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  br i1 %t111, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb26
bb23:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = sub i64 %t113, %t114
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = add i64 %t117, %t118
  %t123 = sub i64 %t121, 1
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = sdiv i64 %t123, %t124
  store i64 %t127, ptr %l65, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb25
bb25:
  %t129 = load i64, ptr %l65, !tbaa !24
  store i64 %t129, ptr %l62, !tbaa !24
  br label %bb26
bb26:
  %t130 = load i64, ptr %l62, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t131 = load i64, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb29:
  br label %bb30
bb30:
  %t139 = load i64, ptr %l7, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = mul i64 %t140, %t141
  %t147 = add i64 %t139, %t144
  store i64 %t147, ptr %l12, !tbaa !24
  %t149 = load ptr, ptr %l5, !tbaa !29
  store ptr %t149, ptr %l83, !tbaa !29
  %t150 = load ptr, ptr %l5, !tbaa !29
  store ptr %t150, ptr %l84, !tbaa !29
  %t151 = load ptr, ptr %l5, !tbaa !29
  store ptr %t151, ptr %l85, !tbaa !29
  %t152 = load i32, ptr %l1, !tbaa !23
  store i32 %t152, ptr %l86, !tbaa !23
  %t153 = load i64, ptr %l12, !tbaa !24
  %t156 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %s0, ptr %s6, ptr %l6, i64 %t153)
  store { i64, ptr } %t156, ptr %l89
  br label %bb31
bb31:
  %t157 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  store i64 %t158, ptr %l90, !tbaa !24
  %t159 = load i64, ptr %l90, !tbaa !24
  %t160 = mul i64 %t159, 8
  %t161 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l91, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l90, !tbaa !24
  %t169 = mul i64 %t168, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t165, ptr %t167, i64 %t169, i1 false)
  %t170 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = mul i64 %t171, 8
  %t174 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t177 = load ptr, ptr %l85, !tbaa !29
  %t178 = load i32, ptr %l86, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eleafAt(ptr %s0, ptr %s6, ptr %s6, ptr %s6, ptr %v0, ptr %t177, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, i32 %t178, { i64, ptr } %t176)
  store { i64, ptr } %t180, ptr %l93
  br label %bb32
bb32:
  %t181 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t183 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = add i64 %t182, %t185
  %t187 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t190 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t189)
  call void @olang_textcopy(ptr %t190, ptr %t181, i64 %t182)
  %t191 = getelementptr i8, ptr %t190, i64 %t182
  call void @olang_textcopy(ptr %t191, ptr %t184, i64 %t185)
  %t192 = getelementptr i8, ptr %t191, i64 %t185
  call void @olang_textcopy(ptr %t192, ptr %t187, i64 %t188)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t190, 1
  %t196 = load ptr, ptr %l84, !tbaa !29
  %t198 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %s0, ptr %s6, ptr %s6, ptr %v0, ptr %t196, { i64, ptr } %t194)
  store { i64, ptr } %t198, ptr %l96
  br label %bb33
bb33:
  %t199 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t200 = load ptr, ptr %l83, !tbaa !29
  %t202 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %s0, ptr %s6, ptr %s6, ptr %s6, ptr %s6, ptr %v0, ptr %t200, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) }, { i64, ptr } %t199, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t202, ptr %l98
  br label %bb34
bb34:
  %t203 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t204 = load ptr, ptr %l5, !tbaa !29
  store ptr %t204, ptr %l99, !tbaa !29
  store { i64, ptr } %t203, ptr %l100, !tbaa !27
  %t206 = load ptr, ptr %l5, !tbaa !29
  store ptr %t206, ptr %l101, !tbaa !29
  %t207 = load ptr, ptr %l5, !tbaa !29
  %t208 = load i32, ptr %l1, !tbaa !23
  %t209 = load i64, ptr %l12, !tbaa !24
  %t213 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWord(ptr %s0, ptr %s6, ptr %s6, ptr %v0, ptr %t207, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, i32 %t208, i64 %t209)
  store { i64, ptr } %t213, ptr %l105
  br label %bb35
bb35:
  %t214 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t215 = load ptr, ptr %l101, !tbaa !29
  %t217 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %s0, ptr %s6, ptr %s6, ptr %s6, ptr %s6, ptr %v0, ptr %t215, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, { i64, ptr } %t214, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t217, ptr %l107
  br label %bb36
bb36:
  %t218 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t220 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = add i64 %t219, %t222
  %t224 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t227 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = add i64 %t226, %t229
  %t231 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t218, i64 %t219)
  %t235 = getelementptr i8, ptr %t234, i64 %t219
  call void @olang_textcopy(ptr %t235, ptr %t221, i64 %t222)
  %t236 = getelementptr i8, ptr %t235, i64 %t222
  call void @olang_textcopy(ptr %t236, ptr %t224, i64 %t225)
  %t237 = getelementptr i8, ptr %t236, i64 %t225
  call void @olang_textcopy(ptr %t237, ptr %t228, i64 %t229)
  %t238 = getelementptr i8, ptr %t237, i64 %t229
  call void @olang_textcopy(ptr %t238, ptr %t231, i64 %t232)
  %t239 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t234, 1
  %t242 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %s0, ptr %s6, ptr %v0, ptr %t242, { i64, ptr } %t240)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t244 = load i64, ptr %l11, !tbaa !24
  %t247 = add i64 %t244, 1
  store i64 %t247, ptr %l11, !tbaa !24
  br label %bb27
bb39:
  %t249 = load ptr, ptr %l5, !tbaa !29
  %t250 = load i32, ptr %l1, !tbaa !23
  %t253 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %s0, ptr %v0, ptr %t249, i32 %t250)
  store i64 %t253, ptr %l115
  br label %bb40
bb40:
  %t254 = load i64, ptr %l115, !tbaa !24
  %t257 = icmp sle i64 %t254, 8
  br i1 %t257, label %bb41, label %bb42
bb41:
  %t259 = load ptr, ptr %l5, !tbaa !29
  %t260 = load i32, ptr %l1, !tbaa !23
  %t263 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2egenBytes(ptr %s0, ptr %v0, ptr %t259, i32 %t260)
  store i64 %t263, ptr %l121
  br label %bb43
bb42:
  store i64 -1, ptr %l118, !tbaa !24
  br label %bb45
bb43:
  %t264 = load i64, ptr %l121, !tbaa !24
  %t265 = add i64 %t264, 8
  %t267 = call i64 @compiler_2femit_2egenClass(i64 %t265)
  store i64 %t267, ptr %l123
  br label %bb44
bb44:
  %t268 = load i64, ptr %l123, !tbaa !24
  store i64 %t268, ptr %l118, !tbaa !24
  br label %bb45
bb45:
  %t269 = load i64, ptr %l118, !tbaa !24
  %t270 = load ptr, ptr %l5, !tbaa !29
  %t273 = add i64 %t269, 1
  %t274 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t277 = call i64 @__olang_fmt_i64(ptr null, i64 %t273)
  %t278 = add i64 %t275, %t277
  %t279 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t278)
  call void @olang_textcopy(ptr %t279, ptr %t274, i64 %t275)
  %t280 = getelementptr i8, ptr %t279, i64 %t275
  %t281 = call i64 @__olang_fmt_i64(ptr %t280, i64 %t273)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t279, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %s0, ptr %s0, ptr %v0, ptr %t270, { i64, ptr } %t283)
  br label %bb46
bb46:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l129, !tbaa !29
  %t288 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t288, ptr %l130, !tbaa !27
  %t289 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t289, ptr %l131, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t290, ptr %l132, !tbaa !27
  %t291 = load ptr, ptr %l5, !tbaa !29
  %t293 = getelementptr %"compiler/emit:fnEm", ptr %t291, i32 0, i32 3
  %t295 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t293)
  store { i64, ptr } %t295, ptr %l135
  br label %bb47
bb47:
  %t296 = load ptr, ptr %l5, !tbaa !29
  %t298 = getelementptr %"compiler/emit:fnEm", ptr %t296, i32 0, i32 4
  %t300 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t298)
  store { i64, ptr } %t300, ptr %l138
  br label %bb48
bb48:
  %t301 = load ptr, ptr %l5, !tbaa !29
  %t303 = getelementptr %"compiler/emit:fnEm", ptr %t301, i32 0, i32 5
  %t305 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t303)
  store { i64, ptr } %t305, ptr %l141
  br label %bb49
bb49:
  %t306 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t308 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t315 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = add i64 %t314, %t317
  %t319 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = add i64 %t318, %t321
  %t323 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t323, 1
  %t325 = extractvalue { i64, ptr } %t323, 0
  %t326 = add i64 %t322, %t325
  %t327 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t328 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t329 = add i64 %t326, %t328
  %t330 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t306, i64 %t307)
  %t331 = getelementptr i8, ptr %t330, i64 %t307
  call void @olang_textcopy(ptr %t331, ptr %t309, i64 %t310)
  %t332 = getelementptr i8, ptr %t331, i64 %t310
  call void @olang_textcopy(ptr %t332, ptr %t312, i64 %t313)
  %t333 = getelementptr i8, ptr %t332, i64 %t313
  call void @olang_textcopy(ptr %t333, ptr %t316, i64 %t317)
  %t334 = getelementptr i8, ptr %t333, i64 %t317
  call void @olang_textcopy(ptr %t334, ptr %t320, i64 %t321)
  %t335 = getelementptr i8, ptr %t334, i64 %t321
  call void @olang_textcopy(ptr %t335, ptr %t324, i64 %t325)
  %t336 = getelementptr i8, ptr %t335, i64 %t325
  call void @olang_textcopy(ptr %t336, ptr %t327, i64 %t328)
  %t337 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t330, 1
  %t340 = load ptr, ptr %l129, !tbaa !29
  %t341 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t342 = load i64, ptr %l131, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t340, { i64, ptr } %t341, i64 %t342, { i64, ptr } %t338, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb50
bb50:
  %t344 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t344, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eharness(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { { i64, ptr }, { i64, ptr } }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca i64
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i64
  %l54 = alloca { i64, ptr }
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca i64
  %l72 = alloca { { i64, ptr }, { i64, ptr } }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l80 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca i64
  %l98 = alloca i1
  %l105 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l128 = alloca %"std/prelude/text:StringBuilder"
  %l134 = alloca i64
  %l136 = alloca ptr
  %l138 = alloca i64
  %l140 = alloca { i64, ptr }
  %l144 = alloca i64
  %l146 = alloca ptr
  %l148 = alloca i64
  %l150 = alloca { i64, ptr }
  %l170 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l175 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l178 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l182 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l200 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l210 = alloca i64
  %l213 = alloca ptr
  %l215 = alloca i64
  %l218 = alloca ptr
  %l220 = alloca { i64, ptr }
  %l224 = alloca ptr
  %l226 = alloca i64
  %l233 = alloca i64
  %l236 = alloca i64
  %l239 = alloca ptr
  %l241 = alloca i64
  %l257 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l292 = alloca { i64, ptr }
  %l311 = alloca ptr
  %l313 = alloca { i64, ptr }
  %l317 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l323 = alloca ptr
  %l325 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l331 = alloca { i64, ptr }
  %l339 = alloca ptr
  %l343 = alloca i64
  %l345 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t217 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2einitOrder(ptr %v0, ptr %s0, ptr %t1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d42, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t7, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d44, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d46, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t11, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d48, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d50, i32 0, i32 1) }, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclareSetjmp(ptr %v0, ptr %t15)
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t17, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) }, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) }, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d55, i32 0, i32 1) })
  br label %bb9
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t21, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb10
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t23, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb11
bb11:
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l29
  br label %bb12
bb12:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %s1, ptr %s1, ptr %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l32
  br label %bb13
bb13:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t33 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t33
  store ptr %t33, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  store i64 %t35, ptr %l34, !tbaa !24
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t36)
  store i64 %t38, ptr %l36
  br label %bb15
bb15:
  %t39 = load i64, ptr %l34, !tbaa !24
  %t40 = load i64, ptr %l36, !tbaa !24
  %t41 = icmp slt i64 %t39, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb17:
  br label %bb18
bb18:
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t45, i64 %t46)
  store i64 %t49, ptr %l41
  br label %bb19
bb19:
  %t50 = load i64, ptr %l41, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/emit:Emitter", ptr %t51, i32 0, i32 61
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t53, i64 %t54)
  store i1 %t57, ptr %l45
  br label %bb20
bb20:
  %t58 = load i1, ptr %l45, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb22:
  br label %bb23
bb23:
  store ptr %l3, ptr %l46, !tbaa !29
  %t59 = call ptr @__olang_scope_hold(ptr %s0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l47, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t63 = call ptr @__olang_region_make(ptr %s0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l47, !tbaa !24
  br label %bb25
bb25:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = trunc i64 %t66 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 0, ptr %t71
  %t73 = insertvalue { i32 } undef, i32 %t68, 0
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  store { i32 } %t73, ptr %t74
  %t75 = load { i64, [2 x i64] }, ptr %t70
  %t78 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s2, ptr %t65, { i64, [2 x i64] } %t75)
  store { i64, ptr } %t78, ptr %l54
  br label %bb26
bb26:
  %t79 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t81 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = add i64 %t80, %t83
  %t85 = load i64, ptr %l47
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = call ptr @__olang_held_alloc(ptr %t86, i64 %t84)
  call void @olang_textcopy(ptr %t87, ptr %t79, i64 %t80)
  %t88 = getelementptr i8, ptr %t87, i64 %t80
  call void @olang_textcopy(ptr %t88, ptr %t82, i64 %t83)
  %t89 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t92, { i64, ptr } %t90)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t94, 1
  store i64 %t97, ptr %l5, !tbaa !24
  br label %bb14
bb29:
  call void @__olang_scope_close(ptr %s1)
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l60
  br label %bb30
bb30:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %l7
  store ptr %l1, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t102 = load i64, ptr %l9, !tbaa !24
  store i64 %t102, ptr %l62, !tbaa !24
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t105 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t103)
  store i64 %t105, ptr %l64
  br label %bb32
bb32:
  %t106 = load i64, ptr %l62, !tbaa !24
  %t107 = load i64, ptr %l64, !tbaa !24
  %t108 = icmp slt i64 %t106, %t107
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb61
bb34:
  br label %bb35
bb35:
  %t112 = load ptr, ptr %l8, !tbaa !29
  %t113 = load i64, ptr %l9, !tbaa !24
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l69
  br label %bb36
bb36:
  %t117 = load i64, ptr %l69, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestParts(ptr %v0, ptr %s7, ptr %t118, i64 %t119)
  store { { i64, ptr }, { i64, ptr } } %t122, ptr %l72
  br label %bb37
bb37:
  %t123 = load { { i64, ptr }, { i64, ptr } }, ptr %l72
  store { { i64, ptr }, { i64, ptr } } %t123, ptr %l11
  %t124 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l11, i32 0, i32 0
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l73, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l74, !tbaa !24
  %t128 = load i64, ptr %l74, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l75, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l74, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t139, ptr %l12, !tbaa !27
  %t140 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l11, i32 0, i32 1
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l76, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l77, !tbaa !24
  %t144 = load i64, ptr %l77, !tbaa !24
  %t145 = mul i64 %t144, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l78, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l77, !tbaa !24
  %t154 = mul i64 %t153, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %t152, i64 %t154, i1 false)
  %t155 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t155, ptr %l13, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t158 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t156, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t158, ptr %l80
  br label %bb38
bb38:
  %t159 = load i1, ptr %l80, !tbaa !21
  %t160 = xor i1 %t159, true
  br i1 %t160, label %bb39, label %bb40
bb39:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/emit:Emitter", ptr %t162, i32 0, i32 65
  store ptr %t164, ptr %l83, !tbaa !29
  %t165 = call ptr @__olang_scope_hold(ptr %v0)
  %t166 = ptrtoint ptr %t165 to i64
  store i64 %t166, ptr %l84, !tbaa !24
  %t167 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t167, label %bb41, label %bb42
bb40:
  br label %bb44
bb41:
  %t169 = call ptr @__olang_region_make(ptr %v0)
  %t170 = ptrtoint ptr %t169 to i64
  store i64 %t170, ptr %l84, !tbaa !24
  br label %bb42
bb42:
  %t171 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 1
  %t174 = extractvalue { i64, ptr } %t171, 0
  %t175 = load i64, ptr %l84
  %t176 = inttoptr i64 %t175 to ptr
  %t177 = call ptr @__olang_held_alloc(ptr %t176, i64 %t174)
  call void @olang_textcopy(ptr %t177, ptr %t173, i64 %t174)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t181 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t181, { i64, ptr } %t179)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/emit:Emitter", ptr %t183, i32 0, i32 65
  store ptr %t185, ptr %l90, !tbaa !29
  %t186 = call ptr @__olang_scope_hold(ptr %v0)
  %t187 = ptrtoint ptr %t186 to i64
  store i64 %t187, ptr %l91, !tbaa !24
  %t188 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t188, label %bb45, label %bb46
bb45:
  %t190 = call ptr @__olang_region_make(ptr %v0)
  %t191 = ptrtoint ptr %t190 to i64
  store i64 %t191, ptr %l91, !tbaa !24
  br label %bb46
bb46:
  %t192 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 1
  %t195 = extractvalue { i64, ptr } %t192, 0
  %t196 = load i64, ptr %l91
  %t197 = inttoptr i64 %t196 to ptr
  %t198 = call ptr @__olang_held_alloc(ptr %t197, i64 %t195)
  call void @olang_textcopy(ptr %t198, ptr %t194, i64 %t195)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t202 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t202, { i64, ptr } %t200)
  br label %bb47
bb47:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i64, ptr %l10, !tbaa !24
  %t208 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eInPart(ptr %v0, ptr %t204, i64 %t205)
  store i1 %t208, ptr %l98
  br label %bb48
bb48:
  %t209 = load i1, ptr %l98, !tbaa !21
  %t210 = xor i1 %t209, true
  br i1 %t210, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb50:
  br label %bb51
bb51:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l10, !tbaa !24
  %t215 = trunc i64 %t213 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t217
  %t218 = getelementptr { i64, [2 x i64] }, ptr %t217, i32 0, i32 0
  store i64 0, ptr %t218
  %t220 = insertvalue { i32 } undef, i32 %t215, 0
  %t221 = getelementptr { i64, [2 x i64] }, ptr %t217, i32 0, i32 1
  store { i32 } %t220, ptr %t221
  %t222 = load { i64, [2 x i64] }, ptr %t217
  %t225 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s7, ptr %t212, { i64, [2 x i64] } %t222)
  store { i64, ptr } %t225, ptr %l105
  br label %bb52
bb52:
  %t226 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t228 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = add i64 %t227, %t230
  %t232 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t226, i64 %t227)
  %t233 = getelementptr i8, ptr %t232, i64 %t227
  call void @olang_textcopy(ptr %t233, ptr %t229, i64 %t230)
  %t234 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t232, 1
  store { i64, ptr } %t235, ptr %l14, !tbaa !27
  store ptr %l7, ptr %l107, !tbaa !29
  %t237 = call ptr @__olang_scope_hold(ptr %s0)
  %t238 = ptrtoint ptr %t237 to i64
  store i64 %t238, ptr %l108, !tbaa !24
  %t239 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t239, label %bb53, label %bb54
bb53:
  %t241 = call ptr @__olang_region_make(ptr %s0)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l108, !tbaa !24
  br label %bb54
bb54:
  %t243 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t243, ptr %l110, !tbaa !27
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l111, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i64, ptr %l10, !tbaa !24
  %t249 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestName(ptr %v0, ptr %s7, ptr %t245, i64 %t246)
  store { i64, ptr } %t249, ptr %l114
  br label %bb55
bb55:
  %t250 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t251 = load ptr, ptr %l111, !tbaa !29
  %t253 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s7, ptr %s7, ptr %t251, { i64, ptr } %t250)
  store { i64, ptr } %t253, ptr %l116
  br label %bb56
bb56:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t258 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s7, ptr %s7, ptr %t254, { i64, ptr } %t255)
  store { i64, ptr } %t258, ptr %l119
  br label %bb57
bb57:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t263 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s7, ptr %s7, ptr %t259, { i64, ptr } %t260)
  store { i64, ptr } %t263, ptr %l122
  br label %bb58
bb58:
  %t264 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t266 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t280 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 1
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t283 = add i64 %t279, %t282
  %t284 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t286 = add i64 %t283, %t285
  %t287 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = add i64 %t286, %t289
  %t291 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t293 = add i64 %t290, %t292
  %t294 = load i64, ptr %l108
  %t295 = inttoptr i64 %t294 to ptr
  %t296 = call ptr @__olang_held_alloc(ptr %t295, i64 %t293)
  call void @olang_textcopy(ptr %t296, ptr %t264, i64 %t265)
  %t297 = getelementptr i8, ptr %t296, i64 %t265
  call void @olang_textcopy(ptr %t297, ptr %t267, i64 %t268)
  %t298 = getelementptr i8, ptr %t297, i64 %t268
  call void @olang_textcopy(ptr %t298, ptr %t270, i64 %t271)
  %t299 = getelementptr i8, ptr %t298, i64 %t271
  call void @olang_textcopy(ptr %t299, ptr %t274, i64 %t275)
  %t300 = getelementptr i8, ptr %t299, i64 %t275
  call void @olang_textcopy(ptr %t300, ptr %t277, i64 %t278)
  %t301 = getelementptr i8, ptr %t300, i64 %t278
  call void @olang_textcopy(ptr %t301, ptr %t281, i64 %t282)
  %t302 = getelementptr i8, ptr %t301, i64 %t282
  call void @olang_textcopy(ptr %t302, ptr %t284, i64 %t285)
  %t303 = getelementptr i8, ptr %t302, i64 %t285
  call void @olang_textcopy(ptr %t303, ptr %t288, i64 %t289)
  %t304 = getelementptr i8, ptr %t303, i64 %t289
  call void @olang_textcopy(ptr %t304, ptr %t291, i64 %t292)
  %t305 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t296, 1
  %t308 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t308, { i64, ptr } %t306)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb60:
  %t310 = load i64, ptr %l9, !tbaa !24
  %t313 = add i64 %t310, 1
  store i64 %t313, ptr %l9, !tbaa !24
  br label %bb31
bb61:
  %t315 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t315, ptr %l128
  br label %bb62
bb62:
  %t316 = load %"std/prelude/text:StringBuilder", ptr %l128
  store %"std/prelude/text:StringBuilder" %t316, ptr %l15
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/emit:Emitter", ptr %t317, i32 0, i32 68
  %t320 = load i1, ptr %t319, !tbaa !21
  br i1 %t320, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l15, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb65
bb64:
  br label %bb67
bb65:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l15, { i64, ptr } { i64 126, ptr getelementptr inbounds (<{ i64, [126 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  %t325 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t325, ptr %l134
  br label %bb68
bb68:
  %t326 = load i64, ptr %l134, !tbaa !24
  %t327 = icmp sgt i64 %t326, 0
  br i1 %t327, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s16
  store ptr %l15, ptr %l136, !tbaa !29
  %t330 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t330, ptr %l138
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t332 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s16, ptr %s16, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store { i64, ptr } %t332, ptr %l140
  br label %bb72
bb72:
  %t333 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t335 = load i64, ptr %l138, !tbaa !24
  %t336 = call i64 @__olang_fmt_i64(ptr null, i64 %t335)
  %t337 = add i64 %t334, %t336
  %t338 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t340 = add i64 %t337, %t339
  %t341 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = add i64 %t340, %t343
  %t345 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t346 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t347 = add i64 %t344, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t333, i64 %t334)
  %t349 = getelementptr i8, ptr %t348, i64 %t334
  %t350 = call i64 @__olang_fmt_i64(ptr %t349, i64 %t335)
  %t351 = getelementptr i8, ptr %t349, i64 %t336
  call void @olang_textcopy(ptr %t351, ptr %t338, i64 %t339)
  %t352 = getelementptr i8, ptr %t351, i64 %t339
  call void @olang_textcopy(ptr %t352, ptr %t342, i64 %t343)
  %t353 = getelementptr i8, ptr %t352, i64 %t343
  call void @olang_textcopy(ptr %t353, ptr %t345, i64 %t346)
  %t354 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t348, 1
  %t357 = load ptr, ptr %l136, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %t357, { i64, ptr } %t355)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s16)
  br label %bb74
bb74:
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t360, ptr %l144
  br label %bb75
bb75:
  %t361 = load i64, ptr %l144, !tbaa !24
  %t362 = icmp sgt i64 %t361, 0
  br i1 %t362, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %l15, ptr %l146, !tbaa !29
  %t365 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t365, ptr %l148
  br label %bb78
bb77:
  br label %bb96
bb78:
  %t367 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s18, ptr %s18, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store { i64, ptr } %t367, ptr %l150
  br label %bb79
bb79:
  %t368 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t370 = load i64, ptr %l148, !tbaa !24
  %t371 = call i64 @__olang_fmt_i64(ptr null, i64 %t370)
  %t372 = add i64 %t369, %t371
  %t373 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t374 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t375 = add i64 %t372, %t374
  %t376 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = add i64 %t375, %t378
  %t380 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t383 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t382)
  call void @olang_textcopy(ptr %t383, ptr %t368, i64 %t369)
  %t384 = getelementptr i8, ptr %t383, i64 %t369
  %t385 = call i64 @__olang_fmt_i64(ptr %t384, i64 %t370)
  %t386 = getelementptr i8, ptr %t384, i64 %t371
  call void @olang_textcopy(ptr %t386, ptr %t373, i64 %t374)
  %t387 = getelementptr i8, ptr %t386, i64 %t374
  call void @olang_textcopy(ptr %t387, ptr %t377, i64 %t378)
  %t388 = getelementptr i8, ptr %t387, i64 %t378
  call void @olang_textcopy(ptr %t388, ptr %t380, i64 %t381)
  %t389 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t383, 1
  %t392 = load ptr, ptr %l146, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t392, { i64, ptr } %t390)
  br label %bb80
bb80:
  %t394 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s18, ptr %s18, ptr %t394, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d74, i32 0, i32 1) }, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb81
bb81:
  %t396 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s18, ptr %s18, ptr %t396, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d76, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb82
bb82:
  %t398 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s18, ptr %s18, ptr %t398, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d78, i32 0, i32 1) }, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d79, i32 0, i32 1) })
  br label %bb83
bb83:
  %t400 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s18, ptr %s18, ptr %t400, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d80, i32 0, i32 1) }, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb84
bb84:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb85
bb85:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb86
bb86:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb87
bb87:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb88
bb88:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb89
bb89:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb90
bb90:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb91
bb91:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb92
bb92:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb93
bb93:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb94
bb94:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l15, { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d92, i32 0, i32 1) })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s18)
  br label %bb96
bb96:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = getelementptr %"compiler/emit:Emitter", ptr %t413, i32 0, i32 64
  %t416 = load { i64, ptr }, ptr %t415, !tbaa !27
  %t418 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t416, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t418, ptr %l170
  br label %bb97
bb97:
  %t419 = load i1, ptr %l170, !tbaa !21
  %t420 = xor i1 %t419, true
  br i1 %t420, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s20
  %t422 = load ptr, ptr %l0, !tbaa !29
  store ptr %t422, ptr %l172, !tbaa !29
  %t423 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t423, ptr %l173
  %t425 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s20, ptr %l173)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t425, ptr %l175
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t426 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t426, ptr %l176
  %t428 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s20, ptr %l176)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t428, ptr %l178
  br label %bb101
bb101:
  %t429 = load ptr, ptr %l172, !tbaa !29
  %t430 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l175
  %t431 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efuzzHarness(ptr %v0, ptr %s20, ptr %s20, ptr %s0, ptr %t429, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t430, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t431, ptr %l15)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb103:
  %t433 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSource(ptr %v0, ptr %t433)
  br label %bb104
bb104:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d94, i32 0, i32 1) })
  br label %bb105
bb105:
  store ptr %l15, ptr %l182, !tbaa !29
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ejmpBuf(ptr %v0, ptr %s0, ptr %t436)
  store { i64, ptr } %t438, ptr %l184
  br label %bb106
bb106:
  %t439 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t440 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t441 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 1
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = add i64 %t440, %t443
  %t445 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t447 = add i64 %t444, %t446
  %t448 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t447)
  call void @olang_textcopy(ptr %t448, ptr %t439, i64 %t440)
  %t449 = getelementptr i8, ptr %t448, i64 %t440
  call void @olang_textcopy(ptr %t449, ptr %t442, i64 %t443)
  %t450 = getelementptr i8, ptr %t449, i64 %t443
  call void @olang_textcopy(ptr %t450, ptr %t445, i64 %t446)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t448, 1
  %t454 = load ptr, ptr %l182, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t454, { i64, ptr } %t452)
  br label %bb107
bb107:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb108
bb108:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb109
bb109:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb110
bb110:
  store ptr %l15, ptr %l190, !tbaa !29
  %t459 = load ptr, ptr %l0, !tbaa !29
  store ptr %t459, ptr %l191, !tbaa !29
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/emit:Emitter", ptr %t460, i32 0, i32 0
  %t463 = load ptr, ptr %t462, !tbaa !29
  %t465 = getelementptr %"compiler/generic:Program", ptr %t463, i32 0, i32 0
  %t466 = load ptr, ptr %t465, !tbaa !29
  %t468 = getelementptr %"compiler/load:Loader", ptr %t466, i32 0, i32 10
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/emit:Emitter", ptr %t469, i32 0, i32 0
  %t472 = load ptr, ptr %t471, !tbaa !29
  %t474 = getelementptr %"compiler/generic:Program", ptr %t472, i32 0, i32 0
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = getelementptr %"compiler/load:Loader", ptr %t475, i32 0, i32 12
  %t478 = load i64, ptr %t477, !tbaa !24
  %t481 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t468, i64 %t478)
  store ptr %t481, ptr %l200
  br label %bb111
bb111:
  %t482 = load ptr, ptr %l200, !tbaa !29
  %t484 = getelementptr %"compiler/load:Module", ptr %t482, i32 0, i32 0
  %t485 = load { i64, ptr }, ptr %t484, !tbaa !27
  %t486 = load ptr, ptr %l191, !tbaa !29
  %t488 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v0, ptr %s0, ptr %t486, { i64, ptr } %t485)
  store { i64, ptr } %t488, ptr %l203
  br label %bb112
bb112:
  %t489 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t491 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t498 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t497)
  call void @olang_textcopy(ptr %t498, ptr %t489, i64 %t490)
  %t499 = getelementptr i8, ptr %t498, i64 %t490
  call void @olang_textcopy(ptr %t499, ptr %t492, i64 %t493)
  %t500 = getelementptr i8, ptr %t499, i64 %t493
  call void @olang_textcopy(ptr %t500, ptr %t495, i64 %t496)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t498, 1
  %t504 = load ptr, ptr %l190, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t504, { i64, ptr } %t502)
  br label %bb113
bb113:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d102, i32 0, i32 1) })
  br label %bb114
bb114:
  %t507 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %s0, ptr %t507, ptr %l15)
  br label %bb115
bb115:
  %t511 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t511, ptr %l210
  br label %bb116
bb116:
  %t512 = load i64, ptr %l210, !tbaa !24
  %t513 = icmp sgt i64 %t512, 0
  br i1 %t513, label %bb117, label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s23
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb119
bb118:
  br label %bb130
bb119:
  store ptr %l15, ptr %l213, !tbaa !29
  %t517 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t517, ptr %l215
  br label %bb120
bb120:
  %t518 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t519 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t520 = load i64, ptr %l215, !tbaa !24
  %t521 = call i64 @__olang_fmt_i64(ptr null, i64 %t520)
  %t522 = add i64 %t519, %t521
  %t523 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t524 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t525 = add i64 %t522, %t524
  %t526 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t525)
  call void @olang_textcopy(ptr %t526, ptr %t518, i64 %t519)
  %t527 = getelementptr i8, ptr %t526, i64 %t519
  %t528 = call i64 @__olang_fmt_i64(ptr %t527, i64 %t520)
  %t529 = getelementptr i8, ptr %t527, i64 %t521
  call void @olang_textcopy(ptr %t529, ptr %t523, i64 %t524)
  %t530 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t531 = insertvalue { i64, ptr } %t530, ptr %t526, 1
  %t533 = load ptr, ptr %l213, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t533, { i64, ptr } %t531)
  br label %bb121
bb121:
  store ptr %l15, ptr %l218, !tbaa !29
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esetjmpCall(ptr %v0, ptr %s23, ptr %t535)
  store { i64, ptr } %t537, ptr %l220
  br label %bb122
bb122:
  %t538 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t539 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t540 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 1
  %t542 = extractvalue { i64, ptr } %t540, 0
  %t543 = add i64 %t539, %t542
  %t544 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t545 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t546 = add i64 %t543, %t545
  %t547 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t546)
  call void @olang_textcopy(ptr %t547, ptr %t538, i64 %t539)
  %t548 = getelementptr i8, ptr %t547, i64 %t539
  call void @olang_textcopy(ptr %t548, ptr %t541, i64 %t542)
  %t549 = getelementptr i8, ptr %t548, i64 %t542
  call void @olang_textcopy(ptr %t549, ptr %t544, i64 %t545)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t547, 1
  %t553 = load ptr, ptr %l218, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t553, { i64, ptr } %t551)
  br label %bb123
bb123:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb124
bb124:
  store ptr %l15, ptr %l224, !tbaa !29
  %t557 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t557, ptr %l226
  br label %bb125
bb125:
  %t558 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t560 = load i64, ptr %l226, !tbaa !24
  %t561 = call i64 @__olang_fmt_i64(ptr null, i64 %t560)
  %t562 = add i64 %t559, %t561
  %t563 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t564 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t565 = add i64 %t562, %t564
  %t566 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t565)
  call void @olang_textcopy(ptr %t566, ptr %t558, i64 %t559)
  %t567 = getelementptr i8, ptr %t566, i64 %t559
  %t568 = call i64 @__olang_fmt_i64(ptr %t567, i64 %t560)
  %t569 = getelementptr i8, ptr %t567, i64 %t561
  call void @olang_textcopy(ptr %t569, ptr %t563, i64 %t564)
  %t570 = insertvalue { i64, ptr } undef, i64 %t565, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t566, 1
  %t573 = load ptr, ptr %l224, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t573, { i64, ptr } %t571)
  br label %bb126
bb126:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb127
bb127:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb128
bb128:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s23)
  br label %bb130
bb130:
  %t579 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t579, ptr %l233
  br label %bb131
bb131:
  %t580 = load i64, ptr %l233, !tbaa !24
  %t581 = icmp sgt i64 %t580, 0
  br i1 %t581, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s27
  %t584 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t584, ptr %l236
  br label %bb134
bb133:
  br label %bb174
bb134:
  %t585 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t586 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t587 = load i64, ptr %l236, !tbaa !24
  %t588 = call i64 @__olang_fmt_i64(ptr null, i64 %t587)
  %t589 = add i64 %t586, %t588
  %t590 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t591 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t592 = add i64 %t589, %t591
  %t593 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t592)
  call void @olang_textcopy(ptr %t593, ptr %t585, i64 %t586)
  %t594 = getelementptr i8, ptr %t593, i64 %t586
  %t595 = call i64 @__olang_fmt_i64(ptr %t594, i64 %t587)
  %t596 = getelementptr i8, ptr %t594, i64 %t588
  call void @olang_textcopy(ptr %t596, ptr %t590, i64 %t591)
  %t597 = insertvalue { i64, ptr } undef, i64 %t592, 0
  %t598 = insertvalue { i64, ptr } %t597, ptr %t593, 1
  store { i64, ptr } %t598, ptr %l16, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb135
bb135:
  store ptr %l15, ptr %l239, !tbaa !29
  %t602 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t602, ptr %l241
  br label %bb136
bb136:
  %t603 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t604 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t605 = load i64, ptr %l241, !tbaa !24
  %t606 = call i64 @__olang_fmt_i64(ptr null, i64 %t605)
  %t607 = add i64 %t604, %t606
  %t608 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t609 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t610 = add i64 %t607, %t609
  %t611 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t610)
  call void @olang_textcopy(ptr %t611, ptr %t603, i64 %t604)
  %t612 = getelementptr i8, ptr %t611, i64 %t604
  %t613 = call i64 @__olang_fmt_i64(ptr %t612, i64 %t605)
  %t614 = getelementptr i8, ptr %t612, i64 %t606
  call void @olang_textcopy(ptr %t614, ptr %t608, i64 %t609)
  %t615 = insertvalue { i64, ptr } undef, i64 %t610, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t611, 1
  %t618 = load ptr, ptr %l239, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t618, { i64, ptr } %t616)
  br label %bb137
bb137:
  %t620 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t621 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t622 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t624 = extractvalue { i64, ptr } %t620, 1
  %t625 = extractvalue { i64, ptr } %t620, 0
  %t626 = add i64 %t622, %t625
  %t627 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t628 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t629 = add i64 %t626, %t628
  %t630 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t629)
  call void @olang_textcopy(ptr %t630, ptr %t621, i64 %t622)
  %t631 = getelementptr i8, ptr %t630, i64 %t622
  call void @olang_textcopy(ptr %t631, ptr %t624, i64 %t625)
  %t632 = getelementptr i8, ptr %t631, i64 %t625
  call void @olang_textcopy(ptr %t632, ptr %t627, i64 %t628)
  %t633 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t634 = insertvalue { i64, ptr } %t633, ptr %t630, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } %t634)
  br label %bb138
bb138:
  %t638 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t639 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t640 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t642 = extractvalue { i64, ptr } %t638, 1
  %t643 = extractvalue { i64, ptr } %t638, 0
  %t644 = add i64 %t640, %t643
  %t645 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t646 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t647 = add i64 %t644, %t646
  %t648 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t647)
  call void @olang_textcopy(ptr %t648, ptr %t639, i64 %t640)
  %t649 = getelementptr i8, ptr %t648, i64 %t640
  call void @olang_textcopy(ptr %t649, ptr %t642, i64 %t643)
  %t650 = getelementptr i8, ptr %t649, i64 %t643
  call void @olang_textcopy(ptr %t650, ptr %t645, i64 %t646)
  %t651 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t648, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } %t652)
  br label %bb139
bb139:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d123, i32 0, i32 1) })
  br label %bb140
bb140:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d124, i32 0, i32 1) })
  br label %bb141
bb141:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d125, i32 0, i32 1) })
  br label %bb142
bb142:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d126, i32 0, i32 1) })
  br label %bb143
bb143:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d127, i32 0, i32 1) })
  br label %bb144
bb144:
  store ptr %l15, ptr %l257, !tbaa !29
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esetjmpCall(ptr %v0, ptr %s27, ptr %t661)
  store { i64, ptr } %t663, ptr %l259
  br label %bb145
bb145:
  %t664 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t665 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t666 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t666, 1
  %t668 = extractvalue { i64, ptr } %t666, 0
  %t669 = add i64 %t665, %t668
  %t670 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t671 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t672 = add i64 %t669, %t671
  %t673 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t672)
  call void @olang_textcopy(ptr %t673, ptr %t664, i64 %t665)
  %t674 = getelementptr i8, ptr %t673, i64 %t665
  call void @olang_textcopy(ptr %t674, ptr %t667, i64 %t668)
  %t675 = getelementptr i8, ptr %t674, i64 %t668
  call void @olang_textcopy(ptr %t675, ptr %t670, i64 %t671)
  %t676 = insertvalue { i64, ptr } undef, i64 %t672, 0
  %t677 = insertvalue { i64, ptr } %t676, ptr %t673, 1
  %t679 = load ptr, ptr %l257, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t679, { i64, ptr } %t677)
  br label %bb146
bb146:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb147
bb147:
  %t682 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t683 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t684 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t686 = extractvalue { i64, ptr } %t682, 1
  %t687 = extractvalue { i64, ptr } %t682, 0
  %t688 = add i64 %t684, %t687
  %t689 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t690 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t691 = add i64 %t688, %t690
  %t692 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t691)
  call void @olang_textcopy(ptr %t692, ptr %t683, i64 %t684)
  %t693 = getelementptr i8, ptr %t692, i64 %t684
  call void @olang_textcopy(ptr %t693, ptr %t686, i64 %t687)
  %t694 = getelementptr i8, ptr %t693, i64 %t687
  call void @olang_textcopy(ptr %t694, ptr %t689, i64 %t690)
  %t695 = insertvalue { i64, ptr } undef, i64 %t691, 0
  %t696 = insertvalue { i64, ptr } %t695, ptr %t692, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } %t696)
  br label %bb148
bb148:
  %t700 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t701 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t702 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t704 = extractvalue { i64, ptr } %t700, 1
  %t705 = extractvalue { i64, ptr } %t700, 0
  %t706 = add i64 %t702, %t705
  %t707 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t708 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t709 = add i64 %t706, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t701, i64 %t702)
  %t711 = getelementptr i8, ptr %t710, i64 %t702
  call void @olang_textcopy(ptr %t711, ptr %t704, i64 %t705)
  %t712 = getelementptr i8, ptr %t711, i64 %t705
  call void @olang_textcopy(ptr %t712, ptr %t707, i64 %t708)
  %t713 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t710, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } %t714)
  br label %bb149
bb149:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d135, i32 0, i32 1) })
  br label %bb150
bb150:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d136, i32 0, i32 1) })
  br label %bb151
bb151:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb152
bb152:
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t723 = getelementptr %"compiler/emit:Emitter", ptr %t721, i32 0, i32 68
  %t724 = load i1, ptr %t723, !tbaa !21
  br i1 %t724, label %bb153, label %bb154
bb153:
  store %olang.scope zeroinitializer, ptr %s35
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s35, ptr %l15, { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d138, i32 0, i32 1) })
  br label %bb155
bb154:
  br label %bb156
bb155:
  call void @__olang_scope_close(ptr %s35)
  br label %bb156
bb156:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb157
bb157:
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = getelementptr %"compiler/emit:Emitter", ptr %t728, i32 0, i32 68
  %t731 = load i1, ptr %t730, !tbaa !21
  br i1 %t731, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s36
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s36, ptr %l15, { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d140, i32 0, i32 1) })
  br label %bb160
bb159:
  br label %bb166
bb160:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s36, ptr %l15, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d141, i32 0, i32 1) })
  br label %bb161
bb161:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s36, ptr %l15, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d142, i32 0, i32 1) })
  br label %bb162
bb162:
  store ptr %l15, ptr %l283, !tbaa !29
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t738 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s36, ptr %s36, ptr %t736, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store { i64, ptr } %t738, ptr %l285
  br label %bb163
bb163:
  %t739 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t740 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t741 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t742 = extractvalue { i64, ptr } %t741, 1
  %t743 = extractvalue { i64, ptr } %t741, 0
  %t744 = add i64 %t740, %t743
  %t745 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t747 = add i64 %t744, %t746
  %t748 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t747)
  call void @olang_textcopy(ptr %t748, ptr %t739, i64 %t740)
  %t749 = getelementptr i8, ptr %t748, i64 %t740
  call void @olang_textcopy(ptr %t749, ptr %t742, i64 %t743)
  %t750 = getelementptr i8, ptr %t749, i64 %t743
  call void @olang_textcopy(ptr %t750, ptr %t745, i64 %t746)
  %t751 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t752 = insertvalue { i64, ptr } %t751, ptr %t748, 1
  %t754 = load ptr, ptr %l283, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s36, ptr %t754, { i64, ptr } %t752)
  br label %bb164
bb164:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s36, ptr %l15, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d146, i32 0, i32 1) })
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s36)
  br label %bb166
bb166:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d147, i32 0, i32 1) })
  br label %bb167
bb167:
  store ptr %l15, ptr %l290, !tbaa !29
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t760 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s27, ptr %s27, ptr %t758, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d148, i32 0, i32 1) })
  store { i64, ptr } %t760, ptr %l292
  br label %bb168
bb168:
  %t761 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t762 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t763 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t763, 1
  %t765 = extractvalue { i64, ptr } %t763, 0
  %t766 = add i64 %t762, %t765
  %t767 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t768 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t769 = add i64 %t766, %t768
  %t770 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t769)
  call void @olang_textcopy(ptr %t770, ptr %t761, i64 %t762)
  %t771 = getelementptr i8, ptr %t770, i64 %t762
  call void @olang_textcopy(ptr %t771, ptr %t764, i64 %t765)
  %t772 = getelementptr i8, ptr %t771, i64 %t765
  call void @olang_textcopy(ptr %t772, ptr %t767, i64 %t768)
  %t773 = insertvalue { i64, ptr } undef, i64 %t769, 0
  %t774 = insertvalue { i64, ptr } %t773, ptr %t770, 1
  %t776 = load ptr, ptr %l290, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t776, { i64, ptr } %t774)
  br label %bb169
bb169:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d151, i32 0, i32 1) })
  br label %bb170
bb170:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d152, i32 0, i32 1) })
  br label %bb171
bb171:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d153, i32 0, i32 1) })
  br label %bb172
bb172:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l15, { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d154, i32 0, i32 1) })
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s27)
  br label %bb174
bb174:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d155, i32 0, i32 1) })
  br label %bb175
bb175:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d156, i32 0, i32 1) })
  br label %bb176
bb176:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d157, i32 0, i32 1) })
  br label %bb177
bb177:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d158, i32 0, i32 1) })
  br label %bb178
bb178:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d159, i32 0, i32 1) })
  br label %bb179
bb179:
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t789 = getelementptr %"compiler/emit:Emitter", ptr %t787, i32 0, i32 66
  %t790 = load i64, ptr %t789, !tbaa !24
  %t792 = icmp ne i64 %t790, 0
  br i1 %t792, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s39
  %t794 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s39, ptr %s39, ptr %t794, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d160, i32 0, i32 1) }, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d161, i32 0, i32 1) })
  br label %bb182
bb181:
  br label %bb195
bb182:
  %t796 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s39, ptr %s39, ptr %t796, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d162, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d163, i32 0, i32 1) })
  br label %bb183
bb183:
  %t798 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s39, ptr %s39, ptr %t798, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d164, i32 0, i32 1) }, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d165, i32 0, i32 1) })
  br label %bb184
bb184:
  %t800 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s39, ptr %s39, ptr %t800, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d166, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d167, i32 0, i32 1) })
  br label %bb185
bb185:
  store ptr %l15, ptr %l311, !tbaa !29
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t804 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s39, ptr %s39, ptr %t802, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d168, i32 0, i32 1) })
  store { i64, ptr } %t804, ptr %l313
  br label %bb186
bb186:
  %t805 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t806 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t807 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t807, 1
  %t809 = extractvalue { i64, ptr } %t807, 0
  %t810 = add i64 %t806, %t809
  %t811 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t812 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t813 = add i64 %t810, %t812
  %t814 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t813)
  call void @olang_textcopy(ptr %t814, ptr %t805, i64 %t806)
  %t815 = getelementptr i8, ptr %t814, i64 %t806
  call void @olang_textcopy(ptr %t815, ptr %t808, i64 %t809)
  %t816 = getelementptr i8, ptr %t815, i64 %t809
  call void @olang_textcopy(ptr %t816, ptr %t811, i64 %t812)
  %t817 = insertvalue { i64, ptr } undef, i64 %t813, 0
  %t818 = insertvalue { i64, ptr } %t817, ptr %t814, 1
  %t820 = load ptr, ptr %l311, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %t820, { i64, ptr } %t818)
  br label %bb187
bb187:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %l15, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d171, i32 0, i32 1) })
  br label %bb188
bb188:
  store ptr %l15, ptr %l317, !tbaa !29
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t825 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s39, ptr %s39, ptr %t823, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) })
  store { i64, ptr } %t825, ptr %l319
  br label %bb189
bb189:
  %t826 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t827 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t828 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t829 = extractvalue { i64, ptr } %t828, 1
  %t830 = extractvalue { i64, ptr } %t828, 0
  %t831 = add i64 %t827, %t830
  %t832 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t833 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t834 = add i64 %t831, %t833
  %t835 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t834)
  call void @olang_textcopy(ptr %t835, ptr %t826, i64 %t827)
  %t836 = getelementptr i8, ptr %t835, i64 %t827
  call void @olang_textcopy(ptr %t836, ptr %t829, i64 %t830)
  %t837 = getelementptr i8, ptr %t836, i64 %t830
  call void @olang_textcopy(ptr %t837, ptr %t832, i64 %t833)
  %t838 = insertvalue { i64, ptr } undef, i64 %t834, 0
  %t839 = insertvalue { i64, ptr } %t838, ptr %t835, 1
  %t841 = load ptr, ptr %l317, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %t841, { i64, ptr } %t839)
  br label %bb190
bb190:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %l15, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d175, i32 0, i32 1) })
  br label %bb191
bb191:
  store ptr %l15, ptr %l323, !tbaa !29
  %t844 = load ptr, ptr %l0, !tbaa !29
  %t846 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s39, ptr %s39, ptr %t844, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d176, i32 0, i32 1) })
  store { i64, ptr } %t846, ptr %l325
  br label %bb192
bb192:
  %t847 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t848 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t849 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t850 = extractvalue { i64, ptr } %t849, 1
  %t851 = extractvalue { i64, ptr } %t849, 0
  %t852 = add i64 %t848, %t851
  %t853 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t854 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t855 = add i64 %t852, %t854
  %t856 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t855)
  call void @olang_textcopy(ptr %t856, ptr %t847, i64 %t848)
  %t857 = getelementptr i8, ptr %t856, i64 %t848
  call void @olang_textcopy(ptr %t857, ptr %t850, i64 %t851)
  %t858 = getelementptr i8, ptr %t857, i64 %t851
  call void @olang_textcopy(ptr %t858, ptr %t853, i64 %t854)
  %t859 = insertvalue { i64, ptr } undef, i64 %t855, 0
  %t860 = insertvalue { i64, ptr } %t859, ptr %t856, 1
  %t862 = load ptr, ptr %l323, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %t862, { i64, ptr } %t860)
  br label %bb193
bb193:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s39, ptr %l15, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d179, i32 0, i32 1) })
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s39)
  br label %bb195
bb195:
  store ptr %l15, ptr %l329, !tbaa !29
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t867 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %t865, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store { i64, ptr } %t867, ptr %l331
  br label %bb196
bb196:
  %t868 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t869 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t870 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t871 = extractvalue { i64, ptr } %t870, 1
  %t872 = extractvalue { i64, ptr } %t870, 0
  %t873 = add i64 %t869, %t872
  %t874 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t875 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t876 = add i64 %t873, %t875
  %t877 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t876)
  call void @olang_textcopy(ptr %t877, ptr %t868, i64 %t869)
  %t878 = getelementptr i8, ptr %t877, i64 %t869
  call void @olang_textcopy(ptr %t878, ptr %t871, i64 %t872)
  %t879 = getelementptr i8, ptr %t878, i64 %t872
  call void @olang_textcopy(ptr %t879, ptr %t874, i64 %t875)
  %t880 = insertvalue { i64, ptr } undef, i64 %t876, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t877, 1
  %t883 = load ptr, ptr %l329, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t883, { i64, ptr } %t881)
  br label %bb197
bb197:
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t887 = getelementptr %"compiler/emit:Emitter", ptr %t885, i32 0, i32 66
  %t888 = load i64, ptr %t887, !tbaa !24
  %t890 = icmp ne i64 %t888, 0
  br i1 %t890, label %bb198, label %bb199
bb198:
  store %olang.scope zeroinitializer, ptr %s44
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s44, ptr %l15, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d183, i32 0, i32 1) })
  br label %bb200
bb199:
  br label %bb201
bb200:
  call void @__olang_scope_close(ptr %s44)
  br label %bb201
bb201:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb202
bb202:
  %t894 = load ptr, ptr %l0, !tbaa !29
  store ptr %t894, ptr %l339, !tbaa !29
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t897 = getelementptr %"compiler/emit:Emitter", ptr %t895, i32 0, i32 0
  %t898 = load ptr, ptr %t897, !tbaa !29
  %t900 = getelementptr %"compiler/generic:Program", ptr %t898, i32 0, i32 0
  %t901 = load ptr, ptr %t900, !tbaa !29
  %t903 = getelementptr %"compiler/load:Loader", ptr %t901, i32 0, i32 12
  %t904 = load i64, ptr %t903, !tbaa !24
  store i64 %t904, ptr %l343, !tbaa !24
  %t906 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l15)
  store { i64, ptr } %t906, ptr %l345
  br label %bb203
bb203:
  %t907 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t908 = load ptr, ptr %l339, !tbaa !29
  %t909 = load i64, ptr %l343, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t908, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d185, i32 0, i32 1) }, i64 %t909, { i64, ptr } %t907, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epartOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i64
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %t6, i64 %t7)
  store i1 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t12, i32 0, i32 85
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t14, i64 %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l18
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l17
  br label %bb7
bb6:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb11
bb7:
  %t25 = load i64, ptr %l17, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  %t28 = load i64, ptr %l13, !tbaa !24
  store i64 %t28, ptr %l12, !tbaa !24
  br label %bb11
bb11:
  %t29 = load i64, ptr %l12, !tbaa !24
  store i64 %t29, ptr %l3, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 22
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:Emitter", ptr %t33, i32 0, i32 94
  %t36 = load i1, ptr %t35, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/emit:Emitter", ptr %t38, i32 0, i32 96
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l29
  br label %bb14
bb13:
  %t45 = load i64, ptr %l3, !tbaa !24
  store i64 %t45, ptr %l25, !tbaa !24
  br label %bb15
bb14:
  %t47 = load i64, ptr %l29, !tbaa !24
  store i64 %t47, ptr %l25, !tbaa !24
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l22, !tbaa !29
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t50, ptr %l31
  br label %bb16
bb16:
  %t51 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d186, i32 0, i32 1) })
  store i1 %t54, ptr %l33
  br label %bb17
bb17:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb18, label %bb19
bb18:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb21
bb19:
  %t56 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t58 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %t56)
  store i64 %t58, ptr %l36
  br label %bb20
bb20:
  %t59 = load i64, ptr %l36, !tbaa !24
  store i64 %t59, ptr %l34, !tbaa !24
  br label %bb21
bb21:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load i64, ptr %l34, !tbaa !24
  %t63 = srem i64 %t61, %t60
  store i64 %t63, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = add i64 %t69, %t70
  store i64 %t73, ptr %l41, !tbaa !24
  br label %bb24
bb23:
  %t75 = load i64, ptr %l5, !tbaa !24
  store i64 %t75, ptr %l41, !tbaa !24
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i64, ptr %l41, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i32
  %l33 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %t15, i64 %t18)
  store { i64, ptr } %t21, ptr %l22
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb48
bb5:
  %t23 = load { i64, [2 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 3
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 10}
  store i32 %t30, ptr %l4
  %t32 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { i32, i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i32, ptr %l4, !range !{i32 0, i32 10}
  store i32 %t36, ptr %l27
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l30
  br label %bb9
bb9:
  %t42 = load i32, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l30, !tbaa !23
  %t45 = icmp eq i32 %t43, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t48 = load i32, ptr %l5, !tbaa !23
  %t50 = inttoptr i64 0 to ptr
  %t53 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t50, ptr %t47, i32 %t48)
  store { i64, ptr } %t53, ptr %l37
  br label %bb12
bb11:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i32, ptr %l5, !tbaa !23
  %t57 = inttoptr i64 0 to ptr
  %t60 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %s2, ptr %t57, ptr %t54, i32 %t55)
  store { i64, ptr } %t60, ptr %l41
  br label %bb13
bb12:
  %t61 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  br label %bb14
bb13:
  %t62 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t62, ptr %l33, !tbaa !27
  br label %bb14
bb14:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t63 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t63, i64 %t64)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %s3, ptr %l27, i64 0)
  br label %bb15
bb15:
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t66, i64 %t67)
  %t68 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  call void @__olang_sb_put(ptr %s3, ptr %t69, i64 %t70)
  %t71 = load ptr, ptr %s3
  %t72 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t71, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l43, !tbaa !27
  %t77 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t78 = load ptr, ptr %t77
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %sbgrew.80, label %sbdone.81
sbgrew.80:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.81
sbdone.81:
  %t82 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s2, ptr %v1, { i64, ptr } %t82)
  store { i64, ptr } %t84, ptr %l45
  br label %bb16
bb16:
  %t85 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t85, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb17:
  %t86 = load { i64, [2 x i64] }, ptr %l1
  %t88 = extractvalue { i64, [2 x i64] } %t86, 0
  %t89 = icmp eq i64 %t88, 1
  br i1 %t89, label %bb18, label %bb19
bb18:
  %t91 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t92 = getelementptr { i32 }, ptr %t91, i32 0, i32 0
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l6, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l6, !tbaa !23
  %t98 = sext i32 %t96 to i64
  %t101 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s4, ptr %t95, i64 %t98)
  store { i64, ptr } %t101, ptr %l52
  br label %bb21
bb21:
  %t102 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t107 = add i64 %t104, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t103, i64 %t104)
  %t109 = getelementptr i8, ptr %t108, i64 %t104
  call void @olang_textcopy(ptr %t109, ptr %t105, i64 %t106)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  store { i64, ptr } %t111, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb48
bb22:
  %t113 = load { i64, [2 x i64] }, ptr %l1
  %t115 = extractvalue { i64, [2 x i64] } %t113, 0
  %t116 = icmp eq i64 %t115, 2
  br i1 %t116, label %bb23, label %bb24
bb23:
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { i32 }, ptr %t118, i32 0, i32 0
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l7, !tbaa !23
  br label %bb25
bb24:
  br label %bb27
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l7, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t128 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s6, ptr %t122, i64 %t125)
  store { i64, ptr } %t128, ptr %l60
  br label %bb26
bb26:
  %t129 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t130, i64 %t131)
  %t136 = getelementptr i8, ptr %t135, i64 %t131
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb27:
  %t140 = load { i64, [2 x i64] }, ptr %l1
  %t142 = extractvalue { i64, [2 x i64] } %t140, 0
  %t143 = icmp eq i64 %t142, 6
  br i1 %t143, label %bb28, label %bb29
bb28:
  %t145 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t146 = getelementptr { i32, i64 }, ptr %t145, i32 0, i32 0
  %t147 = load i32, ptr %t146
  store i32 %t147, ptr %l8, !tbaa !23
  %t149 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t150 = getelementptr { i32, i64 }, ptr %t149, i32 0, i32 1
  %t151 = load i64, ptr %t150
  store i64 %t151, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  br label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l8, !tbaa !23
  %t156 = sext i32 %t154 to i64
  %t159 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s8, ptr %t153, i64 %t156)
  store { i64, ptr } %t159, ptr %l69
  br label %bb31
bb31:
  %t160 = load i64, ptr %l9, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t168 = call i64 @__olang_fmt_i64(ptr null, i64 %t160)
  %t169 = add i64 %t166, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t162, i64 %t163)
  %t171 = getelementptr i8, ptr %t170, i64 %t163
  call void @olang_textcopy(ptr %t171, ptr %t164, i64 %t165)
  %t172 = getelementptr i8, ptr %t171, i64 %t165
  %t173 = call i64 @__olang_fmt_i64(ptr %t172, i64 %t160)
  %t174 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t170, 1
  store { i64, ptr } %t175, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb32:
  %t177 = load { i64, [2 x i64] }, ptr %l1
  %t179 = extractvalue { i64, [2 x i64] } %t177, 0
  %t180 = icmp eq i64 %t179, 4
  br i1 %t180, label %bb33, label %bb34
bb33:
  %t182 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t183 = getelementptr { i64 }, ptr %t182, i32 0, i32 0
  %t184 = load i64, ptr %t183
  store i64 %t184, ptr %l10, !tbaa !24
  br label %bb35
bb34:
  br label %bb38
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/emit:Emitter", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/generic:Program", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/load:Loader", ptr %t192, i32 0, i32 10
  %t195 = load i64, ptr %l10, !tbaa !24
  %t198 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t194, i64 %t195)
  store ptr %t198, ptr %l80
  br label %bb36
bb36:
  %t199 = load ptr, ptr %l80, !tbaa !29
  %t201 = getelementptr %"compiler/load:Module", ptr %t199, i32 0, i32 2
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t203 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t206 = extractvalue { i64, ptr } %t202, 1
  %t207 = extractvalue { i64, ptr } %t202, 0
  %t208 = add i64 %t204, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t203, i64 %t204)
  %t210 = getelementptr i8, ptr %t209, i64 %t204
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t209, 1
  %t215 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s10, ptr %v1, { i64, ptr } %t212)
  store { i64, ptr } %t215, ptr %l85
  br label %bb37
bb37:
  %t216 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t216, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb38:
  %t217 = load { i64, [2 x i64] }, ptr %l1
  %t219 = extractvalue { i64, [2 x i64] } %t217, 0
  %t220 = icmp eq i64 %t219, 5
  br i1 %t220, label %bb39, label %bb40
bb39:
  %t222 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t223 = getelementptr { i64, i1 }, ptr %t222, i32 0, i32 0
  %t224 = load i64, ptr %t223
  store i64 %t224, ptr %l11, !tbaa !24
  %t226 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t227 = getelementptr { i64, i1 }, ptr %t226, i32 0, i32 1
  %t228 = load i1, ptr %t227
  store i1 %t228, ptr %l12, !tbaa !21
  br label %bb41
bb40:
  br label %bb47
bb41:
  store %olang.scope zeroinitializer, ptr %s12
  %t230 = load i1, ptr %l12, !tbaa !21
  br i1 %t230, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d193, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d194, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb44
bb44:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l11, !tbaa !24
  %t236 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s12, ptr %t232, i64 %t233)
  store { i64, ptr } %t236, ptr %l94
  br label %bb45
bb45:
  %t237 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t239 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t246 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 1
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t249 = add i64 %t245, %t248
  %t250 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t249)
  call void @olang_textcopy(ptr %t250, ptr %t237, i64 %t238)
  %t251 = getelementptr i8, ptr %t250, i64 %t238
  call void @olang_textcopy(ptr %t251, ptr %t240, i64 %t241)
  %t252 = getelementptr i8, ptr %t251, i64 %t241
  call void @olang_textcopy(ptr %t252, ptr %t243, i64 %t244)
  %t253 = getelementptr i8, ptr %t252, i64 %t244
  call void @olang_textcopy(ptr %t253, ptr %t247, i64 %t248)
  %t254 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t250, 1
  %t258 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s12, ptr %v1, { i64, ptr } %t255)
  store { i64, ptr } %t258, ptr %l97
  br label %bb46
bb46:
  %t259 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t259, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_325a0aca37049b03_8faf0435ed6a0227)
  unreachable
bb48:
  %t260 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t260, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypesNamedIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i32
  %l65 = alloca i1
  %l68 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2erefsIn(ptr %v1, ptr %s0, { i64, ptr } %t1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t6, ptr %l15
  br label %bb2
bb2:
  %t7 = load i64, ptr %l15, !tbaa !24
  store i64 %t7, ptr %l6, !tbaa !24
  store i64 3, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l7, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  br label %bb38
bb11:
  br label %bb12
bb12:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t54)
  store i64 %t57, ptr %l42
  br label %bb13
bb13:
  %t58 = load i64, ptr %l42, !tbaa !24
  %t59 = icmp ne i64 %t58, 1
  br i1 %t59, label %bb14, label %bb15
bb14:
  br label %bb37
bb15:
  br label %bb16
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/emit:Emitter", ptr %t61, i32 0, i32 60
  store ptr %t63, ptr %l46, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t64, ptr %l47, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = add i64 %t65, 1
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t67)
  store i64 %t70, ptr %l51
  br label %bb17
bb17:
  %t71 = load i64, ptr %l10, !tbaa !24
  %t73 = add i64 %t71, 2
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t73)
  store i64 %t76, ptr %l55
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l56, !tbaa !24
  %t79 = load i64, ptr %l51, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load i64, ptr %l51, !tbaa !24
  %t83 = load i64, ptr %l55, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c5f6c8e5cb109282_c1c50765d35d3abe)
  unreachable
bb21:
  %t86 = load i64, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l56, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c5f6c8e5cb109282_c1c50765d35d3abe)
  unreachable
bb23:
  %t90 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l51, !tbaa !24
  %t93 = load i64, ptr %l55, !tbaa !24
  %t94 = getelementptr i8, ptr %t91, i64 %t92
  %t95 = sub i64 %t93, %t92
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  %t98 = load ptr, ptr %l46, !tbaa !29
  %t100 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t98, { i64, ptr } %t97)
  %t101 = extractvalue { i32, i64 } %t100, 1
  %t102 = extractvalue { i32, i64 } %t100, 0
  store i32 %t102, ptr %l62
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb26, label %ok.104, !prof !99
ok.104:
  store i64 %t101, ptr %l61
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_c5f6c8e5cb109282_c1c50765d35d3abe)
  unreachable
bb25:
  %t105 = load i64, ptr %l61, !tbaa !24
  store i64 %t105, ptr %l44, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l44, !tbaa !24
  br label %bb28
bb28:
  %t106 = load i64, ptr %l44, !tbaa !24
  store i64 %t106, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = icmp sge i64 %t107, 0
  br i1 %t109, label %bb29, label %bb30
bb29:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v3, ptr %t111, i64 %t112)
  store i1 %t115, ptr %l68
  br label %bb31
bb30:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb32
bb31:
  %t116 = load i1, ptr %l68, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l65, !tbaa !21
  br label %bb32
bb32:
  %t119 = load i1, ptr %l65, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v2, ptr %v3, ptr %t120, i64 %t121, ptr %a2, ptr %t123)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb9
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { { i64, ptr }, { i64, ptr }, i64 }
  %l11 = alloca { { i64, ptr }, i64 }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca { i64, [1 x i64] }
  %l28 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca i1
  %l41 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l49 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca i32
  %l80 = alloca { { i64, ptr }, { i64, ptr }, i64 }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca { { i64, ptr }, i64 }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l99 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 19
  store ptr %t14, ptr %l19, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t18 = load ptr, ptr %l19, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v2, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t26 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %t23, ptr %t24, i64 %t17)
  store { i64, [1 x i64] } %t26, ptr %l23
  br label %bb1
bb1:
  %t27 = load { i64, [1 x i64] }, ptr %l23
  store { i64, [1 x i64] } %t27, ptr %l4
  %t28 = load { i64, [1 x i64] }, ptr %l4
  %t30 = extractvalue { i64, [1 x i64] } %t28, 0
  %t31 = icmp eq i64 %t30, 0
  br i1 %t31, label %bb2, label %bb3
bb2:
  %t33 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t34 = getelementptr { i64 }, ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34
  store i64 %t35, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/emit:fnEm", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  %t41 = load i32, ptr %l1, !tbaa !23
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = call ptr @__olang_scope_or(ptr %v3, ptr %t43)
  %t45 = call ptr @__olang_scope_hold(ptr %t44)
  %t46 = ptrtoint ptr %t45 to i64
  %t48 = inttoptr i64 %t46 to ptr
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t52 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %t48, ptr %v1, ptr %t49, i32 %t41, i64 %t42)
  store { i64, ptr } %t52, ptr %l32
  br label %bb5
bb5:
  %t53 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb42
bb9:
  %t54 = load ptr, ptr %l3, !tbaa !29
  store ptr %t54, ptr %l33, !tbaa !29
  %t55 = load i32, ptr %l1, !tbaa !23
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = call ptr @__olang_scope_or(ptr %v3, ptr %t56)
  %t58 = call ptr @__olang_scope_hold(ptr %t57)
  %t59 = ptrtoint ptr %t58 to i64
  %t61 = inttoptr i64 %t59 to ptr
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t61, ptr %t62, i32 %t55)
  store i32 %t64, ptr %l36
  br label %bb10
bb10:
  %t65 = load i32, ptr %l36, !tbaa !23
  store i32 %t65, ptr %l6, !tbaa !23
  %t66 = load ptr, ptr %l3, !tbaa !29
  store ptr %t66, ptr %l37, !tbaa !29
  %t67 = load i32, ptr %l6, !tbaa !23
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = call ptr @__olang_scope_or(ptr %v3, ptr %t68)
  %t70 = call ptr @__olang_scope_hold(ptr %t69)
  %t71 = ptrtoint ptr %t70 to i64
  %t73 = inttoptr i64 %t71 to ptr
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t76 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t73, ptr %t74, i32 %t67)
  store i1 %t76, ptr %l40
  br label %bb11
bb11:
  %t77 = load i1, ptr %l40, !tbaa !21
  br i1 %t77, label %bb12, label %bb13
bb12:
  %t78 = load ptr, ptr %l3, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  %t79 = load i32, ptr %l6, !tbaa !23
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v3, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l42, !tbaa !29
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t85, ptr %t86, i32 %t79)
  store i32 %t88, ptr %l45
  br label %bb14
bb13:
  %t89 = load i32, ptr %l6, !tbaa !23
  store i32 %t89, ptr %l41, !tbaa !23
  br label %bb15
bb14:
  %t91 = load i32, ptr %l45, !tbaa !23
  store i32 %t91, ptr %l41, !tbaa !23
  br label %bb15
bb15:
  %t92 = load i32, ptr %l41, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t97 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %v3, ptr %t93, i32 %t92)
  store i32 %t97, ptr %l49
  br label %bb16
bb16:
  %t98 = load i32, ptr %l49, !tbaa !23
  store i32 %t98, ptr %l8, !tbaa !23
  %t99 = load i32, ptr %l8, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t103 = icmp eq i32 %t99, %t100
  br i1 %t103, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l53, !tbaa !29
  %t106 = load ptr, ptr %l3, !tbaa !29
  store ptr %t106, ptr %l54, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t108 = load ptr, ptr %l54, !tbaa !29
  %t109 = call ptr @__olang_scope_or(ptr %v3, ptr %t108)
  %t110 = call ptr @__olang_scope_hold(ptr %t109)
  %t111 = ptrtoint ptr %t110 to i64
  %t113 = inttoptr i64 %t111 to ptr
  %t115 = inttoptr i64 0 to ptr
  %t116 = load ptr, ptr %l54, !tbaa !29
  %t118 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t113, ptr %s3, ptr %t115, ptr %t116, i32 %t107)
  store { i64, ptr } %t118, ptr %l58
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t119 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t121 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t119, i64 %t120)
  %t126 = getelementptr i8, ptr %t125, i64 %t120
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  %t130 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %v3, ptr %t130, { i64, ptr } %t128)
  br label %bb20
bb20:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d198, i32 0, i32 1) }, ptr %l61, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t132, ptr %l62, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l63, !tbaa !24
  %t135 = load i64, ptr %l63, !tbaa !24
  %t136 = mul i64 %t135, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l64, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l63, !tbaa !24
  %t145 = mul i64 %t144, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t141, ptr %t143, i64 %t145, i1 false)
  %t146 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t146, ptr %l62, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  %t147 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t147, ptr %rv
  br label %ret
bb21:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l8, !tbaa !23
  %t152 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %v3, ptr %t148, i32 %t149)
  store i1 %t152, ptr %l67
  br label %bb22
bb22:
  %t153 = load i1, ptr %l67, !tbaa !21
  br i1 %t153, label %bb23, label %bb24
bb23:
  %t154 = load ptr, ptr %l3, !tbaa !29
  store ptr %t154, ptr %l69, !tbaa !29
  %t155 = load i32, ptr %l6, !tbaa !23
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = call ptr @__olang_scope_or(ptr %v3, ptr %t156)
  %t158 = call ptr @__olang_scope_hold(ptr %t157)
  %t159 = ptrtoint ptr %t158 to i64
  %t161 = inttoptr i64 %t159 to ptr
  %t162 = load ptr, ptr %l69, !tbaa !29
  %t164 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t161, ptr %t162, i32 %t155)
  store i1 %t164, ptr %l72
  br label %bb25
bb24:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb26
bb25:
  %t165 = load i1, ptr %l72, !tbaa !21
  %t166 = xor i1 %t165, true
  store i1 %t166, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t168 = load i1, ptr %l68, !tbaa !21
  br i1 %t168, label %bb27, label %bb28
bb27:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l74, !tbaa !29
  %t170 = load ptr, ptr %l3, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  %t171 = load i32, ptr %l8, !tbaa !23
  %t172 = load ptr, ptr %l75, !tbaa !29
  %t173 = call ptr @__olang_scope_or(ptr %v3, ptr %t172)
  %t174 = call ptr @__olang_scope_hold(ptr %t173)
  %t175 = ptrtoint ptr %t174 to i64
  %t177 = inttoptr i64 %t175 to ptr
  %t178 = load ptr, ptr %l75, !tbaa !29
  %t180 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t177, ptr %t178, i32 %t171)
  store i32 %t180, ptr %l78
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t181 = load i32, ptr %l2, !tbaa !23
  %t182 = load ptr, ptr %l74, !tbaa !29
  %t183 = load i32, ptr %l78, !tbaa !23
  %t185 = call { { i64, ptr }, { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstInit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t182, i32 %t183, i32 %t181)
  store { { i64, ptr }, { i64, ptr }, i64 } %t185, ptr %l80
  br label %bb30
bb30:
  %t186 = load { { i64, ptr }, { i64, ptr }, i64 }, ptr %l80
  store { { i64, ptr }, { i64, ptr }, i64 } %t186, ptr %l9
  %t187 = getelementptr { { i64, ptr }, { i64, ptr }, i64 }, ptr %l9, i32 0, i32 1
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l81, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l82, !tbaa !24
  %t191 = load i64, ptr %l82, !tbaa !24
  %t192 = mul i64 %t191, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l83, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l82, !tbaa !24
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  %t202 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t202, ptr %rv
  br label %ret
bb31:
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l85, !tbaa !29
  %t206 = load ptr, ptr %l3, !tbaa !29
  store ptr %t206, ptr %l86, !tbaa !29
  %t207 = load i32, ptr %l8, !tbaa !23
  %t208 = load ptr, ptr %l86, !tbaa !29
  %t209 = call ptr @__olang_scope_or(ptr %v3, ptr %t208)
  %t210 = call ptr @__olang_scope_hold(ptr %t209)
  %t211 = ptrtoint ptr %t210 to i64
  %t213 = inttoptr i64 %t211 to ptr
  %t214 = load ptr, ptr %l86, !tbaa !29
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t213, ptr %t214, i32 %t207)
  store i32 %t216, ptr %l89
  br label %bb32
bb32:
  %t217 = load i32, ptr %l2, !tbaa !23
  %t218 = load ptr, ptr %l85, !tbaa !29
  %t219 = load i32, ptr %l89, !tbaa !23
  %t221 = call { { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstGlobal(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %v3, ptr %t218, i32 %t219, i32 %t217, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d199, i32 0, i32 1) })
  store { { i64, ptr }, i64 } %t221, ptr %l91
  br label %bb33
bb33:
  %t222 = load { { i64, ptr }, i64 }, ptr %l91
  store { { i64, ptr }, i64 } %t222, ptr %l11
  %t223 = getelementptr { { i64, ptr }, i64 }, ptr %l11, i32 0, i32 0
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l92, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l93, !tbaa !24
  %t227 = load i64, ptr %l93, !tbaa !24
  %t228 = mul i64 %t227, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l94, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l93, !tbaa !24
  %t237 = mul i64 %t236, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %t235, i64 %t237, i1 false)
  %t238 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t238, ptr %l12, !tbaa !27
  %t239 = getelementptr { { i64, ptr }, i64 }, ptr %l11, i32 0, i32 1
  %t240 = load i64, ptr %t239, !tbaa !24
  store i64 %t240, ptr %l13, !tbaa !24
  %t242 = load ptr, ptr %l3, !tbaa !29
  store ptr %t242, ptr %l96, !tbaa !29
  %t243 = load i32, ptr %l6, !tbaa !23
  %t244 = load ptr, ptr %l96, !tbaa !29
  %t245 = call ptr @__olang_scope_or(ptr %v3, ptr %t244)
  %t246 = call ptr @__olang_scope_hold(ptr %t245)
  %t247 = ptrtoint ptr %t246 to i64
  %t249 = inttoptr i64 %t247 to ptr
  %t250 = load ptr, ptr %l96, !tbaa !29
  %t252 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t249, ptr %t250, i32 %t243)
  store i1 %t252, ptr %l99
  br label %bb34
bb34:
  %t253 = load i1, ptr %l99, !tbaa !21
  br i1 %t253, label %bb35, label %bb36
bb35:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i32, ptr %l8, !tbaa !23
  %t258 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %v3, ptr %t254, i32 %t255)
  store i1 %t258, ptr %l103
  br label %bb37
bb36:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb38
bb37:
  %t259 = load i1, ptr %l103, !tbaa !21
  store i1 %t259, ptr %l100, !tbaa !21
  br label %bb38
bb38:
  %t260 = load i1, ptr %l100, !tbaa !21
  br i1 %t260, label %bb39, label %bb40
bb39:
  %t261 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t261, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t263 = load i64, ptr %l13, !tbaa !24
  %t264 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t265 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t268 = call i64 @__olang_fmt_i64(ptr null, i64 %t263)
  %t269 = add i64 %t266, %t268
  %t270 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t274 = extractvalue { i64, ptr } %t264, 1
  %t275 = extractvalue { i64, ptr } %t264, 0
  %t276 = add i64 %t272, %t275
  %t277 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t280 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t279)
  call void @olang_textcopy(ptr %t280, ptr %t265, i64 %t266)
  %t281 = getelementptr i8, ptr %t280, i64 %t266
  %t282 = call i64 @__olang_fmt_i64(ptr %t281, i64 %t263)
  %t283 = getelementptr i8, ptr %t281, i64 %t268
  call void @olang_textcopy(ptr %t283, ptr %t270, i64 %t271)
  %t284 = getelementptr i8, ptr %t283, i64 %t271
  call void @olang_textcopy(ptr %t284, ptr %t274, i64 %t275)
  %t285 = getelementptr i8, ptr %t284, i64 %t275
  call void @olang_textcopy(ptr %t285, ptr %t277, i64 %t278)
  %t286 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t280, 1
  store { i64, ptr } %t287, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_3de177096d03f952_4b04555d717d3dfe)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca i32
  %l24 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l14, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %v4, ptr %t10, i32 %a3)
  store i32 %t14, ptr %l17
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l14, !tbaa !29
  %t16 = call ptr @__olang_scope_or(ptr %v4, ptr %t15)
  %t17 = call ptr @__olang_scope_hold(ptr %t16)
  %t18 = ptrtoint ptr %t17 to i64
  %t20 = inttoptr i64 %t18 to ptr
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = load i32, ptr %l17, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t20, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l19
  br label %bb2
bb2:
  %t24 = load i32, ptr %l19, !tbaa !23
  store i32 %t24, ptr %l6, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t30 = extractvalue { i64, ptr } %t26, 1
  %t31 = extractvalue { i64, ptr } %t26, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t25, { i64, ptr } %t40)
  store { i64, ptr } %t44, ptr %l24
  br label %bb3
bb3:
  %t45 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t48, i64 %t49)
  %t58 = getelementptr i8, ptr %t57, i64 %t49
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  call void @olang_textcopy(ptr %t59, ptr %t54, i64 %t55)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t46, { i64, ptr } %t61)
  store { i64, ptr } %t65, ptr %l29
  br label %bb4
bb4:
  %t66 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t66, ptr %l8, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l30, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l6, !tbaa !23
  %t73 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v4, ptr %t69, i32 %t70)
  store i64 %t73, ptr %l34
  br label %bb5
bb5:
  %t74 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t76 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = load i64, ptr %l34, !tbaa !24
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t85 = add i64 %t82, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t74, i64 %t75)
  %t87 = getelementptr i8, ptr %t86, i64 %t75
  call void @olang_textcopy(ptr %t87, ptr %t77, i64 %t78)
  %t88 = getelementptr i8, ptr %t87, i64 %t78
  call void @olang_textcopy(ptr %t88, ptr %t80, i64 %t81)
  %t89 = getelementptr i8, ptr %t88, i64 %t81
  %t90 = call i64 @__olang_fmt_i64(ptr %t89, i64 %t83)
  %t91 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t86, 1
  %t94 = load ptr, ptr %l30, !tbaa !29
  %t96 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t94, { i64, ptr } %t92)
  store { i64, ptr } %t96, ptr %l37
  br label %bb6
bb6:
  %t97 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t97, ptr %l9, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t101 = load i32, ptr %l6, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %v4, ptr %t98, { i64, ptr } %a1, { i64, ptr } %t100, i32 %t101, i1 false, i1 %a4)
  store { i64, ptr } %t108, ptr %l43
  br label %bb7
bb7:
  %t109 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t109, ptr %l10, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/emit:fnEm", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l45, !tbaa !29
  %t114 = load ptr, ptr %l45, !tbaa !29
  %t115 = call ptr @__olang_scope_or(ptr %v4, ptr %t114)
  %t116 = call ptr @__olang_scope_hold(ptr %t115)
  %t117 = ptrtoint ptr %t116 to i64
  %t119 = inttoptr i64 %t117 to ptr
  %t120 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t119, ptr %s0, ptr %s0, ptr %t120, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d209, i32 0, i32 1) }, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d210, i32 0, i32 1) })
  br label %bb8
bb8:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t125 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t128 = extractvalue { i64, ptr } %t122, 1
  %t129 = extractvalue { i64, ptr } %t122, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = extractvalue { i64, ptr } %t123, 1
  %t136 = extractvalue { i64, ptr } %t123, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t142 = extractvalue { i64, ptr } %t124, 1
  %t143 = extractvalue { i64, ptr } %t124, 0
  %t144 = add i64 %t140, %t143
  %t145 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t125, i64 %t126)
  %t149 = getelementptr i8, ptr %t148, i64 %t126
  call void @olang_textcopy(ptr %t149, ptr %t128, i64 %t129)
  %t150 = getelementptr i8, ptr %t149, i64 %t129
  call void @olang_textcopy(ptr %t150, ptr %t131, i64 %t132)
  %t151 = getelementptr i8, ptr %t150, i64 %t132
  call void @olang_textcopy(ptr %t151, ptr %t135, i64 %t136)
  %t152 = getelementptr i8, ptr %t151, i64 %t136
  call void @olang_textcopy(ptr %t152, ptr %t138, i64 %t139)
  %t153 = getelementptr i8, ptr %t152, i64 %t139
  call void @olang_textcopy(ptr %t153, ptr %t142, i64 %t143)
  %t154 = getelementptr i8, ptr %t153, i64 %t143
  call void @olang_textcopy(ptr %t154, ptr %t145, i64 %t146)
  %t155 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t148, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v4, ptr %t121, { i64, ptr } %t156)
  br label %bb9
bb9:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %v4, ptr %t160, { i64, ptr } %t161, { i64, ptr } %t162)
  store { i64, ptr } %t166, ptr %l56
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t167 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t167, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eextend(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l10, !tbaa !29
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v4, ptr %t11)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t16, ptr %t17, i32 %a2)
  store i32 %t19, ptr %l13
  br label %bb1
bb1:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l6, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %v4, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l16
  br label %bb2
bb2:
  %t26 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v2, { i64, ptr } %t31, { i64, ptr } %t33)
  store i1 %t36, ptr %l20
  br label %bb3
bb3:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb4, label %bb5
bb4:
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = extractvalue { i64, ptr } %t38, 0
  %t42 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t40, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l23, !tbaa !29
  br i1 %a4, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d216, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l6, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %v4, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l28
  br label %bb10
bb10:
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t67 = extractvalue { i64, ptr } %t54, 1
  %t68 = extractvalue { i64, ptr } %t54, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t74 = extractvalue { i64, ptr } %t55, 1
  %t75 = extractvalue { i64, ptr } %t55, 0
  %t76 = add i64 %t72, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t57, i64 %t58)
  %t78 = getelementptr i8, ptr %t77, i64 %t58
  call void @olang_textcopy(ptr %t78, ptr %t60, i64 %t61)
  %t79 = getelementptr i8, ptr %t78, i64 %t61
  call void @olang_textcopy(ptr %t79, ptr %t63, i64 %t64)
  %t80 = getelementptr i8, ptr %t79, i64 %t64
  call void @olang_textcopy(ptr %t80, ptr %t67, i64 %t68)
  %t81 = getelementptr i8, ptr %t80, i64 %t68
  call void @olang_textcopy(ptr %t81, ptr %t70, i64 %t71)
  %t82 = getelementptr i8, ptr %t81, i64 %t71
  call void @olang_textcopy(ptr %t82, ptr %t74, i64 %t75)
  %t83 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t77, 1
  %t86 = load ptr, ptr %l23, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t86, { i64, ptr } %t84)
  store { i64, ptr } %t88, ptr %l33
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2egenAlloc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l48 = alloca i64
  %l51 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca i64
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %v2, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sle i64 %t7, 8
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb4
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l16, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l16, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2egenBytes(ptr %v0, ptr %v2, ptr %t14, i32 %t15)
  store i64 %t18, ptr %l20
  br label %bb5
bb5:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l20, !tbaa !24
  %t22 = add i64 %t20, %t19
  store i64 %t22, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = call i64 @compiler_2femit_2egenClass(i64 %t24)
  store i64 %t26, ptr %l24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l24, !tbaa !24
  store i64 %t27, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp eq i64 %t28, 8
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  store i1 %t34, ptr %l27, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, [1 x i64] }, ptr %l1
  %t41 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t37, { i64, [1 x i64] } %t38)
  store i1 %t41, ptr %l33
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb13
bb12:
  %t42 = load i1, ptr %l33, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l30, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load { i64, [1 x i64] }, ptr %l1
  %t48 = extractvalue { i64, [1 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 4
  %t51 = xor i1 %t49, true
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l35, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/emit:fnEm", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = call ptr @__olang_scope_or(ptr %v2, ptr %t58)
  %t60 = call ptr @__olang_scope_hold(ptr %t59)
  %t61 = ptrtoint ptr %t60 to i64
  %t63 = inttoptr i64 %t61 to ptr
  %t64 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t63, ptr %s1, ptr %t64, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d219, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb24
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l42, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load { i64, [1 x i64] }, ptr %l1
  %t70 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s1, ptr %v2, ptr %v3, ptr %t66, { i64, [1 x i64] } %t67)
  store { i64, ptr } %t70, ptr %l45
  br label %bb20
bb20:
  %t71 = load i64, ptr %l6, !tbaa !24
  store i64 %t71, ptr %l46, !tbaa !24
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = call i64 @compiler_2femit_2egenClassSize(i64 %t72)
  store i64 %t74, ptr %l48
  br label %bb21
bb21:
  %t75 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t77 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = load i64, ptr %l46, !tbaa !24
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t86 = add i64 %t83, %t85
  %t87 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = call i64 @__olang_fmt_i64(ptr null, i64 %t90)
  %t92 = add i64 %t89, %t91
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t75, i64 %t76)
  %t97 = getelementptr i8, ptr %t96, i64 %t76
  call void @olang_textcopy(ptr %t97, ptr %t78, i64 %t79)
  %t98 = getelementptr i8, ptr %t97, i64 %t79
  call void @olang_textcopy(ptr %t98, ptr %t81, i64 %t82)
  %t99 = getelementptr i8, ptr %t98, i64 %t82
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t84)
  %t101 = getelementptr i8, ptr %t99, i64 %t85
  call void @olang_textcopy(ptr %t101, ptr %t87, i64 %t88)
  %t102 = getelementptr i8, ptr %t101, i64 %t88
  %t103 = call i64 @__olang_fmt_i64(ptr %t102, i64 %t90)
  %t104 = getelementptr i8, ptr %t102, i64 %t91
  call void @olang_textcopy(ptr %t104, ptr %t93, i64 %t94)
  %t105 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t96, 1
  %t108 = load ptr, ptr %l42, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %v1, ptr %v2, ptr %t108, { i64, ptr } %t106)
  store { i64, ptr } %t110, ptr %l51
  br label %bb22
bb22:
  %t111 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t111, ptr %l7, !tbaa !27
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t114 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWordsClear(ptr %v0, ptr %v1, ptr %v2, ptr %t112, { i64, ptr } %t113, i32 %t114)
  br label %bb23
bb23:
  %t118 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t118, ptr %rv
  br label %ret
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load { i64, [1 x i64] }, ptr %l1
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  %t126 = call i64 @__olang_fmt_i64(ptr %t125, i64 %t122)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  %t130 = load i64, ptr %l4, !tbaa !24
  %t131 = load i64, ptr %l5, !tbaa !24
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t135 = call i64 @__olang_fmt_i64(ptr null, i64 %t131)
  %t136 = add i64 %t133, %t135
  %t137 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t132, i64 %t133)
  %t141 = getelementptr i8, ptr %t140, i64 %t133
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t131)
  %t143 = getelementptr i8, ptr %t141, i64 %t135
  call void @olang_textcopy(ptr %t143, ptr %t137, i64 %t138)
  %t144 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t140, 1
  %t152 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %v2, ptr %v3, ptr %t120, { i64, [1 x i64] } %t121, { i64, ptr } %t128, i64 %t130, { i64, ptr } %t145)
  store { i64, ptr } %t152, ptr %l65
  br label %bb25
bb25:
  %t153 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l4, !tbaa !24
  %t157 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t160 = extractvalue { i64, ptr } %t153, 1
  %t161 = extractvalue { i64, ptr } %t153, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t167 = call i64 @__olang_fmt_i64(ptr null, i64 %t156)
  %t168 = add i64 %t165, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t157, i64 %t158)
  %t170 = getelementptr i8, ptr %t169, i64 %t158
  call void @olang_textcopy(ptr %t170, ptr %t160, i64 %t161)
  %t171 = getelementptr i8, ptr %t170, i64 %t161
  call void @olang_textcopy(ptr %t171, ptr %t163, i64 %t164)
  %t172 = getelementptr i8, ptr %t171, i64 %t164
  %t173 = call i64 @__olang_fmt_i64(ptr %t172, i64 %t156)
  %t174 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t169, 1
  %t179 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t154, { i64, ptr } %t175)
  store { i64, ptr } %t179, ptr %l71
  br label %bb26
bb26:
  %t180 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t180, ptr %l9, !tbaa !27
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load { i64, [1 x i64] }, ptr %l1
  %t185 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t181, { i64, [1 x i64] } %t182)
  store i1 %t185, ptr %l74
  br label %bb27
bb27:
  %t186 = load i1, ptr %l74, !tbaa !21
  br i1 %t186, label %bb28, label %bb29
bb28:
  store i64 196609, ptr %l75, !tbaa !24
  br label %bb30
bb29:
  store i64 1, ptr %l75, !tbaa !24
  br label %bb30
bb30:
  %t187 = load i64, ptr %l75, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l76, !tbaa !29
  store i64 %t187, ptr %l77, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t192 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t195 = extractvalue { i64, ptr } %t191, 1
  %t196 = extractvalue { i64, ptr } %t191, 0
  %t197 = add i64 %t193, %t196
  %t198 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t200 = add i64 %t197, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t200)
  call void @olang_textcopy(ptr %t201, ptr %t192, i64 %t193)
  %t202 = getelementptr i8, ptr %t201, i64 %t193
  call void @olang_textcopy(ptr %t202, ptr %t195, i64 %t196)
  %t203 = getelementptr i8, ptr %t202, i64 %t196
  call void @olang_textcopy(ptr %t203, ptr %t198, i64 %t199)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t201, 1
  %t209 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v2, ptr %t190, { i64, ptr } %t205)
  store { i64, ptr } %t209, ptr %l82
  br label %bb31
bb31:
  %t210 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t212 = load i64, ptr %l77, !tbaa !24
  %t213 = call i64 @__olang_fmt_i64(ptr null, i64 %t212)
  %t214 = add i64 %t211, %t213
  %t215 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t210, i64 %t211)
  %t226 = getelementptr i8, ptr %t225, i64 %t211
  %t227 = call i64 @__olang_fmt_i64(ptr %t226, i64 %t212)
  %t228 = getelementptr i8, ptr %t226, i64 %t213
  call void @olang_textcopy(ptr %t228, ptr %t215, i64 %t216)
  %t229 = getelementptr i8, ptr %t228, i64 %t216
  call void @olang_textcopy(ptr %t229, ptr %t219, i64 %t220)
  %t230 = getelementptr i8, ptr %t229, i64 %t220
  call void @olang_textcopy(ptr %t230, ptr %t222, i64 %t223)
  %t231 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t225, 1
  %t234 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v2, ptr %t234, { i64, ptr } %t232)
  br label %bb32
bb32:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t238 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWordsClear(ptr %v0, ptr %v1, ptr %v2, ptr %t236, { i64, ptr } %t237, i32 %t238)
  br label %bb33
bb33:
  %t242 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t242, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholders(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca %"compiler/mir:Lvalue"
  %l5 = alloca { { i64, ptr }, i32 }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca i32
  %l17 = alloca { { i64, ptr }, i32 }
  %l31 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [4 x i64] }, ptr %l1
  %t5 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v3, ptr %t1, { i64, [4 x i64] } %t2)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i32, ptr %l11, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load { i64, [4 x i64] }, ptr %l1
  %t9 = extractvalue { i64, [4 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 1
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t13 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l4
  br label %bb4
bb3:
  br label %bb7
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/mir:Lvalue", ptr %l4
  %t20 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %v2, ptr %v3, ptr %t16, %"compiler/mir:Lvalue" %t17)
  store { { i64, ptr }, i32 } %t20, ptr %l17
  br label %bb5
bb5:
  %t21 = load { { i64, ptr }, i32 }, ptr %l17
  store { { i64, ptr }, i32 } %t21, ptr %l5
  %t22 = getelementptr { { i64, ptr }, i32 }, ptr %l5, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %s1, ptr %v1, ptr %v3, ptr %t25, { i64, ptr } %t23, i32 %t27, { i64, ptr } %t28, i1 true)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb7:
  %t33 = load { i64, [4 x i64] }, ptr %l1
  %t35 = extractvalue { i64, [4 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 2
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t39 = getelementptr { i32, i64 }, ptr %t38, i32 0, i32 1
  %t40 = load i64, ptr %t39
  store i64 %t40, ptr %l7, !tbaa !24
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp ne i64 %t42, 0
  br i1 %t44, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %v3, ptr %t46, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d232, i32 0, i32 1) })
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  br label %bb23
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb22
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s4, ptr %v3, ptr %t48, i32 %t49)
  store { i64, ptr } %t52, ptr %l31
  br label %bb19
bb19:
  %t53 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t53, ptr %l8, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t56 = load i32, ptr %l3, !tbaa !23
  %t57 = load { i64, [4 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s4, ptr %s4, ptr %v3, ptr %v2, ptr %t54, { i64, ptr } %t55, i32 %t56, { i64, [4 x i64] } %t57, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d233, i32 0, i32 1) })
  br label %bb20
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %s4, ptr %v1, ptr %v3, ptr %t62, { i64, ptr } %t63, i32 %t64, { i64, ptr } %t65, i1 true)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7fed6075202c6f47_53bfc91b56218413)
  unreachable
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2elaneDots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/mir:Range" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca ptr
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l30 = alloca { i64, [4 x i64] }
  %l33 = alloca { i64, [4 x i64] }
  %l36 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i32
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca i32
  %l61 = alloca i32
  %l63 = alloca i32
  %l65 = alloca i1
  %l69 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca { i64, [4 x i64] }
  %l78 = alloca ptr
  %l81 = alloca { i64, [4 x i64] }
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca { i64, [4 x i64] }
  %l88 = alloca ptr
  %l91 = alloca { i64, [4 x i64] }
  %l92 = alloca i32
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l97 = alloca { i64, [4 x i64] }
  %l98 = alloca ptr
  %l101 = alloca { i64, [4 x i64] }
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l111 = alloca { i64, [4 x i64] }
  %l112 = alloca i32
  %l114 = alloca i32
  %l116 = alloca i32
  %l118 = alloca { i64, ptr }
  %l120 = alloca ptr
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l125 = alloca i32
  %l127 = alloca i32
  %l129 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l136 = alloca i32
  %l138 = alloca i32
  %l140 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l146 = alloca i32
  %l148 = alloca i32
  %l150 = alloca i32
  %l153 = alloca ptr
  %l157 = alloca %"compiler/emit:laneTags"
  %l159 = alloca { i64, ptr }
  %l171 = alloca i1
  %l175 = alloca ptr
  %l177 = alloca i1
  %l181 = alloca i1
  %l184 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l193 = alloca %"compiler/emit:laneTags"
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l200 = alloca i64
  %l201 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l206 = alloca i64
  %l207 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l212 = alloca i64
  %l213 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l218 = alloca i64
  %l219 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Range", ptr %l2
  %t13 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t9, %"compiler/mir:Range" %t10, i64 1)
  store { i64, [4 x i64] } %t13, ptr %l30
  br label %bb1
bb1:
  %t14 = load { i64, [4 x i64] }, ptr %l30
  store { i64, [4 x i64] } %t14, ptr %l4
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/mir:Range", ptr %l2
  %t19 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t15, %"compiler/mir:Range" %t16, i64 2)
  store { i64, [4 x i64] } %t19, ptr %l33
  br label %bb2
bb2:
  %t20 = load { i64, [4 x i64] }, ptr %l33
  store { i64, [4 x i64] } %t20, ptr %l5
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, [4 x i64] }, ptr %l4
  %t25 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v3, ptr %t21, { i64, [4 x i64] } %t22)
  store i32 %t25, ptr %l36
  br label %bb3
bb3:
  %t26 = load i32, ptr %l36, !tbaa !23
  store i32 %t26, ptr %l6, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [4 x i64] }, ptr %l5
  %t31 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v3, ptr %t27, { i64, [4 x i64] } %t28)
  store i32 %t31, ptr %l39
  br label %bb4
bb4:
  %t32 = load i32, ptr %l39, !tbaa !23
  store i32 %t32, ptr %l7, !tbaa !23
  %t33 = load ptr, ptr %l3, !tbaa !29
  store ptr %t33, ptr %l40, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  store ptr %t34, ptr %l41, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %l42, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l43, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t38 = load ptr, ptr %l43, !tbaa !29
  %t39 = call ptr @__olang_scope_or(ptr %v3, ptr %t38)
  %t40 = call ptr @__olang_scope_hold(ptr %t39)
  %t41 = ptrtoint ptr %t40 to i64
  %t43 = inttoptr i64 %t41 to ptr
  %t44 = load ptr, ptr %l43, !tbaa !29
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t43, ptr %t44, i32 %t37)
  store i32 %t46, ptr %l46
  br label %bb5
bb5:
  %t47 = load ptr, ptr %l42, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v3, ptr %t47)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t50 to ptr
  %t53 = load ptr, ptr %l42, !tbaa !29
  %t54 = load i32, ptr %l46, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t52, ptr %t53, i32 %t54)
  store i32 %t55, ptr %l48
  br label %bb6
bb6:
  %t56 = load ptr, ptr %l41, !tbaa !29
  %t57 = call ptr @__olang_scope_or(ptr %v3, ptr %t56)
  %t58 = call ptr @__olang_scope_hold(ptr %t57)
  %t59 = ptrtoint ptr %t58 to i64
  %t61 = inttoptr i64 %t59 to ptr
  %t62 = load ptr, ptr %l41, !tbaa !29
  %t63 = load i32, ptr %l48, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t61, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l50
  br label %bb7
bb7:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v3, ptr %t65)
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = inttoptr i64 %t68 to ptr
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t72 = load i32, ptr %l50, !tbaa !23
  %t73 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t70, ptr %t71, i32 %t72)
  store i1 %t73, ptr %l52
  br label %bb8
bb8:
  %t74 = load i1, ptr %l52, !tbaa !21
  store i1 %t74, ptr %l8, !tbaa !21
  %t75 = load ptr, ptr %l3, !tbaa !29
  store ptr %t75, ptr %l53, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  store ptr %t76, ptr %l54, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  store ptr %t77, ptr %l55, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  store ptr %t78, ptr %l56, !tbaa !29
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load ptr, ptr %l56, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v3, ptr %t80)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t83 to ptr
  %t86 = load ptr, ptr %l56, !tbaa !29
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t85, ptr %t86, i32 %t79)
  store i32 %t88, ptr %l59
  br label %bb9
bb9:
  %t89 = load ptr, ptr %l55, !tbaa !29
  %t90 = call ptr @__olang_scope_or(ptr %v3, ptr %t89)
  %t91 = call ptr @__olang_scope_hold(ptr %t90)
  %t92 = ptrtoint ptr %t91 to i64
  %t94 = inttoptr i64 %t92 to ptr
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = load i32, ptr %l59, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t94, ptr %t95, i32 %t96)
  store i32 %t97, ptr %l61
  br label %bb10
bb10:
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t99 = call ptr @__olang_scope_or(ptr %v3, ptr %t98)
  %t100 = call ptr @__olang_scope_hold(ptr %t99)
  %t101 = ptrtoint ptr %t100 to i64
  %t103 = inttoptr i64 %t101 to ptr
  %t104 = load ptr, ptr %l54, !tbaa !29
  %t105 = load i32, ptr %l61, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t103, ptr %t104, i32 %t105)
  store i32 %t106, ptr %l63
  br label %bb11
bb11:
  %t107 = load ptr, ptr %l53, !tbaa !29
  %t108 = call ptr @__olang_scope_or(ptr %v3, ptr %t107)
  %t109 = call ptr @__olang_scope_hold(ptr %t108)
  %t110 = ptrtoint ptr %t109 to i64
  %t112 = inttoptr i64 %t110 to ptr
  %t113 = load ptr, ptr %l53, !tbaa !29
  %t114 = load i32, ptr %l63, !tbaa !23
  %t115 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t112, ptr %t113, i32 %t114)
  store i1 %t115, ptr %l65
  br label %bb12
bb12:
  %t116 = load i1, ptr %l65, !tbaa !21
  store i1 %t116, ptr %l9, !tbaa !21
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load { i64, [4 x i64] }, ptr %l4
  %t119 = load i32, ptr %l6, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t117, { i64, [4 x i64] } %t118, i32 %t119)
  store { i64, ptr } %t123, ptr %l69
  br label %bb13
bb13:
  %t124 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t124, ptr %l10, !tbaa !27
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load { i64, [4 x i64] }, ptr %l5
  %t127 = load i32, ptr %l7, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t125, { i64, [4 x i64] } %t126, i32 %t127)
  store { i64, ptr } %t131, ptr %l73
  br label %bb14
bb14:
  %t132 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t132, ptr %l11, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l74, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/mir:Range", ptr %l2
  %t138 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t134, %"compiler/mir:Range" %t135, i64 3)
  store { i64, [4 x i64] } %t138, ptr %l77
  br label %bb15
bb15:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l78, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load %"compiler/mir:Range", ptr %l2
  %t144 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t140, %"compiler/mir:Range" %t141, i64 3)
  store { i64, [4 x i64] } %t144, ptr %l81
  br label %bb16
bb16:
  %t145 = load ptr, ptr %l78, !tbaa !29
  %t146 = load { i64, [4 x i64] }, ptr %l81
  %t147 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v3, ptr %t145, { i64, [4 x i64] } %t146)
  store i32 %t147, ptr %l82
  br label %bb17
bb17:
  %t148 = load ptr, ptr %l74, !tbaa !29
  %t149 = load { i64, [4 x i64] }, ptr %l77
  %t150 = load i32, ptr %l82, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t148, { i64, [4 x i64] } %t149, i32 %t150)
  store { i64, ptr } %t151, ptr %l83
  br label %bb18
bb18:
  %t152 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t152, ptr %l12, !tbaa !27
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/mir:Range", ptr %l2
  %t158 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t154, %"compiler/mir:Range" %t155, i64 4)
  store { i64, [4 x i64] } %t158, ptr %l87
  br label %bb19
bb19:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l88, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/mir:Range", ptr %l2
  %t164 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t160, %"compiler/mir:Range" %t161, i64 4)
  store { i64, [4 x i64] } %t164, ptr %l91
  br label %bb20
bb20:
  %t165 = load ptr, ptr %l88, !tbaa !29
  %t166 = load { i64, [4 x i64] }, ptr %l91
  %t167 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v3, ptr %t165, { i64, [4 x i64] } %t166)
  store i32 %t167, ptr %l92
  br label %bb21
bb21:
  %t168 = load ptr, ptr %l84, !tbaa !29
  %t169 = load { i64, [4 x i64] }, ptr %l87
  %t170 = load i32, ptr %l92, !tbaa !23
  %t171 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t168, { i64, [4 x i64] } %t169, i32 %t170)
  store { i64, ptr } %t171, ptr %l93
  br label %bb22
bb22:
  %t172 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t172, ptr %l13, !tbaa !27
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l94, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/mir:Range", ptr %l2
  %t178 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t174, %"compiler/mir:Range" %t175, i64 5)
  store { i64, [4 x i64] } %t178, ptr %l97
  br label %bb23
bb23:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l98, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/mir:Range", ptr %l2
  %t184 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t180, %"compiler/mir:Range" %t181, i64 5)
  store { i64, [4 x i64] } %t184, ptr %l101
  br label %bb24
bb24:
  %t185 = load ptr, ptr %l98, !tbaa !29
  %t186 = load { i64, [4 x i64] }, ptr %l101
  %t187 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v3, ptr %t185, { i64, [4 x i64] } %t186)
  store i32 %t187, ptr %l102
  br label %bb25
bb25:
  %t188 = load ptr, ptr %l94, !tbaa !29
  %t189 = load { i64, [4 x i64] }, ptr %l97
  %t190 = load i32, ptr %l102, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t188, { i64, [4 x i64] } %t189, i32 %t190)
  store { i64, ptr } %t191, ptr %l103
  br label %bb26
bb26:
  %t192 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t192, ptr %l14, !tbaa !27
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/emit:fnEm", ptr %t193, i32 0, i32 0
  %t196 = load ptr, ptr %t195, !tbaa !29
  store ptr %t196, ptr %l105, !tbaa !29
  %t197 = load ptr, ptr %l3, !tbaa !29
  store ptr %t197, ptr %l106, !tbaa !29
  %t198 = load ptr, ptr %l3, !tbaa !29
  store ptr %t198, ptr %l107, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l108, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load %"compiler/mir:Range", ptr %l2
  %t204 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t200, %"compiler/mir:Range" %t201, i64 0)
  store { i64, [4 x i64] } %t204, ptr %l111
  br label %bb27
bb27:
  %t205 = load ptr, ptr %l108, !tbaa !29
  %t206 = load { i64, [4 x i64] }, ptr %l111
  %t207 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v3, ptr %t205, { i64, [4 x i64] } %t206)
  store i32 %t207, ptr %l112
  br label %bb28
bb28:
  %t208 = load ptr, ptr %l107, !tbaa !29
  %t209 = call ptr @__olang_scope_or(ptr %v3, ptr %t208)
  %t210 = call ptr @__olang_scope_hold(ptr %t209)
  %t211 = ptrtoint ptr %t210 to i64
  %t213 = inttoptr i64 %t211 to ptr
  %t214 = load ptr, ptr %l107, !tbaa !29
  %t215 = load i32, ptr %l112, !tbaa !23
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t213, ptr %t214, i32 %t215)
  store i32 %t216, ptr %l114
  br label %bb29
bb29:
  %t217 = load ptr, ptr %l106, !tbaa !29
  %t218 = call ptr @__olang_scope_or(ptr %v3, ptr %t217)
  %t219 = call ptr @__olang_scope_hold(ptr %t218)
  %t220 = ptrtoint ptr %t219 to i64
  %t222 = inttoptr i64 %t220 to ptr
  %t223 = load ptr, ptr %l106, !tbaa !29
  %t224 = load i32, ptr %l114, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t222, ptr %t223, i32 %t224)
  store i32 %t225, ptr %l116
  br label %bb30
bb30:
  %t226 = load ptr, ptr %l105, !tbaa !29
  %t227 = call ptr @__olang_scope_or(ptr %v3, ptr %t226)
  %t228 = call ptr @__olang_scope_hold(ptr %t227)
  %t229 = ptrtoint ptr %t228 to i64
  %t231 = inttoptr i64 %t229 to ptr
  %t232 = load ptr, ptr %l105, !tbaa !29
  %t233 = load i32, ptr %l116, !tbaa !23
  %t234 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %t231, ptr %s0, ptr %t232, i32 %t233, i1 true)
  store { i64, ptr } %t234, ptr %l118
  br label %bb31
bb31:
  %t235 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t235, ptr %l15, !tbaa !27
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/emit:fnEm", ptr %t236, i32 0, i32 0
  %t239 = load ptr, ptr %t238, !tbaa !29
  store ptr %t239, ptr %l120, !tbaa !29
  %t240 = load ptr, ptr %l3, !tbaa !29
  store ptr %t240, ptr %l121, !tbaa !29
  %t241 = load ptr, ptr %l3, !tbaa !29
  store ptr %t241, ptr %l122, !tbaa !29
  %t242 = load i32, ptr %l6, !tbaa !23
  %t243 = load ptr, ptr %l122, !tbaa !29
  %t244 = call ptr @__olang_scope_or(ptr %v3, ptr %t243)
  %t245 = call ptr @__olang_scope_hold(ptr %t244)
  %t246 = ptrtoint ptr %t245 to i64
  %t248 = inttoptr i64 %t246 to ptr
  %t249 = load ptr, ptr %l122, !tbaa !29
  %t251 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t248, ptr %t249, i32 %t242)
  store i32 %t251, ptr %l125
  br label %bb32
bb32:
  %t252 = load ptr, ptr %l121, !tbaa !29
  %t253 = call ptr @__olang_scope_or(ptr %v3, ptr %t252)
  %t254 = call ptr @__olang_scope_hold(ptr %t253)
  %t255 = ptrtoint ptr %t254 to i64
  %t257 = inttoptr i64 %t255 to ptr
  %t258 = load ptr, ptr %l121, !tbaa !29
  %t259 = load i32, ptr %l125, !tbaa !23
  %t260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t257, ptr %t258, i32 %t259)
  store i32 %t260, ptr %l127
  br label %bb33
bb33:
  %t261 = load ptr, ptr %l120, !tbaa !29
  %t262 = call ptr @__olang_scope_or(ptr %v3, ptr %t261)
  %t263 = call ptr @__olang_scope_hold(ptr %t262)
  %t264 = ptrtoint ptr %t263 to i64
  %t266 = inttoptr i64 %t264 to ptr
  %t267 = load ptr, ptr %l120, !tbaa !29
  %t268 = load i32, ptr %l127, !tbaa !23
  %t269 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %t266, ptr %s0, ptr %t267, i32 %t268, i1 true)
  store { i64, ptr } %t269, ptr %l129
  br label %bb34
bb34:
  %t270 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t270, ptr %l16, !tbaa !27
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/emit:fnEm", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  store ptr %t274, ptr %l131, !tbaa !29
  %t275 = load ptr, ptr %l3, !tbaa !29
  store ptr %t275, ptr %l132, !tbaa !29
  %t276 = load ptr, ptr %l3, !tbaa !29
  store ptr %t276, ptr %l133, !tbaa !29
  %t277 = load i32, ptr %l7, !tbaa !23
  %t278 = load ptr, ptr %l133, !tbaa !29
  %t279 = call ptr @__olang_scope_or(ptr %v3, ptr %t278)
  %t280 = call ptr @__olang_scope_hold(ptr %t279)
  %t281 = ptrtoint ptr %t280 to i64
  %t283 = inttoptr i64 %t281 to ptr
  %t284 = load ptr, ptr %l133, !tbaa !29
  %t286 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t283, ptr %t284, i32 %t277)
  store i32 %t286, ptr %l136
  br label %bb35
bb35:
  %t287 = load ptr, ptr %l132, !tbaa !29
  %t288 = call ptr @__olang_scope_or(ptr %v3, ptr %t287)
  %t289 = call ptr @__olang_scope_hold(ptr %t288)
  %t290 = ptrtoint ptr %t289 to i64
  %t292 = inttoptr i64 %t290 to ptr
  %t293 = load ptr, ptr %l132, !tbaa !29
  %t294 = load i32, ptr %l136, !tbaa !23
  %t295 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t292, ptr %t293, i32 %t294)
  store i32 %t295, ptr %l138
  br label %bb36
bb36:
  %t296 = load ptr, ptr %l131, !tbaa !29
  %t297 = call ptr @__olang_scope_or(ptr %v3, ptr %t296)
  %t298 = call ptr @__olang_scope_hold(ptr %t297)
  %t299 = ptrtoint ptr %t298 to i64
  %t301 = inttoptr i64 %t299 to ptr
  %t302 = load ptr, ptr %l131, !tbaa !29
  %t303 = load i32, ptr %l138, !tbaa !23
  %t304 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %t301, ptr %s0, ptr %t302, i32 %t303, i1 true)
  store { i64, ptr } %t304, ptr %l140
  br label %bb37
bb37:
  %t305 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t305, ptr %l17, !tbaa !27
  %t306 = load ptr, ptr %l3, !tbaa !29
  store ptr %t306, ptr %l141, !tbaa !29
  %t307 = load ptr, ptr %l3, !tbaa !29
  store ptr %t307, ptr %l142, !tbaa !29
  %t308 = load ptr, ptr %l3, !tbaa !29
  store ptr %t308, ptr %l143, !tbaa !29
  %t309 = load i32, ptr %l6, !tbaa !23
  %t310 = load ptr, ptr %l143, !tbaa !29
  %t311 = call ptr @__olang_scope_or(ptr %v3, ptr %t310)
  %t312 = call ptr @__olang_scope_hold(ptr %t311)
  %t313 = ptrtoint ptr %t312 to i64
  %t315 = inttoptr i64 %t313 to ptr
  %t316 = load ptr, ptr %l143, !tbaa !29
  %t318 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t315, ptr %t316, i32 %t309)
  store i32 %t318, ptr %l146
  br label %bb38
bb38:
  %t319 = load ptr, ptr %l142, !tbaa !29
  %t320 = call ptr @__olang_scope_or(ptr %v3, ptr %t319)
  %t321 = call ptr @__olang_scope_hold(ptr %t320)
  %t322 = ptrtoint ptr %t321 to i64
  %t324 = inttoptr i64 %t322 to ptr
  %t325 = load ptr, ptr %l142, !tbaa !29
  %t326 = load i32, ptr %l146, !tbaa !23
  %t327 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t324, ptr %t325, i32 %t326)
  store i32 %t327, ptr %l148
  br label %bb39
bb39:
  %t328 = load ptr, ptr %l141, !tbaa !29
  %t329 = call ptr @__olang_scope_or(ptr %v3, ptr %t328)
  %t330 = call ptr @__olang_scope_hold(ptr %t329)
  %t331 = ptrtoint ptr %t330 to i64
  %t333 = inttoptr i64 %t331 to ptr
  %t334 = load ptr, ptr %l141, !tbaa !29
  %t335 = load i32, ptr %l148, !tbaa !23
  %t336 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t333, ptr %t334, i32 %t335)
  store i32 %t336, ptr %l150
  br label %bb40
bb40:
  %t337 = load i32, ptr %l150, !tbaa !23
  %t338 = icmp eq i32 %t337, 12
  br i1 %t338, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s1
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/emit:fnEm", ptr %t340, i32 0, i32 0
  %t343 = load ptr, ptr %t342, !tbaa !29
  store ptr %t343, ptr %l153, !tbaa !29
  %t344 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t350 = call %"compiler/emit:laneTags" @compiler_2femit_3alaneTags_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s1, { i64, ptr } %t344, { i64, ptr } %t345, { i64, ptr } %t346)
  store %"compiler/emit:laneTags" %t350, ptr %l157
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t351 = load ptr, ptr %l153, !tbaa !29
  %t352 = call ptr @__olang_scope_or(ptr %v3, ptr %t351)
  %t353 = call ptr @__olang_scope_hold(ptr %t352)
  %t354 = ptrtoint ptr %t353 to i64
  %t356 = inttoptr i64 %t354 to ptr
  %t357 = load ptr, ptr %l153, !tbaa !29
  %t358 = load %"compiler/emit:laneTags", ptr %l157
  %t359 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epairDotsFn(ptr %t356, ptr %s1, ptr %s1, ptr %t357, %"compiler/emit:laneTags" %t358)
  store { i64, ptr } %t359, ptr %l159
  br label %bb44
bb44:
  %t360 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t365 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t368 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t369 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t372 = extractvalue { i64, ptr } %t360, 1
  %t373 = extractvalue { i64, ptr } %t360, 0
  %t374 = add i64 %t370, %t373
  %t375 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t363, 1
  %t380 = extractvalue { i64, ptr } %t363, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t386 = extractvalue { i64, ptr } %t364, 1
  %t387 = extractvalue { i64, ptr } %t364, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t390 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t391 = add i64 %t388, %t390
  %t393 = extractvalue { i64, ptr } %t365, 1
  %t394 = extractvalue { i64, ptr } %t365, 0
  %t395 = add i64 %t391, %t394
  %t396 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t397 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t398 = add i64 %t395, %t397
  %t400 = extractvalue { i64, ptr } %t366, 1
  %t401 = extractvalue { i64, ptr } %t366, 0
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t407 = extractvalue { i64, ptr } %t367, 1
  %t408 = extractvalue { i64, ptr } %t367, 0
  %t409 = add i64 %t405, %t408
  %t410 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t411 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t412 = add i64 %t409, %t411
  %t414 = extractvalue { i64, ptr } %t368, 1
  %t415 = extractvalue { i64, ptr } %t368, 0
  %t416 = add i64 %t412, %t415
  %t417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t419 = add i64 %t416, %t418
  %t420 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t419)
  call void @olang_textcopy(ptr %t420, ptr %t369, i64 %t370)
  %t421 = getelementptr i8, ptr %t420, i64 %t370
  call void @olang_textcopy(ptr %t421, ptr %t372, i64 %t373)
  %t422 = getelementptr i8, ptr %t421, i64 %t373
  call void @olang_textcopy(ptr %t422, ptr %t375, i64 %t376)
  %t423 = getelementptr i8, ptr %t422, i64 %t376
  call void @olang_textcopy(ptr %t423, ptr %t379, i64 %t380)
  %t424 = getelementptr i8, ptr %t423, i64 %t380
  call void @olang_textcopy(ptr %t424, ptr %t382, i64 %t383)
  %t425 = getelementptr i8, ptr %t424, i64 %t383
  call void @olang_textcopy(ptr %t425, ptr %t386, i64 %t387)
  %t426 = getelementptr i8, ptr %t425, i64 %t387
  call void @olang_textcopy(ptr %t426, ptr %t389, i64 %t390)
  %t427 = getelementptr i8, ptr %t426, i64 %t390
  call void @olang_textcopy(ptr %t427, ptr %t393, i64 %t394)
  %t428 = getelementptr i8, ptr %t427, i64 %t394
  call void @olang_textcopy(ptr %t428, ptr %t396, i64 %t397)
  %t429 = getelementptr i8, ptr %t428, i64 %t397
  call void @olang_textcopy(ptr %t429, ptr %t400, i64 %t401)
  %t430 = getelementptr i8, ptr %t429, i64 %t401
  call void @olang_textcopy(ptr %t430, ptr %t403, i64 %t404)
  %t431 = getelementptr i8, ptr %t430, i64 %t404
  call void @olang_textcopy(ptr %t431, ptr %t407, i64 %t408)
  %t432 = getelementptr i8, ptr %t431, i64 %t408
  call void @olang_textcopy(ptr %t432, ptr %t410, i64 %t411)
  %t433 = getelementptr i8, ptr %t432, i64 %t411
  call void @olang_textcopy(ptr %t433, ptr %t414, i64 %t415)
  %t434 = getelementptr i8, ptr %t433, i64 %t415
  call void @olang_textcopy(ptr %t434, ptr %t417, i64 %t418)
  %t435 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t436 = insertvalue { i64, ptr } %t435, ptr %t420, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s1, ptr %v3, ptr %t361, { i64, ptr } %t436)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  %t440 = load i1, ptr %l9, !tbaa !21
  br i1 %t440, label %bb47, label %bb48
bb47:
  %t442 = load i1, ptr %l8, !tbaa !21
  %t444 = xor i1 %t442, true
  store i1 %t444, ptr %l171, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb49
bb49:
  %t446 = load i1, ptr %l171, !tbaa !21
  store i1 %t446, ptr %l19, !tbaa !21
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/emit:fnEm", ptr %t447, i32 0, i32 0
  %t450 = load ptr, ptr %t449, !tbaa !29
  store ptr %t450, ptr %l175, !tbaa !29
  %t451 = load i1, ptr %l19, !tbaa !21
  br i1 %t451, label %bb50, label %bb51
bb50:
  %t453 = load i1, ptr %l9, !tbaa !21
  store i1 %t453, ptr %l177, !tbaa !21
  br label %bb52
bb51:
  %t455 = load i1, ptr %l8, !tbaa !21
  store i1 %t455, ptr %l177, !tbaa !21
  br label %bb52
bb52:
  %t457 = load i1, ptr %l19, !tbaa !21
  br i1 %t457, label %bb53, label %bb54
bb53:
  %t459 = load i1, ptr %l8, !tbaa !21
  store i1 %t459, ptr %l181, !tbaa !21
  br label %bb55
bb54:
  %t461 = load i1, ptr %l9, !tbaa !21
  store i1 %t461, ptr %l181, !tbaa !21
  br label %bb55
bb55:
  %t463 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t463, ptr %l184, !tbaa !27
  %t464 = load i1, ptr %l19, !tbaa !21
  br i1 %t464, label %bb56, label %bb57
bb56:
  %t466 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t466, ptr %l186, !tbaa !27
  br label %bb58
bb57:
  %t468 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t468, ptr %l186, !tbaa !27
  br label %bb58
bb58:
  %t470 = load i1, ptr %l19, !tbaa !21
  br i1 %t470, label %bb59, label %bb60
bb59:
  %t472 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t472, ptr %l190, !tbaa !27
  br label %bb61
bb60:
  %t474 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t474, ptr %l190, !tbaa !27
  br label %bb61
bb61:
  %t476 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t477 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t479 = call %"compiler/emit:laneTags" @compiler_2femit_3alaneTags_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t476, { i64, ptr } %t477, { i64, ptr } %t478)
  store %"compiler/emit:laneTags" %t479, ptr %l193
  br label %bb62
bb62:
  %t480 = load ptr, ptr %l175, !tbaa !29
  %t481 = call ptr @__olang_scope_or(ptr %v3, ptr %t480)
  %t482 = call ptr @__olang_scope_hold(ptr %t481)
  %t483 = ptrtoint ptr %t482 to i64
  %t485 = inttoptr i64 %t483 to ptr
  %t486 = load ptr, ptr %l175, !tbaa !29
  %t487 = load i1, ptr %l177, !tbaa !21
  %t488 = load i1, ptr %l181, !tbaa !21
  %t489 = load %"compiler/emit:laneTags", ptr %l193
  %t490 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elaneDotsFn(ptr %t485, ptr %s0, ptr %s0, ptr %t486, i1 %t487, i1 %t488, %"compiler/emit:laneTags" %t489)
  store { i64, ptr } %t490, ptr %l195
  br label %bb63
bb63:
  %t491 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t491, ptr %l20, !tbaa !27
  %t492 = load i1, ptr %l19, !tbaa !21
  br i1 %t492, label %bb64, label %bb65
bb64:
  %t494 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t494, ptr %l197, !tbaa !27
  br label %bb66
bb65:
  %t496 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t496, ptr %l197, !tbaa !27
  br label %bb66
bb66:
  %t498 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 0
  store i64 %t499, ptr %l200, !tbaa !24
  %t500 = load i64, ptr %l200, !tbaa !24
  %t501 = mul i64 %t500, 1
  %t502 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t501)
  %t503 = insertvalue { i64, ptr } undef, i64 %t500, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t502, 1
  store { i64, ptr } %t504, ptr %l201, !tbaa !27
  %t505 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t506 = load ptr, ptr %t505, !tbaa !27
  %t507 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = load i64, ptr %l200, !tbaa !24
  %t510 = mul i64 %t509, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t506, ptr %t508, i64 %t510, i1 false)
  %t511 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t511, ptr %l21, !tbaa !27
  %t512 = load i1, ptr %l19, !tbaa !21
  br i1 %t512, label %bb67, label %bb68
bb67:
  %t514 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t514, ptr %l203, !tbaa !27
  br label %bb69
bb68:
  %t516 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t516, ptr %l203, !tbaa !27
  br label %bb69
bb69:
  %t518 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t519 = extractvalue { i64, ptr } %t518, 0
  store i64 %t519, ptr %l206, !tbaa !24
  %t520 = load i64, ptr %l206, !tbaa !24
  %t521 = mul i64 %t520, 1
  %t522 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t521)
  %t523 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t522, 1
  store { i64, ptr } %t524, ptr %l207, !tbaa !27
  %t525 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = load i64, ptr %l206, !tbaa !24
  %t530 = mul i64 %t529, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t526, ptr %t528, i64 %t530, i1 false)
  %t531 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t531, ptr %l22, !tbaa !27
  %t532 = load i1, ptr %l19, !tbaa !21
  br i1 %t532, label %bb70, label %bb71
bb70:
  %t534 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t534, ptr %l209, !tbaa !27
  br label %bb72
bb71:
  %t536 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t536, ptr %l209, !tbaa !27
  br label %bb72
bb72:
  %t538 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t539 = extractvalue { i64, ptr } %t538, 0
  store i64 %t539, ptr %l212, !tbaa !24
  %t540 = load i64, ptr %l212, !tbaa !24
  %t541 = mul i64 %t540, 1
  %t542 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t541)
  %t543 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t542, 1
  store { i64, ptr } %t544, ptr %l213, !tbaa !27
  %t545 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t548 = load ptr, ptr %t547, !tbaa !27
  %t549 = load i64, ptr %l212, !tbaa !24
  %t550 = mul i64 %t549, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t546, ptr %t548, i64 %t550, i1 false)
  %t551 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t551, ptr %l23, !tbaa !27
  %t552 = load i1, ptr %l19, !tbaa !21
  br i1 %t552, label %bb73, label %bb74
bb73:
  %t554 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t554, ptr %l215, !tbaa !27
  br label %bb75
bb74:
  %t556 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t556, ptr %l215, !tbaa !27
  br label %bb75
bb75:
  %t558 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t558, 0
  store i64 %t559, ptr %l218, !tbaa !24
  %t560 = load i64, ptr %l218, !tbaa !24
  %t561 = mul i64 %t560, 1
  %t562 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t561)
  %t563 = insertvalue { i64, ptr } undef, i64 %t560, 0
  %t564 = insertvalue { i64, ptr } %t563, ptr %t562, 1
  store { i64, ptr } %t564, ptr %l219, !tbaa !27
  %t565 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t566 = load ptr, ptr %t565, !tbaa !27
  %t567 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = load i64, ptr %l218, !tbaa !24
  %t570 = mul i64 %t569, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t566, ptr %t568, i64 %t570, i1 false)
  %t571 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t574 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t578 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t580 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t581 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t583 = extractvalue { i64, ptr } %t573, 1
  %t584 = extractvalue { i64, ptr } %t573, 0
  %t585 = add i64 %t581, %t584
  %t586 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t587 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t588 = add i64 %t585, %t587
  %t590 = extractvalue { i64, ptr } %t574, 1
  %t591 = extractvalue { i64, ptr } %t574, 0
  %t592 = add i64 %t588, %t591
  %t593 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t594 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t595 = add i64 %t592, %t594
  %t597 = extractvalue { i64, ptr } %t575, 1
  %t598 = extractvalue { i64, ptr } %t575, 0
  %t599 = add i64 %t595, %t598
  %t600 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t601 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t602 = add i64 %t599, %t601
  %t604 = extractvalue { i64, ptr } %t576, 1
  %t605 = extractvalue { i64, ptr } %t576, 0
  %t606 = add i64 %t602, %t605
  %t607 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t608 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t609 = add i64 %t606, %t608
  %t611 = extractvalue { i64, ptr } %t577, 1
  %t612 = extractvalue { i64, ptr } %t577, 0
  %t613 = add i64 %t609, %t612
  %t614 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t615 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t616 = add i64 %t613, %t615
  %t618 = extractvalue { i64, ptr } %t578, 1
  %t619 = extractvalue { i64, ptr } %t578, 0
  %t620 = add i64 %t616, %t619
  %t621 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t622 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t623 = add i64 %t620, %t622
  %t625 = extractvalue { i64, ptr } %t571, 1
  %t626 = extractvalue { i64, ptr } %t571, 0
  %t627 = add i64 %t623, %t626
  %t628 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t629 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t630 = add i64 %t627, %t629
  %t631 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t630)
  call void @olang_textcopy(ptr %t631, ptr %t580, i64 %t581)
  %t632 = getelementptr i8, ptr %t631, i64 %t581
  call void @olang_textcopy(ptr %t632, ptr %t583, i64 %t584)
  %t633 = getelementptr i8, ptr %t632, i64 %t584
  call void @olang_textcopy(ptr %t633, ptr %t586, i64 %t587)
  %t634 = getelementptr i8, ptr %t633, i64 %t587
  call void @olang_textcopy(ptr %t634, ptr %t590, i64 %t591)
  %t635 = getelementptr i8, ptr %t634, i64 %t591
  call void @olang_textcopy(ptr %t635, ptr %t593, i64 %t594)
  %t636 = getelementptr i8, ptr %t635, i64 %t594
  call void @olang_textcopy(ptr %t636, ptr %t597, i64 %t598)
  %t637 = getelementptr i8, ptr %t636, i64 %t598
  call void @olang_textcopy(ptr %t637, ptr %t600, i64 %t601)
  %t638 = getelementptr i8, ptr %t637, i64 %t601
  call void @olang_textcopy(ptr %t638, ptr %t604, i64 %t605)
  %t639 = getelementptr i8, ptr %t638, i64 %t605
  call void @olang_textcopy(ptr %t639, ptr %t607, i64 %t608)
  %t640 = getelementptr i8, ptr %t639, i64 %t608
  call void @olang_textcopy(ptr %t640, ptr %t611, i64 %t612)
  %t641 = getelementptr i8, ptr %t640, i64 %t612
  call void @olang_textcopy(ptr %t641, ptr %t614, i64 %t615)
  %t642 = getelementptr i8, ptr %t641, i64 %t615
  call void @olang_textcopy(ptr %t642, ptr %t618, i64 %t619)
  %t643 = getelementptr i8, ptr %t642, i64 %t619
  call void @olang_textcopy(ptr %t643, ptr %t621, i64 %t622)
  %t644 = getelementptr i8, ptr %t643, i64 %t622
  call void @olang_textcopy(ptr %t644, ptr %t625, i64 %t626)
  %t645 = getelementptr i8, ptr %t644, i64 %t626
  call void @olang_textcopy(ptr %t645, ptr %t628, i64 %t629)
  %t646 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t631, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v3, ptr %t572, { i64, ptr } %t647)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWordsClear(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3afnEm_2egenLeaves(ptr %v0, ptr %s0, ptr %v2, ptr %t1, i32 %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l12
  br label %bb1
bb1:
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %l12)
  store i64 %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load i64, ptr %l14, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWord(ptr %v0, ptr %v1, ptr %s2, ptr %v2, ptr %t58, { i64, ptr } %a1, i32 %t60, i64 %t55)
  store { i64, ptr } %t66, ptr %l45
  br label %bb13
bb13:
  %t67 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t69 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = add i64 %t68, %t71
  %t73 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t67, i64 %t68)
  %t77 = getelementptr i8, ptr %t76, i64 %t68
  call void @olang_textcopy(ptr %t77, ptr %t70, i64 %t71)
  %t78 = getelementptr i8, ptr %t77, i64 %t71
  call void @olang_textcopy(ptr %t78, ptr %t73, i64 %t74)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t76, 1
  %t82 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %v2, ptr %t82, { i64, ptr } %t80)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb9
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedInto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca { { i64, ptr }, i32 }
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i64
  %l36 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l57 = alloca { i64, [4 x i64] }
  %l60 = alloca { i64, [4 x i64] }
  %l61 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l82 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l103 = alloca { i64, [4 x i64] }
  %l105 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l120 = alloca { { i64, ptr }, i32 }
  %l122 = alloca ptr
  %l125 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  store ptr %t9, ptr %l21, !tbaa !29
  %t11 = load ptr, ptr %l21, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v1, ptr %t11)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t17 = load ptr, ptr %l21, !tbaa !29
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t16, ptr %t17, i32 %a2)
  store i32 %t19, ptr %l24
  br label %bb1
bb1:
  %t20 = load i32, ptr %l24, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  store ptr %t21, ptr %l25, !tbaa !29
  %t22 = load i32, ptr %l5, !tbaa !23
  %t23 = load ptr, ptr %l25, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v1, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l25, !tbaa !29
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %t28, ptr %t29, i32 %t22)
  store i1 %t31, ptr %l28
  br label %bb2
bb2:
  %t32 = load i1, ptr %l28, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb6
bb4:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v1, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l33
  br label %bb5
bb5:
  %t40 = load i64, ptr %l33, !tbaa !24
  %t41 = icmp eq i64 %t40, 0
  store i1 %t41, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t43 = load i1, ptr %l30, !tbaa !21
  br i1 %t43, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d246, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t47 = load { i64, [15 x i64] }, ptr %l3
  %t49 = extractvalue { i64, [15 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 6
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t53 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t52, i32 0, i32 2
  %t54 = load %"compiler/mir:Range", ptr %t53
  store %"compiler/mir:Range" %t54, ptr %l7
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l5, !tbaa !23
  %t58 = load %"compiler/mir:Range", ptr %l7
  %t62 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedMake(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %t56, i32 %t57, %"compiler/mir:Range" %t58)
  store { i64, ptr } %t62, ptr %l44
  br label %bb13
bb13:
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t63, ptr %l45, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t64, ptr %l6, !tbaa !27
  %t65 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epackedInto_2elocal_2e6
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load { i64, ptr }, ptr %l45
  %t68 = extractvalue { i64, ptr } %t67, 1
  call void @__olang_region_release(ptr %t68)
  store { i64, ptr } zeroinitializer, ptr %l45
  br label %bb15
bb15:
  br label %bb57
bb16:
  %t69 = load { i64, [15 x i64] }, ptr %l3
  %t71 = extractvalue { i64, [15 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 3
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t74 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t75 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !range !{i32 0, i32 54}
  store i32 %t76, ptr %l8
  %t78 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t79 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t78, i32 0, i32 2
  %t80 = load %"compiler/mir:Range", ptr %t79
  store %"compiler/mir:Range" %t80, ptr %l9
  br label %bb19
bb18:
  br label %bb52
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load i32, ptr %l8, !range !{i32 0, i32 54}
  %t84 = trunc i64 43 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/mir:Range", ptr %l9
  %t94 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t90, %"compiler/mir:Range" %t91, i64 0)
  store { i64, [4 x i64] } %t94, ptr %l57
  br label %bb23
bb23:
  %t95 = load { i64, [4 x i64] }, ptr %l57
  store { i64, [4 x i64] } %t95, ptr %l10
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/mir:Range", ptr %l9
  %t100 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t96, %"compiler/mir:Range" %t97, i64 1)
  store { i64, [4 x i64] } %t100, ptr %l60
  br label %bb24
bb24:
  %t101 = load { i64, [4 x i64] }, ptr %l60
  store { i64, [4 x i64] } %t101, ptr %l11
  %t102 = load { i64, [4 x i64] }, ptr %l11
  %t104 = extractvalue { i64, [4 x i64] } %t102, 0
  %t105 = icmp eq i64 %t104, 2
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t107 = getelementptr { i64, [4 x i64] }, ptr %l11, i32 0, i32 1
  %t108 = getelementptr { i32, i64 }, ptr %t107, i32 0, i32 1
  %t109 = load i64, ptr %t108
  store i64 %t109, ptr %l12, !tbaa !24
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t111 = load i64, ptr %l12, !tbaa !24
  store i64 %t111, ptr %l61, !tbaa !24
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_44ed23dda5502268_7ffab923032619a4)
  unreachable
bb33:
  %t113 = load i64, ptr %l61, !tbaa !24
  store i64 %t113, ptr %l13, !tbaa !24
  %t114 = load ptr, ptr %l4, !tbaa !29
  store ptr %t114, ptr %l66, !tbaa !29
  %t115 = load ptr, ptr %l4, !tbaa !29
  store ptr %t115, ptr %l67, !tbaa !29
  %t116 = load i32, ptr %l5, !tbaa !23
  %t117 = load ptr, ptr %l67, !tbaa !29
  %t118 = call ptr @__olang_scope_or(ptr %v1, ptr %t117)
  %t119 = call ptr @__olang_scope_hold(ptr %t118)
  %t120 = ptrtoint ptr %t119 to i64
  %t122 = inttoptr i64 %t120 to ptr
  %t123 = load ptr, ptr %l67, !tbaa !29
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %t122, ptr %t123, i32 %t116)
  store i32 %t125, ptr %l70
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l66, !tbaa !29
  %t127 = call ptr @__olang_scope_or(ptr %v1, ptr %t126)
  %t128 = call ptr @__olang_scope_hold(ptr %t127)
  %t129 = ptrtoint ptr %t128 to i64
  %t131 = inttoptr i64 %t129 to ptr
  %t132 = load ptr, ptr %l66, !tbaa !29
  %t133 = load i32, ptr %l70, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t131, ptr %s3, ptr %t132, i32 %t133)
  store { i64, ptr } %t134, ptr %l72
  br label %bb35
bb35:
  %t135 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t135, ptr %l73, !tbaa !27
  %t136 = load i64, ptr %l13, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr i32, ptr %t139, i64 %t136
  %t141 = load i32, ptr %t140, !tbaa !33
  store i32 %t141, ptr %l14, !tbaa !23
  %t143 = load ptr, ptr %l4, !tbaa !29
  store ptr %t143, ptr %l76, !tbaa !29
  %t144 = load i32, ptr %l14, !tbaa !23
  %t145 = load ptr, ptr %l76, !tbaa !29
  %t146 = call ptr @__olang_scope_or(ptr %v1, ptr %t145)
  %t147 = call ptr @__olang_scope_hold(ptr %t146)
  %t148 = ptrtoint ptr %t147 to i64
  %t150 = inttoptr i64 %t148 to ptr
  %t151 = load ptr, ptr %l76, !tbaa !29
  %t153 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %t150, ptr %t151, i32 %t144)
  store i64 %t153, ptr %l79
  br label %bb36
bb36:
  %t154 = load i64, ptr %l79, !tbaa !24
  store i64 %t154, ptr %l15, !tbaa !24
  %t155 = call ptr @__olang_scope_hold(ptr %s0)
  %t156 = ptrtoint ptr %t155 to i64
  store i64 %t156, ptr %l80, !tbaa !24
  %t157 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epackedInto_2elocal_2e6
  br i1 %t157, label %bb37, label %bb38
bb37:
  %t159 = call ptr @__olang_region_make(ptr %s0)
  %t160 = ptrtoint ptr %t159 to i64
  store i64 %t160, ptr %l80, !tbaa !24
  br label %bb38
bb38:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l82, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load { i64, [4 x i64] }, ptr %l10
  %t164 = load i32, ptr %l5, !tbaa !23
  %t168 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedBits(ptr %v0, ptr %s3, ptr %v1, ptr %v2, ptr %t162, { i64, [4 x i64] } %t163, i32 %t164)
  store { i64, ptr } %t168, ptr %l86
  br label %bb39
bb39:
  %t169 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t169, ptr %l87, !tbaa !27
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l5, !tbaa !23
  %t174 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v1, ptr %t170, i32 %t171)
  store i64 %t174, ptr %l90
  br label %bb40
bb40:
  %t175 = load i64, ptr %l90, !tbaa !24
  %t176 = mul i64 8, %t175
  store i64 %t176, ptr %l91, !tbaa !24
  %t177 = load ptr, ptr %l4, !tbaa !29
  store ptr %t177, ptr %l92, !tbaa !29
  %t178 = load i32, ptr %l5, !tbaa !23
  %t179 = load ptr, ptr %l92, !tbaa !29
  %t180 = call ptr @__olang_scope_or(ptr %v1, ptr %t179)
  %t181 = call ptr @__olang_scope_hold(ptr %t180)
  %t182 = ptrtoint ptr %t181 to i64
  %t184 = inttoptr i64 %t182 to ptr
  %t185 = load ptr, ptr %l92, !tbaa !29
  %t187 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %t184, ptr %s3, ptr %t185, i32 %t178)
  store { i64, ptr } %t187, ptr %l95
  br label %bb41
bb41:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  store i64 %t193, ptr %l97, !tbaa !24
  %t194 = load i64, ptr %l15, !tbaa !24
  store i64 %t194, ptr %l98, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l99, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l100, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load %"compiler/mir:Range", ptr %l9
  %t201 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v2, ptr %t197, %"compiler/mir:Range" %t198, i64 2)
  store { i64, [4 x i64] } %t201, ptr %l103
  br label %bb42
bb42:
  %t202 = load i32, ptr %l14, !tbaa !23
  %t203 = load ptr, ptr %l100, !tbaa !29
  %t204 = load { i64, [4 x i64] }, ptr %l103
  %t206 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s3, ptr %v2, ptr %v1, ptr %t203, { i64, [4 x i64] } %t204, i32 %t202)
  store { i64, ptr } %t206, ptr %l105
  br label %bb43
bb43:
  %t207 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t208 = load i32, ptr %l14, !tbaa !23
  %t209 = load i64, ptr %l15, !tbaa !24
  %t210 = load ptr, ptr %l99, !tbaa !29
  %t214 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etoBits(ptr %v0, ptr %s3, ptr %s3, ptr %v1, ptr %t210, { i64, ptr } %t207, i32 %t208, i64 %t209)
  store { i64, ptr } %t214, ptr %l109
  br label %bb44
bb44:
  %t215 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t216 = load i64, ptr %l80
  %t217 = inttoptr i64 %t216 to ptr
  %t218 = load ptr, ptr %l82, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t220 = load i64, ptr %l91, !tbaa !24
  %t221 = load i64, ptr %l97, !tbaa !24
  %t222 = load i64, ptr %l98, !tbaa !24
  %t224 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceBits(ptr %v0, ptr %s3, ptr %s3, ptr %t217, ptr %v1, ptr %t218, { i64, ptr } %t219, i64 %t220, i64 %t221, i64 %t222, { i64, ptr } %t215)
  store { i64, ptr } %t224, ptr %l111
  br label %bb45
bb45:
  %t225 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epackedInto_2elocal_2e6
  br i1 %t225, label %bb46, label %bb47
bb46:
  %t227 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t230 = icmp eq i64 %t228, 0
  br i1 %t230, label %bb48, label %bb49
bb47:
  %t232 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t232, ptr %l115, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t233, ptr %l6, !tbaa !27
  %t234 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epackedInto_2elocal_2e6
  br i1 %t234, label %bb50, label %bb51
bb48:
  store { i64, ptr } zeroinitializer, ptr %l111, !tbaa !27
  br label %bb49
bb49:
  %t236 = load i64, ptr %l80
  %t237 = inttoptr i64 %t236 to ptr
  %t238 = load { i64, ptr }, ptr %l111
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = call ptr @__olang_region_or(ptr %t239, ptr null)
  %t241 = icmp ne ptr %t240, null
  %t242 = select i1 %t241, ptr %t240, ptr null
  call void @__olang_region_settle_in(ptr %t237, ptr %t242)
  br label %bb47
bb50:
  %t243 = load { i64, ptr }, ptr %l115
  %t244 = extractvalue { i64, ptr } %t243, 1
  call void @__olang_region_release(ptr %t244)
  store { i64, ptr } zeroinitializer, ptr %l115
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb56:
  call void @__olang_check_failed(ptr @olang_loc_745b41379bd01239_c904106b8ad08895)
  unreachable
bb57:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t250 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t246, %"compiler/mir:Lvalue" %a1)
  store { { i64, ptr }, i32 } %t250, ptr %l120
  br label %bb58
bb58:
  %t251 = load { { i64, ptr }, i32 }, ptr %l120
  store { { i64, ptr }, i32 } %t251, ptr %l16
  %t252 = getelementptr { { i64, ptr }, i32 }, ptr %l16, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l17, !tbaa !27
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l122, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i32, ptr %l5, !tbaa !23
  %t260 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v1, ptr %t256, i32 %t257)
  store i64 %t260, ptr %l125
  br label %bb59
bb59:
  %t261 = load i64, ptr %l125, !tbaa !24
  %t262 = mul i64 8, %t261
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t266 = call i64 @__olang_fmt_i64(ptr null, i64 %t262)
  %t267 = add i64 %t264, %t266
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t263, i64 %t264)
  %t269 = getelementptr i8, ptr %t268, i64 %t264
  %t270 = call i64 @__olang_fmt_i64(ptr %t269, i64 %t262)
  %t271 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t268, 1
  %t274 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t276 = load ptr, ptr %l122, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t276, { i64, ptr } %t272, { i64, ptr } %t274, { i64, ptr } %t275, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) })
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca { i64, [4 x i64] }
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %v3, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d249, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l8, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l26, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l10, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l11, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l44, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l11, !tbaa !24
  %t66 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v4, ptr %t60, %"compiler/mir:Range" %a3, i64 %t62)
  store { i64, [4 x i64] } %t66, ptr %l48
  br label %bb12
bb12:
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t67, ptr %l49, !tbaa !27
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i32, ptr %t71, i64 %t68
  %t73 = load i32, ptr %t72, !tbaa !33
  %t74 = load ptr, ptr %l44, !tbaa !29
  %t75 = load { i64, [4 x i64] }, ptr %l48
  %t77 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s2, ptr %v4, ptr %v3, ptr %t74, { i64, [4 x i64] } %t75, i32 %t73)
  store { i64, ptr } %t77, ptr %l52
  br label %bb13
bb13:
  %t78 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t78, ptr %l12, !tbaa !27
  %t79 = call ptr @__olang_scope_hold(ptr %v2)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l53, !tbaa !24
  %t81 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eparts_2elocal_2e5
  br i1 %t81, label %bb14, label %bb15
bb14:
  %t83 = call ptr @__olang_region_make(ptr %v2)
  %t84 = ptrtoint ptr %t83 to i64
  store i64 %t84, ptr %l53, !tbaa !24
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l55, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t86, ptr %l56, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t87, ptr %l57, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t89, ptr %l59, !tbaa !27
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %v3, ptr %t88, i32 %t95)
  store { i64, ptr } %t98, ptr %l62
  br label %bb16
bb16:
  %t99 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t103 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = add i64 %t109, %t112
  %t114 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t117 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = add i64 %t116, %t119
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t125 = extractvalue { i64, ptr } %t99, 1
  %t126 = extractvalue { i64, ptr } %t99, 0
  %t127 = add i64 %t123, %t126
  %t128 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t132 = call i64 @__olang_fmt_i64(ptr null, i64 %t100)
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t101, i64 %t102)
  %t135 = getelementptr i8, ptr %t134, i64 %t102
  call void @olang_textcopy(ptr %t135, ptr %t104, i64 %t105)
  %t136 = getelementptr i8, ptr %t135, i64 %t105
  call void @olang_textcopy(ptr %t136, ptr %t107, i64 %t108)
  %t137 = getelementptr i8, ptr %t136, i64 %t108
  call void @olang_textcopy(ptr %t137, ptr %t111, i64 %t112)
  %t138 = getelementptr i8, ptr %t137, i64 %t112
  call void @olang_textcopy(ptr %t138, ptr %t114, i64 %t115)
  %t139 = getelementptr i8, ptr %t138, i64 %t115
  call void @olang_textcopy(ptr %t139, ptr %t118, i64 %t119)
  %t140 = getelementptr i8, ptr %t139, i64 %t119
  call void @olang_textcopy(ptr %t140, ptr %t121, i64 %t122)
  %t141 = getelementptr i8, ptr %t140, i64 %t122
  call void @olang_textcopy(ptr %t141, ptr %t125, i64 %t126)
  %t142 = getelementptr i8, ptr %t141, i64 %t126
  call void @olang_textcopy(ptr %t142, ptr %t128, i64 %t129)
  %t143 = getelementptr i8, ptr %t142, i64 %t129
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t100)
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t134, 1
  %t148 = load i64, ptr %l53
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = load ptr, ptr %l55, !tbaa !29
  %t152 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s2, ptr %t149, ptr %v3, ptr %t150, { i64, ptr } %t146)
  store { i64, ptr } %t152, ptr %l67
  br label %bb17
bb17:
  %t153 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eparts_2elocal_2e5
  br i1 %t153, label %bb18, label %bb19
bb18:
  %t155 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t158 = icmp eq i64 %t156, 0
  br i1 %t158, label %bb20, label %bb21
bb19:
  %t160 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t160, ptr %l71, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t161, ptr %l5, !tbaa !27
  %t162 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eparts_2elocal_2e5
  br i1 %t162, label %bb22, label %bb23
bb20:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb21
bb21:
  %t164 = load i64, ptr %l53
  %t165 = inttoptr i64 %t164 to ptr
  %t166 = load { i64, ptr }, ptr %l67
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_region_or(ptr %t167, ptr null)
  %t169 = icmp ne ptr %t168, null
  %t170 = select i1 %t169, ptr %t168, ptr null
  call void @__olang_region_settle_in(ptr %t165, ptr %t170)
  br label %bb19
bb22:
  %t171 = load { i64, ptr }, ptr %l71
  %t172 = extractvalue { i64, ptr } %t171, 1
  call void @__olang_region_release(ptr %t172)
  store { i64, ptr } zeroinitializer, ptr %l71
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t173 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t173, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb8
bb25:
  %t178 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t182 = icmp eq i64 %t180, 0
  br i1 %t182, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d253, i32 0, i32 1) }, ptr %l79, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t184, ptr %l80, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  store i64 %t186, ptr %l81, !tbaa !24
  %t187 = load i64, ptr %l81, !tbaa !24
  %t188 = mul i64 %t187, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l82, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l81, !tbaa !24
  %t197 = mul i64 %t196, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t193, ptr %t195, i64 %t197, i1 false)
  %t198 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t198, ptr %l80, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t200 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epartsResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/cabi:Way" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/cabi:Way"
  %l2 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca i64
  %l41 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l77 = alloca i64
  %l79 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/cabi:Way" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l18, !tbaa !29
  store ptr %t7, ptr %l19, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l19, !tbaa !29
  %t13 = call ptr @__olang_scope_or(ptr %v4, ptr %t12)
  %t14 = call ptr @__olang_scope_hold(ptr %t13)
  %t15 = ptrtoint ptr %t14 to i64
  %t17 = inttoptr i64 %t15 to ptr
  %t18 = load ptr, ptr %l19, !tbaa !29
  %t21 = call i64 @compiler_2fcabi_2eSpan(ptr %t17, ptr %v1, ptr %t18, ptr %l1, i32 %t11)
  store i64 %t21, ptr %l23
  br label %bb1
bb1:
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t24 = load i64, ptr %l23, !tbaa !24
  %t25 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t26 = add i64 %t23, %t25
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t22, i64 %t23)
  %t31 = getelementptr i8, ptr %t30, i64 %t23
  %t32 = call i64 @__olang_fmt_i64(ptr %t31, i64 %t24)
  %t33 = getelementptr i8, ptr %t31, i64 %t25
  call void @olang_textcopy(ptr %t33, ptr %t27, i64 %t28)
  %t34 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t30, 1
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t39 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %s0, ptr %t37, { i64, ptr } %t35, i64 8)
  store { i64, ptr } %t39, ptr %l26
  br label %bb2
bb2:
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l27, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/emit:fnEm", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l29, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t47 = load ptr, ptr %l29, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v4, ptr %t47)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t50 to ptr
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %t52, ptr %s0, ptr %t53, i32 %t46)
  store { i64, ptr } %t55, ptr %l32
  br label %bb3
bb3:
  %t56 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t59 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %v2, ptr %s0, ptr %s0, ptr %v4, ptr %t59, { i64, ptr } %t56, { i64, ptr } %a3, { i64, ptr } %t58, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) })
  br label %bb4
bb4:
  %t64 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v1, ptr %s0, ptr %l1)
  store { i64, ptr } %t64, ptr %l37
  br label %bb5
bb5:
  %t65 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t65, ptr %l6, !tbaa !27
  %t66 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t66)
  store i64 %t68, ptr %l39
  br label %bb6
bb6:
  %t69 = load i64, ptr %l39, !tbaa !24
  %t70 = icmp eq i64 %t69, 1
  br i1 %t70, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t72, ptr %l41, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s2, ptr %s2, ptr %v4, ptr %t73, { i64, ptr } %t74, { i64, ptr } %t75, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t79, ptr %l45
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t80 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t83, i64 %t84)
  %t92 = getelementptr i8, ptr %t91, i64 %t84
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t90, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t94, ptr %rv
  br label %ret
bb10:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d257, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t96, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t98 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t98)
  store i64 %t100, ptr %l50
  br label %bb11
bb11:
  %t101 = load i64, ptr %l50, !tbaa !24
  store i64 %t101, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb12, label %bb13
bb12:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb17
bb14:
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l57, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb16
bb16:
  %t128 = load i64, ptr %l57, !tbaa !24
  store i64 %t128, ptr %l54, !tbaa !24
  br label %bb17
bb17:
  %t129 = load i64, ptr %l54, !tbaa !24
  store i64 %t129, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t130 = load i64, ptr %l12, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb20:
  br label %bb21
bb21:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t139 = load i64, ptr %l12, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l13, !tbaa !24
  %t148 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 2
  %t149 = load i64, ptr %l13, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l77
  br label %bb22
bb22:
  %t153 = load i64, ptr %l77, !tbaa !24
  %t154 = icmp eq i64 %t153, 0
  br i1 %t154, label %bb23, label %bb24
bb23:
  %t156 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t156, ptr %l79, !tbaa !27
  br label %bb27
bb24:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l81, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t159, ptr %l82, !tbaa !27
  %t160 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 2
  %t161 = load i64, ptr %l13, !tbaa !24
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t160, i64 %t161)
  store i64 %t164, ptr %l85
  br label %bb25
bb25:
  %t165 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t167 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t174 = load i64, ptr %l85, !tbaa !24
  %t175 = call i64 @__olang_fmt_i64(ptr null, i64 %t174)
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t165, i64 %t166)
  %t178 = getelementptr i8, ptr %t177, i64 %t166
  call void @olang_textcopy(ptr %t178, ptr %t168, i64 %t169)
  %t179 = getelementptr i8, ptr %t178, i64 %t169
  call void @olang_textcopy(ptr %t179, ptr %t171, i64 %t172)
  %t180 = getelementptr i8, ptr %t179, i64 %t172
  %t181 = call i64 @__olang_fmt_i64(ptr %t180, i64 %t174)
  %t182 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t177, 1
  %t185 = load ptr, ptr %l81, !tbaa !29
  %t187 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s5, ptr %s5, ptr %v4, ptr %t185, { i64, ptr } %t183)
  store { i64, ptr } %t187, ptr %l88
  br label %bb26
bb26:
  %t188 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t188, ptr %l79, !tbaa !27
  br label %bb27
bb27:
  %t189 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l89, !tbaa !24
  %t191 = load i64, ptr %l89, !tbaa !24
  %t192 = mul i64 %t191, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l90, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l89, !tbaa !24
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  %t202 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t202, ptr %l14, !tbaa !27
  %t203 = call ptr @__olang_scope_hold(ptr %s0)
  %t204 = ptrtoint ptr %t203 to i64
  store i64 %t204, ptr %l91, !tbaa !24
  %t205 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epartsResult_2elocal_2e7
  br i1 %t205, label %bb28, label %bb29
bb28:
  %t207 = call ptr @__olang_region_make(ptr %s0)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l91, !tbaa !24
  br label %bb29
bb29:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l93, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t210, ptr %l94, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t211, ptr %l95, !tbaa !27
  %t212 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t213 = load i64, ptr %l13, !tbaa !24
  %t216 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %s5, ptr %t212, i64 %t213)
  store { i64, ptr } %t216, ptr %l98
  br label %bb30
bb30:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l99, !tbaa !29
  %t218 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t219 = load i64, ptr %l13, !tbaa !24
  %t222 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t218, i64 %t219)
  store { i64, ptr } %t222, ptr %l102
  br label %bb31
bb31:
  %t223 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t224 = load ptr, ptr %l99, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %s5, ptr %s5, ptr %s5, ptr %v4, ptr %t224, { i64, ptr } %t225, { i64, ptr } %t223, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t227, ptr %l104
  br label %bb32
bb32:
  %t228 = load i64, ptr %l13, !tbaa !24
  %t229 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t231 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = add i64 %t230, %t233
  %t235 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t237 = add i64 %t234, %t236
  %t238 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = add i64 %t237, %t240
  %t242 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t244 = add i64 %t241, %t243
  %t245 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 1
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t248 = add i64 %t244, %t247
  %t249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t251 = add i64 %t248, %t250
  %t252 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = add i64 %t251, %t254
  %t256 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t258 = add i64 %t255, %t257
  %t260 = call i64 @__olang_fmt_i64(ptr null, i64 %t228)
  %t261 = add i64 %t258, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t229, i64 %t230)
  %t263 = getelementptr i8, ptr %t262, i64 %t230
  call void @olang_textcopy(ptr %t263, ptr %t232, i64 %t233)
  %t264 = getelementptr i8, ptr %t263, i64 %t233
  call void @olang_textcopy(ptr %t264, ptr %t235, i64 %t236)
  %t265 = getelementptr i8, ptr %t264, i64 %t236
  call void @olang_textcopy(ptr %t265, ptr %t239, i64 %t240)
  %t266 = getelementptr i8, ptr %t265, i64 %t240
  call void @olang_textcopy(ptr %t266, ptr %t242, i64 %t243)
  %t267 = getelementptr i8, ptr %t266, i64 %t243
  call void @olang_textcopy(ptr %t267, ptr %t246, i64 %t247)
  %t268 = getelementptr i8, ptr %t267, i64 %t247
  call void @olang_textcopy(ptr %t268, ptr %t249, i64 %t250)
  %t269 = getelementptr i8, ptr %t268, i64 %t250
  call void @olang_textcopy(ptr %t269, ptr %t253, i64 %t254)
  %t270 = getelementptr i8, ptr %t269, i64 %t254
  call void @olang_textcopy(ptr %t270, ptr %t256, i64 %t257)
  %t271 = getelementptr i8, ptr %t270, i64 %t257
  %t272 = call i64 @__olang_fmt_i64(ptr %t271, i64 %t228)
  %t273 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t262, 1
  %t276 = load i64, ptr %l91
  %t277 = inttoptr i64 %t276 to ptr
  %t278 = load ptr, ptr %l93, !tbaa !29
  %t280 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s5, ptr %t277, ptr %v4, ptr %t278, { i64, ptr } %t274)
  store { i64, ptr } %t280, ptr %l108
  br label %bb33
bb33:
  %t281 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epartsResult_2elocal_2e7
  br i1 %t281, label %bb34, label %bb35
bb34:
  %t283 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 0
  %t286 = icmp eq i64 %t284, 0
  br i1 %t286, label %bb36, label %bb37
bb35:
  %t288 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t288, ptr %l112, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t289, ptr %l7, !tbaa !27
  %t290 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epartsResult_2elocal_2e7
  br i1 %t290, label %bb38, label %bb39
bb36:
  store { i64, ptr } zeroinitializer, ptr %l108, !tbaa !27
  br label %bb37
bb37:
  %t292 = load i64, ptr %l91
  %t293 = inttoptr i64 %t292 to ptr
  %t294 = load { i64, ptr }, ptr %l108
  %t295 = extractvalue { i64, ptr } %t294, 1
  %t296 = call ptr @__olang_region_or(ptr %t295, ptr null)
  %t297 = icmp ne ptr %t296, null
  %t298 = select i1 %t297, ptr %t296, ptr null
  call void @__olang_region_settle_in(ptr %t293, ptr %t298)
  br label %bb35
bb38:
  %t299 = load { i64, ptr }, ptr %l112
  %t300 = extractvalue { i64, ptr } %t299, 1
  call void @__olang_region_release(ptr %t300)
  store { i64, ptr } zeroinitializer, ptr %l112
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  %t301 = load i64, ptr %l12, !tbaa !24
  %t304 = add i64 %t301, 1
  store i64 %t304, ptr %l12, !tbaa !24
  br label %bb18
bb41:
  %t306 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t306, 1
  %t310 = extractvalue { i64, ptr } %t306, 0
  %t311 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t313 = add i64 %t310, %t312
  %t315 = extractvalue { i64, ptr } %t307, 1
  %t316 = extractvalue { i64, ptr } %t307, 0
  %t317 = add i64 %t313, %t316
  %t318 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t317)
  call void @olang_textcopy(ptr %t318, ptr %t309, i64 %t310)
  %t319 = getelementptr i8, ptr %t318, i64 %t310
  call void @olang_textcopy(ptr %t319, ptr %t311, i64 %t312)
  %t320 = getelementptr i8, ptr %t319, i64 %t312
  call void @olang_textcopy(ptr %t320, ptr %t315, i64 %t316)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t318, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t322, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { { i64, ptr }, i32 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca { i64, [4 x i64] }
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca i32
  %l27 = alloca %"compiler/mir:Range"
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca i32
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, [2 x i64] }
  %l32 = alloca %"compiler/mir:Lvalue"
  %l33 = alloca { { i64, ptr }, i32 }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca %"compiler/mir:Lvalue"
  %l38 = alloca { { i64, ptr }, i32 }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"compiler/mir:Lvalue"
  %l44 = alloca { { i64, ptr }, i32 }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l49 = alloca %"compiler/mir:Lvalue"
  %l50 = alloca { { i64, ptr }, i32 }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, [1 x i64] }
  %l58 = alloca i32
  %l59 = alloca { i64, [4 x i64] }
  %l60 = alloca %"compiler/mir:Lvalue"
  %l61 = alloca %"compiler/mir:Lvalue"
  %l62 = alloca { i64, [4 x i64] }
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca i32
  %l68 = alloca i32
  %l75 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca ptr
  %l79 = alloca i1
  %l88 = alloca i1
  %l94 = alloca i32
  %l99 = alloca i1
  %l104 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i1
  %l113 = alloca i1
  %l117 = alloca { i64, ptr }
  %l121 = alloca i1
  %l127 = alloca { { i64, ptr }, i32 }
  %l129 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca i1
  %l146 = alloca ptr
  %l150 = alloca %"compiler/mir:Local"
  %l154 = alloca i1
  %l158 = alloca i32
  %l159 = alloca ptr
  %l160 = alloca { i64, [1 x i64] }
  %l163 = alloca i64
  %l165 = alloca { i64, ptr }
  %l168 = alloca i64
  %l169 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l189 = alloca i1
  %l194 = alloca i1
  %l201 = alloca ptr
  %l205 = alloca %"compiler/mir:ScopeInfo"
  %l219 = alloca ptr
  %l223 = alloca %"compiler/mir:ScopeInfo"
  %l233 = alloca ptr
  %l237 = alloca %"compiler/mir:ScopeInfo"
  %l251 = alloca ptr
  %l252 = alloca i1
  %l261 = alloca i1
  %l262 = alloca i1
  %l267 = alloca i1
  %l270 = alloca ptr
  %l274 = alloca %"compiler/mir:ScopeInfo"
  %l278 = alloca ptr
  %l280 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l315 = alloca ptr
  %l317 = alloca i64
  %l323 = alloca i64
  %l325 = alloca ptr
  %l336 = alloca ptr
  %l337 = alloca i1
  %l344 = alloca ptr
  %l345 = alloca i1
  %l351 = alloca ptr
  %l353 = alloca ptr
  %l357 = alloca { i64, ptr }
  %l360 = alloca ptr
  %l361 = alloca i1
  %l365 = alloca ptr
  %l368 = alloca ptr
  %l369 = alloca i1
  %l373 = alloca ptr
  %l374 = alloca i1
  %l381 = alloca ptr
  %l382 = alloca { i64, [4 x i64] }
  %l386 = alloca { i64, ptr }
  %l388 = alloca ptr
  %l389 = alloca i1
  %l402 = alloca ptr
  %l403 = alloca i1
  %l412 = alloca { i64, [2 x i64] }
  %l413 = alloca ptr
  %l414 = alloca i32
  %l415 = alloca i64
  %l418 = alloca ptr
  %l421 = alloca i64
  %l422 = alloca i32
  %l424 = alloca { i64, [2 x i64] }
  %l425 = alloca i32
  %l426 = alloca ptr
  %l427 = alloca ptr
  %l431 = alloca { i64, ptr }
  %l435 = alloca ptr
  %l440 = alloca ptr
  %l443 = alloca i1
  %l447 = alloca ptr
  %l452 = alloca ptr
  %l456 = alloca ptr
  %l458 = alloca ptr
  %l461 = alloca { i64, ptr }
  %l465 = alloca { i64, ptr }
  %l467 = alloca ptr
  %l470 = alloca { i64, ptr }
  %l473 = alloca ptr
  %l474 = alloca i1
  %l481 = alloca { { i64, ptr }, i32 }
  %l482 = alloca { i64, ptr }
  %l483 = alloca i64
  %l484 = alloca { i64, ptr }
  %l486 = alloca ptr
  %l489 = alloca i1
  %l491 = alloca i1
  %l492 = alloca ptr
  %l495 = alloca i1
  %l498 = alloca ptr
  %l500 = alloca ptr
  %l504 = alloca { i64, ptr }
  %l507 = alloca ptr
  %l510 = alloca { i64, ptr }
  %l513 = alloca ptr
  %l516 = alloca { i64, ptr }
  %l519 = alloca { i64, ptr }
  %l521 = alloca ptr
  %l523 = alloca ptr
  %l527 = alloca { i64, ptr }
  %l528 = alloca i64
  %l529 = alloca { i64, ptr }
  %l532 = alloca ptr
  %l535 = alloca { i64, ptr }
  %l536 = alloca { i64, ptr }
  %l538 = alloca ptr
  %l541 = alloca { i64, ptr }
  %l544 = alloca ptr
  %l545 = alloca i1
  %l552 = alloca { { i64, ptr }, i32 }
  %l555 = alloca ptr
  %l558 = alloca { i64, ptr }
  %l561 = alloca { i64, ptr }
  %l563 = alloca ptr
  %l569 = alloca { i64, ptr }
  %l570 = alloca ptr
  %l574 = alloca { i64, ptr }
  %l575 = alloca i64
  %l576 = alloca { i64, ptr }
  %l580 = alloca ptr
  %l583 = alloca { i64, ptr }
  %l584 = alloca { i64, ptr }
  %l586 = alloca ptr
  %l589 = alloca { i64, ptr }
  %l592 = alloca ptr
  %l593 = alloca i1
  %l600 = alloca { { i64, ptr }, i32 }
  %l603 = alloca ptr
  %l606 = alloca { i64, ptr }
  %l609 = alloca { i64, ptr }
  %l611 = alloca ptr
  %l613 = alloca ptr
  %l617 = alloca { i64, ptr }
  %l618 = alloca i64
  %l619 = alloca { i64, ptr }
  %l622 = alloca ptr
  %l625 = alloca { i64, ptr }
  %l626 = alloca { i64, ptr }
  %l628 = alloca ptr
  %l631 = alloca { i64, ptr }
  %l634 = alloca ptr
  %l635 = alloca i1
  %l644 = alloca { { i64, ptr }, i32 }
  %l645 = alloca { i64, ptr }
  %l646 = alloca i64
  %l647 = alloca { i64, ptr }
  %l649 = alloca ptr
  %l650 = alloca ptr
  %l653 = alloca { i64, ptr }
  %l655 = alloca { i64, ptr }
  %l658 = alloca { i64, ptr }
  %l662 = alloca { i64, ptr }
  %l664 = alloca ptr
  %l671 = alloca ptr
  %l672 = alloca i1
  %l677 = alloca ptr
  %l678 = alloca ptr
  %l681 = alloca { i64, ptr }
  %l683 = alloca { i64, ptr }
  %l686 = alloca { i64, ptr }
  %l688 = alloca ptr
  %l694 = alloca ptr
  %l695 = alloca i1
  %l706 = alloca i1
  %l713 = alloca ptr
  %l716 = alloca { i64, ptr }
  %l720 = alloca ptr
  %l721 = alloca i1
  %l732 = alloca { i64, ptr }
  %l735 = alloca { i64, ptr }
  %l736 = alloca ptr
  %l737 = alloca ptr
  %l740 = alloca i32
  %l741 = alloca i32
  %l743 = alloca i32
  %l744 = alloca ptr
  %l745 = alloca ptr
  %l749 = alloca { i64, ptr }
  %l750 = alloca { i64, ptr }
  %l753 = alloca i32
  %l754 = alloca { i64, ptr }
  %l757 = alloca i64
  %l760 = alloca { i64, ptr }
  %l762 = alloca ptr
  %l770 = alloca ptr
  %l771 = alloca i1
  %l778 = alloca ptr
  %l779 = alloca i32
  %l782 = alloca ptr
  %l786 = alloca %"compiler/mir:Task"
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %t2047 = alloca %"compiler/mir:Task", align 8
  %t2054 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 18
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l75, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = call %"compiler/source:Span" @compiler_2femit_2estmtSpan(ptr %v1, ptr %t17)
  store %"compiler/source:Span" %t19, ptr %l77
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l75, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l77
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %v2, ptr %v3, ptr %t20, %"compiler/source:Span" %t21)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t23 = load ptr, ptr %l78, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l78, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 20}
  %t29 = icmp eq i64 %t27, 0
  store i1 %t29, ptr %l79, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l79, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [21 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t33, i32 0, i32 1
  %t35 = load %"compiler/mir:Lvalue", ptr %t34
  store %"compiler/mir:Lvalue" %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [21 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t39, i32 0, i32 2
  %t41 = load { i64, [15 x i64] }, ptr %t40
  store { i64, [15 x i64] } %t41, ptr %l4
  br label %bb10
bb9:
  br label %bb44
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load { i64, [15 x i64] }, ptr %l4
  %t45 = extractvalue { i64, [15 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 0
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t49 = getelementptr { { i64, [4 x i64] } }, ptr %t48, i32 0, i32 0
  %t50 = load { i64, [4 x i64] }, ptr %t49
  %t52 = extractvalue { i64, [4 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 0
  store i1 %t53, ptr %l88, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l88, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t56 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t57 = getelementptr { { i64, [4 x i64] } }, ptr %t56, i32 0, i32 0
  %t58 = load { i64, [4 x i64] }, ptr %t57
  store { i64, [4 x i64] } %t58, ptr %l5
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/mir:Lvalue", ptr %l3
  %t64 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %v3, ptr %v2, ptr %t60, %"compiler/mir:Lvalue" %t61)
  store i32 %t64, ptr %l94
  br label %bb17
bb17:
  %t65 = load i32, ptr %l94, !tbaa !23
  store i32 %t65, ptr %l6, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/mir:Lvalue", ptr %l3
  %t68 = load i32, ptr %l6, !tbaa !23
  %t69 = load { i64, [15 x i64] }, ptr %l4
  %t74 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedInto(ptr %v0, ptr %v2, ptr %v3, ptr %t66, %"compiler/mir:Lvalue" %t67, i32 %t68, { i64, [15 x i64] } %t69)
  store i1 %t74, ptr %l99
  br label %bb18
bb18:
  %t75 = load i1, ptr %l99, !tbaa !21
  br i1 %t75, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb20:
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/mir:Lvalue", ptr %l3
  %t78 = load i32, ptr %l6, !tbaa !23
  %t79 = load { i64, [15 x i64] }, ptr %l4
  %t84 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %v2, ptr %v3, ptr %t76, %"compiler/mir:Lvalue" %t77, i32 %t78, { i64, [15 x i64] } %t79)
  store i1 %t84, ptr %l104
  br label %bb22
bb22:
  %t85 = load i1, ptr %l104, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb24:
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l6, !tbaa !23
  %t90 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %v2, ptr %t86, i32 %t87)
  store i1 %t90, ptr %l107
  br label %bb26
bb26:
  %t91 = load i1, ptr %l107, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/mir:Lvalue", ptr %l3
  %t94 = load i32, ptr %l6, !tbaa !23
  %t95 = load { i64, [15 x i64] }, ptr %l4
  %t100 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eintoPlace(ptr %v0, ptr %v3, ptr %v2, ptr %t92, %"compiler/mir:Lvalue" %t93, i32 %t94, { i64, [15 x i64] } %t95)
  store i1 %t100, ptr %l113
  br label %bb29
bb28:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb30
bb29:
  %t101 = load i1, ptr %l113, !tbaa !21
  store i1 %t101, ptr %l108, !tbaa !21
  br label %bb30
bb30:
  %t102 = load i1, ptr %l108, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb32:
  br label %bb33
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, [15 x i64] }, ptr %l4
  %t105 = load i32, ptr %l6, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ervalue(ptr %v0, ptr %s2, ptr %v3, ptr %v2, ptr %t103, { i64, [15 x i64] } %t104, i32 %t105)
  store { i64, ptr } %t109, ptr %l117
  br label %bb34
bb34:
  %t110 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t110, ptr %l7, !tbaa !27
  %t111 = load i32, ptr %l6, !tbaa !23
  %t112 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t115 = icmp eq i32 %t111, %t112
  br i1 %t115, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb37
bb36:
  %t117 = load i32, ptr %l6, !tbaa !23
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t121 = icmp eq i32 %t117, %t118
  store i1 %t121, ptr %l121, !tbaa !21
  br label %bb37
bb37:
  %t123 = load i1, ptr %l121, !tbaa !21
  br i1 %t123, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb39:
  br label %bb40
bb40:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/mir:Lvalue", ptr %l3
  %t128 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s2, ptr %v3, ptr %v2, ptr %t124, %"compiler/mir:Lvalue" %t125)
  store { { i64, ptr }, i32 } %t128, ptr %l127
  br label %bb41
bb41:
  %t129 = load { { i64, ptr }, i32 }, ptr %l127
  store { { i64, ptr }, i32 } %t129, ptr %l8
  %t130 = getelementptr { { i64, ptr }, i32 }, ptr %l8, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l9, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l129, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l6, !tbaa !23
  %t138 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %v2, ptr %t134, i32 %t135)
  store { i64, ptr } %t138, ptr %l132
  br label %bb42
bb42:
  %t139 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/emit:fnEm", ptr %t142, i32 0, i32 15
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t146 = load ptr, ptr %l129, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s2, ptr %s2, ptr %s2, ptr %v0, ptr %v2, ptr %t146, { i64, ptr } %t139, { i64, ptr } %t140, { i64, ptr } %t141, { i64, ptr } %t145)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s2)
  br label %bb338
bb44:
  %t151 = load ptr, ptr %l1, !tbaa !29
  store ptr %t151, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t152 = load ptr, ptr %l138, !tbaa !29
  %t153 = icmp ne ptr %t152, null
  br i1 %t153, label %bb45, label %bb46
bb45:
  %t155 = load ptr, ptr %l138, !tbaa !29
  %t156 = load i64, ptr %t155, !range !{i64 0, i64 20}
  %t158 = icmp eq i64 %t156, 1
  store i1 %t158, ptr %l139, !tbaa !21
  br label %bb46
bb46:
  %t159 = load i1, ptr %l139, !tbaa !21
  br i1 %t159, label %bb47, label %bb48
bb47:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr { i64, [21 x i64] }, ptr %t160, i32 0, i32 1
  %t163 = getelementptr { %"compiler/source:Span", i32 }, ptr %t162, i32 0, i32 1
  %t164 = load i32, ptr %t163
  store i32 %t164, ptr %l10, !tbaa !23
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/emit:fnEm", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/mir:Fn", ptr %t169, i32 0, i32 7
  store ptr %t171, ptr %l146, !tbaa !29
  %t172 = load i32, ptr %l10, !tbaa !23
  %t174 = sext i32 %t172 to i64
  %t175 = load ptr, ptr %l146, !tbaa !29
  %t176 = call ptr @__olang_scope_or(ptr %v3, ptr %t175)
  %t177 = call ptr @__olang_scope_hold(ptr %t176)
  %t178 = ptrtoint ptr %t177 to i64
  %t180 = inttoptr i64 %t178 to ptr
  %t181 = load ptr, ptr %l146, !tbaa !29
  %t183 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t180, ptr %t181, i64 %t174)
  store %"compiler/mir:Local" %t183, ptr %l150
  br label %bb50
bb50:
  %t184 = getelementptr %"compiler/mir:Local", ptr %l150, i32 0, i32 4
  %t185 = load { i64, [1 x i64] }, ptr %t184
  store { i64, [1 x i64] } %t185, ptr %l11
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, [1 x i64] }, ptr %l11
  %t191 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t187, { i64, [1 x i64] } %t188)
  store i1 %t191, ptr %l154
  br label %bb51
bb51:
  %t192 = load i1, ptr %l154, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l10, !tbaa !23
  %t199 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %v3, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l158
  br label %bb54
bb53:
  br label %bb59
bb54:
  %t200 = load i32, ptr %l158, !tbaa !23
  store i32 %t200, ptr %l12, !tbaa !23
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l159, !tbaa !29
  %t202 = load { i64, [1 x i64] }, ptr %l11
  store { i64, [1 x i64] } %t202, ptr %l160
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l12, !tbaa !23
  %t207 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v2, ptr %t203, i32 %t204)
  store i64 %t207, ptr %l163
  br label %bb55
bb55:
  %t208 = load i64, ptr %l163, !tbaa !24
  %t209 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t210 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t209)
  %t211 = call i64 @__olang_fmt_i64(ptr %t210, i64 %t208)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t210, 1
  store { i64, ptr } %t213, ptr %l165, !tbaa !27
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr %l12, !tbaa !23
  %t219 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %v2, ptr %t215, i32 %t216)
  store i64 %t219, ptr %l168
  br label %bb56
bb56:
  %t220 = load ptr, ptr %l159, !tbaa !29
  %t221 = load { i64, [1 x i64] }, ptr %l160
  %t222 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t223 = load i64, ptr %l168, !tbaa !24
  %t224 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %v2, ptr %v3, ptr %t220, { i64, [1 x i64] } %t221, { i64, ptr } %t222, i64 %t223, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d264, i32 0, i32 1) })
  store { i64, ptr } %t224, ptr %l169
  br label %bb57
bb57:
  %t225 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l10, !tbaa !23
  %t229 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t232 = sext i32 %t228 to i64
  %t233 = call i64 @__olang_fmt_i64(ptr null, i64 %t232)
  %t234 = add i64 %t230, %t233
  %t235 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t229, i64 %t230)
  %t236 = getelementptr i8, ptr %t235, i64 %t230
  %t237 = call i64 @__olang_fmt_i64(ptr %t236, i64 %t232)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t235, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %s9, ptr %v2, ptr %t226, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d266, i32 0, i32 1) }, { i64, ptr } %t225, { i64, ptr } %t239, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) })
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  br label %bb338
bb60:
  %t244 = load ptr, ptr %l1, !tbaa !29
  store ptr %t244, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t245 = load ptr, ptr %l175, !tbaa !29
  %t246 = icmp ne ptr %t245, null
  br i1 %t246, label %bb61, label %bb62
bb61:
  %t248 = load ptr, ptr %l175, !tbaa !29
  %t249 = load i64, ptr %t248, !range !{i64 0, i64 20}
  %t251 = icmp eq i64 %t249, 2
  store i1 %t251, ptr %l176, !tbaa !21
  br label %bb62
bb62:
  %t252 = load i1, ptr %l176, !tbaa !21
  br i1 %t252, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb338
bb66:
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t254 = load ptr, ptr %l179, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb67, label %bb68
bb67:
  %t257 = load ptr, ptr %l179, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 20}
  %t260 = icmp eq i64 %t258, 3
  store i1 %t260, ptr %l180, !tbaa !21
  br label %bb68
bb68:
  %t261 = load i1, ptr %l180, !tbaa !21
  br i1 %t261, label %bb69, label %bb70
bb69:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [21 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", i32 }, ptr %t264, i32 0, i32 1
  %t266 = load i32, ptr %t265
  store i32 %t266, ptr %l14, !tbaa !23
  br label %bb71
bb70:
  br label %bb103
bb71:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/emit:fnEm", ptr %t268, i32 0, i32 26
  %t271 = load i32, ptr %l14, !tbaa !23
  %t273 = sext i32 %t271 to i64
  %t276 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t270, i64 %t273)
  store i1 %t276, ptr %l189
  br label %bb72
bb72:
  %t277 = load i1, ptr %l189, !tbaa !21
  br i1 %t277, label %bb73, label %bb74
bb73:
  br label %ret
bb74:
  br label %bb75
bb75:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/emit:fnEm", ptr %t278, i32 0, i32 25
  %t281 = load i32, ptr %l14, !tbaa !23
  %t283 = sext i32 %t281 to i64
  %t286 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t280, i64 %t283)
  store i1 %t286, ptr %l194
  br label %bb76
bb76:
  %t287 = load i1, ptr %l194, !tbaa !21
  br i1 %t287, label %bb77, label %bb78
bb77:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/emit:fnEm", ptr %t288, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2eClear_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %t290)
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/emit:fnEm", ptr %t292, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eClear_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t294)
  br label %bb80
bb80:
  br label %ret
bb81:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/emit:fnEm", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = getelementptr %"compiler/mir:Fn", ptr %t299, i32 0, i32 8
  store ptr %t301, ptr %l201, !tbaa !29
  %t302 = load i32, ptr %l14, !tbaa !23
  %t304 = sext i32 %t302 to i64
  %t305 = load ptr, ptr %l201, !tbaa !29
  %t306 = call ptr @__olang_scope_or(ptr %v3, ptr %t305)
  %t307 = call ptr @__olang_scope_hold(ptr %t306)
  %t308 = ptrtoint ptr %t307 to i64
  %t310 = inttoptr i64 %t308 to ptr
  %t311 = load ptr, ptr %l201, !tbaa !29
  %t313 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t310, ptr %t311, i64 %t304)
  store %"compiler/mir:ScopeInfo" %t313, ptr %l205
  br label %bb82
bb82:
  %t314 = getelementptr %"compiler/mir:ScopeInfo", ptr %l205, i32 0, i32 0
  %t315 = load i32, ptr %t314, !range !{i32 0, i32 7}
  %t317 = trunc i64 6 to i32
  %t318 = icmp eq i32 %t315, %t317
  br i1 %t318, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s16
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i32, ptr %l14, !tbaa !23
  %t322 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t325 = sext i32 %t321 to i64
  %t326 = call i64 @__olang_fmt_i64(ptr null, i64 %t325)
  %t327 = add i64 %t323, %t326
  %t328 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t327)
  call void @olang_textcopy(ptr %t328, ptr %t322, i64 %t323)
  %t329 = getelementptr i8, ptr %t328, i64 %t323
  %t330 = call i64 @__olang_fmt_i64(ptr %t329, i64 %t325)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t328, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s16, ptr %v2, ptr %t320, { i64, ptr } %t332)
  br label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s19
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/emit:fnEm", ptr %t336, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = getelementptr %"compiler/mir:Fn", ptr %t339, i32 0, i32 8
  store ptr %t341, ptr %l219, !tbaa !29
  %t342 = load i32, ptr %l14, !tbaa !23
  %t344 = sext i32 %t342 to i64
  %t345 = load ptr, ptr %l219, !tbaa !29
  %t346 = call ptr @__olang_scope_or(ptr %v3, ptr %t345)
  %t347 = call ptr @__olang_scope_hold(ptr %t346)
  %t348 = ptrtoint ptr %t347 to i64
  %t350 = inttoptr i64 %t348 to ptr
  %t351 = load ptr, ptr %l219, !tbaa !29
  %t353 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t350, ptr %t351, i64 %t344)
  store %"compiler/mir:ScopeInfo" %t353, ptr %l223
  br label %bb87
bb85:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l14, !tbaa !23
  %t356 = load i32, ptr %l14, !tbaa !23
  %t357 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t358 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t360 = sext i32 %t355 to i64
  %t361 = call i64 @__olang_fmt_i64(ptr null, i64 %t360)
  %t362 = add i64 %t358, %t361
  %t363 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t365 = add i64 %t362, %t364
  %t367 = sext i32 %t356 to i64
  %t368 = call i64 @__olang_fmt_i64(ptr null, i64 %t367)
  %t369 = add i64 %t365, %t368
  %t370 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t369)
  call void @olang_textcopy(ptr %t370, ptr %t357, i64 %t358)
  %t371 = getelementptr i8, ptr %t370, i64 %t358
  %t372 = call i64 @__olang_fmt_i64(ptr %t371, i64 %t360)
  %t373 = getelementptr i8, ptr %t371, i64 %t361
  call void @olang_textcopy(ptr %t373, ptr %t363, i64 %t364)
  %t374 = getelementptr i8, ptr %t373, i64 %t364
  %t375 = call i64 @__olang_fmt_i64(ptr %t374, i64 %t367)
  %t376 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t370, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s16, ptr %v2, ptr %t354, { i64, ptr } %t377)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s16)
  br label %bb102
bb87:
  %t381 = getelementptr %"compiler/mir:ScopeInfo", ptr %l223, i32 0, i32 0
  %t382 = load i32, ptr %t381, !range !{i32 0, i32 7}
  %t384 = trunc i64 4 to i32
  %t385 = icmp eq i32 %t382, %t384
  br i1 %t385, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s20
  %t387 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s20, ptr %v2, ptr %t387, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d270, i32 0, i32 1) })
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s20)
  br label %bb91
bb91:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load i32, ptr %l14, !tbaa !23
  %t391 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t394 = sext i32 %t390 to i64
  %t395 = call i64 @__olang_fmt_i64(ptr null, i64 %t394)
  %t396 = add i64 %t392, %t395
  %t397 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t396)
  call void @olang_textcopy(ptr %t397, ptr %t391, i64 %t392)
  %t398 = getelementptr i8, ptr %t397, i64 %t392
  %t399 = call i64 @__olang_fmt_i64(ptr %t398, i64 %t394)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t397, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s19, ptr %v2, ptr %t389, { i64, ptr } %t401)
  br label %bb92
bb92:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/emit:fnEm", ptr %t405, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = getelementptr %"compiler/mir:Fn", ptr %t408, i32 0, i32 8
  store ptr %t410, ptr %l233, !tbaa !29
  %t411 = load i32, ptr %l14, !tbaa !23
  %t413 = sext i32 %t411 to i64
  %t414 = load ptr, ptr %l233, !tbaa !29
  %t415 = call ptr @__olang_scope_or(ptr %v3, ptr %t414)
  %t416 = call ptr @__olang_scope_hold(ptr %t415)
  %t417 = ptrtoint ptr %t416 to i64
  %t419 = inttoptr i64 %t417 to ptr
  %t420 = load ptr, ptr %l233, !tbaa !29
  %t422 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t419, ptr %t420, i64 %t413)
  store %"compiler/mir:ScopeInfo" %t422, ptr %l237
  br label %bb93
bb93:
  %t423 = getelementptr %"compiler/mir:ScopeInfo", ptr %l237, i32 0, i32 0
  %t424 = load i32, ptr %t423, !range !{i32 0, i32 7}
  %t426 = trunc i64 3 to i32
  %t427 = icmp eq i32 %t424, %t426
  store i1 %t427, ptr %l15, !tbaa !21
  %t429 = load i1, ptr %l15, !tbaa !21
  br i1 %t429, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s22
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load i32, ptr %l14, !tbaa !23
  %t433 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t434 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t436 = sext i32 %t432 to i64
  %t437 = call i64 @__olang_fmt_i64(ptr null, i64 %t436)
  %t438 = add i64 %t434, %t437
  %t439 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t438)
  call void @olang_textcopy(ptr %t439, ptr %t433, i64 %t434)
  %t440 = getelementptr i8, ptr %t439, i64 %t434
  %t441 = call i64 @__olang_fmt_i64(ptr %t440, i64 %t436)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t439, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s22, ptr %v2, ptr %t431, { i64, ptr } %t443)
  br label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_scope_close(ptr %s22)
  br label %bb97
bb97:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/emit:fnEm", ptr %t447, i32 0, i32 0
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/emit:Emitter", ptr %t450, i32 0, i32 4
  %t453 = load i1, ptr %t452, !tbaa !21
  br i1 %t453, label %bb98, label %bb99
bb98:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i32, ptr %l14, !tbaa !23
  %t457 = load i1, ptr %l15, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %v2, ptr %t455, i32 %t456, i1 %t457)
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s19)
  br label %bb102
bb102:
  br label %bb338
bb103:
  %t461 = load ptr, ptr %l1, !tbaa !29
  store ptr %t461, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t462 = load ptr, ptr %l251, !tbaa !29
  %t463 = icmp ne ptr %t462, null
  br i1 %t463, label %bb104, label %bb105
bb104:
  %t465 = load ptr, ptr %l251, !tbaa !29
  %t466 = load i64, ptr %t465, !range !{i64 0, i64 20}
  %t468 = icmp eq i64 %t466, 4
  store i1 %t468, ptr %l252, !tbaa !21
  br label %bb105
bb105:
  %t469 = load i1, ptr %l252, !tbaa !21
  br i1 %t469, label %bb106, label %bb107
bb106:
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = getelementptr { i64, [21 x i64] }, ptr %t470, i32 0, i32 1
  %t473 = getelementptr { %"compiler/source:Span", i32 }, ptr %t472, i32 0, i32 1
  %t474 = load i32, ptr %t473
  store i32 %t474, ptr %l16, !tbaa !23
  br label %bb108
bb107:
  br label %bb140
bb108:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/emit:fnEm", ptr %t476, i32 0, i32 25
  %t479 = load i32, ptr %l16, !tbaa !23
  %t481 = sext i32 %t479 to i64
  %t484 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t478, i64 %t481)
  store i1 %t484, ptr %l261
  br label %bb109
bb109:
  %t485 = load i1, ptr %l261, !tbaa !21
  br i1 %t485, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l262, !tbaa !21
  br label %bb113
bb111:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/emit:fnEm", ptr %t486, i32 0, i32 26
  %t489 = load i32, ptr %l16, !tbaa !23
  %t491 = sext i32 %t489 to i64
  %t494 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t488, i64 %t491)
  store i1 %t494, ptr %l267
  br label %bb112
bb112:
  %t495 = load i1, ptr %l267, !tbaa !21
  store i1 %t495, ptr %l262, !tbaa !21
  br label %bb113
bb113:
  %t496 = load i1, ptr %l262, !tbaa !21
  br i1 %t496, label %bb114, label %bb115
bb114:
  br label %ret
bb115:
  br label %bb116
bb116:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/emit:fnEm", ptr %t497, i32 0, i32 1
  %t500 = load ptr, ptr %t499, !tbaa !29
  %t502 = getelementptr %"compiler/mir:Fn", ptr %t500, i32 0, i32 8
  store ptr %t502, ptr %l270, !tbaa !29
  %t503 = load i32, ptr %l16, !tbaa !23
  %t505 = sext i32 %t503 to i64
  %t506 = load ptr, ptr %l270, !tbaa !29
  %t507 = call ptr @__olang_scope_or(ptr %v3, ptr %t506)
  %t508 = call ptr @__olang_scope_hold(ptr %t507)
  %t509 = ptrtoint ptr %t508 to i64
  %t511 = inttoptr i64 %t509 to ptr
  %t512 = load ptr, ptr %l270, !tbaa !29
  %t514 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t511, ptr %t512, i64 %t505)
  store %"compiler/mir:ScopeInfo" %t514, ptr %l274
  br label %bb117
bb117:
  %t515 = getelementptr %"compiler/mir:ScopeInfo", ptr %l274, i32 0, i32 0
  %t516 = load i32, ptr %t515, !range !{i32 0, i32 7}
  %t518 = trunc i64 6 to i32
  %t519 = icmp eq i32 %t516, %t518
  br i1 %t519, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s27
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/emit:fnEm", ptr %t521, i32 0, i32 0
  %t524 = load ptr, ptr %t523, !tbaa !29
  store ptr %t524, ptr %l278, !tbaa !29
  %t525 = load ptr, ptr %l278, !tbaa !29
  %t526 = call ptr @__olang_scope_or(ptr %v2, ptr %t525)
  %t527 = call ptr @__olang_scope_hold(ptr %t526)
  %t528 = ptrtoint ptr %t527 to i64
  %t530 = inttoptr i64 %t528 to ptr
  %t531 = load ptr, ptr %l278, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t530, ptr %s27, ptr %t531, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d273, i32 0, i32 1) })
  br label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s33
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l315, !tbaa !29
  %t533 = load i32, ptr %l16, !tbaa !23
  %t535 = sext i32 %t533 to i64
  store i64 %t535, ptr %l317, !tbaa !24
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/emit:fnEm", ptr %t537, i32 0, i32 37
  %t540 = load i64, ptr %t539, !tbaa !24
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr %"compiler/emit:fnEm", ptr %t541, i32 0, i32 38
  %t544 = load i64, ptr %t543, !tbaa !24
  %t548 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %t536, i64 %t540, i64 %t544)
  store i64 %t548, ptr %l323
  br label %bb131
bb120:
  %t549 = load ptr, ptr %l0, !tbaa !29
  store ptr %t549, ptr %l280, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load i32, ptr %l16, !tbaa !23
  %t552 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t555 = sext i32 %t551 to i64
  %t556 = call i64 @__olang_fmt_i64(ptr null, i64 %t555)
  %t557 = add i64 %t553, %t556
  %t558 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t560 = add i64 %t557, %t559
  %t561 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t560)
  call void @olang_textcopy(ptr %t561, ptr %t552, i64 %t553)
  %t562 = getelementptr i8, ptr %t561, i64 %t553
  %t563 = call i64 @__olang_fmt_i64(ptr %t562, i64 %t555)
  %t564 = getelementptr i8, ptr %t562, i64 %t556
  call void @olang_textcopy(ptr %t564, ptr %t558, i64 %t559)
  %t565 = insertvalue { i64, ptr } undef, i64 %t560, 0
  %t566 = insertvalue { i64, ptr } %t565, ptr %t561, 1
  %t570 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s27, ptr %s27, ptr %v2, ptr %t550, { i64, ptr } %t566)
  store { i64, ptr } %t570, ptr %l285
  br label %bb121
bb121:
  %t571 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t572 = load ptr, ptr %l280, !tbaa !29
  %t574 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s27, ptr %s27, ptr %s27, ptr %s27, ptr %v2, ptr %t572, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d276, i32 0, i32 1) }, { i64, ptr } %t571, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t574, ptr %l287
  br label %bb122
bb122:
  %t575 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t579 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t581 = extractvalue { i64, ptr } %t575, 1
  %t582 = extractvalue { i64, ptr } %t575, 0
  %t583 = add i64 %t579, %t582
  %t584 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t585 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t586 = add i64 %t583, %t585
  %t587 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t586)
  call void @olang_textcopy(ptr %t587, ptr %t578, i64 %t579)
  %t588 = getelementptr i8, ptr %t587, i64 %t579
  call void @olang_textcopy(ptr %t588, ptr %t581, i64 %t582)
  %t589 = getelementptr i8, ptr %t588, i64 %t582
  call void @olang_textcopy(ptr %t589, ptr %t584, i64 %t585)
  %t590 = insertvalue { i64, ptr } undef, i64 %t586, 0
  %t591 = insertvalue { i64, ptr } %t590, ptr %t587, 1
  %t595 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s27, ptr %s27, ptr %v2, ptr %t576, { i64, ptr } %t591)
  store { i64, ptr } %t595, ptr %l292
  br label %bb123
bb123:
  %t596 = load { i64, ptr }, ptr %l292, !tbaa !27
  store { i64, ptr } %t596, ptr %l18, !tbaa !27
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s27, ptr %s27, ptr %t597, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d279, i32 0, i32 1) })
  store { i64, ptr } %t599, ptr %l294
  br label %bb124
bb124:
  %t600 = load { i64, ptr }, ptr %l294, !tbaa !27
  store { i64, ptr } %t600, ptr %l19, !tbaa !27
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s27, ptr %s27, ptr %t601, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d280, i32 0, i32 1) })
  store { i64, ptr } %t603, ptr %l296
  br label %bb125
bb125:
  %t604 = load { i64, ptr }, ptr %l296, !tbaa !27
  store { i64, ptr } %t604, ptr %l20, !tbaa !27
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t607 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t608 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t609 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t610 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t612 = extractvalue { i64, ptr } %t606, 1
  %t613 = extractvalue { i64, ptr } %t606, 0
  %t614 = add i64 %t610, %t613
  %t615 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t616 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t617 = add i64 %t614, %t616
  %t619 = extractvalue { i64, ptr } %t607, 1
  %t620 = extractvalue { i64, ptr } %t607, 0
  %t621 = add i64 %t617, %t620
  %t622 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t623 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t624 = add i64 %t621, %t623
  %t626 = extractvalue { i64, ptr } %t608, 1
  %t627 = extractvalue { i64, ptr } %t608, 0
  %t628 = add i64 %t624, %t627
  %t629 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t628)
  call void @olang_textcopy(ptr %t629, ptr %t609, i64 %t610)
  %t630 = getelementptr i8, ptr %t629, i64 %t610
  call void @olang_textcopy(ptr %t630, ptr %t612, i64 %t613)
  %t631 = getelementptr i8, ptr %t630, i64 %t613
  call void @olang_textcopy(ptr %t631, ptr %t615, i64 %t616)
  %t632 = getelementptr i8, ptr %t631, i64 %t616
  call void @olang_textcopy(ptr %t632, ptr %t619, i64 %t620)
  %t633 = getelementptr i8, ptr %t632, i64 %t620
  call void @olang_textcopy(ptr %t633, ptr %t622, i64 %t623)
  %t634 = getelementptr i8, ptr %t633, i64 %t623
  call void @olang_textcopy(ptr %t634, ptr %t626, i64 %t627)
  %t635 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t629, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s27, ptr %v2, ptr %t605, { i64, ptr } %t636)
  br label %bb126
bb126:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t641 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s27, ptr %t640, { i64, ptr } %t641)
  br label %bb127
bb127:
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t645 = load i32, ptr %l16, !tbaa !23
  %t646 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t647 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t649 = sext i32 %t645 to i64
  %t650 = call i64 @__olang_fmt_i64(ptr null, i64 %t649)
  %t651 = add i64 %t647, %t650
  %t652 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t653 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  %t654 = add i64 %t651, %t653
  %t655 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t654)
  call void @olang_textcopy(ptr %t655, ptr %t646, i64 %t647)
  %t656 = getelementptr i8, ptr %t655, i64 %t647
  %t657 = call i64 @__olang_fmt_i64(ptr %t656, i64 %t649)
  %t658 = getelementptr i8, ptr %t656, i64 %t650
  call void @olang_textcopy(ptr %t658, ptr %t652, i64 %t653)
  %t659 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t660 = insertvalue { i64, ptr } %t659, ptr %t655, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s27, ptr %v2, ptr %t644, { i64, ptr } %t660)
  br label %bb128
bb128:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t666 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t667 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t669 = extractvalue { i64, ptr } %t665, 1
  %t670 = extractvalue { i64, ptr } %t665, 0
  %t671 = add i64 %t667, %t670
  %t672 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t671)
  call void @olang_textcopy(ptr %t672, ptr %t666, i64 %t667)
  %t673 = getelementptr i8, ptr %t672, i64 %t667
  call void @olang_textcopy(ptr %t673, ptr %t669, i64 %t670)
  %t674 = insertvalue { i64, ptr } undef, i64 %t671, 0
  %t675 = insertvalue { i64, ptr } %t674, ptr %t672, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s27, ptr %v2, ptr %t664, { i64, ptr } %t675)
  br label %bb129
bb129:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s27, ptr %t679, { i64, ptr } %t680)
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s27)
  br label %bb139
bb131:
  %t683 = load ptr, ptr %l315, !tbaa !29
  %t684 = load i64, ptr %l317, !tbaa !24
  %t685 = load i64, ptr %l323, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkEnd(ptr %v0, ptr %v2, ptr %t683, i64 %t684, i64 %t685)
  br label %bb132
bb132:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/emit:fnEm", ptr %t686, i32 0, i32 0
  %t689 = load ptr, ptr %t688, !tbaa !29
  store ptr %t689, ptr %l325, !tbaa !29
  %t690 = load ptr, ptr %l325, !tbaa !29
  %t691 = call ptr @__olang_scope_or(ptr %v2, ptr %t690)
  %t692 = call ptr @__olang_scope_hold(ptr %t691)
  %t693 = ptrtoint ptr %t692 to i64
  %t695 = inttoptr i64 %t693 to ptr
  %t696 = load ptr, ptr %l325, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t695, ptr %s33, ptr %t696, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d286, i32 0, i32 1) })
  br label %bb133
bb133:
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t698 = load i32, ptr %l16, !tbaa !23
  %t699 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t700 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t702 = sext i32 %t698 to i64
  %t703 = call i64 @__olang_fmt_i64(ptr null, i64 %t702)
  %t704 = add i64 %t700, %t703
  %t705 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t706 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t707 = add i64 %t704, %t706
  %t708 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t707)
  call void @olang_textcopy(ptr %t708, ptr %t699, i64 %t700)
  %t709 = getelementptr i8, ptr %t708, i64 %t700
  %t710 = call i64 @__olang_fmt_i64(ptr %t709, i64 %t702)
  %t711 = getelementptr i8, ptr %t709, i64 %t703
  call void @olang_textcopy(ptr %t711, ptr %t705, i64 %t706)
  %t712 = insertvalue { i64, ptr } undef, i64 %t707, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t708, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s33, ptr %v2, ptr %t697, { i64, ptr } %t713)
  br label %bb134
bb134:
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/emit:fnEm", ptr %t717, i32 0, i32 0
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t722 = getelementptr %"compiler/emit:Emitter", ptr %t720, i32 0, i32 4
  %t723 = load i1, ptr %t722, !tbaa !21
  br i1 %t723, label %bb135, label %bb136
bb135:
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t726 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %v2, ptr %t725, i32 %t726)
  br label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s33)
  br label %bb139
bb139:
  br label %bb338
bb140:
  %t729 = load ptr, ptr %l1, !tbaa !29
  store ptr %t729, ptr %l336, !tbaa !29
  store i1 false, ptr %l337, !tbaa !21
  %t730 = load ptr, ptr %l336, !tbaa !29
  %t731 = icmp ne ptr %t730, null
  br i1 %t731, label %bb141, label %bb142
bb141:
  %t733 = load ptr, ptr %l336, !tbaa !29
  %t734 = load i64, ptr %t733, !range !{i64 0, i64 20}
  %t736 = icmp eq i64 %t734, 14
  store i1 %t736, ptr %l337, !tbaa !21
  br label %bb142
bb142:
  %t737 = load i1, ptr %l337, !tbaa !21
  br i1 %t737, label %bb143, label %bb144
bb143:
  %t738 = load ptr, ptr %l1, !tbaa !29
  %t740 = getelementptr { i64, [21 x i64] }, ptr %t738, i32 0, i32 1
  %t741 = getelementptr { %"compiler/source:Span" }, ptr %t740, i32 0, i32 0
  %t742 = load %"compiler/source:Span", ptr %t741
  store %"compiler/source:Span" %t742, ptr %l21
  br label %bb145
bb144:
  br label %bb147
bb145:
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t745 = load %"compiler/source:Span", ptr %l21
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %v2, ptr %v3, ptr %t744, %"compiler/source:Span" %t745)
  br label %bb146
bb146:
  br label %bb338
bb147:
  %t748 = load ptr, ptr %l1, !tbaa !29
  store ptr %t748, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t749 = load ptr, ptr %l344, !tbaa !29
  %t750 = icmp ne ptr %t749, null
  br i1 %t750, label %bb148, label %bb149
bb148:
  %t752 = load ptr, ptr %l344, !tbaa !29
  %t753 = load i64, ptr %t752, !range !{i64 0, i64 20}
  %t755 = icmp eq i64 %t753, 15
  store i1 %t755, ptr %l345, !tbaa !21
  br label %bb149
bb149:
  %t756 = load i1, ptr %l345, !tbaa !21
  br i1 %t756, label %bb150, label %bb151
bb150:
  %t757 = load ptr, ptr %l1, !tbaa !29
  %t759 = getelementptr { i64, [21 x i64] }, ptr %t757, i32 0, i32 1
  %t760 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t759, i32 0, i32 1
  %t761 = load { i64, [4 x i64] }, ptr %t760
  store { i64, [4 x i64] } %t761, ptr %l22
  br label %bb152
bb151:
  br label %bb156
bb152:
  store %olang.scope zeroinitializer, ptr %s37
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = getelementptr %"compiler/emit:fnEm", ptr %t763, i32 0, i32 0
  %t766 = load ptr, ptr %t765, !tbaa !29
  store ptr %t766, ptr %l351, !tbaa !29
  %t767 = load ptr, ptr %l351, !tbaa !29
  %t768 = call ptr @__olang_scope_or(ptr %v2, ptr %t767)
  %t769 = call ptr @__olang_scope_hold(ptr %t768)
  %t770 = ptrtoint ptr %t769 to i64
  %t772 = inttoptr i64 %t770 to ptr
  %t773 = load ptr, ptr %l351, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t772, ptr %s37, ptr %t773, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d289, i32 0, i32 1) })
  br label %bb153
bb153:
  %t774 = load ptr, ptr %l0, !tbaa !29
  store ptr %t774, ptr %l353, !tbaa !29
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load { i64, [4 x i64] }, ptr %l22
  %t777 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t781 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s37, ptr %v3, ptr %v2, ptr %t775, { i64, [4 x i64] } %t776, i32 %t777)
  store { i64, ptr } %t781, ptr %l357
  br label %bb154
bb154:
  %t782 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t783 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t784 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t785 = extractvalue { i64, ptr } %t784, 1
  %t786 = extractvalue { i64, ptr } %t784, 0
  %t787 = add i64 %t783, %t786
  %t788 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t790 = add i64 %t787, %t789
  %t791 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t790)
  call void @olang_textcopy(ptr %t791, ptr %t782, i64 %t783)
  %t792 = getelementptr i8, ptr %t791, i64 %t783
  call void @olang_textcopy(ptr %t792, ptr %t785, i64 %t786)
  %t793 = getelementptr i8, ptr %t792, i64 %t786
  call void @olang_textcopy(ptr %t793, ptr %t788, i64 %t789)
  %t794 = insertvalue { i64, ptr } undef, i64 %t790, 0
  %t795 = insertvalue { i64, ptr } %t794, ptr %t791, 1
  %t797 = load ptr, ptr %l353, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s37, ptr %v2, ptr %t797, { i64, ptr } %t795)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s37)
  br label %bb338
bb156:
  %t799 = load ptr, ptr %l1, !tbaa !29
  store ptr %t799, ptr %l360, !tbaa !29
  store i1 false, ptr %l361, !tbaa !21
  %t800 = load ptr, ptr %l360, !tbaa !29
  %t801 = icmp ne ptr %t800, null
  br i1 %t801, label %bb157, label %bb158
bb157:
  %t803 = load ptr, ptr %l360, !tbaa !29
  %t804 = load i64, ptr %t803, !range !{i64 0, i64 20}
  %t806 = icmp eq i64 %t804, 16
  store i1 %t806, ptr %l361, !tbaa !21
  br label %bb158
bb158:
  %t807 = load i1, ptr %l361, !tbaa !21
  br i1 %t807, label %bb159, label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb164
bb161:
  store %olang.scope zeroinitializer, ptr %s39
  %t808 = load ptr, ptr %l0, !tbaa !29
  %t810 = getelementptr %"compiler/emit:fnEm", ptr %t808, i32 0, i32 0
  %t811 = load ptr, ptr %t810, !tbaa !29
  store ptr %t811, ptr %l365, !tbaa !29
  %t812 = load ptr, ptr %l365, !tbaa !29
  %t813 = call ptr @__olang_scope_or(ptr %v2, ptr %t812)
  %t814 = call ptr @__olang_scope_hold(ptr %t813)
  %t815 = ptrtoint ptr %t814 to i64
  %t817 = inttoptr i64 %t815 to ptr
  %t818 = load ptr, ptr %l365, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t817, ptr %s39, ptr %t818, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d292, i32 0, i32 1) })
  br label %bb162
bb162:
  %t819 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s39, ptr %v2, ptr %t819, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d293, i32 0, i32 1) })
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s39)
  br label %bb338
bb164:
  %t821 = load ptr, ptr %l1, !tbaa !29
  store ptr %t821, ptr %l368, !tbaa !29
  store i1 false, ptr %l369, !tbaa !21
  %t822 = load ptr, ptr %l368, !tbaa !29
  %t823 = icmp ne ptr %t822, null
  br i1 %t823, label %bb165, label %bb166
bb165:
  %t825 = load ptr, ptr %l368, !tbaa !29
  %t826 = load i64, ptr %t825, !range !{i64 0, i64 20}
  %t828 = icmp eq i64 %t826, 19
  store i1 %t828, ptr %l369, !tbaa !21
  br label %bb166
bb166:
  %t829 = load i1, ptr %l369, !tbaa !21
  br i1 %t829, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb171
bb169:
  store %olang.scope zeroinitializer, ptr %s40
  %t830 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s40, ptr %v2, ptr %t830, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d294, i32 0, i32 1) })
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s40)
  br label %bb338
bb171:
  %t832 = load ptr, ptr %l1, !tbaa !29
  store ptr %t832, ptr %l373, !tbaa !29
  store i1 false, ptr %l374, !tbaa !21
  %t833 = load ptr, ptr %l373, !tbaa !29
  %t834 = icmp ne ptr %t833, null
  br i1 %t834, label %bb172, label %bb173
bb172:
  %t836 = load ptr, ptr %l373, !tbaa !29
  %t837 = load i64, ptr %t836, !range !{i64 0, i64 20}
  %t839 = icmp eq i64 %t837, 17
  store i1 %t839, ptr %l374, !tbaa !21
  br label %bb173
bb173:
  %t840 = load i1, ptr %l374, !tbaa !21
  br i1 %t840, label %bb174, label %bb175
bb174:
  %t841 = load ptr, ptr %l1, !tbaa !29
  %t843 = getelementptr { i64, [21 x i64] }, ptr %t841, i32 0, i32 1
  %t844 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t843, i32 0, i32 1
  %t845 = load { i64, [4 x i64] }, ptr %t844
  store { i64, [4 x i64] } %t845, ptr %l23
  %t847 = load ptr, ptr %l1, !tbaa !29
  %t849 = getelementptr { i64, [21 x i64] }, ptr %t847, i32 0, i32 1
  %t850 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t849, i32 0, i32 2
  %t851 = load { i64, [4 x i64] }, ptr %t850
  store { i64, [4 x i64] } %t851, ptr %l24
  br label %bb176
bb175:
  br label %bb179
bb176:
  store %olang.scope zeroinitializer, ptr %s41
  %t853 = load ptr, ptr %l0, !tbaa !29
  store ptr %t853, ptr %l381, !tbaa !29
  %t854 = load { i64, [4 x i64] }, ptr %l23
  store { i64, [4 x i64] } %t854, ptr %l382
  %t855 = load ptr, ptr %l0, !tbaa !29
  %t856 = load { i64, [4 x i64] }, ptr %l24
  %t857 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t861 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s41, ptr %v3, ptr %v2, ptr %t855, { i64, [4 x i64] } %t856, i32 %t857)
  store { i64, ptr } %t861, ptr %l386
  br label %bb177
bb177:
  %t862 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t863 = load ptr, ptr %l381, !tbaa !29
  %t864 = load { i64, [4 x i64] }, ptr %l382
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholders(ptr %v0, ptr %s41, ptr %v3, ptr %v2, ptr %t863, { i64, [4 x i64] } %t864, { i64, ptr } %t862)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s41)
  br label %bb338
bb179:
  %t866 = load ptr, ptr %l1, !tbaa !29
  store ptr %t866, ptr %l388, !tbaa !29
  store i1 false, ptr %l389, !tbaa !21
  %t867 = load ptr, ptr %l388, !tbaa !29
  %t868 = icmp ne ptr %t867, null
  br i1 %t868, label %bb180, label %bb181
bb180:
  %t870 = load ptr, ptr %l388, !tbaa !29
  %t871 = load i64, ptr %t870, !range !{i64 0, i64 20}
  %t873 = icmp eq i64 %t871, 18
  store i1 %t873, ptr %l389, !tbaa !21
  br label %bb181
bb181:
  %t874 = load i1, ptr %l389, !tbaa !21
  br i1 %t874, label %bb182, label %bb183
bb182:
  %t875 = load ptr, ptr %l1, !tbaa !29
  %t877 = getelementptr { i64, [21 x i64] }, ptr %t875, i32 0, i32 1
  %t878 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t877, i32 0, i32 1
  %t879 = load { i64, [4 x i64] }, ptr %t878
  store { i64, [4 x i64] } %t879, ptr %l25
  %t881 = load ptr, ptr %l1, !tbaa !29
  %t883 = getelementptr { i64, [21 x i64] }, ptr %t881, i32 0, i32 1
  %t884 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t883, i32 0, i32 2
  %t885 = load i32, ptr %t884
  store i32 %t885, ptr %l26, !tbaa !23
  %t887 = load ptr, ptr %l1, !tbaa !29
  %t889 = getelementptr { i64, [21 x i64] }, ptr %t887, i32 0, i32 1
  %t890 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t889, i32 0, i32 3
  %t891 = load %"compiler/mir:Range", ptr %t890
  store %"compiler/mir:Range" %t891, ptr %l27
  br label %bb184
bb183:
  br label %bb186
bb184:
  %t893 = load ptr, ptr %l0, !tbaa !29
  %t894 = load { i64, [4 x i64] }, ptr %l25
  %t895 = load i32, ptr %l26, !tbaa !23
  %t896 = load %"compiler/mir:Range", ptr %l27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ereclaim(ptr %v0, ptr %v2, ptr %v3, ptr %t893, { i64, [4 x i64] } %t894, i32 %t895, %"compiler/mir:Range" %t896)
  br label %bb185
bb185:
  br label %bb338
bb186:
  %t901 = load ptr, ptr %l1, !tbaa !29
  store ptr %t901, ptr %l402, !tbaa !29
  store i1 false, ptr %l403, !tbaa !21
  %t902 = load ptr, ptr %l402, !tbaa !29
  %t903 = icmp ne ptr %t902, null
  br i1 %t903, label %bb187, label %bb188
bb187:
  %t905 = load ptr, ptr %l402, !tbaa !29
  %t906 = load i64, ptr %t905, !range !{i64 0, i64 20}
  %t908 = icmp eq i64 %t906, 5
  store i1 %t908, ptr %l403, !tbaa !21
  br label %bb188
bb188:
  %t909 = load i1, ptr %l403, !tbaa !21
  br i1 %t909, label %bb189, label %bb190
bb189:
  %t910 = load ptr, ptr %l1, !tbaa !29
  %t912 = getelementptr { i64, [21 x i64] }, ptr %t910, i32 0, i32 1
  %t913 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t912, i32 0, i32 1
  %t914 = load { i64, [1 x i64] }, ptr %t913
  store { i64, [1 x i64] } %t914, ptr %l28
  %t916 = load ptr, ptr %l1, !tbaa !29
  %t918 = getelementptr { i64, [21 x i64] }, ptr %t916, i32 0, i32 1
  %t919 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t918, i32 0, i32 2
  %t920 = load i32, ptr %t919
  store i32 %t920, ptr %l29, !tbaa !23
  %t922 = load ptr, ptr %l1, !tbaa !29
  %t924 = getelementptr { i64, [21 x i64] }, ptr %t922, i32 0, i32 1
  %t925 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t924, i32 0, i32 3
  %t926 = load { i64, [4 x i64] }, ptr %t925
  store { i64, [4 x i64] } %t926, ptr %l30
  br label %bb191
bb190:
  br label %bb214
bb191:
  store %olang.scope zeroinitializer, ptr %s43
  %t928 = load ptr, ptr %l2, !tbaa !29
  store ptr %t928, ptr %l413, !tbaa !29
  %t929 = load i32, ptr %l29, !tbaa !23
  store i32 %t929, ptr %l414, !tbaa !23
  %t930 = load ptr, ptr %l0, !tbaa !29
  %t932 = getelementptr %"compiler/emit:fnEm", ptr %t930, i32 0, i32 0
  %t933 = load ptr, ptr %t932, !tbaa !29
  %t935 = getelementptr %"compiler/emit:Emitter", ptr %t933, i32 0, i32 46
  store ptr %t935, ptr %l418, !tbaa !29
  %t936 = load i32, ptr %l29, !tbaa !23
  %t937 = load ptr, ptr %l418, !tbaa !29
  %t938 = call ptr @__olang_scope_or(ptr %v2, ptr %t937)
  %t939 = call ptr @__olang_scope_hold(ptr %t938)
  %t940 = ptrtoint ptr %t939 to i64
  %t942 = inttoptr i64 %t940 to ptr
  %t943 = load ptr, ptr %l418, !tbaa !29
  %t945 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %t942, ptr %t943, i32 %t936)
  %t946 = extractvalue { i32, i64 } %t945, 1
  %t947 = extractvalue { i32, i64 } %t945, 0
  store i32 %t947, ptr %l422
  %t948 = icmp ne i32 %t947, 0
  br i1 %t948, label %bb193, label %ok.949, !prof !99
ok.949:
  store i64 %t946, ptr %l421
  br label %bb192
bb192:
  %t950 = load i64, ptr %l421, !tbaa !24
  store i64 %t950, ptr %l415, !tbaa !24
  br label %bb195
bb193:
  br label %bb194
bb194:
  store i64 -1, ptr %l415, !tbaa !24
  br label %bb195
bb195:
  %t951 = load ptr, ptr %l413, !tbaa !29
  %t952 = call ptr @__olang_scope_or(ptr %v2, ptr %t951)
  %t953 = call ptr @__olang_scope_hold(ptr %t952)
  %t954 = ptrtoint ptr %t953 to i64
  %t956 = inttoptr i64 %t954 to ptr
  %t957 = load ptr, ptr %l413, !tbaa !29
  %t958 = load i32, ptr %l414, !tbaa !23
  %t959 = load i64, ptr %l415, !tbaa !24
  %t960 = call { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %t956, ptr %t957, i32 %t958, i64 %t959)
  %t961 = extractvalue { i32, { i64, [2 x i64] } } %t960, 1
  %t962 = extractvalue { i32, { i64, [2 x i64] } } %t960, 0
  store i32 %t962, ptr %l425
  %t963 = icmp ne i32 %t962, 0
  br i1 %t963, label %bb197, label %ok.964, !prof !99
ok.964:
  store { i64, [2 x i64] } %t961, ptr %l424
  br label %bb196
bb196:
  %t965 = load { i64, [2 x i64] }, ptr %l424
  store { i64, [2 x i64] } %t965, ptr %l412
  br label %bb201
bb197:
  br label %bb198
bb198:
  store %olang.scope zeroinitializer, ptr %s44
  %t966 = load ptr, ptr %l0, !tbaa !29
  store ptr %t966, ptr %l426, !tbaa !29
  %t967 = load ptr, ptr %l2, !tbaa !29
  store ptr %t967, ptr %l427, !tbaa !29
  %t968 = load i32, ptr %l29, !tbaa !23
  %t969 = load ptr, ptr %l427, !tbaa !29
  %t970 = call ptr @__olang_scope_or(ptr %v2, ptr %t969)
  %t971 = call ptr @__olang_scope_hold(ptr %t970)
  %t972 = ptrtoint ptr %t971 to i64
  %t974 = inttoptr i64 %t972 to ptr
  %t976 = inttoptr i64 0 to ptr
  %t977 = load ptr, ptr %l427, !tbaa !29
  %t979 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t974, ptr %s44, ptr %t976, ptr %t977, i32 %t968)
  store { i64, ptr } %t979, ptr %l431
  br label %bb199
bb199:
  %t980 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t981 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t982 = load { i64, ptr }, ptr %l431, !tbaa !27
  %t983 = extractvalue { i64, ptr } %t982, 1
  %t984 = extractvalue { i64, ptr } %t982, 0
  %t985 = add i64 %t981, %t984
  %t986 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t985)
  call void @olang_textcopy(ptr %t986, ptr %t980, i64 %t981)
  %t987 = getelementptr i8, ptr %t986, i64 %t981
  call void @olang_textcopy(ptr %t987, ptr %t983, i64 %t984)
  %t988 = insertvalue { i64, ptr } undef, i64 %t985, 0
  %t989 = insertvalue { i64, ptr } %t988, ptr %t986, 1
  %t991 = load ptr, ptr %l426, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s44, ptr %v2, ptr %t991, { i64, ptr } %t989)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s43)
  br label %ret
bb201:
  %t993 = load { i64, [2 x i64] }, ptr %l412
  store { i64, [2 x i64] } %t993, ptr %l31
  %t994 = load ptr, ptr %l0, !tbaa !29
  %t996 = getelementptr %"compiler/emit:fnEm", ptr %t994, i32 0, i32 0
  %t997 = load ptr, ptr %t996, !tbaa !29
  store ptr %t997, ptr %l435, !tbaa !29
  %t998 = load { i64, [2 x i64] }, ptr %l31
  %t999 = load ptr, ptr %l435, !tbaa !29
  %t1000 = call ptr @__olang_scope_or(ptr %v2, ptr %t999)
  %t1001 = call ptr @__olang_scope_hold(ptr %t1000)
  %t1002 = ptrtoint ptr %t1001 to i64
  %t1004 = inttoptr i64 %t1002 to ptr
  %t1005 = load ptr, ptr %l435, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %t1004, ptr %t1005, { i64, [2 x i64] } %t998)
  br label %bb202
bb202:
  %t1007 = load ptr, ptr %l0, !tbaa !29
  %t1009 = getelementptr %"compiler/emit:fnEm", ptr %t1007, i32 0, i32 0
  %t1010 = load ptr, ptr %t1009, !tbaa !29
  %t1012 = getelementptr %"compiler/emit:Emitter", ptr %t1010, i32 0, i32 44
  store ptr %t1012, ptr %l440, !tbaa !29
  %t1013 = load { i64, [2 x i64] }, ptr %l31
  %t1014 = load ptr, ptr %l440, !tbaa !29
  %t1015 = call ptr @__olang_scope_or(ptr %v2, ptr %t1014)
  %t1016 = call ptr @__olang_scope_hold(ptr %t1015)
  %t1017 = ptrtoint ptr %t1016 to i64
  %t1019 = inttoptr i64 %t1017 to ptr
  %t1020 = load ptr, ptr %l440, !tbaa !29
  %t1022 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %t1019, ptr %t1020, { i64, [2 x i64] } %t1013)
  store i1 %t1022, ptr %l443
  br label %bb203
bb203:
  %t1023 = load i1, ptr %l443, !tbaa !21
  %t1024 = xor i1 %t1023, true
  br i1 %t1024, label %bb204, label %bb205
bb204:
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1028 = getelementptr %"compiler/emit:fnEm", ptr %t1026, i32 0, i32 0
  %t1029 = load ptr, ptr %t1028, !tbaa !29
  %t1031 = getelementptr %"compiler/emit:Emitter", ptr %t1029, i32 0, i32 44
  store ptr %t1031, ptr %l447, !tbaa !29
  %t1032 = load { i64, [2 x i64] }, ptr %l31
  %t1033 = load ptr, ptr %l447, !tbaa !29
  %t1034 = call ptr @__olang_scope_or(ptr %v2, ptr %t1033)
  %t1035 = call ptr @__olang_scope_hold(ptr %t1034)
  %t1036 = ptrtoint ptr %t1035 to i64
  %t1038 = inttoptr i64 %t1036 to ptr
  %t1039 = load ptr, ptr %l447, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %t1038, ptr %t1039, { i64, [2 x i64] } %t1032, i1 true)
  br label %bb206
bb205:
  br label %bb208
bb206:
  %t1041 = load ptr, ptr %l0, !tbaa !29
  %t1043 = getelementptr %"compiler/emit:fnEm", ptr %t1041, i32 0, i32 0
  %t1044 = load ptr, ptr %t1043, !tbaa !29
  %t1046 = getelementptr %"compiler/emit:Emitter", ptr %t1044, i32 0, i32 43
  store ptr %t1046, ptr %l452, !tbaa !29
  %t1047 = load { i64, [2 x i64] }, ptr %l31
  %t1048 = load ptr, ptr %l452, !tbaa !29
  %t1049 = call ptr @__olang_scope_or(ptr %v2, ptr %t1048)
  %t1050 = call ptr @__olang_scope_hold(ptr %t1049)
  %t1051 = ptrtoint ptr %t1050 to i64
  %t1053 = inttoptr i64 %t1051 to ptr
  %t1054 = load ptr, ptr %l452, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %t1053, ptr %t1054, { i64, [2 x i64] } %t1047)
  br label %bb207
bb207:
  br label %bb208
bb208:
  %t1056 = load ptr, ptr %l0, !tbaa !29
  %t1058 = getelementptr %"compiler/emit:fnEm", ptr %t1056, i32 0, i32 0
  %t1059 = load ptr, ptr %t1058, !tbaa !29
  store ptr %t1059, ptr %l456, !tbaa !29
  %t1060 = load ptr, ptr %l456, !tbaa !29
  %t1061 = call ptr @__olang_scope_or(ptr %v2, ptr %t1060)
  %t1062 = call ptr @__olang_scope_hold(ptr %t1061)
  %t1063 = ptrtoint ptr %t1062 to i64
  %t1065 = inttoptr i64 %t1063 to ptr
  %t1066 = load ptr, ptr %l456, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1065, ptr %s43, ptr %t1066, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d296, i32 0, i32 1) })
  br label %bb209
bb209:
  %t1067 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1067, ptr %l458, !tbaa !29
  %t1068 = load ptr, ptr %l0, !tbaa !29
  %t1069 = load { i64, [1 x i64] }, ptr %l28
  %t1072 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s43, ptr %v2, ptr %v3, ptr %t1068, { i64, [1 x i64] } %t1069)
  store { i64, ptr } %t1072, ptr %l461
  br label %bb210
bb210:
  %t1073 = load ptr, ptr %l0, !tbaa !29
  %t1074 = load { i64, [4 x i64] }, ptr %l30
  %t1075 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1079 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s43, ptr %v3, ptr %v2, ptr %t1073, { i64, [4 x i64] } %t1074, i32 %t1075)
  store { i64, ptr } %t1079, ptr %l465
  br label %bb211
bb211:
  %t1080 = load ptr, ptr %l0, !tbaa !29
  %t1082 = getelementptr %"compiler/emit:fnEm", ptr %t1080, i32 0, i32 0
  %t1083 = load ptr, ptr %t1082, !tbaa !29
  store ptr %t1083, ptr %l467, !tbaa !29
  %t1084 = load { i64, [2 x i64] }, ptr %l31
  %t1085 = load ptr, ptr %l467, !tbaa !29
  %t1086 = call ptr @__olang_scope_or(ptr %v2, ptr %t1085)
  %t1087 = call ptr @__olang_scope_hold(ptr %t1086)
  %t1088 = ptrtoint ptr %t1087 to i64
  %t1090 = inttoptr i64 %t1088 to ptr
  %t1091 = load ptr, ptr %l467, !tbaa !29
  %t1093 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t1090, ptr %s43, ptr %t1091, { i64, [2 x i64] } %t1084)
  store { i64, ptr } %t1093, ptr %l470
  br label %bb212
bb212:
  %t1094 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t1095 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t1096 = load { i64, ptr }, ptr %l461, !tbaa !27
  %t1097 = extractvalue { i64, ptr } %t1096, 1
  %t1098 = extractvalue { i64, ptr } %t1096, 0
  %t1099 = add i64 %t1095, %t1098
  %t1100 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t1101 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t1102 = add i64 %t1099, %t1101
  %t1103 = load { i64, ptr }, ptr %l465, !tbaa !27
  %t1104 = extractvalue { i64, ptr } %t1103, 1
  %t1105 = extractvalue { i64, ptr } %t1103, 0
  %t1106 = add i64 %t1102, %t1105
  %t1107 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t1108 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t1109 = add i64 %t1106, %t1108
  %t1110 = load { i64, ptr }, ptr %l470, !tbaa !27
  %t1111 = extractvalue { i64, ptr } %t1110, 1
  %t1112 = extractvalue { i64, ptr } %t1110, 0
  %t1113 = add i64 %t1109, %t1112
  %t1114 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t1115 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t1116 = add i64 %t1113, %t1115
  %t1117 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1116)
  call void @olang_textcopy(ptr %t1117, ptr %t1094, i64 %t1095)
  %t1118 = getelementptr i8, ptr %t1117, i64 %t1095
  call void @olang_textcopy(ptr %t1118, ptr %t1097, i64 %t1098)
  %t1119 = getelementptr i8, ptr %t1118, i64 %t1098
  call void @olang_textcopy(ptr %t1119, ptr %t1100, i64 %t1101)
  %t1120 = getelementptr i8, ptr %t1119, i64 %t1101
  call void @olang_textcopy(ptr %t1120, ptr %t1104, i64 %t1105)
  %t1121 = getelementptr i8, ptr %t1120, i64 %t1105
  call void @olang_textcopy(ptr %t1121, ptr %t1107, i64 %t1108)
  %t1122 = getelementptr i8, ptr %t1121, i64 %t1108
  call void @olang_textcopy(ptr %t1122, ptr %t1111, i64 %t1112)
  %t1123 = getelementptr i8, ptr %t1122, i64 %t1112
  call void @olang_textcopy(ptr %t1123, ptr %t1114, i64 %t1115)
  %t1124 = insertvalue { i64, ptr } undef, i64 %t1116, 0
  %t1125 = insertvalue { i64, ptr } %t1124, ptr %t1117, 1
  %t1127 = load ptr, ptr %l458, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s43, ptr %v2, ptr %t1127, { i64, ptr } %t1125)
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s43)
  br label %bb338
bb214:
  %t1129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1129, ptr %l473, !tbaa !29
  store i1 false, ptr %l474, !tbaa !21
  %t1130 = load ptr, ptr %l473, !tbaa !29
  %t1131 = icmp ne ptr %t1130, null
  br i1 %t1131, label %bb215, label %bb216
bb215:
  %t1133 = load ptr, ptr %l473, !tbaa !29
  %t1134 = load i64, ptr %t1133, !range !{i64 0, i64 20}
  %t1136 = icmp eq i64 %t1134, 6
  store i1 %t1136, ptr %l474, !tbaa !21
  br label %bb216
bb216:
  %t1137 = load i1, ptr %l474, !tbaa !21
  br i1 %t1137, label %bb217, label %bb218
bb217:
  %t1138 = load ptr, ptr %l1, !tbaa !29
  %t1140 = getelementptr { i64, [21 x i64] }, ptr %t1138, i32 0, i32 1
  %t1141 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t1140, i32 0, i32 1
  %t1142 = load %"compiler/mir:Lvalue", ptr %t1141
  store %"compiler/mir:Lvalue" %t1142, ptr %l32
  br label %bb219
bb218:
  br label %bb242
bb219:
  store %olang.scope zeroinitializer, ptr %s48
  %t1144 = load ptr, ptr %l0, !tbaa !29
  %t1145 = load %"compiler/mir:Lvalue", ptr %l32
  %t1148 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s48, ptr %v3, ptr %v2, ptr %t1144, %"compiler/mir:Lvalue" %t1145)
  store { { i64, ptr }, i32 } %t1148, ptr %l481
  br label %bb220
bb220:
  %t1149 = load { { i64, ptr }, i32 }, ptr %l481
  store { { i64, ptr }, i32 } %t1149, ptr %l33
  %t1150 = getelementptr { { i64, ptr }, i32 }, ptr %l33, i32 0, i32 0
  %t1151 = load { i64, ptr }, ptr %t1150, !tbaa !27
  store { i64, ptr } %t1151, ptr %l482, !tbaa !27
  %t1152 = load { i64, ptr }, ptr %l482, !tbaa !27
  %t1153 = extractvalue { i64, ptr } %t1152, 0
  store i64 %t1153, ptr %l483, !tbaa !24
  %t1154 = load i64, ptr %l483, !tbaa !24
  %t1155 = mul i64 %t1154, 1
  %t1156 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1155)
  %t1157 = insertvalue { i64, ptr } undef, i64 %t1154, 0
  %t1158 = insertvalue { i64, ptr } %t1157, ptr %t1156, 1
  store { i64, ptr } %t1158, ptr %l484, !tbaa !27
  %t1159 = getelementptr { i64, ptr }, ptr %l484, i32 0, i32 1
  %t1160 = load ptr, ptr %t1159, !tbaa !27
  %t1161 = getelementptr { i64, ptr }, ptr %l482, i32 0, i32 1
  %t1162 = load ptr, ptr %t1161, !tbaa !27
  %t1163 = load i64, ptr %l483, !tbaa !24
  %t1164 = mul i64 %t1163, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1160, ptr %t1162, i64 %t1164, i1 false)
  %t1165 = load { i64, ptr }, ptr %l484, !tbaa !27
  store { i64, ptr } %t1165, ptr %l34, !tbaa !27
  %t1166 = getelementptr { { i64, ptr }, i32 }, ptr %l33, i32 0, i32 1
  %t1167 = load i32, ptr %t1166, !tbaa !23
  store i32 %t1167, ptr %l35, !tbaa !23
  %t1169 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1169, ptr %l486, !tbaa !29
  %t1170 = load i32, ptr %l35, !tbaa !23
  %t1171 = load ptr, ptr %l486, !tbaa !29
  %t1172 = call ptr @__olang_scope_or(ptr %v2, ptr %t1171)
  %t1173 = call ptr @__olang_scope_hold(ptr %t1172)
  %t1174 = ptrtoint ptr %t1173 to i64
  %t1176 = inttoptr i64 %t1174 to ptr
  %t1177 = load ptr, ptr %l486, !tbaa !29
  %t1179 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t1176, ptr %t1177, i32 %t1170)
  store i1 %t1179, ptr %l489
  br label %bb221
bb221:
  %t1180 = load i1, ptr %l489, !tbaa !21
  %t1181 = xor i1 %t1180, true
  br i1 %t1181, label %bb222, label %bb223
bb222:
  %t1183 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1183, ptr %l492, !tbaa !29
  %t1184 = load i32, ptr %l35, !tbaa !23
  %t1185 = load ptr, ptr %l492, !tbaa !29
  %t1186 = call ptr @__olang_scope_or(ptr %v2, ptr %t1185)
  %t1187 = call ptr @__olang_scope_hold(ptr %t1186)
  %t1188 = ptrtoint ptr %t1187 to i64
  %t1190 = inttoptr i64 %t1188 to ptr
  %t1191 = load ptr, ptr %l492, !tbaa !29
  %t1193 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %t1190, ptr %t1191, i32 %t1184)
  store i1 %t1193, ptr %l495
  br label %bb224
bb223:
  store i1 false, ptr %l491, !tbaa !21
  br label %bb225
bb224:
  %t1194 = load i1, ptr %l495, !tbaa !21
  %t1195 = xor i1 %t1194, true
  store i1 %t1195, ptr %l491, !tbaa !21
  br label %bb225
bb225:
  %t1197 = load i1, ptr %l491, !tbaa !21
  br i1 %t1197, label %bb226, label %bb227
bb226:
  store %olang.scope zeroinitializer, ptr %s49
  %t1198 = load ptr, ptr %l0, !tbaa !29
  %t1200 = getelementptr %"compiler/emit:fnEm", ptr %t1198, i32 0, i32 0
  %t1201 = load ptr, ptr %t1200, !tbaa !29
  store ptr %t1201, ptr %l498, !tbaa !29
  %t1202 = load ptr, ptr %l498, !tbaa !29
  %t1203 = call ptr @__olang_scope_or(ptr %v2, ptr %t1202)
  %t1204 = call ptr @__olang_scope_hold(ptr %t1203)
  %t1205 = ptrtoint ptr %t1204 to i64
  %t1207 = inttoptr i64 %t1205 to ptr
  %t1208 = load ptr, ptr %l498, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1207, ptr %s49, ptr %t1208, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d301, i32 0, i32 1) })
  br label %bb228
bb227:
  br label %bb233
bb228:
  %t1209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1209, ptr %l500, !tbaa !29
  %t1210 = load ptr, ptr %l0, !tbaa !29
  %t1211 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1212 = load i32, ptr %l35, !tbaa !23
  %t1216 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eanchorRegion(ptr %v0, ptr %s48, ptr %s49, ptr %v2, ptr %t1210, { i64, ptr } %t1211, i32 %t1212)
  store { i64, ptr } %t1216, ptr %l504
  br label %bb229
bb229:
  %t1217 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t1218 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t1219 = load { i64, ptr }, ptr %l504, !tbaa !27
  %t1220 = extractvalue { i64, ptr } %t1219, 1
  %t1221 = extractvalue { i64, ptr } %t1219, 0
  %t1222 = add i64 %t1218, %t1221
  %t1223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t1224 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t1225 = add i64 %t1222, %t1224
  %t1226 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1225)
  call void @olang_textcopy(ptr %t1226, ptr %t1217, i64 %t1218)
  %t1227 = getelementptr i8, ptr %t1226, i64 %t1218
  call void @olang_textcopy(ptr %t1227, ptr %t1220, i64 %t1221)
  %t1228 = getelementptr i8, ptr %t1227, i64 %t1221
  call void @olang_textcopy(ptr %t1228, ptr %t1223, i64 %t1224)
  %t1229 = insertvalue { i64, ptr } undef, i64 %t1225, 0
  %t1230 = insertvalue { i64, ptr } %t1229, ptr %t1226, 1
  %t1232 = load ptr, ptr %l500, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s49, ptr %v2, ptr %t1232, { i64, ptr } %t1230)
  br label %bb230
bb230:
  %t1234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1234, ptr %l507, !tbaa !29
  %t1235 = load ptr, ptr %l0, !tbaa !29
  %t1236 = load i32, ptr %l35, !tbaa !23
  %t1239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s49, ptr %v2, ptr %t1235, i32 %t1236)
  store { i64, ptr } %t1239, ptr %l510
  br label %bb231
bb231:
  %t1240 = load { i64, ptr }, ptr %l510, !tbaa !27
  %t1241 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1242 = load ptr, ptr %l507, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s49, ptr %s49, ptr %s48, ptr %s49, ptr %v2, ptr %t1242, { i64, ptr } %t1240, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d304, i32 0, i32 1) }, { i64, ptr } %t1241, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) })
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s49)
  call void @__olang_scope_close(ptr %s48)
  br label %ret
bb233:
  %t1245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1245, ptr %l513, !tbaa !29
  %t1246 = load ptr, ptr %l0, !tbaa !29
  %t1247 = load i32, ptr %l35, !tbaa !23
  %t1250 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s48, ptr %v2, ptr %t1246, i32 %t1247)
  store { i64, ptr } %t1250, ptr %l516
  br label %bb234
bb234:
  %t1251 = load { i64, ptr }, ptr %l516, !tbaa !27
  %t1252 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1253 = load ptr, ptr %l513, !tbaa !29
  %t1256 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s48, ptr %s48, ptr %s48, ptr %s48, ptr %v2, ptr %t1253, { i64, ptr } %t1251, { i64, ptr } %t1252, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t1256, ptr %l519
  br label %bb235
bb235:
  %t1257 = load { i64, ptr }, ptr %l519, !tbaa !27
  store { i64, ptr } %t1257, ptr %l36, !tbaa !27
  %t1258 = load ptr, ptr %l0, !tbaa !29
  %t1260 = getelementptr %"compiler/emit:fnEm", ptr %t1258, i32 0, i32 0
  %t1261 = load ptr, ptr %t1260, !tbaa !29
  store ptr %t1261, ptr %l521, !tbaa !29
  %t1262 = load ptr, ptr %l521, !tbaa !29
  %t1263 = call ptr @__olang_scope_or(ptr %v2, ptr %t1262)
  %t1264 = call ptr @__olang_scope_hold(ptr %t1263)
  %t1265 = ptrtoint ptr %t1264 to i64
  %t1267 = inttoptr i64 %t1265 to ptr
  %t1268 = load ptr, ptr %l521, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1267, ptr %s48, ptr %t1268, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d305, i32 0, i32 1) })
  br label %bb236
bb236:
  %t1269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1269, ptr %l523, !tbaa !29
  %t1270 = load ptr, ptr %l0, !tbaa !29
  %t1271 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1272 = load i32, ptr %l35, !tbaa !23
  %t1276 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %s48, ptr %s48, ptr %v2, ptr %t1270, { i64, ptr } %t1271, i32 %t1272)
  store { i64, ptr } %t1276, ptr %l527
  br label %bb237
bb237:
  %t1277 = load { i64, ptr }, ptr %l527, !tbaa !27
  %t1278 = extractvalue { i64, ptr } %t1277, 0
  store i64 %t1278, ptr %l528, !tbaa !24
  %t1279 = load i64, ptr %l528, !tbaa !24
  %t1280 = mul i64 %t1279, 1
  %t1281 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1280)
  %t1282 = insertvalue { i64, ptr } undef, i64 %t1279, 0
  %t1283 = insertvalue { i64, ptr } %t1282, ptr %t1281, 1
  store { i64, ptr } %t1283, ptr %l529, !tbaa !27
  %t1284 = getelementptr { i64, ptr }, ptr %l529, i32 0, i32 1
  %t1285 = load ptr, ptr %t1284, !tbaa !27
  %t1286 = getelementptr { i64, ptr }, ptr %l527, i32 0, i32 1
  %t1287 = load ptr, ptr %t1286, !tbaa !27
  %t1288 = load i64, ptr %l528, !tbaa !24
  %t1289 = mul i64 %t1288, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1285, ptr %t1287, i64 %t1289, i1 false)
  %t1290 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t1291 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t1292 = load { i64, ptr }, ptr %l529, !tbaa !27
  %t1293 = extractvalue { i64, ptr } %t1292, 1
  %t1294 = extractvalue { i64, ptr } %t1292, 0
  %t1295 = add i64 %t1291, %t1294
  %t1296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t1297 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t1298 = add i64 %t1295, %t1297
  %t1299 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1298)
  call void @olang_textcopy(ptr %t1299, ptr %t1290, i64 %t1291)
  %t1300 = getelementptr i8, ptr %t1299, i64 %t1291
  call void @olang_textcopy(ptr %t1300, ptr %t1293, i64 %t1294)
  %t1301 = getelementptr i8, ptr %t1300, i64 %t1294
  call void @olang_textcopy(ptr %t1301, ptr %t1296, i64 %t1297)
  %t1302 = insertvalue { i64, ptr } undef, i64 %t1298, 0
  %t1303 = insertvalue { i64, ptr } %t1302, ptr %t1299, 1
  %t1305 = load ptr, ptr %l523, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s48, ptr %v2, ptr %t1305, { i64, ptr } %t1303)
  br label %bb238
bb238:
  %t1307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1307, ptr %l532, !tbaa !29
  %t1308 = load ptr, ptr %l0, !tbaa !29
  %t1309 = load i32, ptr %l35, !tbaa !23
  %t1312 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s48, ptr %v2, ptr %t1308, i32 %t1309)
  store { i64, ptr } %t1312, ptr %l535
  br label %bb239
bb239:
  %t1313 = load { i64, ptr }, ptr %l535, !tbaa !27
  store { i64, ptr } %t1313, ptr %l536, !tbaa !27
  %t1314 = load ptr, ptr %l0, !tbaa !29
  %t1316 = getelementptr %"compiler/emit:fnEm", ptr %t1314, i32 0, i32 0
  %t1317 = load ptr, ptr %t1316, !tbaa !29
  store ptr %t1317, ptr %l538, !tbaa !29
  %t1318 = load i32, ptr %l35, !tbaa !23
  %t1319 = load ptr, ptr %l538, !tbaa !29
  %t1320 = call ptr @__olang_scope_or(ptr %v2, ptr %t1319)
  %t1321 = call ptr @__olang_scope_hold(ptr %t1320)
  %t1322 = ptrtoint ptr %t1321 to i64
  %t1324 = inttoptr i64 %t1322 to ptr
  %t1325 = load ptr, ptr %l538, !tbaa !29
  %t1327 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %t1324, ptr %s48, ptr %t1325, i32 %t1318, i64 0)
  store { i64, ptr } %t1327, ptr %l541
  br label %bb240
bb240:
  %t1328 = load { i64, ptr }, ptr %l541, !tbaa !27
  %t1329 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1330 = load ptr, ptr %l532, !tbaa !29
  %t1331 = load { i64, ptr }, ptr %l536, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s48, ptr %s48, ptr %s48, ptr %s48, ptr %v2, ptr %t1330, { i64, ptr } %t1331, { i64, ptr } %t1328, { i64, ptr } %t1329, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) })
  br label %bb241
bb241:
  call void @__olang_scope_close(ptr %s48)
  br label %bb338
bb242:
  %t1334 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1334, ptr %l544, !tbaa !29
  store i1 false, ptr %l545, !tbaa !21
  %t1335 = load ptr, ptr %l544, !tbaa !29
  %t1336 = icmp ne ptr %t1335, null
  br i1 %t1336, label %bb243, label %bb244
bb243:
  %t1338 = load ptr, ptr %l544, !tbaa !29
  %t1339 = load i64, ptr %t1338, !range !{i64 0, i64 20}
  %t1341 = icmp eq i64 %t1339, 8
  store i1 %t1341, ptr %l545, !tbaa !21
  br label %bb244
bb244:
  %t1342 = load i1, ptr %l545, !tbaa !21
  br i1 %t1342, label %bb245, label %bb246
bb245:
  %t1343 = load ptr, ptr %l1, !tbaa !29
  %t1345 = getelementptr { i64, [21 x i64] }, ptr %t1343, i32 0, i32 1
  %t1346 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t1345, i32 0, i32 1
  %t1347 = load %"compiler/mir:Lvalue", ptr %t1346
  store %"compiler/mir:Lvalue" %t1347, ptr %l37
  br label %bb247
bb246:
  br label %bb258
bb247:
  store %olang.scope zeroinitializer, ptr %s52
  %t1349 = load ptr, ptr %l0, !tbaa !29
  %t1350 = load %"compiler/mir:Lvalue", ptr %l37
  %t1353 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s52, ptr %v3, ptr %v2, ptr %t1349, %"compiler/mir:Lvalue" %t1350)
  store { { i64, ptr }, i32 } %t1353, ptr %l552
  br label %bb248
bb248:
  %t1354 = load { { i64, ptr }, i32 }, ptr %l552
  store { { i64, ptr }, i32 } %t1354, ptr %l38
  %t1355 = getelementptr { { i64, ptr }, i32 }, ptr %l38, i32 0, i32 0
  %t1356 = load { i64, ptr }, ptr %t1355, !tbaa !27
  store { i64, ptr } %t1356, ptr %l39, !tbaa !27
  %t1358 = getelementptr { { i64, ptr }, i32 }, ptr %l38, i32 0, i32 1
  %t1359 = load i32, ptr %t1358, !tbaa !23
  store i32 %t1359, ptr %l40, !tbaa !23
  %t1361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1361, ptr %l555, !tbaa !29
  %t1362 = load ptr, ptr %l0, !tbaa !29
  %t1363 = load i32, ptr %l40, !tbaa !23
  %t1366 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s52, ptr %v2, ptr %t1362, i32 %t1363)
  store { i64, ptr } %t1366, ptr %l558
  br label %bb249
bb249:
  %t1367 = load { i64, ptr }, ptr %l558, !tbaa !27
  %t1368 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1369 = load ptr, ptr %l555, !tbaa !29
  %t1372 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s52, ptr %s52, ptr %s52, ptr %s52, ptr %v2, ptr %t1369, { i64, ptr } %t1367, { i64, ptr } %t1368, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t1372, ptr %l561
  br label %bb250
bb250:
  %t1373 = load { i64, ptr }, ptr %l561, !tbaa !27
  store { i64, ptr } %t1373, ptr %l41, !tbaa !27
  %t1374 = load ptr, ptr %l0, !tbaa !29
  %t1376 = getelementptr %"compiler/emit:fnEm", ptr %t1374, i32 0, i32 0
  %t1377 = load ptr, ptr %t1376, !tbaa !29
  store ptr %t1377, ptr %l563, !tbaa !29
  %t1378 = load ptr, ptr %l563, !tbaa !29
  %t1379 = call ptr @__olang_scope_or(ptr %v2, ptr %t1378)
  %t1380 = call ptr @__olang_scope_hold(ptr %t1379)
  %t1381 = ptrtoint ptr %t1380 to i64
  %t1383 = inttoptr i64 %t1381 to ptr
  %t1384 = load ptr, ptr %l563, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1383, ptr %s52, ptr %t1384, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d308, i32 0, i32 1) })
  br label %bb251
bb251:
  %t1385 = load ptr, ptr %l0, !tbaa !29
  %t1386 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1387 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t1388 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t1390 = extractvalue { i64, ptr } %t1386, 1
  %t1391 = extractvalue { i64, ptr } %t1386, 0
  %t1392 = add i64 %t1388, %t1391
  %t1393 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t1394 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t1395 = add i64 %t1392, %t1394
  %t1396 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1395)
  call void @olang_textcopy(ptr %t1396, ptr %t1387, i64 %t1388)
  %t1397 = getelementptr i8, ptr %t1396, i64 %t1388
  call void @olang_textcopy(ptr %t1397, ptr %t1390, i64 %t1391)
  %t1398 = getelementptr i8, ptr %t1397, i64 %t1391
  call void @olang_textcopy(ptr %t1398, ptr %t1393, i64 %t1394)
  %t1399 = insertvalue { i64, ptr } undef, i64 %t1395, 0
  %t1400 = insertvalue { i64, ptr } %t1399, ptr %t1396, 1
  %t1404 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s52, ptr %s52, ptr %v2, ptr %t1385, { i64, ptr } %t1400)
  store { i64, ptr } %t1404, ptr %l569
  br label %bb252
bb252:
  %t1405 = load { i64, ptr }, ptr %l569, !tbaa !27
  store { i64, ptr } %t1405, ptr %l42, !tbaa !27
  %t1406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1406, ptr %l570, !tbaa !29
  %t1407 = load ptr, ptr %l0, !tbaa !29
  %t1408 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1409 = load i32, ptr %l40, !tbaa !23
  %t1413 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %s52, ptr %s52, ptr %v2, ptr %t1407, { i64, ptr } %t1408, i32 %t1409)
  store { i64, ptr } %t1413, ptr %l574
  br label %bb253
bb253:
  %t1414 = load { i64, ptr }, ptr %l574, !tbaa !27
  %t1415 = extractvalue { i64, ptr } %t1414, 0
  store i64 %t1415, ptr %l575, !tbaa !24
  %t1416 = load i64, ptr %l575, !tbaa !24
  %t1417 = mul i64 %t1416, 1
  %t1418 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1417)
  %t1419 = insertvalue { i64, ptr } undef, i64 %t1416, 0
  %t1420 = insertvalue { i64, ptr } %t1419, ptr %t1418, 1
  store { i64, ptr } %t1420, ptr %l576, !tbaa !27
  %t1421 = getelementptr { i64, ptr }, ptr %l576, i32 0, i32 1
  %t1422 = load ptr, ptr %t1421, !tbaa !27
  %t1423 = getelementptr { i64, ptr }, ptr %l574, i32 0, i32 1
  %t1424 = load ptr, ptr %t1423, !tbaa !27
  %t1425 = load i64, ptr %l575, !tbaa !24
  %t1426 = mul i64 %t1425, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1422, ptr %t1424, i64 %t1426, i1 false)
  %t1427 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t1428 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t1429 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t1430 = load { i64, ptr }, ptr %l576, !tbaa !27
  %t1431 = extractvalue { i64, ptr } %t1430, 1
  %t1432 = extractvalue { i64, ptr } %t1430, 0
  %t1433 = add i64 %t1429, %t1432
  %t1434 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t1435 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t1436 = add i64 %t1433, %t1435
  %t1438 = extractvalue { i64, ptr } %t1427, 1
  %t1439 = extractvalue { i64, ptr } %t1427, 0
  %t1440 = add i64 %t1436, %t1439
  %t1441 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t1442 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t1443 = add i64 %t1440, %t1442
  %t1444 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1443)
  call void @olang_textcopy(ptr %t1444, ptr %t1428, i64 %t1429)
  %t1445 = getelementptr i8, ptr %t1444, i64 %t1429
  call void @olang_textcopy(ptr %t1445, ptr %t1431, i64 %t1432)
  %t1446 = getelementptr i8, ptr %t1445, i64 %t1432
  call void @olang_textcopy(ptr %t1446, ptr %t1434, i64 %t1435)
  %t1447 = getelementptr i8, ptr %t1446, i64 %t1435
  call void @olang_textcopy(ptr %t1447, ptr %t1438, i64 %t1439)
  %t1448 = getelementptr i8, ptr %t1447, i64 %t1439
  call void @olang_textcopy(ptr %t1448, ptr %t1441, i64 %t1442)
  %t1449 = insertvalue { i64, ptr } undef, i64 %t1443, 0
  %t1450 = insertvalue { i64, ptr } %t1449, ptr %t1444, 1
  %t1452 = load ptr, ptr %l570, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s52, ptr %v2, ptr %t1452, { i64, ptr } %t1450)
  br label %bb254
bb254:
  %t1454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1454, ptr %l580, !tbaa !29
  %t1455 = load ptr, ptr %l0, !tbaa !29
  %t1456 = load i32, ptr %l40, !tbaa !23
  %t1459 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s52, ptr %v2, ptr %t1455, i32 %t1456)
  store { i64, ptr } %t1459, ptr %l583
  br label %bb255
bb255:
  %t1460 = load { i64, ptr }, ptr %l583, !tbaa !27
  store { i64, ptr } %t1460, ptr %l584, !tbaa !27
  %t1461 = load ptr, ptr %l0, !tbaa !29
  %t1463 = getelementptr %"compiler/emit:fnEm", ptr %t1461, i32 0, i32 0
  %t1464 = load ptr, ptr %t1463, !tbaa !29
  store ptr %t1464, ptr %l586, !tbaa !29
  %t1465 = load i32, ptr %l40, !tbaa !23
  %t1466 = load ptr, ptr %l586, !tbaa !29
  %t1467 = call ptr @__olang_scope_or(ptr %v2, ptr %t1466)
  %t1468 = call ptr @__olang_scope_hold(ptr %t1467)
  %t1469 = ptrtoint ptr %t1468 to i64
  %t1471 = inttoptr i64 %t1469 to ptr
  %t1472 = load ptr, ptr %l586, !tbaa !29
  %t1474 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %t1471, ptr %s52, ptr %t1472, i32 %t1465, i64 0)
  store { i64, ptr } %t1474, ptr %l589
  br label %bb256
bb256:
  %t1475 = load { i64, ptr }, ptr %l589, !tbaa !27
  %t1476 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1477 = load ptr, ptr %l580, !tbaa !29
  %t1478 = load { i64, ptr }, ptr %l584, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s52, ptr %s52, ptr %s52, ptr %s52, ptr %v2, ptr %t1477, { i64, ptr } %t1478, { i64, ptr } %t1475, { i64, ptr } %t1476, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) })
  br label %bb257
bb257:
  call void @__olang_scope_close(ptr %s52)
  br label %bb338
bb258:
  %t1481 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1481, ptr %l592, !tbaa !29
  store i1 false, ptr %l593, !tbaa !21
  %t1482 = load ptr, ptr %l592, !tbaa !29
  %t1483 = icmp ne ptr %t1482, null
  br i1 %t1483, label %bb259, label %bb260
bb259:
  %t1485 = load ptr, ptr %l592, !tbaa !29
  %t1486 = load i64, ptr %t1485, !range !{i64 0, i64 20}
  %t1488 = icmp eq i64 %t1486, 7
  store i1 %t1488, ptr %l593, !tbaa !21
  br label %bb260
bb260:
  %t1489 = load i1, ptr %l593, !tbaa !21
  br i1 %t1489, label %bb261, label %bb262
bb261:
  %t1490 = load ptr, ptr %l1, !tbaa !29
  %t1492 = getelementptr { i64, [21 x i64] }, ptr %t1490, i32 0, i32 1
  %t1493 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t1492, i32 0, i32 1
  %t1494 = load %"compiler/mir:Lvalue", ptr %t1493
  store %"compiler/mir:Lvalue" %t1494, ptr %l43
  br label %bb263
bb262:
  br label %bb273
bb263:
  store %olang.scope zeroinitializer, ptr %s55
  %t1496 = load ptr, ptr %l0, !tbaa !29
  %t1497 = load %"compiler/mir:Lvalue", ptr %l43
  %t1500 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s55, ptr %v3, ptr %v2, ptr %t1496, %"compiler/mir:Lvalue" %t1497)
  store { { i64, ptr }, i32 } %t1500, ptr %l600
  br label %bb264
bb264:
  %t1501 = load { { i64, ptr }, i32 }, ptr %l600
  store { { i64, ptr }, i32 } %t1501, ptr %l44
  %t1502 = getelementptr { { i64, ptr }, i32 }, ptr %l44, i32 0, i32 0
  %t1503 = load { i64, ptr }, ptr %t1502, !tbaa !27
  store { i64, ptr } %t1503, ptr %l45, !tbaa !27
  %t1505 = getelementptr { { i64, ptr }, i32 }, ptr %l44, i32 0, i32 1
  %t1506 = load i32, ptr %t1505, !tbaa !23
  store i32 %t1506, ptr %l46, !tbaa !23
  %t1508 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1508, ptr %l603, !tbaa !29
  %t1509 = load ptr, ptr %l0, !tbaa !29
  %t1510 = load i32, ptr %l46, !tbaa !23
  %t1513 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s55, ptr %v2, ptr %t1509, i32 %t1510)
  store { i64, ptr } %t1513, ptr %l606
  br label %bb265
bb265:
  %t1514 = load { i64, ptr }, ptr %l606, !tbaa !27
  %t1515 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1516 = load ptr, ptr %l603, !tbaa !29
  %t1519 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s55, ptr %s55, ptr %s55, ptr %s55, ptr %v2, ptr %t1516, { i64, ptr } %t1514, { i64, ptr } %t1515, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t1519, ptr %l609
  br label %bb266
bb266:
  %t1520 = load { i64, ptr }, ptr %l609, !tbaa !27
  store { i64, ptr } %t1520, ptr %l47, !tbaa !27
  %t1521 = load ptr, ptr %l0, !tbaa !29
  %t1523 = getelementptr %"compiler/emit:fnEm", ptr %t1521, i32 0, i32 0
  %t1524 = load ptr, ptr %t1523, !tbaa !29
  store ptr %t1524, ptr %l611, !tbaa !29
  %t1525 = load ptr, ptr %l611, !tbaa !29
  %t1526 = call ptr @__olang_scope_or(ptr %v2, ptr %t1525)
  %t1527 = call ptr @__olang_scope_hold(ptr %t1526)
  %t1528 = ptrtoint ptr %t1527 to i64
  %t1530 = inttoptr i64 %t1528 to ptr
  %t1531 = load ptr, ptr %l611, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1530, ptr %s55, ptr %t1531, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d314, i32 0, i32 1) })
  br label %bb267
bb267:
  %t1532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1532, ptr %l613, !tbaa !29
  %t1533 = load ptr, ptr %l0, !tbaa !29
  %t1534 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1535 = load i32, ptr %l46, !tbaa !23
  %t1539 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %s55, ptr %s55, ptr %v2, ptr %t1533, { i64, ptr } %t1534, i32 %t1535)
  store { i64, ptr } %t1539, ptr %l617
  br label %bb268
bb268:
  %t1540 = load { i64, ptr }, ptr %l617, !tbaa !27
  %t1541 = extractvalue { i64, ptr } %t1540, 0
  store i64 %t1541, ptr %l618, !tbaa !24
  %t1542 = load i64, ptr %l618, !tbaa !24
  %t1543 = mul i64 %t1542, 1
  %t1544 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1543)
  %t1545 = insertvalue { i64, ptr } undef, i64 %t1542, 0
  %t1546 = insertvalue { i64, ptr } %t1545, ptr %t1544, 1
  store { i64, ptr } %t1546, ptr %l619, !tbaa !27
  %t1547 = getelementptr { i64, ptr }, ptr %l619, i32 0, i32 1
  %t1548 = load ptr, ptr %t1547, !tbaa !27
  %t1549 = getelementptr { i64, ptr }, ptr %l617, i32 0, i32 1
  %t1550 = load ptr, ptr %t1549, !tbaa !27
  %t1551 = load i64, ptr %l618, !tbaa !24
  %t1552 = mul i64 %t1551, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1548, ptr %t1550, i64 %t1552, i1 false)
  %t1553 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t1554 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t1555 = load { i64, ptr }, ptr %l619, !tbaa !27
  %t1556 = extractvalue { i64, ptr } %t1555, 1
  %t1557 = extractvalue { i64, ptr } %t1555, 0
  %t1558 = add i64 %t1554, %t1557
  %t1559 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t1560 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t1561 = add i64 %t1558, %t1560
  %t1562 = call ptr @__olang_scope_alloc(ptr %s55, i64 %t1561)
  call void @olang_textcopy(ptr %t1562, ptr %t1553, i64 %t1554)
  %t1563 = getelementptr i8, ptr %t1562, i64 %t1554
  call void @olang_textcopy(ptr %t1563, ptr %t1556, i64 %t1557)
  %t1564 = getelementptr i8, ptr %t1563, i64 %t1557
  call void @olang_textcopy(ptr %t1564, ptr %t1559, i64 %t1560)
  %t1565 = insertvalue { i64, ptr } undef, i64 %t1561, 0
  %t1566 = insertvalue { i64, ptr } %t1565, ptr %t1562, 1
  %t1568 = load ptr, ptr %l613, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s55, ptr %v2, ptr %t1568, { i64, ptr } %t1566)
  br label %bb269
bb269:
  %t1570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1570, ptr %l622, !tbaa !29
  %t1571 = load ptr, ptr %l0, !tbaa !29
  %t1572 = load i32, ptr %l46, !tbaa !23
  %t1575 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s55, ptr %v2, ptr %t1571, i32 %t1572)
  store { i64, ptr } %t1575, ptr %l625
  br label %bb270
bb270:
  %t1576 = load { i64, ptr }, ptr %l625, !tbaa !27
  store { i64, ptr } %t1576, ptr %l626, !tbaa !27
  %t1577 = load ptr, ptr %l0, !tbaa !29
  %t1579 = getelementptr %"compiler/emit:fnEm", ptr %t1577, i32 0, i32 0
  %t1580 = load ptr, ptr %t1579, !tbaa !29
  store ptr %t1580, ptr %l628, !tbaa !29
  %t1581 = load i32, ptr %l46, !tbaa !23
  %t1582 = load ptr, ptr %l628, !tbaa !29
  %t1583 = call ptr @__olang_scope_or(ptr %v2, ptr %t1582)
  %t1584 = call ptr @__olang_scope_hold(ptr %t1583)
  %t1585 = ptrtoint ptr %t1584 to i64
  %t1587 = inttoptr i64 %t1585 to ptr
  %t1588 = load ptr, ptr %l628, !tbaa !29
  %t1590 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %t1587, ptr %s55, ptr %t1588, i32 %t1581, i64 0)
  store { i64, ptr } %t1590, ptr %l631
  br label %bb271
bb271:
  %t1591 = load { i64, ptr }, ptr %l631, !tbaa !27
  %t1592 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1593 = load ptr, ptr %l622, !tbaa !29
  %t1594 = load { i64, ptr }, ptr %l626, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s55, ptr %s55, ptr %s55, ptr %s55, ptr %v2, ptr %t1593, { i64, ptr } %t1594, { i64, ptr } %t1591, { i64, ptr } %t1592, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) })
  br label %bb272
bb272:
  call void @__olang_scope_close(ptr %s55)
  br label %bb338
bb273:
  %t1597 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1597, ptr %l634, !tbaa !29
  store i1 false, ptr %l635, !tbaa !21
  %t1598 = load ptr, ptr %l634, !tbaa !29
  %t1599 = icmp ne ptr %t1598, null
  br i1 %t1599, label %bb274, label %bb275
bb274:
  %t1601 = load ptr, ptr %l634, !tbaa !29
  %t1602 = load i64, ptr %t1601, !range !{i64 0, i64 20}
  %t1604 = icmp eq i64 %t1602, 9
  store i1 %t1604, ptr %l635, !tbaa !21
  br label %bb275
bb275:
  %t1605 = load i1, ptr %l635, !tbaa !21
  br i1 %t1605, label %bb276, label %bb277
bb276:
  %t1606 = load ptr, ptr %l1, !tbaa !29
  %t1608 = getelementptr { i64, [21 x i64] }, ptr %t1606, i32 0, i32 1
  %t1609 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t1608, i32 0, i32 1
  %t1610 = load i32, ptr %t1609
  store i32 %t1610, ptr %l48, !tbaa !23
  %t1612 = load ptr, ptr %l1, !tbaa !29
  %t1614 = getelementptr { i64, [21 x i64] }, ptr %t1612, i32 0, i32 1
  %t1615 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t1614, i32 0, i32 2
  %t1616 = load %"compiler/mir:Lvalue", ptr %t1615
  store %"compiler/mir:Lvalue" %t1616, ptr %l49
  br label %bb278
bb277:
  br label %bb286
bb278:
  store %olang.scope zeroinitializer, ptr %s57
  %t1618 = load ptr, ptr %l0, !tbaa !29
  %t1619 = load %"compiler/mir:Lvalue", ptr %l49
  %t1622 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s57, ptr %v3, ptr %v2, ptr %t1618, %"compiler/mir:Lvalue" %t1619)
  store { { i64, ptr }, i32 } %t1622, ptr %l644
  br label %bb279
bb279:
  %t1623 = load { { i64, ptr }, i32 }, ptr %l644
  store { { i64, ptr }, i32 } %t1623, ptr %l50
  %t1624 = getelementptr { { i64, ptr }, i32 }, ptr %l50, i32 0, i32 0
  %t1625 = load { i64, ptr }, ptr %t1624, !tbaa !27
  store { i64, ptr } %t1625, ptr %l645, !tbaa !27
  %t1626 = load { i64, ptr }, ptr %l645, !tbaa !27
  %t1627 = extractvalue { i64, ptr } %t1626, 0
  store i64 %t1627, ptr %l646, !tbaa !24
  %t1628 = load i64, ptr %l646, !tbaa !24
  %t1629 = mul i64 %t1628, 1
  %t1630 = call ptr @__olang_scope_alloc(ptr %s57, i64 %t1629)
  %t1631 = insertvalue { i64, ptr } undef, i64 %t1628, 0
  %t1632 = insertvalue { i64, ptr } %t1631, ptr %t1630, 1
  store { i64, ptr } %t1632, ptr %l647, !tbaa !27
  %t1633 = getelementptr { i64, ptr }, ptr %l647, i32 0, i32 1
  %t1634 = load ptr, ptr %t1633, !tbaa !27
  %t1635 = getelementptr { i64, ptr }, ptr %l645, i32 0, i32 1
  %t1636 = load ptr, ptr %t1635, !tbaa !27
  %t1637 = load i64, ptr %l646, !tbaa !24
  %t1638 = mul i64 %t1637, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1634, ptr %t1636, i64 %t1638, i1 false)
  %t1639 = load { i64, ptr }, ptr %l647, !tbaa !27
  store { i64, ptr } %t1639, ptr %l51, !tbaa !27
  %t1640 = getelementptr { { i64, ptr }, i32 }, ptr %l50, i32 0, i32 1
  %t1641 = load i32, ptr %t1640, !tbaa !23
  store i32 %t1641, ptr %l52, !tbaa !23
  %t1643 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1643, ptr %l649, !tbaa !29
  %t1644 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1644, ptr %l650, !tbaa !29
  %t1645 = load ptr, ptr %l0, !tbaa !29
  %t1646 = load i32, ptr %l48, !tbaa !23
  %t1649 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s57, ptr %v3, ptr %v2, ptr %t1645, i32 %t1646)
  store { i64, ptr } %t1649, ptr %l653
  br label %bb280
bb280:
  %t1650 = load { i64, ptr }, ptr %l653, !tbaa !27
  %t1651 = load ptr, ptr %l650, !tbaa !29
  %t1653 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s57, ptr %s57, ptr %s57, ptr %s57, ptr %v2, ptr %t1651, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d317, i32 0, i32 1) }, { i64, ptr } %t1650, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t1653, ptr %l655
  br label %bb281
bb281:
  %t1654 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t1655 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t1656 = load { i64, ptr }, ptr %l655, !tbaa !27
  %t1657 = extractvalue { i64, ptr } %t1656, 1
  %t1658 = extractvalue { i64, ptr } %t1656, 0
  %t1659 = add i64 %t1655, %t1658
  %t1660 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t1661 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t1662 = add i64 %t1659, %t1661
  %t1663 = call ptr @__olang_scope_alloc(ptr %s57, i64 %t1662)
  call void @olang_textcopy(ptr %t1663, ptr %t1654, i64 %t1655)
  %t1664 = getelementptr i8, ptr %t1663, i64 %t1655
  call void @olang_textcopy(ptr %t1664, ptr %t1657, i64 %t1658)
  %t1665 = getelementptr i8, ptr %t1664, i64 %t1658
  call void @olang_textcopy(ptr %t1665, ptr %t1660, i64 %t1661)
  %t1666 = insertvalue { i64, ptr } undef, i64 %t1662, 0
  %t1667 = insertvalue { i64, ptr } %t1666, ptr %t1663, 1
  %t1669 = load ptr, ptr %l649, !tbaa !29
  %t1671 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s57, ptr %s57, ptr %v2, ptr %t1669, { i64, ptr } %t1667)
  store { i64, ptr } %t1671, ptr %l658
  br label %bb282
bb282:
  %t1672 = load { i64, ptr }, ptr %l658, !tbaa !27
  store { i64, ptr } %t1672, ptr %l53, !tbaa !27
  %t1673 = load ptr, ptr %l0, !tbaa !29
  %t1674 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t1675 = load i32, ptr %l52, !tbaa !23
  %t1679 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eanchorRegion(ptr %v0, ptr %s57, ptr %s57, ptr %v2, ptr %t1673, { i64, ptr } %t1674, i32 %t1675)
  store { i64, ptr } %t1679, ptr %l662
  br label %bb283
bb283:
  %t1680 = load { i64, ptr }, ptr %l662, !tbaa !27
  store { i64, ptr } %t1680, ptr %l54, !tbaa !27
  %t1681 = load ptr, ptr %l0, !tbaa !29
  %t1683 = getelementptr %"compiler/emit:fnEm", ptr %t1681, i32 0, i32 0
  %t1684 = load ptr, ptr %t1683, !tbaa !29
  store ptr %t1684, ptr %l664, !tbaa !29
  %t1685 = load ptr, ptr %l664, !tbaa !29
  %t1686 = call ptr @__olang_scope_or(ptr %v2, ptr %t1685)
  %t1687 = call ptr @__olang_scope_hold(ptr %t1686)
  %t1688 = ptrtoint ptr %t1687 to i64
  %t1690 = inttoptr i64 %t1688 to ptr
  %t1691 = load ptr, ptr %l664, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1690, ptr %s57, ptr %t1691, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d320, i32 0, i32 1) })
  br label %bb284
bb284:
  %t1692 = load ptr, ptr %l0, !tbaa !29
  %t1693 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t1694 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t1695 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t1696 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t1698 = extractvalue { i64, ptr } %t1693, 1
  %t1699 = extractvalue { i64, ptr } %t1693, 0
  %t1700 = add i64 %t1696, %t1699
  %t1701 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t1702 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t1703 = add i64 %t1700, %t1702
  %t1705 = extractvalue { i64, ptr } %t1694, 1
  %t1706 = extractvalue { i64, ptr } %t1694, 0
  %t1707 = add i64 %t1703, %t1706
  %t1708 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t1709 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t1710 = add i64 %t1707, %t1709
  %t1711 = call ptr @__olang_scope_alloc(ptr %s57, i64 %t1710)
  call void @olang_textcopy(ptr %t1711, ptr %t1695, i64 %t1696)
  %t1712 = getelementptr i8, ptr %t1711, i64 %t1696
  call void @olang_textcopy(ptr %t1712, ptr %t1698, i64 %t1699)
  %t1713 = getelementptr i8, ptr %t1712, i64 %t1699
  call void @olang_textcopy(ptr %t1713, ptr %t1701, i64 %t1702)
  %t1714 = getelementptr i8, ptr %t1713, i64 %t1702
  call void @olang_textcopy(ptr %t1714, ptr %t1705, i64 %t1706)
  %t1715 = getelementptr i8, ptr %t1714, i64 %t1706
  call void @olang_textcopy(ptr %t1715, ptr %t1708, i64 %t1709)
  %t1716 = insertvalue { i64, ptr } undef, i64 %t1710, 0
  %t1717 = insertvalue { i64, ptr } %t1716, ptr %t1711, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s57, ptr %v2, ptr %t1692, { i64, ptr } %t1717)
  br label %bb285
bb285:
  call void @__olang_scope_close(ptr %s57)
  br label %bb338
bb286:
  %t1721 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1721, ptr %l671, !tbaa !29
  store i1 false, ptr %l672, !tbaa !21
  %t1722 = load ptr, ptr %l671, !tbaa !29
  %t1723 = icmp ne ptr %t1722, null
  br i1 %t1723, label %bb287, label %bb288
bb287:
  %t1725 = load ptr, ptr %l671, !tbaa !29
  %t1726 = load i64, ptr %t1725, !range !{i64 0, i64 20}
  %t1728 = icmp eq i64 %t1726, 10
  store i1 %t1728, ptr %l672, !tbaa !21
  br label %bb288
bb288:
  %t1729 = load i1, ptr %l672, !tbaa !21
  br i1 %t1729, label %bb289, label %bb290
bb289:
  %t1730 = load ptr, ptr %l1, !tbaa !29
  %t1732 = getelementptr { i64, [21 x i64] }, ptr %t1730, i32 0, i32 1
  %t1733 = getelementptr { %"compiler/source:Span", i32 }, ptr %t1732, i32 0, i32 1
  %t1734 = load i32, ptr %t1733
  store i32 %t1734, ptr %l55, !tbaa !23
  br label %bb291
bb290:
  br label %bb297
bb291:
  store %olang.scope zeroinitializer, ptr %s60
  %t1736 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1736, ptr %l677, !tbaa !29
  %t1737 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1737, ptr %l678, !tbaa !29
  %t1738 = load ptr, ptr %l0, !tbaa !29
  %t1739 = load i32, ptr %l55, !tbaa !23
  %t1742 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s60, ptr %v3, ptr %v2, ptr %t1738, i32 %t1739)
  store { i64, ptr } %t1742, ptr %l681
  br label %bb292
bb292:
  %t1743 = load { i64, ptr }, ptr %l681, !tbaa !27
  %t1744 = load ptr, ptr %l678, !tbaa !29
  %t1746 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s60, ptr %s60, ptr %s60, ptr %s60, ptr %v2, ptr %t1744, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d324, i32 0, i32 1) }, { i64, ptr } %t1743, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t1746, ptr %l683
  br label %bb293
bb293:
  %t1747 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t1748 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t1749 = load { i64, ptr }, ptr %l683, !tbaa !27
  %t1750 = extractvalue { i64, ptr } %t1749, 1
  %t1751 = extractvalue { i64, ptr } %t1749, 0
  %t1752 = add i64 %t1748, %t1751
  %t1753 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t1754 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t1755 = add i64 %t1752, %t1754
  %t1756 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1755)
  call void @olang_textcopy(ptr %t1756, ptr %t1747, i64 %t1748)
  %t1757 = getelementptr i8, ptr %t1756, i64 %t1748
  call void @olang_textcopy(ptr %t1757, ptr %t1750, i64 %t1751)
  %t1758 = getelementptr i8, ptr %t1757, i64 %t1751
  call void @olang_textcopy(ptr %t1758, ptr %t1753, i64 %t1754)
  %t1759 = insertvalue { i64, ptr } undef, i64 %t1755, 0
  %t1760 = insertvalue { i64, ptr } %t1759, ptr %t1756, 1
  %t1762 = load ptr, ptr %l677, !tbaa !29
  %t1764 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s60, ptr %s60, ptr %v2, ptr %t1762, { i64, ptr } %t1760)
  store { i64, ptr } %t1764, ptr %l686
  br label %bb294
bb294:
  %t1765 = load { i64, ptr }, ptr %l686, !tbaa !27
  store { i64, ptr } %t1765, ptr %l56, !tbaa !27
  %t1766 = load ptr, ptr %l0, !tbaa !29
  %t1768 = getelementptr %"compiler/emit:fnEm", ptr %t1766, i32 0, i32 0
  %t1769 = load ptr, ptr %t1768, !tbaa !29
  store ptr %t1769, ptr %l688, !tbaa !29
  %t1770 = load ptr, ptr %l688, !tbaa !29
  %t1771 = call ptr @__olang_scope_or(ptr %v2, ptr %t1770)
  %t1772 = call ptr @__olang_scope_hold(ptr %t1771)
  %t1773 = ptrtoint ptr %t1772 to i64
  %t1775 = inttoptr i64 %t1773 to ptr
  %t1776 = load ptr, ptr %l688, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t1775, ptr %s60, ptr %t1776, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d327, i32 0, i32 1) })
  br label %bb295
bb295:
  %t1777 = load ptr, ptr %l0, !tbaa !29
  %t1778 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t1779 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t1780 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t1782 = extractvalue { i64, ptr } %t1778, 1
  %t1783 = extractvalue { i64, ptr } %t1778, 0
  %t1784 = add i64 %t1780, %t1783
  %t1785 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t1786 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t1787 = add i64 %t1784, %t1786
  %t1788 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1787)
  call void @olang_textcopy(ptr %t1788, ptr %t1779, i64 %t1780)
  %t1789 = getelementptr i8, ptr %t1788, i64 %t1780
  call void @olang_textcopy(ptr %t1789, ptr %t1782, i64 %t1783)
  %t1790 = getelementptr i8, ptr %t1789, i64 %t1783
  call void @olang_textcopy(ptr %t1790, ptr %t1785, i64 %t1786)
  %t1791 = insertvalue { i64, ptr } undef, i64 %t1787, 0
  %t1792 = insertvalue { i64, ptr } %t1791, ptr %t1788, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s60, ptr %v2, ptr %t1777, { i64, ptr } %t1792)
  br label %bb296
bb296:
  call void @__olang_scope_close(ptr %s60)
  br label %bb338
bb297:
  %t1796 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1796, ptr %l694, !tbaa !29
  store i1 false, ptr %l695, !tbaa !21
  %t1797 = load ptr, ptr %l694, !tbaa !29
  %t1798 = icmp ne ptr %t1797, null
  br i1 %t1798, label %bb298, label %bb299
bb298:
  %t1800 = load ptr, ptr %l694, !tbaa !29
  %t1801 = load i64, ptr %t1800, !range !{i64 0, i64 20}
  %t1803 = icmp eq i64 %t1801, 11
  store i1 %t1803, ptr %l695, !tbaa !21
  br label %bb299
bb299:
  %t1804 = load i1, ptr %l695, !tbaa !21
  br i1 %t1804, label %bb300, label %bb301
bb300:
  %t1805 = load ptr, ptr %l1, !tbaa !29
  %t1807 = getelementptr { i64, [21 x i64] }, ptr %t1805, i32 0, i32 1
  %t1808 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1807, i32 0, i32 1
  %t1809 = load { i64, [1 x i64] }, ptr %t1808
  store { i64, [1 x i64] } %t1809, ptr %l57
  %t1811 = load ptr, ptr %l1, !tbaa !29
  %t1813 = getelementptr { i64, [21 x i64] }, ptr %t1811, i32 0, i32 1
  %t1814 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1813, i32 0, i32 2
  %t1815 = load i32, ptr %t1814, !range !{i32 0, i32 8}
  store i32 %t1815, ptr %l58
  %t1817 = load ptr, ptr %l1, !tbaa !29
  %t1819 = getelementptr { i64, [21 x i64] }, ptr %t1817, i32 0, i32 1
  %t1820 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1819, i32 0, i32 3
  %t1821 = load { i64, [4 x i64] }, ptr %t1820
  store { i64, [4 x i64] } %t1821, ptr %l59
  br label %bb302
bb301:
  br label %bb311
bb302:
  store %olang.scope zeroinitializer, ptr %s63
  %t1823 = load ptr, ptr %l0, !tbaa !29
  %t1824 = load { i64, [1 x i64] }, ptr %l57
  %t1827 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %t1823, { i64, [1 x i64] } %t1824)
  store i1 %t1827, ptr %l706
  br label %bb303
bb303:
  %t1828 = load i1, ptr %l706, !tbaa !21
  br i1 %t1828, label %bb304, label %bb305
bb304:
  %t1829 = load ptr, ptr %l0, !tbaa !29
  %t1831 = getelementptr %"compiler/emit:fnEm", ptr %t1829, i32 0, i32 27
  %t1832 = load i32, ptr %l58, !range !{i32 0, i32 8}
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2ePush_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %t1831, i32 %t1832)
  br label %bb306
bb305:
  br label %bb308
bb306:
  %t1835 = load ptr, ptr %l0, !tbaa !29
  %t1837 = getelementptr %"compiler/emit:fnEm", ptr %t1835, i32 0, i32 28
  %t1838 = load { i64, [4 x i64] }, ptr %l59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t1837, { i64, [4 x i64] } %t1838)
  br label %bb307
bb307:
  call void @__olang_scope_close(ptr %s63)
  br label %ret
bb308:
  %t1841 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1841, ptr %l713, !tbaa !29
  %t1842 = load ptr, ptr %l0, !tbaa !29
  %t1843 = load { i64, [1 x i64] }, ptr %l57
  %t1846 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s63, ptr %v2, ptr %v3, ptr %t1842, { i64, [1 x i64] } %t1843)
  store { i64, ptr } %t1846, ptr %l716
  br label %bb309
bb309:
  %t1847 = load { i64, ptr }, ptr %l716, !tbaa !27
  %t1848 = load i32, ptr %l58, !range !{i32 0, i32 8}
  %t1849 = load { i64, [4 x i64] }, ptr %l59
  %t1850 = load ptr, ptr %l713, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewrite(ptr %v0, ptr %s63, ptr %v3, ptr %v2, ptr %t1850, { i64, ptr } %t1847, i32 %t1848, { i64, [4 x i64] } %t1849)
  br label %bb310
bb310:
  call void @__olang_scope_close(ptr %s63)
  br label %bb338
bb311:
  %t1854 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1854, ptr %l720, !tbaa !29
  store i1 false, ptr %l721, !tbaa !21
  %t1855 = load ptr, ptr %l720, !tbaa !29
  %t1856 = icmp ne ptr %t1855, null
  br i1 %t1856, label %bb312, label %bb313
bb312:
  %t1858 = load ptr, ptr %l720, !tbaa !29
  %t1859 = load i64, ptr %t1858, !range !{i64 0, i64 20}
  %t1861 = icmp eq i64 %t1859, 12
  store i1 %t1861, ptr %l721, !tbaa !21
  br label %bb313
bb313:
  %t1862 = load i1, ptr %l721, !tbaa !21
  br i1 %t1862, label %bb314, label %bb315
bb314:
  %t1863 = load ptr, ptr %l1, !tbaa !29
  %t1865 = getelementptr { i64, [21 x i64] }, ptr %t1863, i32 0, i32 1
  %t1866 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1865, i32 0, i32 1
  %t1867 = load %"compiler/mir:Lvalue", ptr %t1866
  store %"compiler/mir:Lvalue" %t1867, ptr %l60
  %t1869 = load ptr, ptr %l1, !tbaa !29
  %t1871 = getelementptr { i64, [21 x i64] }, ptr %t1869, i32 0, i32 1
  %t1872 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1871, i32 0, i32 2
  %t1873 = load %"compiler/mir:Lvalue", ptr %t1872
  store %"compiler/mir:Lvalue" %t1873, ptr %l61
  %t1875 = load ptr, ptr %l1, !tbaa !29
  %t1877 = getelementptr { i64, [21 x i64] }, ptr %t1875, i32 0, i32 1
  %t1878 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1877, i32 0, i32 3
  %t1879 = load { i64, [4 x i64] }, ptr %t1878
  store { i64, [4 x i64] } %t1879, ptr %l62
  br label %bb316
bb315:
  br label %bb329
bb316:
  store %olang.scope zeroinitializer, ptr %s65
  %t1881 = load ptr, ptr %l0, !tbaa !29
  %t1882 = load %"compiler/mir:Lvalue", ptr %l60
  %t1885 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s65, ptr %v3, ptr %v2, ptr %t1881, %"compiler/mir:Lvalue" %t1882)
  store { i64, ptr } %t1885, ptr %l732
  br label %bb317
bb317:
  %t1886 = load { i64, ptr }, ptr %l732, !tbaa !27
  store { i64, ptr } %t1886, ptr %l63, !tbaa !27
  %t1887 = load ptr, ptr %l0, !tbaa !29
  %t1888 = load %"compiler/mir:Lvalue", ptr %l61
  %t1891 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s65, ptr %v3, ptr %v2, ptr %t1887, %"compiler/mir:Lvalue" %t1888)
  store { i64, ptr } %t1891, ptr %l735
  br label %bb318
bb318:
  %t1892 = load { i64, ptr }, ptr %l735, !tbaa !27
  store { i64, ptr } %t1892, ptr %l64, !tbaa !27
  %t1893 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1893, ptr %l736, !tbaa !29
  %t1894 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1894, ptr %l737, !tbaa !29
  %t1895 = load ptr, ptr %l0, !tbaa !29
  %t1896 = load %"compiler/mir:Lvalue", ptr %l60
  %t1899 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %v3, ptr %v2, ptr %t1895, %"compiler/mir:Lvalue" %t1896)
  store i32 %t1899, ptr %l740
  br label %bb319
bb319:
  %t1900 = load ptr, ptr %l737, !tbaa !29
  %t1901 = load i32, ptr %l740, !tbaa !23
  %t1902 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %v2, ptr %t1900, i32 %t1901)
  store i32 %t1902, ptr %l741
  br label %bb320
bb320:
  %t1903 = load ptr, ptr %l736, !tbaa !29
  %t1904 = call ptr @__olang_scope_or(ptr %v2, ptr %t1903)
  %t1905 = call ptr @__olang_scope_hold(ptr %t1904)
  %t1906 = ptrtoint ptr %t1905 to i64
  %t1908 = inttoptr i64 %t1906 to ptr
  %t1909 = load ptr, ptr %l736, !tbaa !29
  %t1910 = load i32, ptr %l741, !tbaa !23
  %t1911 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t1908, ptr %t1909, i32 %t1910)
  store i32 %t1911, ptr %l743
  br label %bb321
bb321:
  %t1912 = load i32, ptr %l743, !tbaa !23
  store i32 %t1912, ptr %l65, !tbaa !23
  %t1913 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1913, ptr %l744, !tbaa !29
  %t1914 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1914, ptr %l745, !tbaa !29
  %t1915 = load ptr, ptr %l0, !tbaa !29
  %t1916 = load { i64, [4 x i64] }, ptr %l62
  %t1917 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1921 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s65, ptr %v3, ptr %v2, ptr %t1915, { i64, [4 x i64] } %t1916, i32 %t1917)
  store { i64, ptr } %t1921, ptr %l749
  br label %bb322
bb322:
  %t1922 = load { i64, ptr }, ptr %l749, !tbaa !27
  store { i64, ptr } %t1922, ptr %l750, !tbaa !27
  %t1923 = load ptr, ptr %l0, !tbaa !29
  %t1924 = load { i64, [4 x i64] }, ptr %l62
  %t1927 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v3, ptr %v2, ptr %t1923, { i64, [4 x i64] } %t1924)
  store i32 %t1927, ptr %l753
  br label %bb323
bb323:
  %t1928 = load ptr, ptr %l745, !tbaa !29
  %t1929 = load { i64, ptr }, ptr %l750, !tbaa !27
  %t1930 = load i32, ptr %l753, !tbaa !23
  %t1931 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s65, ptr %s65, ptr %v2, ptr %t1928, { i64, ptr } %t1929, i32 %t1930)
  store { i64, ptr } %t1931, ptr %l754
  br label %bb324
bb324:
  %t1932 = load ptr, ptr %l0, !tbaa !29
  %t1933 = load i32, ptr %l65, !tbaa !23
  %t1936 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v2, ptr %t1932, i32 %t1933)
  store i64 %t1936, ptr %l757
  br label %bb325
bb325:
  %t1937 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t1938 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t1939 = load { i64, ptr }, ptr %l754, !tbaa !27
  %t1940 = extractvalue { i64, ptr } %t1939, 1
  %t1941 = extractvalue { i64, ptr } %t1939, 0
  %t1942 = add i64 %t1938, %t1941
  %t1943 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t1944 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t1945 = add i64 %t1942, %t1944
  %t1946 = load i64, ptr %l757, !tbaa !24
  %t1947 = call i64 @__olang_fmt_i64(ptr null, i64 %t1946)
  %t1948 = add i64 %t1945, %t1947
  %t1949 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1948)
  call void @olang_textcopy(ptr %t1949, ptr %t1937, i64 %t1938)
  %t1950 = getelementptr i8, ptr %t1949, i64 %t1938
  call void @olang_textcopy(ptr %t1950, ptr %t1940, i64 %t1941)
  %t1951 = getelementptr i8, ptr %t1950, i64 %t1941
  call void @olang_textcopy(ptr %t1951, ptr %t1943, i64 %t1944)
  %t1952 = getelementptr i8, ptr %t1951, i64 %t1944
  %t1953 = call i64 @__olang_fmt_i64(ptr %t1952, i64 %t1946)
  %t1954 = insertvalue { i64, ptr } undef, i64 %t1948, 0
  %t1955 = insertvalue { i64, ptr } %t1954, ptr %t1949, 1
  %t1957 = load ptr, ptr %l744, !tbaa !29
  %t1959 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s65, ptr %s65, ptr %v2, ptr %t1957, { i64, ptr } %t1955)
  store { i64, ptr } %t1959, ptr %l760
  br label %bb326
bb326:
  %t1960 = load { i64, ptr }, ptr %l760, !tbaa !27
  store { i64, ptr } %t1960, ptr %l66, !tbaa !27
  %t1961 = load ptr, ptr %l0, !tbaa !29
  %t1963 = getelementptr %"compiler/emit:fnEm", ptr %t1961, i32 0, i32 0
  %t1964 = load ptr, ptr %t1963, !tbaa !29
  store ptr %t1964, ptr %l762, !tbaa !29
  %t1965 = load ptr, ptr %l762, !tbaa !29
  %t1966 = call ptr @__olang_scope_or(ptr %v2, ptr %t1965)
  %t1967 = call ptr @__olang_scope_hold(ptr %t1966)
  %t1968 = ptrtoint ptr %t1967 to i64
  %t1970 = inttoptr i64 %t1968 to ptr
  %t1971 = load ptr, ptr %l762, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t1970, ptr %s65, ptr %s65, ptr %t1971, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d332, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d333, i32 0, i32 1) })
  br label %bb327
bb327:
  %t1972 = load ptr, ptr %l0, !tbaa !29
  %t1973 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t1974 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t1975 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1976 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t1977 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t1979 = extractvalue { i64, ptr } %t1973, 1
  %t1980 = extractvalue { i64, ptr } %t1973, 0
  %t1981 = add i64 %t1977, %t1980
  %t1982 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t1983 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t1984 = add i64 %t1981, %t1983
  %t1986 = extractvalue { i64, ptr } %t1974, 1
  %t1987 = extractvalue { i64, ptr } %t1974, 0
  %t1988 = add i64 %t1984, %t1987
  %t1989 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t1990 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  %t1991 = add i64 %t1988, %t1990
  %t1993 = extractvalue { i64, ptr } %t1975, 1
  %t1994 = extractvalue { i64, ptr } %t1975, 0
  %t1995 = add i64 %t1991, %t1994
  %t1996 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t1997 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  %t1998 = add i64 %t1995, %t1997
  %t1999 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1998)
  call void @olang_textcopy(ptr %t1999, ptr %t1976, i64 %t1977)
  %t2000 = getelementptr i8, ptr %t1999, i64 %t1977
  call void @olang_textcopy(ptr %t2000, ptr %t1979, i64 %t1980)
  %t2001 = getelementptr i8, ptr %t2000, i64 %t1980
  call void @olang_textcopy(ptr %t2001, ptr %t1982, i64 %t1983)
  %t2002 = getelementptr i8, ptr %t2001, i64 %t1983
  call void @olang_textcopy(ptr %t2002, ptr %t1986, i64 %t1987)
  %t2003 = getelementptr i8, ptr %t2002, i64 %t1987
  call void @olang_textcopy(ptr %t2003, ptr %t1989, i64 %t1990)
  %t2004 = getelementptr i8, ptr %t2003, i64 %t1990
  call void @olang_textcopy(ptr %t2004, ptr %t1993, i64 %t1994)
  %t2005 = getelementptr i8, ptr %t2004, i64 %t1994
  call void @olang_textcopy(ptr %t2005, ptr %t1996, i64 %t1997)
  %t2006 = insertvalue { i64, ptr } undef, i64 %t1998, 0
  %t2007 = insertvalue { i64, ptr } %t2006, ptr %t1999, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s65, ptr %v2, ptr %t1972, { i64, ptr } %t2007)
  br label %bb328
bb328:
  call void @__olang_scope_close(ptr %s65)
  br label %bb338
bb329:
  %t2011 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2011, ptr %l770, !tbaa !29
  store i1 false, ptr %l771, !tbaa !21
  %t2012 = load ptr, ptr %l770, !tbaa !29
  %t2013 = icmp ne ptr %t2012, null
  br i1 %t2013, label %bb330, label %bb331
bb330:
  %t2015 = load ptr, ptr %l770, !tbaa !29
  %t2016 = load i64, ptr %t2015, !range !{i64 0, i64 20}
  %t2018 = icmp eq i64 %t2016, 13
  store i1 %t2018, ptr %l771, !tbaa !21
  br label %bb331
bb331:
  %t2019 = load i1, ptr %l771, !tbaa !21
  br i1 %t2019, label %bb332, label %bb333
bb332:
  %t2020 = load ptr, ptr %l1, !tbaa !29
  %t2022 = getelementptr { i64, [21 x i64] }, ptr %t2020, i32 0, i32 1
  %t2023 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t2022, i32 0, i32 1
  %t2024 = load i32, ptr %t2023
  store i32 %t2024, ptr %l67, !tbaa !23
  %t2026 = load ptr, ptr %l1, !tbaa !29
  %t2028 = getelementptr { i64, [21 x i64] }, ptr %t2026, i32 0, i32 1
  %t2029 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t2028, i32 0, i32 2
  %t2030 = load i32, ptr %t2029
  store i32 %t2030, ptr %l68, !tbaa !23
  br label %bb334
bb333:
  br label %bb337
bb334:
  %t2032 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2032, ptr %l778, !tbaa !29
  %t2033 = load i32, ptr %l67, !tbaa !23
  store i32 %t2033, ptr %l779, !tbaa !23
  %t2034 = load ptr, ptr %l0, !tbaa !29
  %t2036 = getelementptr %"compiler/emit:fnEm", ptr %t2034, i32 0, i32 1
  %t2037 = load ptr, ptr %t2036, !tbaa !29
  %t2039 = getelementptr %"compiler/mir:Fn", ptr %t2037, i32 0, i32 16
  store ptr %t2039, ptr %l782, !tbaa !29
  %t2040 = load i32, ptr %l68, !tbaa !23
  %t2042 = sext i32 %t2040 to i64
  %t2043 = load ptr, ptr %l782, !tbaa !29
  %t2044 = call ptr @__olang_scope_or(ptr %v3, ptr %t2043)
  %t2045 = call ptr @__olang_scope_hold(ptr %t2044)
  %t2046 = ptrtoint ptr %t2045 to i64
  %t2049 = inttoptr i64 %t2046 to ptr
  %t2050 = load ptr, ptr %l782, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t2047, ptr %t2049, ptr %t2050, i64 %t2042)
  call void @llvm.memmove.p0.p0.i64(ptr %l786, ptr %t2047, i64 144, i1 false)
  br label %bb335
bb335:
  %t2052 = load ptr, ptr %l778, !tbaa !29
  %t2053 = load i32, ptr %l779, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %t2054, ptr %l786, i64 144, i1 false)
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %v2, ptr %v3, ptr %t2052, i32 %t2053, ptr %t2054)
  br label %bb336
bb336:
  br label %bb338
bb337:
  call void @__olang_check_failed(ptr @olang_loc_73cacc8093766858_2881ed4d4d5af0d4)
  unreachable
bb338:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Task"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l28 = alloca i32
  %l31 = alloca i32
  %l50 = alloca %"compiler/mir:Task"
  %l53 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca ptr
  %l66 = alloca %"compiler/mir:Lvalue"
  %l67 = alloca i32
  %l69 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca ptr
  %l78 = alloca i1
  %l79 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l117 = alloca i64
  %l143 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l150 = alloca i64
  %l153 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l157 = alloca ptr
  %l161 = alloca { i64, ptr }
  %l176 = alloca ptr
  %l177 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t66 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 144, i1 false)
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  store i32 0, ptr %l8, !tbaa !23
  %t11 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l9, !tbaa !23
  store i32 1, ptr %l10, !tbaa !23
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = load i32, ptr %l8, !tbaa !23
  %t19 = icmp sgt i32 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i32, ptr %l10, !tbaa !23
  %t23 = icmp sgt i32 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l28, !tbaa !23
  br label %bb6
bb3:
  %t25 = load i32, ptr %l9, !tbaa !23
  %t26 = load i32, ptr %l8, !tbaa !23
  %t29 = sub i32 %t25, %t26
  %t30 = load i32, ptr %l10, !tbaa !23
  %t33 = add i32 %t29, %t30
  %t35 = sub i32 %t33, 1
  %t36 = load i32, ptr %l10, !tbaa !23
  %t39 = sdiv i32 %t35, %t36
  store i32 %t39, ptr %l31, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l31, !tbaa !23
  br label %bb5
bb5:
  %t41 = load i32, ptr %l31, !tbaa !23
  store i32 %t41, ptr %l28, !tbaa !23
  br label %bb6
bb6:
  %t42 = load i32, ptr %l28, !tbaa !23
  store i32 %t42, ptr %l11, !tbaa !23
  store i32 0, ptr %l12, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i32, ptr %l12, !tbaa !23
  %t44 = load i32, ptr %l11, !tbaa !23
  %t47 = icmp slt i32 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb9:
  br label %bb10
bb10:
  %t51 = load i32, ptr %l8, !tbaa !23
  %t52 = load i32, ptr %l12, !tbaa !23
  %t53 = load i32, ptr %l10, !tbaa !23
  %t56 = mul i32 %t52, %t53
  %t59 = add i32 %t51, %t56
  store i32 %t59, ptr %l13, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %l2, i64 144, i1 false)
  %t62 = load i32, ptr %l13, !tbaa !23
  %t64 = sext i32 %t62 to i64
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %l50, i64 144, i1 false)
  %t68 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %v4, ptr %v5, ptr %t61, ptr %t66, i64 %t64)
  store i1 %t68, ptr %l53
  br label %bb11
bb11:
  %t69 = load i1, ptr %l53, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l7, !tbaa !29
  store ptr %t72, ptr %l55, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l56, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:fnEm", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 13
  store ptr %t79, ptr %l59, !tbaa !29
  %t80 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t81 = getelementptr %"compiler/mir:Range", ptr %t80, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = sext i32 %t82 to i64
  %t85 = load i32, ptr %l13, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t90 = add i64 %t84, %t87
  %t91 = load ptr, ptr %l59, !tbaa !29
  %t92 = call ptr @__olang_scope_or(ptr %v4, ptr %t91)
  %t93 = call ptr @__olang_scope_hold(ptr %t92)
  %t94 = ptrtoint ptr %t93 to i64
  %t96 = inttoptr i64 %t94 to ptr
  %t97 = load ptr, ptr %l59, !tbaa !29
  %t99 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %t96, ptr %t97, i64 %t90)
  store %"compiler/mir:Lvalue" %t99, ptr %l66
  br label %bb15
bb15:
  %t100 = load ptr, ptr %l56, !tbaa !29
  %t101 = load %"compiler/mir:Lvalue", ptr %l66
  %t102 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %v4, ptr %v5, ptr %t100, %"compiler/mir:Lvalue" %t101)
  store i32 %t102, ptr %l67
  br label %bb16
bb16:
  %t103 = load ptr, ptr %l55, !tbaa !29
  %t104 = call ptr @__olang_scope_or(ptr %v5, ptr %t103)
  %t105 = call ptr @__olang_scope_hold(ptr %t104)
  %t106 = ptrtoint ptr %t105 to i64
  %t108 = inttoptr i64 %t106 to ptr
  %t109 = load ptr, ptr %l55, !tbaa !29
  %t110 = load i32, ptr %l67, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t108, ptr %t109, i32 %t110)
  store i32 %t111, ptr %l69
  br label %bb17
bb17:
  %t112 = load i32, ptr %l69, !tbaa !23
  %t113 = load ptr, ptr %l7, !tbaa !29
  store ptr %t113, ptr %l70, !tbaa !29
  %t115 = load ptr, ptr %l70, !tbaa !29
  %t116 = call ptr @__olang_scope_or(ptr %v5, ptr %t115)
  %t117 = call ptr @__olang_scope_hold(ptr %t116)
  %t118 = ptrtoint ptr %t117 to i64
  %t120 = inttoptr i64 %t118 to ptr
  %t121 = load ptr, ptr %l70, !tbaa !29
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t120, ptr %t121, i32 %t112)
  store i32 %t123, ptr %l73
  br label %bb18
bb18:
  %t124 = load i32, ptr %l73, !tbaa !23
  store i32 %t124, ptr %l15, !tbaa !23
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = getelementptr %"compiler/emit:Emitter", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l75, !tbaa !29
  %t129 = load i32, ptr %l15, !tbaa !23
  %t130 = load ptr, ptr %l75, !tbaa !29
  %t131 = call ptr @__olang_scope_or(ptr %v5, ptr %t130)
  %t132 = call ptr @__olang_scope_hold(ptr %t131)
  %t133 = ptrtoint ptr %t132 to i64
  %t135 = inttoptr i64 %t133 to ptr
  %t136 = load ptr, ptr %l75, !tbaa !29
  %t138 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %t135, ptr %t136, i32 %t129)
  store i1 %t138, ptr %l78
  br label %bb19
bb19:
  %t139 = load ptr, ptr %l6, !tbaa !29
  store ptr %t139, ptr %l79, !tbaa !29
  %t140 = load ptr, ptr %l79, !tbaa !29
  %t141 = call ptr @__olang_scope_or(ptr %v5, ptr %t140)
  %t142 = call ptr @__olang_scope_hold(ptr %t141)
  %t143 = ptrtoint ptr %t142 to i64
  %t145 = inttoptr i64 %t143 to ptr
  %t146 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t145, ptr %s2, ptr %s2, ptr %t146, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d338, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d339, i32 0, i32 1) })
  br label %bb20
bb20:
  %t147 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t148 = load i32, ptr %l13, !tbaa !23
  %t149 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t152 = extractvalue { i64, ptr } %t147, 1
  %t153 = extractvalue { i64, ptr } %t147, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t159 = sext i32 %t148 to i64
  %t160 = call i64 @__olang_fmt_i64(ptr null, i64 %t159)
  %t161 = add i64 %t157, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t149, i64 %t150)
  %t163 = getelementptr i8, ptr %t162, i64 %t150
  call void @olang_textcopy(ptr %t163, ptr %t152, i64 %t153)
  %t164 = getelementptr i8, ptr %t163, i64 %t153
  call void @olang_textcopy(ptr %t164, ptr %t155, i64 %t156)
  %t165 = getelementptr i8, ptr %t164, i64 %t156
  %t166 = call i64 @__olang_fmt_i64(ptr %t165, i64 %t159)
  %t167 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t162, 1
  store { i64, ptr } %t168, ptr %l16, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t171 = load i32, ptr %l13, !tbaa !23
  %t172 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d342, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d342, i32 0, i32 1) }, 0
  %t175 = extractvalue { i64, ptr } %t170, 1
  %t176 = extractvalue { i64, ptr } %t170, 0
  %t177 = add i64 %t173, %t176
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t180 = add i64 %t177, %t179
  %t182 = sext i32 %t171 to i64
  %t183 = call i64 @__olang_fmt_i64(ptr null, i64 %t182)
  %t184 = add i64 %t180, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t172, i64 %t173)
  %t186 = getelementptr i8, ptr %t185, i64 %t173
  call void @olang_textcopy(ptr %t186, ptr %t175, i64 %t176)
  %t187 = getelementptr i8, ptr %t186, i64 %t176
  call void @olang_textcopy(ptr %t187, ptr %t178, i64 %t179)
  %t188 = getelementptr i8, ptr %t187, i64 %t179
  %t189 = call i64 @__olang_fmt_i64(ptr %t188, i64 %t182)
  %t190 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t185, 1
  store { i64, ptr } %t191, ptr %l17, !tbaa !27
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t196 = load i32, ptr %l13, !tbaa !23
  %t198 = sext i32 %t196 to i64
  %t201 = add i64 %a3, %t198
  %t202 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t204 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t207 = extractvalue { i64, ptr } %t194, 1
  %t208 = extractvalue { i64, ptr } %t194, 0
  %t209 = add i64 %t205, %t208
  %t210 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t212 = add i64 %t209, %t211
  %t214 = call i64 @__olang_fmt_i64(ptr null, i64 %t201)
  %t215 = add i64 %t212, %t214
  %t216 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d346, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d346, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t220 = extractvalue { i64, ptr } %t202, 1
  %t221 = extractvalue { i64, ptr } %t202, 0
  %t222 = add i64 %t218, %t221
  %t223 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t227 = extractvalue { i64, ptr } %t203, 1
  %t228 = extractvalue { i64, ptr } %t203, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t204, i64 %t205)
  %t234 = getelementptr i8, ptr %t233, i64 %t205
  call void @olang_textcopy(ptr %t234, ptr %t207, i64 %t208)
  %t235 = getelementptr i8, ptr %t234, i64 %t208
  call void @olang_textcopy(ptr %t235, ptr %t210, i64 %t211)
  %t236 = getelementptr i8, ptr %t235, i64 %t211
  %t237 = call i64 @__olang_fmt_i64(ptr %t236, i64 %t201)
  %t238 = getelementptr i8, ptr %t236, i64 %t214
  call void @olang_textcopy(ptr %t238, ptr %t216, i64 %t217)
  %t239 = getelementptr i8, ptr %t238, i64 %t217
  call void @olang_textcopy(ptr %t239, ptr %t220, i64 %t221)
  %t240 = getelementptr i8, ptr %t239, i64 %t221
  call void @olang_textcopy(ptr %t240, ptr %t223, i64 %t224)
  %t241 = getelementptr i8, ptr %t240, i64 %t224
  call void @olang_textcopy(ptr %t241, ptr %t227, i64 %t228)
  %t242 = getelementptr i8, ptr %t241, i64 %t228
  call void @olang_textcopy(ptr %t242, ptr %t230, i64 %t231)
  %t243 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t233, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t193, { i64, ptr } %t244)
  br label %bb21
bb21:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t253 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t256 = extractvalue { i64, ptr } %t249, 1
  %t257 = extractvalue { i64, ptr } %t249, 0
  %t258 = add i64 %t254, %t257
  %t259 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t263 = extractvalue { i64, ptr } %t250, 1
  %t264 = extractvalue { i64, ptr } %t250, 0
  %t265 = add i64 %t261, %t264
  %t266 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t268 = add i64 %t265, %t267
  %t270 = extractvalue { i64, ptr } %t251, 1
  %t271 = extractvalue { i64, ptr } %t251, 0
  %t272 = add i64 %t268, %t271
  %t273 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t275 = add i64 %t272, %t274
  %t277 = extractvalue { i64, ptr } %t252, 1
  %t278 = extractvalue { i64, ptr } %t252, 0
  %t279 = add i64 %t275, %t278
  %t280 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d353, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d353, i32 0, i32 1) }, 0
  %t282 = add i64 %t279, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t253, i64 %t254)
  %t284 = getelementptr i8, ptr %t283, i64 %t254
  call void @olang_textcopy(ptr %t284, ptr %t256, i64 %t257)
  %t285 = getelementptr i8, ptr %t284, i64 %t257
  call void @olang_textcopy(ptr %t285, ptr %t259, i64 %t260)
  %t286 = getelementptr i8, ptr %t285, i64 %t260
  call void @olang_textcopy(ptr %t286, ptr %t263, i64 %t264)
  %t287 = getelementptr i8, ptr %t286, i64 %t264
  call void @olang_textcopy(ptr %t287, ptr %t266, i64 %t267)
  %t288 = getelementptr i8, ptr %t287, i64 %t267
  call void @olang_textcopy(ptr %t288, ptr %t270, i64 %t271)
  %t289 = getelementptr i8, ptr %t288, i64 %t271
  call void @olang_textcopy(ptr %t289, ptr %t273, i64 %t274)
  %t290 = getelementptr i8, ptr %t289, i64 %t274
  call void @olang_textcopy(ptr %t290, ptr %t277, i64 %t278)
  %t291 = getelementptr i8, ptr %t290, i64 %t278
  call void @olang_textcopy(ptr %t291, ptr %t280, i64 %t281)
  %t292 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t283, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t248, { i64, ptr } %t293)
  br label %bb22
bb22:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t298 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t299 = load i32, ptr %l13, !tbaa !23
  %t300 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t301 = load i32, ptr %l13, !tbaa !23
  %t302 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t303 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t305 = extractvalue { i64, ptr } %t298, 1
  %t306 = extractvalue { i64, ptr } %t298, 0
  %t307 = add i64 %t303, %t306
  %t308 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t312 = sext i32 %t299 to i64
  %t313 = call i64 @__olang_fmt_i64(ptr null, i64 %t312)
  %t314 = add i64 %t310, %t313
  %t315 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t319 = extractvalue { i64, ptr } %t300, 1
  %t320 = extractvalue { i64, ptr } %t300, 0
  %t321 = add i64 %t317, %t320
  %t322 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t326 = sext i32 %t301 to i64
  %t327 = call i64 @__olang_fmt_i64(ptr null, i64 %t326)
  %t328 = add i64 %t324, %t327
  %t329 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t330 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t331 = add i64 %t328, %t330
  %t332 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t331)
  call void @olang_textcopy(ptr %t332, ptr %t302, i64 %t303)
  %t333 = getelementptr i8, ptr %t332, i64 %t303
  call void @olang_textcopy(ptr %t333, ptr %t305, i64 %t306)
  %t334 = getelementptr i8, ptr %t333, i64 %t306
  call void @olang_textcopy(ptr %t334, ptr %t308, i64 %t309)
  %t335 = getelementptr i8, ptr %t334, i64 %t309
  %t336 = call i64 @__olang_fmt_i64(ptr %t335, i64 %t312)
  %t337 = getelementptr i8, ptr %t335, i64 %t313
  call void @olang_textcopy(ptr %t337, ptr %t315, i64 %t316)
  %t338 = getelementptr i8, ptr %t337, i64 %t316
  call void @olang_textcopy(ptr %t338, ptr %t319, i64 %t320)
  %t339 = getelementptr i8, ptr %t338, i64 %t320
  call void @olang_textcopy(ptr %t339, ptr %t322, i64 %t323)
  %t340 = getelementptr i8, ptr %t339, i64 %t323
  %t341 = call i64 @__olang_fmt_i64(ptr %t340, i64 %t326)
  %t342 = getelementptr i8, ptr %t340, i64 %t327
  call void @olang_textcopy(ptr %t342, ptr %t329, i64 %t330)
  %t343 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t332, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t297, { i64, ptr } %t344)
  br label %bb23
bb23:
  %t348 = load ptr, ptr %l1, !tbaa !29
  store ptr %t348, ptr %l111, !tbaa !29
  %t349 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t349, ptr %l112, !tbaa !27
  %t350 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t350, ptr %l113, !tbaa !27
  %t351 = load ptr, ptr %l7, !tbaa !29
  store ptr %t351, ptr %l114, !tbaa !29
  %t352 = load i32, ptr %l15, !tbaa !23
  %t353 = load ptr, ptr %l114, !tbaa !29
  %t354 = call ptr @__olang_scope_or(ptr %v5, ptr %t353)
  %t355 = call ptr @__olang_scope_hold(ptr %t354)
  %t356 = ptrtoint ptr %t355 to i64
  %t358 = inttoptr i64 %t356 to ptr
  %t359 = load ptr, ptr %l114, !tbaa !29
  %t361 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %t358, ptr %t359, i32 %t352)
  store i64 %t361, ptr %l117
  br label %bb24
bb24:
  %t362 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t363 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t365 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t366 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t367 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 1
  %t369 = extractvalue { i64, ptr } %t367, 0
  %t370 = add i64 %t366, %t369
  %t371 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t372 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t373 = add i64 %t370, %t372
  %t374 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t378 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d361, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d361, i32 0, i32 1) }, 0
  %t380 = add i64 %t377, %t379
  %t381 = load i64, ptr %l117, !tbaa !24
  %t382 = call i64 @__olang_fmt_i64(ptr null, i64 %t381)
  %t383 = add i64 %t380, %t382
  %t384 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d362, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  %t386 = add i64 %t383, %t385
  %t388 = extractvalue { i64, ptr } %t362, 1
  %t389 = extractvalue { i64, ptr } %t362, 0
  %t390 = add i64 %t386, %t389
  %t391 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t393 = add i64 %t390, %t392
  %t395 = extractvalue { i64, ptr } %t363, 1
  %t396 = extractvalue { i64, ptr } %t363, 0
  %t397 = add i64 %t393, %t396
  %t398 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d361, i32 0, i32 1) }, 1
  %t399 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d361, i32 0, i32 1) }, 0
  %t400 = add i64 %t397, %t399
  %t402 = extractvalue { i64, ptr } %t364, 1
  %t403 = extractvalue { i64, ptr } %t364, 0
  %t404 = add i64 %t400, %t403
  %t405 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t406 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t407 = add i64 %t404, %t406
  %t408 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t407)
  call void @olang_textcopy(ptr %t408, ptr %t365, i64 %t366)
  %t409 = getelementptr i8, ptr %t408, i64 %t366
  call void @olang_textcopy(ptr %t409, ptr %t368, i64 %t369)
  %t410 = getelementptr i8, ptr %t409, i64 %t369
  call void @olang_textcopy(ptr %t410, ptr %t371, i64 %t372)
  %t411 = getelementptr i8, ptr %t410, i64 %t372
  call void @olang_textcopy(ptr %t411, ptr %t375, i64 %t376)
  %t412 = getelementptr i8, ptr %t411, i64 %t376
  call void @olang_textcopy(ptr %t412, ptr %t378, i64 %t379)
  %t413 = getelementptr i8, ptr %t412, i64 %t379
  %t414 = call i64 @__olang_fmt_i64(ptr %t413, i64 %t381)
  %t415 = getelementptr i8, ptr %t413, i64 %t382
  call void @olang_textcopy(ptr %t415, ptr %t384, i64 %t385)
  %t416 = getelementptr i8, ptr %t415, i64 %t385
  call void @olang_textcopy(ptr %t416, ptr %t388, i64 %t389)
  %t417 = getelementptr i8, ptr %t416, i64 %t389
  call void @olang_textcopy(ptr %t417, ptr %t391, i64 %t392)
  %t418 = getelementptr i8, ptr %t417, i64 %t392
  call void @olang_textcopy(ptr %t418, ptr %t395, i64 %t396)
  %t419 = getelementptr i8, ptr %t418, i64 %t396
  call void @olang_textcopy(ptr %t419, ptr %t398, i64 %t399)
  %t420 = getelementptr i8, ptr %t419, i64 %t399
  call void @olang_textcopy(ptr %t420, ptr %t402, i64 %t403)
  %t421 = getelementptr i8, ptr %t420, i64 %t403
  call void @olang_textcopy(ptr %t421, ptr %t405, i64 %t406)
  %t422 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t408, 1
  %t425 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t425, { i64, ptr } %t423)
  br label %bb25
bb25:
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t428 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t429 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t430 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t431 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t432 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t433 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t435 = extractvalue { i64, ptr } %t428, 1
  %t436 = extractvalue { i64, ptr } %t428, 0
  %t437 = add i64 %t433, %t436
  %t438 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d366, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d366, i32 0, i32 1) }, 0
  %t440 = add i64 %t437, %t439
  %t442 = extractvalue { i64, ptr } %t429, 1
  %t443 = extractvalue { i64, ptr } %t429, 0
  %t444 = add i64 %t440, %t443
  %t445 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t447 = add i64 %t444, %t446
  %t449 = extractvalue { i64, ptr } %t430, 1
  %t450 = extractvalue { i64, ptr } %t430, 0
  %t451 = add i64 %t447, %t450
  %t452 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t453 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t454 = add i64 %t451, %t453
  %t456 = extractvalue { i64, ptr } %t431, 1
  %t457 = extractvalue { i64, ptr } %t431, 0
  %t458 = add i64 %t454, %t457
  %t459 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t460 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t461 = add i64 %t458, %t460
  %t462 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t461)
  call void @olang_textcopy(ptr %t462, ptr %t432, i64 %t433)
  %t463 = getelementptr i8, ptr %t462, i64 %t433
  call void @olang_textcopy(ptr %t463, ptr %t435, i64 %t436)
  %t464 = getelementptr i8, ptr %t463, i64 %t436
  call void @olang_textcopy(ptr %t464, ptr %t438, i64 %t439)
  %t465 = getelementptr i8, ptr %t464, i64 %t439
  call void @olang_textcopy(ptr %t465, ptr %t442, i64 %t443)
  %t466 = getelementptr i8, ptr %t465, i64 %t443
  call void @olang_textcopy(ptr %t466, ptr %t445, i64 %t446)
  %t467 = getelementptr i8, ptr %t466, i64 %t446
  call void @olang_textcopy(ptr %t467, ptr %t449, i64 %t450)
  %t468 = getelementptr i8, ptr %t467, i64 %t450
  call void @olang_textcopy(ptr %t468, ptr %t452, i64 %t453)
  %t469 = getelementptr i8, ptr %t468, i64 %t453
  call void @olang_textcopy(ptr %t469, ptr %t456, i64 %t457)
  %t470 = getelementptr i8, ptr %t469, i64 %t457
  call void @olang_textcopy(ptr %t470, ptr %t459, i64 %t460)
  %t471 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t462, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t427, { i64, ptr } %t472)
  br label %bb26
bb26:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t477 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t479 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t480 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t481 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t483 = extractvalue { i64, ptr } %t477, 1
  %t484 = extractvalue { i64, ptr } %t477, 0
  %t485 = add i64 %t481, %t484
  %t486 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t487 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t488 = add i64 %t485, %t487
  %t490 = extractvalue { i64, ptr } %t478, 1
  %t491 = extractvalue { i64, ptr } %t478, 0
  %t492 = add i64 %t488, %t491
  %t493 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t494 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t495 = add i64 %t492, %t494
  %t497 = extractvalue { i64, ptr } %t479, 1
  %t498 = extractvalue { i64, ptr } %t479, 0
  %t499 = add i64 %t495, %t498
  %t500 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t501 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t502 = add i64 %t499, %t501
  %t503 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t502)
  call void @olang_textcopy(ptr %t503, ptr %t480, i64 %t481)
  %t504 = getelementptr i8, ptr %t503, i64 %t481
  call void @olang_textcopy(ptr %t504, ptr %t483, i64 %t484)
  %t505 = getelementptr i8, ptr %t504, i64 %t484
  call void @olang_textcopy(ptr %t505, ptr %t486, i64 %t487)
  %t506 = getelementptr i8, ptr %t505, i64 %t487
  call void @olang_textcopy(ptr %t506, ptr %t490, i64 %t491)
  %t507 = getelementptr i8, ptr %t506, i64 %t491
  call void @olang_textcopy(ptr %t507, ptr %t493, i64 %t494)
  %t508 = getelementptr i8, ptr %t507, i64 %t494
  call void @olang_textcopy(ptr %t508, ptr %t497, i64 %t498)
  %t509 = getelementptr i8, ptr %t508, i64 %t498
  call void @olang_textcopy(ptr %t509, ptr %t500, i64 %t501)
  %t510 = insertvalue { i64, ptr } undef, i64 %t502, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t503, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t476, { i64, ptr } %t511)
  br label %bb27
bb27:
  %t515 = load ptr, ptr %l1, !tbaa !29
  %t516 = load i32, ptr %l13, !tbaa !23
  %t517 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t518 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t519 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t520 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d374, i32 0, i32 1) }, 1
  %t521 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d374, i32 0, i32 1) }, 0
  %t523 = sext i32 %t516 to i64
  %t524 = call i64 @__olang_fmt_i64(ptr null, i64 %t523)
  %t525 = add i64 %t521, %t524
  %t526 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t527 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t528 = add i64 %t525, %t527
  %t530 = extractvalue { i64, ptr } %t517, 1
  %t531 = extractvalue { i64, ptr } %t517, 0
  %t532 = add i64 %t528, %t531
  %t533 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t534 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t535 = add i64 %t532, %t534
  %t537 = extractvalue { i64, ptr } %t518, 1
  %t538 = extractvalue { i64, ptr } %t518, 0
  %t539 = add i64 %t535, %t538
  %t540 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d377, i32 0, i32 1) }, 1
  %t541 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d377, i32 0, i32 1) }, 0
  %t542 = add i64 %t539, %t541
  %t544 = extractvalue { i64, ptr } %t519, 1
  %t545 = extractvalue { i64, ptr } %t519, 0
  %t546 = add i64 %t542, %t545
  %t547 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d378, i32 0, i32 1) }, 1
  %t548 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d378, i32 0, i32 1) }, 0
  %t549 = add i64 %t546, %t548
  %t550 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t549)
  call void @olang_textcopy(ptr %t550, ptr %t520, i64 %t521)
  %t551 = getelementptr i8, ptr %t550, i64 %t521
  %t552 = call i64 @__olang_fmt_i64(ptr %t551, i64 %t523)
  %t553 = getelementptr i8, ptr %t551, i64 %t524
  call void @olang_textcopy(ptr %t553, ptr %t526, i64 %t527)
  %t554 = getelementptr i8, ptr %t553, i64 %t527
  call void @olang_textcopy(ptr %t554, ptr %t530, i64 %t531)
  %t555 = getelementptr i8, ptr %t554, i64 %t531
  call void @olang_textcopy(ptr %t555, ptr %t533, i64 %t534)
  %t556 = getelementptr i8, ptr %t555, i64 %t534
  call void @olang_textcopy(ptr %t556, ptr %t537, i64 %t538)
  %t557 = getelementptr i8, ptr %t556, i64 %t538
  call void @olang_textcopy(ptr %t557, ptr %t540, i64 %t541)
  %t558 = getelementptr i8, ptr %t557, i64 %t541
  call void @olang_textcopy(ptr %t558, ptr %t544, i64 %t545)
  %t559 = getelementptr i8, ptr %t558, i64 %t545
  call void @olang_textcopy(ptr %t559, ptr %t547, i64 %t548)
  %t560 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t550, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t515, { i64, ptr } %t561)
  br label %bb28
bb28:
  %t565 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t565, ptr %l143, !tbaa !27
  %t566 = load i32, ptr %l13, !tbaa !23
  %t568 = sext i32 %t566 to i64
  %t569 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t570 = load ptr, ptr %t569, !tbaa !27
  %t571 = getelementptr i64, ptr %t570, i64 %t568
  %t572 = load i64, ptr %t571, !tbaa !34
  %t574 = icmp sge i64 %t572, 0
  br i1 %t574, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s13
  %t576 = load ptr, ptr %l7, !tbaa !29
  store ptr %t576, ptr %l147, !tbaa !29
  %t577 = load i32, ptr %l15, !tbaa !23
  %t578 = load ptr, ptr %l147, !tbaa !29
  %t579 = call ptr @__olang_scope_or(ptr %v5, ptr %t578)
  %t580 = call ptr @__olang_scope_hold(ptr %t579)
  %t581 = ptrtoint ptr %t580 to i64
  %t583 = inttoptr i64 %t581 to ptr
  %t584 = load ptr, ptr %l147, !tbaa !29
  %t586 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %t583, ptr %t584, i32 %t577)
  store i64 %t586, ptr %l150
  br label %bb31
bb30:
  br label %bb46
bb31:
  %t587 = load i64, ptr %l150, !tbaa !24
  store i64 %t587, ptr %l18, !tbaa !24
  %t588 = load i64, ptr %l18, !tbaa !24
  %t590 = icmp sgt i64 %t588, 8
  br i1 %t590, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d379, i32 0, i32 1) }, ptr %l153, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d380, i32 0, i32 1) }, ptr %l153, !tbaa !27
  br label %bb34
bb34:
  %t592 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t592, ptr %l19, !tbaa !27
  %t593 = load ptr, ptr %l6, !tbaa !29
  store ptr %t593, ptr %l154, !tbaa !29
  %t594 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t595 = load ptr, ptr %l154, !tbaa !29
  %t596 = call ptr @__olang_scope_or(ptr %v5, ptr %t595)
  %t597 = call ptr @__olang_scope_hold(ptr %t596)
  %t598 = ptrtoint ptr %t597 to i64
  %t600 = inttoptr i64 %t598 to ptr
  %t601 = load ptr, ptr @__olang_prog_scope
  %t602 = load ptr, ptr %l154, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t600, ptr %t601, ptr %t602, { i64, ptr } %t594)
  br label %bb35
bb35:
  %t604 = load ptr, ptr %l6, !tbaa !29
  store ptr %t604, ptr %l157, !tbaa !29
  %t605 = load ptr, ptr %l157, !tbaa !29
  %t606 = call ptr @__olang_scope_or(ptr %v5, ptr %t605)
  %t607 = call ptr @__olang_scope_hold(ptr %t606)
  %t608 = ptrtoint ptr %t607 to i64
  %t610 = inttoptr i64 %t608 to ptr
  %t611 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %t610, ptr %s13, ptr %s13, ptr %t611, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d381, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d382, i32 0, i32 1) })
  br label %bb36
bb36:
  %t612 = load ptr, ptr %l1, !tbaa !29
  %t613 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t614, ptr %l161, !tbaa !27
  %t615 = load i32, ptr %l13, !tbaa !23
  %t617 = sext i32 %t615 to i64
  %t618 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t619 = load ptr, ptr %t618, !tbaa !27
  %t620 = getelementptr i64, ptr %t619, i64 %t617
  %t621 = load i64, ptr %t620, !tbaa !34
  %t622 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t623 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t624 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t625 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t627 = extractvalue { i64, ptr } %t613, 1
  %t628 = extractvalue { i64, ptr } %t613, 0
  %t629 = add i64 %t625, %t628
  %t630 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t631 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t632 = add i64 %t629, %t631
  %t634 = call i64 @__olang_fmt_i64(ptr null, i64 %t621)
  %t635 = add i64 %t632, %t634
  %t636 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d385, i32 0, i32 1) }, 1
  %t637 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d385, i32 0, i32 1) }, 0
  %t638 = add i64 %t635, %t637
  %t640 = extractvalue { i64, ptr } %t622, 1
  %t641 = extractvalue { i64, ptr } %t622, 0
  %t642 = add i64 %t638, %t641
  %t643 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t644 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t645 = add i64 %t642, %t644
  %t647 = extractvalue { i64, ptr } %t623, 1
  %t648 = extractvalue { i64, ptr } %t623, 0
  %t649 = add i64 %t645, %t648
  %t650 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t651 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t652 = add i64 %t649, %t651
  %t653 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t652)
  call void @olang_textcopy(ptr %t653, ptr %t624, i64 %t625)
  %t654 = getelementptr i8, ptr %t653, i64 %t625
  call void @olang_textcopy(ptr %t654, ptr %t627, i64 %t628)
  %t655 = getelementptr i8, ptr %t654, i64 %t628
  call void @olang_textcopy(ptr %t655, ptr %t630, i64 %t631)
  %t656 = getelementptr i8, ptr %t655, i64 %t631
  %t657 = call i64 @__olang_fmt_i64(ptr %t656, i64 %t621)
  %t658 = getelementptr i8, ptr %t656, i64 %t634
  call void @olang_textcopy(ptr %t658, ptr %t636, i64 %t637)
  %t659 = getelementptr i8, ptr %t658, i64 %t637
  call void @olang_textcopy(ptr %t659, ptr %t640, i64 %t641)
  %t660 = getelementptr i8, ptr %t659, i64 %t641
  call void @olang_textcopy(ptr %t660, ptr %t643, i64 %t644)
  %t661 = getelementptr i8, ptr %t660, i64 %t644
  call void @olang_textcopy(ptr %t661, ptr %t647, i64 %t648)
  %t662 = getelementptr i8, ptr %t661, i64 %t648
  call void @olang_textcopy(ptr %t662, ptr %t650, i64 %t651)
  %t663 = insertvalue { i64, ptr } undef, i64 %t652, 0
  %t664 = insertvalue { i64, ptr } %t663, ptr %t653, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t612, { i64, ptr } %t664)
  br label %bb37
bb37:
  %t668 = load ptr, ptr %l1, !tbaa !29
  %t669 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t670 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t671 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t672 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t673 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t674 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t675 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t677 = extractvalue { i64, ptr } %t669, 1
  %t678 = extractvalue { i64, ptr } %t669, 0
  %t679 = add i64 %t675, %t678
  %t680 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t681 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t682 = add i64 %t679, %t681
  %t684 = extractvalue { i64, ptr } %t670, 1
  %t685 = extractvalue { i64, ptr } %t670, 0
  %t686 = add i64 %t682, %t685
  %t687 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t688 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t689 = add i64 %t686, %t688
  %t691 = extractvalue { i64, ptr } %t671, 1
  %t692 = extractvalue { i64, ptr } %t671, 0
  %t693 = add i64 %t689, %t692
  %t694 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t695 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t696 = add i64 %t693, %t695
  %t698 = extractvalue { i64, ptr } %t672, 1
  %t699 = extractvalue { i64, ptr } %t672, 0
  %t700 = add i64 %t696, %t699
  %t701 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t702 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t703 = add i64 %t700, %t702
  %t705 = extractvalue { i64, ptr } %t673, 1
  %t706 = extractvalue { i64, ptr } %t673, 0
  %t707 = add i64 %t703, %t706
  %t708 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t709 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t710 = add i64 %t707, %t709
  %t711 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t710)
  call void @olang_textcopy(ptr %t711, ptr %t674, i64 %t675)
  %t712 = getelementptr i8, ptr %t711, i64 %t675
  call void @olang_textcopy(ptr %t712, ptr %t677, i64 %t678)
  %t713 = getelementptr i8, ptr %t712, i64 %t678
  call void @olang_textcopy(ptr %t713, ptr %t680, i64 %t681)
  %t714 = getelementptr i8, ptr %t713, i64 %t681
  call void @olang_textcopy(ptr %t714, ptr %t684, i64 %t685)
  %t715 = getelementptr i8, ptr %t714, i64 %t685
  call void @olang_textcopy(ptr %t715, ptr %t687, i64 %t688)
  %t716 = getelementptr i8, ptr %t715, i64 %t688
  call void @olang_textcopy(ptr %t716, ptr %t691, i64 %t692)
  %t717 = getelementptr i8, ptr %t716, i64 %t692
  call void @olang_textcopy(ptr %t717, ptr %t694, i64 %t695)
  %t718 = getelementptr i8, ptr %t717, i64 %t695
  call void @olang_textcopy(ptr %t718, ptr %t698, i64 %t699)
  %t719 = getelementptr i8, ptr %t718, i64 %t699
  call void @olang_textcopy(ptr %t719, ptr %t701, i64 %t702)
  %t720 = getelementptr i8, ptr %t719, i64 %t702
  call void @olang_textcopy(ptr %t720, ptr %t705, i64 %t706)
  %t721 = getelementptr i8, ptr %t720, i64 %t706
  call void @olang_textcopy(ptr %t721, ptr %t708, i64 %t709)
  %t722 = insertvalue { i64, ptr } undef, i64 %t710, 0
  %t723 = insertvalue { i64, ptr } %t722, ptr %t711, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t668, { i64, ptr } %t723)
  br label %bb38
bb38:
  %t727 = load ptr, ptr %l1, !tbaa !29
  store ptr %t727, ptr %l176, !tbaa !29
  %t728 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t728, ptr %l177, !tbaa !27
  %t729 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t729, ptr %l178, !tbaa !27
  %t730 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t730, ptr %l179, !tbaa !27
  %t731 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t731, ptr %l180, !tbaa !27
  %t732 = load i64, ptr %l18, !tbaa !24
  %t734 = icmp sgt i64 %t732, 8
  br i1 %t734, label %bb39, label %bb40
bb39:
  %t736 = load i64, ptr %l18, !tbaa !24
  %t737 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t738 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t740 = call i64 @__olang_fmt_i64(ptr null, i64 %t736)
  %t741 = add i64 %t738, %t740
  %t742 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t741)
  call void @olang_textcopy(ptr %t742, ptr %t737, i64 %t738)
  %t743 = getelementptr i8, ptr %t742, i64 %t738
  %t744 = call i64 @__olang_fmt_i64(ptr %t743, i64 %t736)
  %t745 = insertvalue { i64, ptr } undef, i64 %t741, 0
  %t746 = insertvalue { i64, ptr } %t745, ptr %t742, 1
  store { i64, ptr } %t746, ptr %l183, !tbaa !27
  br label %bb41
bb40:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d395, i32 0, i32 1) }, ptr %l183, !tbaa !27
  br label %bb41
bb41:
  %t749 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t750 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t751 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t752 = extractvalue { i64, ptr } %t751, 1
  %t753 = extractvalue { i64, ptr } %t751, 0
  %t754 = add i64 %t750, %t753
  %t755 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t756 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t757 = add i64 %t754, %t756
  %t758 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t759 = extractvalue { i64, ptr } %t758, 1
  %t760 = extractvalue { i64, ptr } %t758, 0
  %t761 = add i64 %t757, %t760
  %t762 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t763 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t764 = add i64 %t761, %t763
  %t765 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t766 = extractvalue { i64, ptr } %t765, 1
  %t767 = extractvalue { i64, ptr } %t765, 0
  %t768 = add i64 %t764, %t767
  %t769 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d399, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d399, i32 0, i32 1) }, 0
  %t771 = add i64 %t768, %t770
  %t772 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t773 = extractvalue { i64, ptr } %t772, 1
  %t774 = extractvalue { i64, ptr } %t772, 0
  %t775 = add i64 %t771, %t774
  %t776 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t778 = add i64 %t775, %t777
  %t779 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t780 = extractvalue { i64, ptr } %t779, 1
  %t781 = extractvalue { i64, ptr } %t779, 0
  %t782 = add i64 %t778, %t781
  %t783 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d401, i32 0, i32 1) }, 1
  %t784 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d401, i32 0, i32 1) }, 0
  %t785 = add i64 %t782, %t784
  %t786 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t785)
  call void @olang_textcopy(ptr %t786, ptr %t749, i64 %t750)
  %t787 = getelementptr i8, ptr %t786, i64 %t750
  call void @olang_textcopy(ptr %t787, ptr %t752, i64 %t753)
  %t788 = getelementptr i8, ptr %t787, i64 %t753
  call void @olang_textcopy(ptr %t788, ptr %t755, i64 %t756)
  %t789 = getelementptr i8, ptr %t788, i64 %t756
  call void @olang_textcopy(ptr %t789, ptr %t759, i64 %t760)
  %t790 = getelementptr i8, ptr %t789, i64 %t760
  call void @olang_textcopy(ptr %t790, ptr %t762, i64 %t763)
  %t791 = getelementptr i8, ptr %t790, i64 %t763
  call void @olang_textcopy(ptr %t791, ptr %t766, i64 %t767)
  %t792 = getelementptr i8, ptr %t791, i64 %t767
  call void @olang_textcopy(ptr %t792, ptr %t769, i64 %t770)
  %t793 = getelementptr i8, ptr %t792, i64 %t770
  call void @olang_textcopy(ptr %t793, ptr %t773, i64 %t774)
  %t794 = getelementptr i8, ptr %t793, i64 %t774
  call void @olang_textcopy(ptr %t794, ptr %t776, i64 %t777)
  %t795 = getelementptr i8, ptr %t794, i64 %t777
  call void @olang_textcopy(ptr %t795, ptr %t780, i64 %t781)
  %t796 = getelementptr i8, ptr %t795, i64 %t781
  call void @olang_textcopy(ptr %t796, ptr %t783, i64 %t784)
  %t797 = insertvalue { i64, ptr } undef, i64 %t785, 0
  %t798 = insertvalue { i64, ptr } %t797, ptr %t786, 1
  %t800 = load ptr, ptr %l176, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t800, { i64, ptr } %t798)
  br label %bb42
bb42:
  %t802 = load ptr, ptr %l1, !tbaa !29
  %t803 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t804 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t805 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t806 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t807 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t809 = extractvalue { i64, ptr } %t803, 1
  %t810 = extractvalue { i64, ptr } %t803, 0
  %t811 = add i64 %t807, %t810
  %t812 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t813 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t814 = add i64 %t811, %t813
  %t816 = extractvalue { i64, ptr } %t804, 1
  %t817 = extractvalue { i64, ptr } %t804, 0
  %t818 = add i64 %t814, %t817
  %t819 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t820 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t821 = add i64 %t818, %t820
  %t823 = extractvalue { i64, ptr } %t805, 1
  %t824 = extractvalue { i64, ptr } %t805, 0
  %t825 = add i64 %t821, %t824
  %t826 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t827 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t828 = add i64 %t825, %t827
  %t829 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t828)
  call void @olang_textcopy(ptr %t829, ptr %t806, i64 %t807)
  %t830 = getelementptr i8, ptr %t829, i64 %t807
  call void @olang_textcopy(ptr %t830, ptr %t809, i64 %t810)
  %t831 = getelementptr i8, ptr %t830, i64 %t810
  call void @olang_textcopy(ptr %t831, ptr %t812, i64 %t813)
  %t832 = getelementptr i8, ptr %t831, i64 %t813
  call void @olang_textcopy(ptr %t832, ptr %t816, i64 %t817)
  %t833 = getelementptr i8, ptr %t832, i64 %t817
  call void @olang_textcopy(ptr %t833, ptr %t819, i64 %t820)
  %t834 = getelementptr i8, ptr %t833, i64 %t820
  call void @olang_textcopy(ptr %t834, ptr %t823, i64 %t824)
  %t835 = getelementptr i8, ptr %t834, i64 %t824
  call void @olang_textcopy(ptr %t835, ptr %t826, i64 %t827)
  %t836 = insertvalue { i64, ptr } undef, i64 %t828, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t829, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t802, { i64, ptr } %t837)
  br label %bb43
bb43:
  %t841 = load ptr, ptr %l1, !tbaa !29
  %t842 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t843 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t844 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t845 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t847 = extractvalue { i64, ptr } %t842, 1
  %t848 = extractvalue { i64, ptr } %t842, 0
  %t849 = add i64 %t845, %t848
  %t850 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t851 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  %t852 = add i64 %t849, %t851
  %t854 = extractvalue { i64, ptr } %t843, 1
  %t855 = extractvalue { i64, ptr } %t843, 0
  %t856 = add i64 %t852, %t855
  %t857 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t858 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t859 = add i64 %t856, %t858
  %t860 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t859)
  call void @olang_textcopy(ptr %t860, ptr %t844, i64 %t845)
  %t861 = getelementptr i8, ptr %t860, i64 %t845
  call void @olang_textcopy(ptr %t861, ptr %t847, i64 %t848)
  %t862 = getelementptr i8, ptr %t861, i64 %t848
  call void @olang_textcopy(ptr %t862, ptr %t850, i64 %t851)
  %t863 = getelementptr i8, ptr %t862, i64 %t851
  call void @olang_textcopy(ptr %t863, ptr %t854, i64 %t855)
  %t864 = getelementptr i8, ptr %t863, i64 %t855
  call void @olang_textcopy(ptr %t864, ptr %t857, i64 %t858)
  %t865 = insertvalue { i64, ptr } undef, i64 %t859, 0
  %t866 = insertvalue { i64, ptr } %t865, ptr %t860, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t841, { i64, ptr } %t866)
  br label %bb44
bb44:
  %t870 = load ptr, ptr %l1, !tbaa !29
  %t871 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t872 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t873 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t874 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t875 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t876 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t877 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t879 = extractvalue { i64, ptr } %t871, 1
  %t880 = extractvalue { i64, ptr } %t871, 0
  %t881 = add i64 %t877, %t880
  %t882 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d410, i32 0, i32 1) }, 1
  %t883 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d410, i32 0, i32 1) }, 0
  %t884 = add i64 %t881, %t883
  %t886 = extractvalue { i64, ptr } %t872, 1
  %t887 = extractvalue { i64, ptr } %t872, 0
  %t888 = add i64 %t884, %t887
  %t889 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t890 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t891 = add i64 %t888, %t890
  %t893 = extractvalue { i64, ptr } %t873, 1
  %t894 = extractvalue { i64, ptr } %t873, 0
  %t895 = add i64 %t891, %t894
  %t896 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d412, i32 0, i32 1) }, 1
  %t897 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d412, i32 0, i32 1) }, 0
  %t898 = add i64 %t895, %t897
  %t900 = extractvalue { i64, ptr } %t874, 1
  %t901 = extractvalue { i64, ptr } %t874, 0
  %t902 = add i64 %t898, %t901
  %t903 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d413, i32 0, i32 1) }, 1
  %t904 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d413, i32 0, i32 1) }, 0
  %t905 = add i64 %t902, %t904
  %t907 = extractvalue { i64, ptr } %t875, 1
  %t908 = extractvalue { i64, ptr } %t875, 0
  %t909 = add i64 %t905, %t908
  %t910 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d414, i32 0, i32 1) }, 1
  %t911 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d414, i32 0, i32 1) }, 0
  %t912 = add i64 %t909, %t911
  %t913 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t912)
  call void @olang_textcopy(ptr %t913, ptr %t876, i64 %t877)
  %t914 = getelementptr i8, ptr %t913, i64 %t877
  call void @olang_textcopy(ptr %t914, ptr %t879, i64 %t880)
  %t915 = getelementptr i8, ptr %t914, i64 %t880
  call void @olang_textcopy(ptr %t915, ptr %t882, i64 %t883)
  %t916 = getelementptr i8, ptr %t915, i64 %t883
  call void @olang_textcopy(ptr %t916, ptr %t886, i64 %t887)
  %t917 = getelementptr i8, ptr %t916, i64 %t887
  call void @olang_textcopy(ptr %t917, ptr %t889, i64 %t890)
  %t918 = getelementptr i8, ptr %t917, i64 %t890
  call void @olang_textcopy(ptr %t918, ptr %t893, i64 %t894)
  %t919 = getelementptr i8, ptr %t918, i64 %t894
  call void @olang_textcopy(ptr %t919, ptr %t896, i64 %t897)
  %t920 = getelementptr i8, ptr %t919, i64 %t897
  call void @olang_textcopy(ptr %t920, ptr %t900, i64 %t901)
  %t921 = getelementptr i8, ptr %t920, i64 %t901
  call void @olang_textcopy(ptr %t921, ptr %t903, i64 %t904)
  %t922 = getelementptr i8, ptr %t921, i64 %t904
  call void @olang_textcopy(ptr %t922, ptr %t907, i64 %t908)
  %t923 = getelementptr i8, ptr %t922, i64 %t908
  call void @olang_textcopy(ptr %t923, ptr %t910, i64 %t911)
  %t924 = insertvalue { i64, ptr } undef, i64 %t912, 0
  %t925 = insertvalue { i64, ptr } %t924, ptr %t913, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t870, { i64, ptr } %t925)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s13)
  br label %bb46
bb46:
  %t929 = load ptr, ptr %l1, !tbaa !29
  %t930 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t931 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t932 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t933 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t935 = extractvalue { i64, ptr } %t930, 1
  %t936 = extractvalue { i64, ptr } %t930, 0
  %t937 = add i64 %t933, %t936
  %t938 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t939 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t940 = add i64 %t937, %t939
  %t942 = extractvalue { i64, ptr } %t931, 1
  %t943 = extractvalue { i64, ptr } %t931, 0
  %t944 = add i64 %t940, %t943
  %t945 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d417, i32 0, i32 1) }, 1
  %t946 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d417, i32 0, i32 1) }, 0
  %t947 = add i64 %t944, %t946
  %t948 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t947)
  call void @olang_textcopy(ptr %t948, ptr %t932, i64 %t933)
  %t949 = getelementptr i8, ptr %t948, i64 %t933
  call void @olang_textcopy(ptr %t949, ptr %t935, i64 %t936)
  %t950 = getelementptr i8, ptr %t949, i64 %t936
  call void @olang_textcopy(ptr %t950, ptr %t938, i64 %t939)
  %t951 = getelementptr i8, ptr %t950, i64 %t939
  call void @olang_textcopy(ptr %t951, ptr %t942, i64 %t943)
  %t952 = getelementptr i8, ptr %t951, i64 %t943
  call void @olang_textcopy(ptr %t952, ptr %t945, i64 %t946)
  %t953 = insertvalue { i64, ptr } undef, i64 %t947, 0
  %t954 = insertvalue { i64, ptr } %t953, ptr %t948, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t929, { i64, ptr } %t954)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  %t958 = load i32, ptr %l12, !tbaa !23
  %t961 = add i32 %t958, 1
  store i32 %t961, ptr %l12, !tbaa !23
  br label %bb7
bb49:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, { i64, ptr } %a5, ptr %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, [21 x i64] }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca { i64, [8 x i64] }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca %"compiler/mir:Range"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i32
  %l34 = alloca %"compiler/mir:Call"
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i64
  %l44 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l54 = alloca ptr
  %l56 = alloca ptr
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l84 = alloca ptr
  %l87 = alloca { i64, [21 x i64] }
  %l88 = alloca { i64, [21 x i64] }
  %l95 = alloca { i64, [21 x i64] }
  %l107 = alloca ptr
  %l111 = alloca i64
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca i32
  %l147 = alloca i32
  %l165 = alloca ptr
  %l167 = alloca ptr
  %l174 = alloca %"compiler/mir:Case"
  %l187 = alloca ptr
  %l191 = alloca %"compiler/mir:Call"
  %l209 = alloca i1
  %l253 = alloca i64
  %l255 = alloca i64
  %l260 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l44, !tbaa !27
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l9, !tbaa !24
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 9
  store ptr %t16, ptr %l48, !tbaa !29
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load ptr, ptr %l48, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v4, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = call ptr @__olang_scope_or(ptr %v4, ptr %t25)
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t21 to ptr
  %t33 = inttoptr i64 %t29 to ptr
  %t34 = load ptr, ptr %l48, !tbaa !29
  %t36 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t31, ptr %t33, ptr %t34, i64 %t17)
  store ptr %t36, ptr %l54
  br label %bb1
bb1:
  %t37 = load ptr, ptr %l54, !tbaa !29
  store ptr %t37, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t38 = load ptr, ptr %l10, !tbaa !29
  %t40 = getelementptr %"compiler/mir:BasicBlock", ptr %t38, i32 0, i32 0
  store ptr %t40, ptr %l56, !tbaa !29
  %t41 = load ptr, ptr %l56, !tbaa !29
  %t42 = call ptr @__olang_scope_or(ptr %v4, ptr %t41)
  %t43 = call ptr @__olang_scope_hold(ptr %t42)
  %t44 = ptrtoint ptr %t43 to i64
  %t46 = inttoptr i64 %t44 to ptr
  %t47 = load ptr, ptr %l56, !tbaa !29
  %t48 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %t46, ptr %t47)
  store i64 %t48, ptr %l58
  br label %bb2
bb2:
  %t49 = load i64, ptr %l58, !tbaa !24
  store i64 %t49, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t50 = load i64, ptr %l12, !tbaa !24
  %t51 = load i64, ptr %l11, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb3, label %bb4
bb3:
  %t56 = load i64, ptr %l13, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb8
bb5:
  %t60 = load i64, ptr %l12, !tbaa !24
  %t61 = load i64, ptr %l11, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l13, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l13, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l65, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb7
bb7:
  %t76 = load i64, ptr %l65, !tbaa !24
  store i64 %t76, ptr %l62, !tbaa !24
  br label %bb8
bb8:
  %t77 = load i64, ptr %l62, !tbaa !24
  store i64 %t77, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb9
bb9:
  %t78 = load i64, ptr %l15, !tbaa !24
  %t79 = load i64, ptr %l14, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb10, label %bb11
bb10:
  br label %bb42
bb11:
  br label %bb12
bb12:
  %t86 = load i64, ptr %l11, !tbaa !24
  %t87 = load i64, ptr %l15, !tbaa !24
  %t88 = load i64, ptr %l13, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l16, !tbaa !24
  %t96 = load ptr, ptr %l10, !tbaa !29
  %t98 = getelementptr %"compiler/mir:BasicBlock", ptr %t96, i32 0, i32 0
  store ptr %t98, ptr %l84, !tbaa !29
  %t99 = load i64, ptr %l16, !tbaa !24
  %t100 = load ptr, ptr %l84, !tbaa !29
  %t101 = call ptr @__olang_scope_or(ptr %v4, ptr %t100)
  %t102 = call ptr @__olang_scope_hold(ptr %t101)
  %t103 = ptrtoint ptr %t102 to i64
  %t105 = inttoptr i64 %t103 to ptr
  %t106 = load ptr, ptr %l84, !tbaa !29
  %t108 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %t105, ptr %t106, i64 %t99)
  store { i64, [21 x i64] } %t108, ptr %l87
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %l87, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %l17, i64 176, i1 false)
  %t109 = load { i64, [21 x i64] }, ptr %l88
  %t110 = extractvalue { i64, [21 x i64] } %t109, 0
  %t111 = icmp eq i64 %t110, 3
  br i1 %t111, label %bb14, label %bb15
bb14:
  %t113 = getelementptr { i64, [21 x i64] }, ptr %l17, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32 }, ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114
  store i32 %t115, ptr %l18, !tbaa !23
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t117 = load i32, ptr %l18, !tbaa !23
  %t119 = sext i32 %t117 to i64
  %t120 = load i64, ptr %l1, !tbaa !24
  %t123 = icmp eq i64 %t119, %t120
  br i1 %t123, label %bb17, label %bb18
bb17:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb40
bb20:
  call void @llvm.memmove.p0.p0.i64(ptr %l95, ptr %l17, i64 176, i1 false)
  %t125 = load { i64, [21 x i64] }, ptr %l95
  %t126 = extractvalue { i64, [21 x i64] } %t125, 0
  %t127 = icmp eq i64 %t126, 4
  br i1 %t127, label %bb21, label %bb22
bb21:
  %t129 = getelementptr { i64, [21 x i64] }, ptr %l17, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32 }, ptr %t129, i32 0, i32 1
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l19, !tbaa !23
  br label %bb23
bb22:
  br label %bb35
bb23:
  %t133 = load i32, ptr %l19, !tbaa !23
  %t135 = sext i32 %t133 to i64
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = icmp ne i64 %t135, %t136
  br i1 %t139, label %bb24, label %bb25
bb24:
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = icmp eq i64 %t141, 1
  br i1 %t143, label %bb27, label %bb28
bb27:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t147 = icmp eq i64 %t145, 2
  br i1 %t147, label %bb29, label %bb30
bb28:
  br label %bb34
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  store ptr %a7, ptr %l107, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l3, !tbaa !24
  %t153 = load i64, ptr %l16, !tbaa !24
  %t157 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %t151, i64 %t152, i64 %t153)
  store i64 %t157, ptr %l111
  br label %bb32
bb32:
  %t158 = load i64, ptr %l9, !tbaa !24
  %t160 = icmp eq i64 %t158, 1
  %t161 = load ptr, ptr %l107, !tbaa !29
  %t162 = load i64, ptr %l111, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v3, ptr %t161, i64 %t162, i1 %t160)
  br label %bb33
bb33:
  br label %bb34
bb34:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_93708b25bcca1908_59bc9d4dcf3d1544)
  unreachable
bb40:
  br label %bb41
bb41:
  %t164 = load i64, ptr %l15, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l15, !tbaa !24
  br label %bb9
bb42:
  %t169 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %l117
  br label %bb43
bb43:
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l20
  %t171 = load ptr, ptr %l10, !tbaa !29
  %t173 = getelementptr %"compiler/mir:BasicBlock", ptr %t171, i32 0, i32 1
  %t174 = load { i64, [8 x i64] }, ptr %t173
  store { i64, [8 x i64] } %t174, ptr %l21
  %t176 = load { i64, [8 x i64] }, ptr %l21
  %t178 = extractvalue { i64, [8 x i64] } %t176, 0
  %t179 = icmp eq i64 %t178, 1
  br i1 %t179, label %bb44, label %bb45
bb44:
  %t181 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t182 = getelementptr { i32 }, ptr %t181, i32 0, i32 0
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l22, !tbaa !23
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t185 = load i32, ptr %l22, !tbaa !23
  %t187 = sext i32 %t185 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t187)
  br label %bb47
bb47:
  br label %bb120
bb48:
  %t190 = load { i64, [8 x i64] }, ptr %l21
  %t192 = extractvalue { i64, [8 x i64] } %t190, 0
  %t193 = icmp eq i64 %t192, 2
  br i1 %t193, label %bb49, label %bb50
bb49:
  %t195 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t196 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t195, i32 0, i32 1
  %t197 = load i32, ptr %t196
  store i32 %t197, ptr %l23, !tbaa !23
  %t199 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t200 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t199, i32 0, i32 2
  %t201 = load i32, ptr %t200
  store i32 %t201, ptr %l24, !tbaa !23
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t203 = load i32, ptr %l23, !tbaa !23
  %t205 = sext i32 %t203 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t205)
  br label %bb52
bb52:
  %t208 = load i32, ptr %l24, !tbaa !23
  %t210 = sext i32 %t208 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t210)
  br label %bb53
bb53:
  br label %bb120
bb54:
  %t213 = load { i64, [8 x i64] }, ptr %l21
  %t215 = extractvalue { i64, [8 x i64] } %t213, 0
  %t216 = icmp eq i64 %t215, 3
  br i1 %t216, label %bb55, label %bb56
bb55:
  %t218 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t219 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t218, i32 0, i32 1
  %t220 = load %"compiler/mir:Range", ptr %t219
  store %"compiler/mir:Range" %t220, ptr %l25
  %t222 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t223 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t222, i32 0, i32 2
  %t224 = load i32, ptr %t223
  store i32 %t224, ptr %l26, !tbaa !23
  br label %bb57
bb56:
  br label %bb73
bb57:
  store i32 0, ptr %l27, !tbaa !23
  %t226 = getelementptr %"compiler/mir:Range", ptr %l25, i32 0, i32 1
  %t227 = load i32, ptr %t226, !tbaa !23
  store i32 %t227, ptr %l28, !tbaa !23
  store i32 1, ptr %l29, !tbaa !23
  %t229 = load i32, ptr %l28, !tbaa !23
  %t230 = load i32, ptr %l27, !tbaa !23
  %t233 = icmp sgt i32 %t229, %t230
  br i1 %t233, label %bb58, label %bb59
bb58:
  %t235 = load i32, ptr %l29, !tbaa !23
  %t237 = icmp sgt i32 %t235, 0
  br i1 %t237, label %bb60, label %bb61
bb59:
  store i32 0, ptr %l144, !tbaa !23
  br label %bb63
bb60:
  %t239 = load i32, ptr %l28, !tbaa !23
  %t240 = load i32, ptr %l27, !tbaa !23
  %t243 = sub i32 %t239, %t240
  %t244 = load i32, ptr %l29, !tbaa !23
  %t247 = add i32 %t243, %t244
  %t249 = sub i32 %t247, 1
  %t250 = load i32, ptr %l29, !tbaa !23
  %t253 = sdiv i32 %t249, %t250
  store i32 %t253, ptr %l147, !tbaa !23
  br label %bb62
bb61:
  store i32 0, ptr %l147, !tbaa !23
  br label %bb62
bb62:
  %t255 = load i32, ptr %l147, !tbaa !23
  store i32 %t255, ptr %l144, !tbaa !23
  br label %bb63
bb63:
  %t256 = load i32, ptr %l144, !tbaa !23
  store i32 %t256, ptr %l30, !tbaa !23
  store i32 0, ptr %l31, !tbaa !23
  br label %bb64
bb64:
  %t257 = load i32, ptr %l31, !tbaa !23
  %t258 = load i32, ptr %l30, !tbaa !23
  %t261 = icmp slt i32 %t257, %t258
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb65, label %bb66
bb65:
  br label %bb71
bb66:
  br label %bb67
bb67:
  %t265 = load i32, ptr %l27, !tbaa !23
  %t266 = load i32, ptr %l31, !tbaa !23
  %t267 = load i32, ptr %l29, !tbaa !23
  %t270 = mul i32 %t266, %t267
  %t273 = add i32 %t265, %t270
  store ptr %l20, ptr %l165, !tbaa !29
  %t275 = load ptr, ptr %l8, !tbaa !29
  %t277 = getelementptr %"compiler/mir:Fn", ptr %t275, i32 0, i32 15
  store ptr %t277, ptr %l167, !tbaa !29
  %t278 = getelementptr %"compiler/mir:Range", ptr %l25, i32 0, i32 0
  %t279 = load i32, ptr %t278, !tbaa !23
  %t281 = sext i32 %t279 to i64
  %t284 = sext i32 %t273 to i64
  %t287 = add i64 %t281, %t284
  %t288 = load ptr, ptr %l167, !tbaa !29
  %t289 = call ptr @__olang_scope_or(ptr %v4, ptr %t288)
  %t290 = call ptr @__olang_scope_hold(ptr %t289)
  %t291 = ptrtoint ptr %t290 to i64
  %t293 = inttoptr i64 %t291 to ptr
  %t294 = load ptr, ptr %l167, !tbaa !29
  %t296 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t293, ptr %t294, i64 %t287)
  store %"compiler/mir:Case" %t296, ptr %l174
  br label %bb68
bb68:
  %t297 = getelementptr %"compiler/mir:Case", ptr %l174, i32 0, i32 1
  %t298 = load i32, ptr %t297, !tbaa !23
  %t300 = sext i32 %t298 to i64
  %t301 = load ptr, ptr %l165, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t301, i64 %t300)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t303 = load i32, ptr %l31, !tbaa !23
  %t306 = add i32 %t303, 1
  store i32 %t306, ptr %l31, !tbaa !23
  br label %bb64
bb71:
  %t308 = load i32, ptr %l26, !tbaa !23
  %t310 = sext i32 %t308 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t310)
  br label %bb72
bb72:
  br label %bb120
bb73:
  %t313 = load { i64, [8 x i64] }, ptr %l21
  %t315 = extractvalue { i64, [8 x i64] } %t313, 0
  %t316 = icmp eq i64 %t315, 4
  br i1 %t316, label %bb74, label %bb75
bb74:
  %t318 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", i32 }, ptr %t318, i32 0, i32 1
  %t320 = load i32, ptr %t319
  store i32 %t320, ptr %l33, !tbaa !23
  br label %bb76
bb75:
  br label %bb100
bb76:
  %t322 = load ptr, ptr %l8, !tbaa !29
  %t324 = getelementptr %"compiler/mir:Fn", ptr %t322, i32 0, i32 14
  store ptr %t324, ptr %l187, !tbaa !29
  %t325 = load i32, ptr %l33, !tbaa !23
  %t327 = sext i32 %t325 to i64
  %t328 = load ptr, ptr %l187, !tbaa !29
  %t329 = call ptr @__olang_scope_or(ptr %v4, ptr %t328)
  %t330 = call ptr @__olang_scope_hold(ptr %t329)
  %t331 = ptrtoint ptr %t330 to i64
  %t333 = inttoptr i64 %t331 to ptr
  %t334 = load ptr, ptr %l187, !tbaa !29
  %t336 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t333, ptr %t334, i64 %t327)
  store %"compiler/mir:Call" %t336, ptr %l191
  br label %bb77
bb77:
  %t337 = load %"compiler/mir:Call", ptr %l191
  store %"compiler/mir:Call" %t337, ptr %l34
  %t338 = load i32, ptr %l33, !tbaa !23
  %t340 = sext i32 %t338 to i64
  %t344 = icmp eq i64 %t340, %a2
  br i1 %t344, label %bb78, label %bb79
bb78:
  %t346 = load i64, ptr %l9, !tbaa !24
  %t348 = icmp ne i64 %t346, 0
  br i1 %t348, label %bb80, label %bb81
bb79:
  br label %bb94
bb80:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  %t351 = load i64, ptr %l4, !tbaa !24
  %t353 = icmp eq i64 %t351, 0
  br i1 %t353, label %bb83, label %bb84
bb83:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t357 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 5
  %t358 = load i32, ptr %t357, !tbaa !23
  %t360 = sext i32 %t358 to i64
  %t361 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %t355, { i64, ptr } %t356, i64 %t360, i64 1, ptr %t361)
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t366 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 7
  %t367 = load i32, ptr %t366, !tbaa !23
  %t368 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t371 = icmp ne i32 %t367, %t368
  br i1 %t371, label %bb87, label %bb88
bb87:
  %t373 = load i64, ptr %l4, !tbaa !24
  %t375 = icmp eq i64 %t373, 0
  store i1 %t375, ptr %l209, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb89
bb89:
  %t377 = load i1, ptr %l209, !tbaa !21
  br i1 %t377, label %bb90, label %bb91
bb90:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t380 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 7
  %t381 = load i32, ptr %t380, !tbaa !23
  %t383 = sext i32 %t381 to i64
  %t384 = load i64, ptr %l9, !tbaa !24
  %t385 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %t378, { i64, ptr } %t379, i64 %t383, i64 %t384, ptr %t385)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb94:
  %t391 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 5
  %t392 = load i32, ptr %t391, !tbaa !23
  %t394 = sext i32 %t392 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t394)
  br label %bb95
bb95:
  %t397 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 7
  %t398 = load i32, ptr %t397, !tbaa !23
  %t399 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t402 = icmp ne i32 %t398, %t399
  br i1 %t402, label %bb96, label %bb97
bb96:
  %t404 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 7
  %t405 = load i32, ptr %t404, !tbaa !23
  %t407 = sext i32 %t405 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t407)
  br label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb99
bb99:
  br label %bb120
bb100:
  %t410 = load { i64, [8 x i64] }, ptr %l21
  %t412 = extractvalue { i64, [8 x i64] } %t410, 0
  %t413 = icmp eq i64 %t412, 8
  br i1 %t413, label %bb101, label %bb102
bb101:
  %t415 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t415, i32 0, i32 2
  %t417 = load i32, ptr %t416
  store i32 %t417, ptr %l35, !tbaa !23
  %t419 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t419, i32 0, i32 4
  %t421 = load i32, ptr %t420
  store i32 %t421, ptr %l36, !tbaa !23
  br label %bb103
bb102:
  br label %bb109
bb103:
  %t423 = load i32, ptr %l35, !tbaa !23
  %t425 = sext i32 %t423 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t425)
  br label %bb104
bb104:
  %t428 = load i32, ptr %l36, !tbaa !23
  %t429 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t432 = icmp ne i32 %t428, %t429
  br i1 %t432, label %bb105, label %bb106
bb105:
  %t434 = load i32, ptr %l36, !tbaa !23
  %t436 = sext i32 %t434 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t436)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  br label %bb120
bb109:
  %t439 = load { i64, [8 x i64] }, ptr %l21
  %t441 = extractvalue { i64, [8 x i64] } %t439, 0
  %t442 = icmp eq i64 %t441, 11
  br i1 %t442, label %bb110, label %bb111
bb110:
  %t444 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t445 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t444, i32 0, i32 2
  %t446 = load i32, ptr %t445
  store i32 %t446, ptr %l37, !tbaa !23
  %t448 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t449 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t448, i32 0, i32 4
  %t450 = load i32, ptr %t449
  store i32 %t450, ptr %l38, !tbaa !23
  br label %bb112
bb111:
  br label %bb115
bb112:
  %t452 = load i32, ptr %l37, !tbaa !23
  %t454 = sext i32 %t452 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t454)
  br label %bb113
bb113:
  %t457 = load i32, ptr %l38, !tbaa !23
  %t459 = sext i32 %t457 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t459)
  br label %bb114
bb114:
  br label %bb120
bb115:
  br i1 true, label %bb116, label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_82759c8127bb92d9_9a26fc180f98a435)
  unreachable
bb120:
  %t462 = load i64, ptr %l4, !tbaa !24
  %t464 = icmp eq i64 %t462, 0
  br i1 %t464, label %bb121, label %bb122
bb121:
  store ptr %l20, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb123
bb122:
  br label %bb132
bb123:
  %t467 = load i64, ptr %l40, !tbaa !24
  store i64 %t467, ptr %l253, !tbaa !24
  %t468 = load ptr, ptr %l39, !tbaa !29
  %t470 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t468)
  store i64 %t470, ptr %l255
  br label %bb124
bb124:
  %t471 = load i64, ptr %l253, !tbaa !24
  %t472 = load i64, ptr %l255, !tbaa !24
  %t473 = icmp slt i64 %t471, %t472
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb125, label %bb126
bb125:
  br label %bb131
bb126:
  br label %bb127
bb127:
  %t477 = load ptr, ptr %l39, !tbaa !29
  %t478 = load i64, ptr %l40, !tbaa !24
  %t481 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t477, i64 %t478)
  store i64 %t481, ptr %l260
  br label %bb128
bb128:
  %t482 = load i64, ptr %l260, !tbaa !24
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t486 = load i64, ptr %l9, !tbaa !24
  %t487 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %t483, { i64, ptr } %t484, i64 %t482, i64 %t486, ptr %t487)
  br label %bb129
bb129:
  br label %bb130
bb130:
  %t493 = load i64, ptr %l40, !tbaa !24
  %t496 = add i64 %t493, 1
  store i64 %t496, ptr %l40, !tbaa !24
  br label %bb123
bb131:
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %t2
  %t7 = load i64, ptr %t6, !tbaa !34
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l11, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i64, ptr %t15, i64 %t12
  %t17 = load i64, ptr %t16, !tbaa !34
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t24 = load i64, ptr %l3, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 2, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t26 = load i64, ptr %l16, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i64, ptr %t32, i64 %t29
  %t34 = load i64, ptr %t33, !tbaa !34
  %t37 = icmp ne i64 %t27, %t34
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i64, ptr %t45, i64 %t40
  store i64 %t41, ptr %t46, !tbaa !34
  %t48 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %a4, i64 %t48)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewideToBF16(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l62 = alloca i1
  %l64 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l170 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l190 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %v3, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l25
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t15 = call ptr @__olang_scope_hold(ptr %s0)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l26, !tbaa !24
  %t17 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e5
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = call ptr @__olang_region_make(ptr %s0)
  %t20 = ptrtoint ptr %t19 to i64
  store i64 %t20, ptr %l26, !tbaa !24
  br label %bb3
bb3:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = load i64, ptr %l26
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l29, !tbaa !27
  %t30 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e5
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t32 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb5:
  %t37 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d418, i32 0, i32 1) })
  store i1 %t40, ptr %l34
  br label %bb8
bb6:
  store { i64, ptr } zeroinitializer, ptr %l29, !tbaa !27
  br label %bb7
bb7:
  %t41 = load i64, ptr %l26
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = load { i64, ptr }, ptr %l29
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = call ptr @__olang_region_or(ptr %t44, ptr null)
  %t46 = icmp ne ptr %t45, null
  %t47 = select i1 %t46, ptr %t45, ptr null
  call void @__olang_region_settle_in(ptr %t42, ptr %t47)
  br label %bb5
bb8:
  %t48 = load i1, ptr %l34, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = call ptr @__olang_scope_hold(ptr %s0)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l36, !tbaa !24
  %t53 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e5
  br i1 %t53, label %bb11, label %bb12
bb10:
  br label %bb24
bb11:
  %t55 = call ptr @__olang_region_make(ptr %s0)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l36, !tbaa !24
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l38, !tbaa !29
  %t58 = load ptr, ptr %l3, !tbaa !29
  store ptr %t58, ptr %l39, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = call ptr @__olang_scope_or(ptr %v3, ptr %t60)
  %t62 = call ptr @__olang_scope_hold(ptr %t61)
  %t63 = ptrtoint ptr %t62 to i64
  %t65 = inttoptr i64 %t63 to ptr
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t65, ptr %t66, i32 %t59)
  store i1 %t68, ptr %l42
  br label %bb13
bb13:
  %t69 = load i1, ptr %l42, !tbaa !21
  br i1 %t69, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d419, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d420, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb16
bb16:
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t76 = extractvalue { i64, ptr } %t70, 1
  %t77 = extractvalue { i64, ptr } %t70, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d421, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d421, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t83 = extractvalue { i64, ptr } %t71, 1
  %t84 = extractvalue { i64, ptr } %t71, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t73, i64 %t74)
  %t90 = getelementptr i8, ptr %t89, i64 %t74
  call void @olang_textcopy(ptr %t90, ptr %t76, i64 %t77)
  %t91 = getelementptr i8, ptr %t90, i64 %t77
  call void @olang_textcopy(ptr %t91, ptr %t79, i64 %t80)
  %t92 = getelementptr i8, ptr %t91, i64 %t80
  call void @olang_textcopy(ptr %t92, ptr %t83, i64 %t84)
  %t93 = getelementptr i8, ptr %t92, i64 %t84
  call void @olang_textcopy(ptr %t93, ptr %t86, i64 %t87)
  %t94 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t89, 1
  %t97 = load i64, ptr %l36
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = load ptr, ptr %l38, !tbaa !29
  %t101 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s2, ptr %t98, ptr %v3, ptr %t99, { i64, ptr } %t95)
  store { i64, ptr } %t101, ptr %l48
  br label %bb17
bb17:
  %t102 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e5
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t107 = icmp eq i64 %t105, 0
  br i1 %t107, label %bb20, label %bb21
bb19:
  %t109 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t109, ptr %l52, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t110, ptr %l5, !tbaa !27
  %t111 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e5
  br i1 %t111, label %bb22, label %bb23
bb20:
  store { i64, ptr } zeroinitializer, ptr %l48, !tbaa !27
  br label %bb21
bb21:
  %t113 = load i64, ptr %l36
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = load { i64, ptr }, ptr %l48
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = icmp ne ptr %t117, null
  %t119 = select i1 %t118, ptr %t117, ptr null
  call void @__olang_region_settle_in(ptr %t114, ptr %t119)
  br label %bb19
bb22:
  %t120 = load { i64, ptr }, ptr %l52
  %t121 = extractvalue { i64, ptr } %t120, 1
  call void @__olang_region_release(ptr %t121)
  store { i64, ptr } zeroinitializer, ptr %l52
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d423, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t122, ptr %l6, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t124, ptr %l56, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l57, !tbaa !24
  %t127 = load i64, ptr %l57, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l58, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l57, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t139 = load ptr, ptr %l3, !tbaa !29
  store ptr %t139, ptr %l59, !tbaa !29
  %t140 = load i32, ptr %l2, !tbaa !23
  %t141 = load ptr, ptr %l59, !tbaa !29
  %t142 = call ptr @__olang_scope_or(ptr %v3, ptr %t141)
  %t143 = call ptr @__olang_scope_hold(ptr %t142)
  %t144 = ptrtoint ptr %t143 to i64
  %t146 = inttoptr i64 %t144 to ptr
  %t147 = load ptr, ptr %l59, !tbaa !29
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t146, ptr %t147, i32 %t140)
  store i1 %t149, ptr %l62
  br label %bb25
bb25:
  %t150 = load i1, ptr %l62, !tbaa !21
  %t151 = xor i1 %t150, true
  br i1 %t151, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t153 = call ptr @__olang_scope_hold(ptr %s0)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l64, !tbaa !24
  %t155 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e6
  br i1 %t155, label %bb28, label %bb29
bb27:
  br label %bb47
bb28:
  %t157 = call ptr @__olang_region_make(ptr %s0)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l64, !tbaa !24
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d424, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d424, i32 0, i32 1) }, 0
  %t164 = extractvalue { i64, ptr } %t160, 1
  %t165 = extractvalue { i64, ptr } %t160, 0
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t161, i64 %t162)
  %t171 = getelementptr i8, ptr %t170, i64 %t162
  call void @olang_textcopy(ptr %t171, ptr %t164, i64 %t165)
  %t172 = getelementptr i8, ptr %t171, i64 %t165
  call void @olang_textcopy(ptr %t172, ptr %t167, i64 %t168)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t170, 1
  %t176 = load i64, ptr %l64
  %t177 = inttoptr i64 %t176 to ptr
  %t180 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %t177, ptr %v3, ptr %t159, { i64, ptr } %t174)
  store { i64, ptr } %t180, ptr %l70
  br label %bb30
bb30:
  %t181 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e6
  br i1 %t181, label %bb31, label %bb32
bb31:
  %t183 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  %t186 = icmp eq i64 %t184, 0
  br i1 %t186, label %bb33, label %bb34
bb32:
  %t188 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t188, ptr %l74, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t189, ptr %l6, !tbaa !27
  %t190 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e6
  br i1 %t190, label %bb35, label %bb36
bb33:
  store { i64, ptr } zeroinitializer, ptr %l70, !tbaa !27
  br label %bb34
bb34:
  %t192 = load i64, ptr %l64
  %t193 = inttoptr i64 %t192 to ptr
  %t194 = load { i64, ptr }, ptr %l70
  %t195 = extractvalue { i64, ptr } %t194, 1
  %t196 = call ptr @__olang_region_or(ptr %t195, ptr null)
  %t197 = icmp ne ptr %t196, null
  %t198 = select i1 %t197, ptr %t196, ptr null
  call void @__olang_region_settle_in(ptr %t193, ptr %t198)
  br label %bb32
bb35:
  %t199 = load { i64, ptr }, ptr %l74
  %t200 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release(ptr %t200)
  store { i64, ptr } zeroinitializer, ptr %l74
  br label %bb36
bb36:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t203 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t206 = extractvalue { i64, ptr } %t202, 1
  %t207 = extractvalue { i64, ptr } %t202, 0
  %t208 = add i64 %t204, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t203, i64 %t204)
  %t210 = getelementptr i8, ptr %t209, i64 %t204
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t209, 1
  %t216 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %s4, ptr %v3, ptr %t201, { i64, ptr } %t212)
  store { i64, ptr } %t216, ptr %l80
  br label %bb37
bb37:
  %t217 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t217, ptr %l8, !tbaa !27
  %t218 = call ptr @__olang_scope_hold(ptr %s0)
  %t219 = ptrtoint ptr %t218 to i64
  store i64 %t219, ptr %l81, !tbaa !24
  %t220 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e7
  br i1 %t220, label %bb38, label %bb39
bb38:
  %t222 = call ptr @__olang_region_make(ptr %s0)
  %t223 = ptrtoint ptr %t222 to i64
  store i64 %t223, ptr %l81, !tbaa !24
  br label %bb39
bb39:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t228 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t231 = extractvalue { i64, ptr } %t225, 1
  %t232 = extractvalue { i64, ptr } %t225, 0
  %t233 = add i64 %t229, %t232
  %t234 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t236 = add i64 %t233, %t235
  %t238 = extractvalue { i64, ptr } %t226, 1
  %t239 = extractvalue { i64, ptr } %t226, 0
  %t240 = add i64 %t236, %t239
  %t241 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t243 = add i64 %t240, %t242
  %t245 = extractvalue { i64, ptr } %t227, 1
  %t246 = extractvalue { i64, ptr } %t227, 0
  %t247 = add i64 %t243, %t246
  %t248 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t247)
  call void @olang_textcopy(ptr %t248, ptr %t228, i64 %t229)
  %t249 = getelementptr i8, ptr %t248, i64 %t229
  call void @olang_textcopy(ptr %t249, ptr %t231, i64 %t232)
  %t250 = getelementptr i8, ptr %t249, i64 %t232
  call void @olang_textcopy(ptr %t250, ptr %t234, i64 %t235)
  %t251 = getelementptr i8, ptr %t250, i64 %t235
  call void @olang_textcopy(ptr %t251, ptr %t238, i64 %t239)
  %t252 = getelementptr i8, ptr %t251, i64 %t239
  call void @olang_textcopy(ptr %t252, ptr %t241, i64 %t242)
  %t253 = getelementptr i8, ptr %t252, i64 %t242
  call void @olang_textcopy(ptr %t253, ptr %t245, i64 %t246)
  %t254 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t248, 1
  %t257 = load i64, ptr %l81
  %t258 = inttoptr i64 %t257 to ptr
  %t261 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %t258, ptr %v3, ptr %t224, { i64, ptr } %t255)
  store { i64, ptr } %t261, ptr %l89
  br label %bb40
bb40:
  %t262 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e7
  br i1 %t262, label %bb41, label %bb42
bb41:
  %t264 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  %t267 = icmp eq i64 %t265, 0
  br i1 %t267, label %bb43, label %bb44
bb42:
  %t269 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t269, ptr %l93, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t270, ptr %l7, !tbaa !27
  %t271 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e7
  br i1 %t271, label %bb45, label %bb46
bb43:
  store { i64, ptr } zeroinitializer, ptr %l89, !tbaa !27
  br label %bb44
bb44:
  %t273 = load i64, ptr %l81
  %t274 = inttoptr i64 %t273 to ptr
  %t275 = load { i64, ptr }, ptr %l89
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = call ptr @__olang_region_or(ptr %t276, ptr null)
  %t278 = icmp ne ptr %t277, null
  %t279 = select i1 %t278, ptr %t277, ptr null
  call void @__olang_region_settle_in(ptr %t274, ptr %t279)
  br label %bb42
bb45:
  %t280 = load { i64, ptr }, ptr %l93
  %t281 = extractvalue { i64, ptr } %t280, 1
  call void @__olang_region_release(ptr %t281)
  store { i64, ptr } zeroinitializer, ptr %l93
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb47:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/emit:fnEm", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  store ptr %t285, ptr %l96, !tbaa !29
  %t286 = load ptr, ptr %l96, !tbaa !29
  %t287 = call ptr @__olang_scope_or(ptr %v3, ptr %t286)
  %t288 = call ptr @__olang_scope_hold(ptr %t287)
  %t289 = ptrtoint ptr %t288 to i64
  %t291 = inttoptr i64 %t289 to ptr
  %t292 = load ptr, ptr %l96, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t291, ptr %s0, ptr %s0, ptr %t292, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d429, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d430, i32 0, i32 1) })
  br label %bb48
bb48:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t295 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t298 = extractvalue { i64, ptr } %t294, 1
  %t299 = extractvalue { i64, ptr } %t294, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t298, i64 %t299)
  %t306 = getelementptr i8, ptr %t305, i64 %t299
  call void @olang_textcopy(ptr %t306, ptr %t301, i64 %t302)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t304, 1
  %t312 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t293, { i64, ptr } %t308)
  store { i64, ptr } %t312, ptr %l102
  br label %bb49
bb49:
  %t313 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t319 = extractvalue { i64, ptr } %t313, 1
  %t320 = extractvalue { i64, ptr } %t313, 0
  %t321 = add i64 %t317, %t320
  %t322 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @olang_textcopy(ptr %t325, ptr %t316, i64 %t317)
  %t326 = getelementptr i8, ptr %t325, i64 %t317
  call void @olang_textcopy(ptr %t326, ptr %t319, i64 %t320)
  %t327 = getelementptr i8, ptr %t326, i64 %t320
  call void @olang_textcopy(ptr %t327, ptr %t322, i64 %t323)
  %t328 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t325, 1
  %t333 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t314, { i64, ptr } %t329)
  store { i64, ptr } %t333, ptr %l107
  br label %bb50
bb50:
  %t334 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d435, i32 0, i32 1) }, 1
  %t338 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d435, i32 0, i32 1) }, 0
  %t340 = extractvalue { i64, ptr } %t334, 1
  %t341 = extractvalue { i64, ptr } %t334, 0
  %t342 = add i64 %t338, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t337, i64 %t338)
  %t344 = getelementptr i8, ptr %t343, i64 %t338
  call void @olang_textcopy(ptr %t344, ptr %t340, i64 %t341)
  %t345 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t343, 1
  %t350 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t335, { i64, ptr } %t346)
  store { i64, ptr } %t350, ptr %l112
  br label %bb51
bb51:
  %t351 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t351, ptr %l11, !tbaa !27
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t354 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t357 = extractvalue { i64, ptr } %t353, 1
  %t358 = extractvalue { i64, ptr } %t353, 0
  %t359 = add i64 %t355, %t358
  %t360 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t362 = add i64 %t359, %t361
  %t363 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t362)
  call void @olang_textcopy(ptr %t363, ptr %t354, i64 %t355)
  %t364 = getelementptr i8, ptr %t363, i64 %t355
  call void @olang_textcopy(ptr %t364, ptr %t357, i64 %t358)
  %t365 = getelementptr i8, ptr %t364, i64 %t358
  call void @olang_textcopy(ptr %t365, ptr %t360, i64 %t361)
  %t366 = insertvalue { i64, ptr } undef, i64 %t362, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t363, 1
  %t371 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t352, { i64, ptr } %t367)
  store { i64, ptr } %t371, ptr %l117
  br label %bb52
bb52:
  %t372 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t376 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t379 = extractvalue { i64, ptr } %t372, 1
  %t380 = extractvalue { i64, ptr } %t372, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t386 = extractvalue { i64, ptr } %t375, 1
  %t387 = extractvalue { i64, ptr } %t375, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t390 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t391 = add i64 %t388, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t376, i64 %t377)
  %t393 = getelementptr i8, ptr %t392, i64 %t377
  call void @olang_textcopy(ptr %t393, ptr %t379, i64 %t380)
  %t394 = getelementptr i8, ptr %t393, i64 %t380
  call void @olang_textcopy(ptr %t394, ptr %t382, i64 %t383)
  %t395 = getelementptr i8, ptr %t394, i64 %t383
  call void @olang_textcopy(ptr %t395, ptr %t386, i64 %t387)
  %t396 = getelementptr i8, ptr %t395, i64 %t387
  call void @olang_textcopy(ptr %t396, ptr %t389, i64 %t390)
  %t397 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t392, 1
  %t402 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t373, { i64, ptr } %t398)
  store { i64, ptr } %t402, ptr %l123
  br label %bb53
bb53:
  %t403 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t403, ptr %l13, !tbaa !27
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l124, !tbaa !29
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t407 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t410 = extractvalue { i64, ptr } %t406, 1
  %t411 = extractvalue { i64, ptr } %t406, 0
  %t412 = add i64 %t408, %t411
  %t413 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t412)
  call void @olang_textcopy(ptr %t413, ptr %t407, i64 %t408)
  %t414 = getelementptr i8, ptr %t413, i64 %t408
  call void @olang_textcopy(ptr %t414, ptr %t410, i64 %t411)
  %t415 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t413, 1
  %t420 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t405, { i64, ptr } %t416)
  store { i64, ptr } %t420, ptr %l129
  br label %bb54
bb54:
  %t421 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t422 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t423 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 1
  %t425 = extractvalue { i64, ptr } %t423, 0
  %t426 = add i64 %t422, %t425
  %t427 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t428 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t429 = add i64 %t426, %t428
  %t430 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t429)
  call void @olang_textcopy(ptr %t430, ptr %t421, i64 %t422)
  %t431 = getelementptr i8, ptr %t430, i64 %t422
  call void @olang_textcopy(ptr %t431, ptr %t424, i64 %t425)
  %t432 = getelementptr i8, ptr %t431, i64 %t425
  call void @olang_textcopy(ptr %t432, ptr %t427, i64 %t428)
  %t433 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t430, 1
  %t436 = load ptr, ptr %l124, !tbaa !29
  %t438 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t436, { i64, ptr } %t434)
  store { i64, ptr } %t438, ptr %l132
  br label %bb55
bb55:
  %t439 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l133, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t444 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d444, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d444, i32 0, i32 1) }, 0
  %t447 = extractvalue { i64, ptr } %t442, 1
  %t448 = extractvalue { i64, ptr } %t442, 0
  %t449 = add i64 %t445, %t448
  %t450 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d445, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d445, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t454 = extractvalue { i64, ptr } %t439, 1
  %t455 = extractvalue { i64, ptr } %t439, 0
  %t456 = add i64 %t452, %t455
  %t457 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t456)
  call void @olang_textcopy(ptr %t457, ptr %t444, i64 %t445)
  %t458 = getelementptr i8, ptr %t457, i64 %t445
  call void @olang_textcopy(ptr %t458, ptr %t447, i64 %t448)
  %t459 = getelementptr i8, ptr %t458, i64 %t448
  call void @olang_textcopy(ptr %t459, ptr %t450, i64 %t451)
  %t460 = getelementptr i8, ptr %t459, i64 %t451
  call void @olang_textcopy(ptr %t460, ptr %t454, i64 %t455)
  %t461 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t457, 1
  %t466 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t441, { i64, ptr } %t462)
  store { i64, ptr } %t466, ptr %l139
  br label %bb56
bb56:
  %t467 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t469 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t469, 1
  %t471 = extractvalue { i64, ptr } %t469, 0
  %t472 = add i64 %t468, %t471
  %t473 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t474 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t475 = add i64 %t472, %t474
  %t476 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t475)
  call void @olang_textcopy(ptr %t476, ptr %t467, i64 %t468)
  %t477 = getelementptr i8, ptr %t476, i64 %t468
  call void @olang_textcopy(ptr %t477, ptr %t470, i64 %t471)
  %t478 = getelementptr i8, ptr %t477, i64 %t471
  call void @olang_textcopy(ptr %t478, ptr %t473, i64 %t474)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t476, 1
  %t482 = load ptr, ptr %l133, !tbaa !29
  %t484 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t482, { i64, ptr } %t480)
  store { i64, ptr } %t484, ptr %l142
  br label %bb57
bb57:
  %t485 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t485, ptr %l15, !tbaa !27
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l143, !tbaa !29
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l144, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t490 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t491 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t492 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t494 = extractvalue { i64, ptr } %t489, 1
  %t495 = extractvalue { i64, ptr } %t489, 0
  %t496 = add i64 %t492, %t495
  %t497 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t498 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t499 = add i64 %t496, %t498
  %t501 = extractvalue { i64, ptr } %t490, 1
  %t502 = extractvalue { i64, ptr } %t490, 0
  %t503 = add i64 %t499, %t502
  %t504 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t503)
  call void @olang_textcopy(ptr %t504, ptr %t491, i64 %t492)
  %t505 = getelementptr i8, ptr %t504, i64 %t492
  call void @olang_textcopy(ptr %t505, ptr %t494, i64 %t495)
  %t506 = getelementptr i8, ptr %t505, i64 %t495
  call void @olang_textcopy(ptr %t506, ptr %t497, i64 %t498)
  %t507 = getelementptr i8, ptr %t506, i64 %t498
  call void @olang_textcopy(ptr %t507, ptr %t501, i64 %t502)
  %t508 = insertvalue { i64, ptr } undef, i64 %t503, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t504, 1
  %t513 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t488, { i64, ptr } %t509)
  store { i64, ptr } %t513, ptr %l150
  br label %bb58
bb58:
  %t514 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t515 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  %t516 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 1
  %t518 = extractvalue { i64, ptr } %t516, 0
  %t519 = add i64 %t515, %t518
  %t520 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t521 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t522 = add i64 %t519, %t521
  %t523 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t522)
  call void @olang_textcopy(ptr %t523, ptr %t514, i64 %t515)
  %t524 = getelementptr i8, ptr %t523, i64 %t515
  call void @olang_textcopy(ptr %t524, ptr %t517, i64 %t518)
  %t525 = getelementptr i8, ptr %t524, i64 %t518
  call void @olang_textcopy(ptr %t525, ptr %t520, i64 %t521)
  %t526 = insertvalue { i64, ptr } undef, i64 %t522, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t523, 1
  %t529 = load ptr, ptr %l144, !tbaa !29
  %t531 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t529, { i64, ptr } %t527)
  store { i64, ptr } %t531, ptr %l153
  br label %bb59
bb59:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t534 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t535 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t537 = extractvalue { i64, ptr } %t533, 1
  %t538 = extractvalue { i64, ptr } %t533, 0
  %t539 = add i64 %t535, %t538
  %t540 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t541 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t542 = add i64 %t539, %t541
  %t543 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t542)
  call void @olang_textcopy(ptr %t543, ptr %t534, i64 %t535)
  %t544 = getelementptr i8, ptr %t543, i64 %t535
  call void @olang_textcopy(ptr %t544, ptr %t537, i64 %t538)
  %t545 = getelementptr i8, ptr %t544, i64 %t538
  call void @olang_textcopy(ptr %t545, ptr %t540, i64 %t541)
  %t546 = insertvalue { i64, ptr } undef, i64 %t542, 0
  %t547 = insertvalue { i64, ptr } %t546, ptr %t543, 1
  %t551 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t532, { i64, ptr } %t547)
  store { i64, ptr } %t551, ptr %l158
  br label %bb60
bb60:
  %t552 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t554 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = add i64 %t553, %t556
  %t558 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t560 = add i64 %t557, %t559
  %t561 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = add i64 %t560, %t563
  %t565 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t564)
  call void @olang_textcopy(ptr %t565, ptr %t552, i64 %t553)
  %t566 = getelementptr i8, ptr %t565, i64 %t553
  call void @olang_textcopy(ptr %t566, ptr %t555, i64 %t556)
  %t567 = getelementptr i8, ptr %t566, i64 %t556
  call void @olang_textcopy(ptr %t567, ptr %t558, i64 %t559)
  %t568 = getelementptr i8, ptr %t567, i64 %t559
  call void @olang_textcopy(ptr %t568, ptr %t562, i64 %t563)
  %t569 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t570 = insertvalue { i64, ptr } %t569, ptr %t565, 1
  %t572 = load ptr, ptr %l143, !tbaa !29
  %t574 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t572, { i64, ptr } %t570)
  store { i64, ptr } %t574, ptr %l161
  br label %bb61
bb61:
  %t575 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t575, ptr %l16, !tbaa !27
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/emit:fnEm", ptr %t576, i32 0, i32 0
  %t579 = load ptr, ptr %t578, !tbaa !29
  store ptr %t579, ptr %l163, !tbaa !29
  %t580 = load ptr, ptr %l163, !tbaa !29
  %t581 = call ptr @__olang_scope_or(ptr %v3, ptr %t580)
  %t582 = call ptr @__olang_scope_hold(ptr %t581)
  %t583 = ptrtoint ptr %t582 to i64
  %t585 = inttoptr i64 %t583 to ptr
  %t586 = load ptr, ptr %l163, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t585, ptr %s0, ptr %t586, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d456, i32 0, i32 1) })
  br label %bb62
bb62:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t590 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t591 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t593 = extractvalue { i64, ptr } %t588, 1
  %t594 = extractvalue { i64, ptr } %t588, 0
  %t595 = add i64 %t591, %t594
  %t596 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t597 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t598 = add i64 %t595, %t597
  %t600 = extractvalue { i64, ptr } %t589, 1
  %t601 = extractvalue { i64, ptr } %t589, 0
  %t602 = add i64 %t598, %t601
  %t603 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t604 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t605 = add i64 %t602, %t604
  %t606 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t605)
  call void @olang_textcopy(ptr %t606, ptr %t590, i64 %t591)
  %t607 = getelementptr i8, ptr %t606, i64 %t591
  call void @olang_textcopy(ptr %t607, ptr %t593, i64 %t594)
  %t608 = getelementptr i8, ptr %t607, i64 %t594
  call void @olang_textcopy(ptr %t608, ptr %t596, i64 %t597)
  %t609 = getelementptr i8, ptr %t608, i64 %t597
  call void @olang_textcopy(ptr %t609, ptr %t600, i64 %t601)
  %t610 = getelementptr i8, ptr %t609, i64 %t601
  call void @olang_textcopy(ptr %t610, ptr %t603, i64 %t604)
  %t611 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t612 = insertvalue { i64, ptr } %t611, ptr %t606, 1
  %t616 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t587, { i64, ptr } %t612)
  store { i64, ptr } %t616, ptr %l170
  br label %bb63
bb63:
  %t617 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t617, ptr %l17, !tbaa !27
  %t618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t618, ptr %l171, !tbaa !29
  %t619 = load ptr, ptr %l0, !tbaa !29
  store ptr %t619, ptr %l172, !tbaa !29
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t621 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t622 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d460, i32 0, i32 1) }, 1
  %t623 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d460, i32 0, i32 1) }, 0
  %t625 = extractvalue { i64, ptr } %t621, 1
  %t626 = extractvalue { i64, ptr } %t621, 0
  %t627 = add i64 %t623, %t626
  %t628 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d461, i32 0, i32 1) }, 1
  %t629 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d461, i32 0, i32 1) }, 0
  %t630 = add i64 %t627, %t629
  %t631 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t630)
  call void @olang_textcopy(ptr %t631, ptr %t622, i64 %t623)
  %t632 = getelementptr i8, ptr %t631, i64 %t623
  call void @olang_textcopy(ptr %t632, ptr %t625, i64 %t626)
  %t633 = getelementptr i8, ptr %t632, i64 %t626
  call void @olang_textcopy(ptr %t633, ptr %t628, i64 %t629)
  %t634 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t631, 1
  %t639 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t620, { i64, ptr } %t635)
  store { i64, ptr } %t639, ptr %l177
  br label %bb64
bb64:
  %t640 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d462, i32 0, i32 1) }, 1
  %t641 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d462, i32 0, i32 1) }, 0
  %t642 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t643 = extractvalue { i64, ptr } %t642, 1
  %t644 = extractvalue { i64, ptr } %t642, 0
  %t645 = add i64 %t641, %t644
  %t646 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t647 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t648 = add i64 %t645, %t647
  %t649 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t648)
  call void @olang_textcopy(ptr %t649, ptr %t640, i64 %t641)
  %t650 = getelementptr i8, ptr %t649, i64 %t641
  call void @olang_textcopy(ptr %t650, ptr %t643, i64 %t644)
  %t651 = getelementptr i8, ptr %t650, i64 %t644
  call void @olang_textcopy(ptr %t651, ptr %t646, i64 %t647)
  %t652 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t649, 1
  %t655 = load ptr, ptr %l172, !tbaa !29
  %t657 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t655, { i64, ptr } %t653)
  store { i64, ptr } %t657, ptr %l180
  br label %bb65
bb65:
  %t658 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t659 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t660 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t660, 1
  %t662 = extractvalue { i64, ptr } %t660, 0
  %t663 = add i64 %t659, %t662
  %t664 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t665 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t666 = add i64 %t663, %t665
  %t667 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t666)
  call void @olang_textcopy(ptr %t667, ptr %t658, i64 %t659)
  %t668 = getelementptr i8, ptr %t667, i64 %t659
  call void @olang_textcopy(ptr %t668, ptr %t661, i64 %t662)
  %t669 = getelementptr i8, ptr %t668, i64 %t662
  call void @olang_textcopy(ptr %t669, ptr %t664, i64 %t665)
  %t670 = insertvalue { i64, ptr } undef, i64 %t666, 0
  %t671 = insertvalue { i64, ptr } %t670, ptr %t667, 1
  %t673 = load ptr, ptr %l171, !tbaa !29
  %t675 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t673, { i64, ptr } %t671)
  store { i64, ptr } %t675, ptr %l183
  br label %bb66
bb66:
  %t676 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t679 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t680 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t682 = extractvalue { i64, ptr } %t676, 1
  %t683 = extractvalue { i64, ptr } %t676, 0
  %t684 = add i64 %t680, %t683
  %t685 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t686 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t687 = add i64 %t684, %t686
  %t688 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t687)
  call void @olang_textcopy(ptr %t688, ptr %t679, i64 %t680)
  %t689 = getelementptr i8, ptr %t688, i64 %t680
  call void @olang_textcopy(ptr %t689, ptr %t682, i64 %t683)
  %t690 = getelementptr i8, ptr %t689, i64 %t683
  call void @olang_textcopy(ptr %t690, ptr %t685, i64 %t686)
  %t691 = insertvalue { i64, ptr } undef, i64 %t687, 0
  %t692 = insertvalue { i64, ptr } %t691, ptr %t688, 1
  %t696 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t677, { i64, ptr } %t692)
  store { i64, ptr } %t696, ptr %l188
  br label %bb67
bb67:
  %t697 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t697, ptr %l19, !tbaa !27
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l189, !tbaa !29
  %t699 = load ptr, ptr %l0, !tbaa !29
  store ptr %t699, ptr %l190, !tbaa !29
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t701 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t704 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %v3, ptr %t700, { i64, ptr } %t701, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d468, i32 0, i32 1) })
  store { i64, ptr } %t704, ptr %l193
  br label %bb68
bb68:
  %t705 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t706 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d469, i32 0, i32 1) }, 1
  %t707 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d469, i32 0, i32 1) }, 0
  %t708 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t709 = extractvalue { i64, ptr } %t708, 1
  %t710 = extractvalue { i64, ptr } %t708, 0
  %t711 = add i64 %t707, %t710
  %t712 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d470, i32 0, i32 1) }, 1
  %t713 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d470, i32 0, i32 1) }, 0
  %t714 = add i64 %t711, %t713
  %t716 = extractvalue { i64, ptr } %t705, 1
  %t717 = extractvalue { i64, ptr } %t705, 0
  %t718 = add i64 %t714, %t717
  %t719 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t718)
  call void @olang_textcopy(ptr %t719, ptr %t706, i64 %t707)
  %t720 = getelementptr i8, ptr %t719, i64 %t707
  call void @olang_textcopy(ptr %t720, ptr %t709, i64 %t710)
  %t721 = getelementptr i8, ptr %t720, i64 %t710
  call void @olang_textcopy(ptr %t721, ptr %t712, i64 %t713)
  %t722 = getelementptr i8, ptr %t721, i64 %t713
  call void @olang_textcopy(ptr %t722, ptr %t716, i64 %t717)
  %t723 = insertvalue { i64, ptr } undef, i64 %t718, 0
  %t724 = insertvalue { i64, ptr } %t723, ptr %t719, 1
  %t726 = load ptr, ptr %l190, !tbaa !29
  %t728 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t726, { i64, ptr } %t724)
  store { i64, ptr } %t728, ptr %l197
  br label %bb69
bb69:
  %t729 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t730 = load ptr, ptr %l189, !tbaa !29
  %t732 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enarrowBF16(ptr %v0, ptr %s0, ptr %v2, ptr %v3, ptr %t730, { i64, ptr } %t729)
  store { i64, ptr } %t732, ptr %l199
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t733 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t733, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2edotsSteps(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, i64 %a5, { i64, ptr } %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l108 = alloca i64
  %l111 = alloca i64
  %l165 = alloca i64
  %l169 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l192 = alloca i1
  %l193 = alloca i1
  %l205 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l225 = alloca i1
  %l226 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a5, ptr %l5
  store ptr %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d471, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d471, i32 0, i32 1) }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t1)
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t12 = extractvalue { i64, ptr } %t2, 1
  %t13 = extractvalue { i64, ptr } %t2, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d473, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d473, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t3, i64 %t4)
  %t19 = getelementptr i8, ptr %t18, i64 %t4
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t1)
  %t21 = getelementptr i8, ptr %t19, i64 %t6
  call void @olang_textcopy(ptr %t21, ptr %t8, i64 %t9)
  %t22 = getelementptr i8, ptr %t21, i64 %t9
  call void @olang_textcopy(ptr %t22, ptr %t12, i64 %t13)
  %t23 = getelementptr i8, ptr %t22, i64 %t13
  call void @olang_textcopy(ptr %t23, ptr %t15, i64 %t16)
  %t24 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t18, 1
  store { i64, ptr } %t25, ptr %l8, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t28)
  %t33 = add i64 %t30, %t32
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d475, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d475, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t29, i64 %t30)
  %t38 = getelementptr i8, ptr %t37, i64 %t30
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t28)
  %t40 = getelementptr i8, ptr %t38, i64 %t32
  call void @olang_textcopy(ptr %t40, ptr %t34, i64 %t35)
  %t41 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t37, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t27, { i64, ptr } %t42)
  br label %bb1
bb1:
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t46, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d476, i32 0, i32 1) })
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t49 = insertvalue [2 x { i64, ptr }] %t48, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d478, i32 0, i32 1) }, 1
  %t51 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store [2 x { i64, ptr }] %t49, ptr %t51
  store ptr %t51, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t53 = load ptr, ptr %l9
  store i64 2, ptr %l11, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l11, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb5:
  br label %bb6
bb6:
  %t64 = load ptr, ptr %l9
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = getelementptr [2 x { i64, ptr }], ptr %t64, i64 0, i64 %t65
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !37
  store { i64, ptr } %t69, ptr %l12, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d479, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d479, i32 0, i32 1) }, 0
  %t75 = extractvalue { i64, ptr } %t71, 1
  %t76 = extractvalue { i64, ptr } %t71, 0
  %t77 = add i64 %t73, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t72, i64 %t73)
  %t79 = getelementptr i8, ptr %t78, i64 %t73
  call void @olang_textcopy(ptr %t79, ptr %t75, i64 %t76)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l13, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t84 = load ptr, ptr @__olang_prog_scope
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t84, ptr %s4, { i64, ptr } %t83, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d480, i32 0, i32 1) })
  store i1 %t86, ptr %l54
  br label %bb7
bb7:
  %t87 = load i1, ptr %l54, !tbaa !21
  br i1 %t87, label %bb8, label %bb9
bb8:
  %t88 = load ptr, ptr %l7, !tbaa !29
  %t90 = getelementptr %"compiler/emit:laneTags", ptr %t88, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l55, !tbaa !27
  br label %bb10
bb9:
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t95 = getelementptr %"compiler/emit:laneTags", ptr %t93, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l55, !tbaa !27
  br label %bb10
bb10:
  %t98 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t98, ptr %l14, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t100 = load ptr, ptr @__olang_prog_scope
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t100, ptr %s4, { i64, ptr } %t99, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d481, i32 0, i32 1) })
  store i1 %t102, ptr %l61
  br label %bb11
bb11:
  %t103 = load i1, ptr %l61, !tbaa !21
  br i1 %t103, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d482, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d483, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb14
bb14:
  %t104 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t104, ptr %l15, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t110 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d484, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d484, i32 0, i32 1) }, 0
  %t113 = extractvalue { i64, ptr } %t106, 1
  %t114 = extractvalue { i64, ptr } %t106, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t120 = extractvalue { i64, ptr } %t107, 1
  %t121 = extractvalue { i64, ptr } %t107, 0
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t127 = extractvalue { i64, ptr } %t108, 1
  %t128 = extractvalue { i64, ptr } %t108, 0
  %t129 = add i64 %t125, %t128
  %t130 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t134 = extractvalue { i64, ptr } %t109, 1
  %t135 = extractvalue { i64, ptr } %t109, 0
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d488, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d488, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t110, i64 %t111)
  %t141 = getelementptr i8, ptr %t140, i64 %t111
  call void @olang_textcopy(ptr %t141, ptr %t113, i64 %t114)
  %t142 = getelementptr i8, ptr %t141, i64 %t114
  call void @olang_textcopy(ptr %t142, ptr %t116, i64 %t117)
  %t143 = getelementptr i8, ptr %t142, i64 %t117
  call void @olang_textcopy(ptr %t143, ptr %t120, i64 %t121)
  %t144 = getelementptr i8, ptr %t143, i64 %t121
  call void @olang_textcopy(ptr %t144, ptr %t123, i64 %t124)
  %t145 = getelementptr i8, ptr %t144, i64 %t124
  call void @olang_textcopy(ptr %t145, ptr %t127, i64 %t128)
  %t146 = getelementptr i8, ptr %t145, i64 %t128
  call void @olang_textcopy(ptr %t146, ptr %t130, i64 %t131)
  %t147 = getelementptr i8, ptr %t146, i64 %t131
  call void @olang_textcopy(ptr %t147, ptr %t134, i64 %t135)
  %t148 = getelementptr i8, ptr %t147, i64 %t135
  call void @olang_textcopy(ptr %t148, ptr %t137, i64 %t138)
  %t149 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t140, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t105, { i64, ptr } %t150)
  br label %bb15
bb15:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t157 = load i64, ptr %l5, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t159 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d489, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d489, i32 0, i32 1) }, 0
  %t162 = extractvalue { i64, ptr } %t155, 1
  %t163 = extractvalue { i64, ptr } %t155, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t169 = extractvalue { i64, ptr } %t156, 1
  %t170 = extractvalue { i64, ptr } %t156, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d491, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d491, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t157)
  %t177 = add i64 %t174, %t176
  %t179 = extractvalue { i64, ptr } %t158, 1
  %t180 = extractvalue { i64, ptr } %t158, 0
  %t181 = add i64 %t177, %t180
  %t182 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d492, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d492, i32 0, i32 1) }, 0
  %t184 = add i64 %t181, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t159, i64 %t160)
  %t186 = getelementptr i8, ptr %t185, i64 %t160
  call void @olang_textcopy(ptr %t186, ptr %t162, i64 %t163)
  %t187 = getelementptr i8, ptr %t186, i64 %t163
  call void @olang_textcopy(ptr %t187, ptr %t165, i64 %t166)
  %t188 = getelementptr i8, ptr %t187, i64 %t166
  call void @olang_textcopy(ptr %t188, ptr %t169, i64 %t170)
  %t189 = getelementptr i8, ptr %t188, i64 %t170
  call void @olang_textcopy(ptr %t189, ptr %t172, i64 %t173)
  %t190 = getelementptr i8, ptr %t189, i64 %t173
  %t191 = call i64 @__olang_fmt_i64(ptr %t190, i64 %t157)
  %t192 = getelementptr i8, ptr %t190, i64 %t176
  call void @olang_textcopy(ptr %t192, ptr %t179, i64 %t180)
  %t193 = getelementptr i8, ptr %t192, i64 %t180
  call void @olang_textcopy(ptr %t193, ptr %t182, i64 %t183)
  %t194 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t185, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t154, { i64, ptr } %t195)
  br label %bb16
bb16:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t203 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  %t206 = extractvalue { i64, ptr } %t200, 1
  %t207 = extractvalue { i64, ptr } %t200, 0
  %t208 = add i64 %t204, %t207
  %t209 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d494, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d494, i32 0, i32 1) }, 0
  %t211 = add i64 %t208, %t210
  %t213 = extractvalue { i64, ptr } %t201, 1
  %t214 = extractvalue { i64, ptr } %t201, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t220 = extractvalue { i64, ptr } %t202, 1
  %t221 = extractvalue { i64, ptr } %t202, 0
  %t222 = add i64 %t218, %t221
  %t223 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d496, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d496, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t203, i64 %t204)
  %t227 = getelementptr i8, ptr %t226, i64 %t204
  call void @olang_textcopy(ptr %t227, ptr %t206, i64 %t207)
  %t228 = getelementptr i8, ptr %t227, i64 %t207
  call void @olang_textcopy(ptr %t228, ptr %t209, i64 %t210)
  %t229 = getelementptr i8, ptr %t228, i64 %t210
  call void @olang_textcopy(ptr %t229, ptr %t213, i64 %t214)
  %t230 = getelementptr i8, ptr %t229, i64 %t214
  call void @olang_textcopy(ptr %t230, ptr %t216, i64 %t217)
  %t231 = getelementptr i8, ptr %t230, i64 %t217
  call void @olang_textcopy(ptr %t231, ptr %t220, i64 %t221)
  %t232 = getelementptr i8, ptr %t231, i64 %t221
  call void @olang_textcopy(ptr %t232, ptr %t223, i64 %t224)
  %t233 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t226, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t199, { i64, ptr } %t234)
  br label %bb17
bb17:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t244 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d497, i32 0, i32 1) }, 1
  %t245 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d497, i32 0, i32 1) }, 0
  %t247 = extractvalue { i64, ptr } %t239, 1
  %t248 = extractvalue { i64, ptr } %t239, 0
  %t249 = add i64 %t245, %t248
  %t250 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d498, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d498, i32 0, i32 1) }, 0
  %t252 = add i64 %t249, %t251
  %t254 = extractvalue { i64, ptr } %t240, 1
  %t255 = extractvalue { i64, ptr } %t240, 0
  %t256 = add i64 %t252, %t255
  %t257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d499, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d499, i32 0, i32 1) }, 0
  %t259 = add i64 %t256, %t258
  %t261 = extractvalue { i64, ptr } %t241, 1
  %t262 = extractvalue { i64, ptr } %t241, 0
  %t263 = add i64 %t259, %t262
  %t264 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  %t266 = add i64 %t263, %t265
  %t268 = extractvalue { i64, ptr } %t242, 1
  %t269 = extractvalue { i64, ptr } %t242, 0
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d501, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d501, i32 0, i32 1) }, 0
  %t273 = add i64 %t270, %t272
  %t275 = extractvalue { i64, ptr } %t243, 1
  %t276 = extractvalue { i64, ptr } %t243, 0
  %t277 = add i64 %t273, %t276
  %t278 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d502, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d502, i32 0, i32 1) }, 0
  %t280 = add i64 %t277, %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t280)
  call void @olang_textcopy(ptr %t281, ptr %t244, i64 %t245)
  %t282 = getelementptr i8, ptr %t281, i64 %t245
  call void @olang_textcopy(ptr %t282, ptr %t247, i64 %t248)
  %t283 = getelementptr i8, ptr %t282, i64 %t248
  call void @olang_textcopy(ptr %t283, ptr %t250, i64 %t251)
  %t284 = getelementptr i8, ptr %t283, i64 %t251
  call void @olang_textcopy(ptr %t284, ptr %t254, i64 %t255)
  %t285 = getelementptr i8, ptr %t284, i64 %t255
  call void @olang_textcopy(ptr %t285, ptr %t257, i64 %t258)
  %t286 = getelementptr i8, ptr %t285, i64 %t258
  call void @olang_textcopy(ptr %t286, ptr %t261, i64 %t262)
  %t287 = getelementptr i8, ptr %t286, i64 %t262
  call void @olang_textcopy(ptr %t287, ptr %t264, i64 %t265)
  %t288 = getelementptr i8, ptr %t287, i64 %t265
  call void @olang_textcopy(ptr %t288, ptr %t268, i64 %t269)
  %t289 = getelementptr i8, ptr %t288, i64 %t269
  call void @olang_textcopy(ptr %t289, ptr %t271, i64 %t272)
  %t290 = getelementptr i8, ptr %t289, i64 %t272
  call void @olang_textcopy(ptr %t290, ptr %t275, i64 %t276)
  %t291 = getelementptr i8, ptr %t290, i64 %t276
  call void @olang_textcopy(ptr %t291, ptr %t278, i64 %t279)
  %t292 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t281, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t238, { i64, ptr } %t293)
  br label %bb18
bb18:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t305 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  %t308 = extractvalue { i64, ptr } %t298, 1
  %t309 = extractvalue { i64, ptr } %t298, 0
  %t310 = add i64 %t306, %t309
  %t311 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 1
  %t312 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 0
  %t313 = add i64 %t310, %t312
  %t315 = extractvalue { i64, ptr } %t299, 1
  %t316 = extractvalue { i64, ptr } %t299, 0
  %t317 = add i64 %t313, %t316
  %t318 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d505, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d505, i32 0, i32 1) }, 0
  %t320 = add i64 %t317, %t319
  %t322 = extractvalue { i64, ptr } %t300, 1
  %t323 = extractvalue { i64, ptr } %t300, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d506, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d506, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t329 = extractvalue { i64, ptr } %t301, 1
  %t330 = extractvalue { i64, ptr } %t301, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d507, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d507, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t336 = extractvalue { i64, ptr } %t302, 1
  %t337 = extractvalue { i64, ptr } %t302, 0
  %t338 = add i64 %t334, %t337
  %t339 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d508, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d508, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t343 = extractvalue { i64, ptr } %t303, 1
  %t344 = extractvalue { i64, ptr } %t303, 0
  %t345 = add i64 %t341, %t344
  %t346 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d509, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d509, i32 0, i32 1) }, 0
  %t348 = add i64 %t345, %t347
  %t350 = extractvalue { i64, ptr } %t304, 1
  %t351 = extractvalue { i64, ptr } %t304, 0
  %t352 = add i64 %t348, %t351
  %t353 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d510, i32 0, i32 1) }, 1
  %t354 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d510, i32 0, i32 1) }, 0
  %t355 = add i64 %t352, %t354
  %t356 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t355)
  call void @olang_textcopy(ptr %t356, ptr %t305, i64 %t306)
  %t357 = getelementptr i8, ptr %t356, i64 %t306
  call void @olang_textcopy(ptr %t357, ptr %t308, i64 %t309)
  %t358 = getelementptr i8, ptr %t357, i64 %t309
  call void @olang_textcopy(ptr %t358, ptr %t311, i64 %t312)
  %t359 = getelementptr i8, ptr %t358, i64 %t312
  call void @olang_textcopy(ptr %t359, ptr %t315, i64 %t316)
  %t360 = getelementptr i8, ptr %t359, i64 %t316
  call void @olang_textcopy(ptr %t360, ptr %t318, i64 %t319)
  %t361 = getelementptr i8, ptr %t360, i64 %t319
  call void @olang_textcopy(ptr %t361, ptr %t322, i64 %t323)
  %t362 = getelementptr i8, ptr %t361, i64 %t323
  call void @olang_textcopy(ptr %t362, ptr %t325, i64 %t326)
  %t363 = getelementptr i8, ptr %t362, i64 %t326
  call void @olang_textcopy(ptr %t363, ptr %t329, i64 %t330)
  %t364 = getelementptr i8, ptr %t363, i64 %t330
  call void @olang_textcopy(ptr %t364, ptr %t332, i64 %t333)
  %t365 = getelementptr i8, ptr %t364, i64 %t333
  call void @olang_textcopy(ptr %t365, ptr %t336, i64 %t337)
  %t366 = getelementptr i8, ptr %t365, i64 %t337
  call void @olang_textcopy(ptr %t366, ptr %t339, i64 %t340)
  %t367 = getelementptr i8, ptr %t366, i64 %t340
  call void @olang_textcopy(ptr %t367, ptr %t343, i64 %t344)
  %t368 = getelementptr i8, ptr %t367, i64 %t344
  call void @olang_textcopy(ptr %t368, ptr %t346, i64 %t347)
  %t369 = getelementptr i8, ptr %t368, i64 %t347
  call void @olang_textcopy(ptr %t369, ptr %t350, i64 %t351)
  %t370 = getelementptr i8, ptr %t369, i64 %t351
  call void @olang_textcopy(ptr %t370, ptr %t353, i64 %t354)
  %t371 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t356, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t297, { i64, ptr } %t372)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t376 = load i64, ptr %l10, !tbaa !24
  %t379 = add i64 %t376, 1
  store i64 %t379, ptr %l10, !tbaa !24
  br label %bb3
bb21:
  call void @__olang_scope_close(ptr %s3)
  %t381 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t381, { i64, ptr } { i64 116, ptr getelementptr inbounds (<{ i64, [116 x i8] }>, ptr @.d511, i32 0, i32 1) })
  br label %bb22
bb22:
  store i64 0, ptr %l16, !tbaa !24
  store i64 4, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t383 = load i64, ptr %l17, !tbaa !24
  %t384 = load i64, ptr %l16, !tbaa !24
  %t387 = icmp sgt i64 %t383, %t384
  br i1 %t387, label %bb23, label %bb24
bb23:
  %t389 = load i64, ptr %l18, !tbaa !24
  %t391 = icmp sgt i64 %t389, 0
  br i1 %t391, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb28
bb25:
  %t393 = load i64, ptr %l17, !tbaa !24
  %t394 = load i64, ptr %l16, !tbaa !24
  %t397 = sub i64 %t393, %t394
  %t398 = load i64, ptr %l18, !tbaa !24
  %t401 = add i64 %t397, %t398
  %t403 = sub i64 %t401, 1
  %t404 = load i64, ptr %l18, !tbaa !24
  %t407 = sdiv i64 %t403, %t404
  store i64 %t407, ptr %l111, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb27
bb27:
  %t409 = load i64, ptr %l111, !tbaa !24
  store i64 %t409, ptr %l108, !tbaa !24
  br label %bb28
bb28:
  %t410 = load i64, ptr %l108, !tbaa !24
  store i64 %t410, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s13
  %t411 = load i64, ptr %l20, !tbaa !24
  %t412 = load i64, ptr %l19, !tbaa !24
  %t415 = icmp slt i64 %t411, %t412
  %t417 = xor i1 %t415, true
  br i1 %t417, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s13)
  br label %bb71
bb31:
  br label %bb32
bb32:
  %t419 = load i64, ptr %l16, !tbaa !24
  %t420 = load i64, ptr %l20, !tbaa !24
  %t421 = load i64, ptr %l18, !tbaa !24
  %t424 = mul i64 %t420, %t421
  %t427 = add i64 %t419, %t424
  store i64 %t427, ptr %l21, !tbaa !24
  %t429 = load i64, ptr %l21, !tbaa !24
  %t431 = call i64 @__olang_fmt_i64(ptr null, i64 %t429)
  %t432 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t431)
  %t433 = call i64 @__olang_fmt_i64(ptr %t432, i64 %t429)
  %t434 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t432, 1
  store { i64, ptr } %t435, ptr %l22, !tbaa !27
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t438 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t440 = load i64, ptr %l21, !tbaa !24
  %t442 = srem i64 %t440, 2
  %t443 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t444 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t445 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d512, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d512, i32 0, i32 1) }, 0
  %t448 = extractvalue { i64, ptr } %t438, 1
  %t449 = extractvalue { i64, ptr } %t438, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d513, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d513, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t455 = extractvalue { i64, ptr } %t439, 1
  %t456 = extractvalue { i64, ptr } %t439, 0
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d514, i32 0, i32 1) }, 1
  %t459 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d514, i32 0, i32 1) }, 0
  %t460 = add i64 %t457, %t459
  %t462 = call i64 @__olang_fmt_i64(ptr null, i64 %t442)
  %t463 = add i64 %t460, %t462
  %t464 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d515, i32 0, i32 1) }, 1
  %t465 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d515, i32 0, i32 1) }, 0
  %t466 = add i64 %t463, %t465
  %t468 = extractvalue { i64, ptr } %t443, 1
  %t469 = extractvalue { i64, ptr } %t443, 0
  %t470 = add i64 %t466, %t469
  %t471 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d516, i32 0, i32 1) }, 1
  %t472 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d516, i32 0, i32 1) }, 0
  %t473 = add i64 %t470, %t472
  %t475 = extractvalue { i64, ptr } %t444, 1
  %t476 = extractvalue { i64, ptr } %t444, 0
  %t477 = add i64 %t473, %t476
  %t478 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d517, i32 0, i32 1) }, 1
  %t479 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d517, i32 0, i32 1) }, 0
  %t480 = add i64 %t477, %t479
  %t481 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t480)
  call void @olang_textcopy(ptr %t481, ptr %t445, i64 %t446)
  %t482 = getelementptr i8, ptr %t481, i64 %t446
  call void @olang_textcopy(ptr %t482, ptr %t448, i64 %t449)
  %t483 = getelementptr i8, ptr %t482, i64 %t449
  call void @olang_textcopy(ptr %t483, ptr %t451, i64 %t452)
  %t484 = getelementptr i8, ptr %t483, i64 %t452
  call void @olang_textcopy(ptr %t484, ptr %t455, i64 %t456)
  %t485 = getelementptr i8, ptr %t484, i64 %t456
  call void @olang_textcopy(ptr %t485, ptr %t458, i64 %t459)
  %t486 = getelementptr i8, ptr %t485, i64 %t459
  %t487 = call i64 @__olang_fmt_i64(ptr %t486, i64 %t442)
  %t488 = getelementptr i8, ptr %t486, i64 %t462
  call void @olang_textcopy(ptr %t488, ptr %t464, i64 %t465)
  %t489 = getelementptr i8, ptr %t488, i64 %t465
  call void @olang_textcopy(ptr %t489, ptr %t468, i64 %t469)
  %t490 = getelementptr i8, ptr %t489, i64 %t469
  call void @olang_textcopy(ptr %t490, ptr %t471, i64 %t472)
  %t491 = getelementptr i8, ptr %t490, i64 %t472
  call void @olang_textcopy(ptr %t491, ptr %t475, i64 %t476)
  %t492 = getelementptr i8, ptr %t491, i64 %t476
  call void @olang_textcopy(ptr %t492, ptr %t478, i64 %t479)
  %t493 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t481, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t437, { i64, ptr } %t494)
  br label %bb33
bb33:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t499 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t500 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t501 = load i64, ptr %l1, !tbaa !24
  %t502 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t503 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t504 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d518, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d518, i32 0, i32 1) }, 0
  %t507 = extractvalue { i64, ptr } %t499, 1
  %t508 = extractvalue { i64, ptr } %t499, 0
  %t509 = add i64 %t505, %t508
  %t510 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d519, i32 0, i32 1) }, 1
  %t511 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d519, i32 0, i32 1) }, 0
  %t512 = add i64 %t509, %t511
  %t514 = extractvalue { i64, ptr } %t500, 1
  %t515 = extractvalue { i64, ptr } %t500, 0
  %t516 = add i64 %t512, %t515
  %t517 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d520, i32 0, i32 1) }, 1
  %t518 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d520, i32 0, i32 1) }, 0
  %t519 = add i64 %t516, %t518
  %t521 = call i64 @__olang_fmt_i64(ptr null, i64 %t501)
  %t522 = add i64 %t519, %t521
  %t523 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d521, i32 0, i32 1) }, 1
  %t524 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d521, i32 0, i32 1) }, 0
  %t525 = add i64 %t522, %t524
  %t527 = extractvalue { i64, ptr } %t502, 1
  %t528 = extractvalue { i64, ptr } %t502, 0
  %t529 = add i64 %t525, %t528
  %t530 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d522, i32 0, i32 1) }, 1
  %t531 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d522, i32 0, i32 1) }, 0
  %t532 = add i64 %t529, %t531
  %t534 = extractvalue { i64, ptr } %t503, 1
  %t535 = extractvalue { i64, ptr } %t503, 0
  %t536 = add i64 %t532, %t535
  %t537 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d523, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d523, i32 0, i32 1) }, 0
  %t539 = add i64 %t536, %t538
  %t540 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t539)
  call void @olang_textcopy(ptr %t540, ptr %t504, i64 %t505)
  %t541 = getelementptr i8, ptr %t540, i64 %t505
  call void @olang_textcopy(ptr %t541, ptr %t507, i64 %t508)
  %t542 = getelementptr i8, ptr %t541, i64 %t508
  call void @olang_textcopy(ptr %t542, ptr %t510, i64 %t511)
  %t543 = getelementptr i8, ptr %t542, i64 %t511
  call void @olang_textcopy(ptr %t543, ptr %t514, i64 %t515)
  %t544 = getelementptr i8, ptr %t543, i64 %t515
  call void @olang_textcopy(ptr %t544, ptr %t517, i64 %t518)
  %t545 = getelementptr i8, ptr %t544, i64 %t518
  %t546 = call i64 @__olang_fmt_i64(ptr %t545, i64 %t501)
  %t547 = getelementptr i8, ptr %t545, i64 %t521
  call void @olang_textcopy(ptr %t547, ptr %t523, i64 %t524)
  %t548 = getelementptr i8, ptr %t547, i64 %t524
  call void @olang_textcopy(ptr %t548, ptr %t527, i64 %t528)
  %t549 = getelementptr i8, ptr %t548, i64 %t528
  call void @olang_textcopy(ptr %t549, ptr %t530, i64 %t531)
  %t550 = getelementptr i8, ptr %t549, i64 %t531
  call void @olang_textcopy(ptr %t550, ptr %t534, i64 %t535)
  %t551 = getelementptr i8, ptr %t550, i64 %t535
  call void @olang_textcopy(ptr %t551, ptr %t537, i64 %t538)
  %t552 = insertvalue { i64, ptr } undef, i64 %t539, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t540, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t498, { i64, ptr } %t553)
  br label %bb34
bb34:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t559 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t560 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t561 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t562 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t563 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t564 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d524, i32 0, i32 1) }, 1
  %t565 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d524, i32 0, i32 1) }, 0
  %t567 = extractvalue { i64, ptr } %t558, 1
  %t568 = extractvalue { i64, ptr } %t558, 0
  %t569 = add i64 %t565, %t568
  %t570 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d525, i32 0, i32 1) }, 1
  %t571 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d525, i32 0, i32 1) }, 0
  %t572 = add i64 %t569, %t571
  %t574 = extractvalue { i64, ptr } %t559, 1
  %t575 = extractvalue { i64, ptr } %t559, 0
  %t576 = add i64 %t572, %t575
  %t577 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d526, i32 0, i32 1) }, 1
  %t578 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d526, i32 0, i32 1) }, 0
  %t579 = add i64 %t576, %t578
  %t581 = extractvalue { i64, ptr } %t560, 1
  %t582 = extractvalue { i64, ptr } %t560, 0
  %t583 = add i64 %t579, %t582
  %t584 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d527, i32 0, i32 1) }, 1
  %t585 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d527, i32 0, i32 1) }, 0
  %t586 = add i64 %t583, %t585
  %t588 = extractvalue { i64, ptr } %t561, 1
  %t589 = extractvalue { i64, ptr } %t561, 0
  %t590 = add i64 %t586, %t589
  %t591 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t592 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  %t593 = add i64 %t590, %t592
  %t595 = extractvalue { i64, ptr } %t562, 1
  %t596 = extractvalue { i64, ptr } %t562, 0
  %t597 = add i64 %t593, %t596
  %t598 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d529, i32 0, i32 1) }, 1
  %t599 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d529, i32 0, i32 1) }, 0
  %t600 = add i64 %t597, %t599
  %t602 = extractvalue { i64, ptr } %t563, 1
  %t603 = extractvalue { i64, ptr } %t563, 0
  %t604 = add i64 %t600, %t603
  %t605 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d530, i32 0, i32 1) }, 1
  %t606 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d530, i32 0, i32 1) }, 0
  %t607 = add i64 %t604, %t606
  %t608 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t607)
  call void @olang_textcopy(ptr %t608, ptr %t564, i64 %t565)
  %t609 = getelementptr i8, ptr %t608, i64 %t565
  call void @olang_textcopy(ptr %t609, ptr %t567, i64 %t568)
  %t610 = getelementptr i8, ptr %t609, i64 %t568
  call void @olang_textcopy(ptr %t610, ptr %t570, i64 %t571)
  %t611 = getelementptr i8, ptr %t610, i64 %t571
  call void @olang_textcopy(ptr %t611, ptr %t574, i64 %t575)
  %t612 = getelementptr i8, ptr %t611, i64 %t575
  call void @olang_textcopy(ptr %t612, ptr %t577, i64 %t578)
  %t613 = getelementptr i8, ptr %t612, i64 %t578
  call void @olang_textcopy(ptr %t613, ptr %t581, i64 %t582)
  %t614 = getelementptr i8, ptr %t613, i64 %t582
  call void @olang_textcopy(ptr %t614, ptr %t584, i64 %t585)
  %t615 = getelementptr i8, ptr %t614, i64 %t585
  call void @olang_textcopy(ptr %t615, ptr %t588, i64 %t589)
  %t616 = getelementptr i8, ptr %t615, i64 %t589
  call void @olang_textcopy(ptr %t616, ptr %t591, i64 %t592)
  %t617 = getelementptr i8, ptr %t616, i64 %t592
  call void @olang_textcopy(ptr %t617, ptr %t595, i64 %t596)
  %t618 = getelementptr i8, ptr %t617, i64 %t596
  call void @olang_textcopy(ptr %t618, ptr %t598, i64 %t599)
  %t619 = getelementptr i8, ptr %t618, i64 %t599
  call void @olang_textcopy(ptr %t619, ptr %t602, i64 %t603)
  %t620 = getelementptr i8, ptr %t619, i64 %t603
  call void @olang_textcopy(ptr %t620, ptr %t605, i64 %t606)
  %t621 = insertvalue { i64, ptr } undef, i64 %t607, 0
  %t622 = insertvalue { i64, ptr } %t621, ptr %t608, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t557, { i64, ptr } %t622)
  br label %bb35
bb35:
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t628 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t629 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t630 = load ptr, ptr %l7, !tbaa !29
  %t632 = getelementptr %"compiler/emit:laneTags", ptr %t630, i32 0, i32 0
  %t633 = load { i64, ptr }, ptr %t632, !tbaa !27
  %t634 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d531, i32 0, i32 1) }, 1
  %t635 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d531, i32 0, i32 1) }, 0
  %t637 = extractvalue { i64, ptr } %t627, 1
  %t638 = extractvalue { i64, ptr } %t627, 0
  %t639 = add i64 %t635, %t638
  %t640 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d532, i32 0, i32 1) }, 1
  %t641 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d532, i32 0, i32 1) }, 0
  %t642 = add i64 %t639, %t641
  %t644 = extractvalue { i64, ptr } %t628, 1
  %t645 = extractvalue { i64, ptr } %t628, 0
  %t646 = add i64 %t642, %t645
  %t647 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d533, i32 0, i32 1) }, 1
  %t648 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d533, i32 0, i32 1) }, 0
  %t649 = add i64 %t646, %t648
  %t651 = extractvalue { i64, ptr } %t629, 1
  %t652 = extractvalue { i64, ptr } %t629, 0
  %t653 = add i64 %t649, %t652
  %t654 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d534, i32 0, i32 1) }, 1
  %t655 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d534, i32 0, i32 1) }, 0
  %t656 = add i64 %t653, %t655
  %t658 = extractvalue { i64, ptr } %t633, 1
  %t659 = extractvalue { i64, ptr } %t633, 0
  %t660 = add i64 %t656, %t659
  %t661 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d535, i32 0, i32 1) }, 1
  %t662 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d535, i32 0, i32 1) }, 0
  %t663 = add i64 %t660, %t662
  %t664 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t663)
  call void @olang_textcopy(ptr %t664, ptr %t634, i64 %t635)
  %t665 = getelementptr i8, ptr %t664, i64 %t635
  call void @olang_textcopy(ptr %t665, ptr %t637, i64 %t638)
  %t666 = getelementptr i8, ptr %t665, i64 %t638
  call void @olang_textcopy(ptr %t666, ptr %t640, i64 %t641)
  %t667 = getelementptr i8, ptr %t666, i64 %t641
  call void @olang_textcopy(ptr %t667, ptr %t644, i64 %t645)
  %t668 = getelementptr i8, ptr %t667, i64 %t645
  call void @olang_textcopy(ptr %t668, ptr %t647, i64 %t648)
  %t669 = getelementptr i8, ptr %t668, i64 %t648
  call void @olang_textcopy(ptr %t669, ptr %t651, i64 %t652)
  %t670 = getelementptr i8, ptr %t669, i64 %t652
  call void @olang_textcopy(ptr %t670, ptr %t654, i64 %t655)
  %t671 = getelementptr i8, ptr %t670, i64 %t655
  call void @olang_textcopy(ptr %t671, ptr %t658, i64 %t659)
  %t672 = getelementptr i8, ptr %t671, i64 %t659
  call void @olang_textcopy(ptr %t672, ptr %t661, i64 %t662)
  %t673 = insertvalue { i64, ptr } undef, i64 %t663, 0
  %t674 = insertvalue { i64, ptr } %t673, ptr %t664, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t626, { i64, ptr } %t674)
  br label %bb36
bb36:
  %t678 = call ptr @__olang_scope_hold(ptr %s13)
  %t679 = ptrtoint ptr %t678 to i64
  store i64 %t679, ptr %l165, !tbaa !24
  %t680 = load i1, ptr @olang_2esole_2ecompiler__2femit__2edotsSteps_2elocal_2e23
  br i1 %t680, label %bb37, label %bb38
bb37:
  %t682 = call ptr @__olang_region_make(ptr %s13)
  %t683 = ptrtoint ptr %t682 to i64
  store i64 %t683, ptr %l165, !tbaa !24
  br label %bb38
bb38:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d536, i32 0, i32 1) }, ptr %l169, !tbaa !27
  %t686 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t687 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d537, i32 0, i32 1) }, 1
  %t688 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d537, i32 0, i32 1) }, 0
  %t690 = extractvalue { i64, ptr } %t686, 1
  %t691 = extractvalue { i64, ptr } %t686, 0
  %t692 = add i64 %t688, %t691
  %t693 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t692)
  call void @olang_textcopy(ptr %t693, ptr %t687, i64 %t688)
  %t694 = getelementptr i8, ptr %t693, i64 %t688
  call void @olang_textcopy(ptr %t694, ptr %t690, i64 %t691)
  %t695 = insertvalue { i64, ptr } undef, i64 %t692, 0
  %t696 = insertvalue { i64, ptr } %t695, ptr %t693, 1
  %t699 = extractvalue { i64, ptr } %t696, 0
  %t700 = extractvalue { i64, ptr } %t696, 1
  %t701 = mul i64 %t699, 1
  %t702 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t701)
  call void @llvm.memcpy.p0.p0.i64(ptr %t702, ptr %t700, i64 %t701, i1 false)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t702, 1
  %t706 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t708 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v4, ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %a6, { i64, ptr } %t706, { i64, ptr } %t704)
  store { i64, ptr } %t708, ptr %l174
  br label %bb39
bb39:
  %t709 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t711 = extractvalue { i64, ptr } %t709, 1
  %t712 = extractvalue { i64, ptr } %t709, 0
  %t713 = load i64, ptr %l165
  %t714 = inttoptr i64 %t713 to ptr
  %t715 = call ptr @__olang_held_alloc(ptr %t714, i64 %t712)
  call void @olang_textcopy(ptr %t715, ptr %t711, i64 %t712)
  %t716 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t717 = insertvalue { i64, ptr } %t716, ptr %t715, 1
  store { i64, ptr } %t717, ptr %l176, !tbaa !27
  %t718 = load i1, ptr @olang_2esole_2ecompiler__2femit__2edotsSteps_2elocal_2e23
  br i1 %t718, label %bb40, label %bb41
bb40:
  %t720 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t721 = extractvalue { i64, ptr } %t720, 0
  %t723 = icmp eq i64 %t721, 0
  br i1 %t723, label %bb42, label %bb43
bb41:
  %t725 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t725, ptr %l23, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s21
  %t726 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d538, i32 0, i32 1) }, 0
  %t727 = insertvalue [2 x { i64, ptr }] %t726, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d539, i32 0, i32 1) }, 1
  %t729 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 32, i64 8)
  store [2 x { i64, ptr }] %t727, ptr %t729
  store ptr %t729, ptr %l24
  store i64 0, ptr %l25, !tbaa !24
  %t731 = load ptr, ptr %l24
  store i64 2, ptr %l26, !tbaa !24
  br label %bb44
bb42:
  store { i64, ptr } zeroinitializer, ptr %l176, !tbaa !27
  br label %bb43
bb43:
  %t734 = load i64, ptr %l165
  %t735 = inttoptr i64 %t734 to ptr
  %t736 = load { i64, ptr }, ptr %l176
  %t737 = extractvalue { i64, ptr } %t736, 1
  %t738 = call ptr @__olang_region_or(ptr %t737, ptr null)
  %t739 = icmp ne ptr %t738, null
  %t740 = select i1 %t739, ptr %t738, ptr null
  call void @__olang_region_settle_in(ptr %t735, ptr %t740)
  br label %bb41
bb44:
  store %olang.scope zeroinitializer, ptr %s22
  %t741 = load i64, ptr %l25, !tbaa !24
  %t742 = load i64, ptr %l26, !tbaa !24
  %t745 = icmp slt i64 %t741, %t742
  %t747 = xor i1 %t745, true
  br i1 %t747, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s22)
  br label %bb68
bb46:
  br label %bb47
bb47:
  %t749 = load ptr, ptr %l24
  %t750 = load i64, ptr %l25, !tbaa !24
  %t753 = getelementptr [2 x { i64, ptr }], ptr %t749, i64 0, i64 %t750
  %t754 = load { i64, ptr }, ptr %t753, !tbaa !37
  store { i64, ptr } %t754, ptr %l27, !tbaa !27
  %t756 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t757 = load ptr, ptr @__olang_prog_scope
  %t759 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t757, ptr %s22, { i64, ptr } %t756, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d540, i32 0, i32 1) })
  store i1 %t759, ptr %l192
  br label %bb48
bb48:
  %t760 = load i1, ptr %l192, !tbaa !21
  br i1 %t760, label %bb49, label %bb50
bb49:
  %t761 = load i64, ptr %l21, !tbaa !24
  %t763 = srem i64 %t761, 2
  %t765 = icmp eq i64 %t763, 1
  store i1 %t765, ptr %l193, !tbaa !21
  br label %bb51
bb50:
  %t767 = load i64, ptr %l21, !tbaa !24
  %t769 = sdiv i64 %t767, 2
  %t771 = icmp eq i64 %t769, 1
  store i1 %t771, ptr %l193, !tbaa !21
  br label %bb51
bb51:
  %t773 = load i1, ptr %l193, !tbaa !21
  store i1 %t773, ptr %l28, !tbaa !21
  %t774 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t775 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d541, i32 0, i32 1) }, 1
  %t776 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d541, i32 0, i32 1) }, 0
  %t778 = extractvalue { i64, ptr } %t774, 1
  %t779 = extractvalue { i64, ptr } %t774, 0
  %t780 = add i64 %t776, %t779
  %t781 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t780)
  call void @olang_textcopy(ptr %t781, ptr %t775, i64 %t776)
  %t782 = getelementptr i8, ptr %t781, i64 %t776
  call void @olang_textcopy(ptr %t782, ptr %t778, i64 %t779)
  %t783 = insertvalue { i64, ptr } undef, i64 %t780, 0
  %t784 = insertvalue { i64, ptr } %t783, ptr %t781, 1
  store { i64, ptr } %t784, ptr %l29, !tbaa !27
  %t786 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t787 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t789 = extractvalue { i64, ptr } %t786, 1
  %t790 = extractvalue { i64, ptr } %t786, 0
  %t791 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d542, i32 0, i32 1) }, 1
  %t792 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d542, i32 0, i32 1) }, 0
  %t793 = add i64 %t790, %t792
  %t795 = extractvalue { i64, ptr } %t787, 1
  %t796 = extractvalue { i64, ptr } %t787, 0
  %t797 = add i64 %t793, %t796
  %t798 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t797)
  call void @olang_textcopy(ptr %t798, ptr %t789, i64 %t790)
  %t799 = getelementptr i8, ptr %t798, i64 %t790
  call void @olang_textcopy(ptr %t799, ptr %t791, i64 %t792)
  %t800 = getelementptr i8, ptr %t799, i64 %t792
  call void @olang_textcopy(ptr %t800, ptr %t795, i64 %t796)
  %t801 = insertvalue { i64, ptr } undef, i64 %t797, 0
  %t802 = insertvalue { i64, ptr } %t801, ptr %t798, 1
  store { i64, ptr } %t802, ptr %l30, !tbaa !27
  %t804 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t804, ptr %l205, !tbaa !27
  %t805 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t807 = extractvalue { i64, ptr } %t805, 1
  %t808 = extractvalue { i64, ptr } %t805, 0
  %t809 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d543, i32 0, i32 1) }, 1
  %t810 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d543, i32 0, i32 1) }, 0
  %t811 = add i64 %t808, %t810
  %t812 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t811)
  call void @olang_textcopy(ptr %t812, ptr %t807, i64 %t808)
  %t813 = getelementptr i8, ptr %t812, i64 %t808
  call void @olang_textcopy(ptr %t813, ptr %t809, i64 %t810)
  %t814 = insertvalue { i64, ptr } undef, i64 %t811, 0
  %t815 = insertvalue { i64, ptr } %t814, ptr %t812, 1
  %t818 = extractvalue { i64, ptr } %t815, 0
  %t819 = extractvalue { i64, ptr } %t815, 1
  %t820 = mul i64 %t818, 1
  %t821 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t820)
  call void @llvm.memcpy.p0.p0.i64(ptr %t821, ptr %t819, i64 %t820, i1 false)
  %t822 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t821, 1
  store { i64, ptr } %t823, ptr %l209, !tbaa !27
  %t824 = load i1, ptr %l28, !tbaa !21
  br i1 %t824, label %bb52, label %bb53
bb52:
  %t826 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t828 = extractvalue { i64, ptr } %t826, 1
  %t829 = extractvalue { i64, ptr } %t826, 0
  %t830 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d544, i32 0, i32 1) }, 1
  %t831 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d544, i32 0, i32 1) }, 0
  %t832 = add i64 %t829, %t831
  %t833 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t832)
  call void @olang_textcopy(ptr %t833, ptr %t828, i64 %t829)
  %t834 = getelementptr i8, ptr %t833, i64 %t829
  call void @olang_textcopy(ptr %t834, ptr %t830, i64 %t831)
  %t835 = insertvalue { i64, ptr } undef, i64 %t832, 0
  %t836 = insertvalue { i64, ptr } %t835, ptr %t833, 1
  %t839 = extractvalue { i64, ptr } %t836, 0
  %t840 = extractvalue { i64, ptr } %t836, 1
  %t841 = mul i64 %t839, 1
  %t842 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t841)
  call void @llvm.memcpy.p0.p0.i64(ptr %t842, ptr %t840, i64 %t841, i1 false)
  %t843 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t844 = insertvalue { i64, ptr } %t843, ptr %t842, 1
  store { i64, ptr } %t844, ptr %l211, !tbaa !27
  br label %bb54
bb53:
  %t846 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t849 = extractvalue { i64, ptr } %t846, 0
  %t850 = extractvalue { i64, ptr } %t846, 1
  %t851 = mul i64 %t849, 1
  %t852 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t851)
  call void @llvm.memcpy.p0.p0.i64(ptr %t852, ptr %t850, i64 %t851, i1 false)
  %t853 = insertvalue { i64, ptr } undef, i64 %t849, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t852, 1
  store { i64, ptr } %t854, ptr %l211, !tbaa !27
  br label %bb54
bb54:
  %t856 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t857 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t858 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t859 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s13, ptr %s22, ptr %s22, ptr %s13, { i64, ptr } %t856, { i64, ptr } %t857, { i64, ptr } %t858)
  store { i64, ptr } %t859, ptr %l219
  br label %bb55
bb55:
  %t860 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t861 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t861, ptr %l221, !tbaa !27
  store { i64, ptr } %t860, ptr %l23, !tbaa !27
  %t863 = load i1, ptr @olang_2esole_2ecompiler__2femit__2edotsSteps_2elocal_2e23
  br i1 %t863, label %bb56, label %bb57
bb56:
  %t865 = load { i64, ptr }, ptr %l221
  %t866 = extractvalue { i64, ptr } %t865, 1
  call void @__olang_region_release(ptr %t866)
  store { i64, ptr } zeroinitializer, ptr %l221
  br label %bb57
bb57:
  %t867 = load i1, ptr %l28, !tbaa !21
  br i1 %t867, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s22)
  br label %bb67
bb59:
  br label %bb60
bb60:
  %t869 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t870 = load ptr, ptr @__olang_prog_scope
  %t872 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t870, ptr %s22, { i64, ptr } %t869, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d545, i32 0, i32 1) })
  store i1 %t872, ptr %l225
  br label %bb61
bb61:
  %t873 = load i1, ptr %l225, !tbaa !21
  br i1 %t873, label %bb62, label %bb63
bb62:
  %t874 = load ptr, ptr %l7, !tbaa !29
  %t876 = getelementptr %"compiler/emit:laneTags", ptr %t874, i32 0, i32 1
  %t877 = load { i64, ptr }, ptr %t876, !tbaa !27
  store { i64, ptr } %t877, ptr %l226, !tbaa !27
  br label %bb64
bb63:
  %t879 = load ptr, ptr %l7, !tbaa !29
  %t881 = getelementptr %"compiler/emit:laneTags", ptr %t879, i32 0, i32 2
  %t882 = load { i64, ptr }, ptr %t881, !tbaa !27
  store { i64, ptr } %t882, ptr %l226, !tbaa !27
  br label %bb64
bb64:
  %t884 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t884, ptr %l31, !tbaa !27
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t886 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t887 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t888 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t889 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t890 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t891 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t893 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t894 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t895 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t896 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d546, i32 0, i32 1) }, 1
  %t897 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d546, i32 0, i32 1) }, 0
  %t899 = extractvalue { i64, ptr } %t886, 1
  %t900 = extractvalue { i64, ptr } %t886, 0
  %t901 = add i64 %t897, %t900
  %t902 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d547, i32 0, i32 1) }, 1
  %t903 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d547, i32 0, i32 1) }, 0
  %t904 = add i64 %t901, %t903
  %t906 = extractvalue { i64, ptr } %t887, 1
  %t907 = extractvalue { i64, ptr } %t887, 0
  %t908 = add i64 %t904, %t907
  %t909 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d548, i32 0, i32 1) }, 1
  %t910 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d548, i32 0, i32 1) }, 0
  %t911 = add i64 %t908, %t910
  %t913 = extractvalue { i64, ptr } %t888, 1
  %t914 = extractvalue { i64, ptr } %t888, 0
  %t915 = add i64 %t911, %t914
  %t916 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d549, i32 0, i32 1) }, 1
  %t917 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d549, i32 0, i32 1) }, 0
  %t918 = add i64 %t915, %t917
  %t920 = extractvalue { i64, ptr } %t889, 1
  %t921 = extractvalue { i64, ptr } %t889, 0
  %t922 = add i64 %t918, %t921
  %t923 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d550, i32 0, i32 1) }, 1
  %t924 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d550, i32 0, i32 1) }, 0
  %t925 = add i64 %t922, %t924
  %t927 = extractvalue { i64, ptr } %t890, 1
  %t928 = extractvalue { i64, ptr } %t890, 0
  %t929 = add i64 %t925, %t928
  %t930 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d551, i32 0, i32 1) }, 1
  %t931 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d551, i32 0, i32 1) }, 0
  %t932 = add i64 %t929, %t931
  %t934 = extractvalue { i64, ptr } %t891, 1
  %t935 = extractvalue { i64, ptr } %t891, 0
  %t936 = add i64 %t932, %t935
  %t937 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d552, i32 0, i32 1) }, 1
  %t938 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d552, i32 0, i32 1) }, 0
  %t939 = add i64 %t936, %t938
  %t941 = extractvalue { i64, ptr } %a4, 1
  %t942 = extractvalue { i64, ptr } %a4, 0
  %t943 = add i64 %t939, %t942
  %t944 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d553, i32 0, i32 1) }, 1
  %t945 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d553, i32 0, i32 1) }, 0
  %t946 = add i64 %t943, %t945
  %t948 = extractvalue { i64, ptr } %t893, 1
  %t949 = extractvalue { i64, ptr } %t893, 0
  %t950 = add i64 %t946, %t949
  %t951 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d554, i32 0, i32 1) }, 1
  %t952 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d554, i32 0, i32 1) }, 0
  %t953 = add i64 %t950, %t952
  %t955 = extractvalue { i64, ptr } %t894, 1
  %t956 = extractvalue { i64, ptr } %t894, 0
  %t957 = add i64 %t953, %t956
  %t958 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d547, i32 0, i32 1) }, 1
  %t959 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d547, i32 0, i32 1) }, 0
  %t960 = add i64 %t957, %t959
  %t962 = extractvalue { i64, ptr } %t895, 1
  %t963 = extractvalue { i64, ptr } %t895, 0
  %t964 = add i64 %t960, %t963
  %t965 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d555, i32 0, i32 1) }, 1
  %t966 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d555, i32 0, i32 1) }, 0
  %t967 = add i64 %t964, %t966
  %t968 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t967)
  call void @olang_textcopy(ptr %t968, ptr %t896, i64 %t897)
  %t969 = getelementptr i8, ptr %t968, i64 %t897
  call void @olang_textcopy(ptr %t969, ptr %t899, i64 %t900)
  %t970 = getelementptr i8, ptr %t969, i64 %t900
  call void @olang_textcopy(ptr %t970, ptr %t902, i64 %t903)
  %t971 = getelementptr i8, ptr %t970, i64 %t903
  call void @olang_textcopy(ptr %t971, ptr %t906, i64 %t907)
  %t972 = getelementptr i8, ptr %t971, i64 %t907
  call void @olang_textcopy(ptr %t972, ptr %t909, i64 %t910)
  %t973 = getelementptr i8, ptr %t972, i64 %t910
  call void @olang_textcopy(ptr %t973, ptr %t913, i64 %t914)
  %t974 = getelementptr i8, ptr %t973, i64 %t914
  call void @olang_textcopy(ptr %t974, ptr %t916, i64 %t917)
  %t975 = getelementptr i8, ptr %t974, i64 %t917
  call void @olang_textcopy(ptr %t975, ptr %t920, i64 %t921)
  %t976 = getelementptr i8, ptr %t975, i64 %t921
  call void @olang_textcopy(ptr %t976, ptr %t923, i64 %t924)
  %t977 = getelementptr i8, ptr %t976, i64 %t924
  call void @olang_textcopy(ptr %t977, ptr %t927, i64 %t928)
  %t978 = getelementptr i8, ptr %t977, i64 %t928
  call void @olang_textcopy(ptr %t978, ptr %t930, i64 %t931)
  %t979 = getelementptr i8, ptr %t978, i64 %t931
  call void @olang_textcopy(ptr %t979, ptr %t934, i64 %t935)
  %t980 = getelementptr i8, ptr %t979, i64 %t935
  call void @olang_textcopy(ptr %t980, ptr %t937, i64 %t938)
  %t981 = getelementptr i8, ptr %t980, i64 %t938
  call void @olang_textcopy(ptr %t981, ptr %t941, i64 %t942)
  %t982 = getelementptr i8, ptr %t981, i64 %t942
  call void @olang_textcopy(ptr %t982, ptr %t944, i64 %t945)
  %t983 = getelementptr i8, ptr %t982, i64 %t945
  call void @olang_textcopy(ptr %t983, ptr %t948, i64 %t949)
  %t984 = getelementptr i8, ptr %t983, i64 %t949
  call void @olang_textcopy(ptr %t984, ptr %t951, i64 %t952)
  %t985 = getelementptr i8, ptr %t984, i64 %t952
  call void @olang_textcopy(ptr %t985, ptr %t955, i64 %t956)
  %t986 = getelementptr i8, ptr %t985, i64 %t956
  call void @olang_textcopy(ptr %t986, ptr %t958, i64 %t959)
  %t987 = getelementptr i8, ptr %t986, i64 %t959
  call void @olang_textcopy(ptr %t987, ptr %t962, i64 %t963)
  %t988 = getelementptr i8, ptr %t987, i64 %t963
  call void @olang_textcopy(ptr %t988, ptr %t965, i64 %t966)
  %t989 = insertvalue { i64, ptr } undef, i64 %t967, 0
  %t990 = insertvalue { i64, ptr } %t989, ptr %t968, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s22, ptr %t885, { i64, ptr } %t990)
  br label %bb65
bb65:
  %t994 = load ptr, ptr %l0, !tbaa !29
  %t995 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t996 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t997 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t998 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t999 = load i64, ptr %l5, !tbaa !24
  %t1000 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1001 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d556, i32 0, i32 1) }, 1
  %t1002 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d556, i32 0, i32 1) }, 0
  %t1004 = extractvalue { i64, ptr } %t995, 1
  %t1005 = extractvalue { i64, ptr } %t995, 0
  %t1006 = add i64 %t1002, %t1005
  %t1007 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d557, i32 0, i32 1) }, 1
  %t1008 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d557, i32 0, i32 1) }, 0
  %t1009 = add i64 %t1006, %t1008
  %t1011 = extractvalue { i64, ptr } %t996, 1
  %t1012 = extractvalue { i64, ptr } %t996, 0
  %t1013 = add i64 %t1009, %t1012
  %t1014 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d558, i32 0, i32 1) }, 1
  %t1015 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d558, i32 0, i32 1) }, 0
  %t1016 = add i64 %t1013, %t1015
  %t1018 = extractvalue { i64, ptr } %t997, 1
  %t1019 = extractvalue { i64, ptr } %t997, 0
  %t1020 = add i64 %t1016, %t1019
  %t1021 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d559, i32 0, i32 1) }, 1
  %t1022 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d559, i32 0, i32 1) }, 0
  %t1023 = add i64 %t1020, %t1022
  %t1025 = extractvalue { i64, ptr } %t998, 1
  %t1026 = extractvalue { i64, ptr } %t998, 0
  %t1027 = add i64 %t1023, %t1026
  %t1028 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d560, i32 0, i32 1) }, 1
  %t1029 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d560, i32 0, i32 1) }, 0
  %t1030 = add i64 %t1027, %t1029
  %t1032 = call i64 @__olang_fmt_i64(ptr null, i64 %t999)
  %t1033 = add i64 %t1030, %t1032
  %t1035 = extractvalue { i64, ptr } %t1000, 1
  %t1036 = extractvalue { i64, ptr } %t1000, 0
  %t1037 = add i64 %t1033, %t1036
  %t1038 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d561, i32 0, i32 1) }, 1
  %t1039 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d561, i32 0, i32 1) }, 0
  %t1040 = add i64 %t1037, %t1039
  %t1041 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t1040)
  call void @olang_textcopy(ptr %t1041, ptr %t1001, i64 %t1002)
  %t1042 = getelementptr i8, ptr %t1041, i64 %t1002
  call void @olang_textcopy(ptr %t1042, ptr %t1004, i64 %t1005)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1005
  call void @olang_textcopy(ptr %t1043, ptr %t1007, i64 %t1008)
  %t1044 = getelementptr i8, ptr %t1043, i64 %t1008
  call void @olang_textcopy(ptr %t1044, ptr %t1011, i64 %t1012)
  %t1045 = getelementptr i8, ptr %t1044, i64 %t1012
  call void @olang_textcopy(ptr %t1045, ptr %t1014, i64 %t1015)
  %t1046 = getelementptr i8, ptr %t1045, i64 %t1015
  call void @olang_textcopy(ptr %t1046, ptr %t1018, i64 %t1019)
  %t1047 = getelementptr i8, ptr %t1046, i64 %t1019
  call void @olang_textcopy(ptr %t1047, ptr %t1021, i64 %t1022)
  %t1048 = getelementptr i8, ptr %t1047, i64 %t1022
  call void @olang_textcopy(ptr %t1048, ptr %t1025, i64 %t1026)
  %t1049 = getelementptr i8, ptr %t1048, i64 %t1026
  call void @olang_textcopy(ptr %t1049, ptr %t1028, i64 %t1029)
  %t1050 = getelementptr i8, ptr %t1049, i64 %t1029
  %t1051 = call i64 @__olang_fmt_i64(ptr %t1050, i64 %t999)
  %t1052 = getelementptr i8, ptr %t1050, i64 %t1032
  call void @olang_textcopy(ptr %t1052, ptr %t1035, i64 %t1036)
  %t1053 = getelementptr i8, ptr %t1052, i64 %t1036
  call void @olang_textcopy(ptr %t1053, ptr %t1038, i64 %t1039)
  %t1054 = insertvalue { i64, ptr } undef, i64 %t1040, 0
  %t1055 = insertvalue { i64, ptr } %t1054, ptr %t1041, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s22, ptr %t994, { i64, ptr } %t1055)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s22)
  br label %bb67
bb67:
  %t1059 = load i64, ptr %l25, !tbaa !24
  %t1062 = add i64 %t1059, 1
  store i64 %t1062, ptr %l25, !tbaa !24
  br label %bb44
bb68:
  call void @__olang_scope_close(ptr %s21)
  %t1064 = load ptr, ptr %l0, !tbaa !29
  %t1065 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1066 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t1067 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1068 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1069 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1070 = load ptr, ptr %l7, !tbaa !29
  %t1072 = getelementptr %"compiler/emit:laneTags", ptr %t1070, i32 0, i32 0
  %t1073 = load { i64, ptr }, ptr %t1072, !tbaa !27
  %t1074 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1075 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d562, i32 0, i32 1) }, 1
  %t1076 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d562, i32 0, i32 1) }, 0
  %t1078 = extractvalue { i64, ptr } %t1065, 1
  %t1079 = extractvalue { i64, ptr } %t1065, 0
  %t1080 = add i64 %t1076, %t1079
  %t1081 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d563, i32 0, i32 1) }, 1
  %t1082 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d563, i32 0, i32 1) }, 0
  %t1083 = add i64 %t1080, %t1082
  %t1085 = extractvalue { i64, ptr } %t1066, 1
  %t1086 = extractvalue { i64, ptr } %t1066, 0
  %t1087 = add i64 %t1083, %t1086
  %t1088 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d564, i32 0, i32 1) }, 1
  %t1089 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d564, i32 0, i32 1) }, 0
  %t1090 = add i64 %t1087, %t1089
  %t1092 = extractvalue { i64, ptr } %t1067, 1
  %t1093 = extractvalue { i64, ptr } %t1067, 0
  %t1094 = add i64 %t1090, %t1093
  %t1095 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d565, i32 0, i32 1) }, 1
  %t1096 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d565, i32 0, i32 1) }, 0
  %t1097 = add i64 %t1094, %t1096
  %t1099 = extractvalue { i64, ptr } %t1068, 1
  %t1100 = extractvalue { i64, ptr } %t1068, 0
  %t1101 = add i64 %t1097, %t1100
  %t1102 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d566, i32 0, i32 1) }, 1
  %t1103 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d566, i32 0, i32 1) }, 0
  %t1104 = add i64 %t1101, %t1103
  %t1106 = extractvalue { i64, ptr } %t1069, 1
  %t1107 = extractvalue { i64, ptr } %t1069, 0
  %t1108 = add i64 %t1104, %t1107
  %t1109 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d567, i32 0, i32 1) }, 1
  %t1110 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d567, i32 0, i32 1) }, 0
  %t1111 = add i64 %t1108, %t1110
  %t1113 = extractvalue { i64, ptr } %t1073, 1
  %t1114 = extractvalue { i64, ptr } %t1073, 0
  %t1115 = add i64 %t1111, %t1114
  %t1116 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d568, i32 0, i32 1) }, 1
  %t1117 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d568, i32 0, i32 1) }, 0
  %t1118 = add i64 %t1115, %t1117
  %t1120 = extractvalue { i64, ptr } %t1074, 1
  %t1121 = extractvalue { i64, ptr } %t1074, 0
  %t1122 = add i64 %t1118, %t1121
  %t1123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d569, i32 0, i32 1) }, 1
  %t1124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d569, i32 0, i32 1) }, 0
  %t1125 = add i64 %t1122, %t1124
  %t1126 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t1125)
  call void @olang_textcopy(ptr %t1126, ptr %t1075, i64 %t1076)
  %t1127 = getelementptr i8, ptr %t1126, i64 %t1076
  call void @olang_textcopy(ptr %t1127, ptr %t1078, i64 %t1079)
  %t1128 = getelementptr i8, ptr %t1127, i64 %t1079
  call void @olang_textcopy(ptr %t1128, ptr %t1081, i64 %t1082)
  %t1129 = getelementptr i8, ptr %t1128, i64 %t1082
  call void @olang_textcopy(ptr %t1129, ptr %t1085, i64 %t1086)
  %t1130 = getelementptr i8, ptr %t1129, i64 %t1086
  call void @olang_textcopy(ptr %t1130, ptr %t1088, i64 %t1089)
  %t1131 = getelementptr i8, ptr %t1130, i64 %t1089
  call void @olang_textcopy(ptr %t1131, ptr %t1092, i64 %t1093)
  %t1132 = getelementptr i8, ptr %t1131, i64 %t1093
  call void @olang_textcopy(ptr %t1132, ptr %t1095, i64 %t1096)
  %t1133 = getelementptr i8, ptr %t1132, i64 %t1096
  call void @olang_textcopy(ptr %t1133, ptr %t1099, i64 %t1100)
  %t1134 = getelementptr i8, ptr %t1133, i64 %t1100
  call void @olang_textcopy(ptr %t1134, ptr %t1102, i64 %t1103)
  %t1135 = getelementptr i8, ptr %t1134, i64 %t1103
  call void @olang_textcopy(ptr %t1135, ptr %t1106, i64 %t1107)
  %t1136 = getelementptr i8, ptr %t1135, i64 %t1107
  call void @olang_textcopy(ptr %t1136, ptr %t1109, i64 %t1110)
  %t1137 = getelementptr i8, ptr %t1136, i64 %t1110
  call void @olang_textcopy(ptr %t1137, ptr %t1113, i64 %t1114)
  %t1138 = getelementptr i8, ptr %t1137, i64 %t1114
  call void @olang_textcopy(ptr %t1138, ptr %t1116, i64 %t1117)
  %t1139 = getelementptr i8, ptr %t1138, i64 %t1117
  call void @olang_textcopy(ptr %t1139, ptr %t1120, i64 %t1121)
  %t1140 = getelementptr i8, ptr %t1139, i64 %t1121
  call void @olang_textcopy(ptr %t1140, ptr %t1123, i64 %t1124)
  %t1141 = insertvalue { i64, ptr } undef, i64 %t1125, 0
  %t1142 = insertvalue { i64, ptr } %t1141, ptr %t1126, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t1064, { i64, ptr } %t1142)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s13)
  br label %bb70
bb70:
  %t1146 = load i64, ptr %l20, !tbaa !24
  %t1149 = add i64 %t1146, 1
  store i64 %t1149, ptr %l20, !tbaa !24
  br label %bb29
bb71:
  %t1151 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t1151, { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d570, i32 0, i32 1) })
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2egenClassSize(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l6 = alloca [7 x i64]
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = add i64 %t5, 1
  %t9 = mul i64 %t7, 16
  store i64 %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = insertvalue [7 x i64] undef, i64 320, 0
  %t12 = insertvalue [7 x i64] %t11, i64 384, 1
  %t13 = insertvalue [7 x i64] %t12, i64 512, 2
  %t14 = insertvalue [7 x i64] %t13, i64 768, 3
  %t15 = insertvalue [7 x i64] %t14, i64 1024, 4
  %t16 = insertvalue [7 x i64] %t15, i64 1536, 5
  %t17 = insertvalue [7 x i64] %t16, i64 2048, 6
  store [7 x i64] %t17, ptr %l6
  %t18 = load i64, ptr %l0, !tbaa !24
  %t20 = sub i64 %t18, 16
  %t22 = getelementptr [7 x i64], ptr %l6, i64 0, i64 %t20
  %t23 = load i64, ptr %t22, !tbaa !34
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2elaneDotReduce(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l14 = alloca i1
  %l24 = alloca i64
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_hold(ptr %s0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler__2femit__2elaneDotReduce_2elocal_2e4
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %s0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = load i64, ptr %l5
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call ptr @__olang_held_alloc(ptr %t12, i64 %t10)
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  %t16 = load i1, ptr @olang_2esole_2ecompiler__2femit__2elaneDotReduce_2elocal_2e4
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/emit:laneDotForm", ptr %t24, i32 0, i32 6
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t27, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d571, i32 0, i32 1) })
  store i1 %t29, ptr %l14
  br label %bb7
bb5:
  store { i64, ptr } zeroinitializer, ptr %l8, !tbaa !27
  br label %bb6
bb6:
  %t30 = load i64, ptr %l5
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = load { i64, ptr }, ptr %l8
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = call ptr @__olang_region_or(ptr %t33, ptr null)
  %t35 = icmp ne ptr %t34, null
  %t36 = select i1 %t35, ptr %t34, ptr null
  call void @__olang_region_settle_in(ptr %t31, ptr %t36)
  br label %bb4
bb7:
  %t37 = load i1, ptr %l14, !tbaa !21
  br i1 %t37, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/emit:laneDotForm", ptr %t40, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/emit:laneDotForm", ptr %t45, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d572, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d572, i32 0, i32 1) }, 0
  %t52 = extractvalue { i64, ptr } %t39, 1
  %t53 = extractvalue { i64, ptr } %t39, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d573, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d573, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t59 = call i64 @__olang_fmt_i64(ptr null, i64 %t43)
  %t60 = add i64 %t57, %t59
  %t61 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d574, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d574, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t65 = extractvalue { i64, ptr } %t44, 1
  %t66 = extractvalue { i64, ptr } %t44, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d575, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d575, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t72 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t73 = add i64 %t70, %t72
  %t74 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d576, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d576, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t49, i64 %t50)
  %t78 = getelementptr i8, ptr %t77, i64 %t50
  call void @olang_textcopy(ptr %t78, ptr %t52, i64 %t53)
  %t79 = getelementptr i8, ptr %t78, i64 %t53
  call void @olang_textcopy(ptr %t79, ptr %t55, i64 %t56)
  %t80 = getelementptr i8, ptr %t79, i64 %t56
  %t81 = call i64 @__olang_fmt_i64(ptr %t80, i64 %t43)
  %t82 = getelementptr i8, ptr %t80, i64 %t59
  call void @olang_textcopy(ptr %t82, ptr %t61, i64 %t62)
  %t83 = getelementptr i8, ptr %t82, i64 %t62
  call void @olang_textcopy(ptr %t83, ptr %t65, i64 %t66)
  %t84 = getelementptr i8, ptr %t83, i64 %t66
  call void @olang_textcopy(ptr %t84, ptr %t68, i64 %t69)
  %t85 = getelementptr i8, ptr %t84, i64 %t69
  %t86 = call i64 @__olang_fmt_i64(ptr %t85, i64 %t48)
  %t87 = getelementptr i8, ptr %t85, i64 %t72
  call void @olang_textcopy(ptr %t87, ptr %t74, i64 %t75)
  %t88 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t77, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t38, { i64, ptr } %t89)
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t93 = call ptr @__olang_scope_hold(ptr %s0)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l24, !tbaa !24
  %t95 = load i1, ptr @olang_2esole_2ecompiler__2femit__2elaneDotReduce_2elocal_2e4
  br i1 %t95, label %bb11, label %bb12
bb11:
  %t97 = call ptr @__olang_region_make(ptr %s0)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l24, !tbaa !24
  br label %bb12
bb12:
  %t99 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d577, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d577, i32 0, i32 1) }, 0
  %t103 = extractvalue { i64, ptr } %t99, 1
  %t104 = extractvalue { i64, ptr } %t99, 0
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d578, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d578, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = load i64, ptr %l24
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = call ptr @__olang_held_alloc(ptr %t110, i64 %t108)
  call void @olang_textcopy(ptr %t111, ptr %t100, i64 %t101)
  %t112 = getelementptr i8, ptr %t111, i64 %t101
  call void @olang_textcopy(ptr %t112, ptr %t103, i64 %t104)
  %t113 = getelementptr i8, ptr %t112, i64 %t104
  call void @olang_textcopy(ptr %t113, ptr %t106, i64 %t107)
  %t114 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t111, 1
  store { i64, ptr } %t115, ptr %l27, !tbaa !27
  %t116 = load i1, ptr @olang_2esole_2ecompiler__2femit__2elaneDotReduce_2elocal_2e4
  br i1 %t116, label %bb13, label %bb14
bb13:
  %t118 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t121 = icmp eq i64 %t119, 0
  br i1 %t121, label %bb15, label %bb16
bb14:
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t123, ptr %l31, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t124, ptr %l4, !tbaa !27
  %t125 = load i1, ptr @olang_2esole_2ecompiler__2femit__2elaneDotReduce_2elocal_2e4
  br i1 %t125, label %bb17, label %bb18
bb15:
  store { i64, ptr } zeroinitializer, ptr %l27, !tbaa !27
  br label %bb16
bb16:
  %t127 = load i64, ptr %l24
  %t128 = inttoptr i64 %t127 to ptr
  %t129 = load { i64, ptr }, ptr %l27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = call ptr @__olang_region_or(ptr %t130, ptr null)
  %t132 = icmp ne ptr %t131, null
  %t133 = select i1 %t132, ptr %t131, ptr null
  call void @__olang_region_settle_in(ptr %t128, ptr %t133)
  br label %bb14
bb17:
  %t134 = load { i64, ptr }, ptr %l31
  %t135 = extractvalue { i64, ptr } %t134, 1
  call void @__olang_region_release(ptr %t135)
  store { i64, ptr } zeroinitializer, ptr %l31
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/emit:laneDotForm", ptr %t138, i32 0, i32 6
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/emit:laneDotForm", ptr %t142, i32 0, i32 1
  %t145 = load i64, ptr %t144, !tbaa !24
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr %"compiler/emit:laneDotForm", ptr %t146, i32 0, i32 6
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/emit:laneDotForm", ptr %t150, i32 0, i32 1
  %t153 = load i64, ptr %t152, !tbaa !24
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/emit:laneDotForm", ptr %t154, i32 0, i32 6
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t159 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d579, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d579, i32 0, i32 1) }, 0
  %t162 = extractvalue { i64, ptr } %t137, 1
  %t163 = extractvalue { i64, ptr } %t137, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d580, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d580, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t169 = extractvalue { i64, ptr } %t141, 1
  %t170 = extractvalue { i64, ptr } %t141, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d581, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d581, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t145)
  %t177 = add i64 %t174, %t176
  %t179 = extractvalue { i64, ptr } %t149, 1
  %t180 = extractvalue { i64, ptr } %t149, 0
  %t181 = add i64 %t177, %t180
  %t182 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d582, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d582, i32 0, i32 1) }, 0
  %t184 = add i64 %t181, %t183
  %t186 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t187 = add i64 %t184, %t186
  %t188 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d583, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d583, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t192 = extractvalue { i64, ptr } %t157, 1
  %t193 = extractvalue { i64, ptr } %t157, 0
  %t194 = add i64 %t190, %t193
  %t195 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d584, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d584, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t199 = extractvalue { i64, ptr } %t158, 1
  %t200 = extractvalue { i64, ptr } %t158, 0
  %t201 = add i64 %t197, %t200
  %t202 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d585, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d585, i32 0, i32 1) }, 0
  %t204 = add i64 %t201, %t203
  %t205 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t204)
  call void @olang_textcopy(ptr %t205, ptr %t159, i64 %t160)
  %t206 = getelementptr i8, ptr %t205, i64 %t160
  call void @olang_textcopy(ptr %t206, ptr %t162, i64 %t163)
  %t207 = getelementptr i8, ptr %t206, i64 %t163
  call void @olang_textcopy(ptr %t207, ptr %t165, i64 %t166)
  %t208 = getelementptr i8, ptr %t207, i64 %t166
  call void @olang_textcopy(ptr %t208, ptr %t169, i64 %t170)
  %t209 = getelementptr i8, ptr %t208, i64 %t170
  call void @olang_textcopy(ptr %t209, ptr %t172, i64 %t173)
  %t210 = getelementptr i8, ptr %t209, i64 %t173
  %t211 = call i64 @__olang_fmt_i64(ptr %t210, i64 %t145)
  %t212 = getelementptr i8, ptr %t210, i64 %t176
  call void @olang_textcopy(ptr %t212, ptr %t179, i64 %t180)
  %t213 = getelementptr i8, ptr %t212, i64 %t180
  call void @olang_textcopy(ptr %t213, ptr %t182, i64 %t183)
  %t214 = getelementptr i8, ptr %t213, i64 %t183
  %t215 = call i64 @__olang_fmt_i64(ptr %t214, i64 %t153)
  %t216 = getelementptr i8, ptr %t214, i64 %t186
  call void @olang_textcopy(ptr %t216, ptr %t188, i64 %t189)
  %t217 = getelementptr i8, ptr %t216, i64 %t189
  call void @olang_textcopy(ptr %t217, ptr %t192, i64 %t193)
  %t218 = getelementptr i8, ptr %t217, i64 %t193
  call void @olang_textcopy(ptr %t218, ptr %t195, i64 %t196)
  %t219 = getelementptr i8, ptr %t218, i64 %t196
  call void @olang_textcopy(ptr %t219, ptr %t199, i64 %t200)
  %t220 = getelementptr i8, ptr %t219, i64 %t200
  call void @olang_textcopy(ptr %t220, ptr %t202, i64 %t203)
  %t221 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t205, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t136, { i64, ptr } %t222)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2emetaNumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l9
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = add i64 1000, %t14
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t17 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t16, i64 %t17, i64 %t15)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t19, i64 %t20)
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l15
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb8, label %ok.27, !prof !99
ok.27:
  store i64 %t24, ptr %l14
  br label %bb7
bb7:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l11, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t29 = load i64, ptr %l11, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2femit_2estmtSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/source:Span" @compiler_2fmir_2eStmtSpan(ptr %v0, ptr %a0)
  store %"compiler/source:Span" %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t1, i64 %a0)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t6, i64 %a1)
  store { i64, ptr } %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t11, { i64, ptr } %t12)
  store i1 %t13, ptr %l9
  br label %bb3
bb3:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare i64 @__olang_fmt_i64(ptr, i64)
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"void ()" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d4 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = dso_local alias " }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".dtor" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"lambda" }>, align 8
@.d16 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".init" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"_setjmp" }>, align 8
@.d20 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"i32 @_setjmp(ptr, ptr) returns_twice" }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"setjmp" }>, align 8
@.d22 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"i32 @setjmp(ptr) returns_twice" }>, align 8
@.d23 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang.gendrop." }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d24 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%x" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-1" }>, align 8
@.d26 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_gen_leaf" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%x" }>, align 8
@.d28 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { i64, ptr }, ptr " }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%x" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d34 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call void @__olang_gen_leaf(ptr " }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d37 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ret i64 " }>, align 8
@.d38 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"define linkonce_odr hidden i64 @" }>, align 8
@.d39 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"(ptr %x, ptr %keep, i64 %n) #0 {\0Aentry:\0A" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"}\0A\0A" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argc" }>, align 8
@.d43 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argc = external global i32" }>, align 8
@.d44 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argv" }>, align 8
@.d45 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argv = external global ptr" }>, align 8
@.d46 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_jmp_target" }>, align 8
@.d47 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_jmp_target = external thread_local(initialexec) global ptr" }>, align 8
@.d48 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_unwind_top" }>, align 8
@.d49 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_unwind_top = external thread_local(initialexec) global ptr" }>, align 8
@.d50 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_unwind_mark" }>, align 8
@.d51 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"@__olang_unwind_mark = external thread_local(initialexec) global ptr" }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"printf" }>, align 8
@.d53 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"i32 @printf(ptr, ...)" }>, align 8
@.d54 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"fflush" }>, align 8
@.d55 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"i32 @fflush(ptr)" }>, align 8
@.d56 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_thread_init" }>, align 8
@.d57 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_test_failed" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ptr @" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ptr @" }>, align 8
@.d61 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"{ ptr, ptr, ptr, ptr } { " }>, align 8
@.d62 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d63 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d64 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"@olang.race.reports = internal global i32 0\0A" }>, align 8
@.d65 = private constant <{ i64, [126 x i8] }> <{ i64 0, [126 x i8] c"define void @__tsan_on_report(ptr %r) nounwind {\0Aentry:\0A  atomicrmw add ptr @olang.race.reports, i32 1 monotonic\0A  ret void\0A}\0A" }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d67 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"@olang.harness.inits = private constant [" }>, align 8
@.d68 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x ptr] [" }>, align 8
@.d69 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d71 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"@olang.harness.tests = private constant [" }>, align 8
@.d72 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" x { ptr, ptr, ptr, ptr }] [" }>, align 8
@.d73 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d74 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"strcmp" }>, align 8
@.d75 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"i32 @strcmp(ptr, ptr)" }>, align 8
@.d76 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"strncmp" }>, align 8
@.d77 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"i32 @strncmp(ptr, ptr, i64)" }>, align 8
@.d78 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"strlen" }>, align 8
@.d79 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"i64 @strlen(ptr)" }>, align 8
@.d80 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"strstr" }>, align 8
@.d81 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"ptr @strstr(ptr, ptr)" }>, align 8
@.d82 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"\0Adefine private i1 @olang.harness.selected(ptr %tg, ptr %td, i32 %argc, ptr %argv) {\0Aentry:\0A" }>, align 8
@.d83 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"  %few = icmp sle i32 %argc, 1\0A  br i1 %few, label %yes, label %loop\0Aloop:\0A" }>, align 8
@.d84 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"  %i = phi i32 [ 1, %entry ], [ %i2, %next ]\0A  %i64 = sext i32 %i to i64\0A" }>, align 8
@.d85 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"  %ip = getelementptr ptr, ptr %argv, i64 %i64\0A  %f = load ptr, ptr %ip\0A" }>, align 8
@.d86 = private constant <{ i64, [108 x i8] }> <{ i64 0, [108 x i8] c"  %c1 = call i32 @strcmp(ptr %tg, ptr %f)\0A  %e1 = icmp eq i32 %c1, 0\0A  br i1 %e1, label %yes, label %t2\0At2:\0A" }>, align 8
@.d87 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"  %fl = call i64 @strlen(ptr %f)\0A  %c2 = call i32 @strncmp(ptr %tg, ptr %f, i64 %fl)\0A" }>, align 8
@.d88 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"  %e2 = icmp eq i32 %c2, 0\0A  br i1 %e2, label %t2b, label %t3\0At2b:\0A" }>, align 8
@.d89 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %dp = getelementptr i8, ptr %tg, i64 %fl\0A  %dc = load i8, ptr %dp\0A  %dot = icmp eq i8 %dc, 46\0A" }>, align 8
@.d90 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"  br i1 %dot, label %yes, label %t3\0At3:\0A  %ss = call ptr @strstr(ptr %td, ptr %f)\0A" }>, align 8
@.d91 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c"  %e3 = icmp ne ptr %ss, null\0A  br i1 %e3, label %yes, label %next\0Anext:\0A  %i2 = add i32 %i, 1\0A" }>, align 8
@.d92 = private constant <{ i64, [105 x i8] }> <{ i64 0, [105 x i8] c"  %more = icmp slt i32 %i2, %argc\0A  br i1 %more, label %loop, label %no\0Ayes:\0A  ret i1 1\0Ano:\0A  ret i1 0\0A}\0A" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d94 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"\0Adefine i32 @main(i32 %argc, ptr %argv) #0 {\0Aentry:\0A" }>, align 8
@.d95 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"  %pass = alloca i32\0A  %fail = alloca i32\0A  %k = alloca i64\0A  %jb = alloca " }>, align 8
@.d96 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", align 16\0A" }>, align 8
@.d97 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"  %sel = alloca i32\0A  store volatile i32 0, ptr %sel\0A" }>, align 8
@.d98 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"  store volatile i32 0, ptr %pass\0A  store volatile i32 0, ptr %fail\0A" }>, align 8
@.d99 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  store i32 %argc, ptr @__olang_argc\0A  store ptr %argv, ptr @__olang_argv\0A" }>, align 8
@.d100 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  store ptr " }>, align 8
@.d101 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", ptr @__olang_test_file\0A" }>, align 8
@.d102 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"  call void @__olang_thread_init()\0A" }>, align 8
@.d103 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"  store volatile i64 0, ptr %k\0A  br label %gloop\0Agloop:\0A  %gk = load volatile i64, ptr %k\0A" }>, align 8
@.d104 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"  %gm = icmp slt i64 %gk, " }>, align 8
@.d105 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"\0A  br i1 %gm, label %gbody, label %gdone\0Agbody:\0A" }>, align 8
@.d106 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"  store ptr %jb, ptr @__olang_jmp_target\0A  %gj = " }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d108 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"  %gz = icmp eq i32 %gj, 0\0A  br i1 %gz, label %grun, label %gnext\0Agrun:\0A  %gk2 = load volatile i64, ptr %k\0A" }>, align 8
@.d109 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %gp = getelementptr [" }>, align 8
@.d110 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c" x ptr], ptr @olang.harness.inits, i64 0, i64 %gk2\0A" }>, align 8
@.d111 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"  %gf = load ptr, ptr %gp\0A  call void %gf()\0A  br label %gnext\0Agnext:\0A" }>, align 8
@.d112 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"  %gk3 = load volatile i64, ptr %k\0A  %gk4 = add i64 %gk3, 1\0A  store volatile i64 %gk4, ptr %k\0A" }>, align 8
@.d113 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"  br label %gloop\0Agdone:\0A" }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d115 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" x { ptr, ptr, ptr, ptr }]" }>, align 8
@.d116 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"  store volatile i64 0, ptr %k\0A  br label %tloop\0Atloop:\0A  %tk = load volatile i64, ptr %k\0A" }>, align 8
@.d117 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"  %tm = icmp slt i64 %tk, " }>, align 8
@.d118 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"\0A  br i1 %tm, label %tpick, label %tdone\0Atpick:\0A" }>, align 8
@.d119 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %tgp = getelementptr " }>, align 8
@.d120 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c", ptr @olang.harness.tests, i64 0, i64 %tk, i32 2\0A" }>, align 8
@.d121 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %tdp = getelementptr " }>, align 8
@.d122 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c", ptr @olang.harness.tests, i64 0, i64 %tk, i32 3\0A" }>, align 8
@.d123 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"  %tg = load ptr, ptr %tgp\0A  %td = load ptr, ptr %tdp\0A" }>, align 8
@.d124 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"  %tsel = call i1 @olang.harness.selected(ptr %tg, ptr %td, i32 %argc, ptr %argv)\0A" }>, align 8
@.d125 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"  br i1 %tsel, label %tbody, label %tnext\0Atbody:\0A" }>, align 8
@.d126 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %sl = load volatile i32, ptr %sel\0A  %sl2 = add i32 %sl, 1\0A  store volatile i32 %sl2, ptr %sel\0A" }>, align 8
@.d127 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"  %top = load ptr, ptr @__olang_unwind_top\0A  store ptr %top, ptr @__olang_unwind_mark\0A" }>, align 8
@.d128 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"  store ptr %jb, ptr @__olang_jmp_target\0A  %tj = " }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d130 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"  %tk2 = load volatile i64, ptr %k\0A" }>, align 8
@.d131 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %tfp = getelementptr " }>, align 8
@.d132 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c", ptr @olang.harness.tests, i64 0, i64 %tk2, i32 0\0A" }>, align 8
@.d133 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %tnp = getelementptr " }>, align 8
@.d134 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c", ptr @olang.harness.tests, i64 0, i64 %tk2, i32 1\0A" }>, align 8
@.d135 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"  %tf = load ptr, ptr %tfp\0A  %tn = load ptr, ptr %tnp\0A" }>, align 8
@.d136 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"  %tz = icmp eq i32 %tj, 0\0A  br i1 %tz, label %trun, label %tbad\0Atrun:\0A" }>, align 8
@.d137 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"  store ptr %tn, ptr @__olang_test_name\0A" }>, align 8
@.d138 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"  %rr0 = load atomic i32, ptr @olang.race.reports monotonic, align 4\0A" }>, align 8
@.d139 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  call void %tf()\0A" }>, align 8
@.d140 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"  %rr1 = load atomic i32, ptr @olang.race.reports monotonic, align 4\0A  %raced = icmp ne i32 %rr1, %rr0\0A" }>, align 8
@.d141 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"  br i1 %raced, label %trace, label %tpass\0Atrace:\0A" }>, align 8
@.d142 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"  %rf = load volatile i32, ptr %fail\0A  %rff = add i32 %rf, 1\0A  store volatile i32 %rff, ptr %fail\0A" }>, align 8
@.d143 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"FAIL - %s: data race\0A" }>, align 8
@.d144 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"  call i32 (ptr, ...) @printf(ptr " }>, align 8
@.d145 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c", ptr %tn)\0A  call i32 @fflush(ptr null)\0A" }>, align 8
@.d146 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"  br label %tnext\0Atpass:\0A" }>, align 8
@.d147 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"  %p = load volatile i32, ptr %pass\0A  %pp = add i32 %p, 1\0A  store volatile i32 %pp, ptr %pass\0A" }>, align 8
@.d148 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ok - %s\0A" }>, align 8
@.d149 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"  call i32 (ptr, ...) @printf(ptr " }>, align 8
@.d150 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c", ptr %tn)\0A  call i32 @fflush(ptr null)\0A" }>, align 8
@.d151 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"  br label %tnext\0Atbad:\0A  %f = load volatile i32, ptr %fail\0A  %ff = add i32 %f, 1\0A" }>, align 8
@.d152 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"  store volatile i32 %ff, ptr %fail\0A  call void @__olang_test_failed(ptr %tn)\0A  call i32 @fflush(ptr null)\0A" }>, align 8
@.d153 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"  br label %tnext\0Atnext:\0A  %tk3 = load volatile i64, ptr %k\0A  %tk4 = add i64 %tk3, 1\0A" }>, align 8
@.d154 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"  store volatile i64 %tk4, ptr %k\0A  br label %tloop\0Atdone:\0A" }>, align 8
@.d155 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"  store ptr null, ptr @__olang_jmp_target\0A" }>, align 8
@.d156 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"  %ns = load volatile i32, ptr %sel\0A  %none = icmp eq i32 %ns, 0\0A  %words = icmp sgt i32 %argc, 1\0A" }>, align 8
@.d157 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c"  %unmatched = and i1 %none, %words\0A  br i1 %unmatched, label %nomatch, label %counts\0Anomatch:\0A" }>, align 8
@.d158 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"  ret i32 3\0Acounts:\0A" }>, align 8
@.d159 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  %np = load volatile i32, ptr %pass\0A  %nf = load volatile i32, ptr %fail\0A" }>, align 8
@.d160 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"getenv" }>, align 8
@.d161 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ptr @getenv(ptr)" }>, align 8
@.d162 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fopen" }>, align 8
@.d163 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ptr @fopen(ptr, ptr)" }>, align 8
@.d164 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"fclose" }>, align 8
@.d165 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"i32 @fclose(ptr)" }>, align 8
@.d166 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"fprintf" }>, align 8
@.d167 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"i32 @fprintf(ptr, ptr, ...)" }>, align 8
@.d168 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"OLANG_TEST_COUNTS" }>, align 8
@.d169 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"  %cf = call ptr @getenv(ptr " }>, align 8
@.d170 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c")\0A  %hascf = icmp ne ptr %cf, null\0A" }>, align 8
@.d171 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"  br i1 %hascf, label %tofile, label %say\0Atofile:\0A" }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"w" }>, align 8
@.d173 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"  %fh = call ptr @fopen(ptr %cf, ptr " }>, align 8
@.d174 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c")\0A  %fhok = icmp ne ptr %fh, null\0A" }>, align 8
@.d175 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"  br i1 %fhok, label %wrote, label %say\0Awrote:\0A" }>, align 8
@.d176 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"%d %d\0A" }>, align 8
@.d177 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"  call i32 (ptr, ...) @fprintf(ptr %fh, ptr " }>, align 8
@.d178 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", i32 %np, i32 %nf)\0A" }>, align 8
@.d179 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"  call i32 @fclose(ptr %fh)\0A  br label %fin\0Asay:\0A" }>, align 8
@.d180 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"%d passed, %d failed\0A" }>, align 8
@.d181 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"  call i32 (ptr, ...) @printf(ptr " }>, align 8
@.d182 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", i32 %np, i32 %nf)\0A" }>, align 8
@.d183 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"  br label %fin\0Afin:\0A" }>, align 8
@.d184 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  %any = icmp sgt i32 %nf, 0\0A  %st = zext i1 %any to i32\0A  ret i32 %st\0A}\0A\0A" }>, align 8
@.d185 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d186 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G_2e" }>, align 8
@.d187 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang." }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 10}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d586, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d586, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d587, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d587, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d588, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d588, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d589, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d589, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d590, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d590, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d591, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d591, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d592, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d592, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d593, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d593, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d594, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d594, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d595, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d595, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
ret:
  ret void
}

@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_sb_done(ptr)
@.d189 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_adapter" }>, align 8
@.d190 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"_copied" }>, align 8
@.d191 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_twin" }>, align 8
@.d192 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.init." }>, align 8
@.d193 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".top" }>, align 8
@.d194 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d195 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang.anyrender" }>, align 8
@.d196 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
@.d197 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a constant element of a " }>, align 8
@.d198 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d199 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d200 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"{ i64 " }>, align 8
@.d201 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d202 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d203 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d204 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d205 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d206 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d207 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d208 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d209 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"llvm.memcpy.p0.p0.i64" }>, align 8
@.d210 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d211 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"call void @llvm.memcpy.p0.p0.i64(ptr " }>, align 8
@.d212 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d213 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d214 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d215 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"zext " }>, align 8
@.d216 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"sext " }>, align 8
@.d217 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d218 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d219 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_gen_alloc" }>, align 8
@.d220 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call ptr @__olang_gen_alloc(ptr " }>, align 8
@.d221 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d222 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d223 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d224 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d225 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d226 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d227 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d228 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 -8" }>, align 8
@.d229 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"store i64 " }>, align 8
@.d230 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d231 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", align 8" }>, align 8
@.d232 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a count of a constant" }>, align 8
@.d233 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d234 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d235 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d236 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d237 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d238 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d239 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d240 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d241 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d242 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d243 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d244 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"store ptr null, ptr " }>, align 8
@.d245 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", align 8" }>, align 8
@.d246 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epackedInto_2elocal_2e6 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d247 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d248 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d249 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eparts_2elocal_2e5 = weak hidden constant i1 false
@.d250 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d251 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d252 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d253 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d254 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d255 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d256 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d257 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d258 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d259 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2epartsResult_2elocal_2e7 = weak hidden constant i1 false
@.d260 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d261 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d262 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d263 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d264 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d265 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%lp" }>, align 8
@.d266 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d267 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s" }>, align 8
@.d268 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"store ptr %s" }>, align 8
@.d269 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"room, ptr %s" }>, align 8
@.d270 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"a region" }>, align 8
@.d271 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"store %olang.scope zeroinitializer, ptr %s" }>, align 8
@.d272 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"store ptr null, ptr %jh" }>, align 8
@.d273 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_sb_done" }>, align 8
@.d274 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"getelementptr %olang.builder, ptr %s" }>, align 8
@.d275 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 3" }>, align 8
@.d276 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d277 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne ptr " }>, align 8
@.d278 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", null" }>, align 8
@.d279 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"sbgrew" }>, align 8
@.d280 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"sbdone" }>, align 8
@.d281 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d282 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d283 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"call void @__olang_sb_done(ptr %s" }>, align 8
@.d284 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d285 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d286 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_close" }>, align 8
@.d287 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"call void @__olang_scope_close(ptr %s" }>, align 8
@.d288 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d289 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_errpay_set" }>, align 8
@.d290 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call void @__olang_errpay_set(ptr " }>, align 8
@.d291 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d292 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_errpay_pop" }>, align 8
@.d293 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call void @__olang_errpay_pop()" }>, align 8
@.d294 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a cleanup (interpret's)" }>, align 8
@.d295 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a destructor not found: " }>, align 8
@.d296 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"__olang_scope_register_dtor" }>, align 8
@.d297 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"call void @__olang_scope_register_dtor(ptr " }>, align 8
@.d298 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d299 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d300 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"_rt)" }>, align 8
@.d301 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_region_drop" }>, align 8
@.d302 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_region_drop(ptr " }>, align 8
@.d303 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d304 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d305 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"__olang_region_release" }>, align 8
@.d306 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"call void @__olang_region_release(ptr " }>, align 8
@.d307 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d308 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"__olang_region_release_part" }>, align 8
@.d309 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d310 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d311 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"call void @__olang_region_release_part(ptr " }>, align 8
@.d312 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d314 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_slot_release" }>, align 8
@.d315 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call void @__olang_slot_release(ptr " }>, align 8
@.d316 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d317 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d318 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"inttoptr i64 " }>, align 8
@.d319 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to ptr" }>, align 8
@.d320 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"__olang_region_settle_in" }>, align 8
@.d321 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"call void @__olang_region_settle_in(ptr " }>, align 8
@.d322 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d323 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d324 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d325 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"inttoptr i64 " }>, align 8
@.d326 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to ptr" }>, align 8
@.d327 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_region_drop" }>, align 8
@.d328 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_region_drop(ptr " }>, align 8
@.d329 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d330 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d331 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d332 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d333 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d334 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d335 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d336 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d337 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d338 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d339 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d340 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%tf" }>, align 8
@.d341 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d342 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"tf" }>, align 8
@.d343 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d344 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d345 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"d = load ptr, ptr %f" }>, align 8
@.d346 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d347 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"v = load { i64, ptr }, ptr " }>, align 8
@.d348 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"d\0A" }>, align 8
@.d349 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d350 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"n = extractvalue { i64, ptr } " }>, align 8
@.d351 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"v, 0\0A  " }>, align 8
@.d352 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"p = extractvalue { i64, ptr } " }>, align 8
@.d353 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"v, 1\0A" }>, align 8
@.d354 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d355 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"on = extractvalue { i64, ptr } %old" }>, align 8
@.d356 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", 0\0A  " }>, align 8
@.d357 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"op = extractvalue { i64, ptr } %old" }>, align 8
@.d358 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 1\0A" }>, align 8
@.d359 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d360 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"b = mul i64 " }>, align 8
@.d361 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"n, " }>, align 8
@.d362 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d363 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"s = icmp eq i64 " }>, align 8
@.d364 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"on\0A" }>, align 8
@.d365 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d366 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"s, label %" }>, align 8
@.d367 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"i, label %" }>, align 8
@.d368 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"f\0A" }>, align 8
@.d369 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i:\0A" }>, align 8
@.d370 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d371 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"op, ptr " }>, align 8
@.d372 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"p, i64 " }>, align 8
@.d373 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"b, i1 false)\0A" }>, align 8
@.d374 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"  store { i64, ptr } %old" }>, align 8
@.d375 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d376 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"d\0A  br label %" }>, align 8
@.d377 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"e\0A" }>, align 8
@.d378 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"f:\0A" }>, align 8
@.d379 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"__olang_scope_alloc_min" }>, align 8
@.d380 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d381 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d382 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d383 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d384 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"c = load ptr, ptr %f" }>, align 8
@.d385 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d386 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"z = icmp eq ptr " }>, align 8
@.d387 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"c, null\0A" }>, align 8
@.d388 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d389 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"g = load ptr, ptr @__olang_prog_scope\0A  " }>, align 8
@.d390 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"w = select i1 " }>, align 8
@.d391 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"z, ptr " }>, align 8
@.d392 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"g, ptr " }>, align 8
@.d393 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c\0A" }>, align 8
@.d394 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d395 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d396 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d397 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"q = call ptr @" }>, align 8
@.d398 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d399 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"w, i64 " }>, align 8
@.d400 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"b" }>, align 8
@.d401 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d402 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d403 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"q, ptr " }>, align 8
@.d404 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"p, i64 " }>, align 8
@.d405 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"b, i1 false)\0A" }>, align 8
@.d406 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d407 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"x = insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d408 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"n, 0\0A" }>, align 8
@.d409 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d410 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"y = insertvalue { i64, ptr } " }>, align 8
@.d411 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"x, ptr " }>, align 8
@.d412 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"q, 1\0A  store { i64, ptr } " }>, align 8
@.d413 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"y, ptr " }>, align 8
@.d414 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"d\0A" }>, align 8
@.d415 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  br label %" }>, align 8
@.d416 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"e\0A" }>, align 8
@.d417 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"e:\0A" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e5 = weak hidden constant i1 false
@.d418 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i128" }>, align 8
@.d419 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"zext " }>, align 8
@.d420 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"sext " }>, align 8
@.d421 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d422 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" to i128" }>, align 8
@.d423 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e6 = weak hidden constant i1 false
@.d424 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"icmp slt i128 " }>, align 8
@.d425 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d426 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"sub i128 0, " }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ewideToBF16_2elocal_2e7 = weak hidden constant i1 false
@.d427 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d428 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", i128 " }>, align 8
@.d429 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"llvm.ctlz.i128" }>, align 8
@.d430 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"i128 @llvm.ctlz.i128(i128, i1)" }>, align 8
@.d431 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"or i128 " }>, align 8
@.d432 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d433 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call i128 @llvm.ctlz.i128(i128 " }>, align 8
@.d434 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", i1 true)" }>, align 8
@.d435 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"sub i128 65, " }>, align 8
@.d436 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"icmp sgt i128 " }>, align 8
@.d437 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d438 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d439 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", i128 " }>, align 8
@.d440 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i128 0" }>, align 8
@.d441 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"shl i128 1, " }>, align 8
@.d442 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"sub i128 " }>, align 8
@.d443 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d444 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"and i128 " }>, align 8
@.d445 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d446 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp ne i128 " }>, align 8
@.d447 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d448 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"lshr i128 " }>, align 8
@.d449 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d450 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"trunc i128 " }>, align 8
@.d451 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d452 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"zext i1 " }>, align 8
@.d453 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d454 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"or i64 " }>, align 8
@.d455 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d456 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_int_bf16" }>, align 8
@.d457 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call bfloat @__olang_int_bf16(i64 " }>, align 8
@.d458 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i1 " }>, align 8
@.d459 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d460 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"trunc i128 " }>, align 8
@.d461 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d462 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"add i32 " }>, align 8
@.d463 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", 127" }>, align 8
@.d464 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shl i32 " }>, align 8
@.d465 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 23" }>, align 8
@.d466 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"bitcast i32 " }>, align 8
@.d467 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" to float" }>, align 8
@.d468 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d469 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"fmul float " }>, align 8
@.d470 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d471 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d472 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" x " }>, align 8
@.d473 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d474 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"  %pone = icmp eq i64 %ps, 0\0A  %qone = icmp eq i64 %qs, 0\0A  %some = icmp sle i64 " }>, align 8
@.d475 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", %g\0A" }>, align 8
@.d476 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"  br i1 %some, label %pre, label %t\0Apre:\0A" }>, align 8
@.d477 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"p" }>, align 8
@.d478 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"q" }>, align 8
@.d479 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d480 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"p" }>, align 8
@.d481 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"p" }>, align 8
@.d482 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"pre" }>, align 8
@.d483 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"pn" }>, align 8
@.d484 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d485 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"one, label %" }>, align 8
@.d486 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"b, label %" }>, align 8
@.d487 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"n\0A" }>, align 8
@.d488 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"b:\0A" }>, align 8
@.d489 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d490 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"w = load i32, ptr " }>, align 8
@.d491 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", align " }>, align 8
@.d492 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d493 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d494 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"i = insertelement " }>, align 8
@.d495 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" poison, i32 " }>, align 8
@.d496 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"w, i64 0\0A" }>, align 8
@.d497 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d498 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"s1 = shufflevector " }>, align 8
@.d499 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d500 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i, " }>, align 8
@.d501 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" poison, " }>, align 8
@.d502 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" zeroinitializer\0A" }>, align 8
@.d503 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  br label %" }>, align 8
@.d504 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"n\0A" }>, align 8
@.d505 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"n:\0A  " }>, align 8
@.d506 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"B = phi " }>, align 8
@.d507 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" [ " }>, align 8
@.d508 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"s1, %" }>, align 8
@.d509 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"b ], [ zeroinitializer, %" }>, align 8
@.d510 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ]\0A" }>, align 8
@.d511 = private constant <{ i64, [116 x i8] }> <{ i64 0, [116 x i8] c"  br i1 %pone, label %d1, label %d0\0Ad1:\0A  br i1 %qone, label %h3, label %h1\0Ad0:\0A  br i1 %qone, label %h2, label %h0\0A" }>, align 8
@.d512 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"h" }>, align 8
@.d513 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c":\0A  %j" }>, align 8
@.d514 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" = phi i64 [ 0, %d" }>, align 8
@.d515 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" ], [ %n" }>, align 8
@.d516 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", %v" }>, align 8
@.d517 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ]\0A" }>, align 8
@.d518 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %n" }>, align 8
@.d519 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" = add i64 %j" }>, align 8
@.d520 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d521 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0A  %c" }>, align 8
@.d522 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" = icmp sle i64 %n" }>, align 8
@.d523 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", %g\0A" }>, align 8
@.d524 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"  br i1 %c" }>, align 8
@.d525 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", label %v" }>, align 8
@.d526 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", label %t\0Av" }>, align 8
@.d527 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c":\0A  %ap" }>, align 8
@.d528 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" = getelementptr " }>, align 8
@.d529 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", ptr %a, i64 %j" }>, align 8
@.d530 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d531 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %av" }>, align 8
@.d532 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = load " }>, align 8
@.d533 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ap" }>, align 8
@.d534 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", align 4" }>, align 8
@.d535 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler__2femit__2edotsSteps_2elocal_2e23 = weak hidden constant i1 false
@.d536 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%avK" }>, align 8
@.d537 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%av" }>, align 8
@.d538 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"p" }>, align 8
@.d539 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"q" }>, align 8
@.d540 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"p" }>, align 8
@.d541 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d542 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
@.d543 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"xK" }>, align 8
@.d544 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
@.d545 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"p" }>, align 8
@.d546 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d547 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"o" }>, align 8
@.d548 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" = mul i64 %j" }>, align 8
@.d549 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", %" }>, align 8
@.d550 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"s\0A  " }>, align 8
@.d551 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d552 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" = getelementptr " }>, align 8
@.d553 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d554 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d555 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d556 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d557 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = load " }>, align 8
@.d558 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d559 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d560 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", align " }>, align 8
@.d561 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d562 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %r" }>, align 8
@.d563 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d564 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\0A  store " }>, align 8
@.d565 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" %r" }>, align 8
@.d566 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ap" }>, align 8
@.d567 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", align 4" }>, align 8
@.d568 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\0A  br label %h" }>, align 8
@.d569 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d570 = private constant <{ i64, [104 x i8] }> <{ i64 0, [104 x i8] c"t:\0A  %jt = phi i64 [ 0, %entry ], [ %j0, %h0 ], [ %j1, %h1 ], [ %j2, %h2 ], [ %j3, %h3 ]\0A  br label %sh\0A" }>, align 8
@olang_2esole_2ecompiler__2femit__2elaneDotReduce_2elocal_2e4 = weak hidden constant i1 false
@.d571 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d572 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  %" }>, align 8
@.d573 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".w = sext <" }>, align 8
@.d574 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" x i32> " }>, align 8
@.d575 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" to <" }>, align 8
@.d576 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" x i64>\0A" }>, align 8
@.d577 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d578 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".w" }>, align 8
@.d579 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  %" }>, align 8
@.d580 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = call " }>, align 8
@.d581 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" @llvm.vector.reduce.add.v" }>, align 8
@.d582 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"(<" }>, align 8
@.d583 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" x " }>, align 8
@.d584 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"> " }>, align 8
@.d585 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d586 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"mir.HelperKind.Render" }>, align 8
@.d587 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Equal" }>, align 8
@.d588 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Hash" }>, align 8
@.d589 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Zero" }>, align 8
@.d590 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Copy" }>, align 8
@.d591 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Parts" }>, align 8
@.d592 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Drop" }>, align 8
@.d593 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Guard" }>, align 8
@.d594 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Split" }>, align 8
@.d595 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"mir.HelperKind.Release" }>, align 8
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2femit_2eHomeInst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewrapper(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ad9436b5748221a9_385739db7a2b20ed = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitemNamed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2femit_2eprefixOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2eHomeLoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H0211835ad1df5edc8086b9b7bc878d6e(ptr %v0, ptr %a0)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbg(ptr %v0, ptr %a0)
@olang_loc_4635f1a318b549bc_759936c3a7928310 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_2968b987139e6167_76a7d58ddfcdba8b = external constant [0 x i8]
@olang_loc_493930ee087ace8a_eb37955c75d36e8e = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H86f724e2dc8b3b4d675d56b45c81e2ce(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_82b9110c3ab34805_cdca7d87f9ba97f1 = external constant [0 x i8]
@olang_loc_20b52d6bf9b06c28_18043bf0e12df584 = external constant [0 x i8]
@olang_loc_9bd48c53dce2a143_9d318240a700faef = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2femit_2edbgTail(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eattributes(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiArch(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_6aada305a3873fb6_c16c54d6f05c33ea = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_18f6acb4865fb5f2_de2c0e3f26126f06 = external constant [0 x i8]
@olang_loc_795f0ceaa031aa73_92815be2925279e7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2erefsIn(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_84dc5702af008bfa_68e8ae64d289b3ce = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2femit_3afnEm_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, i1 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3afnEm_2egenLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eleafAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, i64 %a3)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2egenBytes(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2egenClass(i64 %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2einitOrder(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestParts(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eInPart(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efuzzHarness(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %a3)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSource(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ejmpBuf(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esetjmpCall(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_325a0aca37049b03_8faf0435ed6a0227 = external constant [0 x i8]
@olang_loc_c5f6c8e5cb109282_c1c50765d35d3abe = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { { i64, ptr }, { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstInit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, i32 %a2)
declare { { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstGlobal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_3de177096d03f952_4b04555d717d3dfe = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i1 %a4, i1 %a5)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
@olang_loc_7fed6075202c6f47_53bfc91b56218413 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare %"compiler/emit:laneTags" @compiler_2femit_3alaneTags_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epairDotsFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/emit:laneTags" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elaneDotsFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, i1 %a2, %"compiler/emit:laneTags" %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedMake(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2)
@olang_loc_44ed23dda5502268_7ffab923032619a4 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedBits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etoBits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, i64 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceBits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, i64 %a4, { i64, ptr } %a5)
@olang_loc_745b41379bd01239_c904106b8ad08895 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, { i64, [15 x i64] } %a3)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eintoPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, { i64, [15 x i64] } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ervalue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [15 x i64] } %a1, i32 %a2)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2eClear_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eClear_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkEnd(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ereclaim(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eanchorRegion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2ePush_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_73cacc8093766858_2881ed4d4d5af0d4 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_93708b25bcca1908_59bc9d4dcf3d1544 = external constant [0 x i8]
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_82759c8127bb92d9_9a26fc180f98a435 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enarrowBF16(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2fmir_2eStmtSpan(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
