; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Writer" = type { i32, { i64, ptr }, i64, { i32, { i64, [1 x i64] } } }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
define dso_local { i64, ptr } @compiler_2ffix_2eBinDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %s0, ptr %v0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store { i64, ptr } %t1, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca i1
  %l4 = alloca %"std/io:Writer"
  %l5 = alloca %"std/io:Writer"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca %"std/io:Writer"
  %l29 = alloca %"std/io:Writer"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l50 = alloca i1
  %l59 = alloca i32
  %l61 = alloca i1
  %l75 = alloca i32
  %l81 = alloca i64
  %l84 = alloca i64
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i32
  %l109 = alloca i1
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca i1
  %l121 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca i32
  %l137 = alloca i1
  %l141 = alloca { i64, ptr }
  %l151 = alloca i32
  %l153 = alloca i1
  %l158 = alloca i32
  %l160 = alloca i1
  %l168 = alloca i1
  %l171 = alloca i1
  %l174 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  store i1 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStderr, !tbaa !23
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %t1, ptr %t3
  %t5 = insertvalue { ptr, ptr } undef, ptr %t3, 0
  %t6 = icmp ne ptr %t3, null
  %t7 = select i1 %t6, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t8 = insertvalue { ptr, ptr } %t5, ptr %t7, 1
  %t10 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t8, i64 65536)
  store %"std/io:Writer" %t10, ptr %l25
  br label %bb1
bb1:
  %t11 = load %"std/io:Writer", ptr %l25
  store %"std/io:Writer" %t11, ptr %l4
  %t12 = load i32, ptr @G_2estd_2fio_2eStdout, !tbaa !23
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %t12, ptr %t14
  %t16 = insertvalue { ptr, ptr } undef, ptr %t14, 0
  %t17 = icmp ne ptr %t14, null
  %t18 = select i1 %t17, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t19 = insertvalue { ptr, ptr } %t16, ptr %t18, 1
  %t21 = call %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t19, i64 65536)
  store %"std/io:Writer" %t21, ptr %l29
  br label %bb2
bb2:
  %t22 = load %"std/io:Writer", ptr %l29
  store %"std/io:Writer" %t22, ptr %l5
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %v0, { i64, ptr } %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l31
  br label %bb3
bb3:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t27 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t27
  %t29 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %s0, ptr %t27)
  store { i64, ptr } %t29, ptr %l33
  br label %bb4
bb4:
  %t30 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l34
  br label %bb5
bb5:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l7
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l10, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  br label %bb25
bb8:
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t47, ptr %l42, !tbaa !27
  %t48 = load i64, ptr %l9, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %t51, i64 %t48
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !37
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t57 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t55)
  %t58 = extractvalue { i32, { i64, ptr } } %t57, 1
  %t59 = extractvalue { i32, { i64, ptr } } %t57, 0
  store i32 %t59, ptr %l48
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb11, label %ok.61, !prof !99
ok.61:
  store { i64, ptr } %t58, ptr %l47
  br label %bb10
bb10:
  %t62 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t62, ptr %l45, !tbaa !27
  br label %bb22
bb11:
  %t63 = load i32, ptr %l48, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  store i1 %t66, ptr %l50, !tbaa !21
  %t67 = load i32, ptr %l48, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t72 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t73 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t76 = extractvalue { i64, ptr } %t72, 1
  %t77 = extractvalue { i64, ptr } %t72, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  %t89 = extractvalue { i64, ptr } %t86, 0
  %t90 = extractvalue { i64, ptr } %t86, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s3, ptr %l4, { i64, ptr } %t94)
  br label %bb15
bb15:
  %t98 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t98, ptr %l59
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb17, label %ok.100, !prof !99
ok.100:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t101 = load i32, ptr %l59, !tbaa !23
  %t102 = ashr i32 %t101, 16
  %t104 = icmp eq i32 %t102, 1
  store i1 %t104, ptr %l61, !tbaa !21
  %t105 = load i32, ptr %l59, !tbaa !23
  %t106 = ashr i32 %t105, 16
  %t108 = icmp eq i32 %t106, 1
  br i1 %t108, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb22:
  %t111 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t111)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb6
bb25:
  %t120 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t128 = call i32 @compiler_2ffix_2erun(ptr %s0, ptr %s0, ptr %v1, ptr %v2, ptr %s0, { i64, ptr } %t120, ptr %l7, { i64, ptr } %a2, { i64, ptr } %a3, ptr %l4)
  store i32 %t128, ptr %l75
  br label %bb26
bb26:
  %t129 = load i32, ptr %l75, !tbaa !23
  store i32 %t129, ptr %l13, !tbaa !23
  store i64 0, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t134 = load i64, ptr %l16, !tbaa !24
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb27, label %bb28
bb27:
  %t140 = load i64, ptr %l17, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb32
bb29:
  %t144 = load i64, ptr %l16, !tbaa !24
  %t145 = load i64, ptr %l15, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l17, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l17, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l84, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb31
bb31:
  %t160 = load i64, ptr %l84, !tbaa !24
  store i64 %t160, ptr %l81, !tbaa !24
  br label %bb32
bb32:
  %t161 = load i64, ptr %l81, !tbaa !24
  store i64 %t161, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t162 = load i64, ptr %l19, !tbaa !24
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s8)
  br label %bb61
bb35:
  br label %bb36
bb36:
  %t170 = load i64, ptr %l15, !tbaa !24
  %t171 = load i64, ptr %l19, !tbaa !24
  %t172 = load i64, ptr %l17, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l20, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t180, ptr %l103, !tbaa !27
  %t181 = load i64, ptr %l20, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %t184, i64 %t181
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !37
  %t188 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s8, { i64, ptr } %t186)
  %t189 = extractvalue { i32, { i64, ptr } } %t188, 1
  %t190 = extractvalue { i32, { i64, ptr } } %t188, 0
  store i32 %t190, ptr %l107
  %t191 = icmp ne i32 %t190, 0
  br i1 %t191, label %bb38, label %ok.192, !prof !99
ok.192:
  store { i64, ptr } %t189, ptr %l106
  br label %bb37
bb37:
  %t193 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t193, ptr %l102, !tbaa !27
  br label %bb42
bb38:
  %t194 = load i32, ptr %l107, !tbaa !23
  %t195 = ashr i32 %t194, 16
  %t197 = icmp eq i32 %t195, 1
  store i1 %t197, ptr %l109, !tbaa !21
  %t198 = load i32, ptr %l107, !tbaa !23
  %t199 = ashr i32 %t198, 16
  %t201 = icmp eq i32 %t199, 1
  br i1 %t201, label %bb39, label %bb40
bb39:
  call void @__olang_errpay_pop()
  br label %bb40
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb42:
  %t203 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t203, ptr %l112, !tbaa !27
  %t205 = load i64, ptr %l20, !tbaa !24
  %t208 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l7, i64 %t205)
  store { i64, ptr } %t208, ptr %l115
  br label %bb43
bb43:
  %t209 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t211 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s0, { i64, ptr } %t209, { i64, ptr } %t210)
  store i1 %t211, ptr %l116
  br label %bb44
bb44:
  %t212 = load i1, ptr %l116, !tbaa !21
  br i1 %t212, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb46:
  br label %bb47
bb47:
  %t213 = load i64, ptr %l14, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l14, !tbaa !24
  %t218 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t218, ptr %l121, !tbaa !27
  %t219 = load i64, ptr %l20, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %t222, i64 %t219
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !37
  %t226 = extractvalue { i64, ptr } %t224, 1
  %t227 = extractvalue { i64, ptr } %t224, 0
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t230 = add i64 %t227, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t226, i64 %t227)
  %t232 = getelementptr i8, ptr %t231, i64 %t227
  call void @olang_textcopy(ptr %t232, ptr %t228, i64 %t229)
  %t233 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t231, 1
  %t237 = extractvalue { i64, ptr } %t234, 0
  %t238 = extractvalue { i64, ptr } %t234, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s8, ptr %l5, { i64, ptr } %t242)
  br label %bb48
bb48:
  %t245 = load i1, ptr %l0, !tbaa !21
  br i1 %t245, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t247 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t247, ptr %l128, !tbaa !27
  %t248 = load i64, ptr %l20, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr { i64, ptr }, ptr %t251, i64 %t248
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !37
  store { i64, ptr } %t253, ptr %l130, !tbaa !27
  %t254 = load i64, ptr %l20, !tbaa !24
  %t257 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s12, ptr %l7, i64 %t254)
  store { i64, ptr } %t257, ptr %l133
  br label %bb51
bb50:
  br label %bb59
bb51:
  %t258 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t261 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s12, { i64, ptr } %t259, { i64, ptr } %t258)
  store i32 %t261, ptr %l135
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb53, label %ok.263, !prof !99
ok.263:
  br label %bb52
bb52:
  br label %bb58
bb53:
  %t264 = load i32, ptr %l135, !tbaa !23
  %t265 = ashr i32 %t264, 16
  %t267 = icmp eq i32 %t265, 1
  store i1 %t267, ptr %l137, !tbaa !21
  %t268 = load i32, ptr %l135, !tbaa !23
  %t269 = ashr i32 %t268, 16
  %t271 = icmp eq i32 %t269, 1
  br i1 %t271, label %bb54, label %bb55
bb54:
  call void @__olang_errpay_pop()
  br label %bb55
bb55:
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t273 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t273, ptr %l141, !tbaa !27
  %t274 = load i64, ptr %l20, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %t277, i64 %t274
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !37
  %t280 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t283 = extractvalue { i64, ptr } %t279, 1
  %t284 = extractvalue { i64, ptr } %t279, 0
  %t285 = add i64 %t281, %t284
  %t286 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t287 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t288 = add i64 %t285, %t287
  %t289 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t288)
  call void @olang_textcopy(ptr %t289, ptr %t280, i64 %t281)
  %t290 = getelementptr i8, ptr %t289, i64 %t281
  call void @olang_textcopy(ptr %t290, ptr %t283, i64 %t284)
  %t291 = getelementptr i8, ptr %t290, i64 %t284
  call void @olang_textcopy(ptr %t291, ptr %t286, i64 %t287)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t289, 1
  %t296 = extractvalue { i64, ptr } %t293, 0
  %t297 = extractvalue { i64, ptr } %t293, 1
  %t298 = mul i64 %t296, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t299, ptr %t297, i64 %t298, i1 false)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %s0, ptr %s13, ptr %l4, { i64, ptr } %t301)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb60:
  %t304 = load i64, ptr %l19, !tbaa !24
  %t307 = add i64 %t304, 1
  store i64 %t307, ptr %l19, !tbaa !24
  br label %bb33
bb61:
  %t310 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l5)
  store i32 %t310, ptr %l151
  %t311 = icmp ne i32 %t310, 0
  br i1 %t311, label %bb63, label %ok.312, !prof !99
ok.312:
  br label %bb62
bb62:
  br label %bb67
bb63:
  %t313 = load i32, ptr %l151, !tbaa !23
  %t314 = ashr i32 %t313, 16
  %t316 = icmp eq i32 %t314, 1
  store i1 %t316, ptr %l153, !tbaa !21
  %t317 = load i32, ptr %l151, !tbaa !23
  %t318 = ashr i32 %t317, 16
  %t320 = icmp eq i32 %t318, 1
  br i1 %t320, label %bb64, label %bb65
bb64:
  call void @__olang_errpay_pop()
  br label %bb65
bb65:
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb67:
  %t324 = call i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %s0, ptr %l4)
  store i32 %t324, ptr %l158
  %t325 = icmp ne i32 %t324, 0
  br i1 %t325, label %bb69, label %ok.326, !prof !99
ok.326:
  br label %bb68
bb68:
  br label %bb73
bb69:
  %t327 = load i32, ptr %l158, !tbaa !23
  %t328 = ashr i32 %t327, 16
  %t330 = icmp eq i32 %t328, 1
  store i1 %t330, ptr %l160, !tbaa !21
  %t331 = load i32, ptr %l158, !tbaa !23
  %t332 = ashr i32 %t331, 16
  %t334 = icmp eq i32 %t332, 1
  br i1 %t334, label %bb70, label %bb71
bb70:
  call void @__olang_errpay_pop()
  br label %bb71
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb73:
  %t337 = load i32, ptr %l13, !tbaa !23
  %t339 = icmp eq i32 %t337, 2
  br i1 %t339, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t342 = load i1, ptr %l0, !tbaa !21
  br i1 %t342, label %bb77, label %bb78
bb77:
  %t344 = load i64, ptr %l14, !tbaa !24
  %t346 = icmp sgt i64 %t344, 0
  store i1 %t346, ptr %l168, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb79
bb79:
  %t348 = load i1, ptr %l168, !tbaa !21
  br i1 %t348, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb82
bb81:
  %t349 = load i32, ptr %l13, !tbaa !23
  %t351 = icmp eq i32 %t349, 1
  store i1 %t351, ptr %l171, !tbaa !21
  br label %bb82
bb82:
  %t353 = load i1, ptr %l171, !tbaa !21
  br i1 %t353, label %bb83, label %bb84
bb83:
  store i32 1, ptr %l174, !tbaa !23
  br label %bb85
bb84:
  store i32 0, ptr %l174, !tbaa !23
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t354 = load i32, ptr %l174, !tbaa !23
  store i32 %t354, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eOrder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca [46 x { i64, ptr }]
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i1
  %l53 = alloca i1
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr @G_2ecompiler_2ffix_2eToolNames, i64 736, i1 false)
  %t26 = load [46 x { i64, ptr }], ptr %l23
  store i64 46, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l28, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr [46 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t74
  %t77 = load i64, ptr %t76, !tbaa !34
  %t79 = call i1 @compiler_2ffix_2edriven(i64 %t77)
  store i1 %t79, ptr %l51
  br label %bb16
bb16:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr @__olang_prog_scope
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t81, ptr %s4, { i64, ptr } %t80, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t83, ptr %l53
  br label %bb17
bb17:
  %t84 = load i1, ptr %l51, !tbaa !21
  %t85 = load i1, ptr %l53, !tbaa !21
  %t86 = icmp eq i1 %t84, %t85
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l0, i64 %t88)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l9, !tbaa !24
  br label %bb12
bb23:
  br label %bb24
bb24:
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = add i64 %t96, 1
  store i64 %t99, ptr %l2, !tbaa !24
  br label %bb2
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t102 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l0)
  store { i64, ptr } %t102, ptr %l64
  br label %bb26
bb26:
  %t103 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t103, ptr %l65, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l66, !tbaa !24
  %t106 = load i64, ptr %l66, !tbaa !24
  %t107 = mul i64 %t106, 8
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l67, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l66, !tbaa !24
  %t116 = mul i64 %t115, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t117, ptr %l65, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t118 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eProgramOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca [2 x { i64, ptr }]
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l5, { i64, ptr } %a3)
  br label %bb2
bb2:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v4, ptr %l5, { i64, ptr } %a4)
  br label %bb3
bb3:
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l14
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l6
  store { i64, ptr } %a2, ptr %l15, !tbaa !27
  %t12 = call ptr @__olang_scope_hold(ptr %s0)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l16, !tbaa !24
  %t14 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = call ptr @__olang_region_make(ptr %s0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 1
  %t21 = extractvalue { i64, ptr } %t18, 0
  %t22 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l16
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t22, i64 %t23)
  %t29 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  %t32 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t33 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t32, 0
  %t35 = insertvalue [2 x { i64, ptr }] %t33, { i64, ptr } %t30, 1
  store [2 x { i64, ptr }] %t35, ptr %l7
  %t38 = insertvalue { i64, ptr } undef, i64 2, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %l7, 1
  %t41 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t39)
  store { i64, ptr } %t41, ptr %l24
  br label %bb7
bb7:
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  call void @compiler_2ffix_2eclosure(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t48, ptr %l6, ptr %l5)
  br label %bb8
bb8:
  store { i64, ptr } %a0, ptr %l28, !tbaa !27
  %t53 = call ptr @__olang_scope_hold(ptr %s0)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l29, !tbaa !24
  %t55 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t57 = call ptr @__olang_region_make(ptr %s0)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l31, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t61, ptr %l33
  br label %bb11
bb11:
  %t62 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l34, !tbaa !24
  %t64 = icmp sge i64 0, 0
  br i1 %t64, label %bb12, label %bb13
bb12:
  %t66 = icmp sle i64 0, 16
  br i1 %t66, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_cce2230832d6a50c_2dcd918d424b1980)
  unreachable
bb14:
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = icmp sle i64 16, %t68
  br i1 %t69, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_cce2230832d6a50c_2dcd918d424b1980)
  unreachable
bb16:
  %t71 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i8, ptr %t72, i64 0
  %t74 = sub i64 16, 0
  %t75 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t73, 1
  %t77 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t79 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t87 = extractvalue { i64, ptr } %t76, 1
  %t88 = extractvalue { i64, ptr } %t76, 0
  %t89 = add i64 %t85, %t88
  %t90 = load i64, ptr %l29
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_held_alloc(ptr %t91, i64 %t89)
  call void @olang_textcopy(ptr %t92, ptr %t77, i64 %t78)
  %t93 = getelementptr i8, ptr %t92, i64 %t78
  call void @olang_textcopy(ptr %t93, ptr %t80, i64 %t81)
  %t94 = getelementptr i8, ptr %t93, i64 %t81
  call void @olang_textcopy(ptr %t94, ptr %t83, i64 %t84)
  %t95 = getelementptr i8, ptr %t94, i64 %t84
  call void @olang_textcopy(ptr %t95, ptr %t87, i64 %t88)
  %t96 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t92, 1
  %t99 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t100 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t99, 0
  %t102 = insertvalue [2 x { i64, ptr }] %t100, { i64, ptr } %t97, 1
  store [2 x { i64, ptr }] %t102, ptr %l8
  %t105 = insertvalue { i64, ptr } undef, i64 2, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %l8, 1
  %t108 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %v5, { i64, ptr } %t106)
  store { i64, ptr } %t108, ptr %l44
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_cce2230832d6a50c_2dcd918d424b1980)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca [2 x { i64, ptr }]
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l11 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d12, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l7
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l7, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t15, ptr %l11
  br label %bb7
bb7:
  %t16 = load i1, ptr %l11, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t29, ptr %l16
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t30, 0
  %t32 = insertvalue [2 x { i64, ptr }] %t31, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t32, ptr %l3
  %t35 = insertvalue { i64, ptr } undef, i64 2, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %l3, 1
  %t38 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t36)
  store { i64, ptr } %t38, ptr %l20
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t39, ptr %l4, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t40)
  store i1 %t42, ptr %l22
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t54 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t54, ptr %l26
  br label %bb17
bb17:
  %t55 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = getelementptr i8, ptr %t61, i64 %t57
  call void @olang_textcopy(ptr %t62, ptr %t58, i64 %t59)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t61, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v0, ptr %t5, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffix_2eStdTool, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t15, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb5
bb4:
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenOpt, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  br i1 %t21, label %bb7, label %bb8
bb5:
  %t23 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v2, ptr %t23, { i64, ptr } %a3)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t27 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t27, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb9
bb8:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2ffix_2eDrivenArg, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb9:
  %t35 = load ptr, ptr %lp5
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v1, ptr %t35, { i64, ptr } %t36)
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t39 = load ptr, ptr %lp5
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v1, ptr %t39, { i64, ptr } %t40)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  store { i64, ptr } %a4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t57, ptr %l37, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %t61, i64 %t58
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !37
  %t65 = load ptr, ptr %lp5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v3, ptr %t65, { i64, ptr } %t63)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb17
bb23:
  %t74 = load ptr, ptr %lp5
  %t76 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v4, ptr %v4, ptr %t74)
  store { i64, ptr } %t76, ptr %l46
  br label %bb24
bb24:
  %t77 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t77, ptr %l47, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l48, !tbaa !24
  %t80 = load i64, ptr %l48, !tbaa !24
  %t81 = mul i64 %t80, 16
  %t82 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l49, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l48, !tbaa !24
  %t90 = mul i64 %t89, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2ebuildAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca [46 x { i64, ptr }]
  %l18 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l45 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %jh5 = alloca ptr
  %rv = alloca { i64, ptr }
  %t11 = alloca i64
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr @G_2ecompiler_2ffix_2eToolNames, i64 736, i1 false)
  %t1 = load [46 x { i64, ptr }], ptr %l17
  store i64 46, ptr %l18, !tbaa !24
  %t2 = load i64, ptr %l18, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l18, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_f01e9d7c18290f7e_330799ec5065ffa2)
  unreachable
bb3:
  %t8 = load i64, ptr %l18, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t9)
  store i64 0, ptr %t11
  br label %fill.12
fill.12:
  %t15 = load i64, ptr %t11
  %t16 = icmp slt i64 %t15, %t8
  br i1 %t16, label %fillb.13, label %filld.14
fillb.13:
  %t17 = getelementptr { i64, ptr }, ptr %t10, i64 %t15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %t17
  %t18 = add i64 %t15, 1
  store i64 %t18, ptr %t11
  br label %fill.12
filld.14:
  %t19 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t10, 1
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l22
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f01e9d7c18290f7e_330799ec5065ffa2)
  unreachable
bb5:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l6
  store ptr %a3, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t26 = load i64, ptr %l8, !tbaa !24
  store i64 %t26, ptr %l24, !tbaa !24
  %t27 = load ptr, ptr %l7, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t27)
  store i64 %t29, ptr %l26
  br label %bb7
bb7:
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = load i64, ptr %l26, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  br label %bb18
bb9:
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l31
  br label %bb11
bb11:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l9, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t42, ptr %l32, !tbaa !27
  %t43 = load i64, ptr %l9, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %t46, i64 %t43
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !37
  %t50 = call i1 @std_2fos_2eExists(ptr %v4, { i64, ptr } %t48)
  store i1 %t50, ptr %l35
  br label %bb12
bb12:
  %t51 = load i1, ptr %l35, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t54)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = add i64 %t57, 1
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb6
bb18:
  %t62 = icmp sge i64 1, 0
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = icmp sle i64 1, 1152921504606846975
  br i1 %t64, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_5136839c006764b3_5260dfbee4468c57)
  unreachable
bb21:
  %t66 = mul i64 1, 8
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 1, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l10, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s5
  store ptr null, ptr %jh5
  store i64 0, ptr %l11, !tbaa !24
  %t71 = load i64, ptr @G_2ecompiler_2ffix_2eBuildWidth, !tbaa !24
  store i64 %t71, ptr %l45, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t73, ptr %l47
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_5136839c006764b3_5260dfbee4468c57)
  unreachable
bb23:
  %t74 = load i64, ptr %l45, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t74, i64 %t75)
  store i64 %t76, ptr %l48
  br label %bb24
bb24:
  %t77 = load i64, ptr %l48, !tbaa !24
  store i64 %t77, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t78 = load i64, ptr %l12, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb25, label %bb26
bb25:
  %t84 = load i64, ptr %l13, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb30
bb27:
  %t88 = load i64, ptr %l12, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l13, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l55, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb29
bb29:
  %t104 = load i64, ptr %l55, !tbaa !24
  store i64 %t104, ptr %l52, !tbaa !24
  br label %bb30
bb30:
  %t105 = load i64, ptr %l52, !tbaa !24
  store i64 %t105, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t106 = load i64, ptr %l15, !tbaa !24
  %t107 = load i64, ptr %l14, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l16, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = call ptr @__olang_standin_in(ptr %v0, ptr %s5)
  %t138 = call ptr @__olang_standin_in(ptr %v1, ptr %s5)
  %t139 = call ptr @__olang_standin_in(ptr %v2, ptr %s5)
  %t140 = call ptr @__olang_standin_in(ptr %s0, ptr %s5)
  %t141 = call ptr @__olang_standin_in(ptr %v4, ptr %s5)
  %t142 = call ptr @__olang_standin_in(ptr %s0, ptr %s5)
  %t143 = call ptr @__olang_standin_in(ptr %v5, ptr %s5)
  %t144 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t145 = ptrtoint ptr %t144 to i64
  %t146 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 %t145, i64 8)
  %t147 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 0
  store { i64, ptr } %a0, ptr %t147
  %t148 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 1
  store { i64, ptr } %a1, ptr %t148
  %t149 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 2
  store { i64, ptr } %a2, ptr %t149
  %t150 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 3
  store ptr %l6, ptr %t150
  %t151 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 4
  store { i64, ptr } %t127, ptr %t151
  %t152 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 5
  store { i64, ptr } %t128, ptr %t152
  %t153 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 6
  store { i64, ptr } %t129, ptr %t153
  %t154 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 7
  store ptr %t137, ptr %t154
  %t155 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 8
  store ptr %t138, ptr %t155
  %t156 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 9
  store ptr %t139, ptr %t156
  %t157 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 10
  store ptr %t140, ptr %t157
  %t158 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 11
  store ptr %t141, ptr %t158
  %t159 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 12
  store ptr %t142, ptr %t159
  %t160 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t146, i32 0, i32 13
  store ptr %t143, ptr %t160
  %t161 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 40, i64 8)
  %t162 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr null, ptr %t162
  %t163 = getelementptr { ptr, ptr }, ptr %t162, i32 0, i32 1
  store ptr %t137, ptr %t163
  %t164 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t162, ptr %t164
  %t165 = getelementptr { ptr, ptr }, ptr %t164, i32 0, i32 1
  store ptr %t138, ptr %t165
  %t166 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t164, ptr %t166
  %t167 = getelementptr { ptr, ptr }, ptr %t166, i32 0, i32 1
  store ptr %t139, ptr %t167
  %t168 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t166, ptr %t168
  %t169 = getelementptr { ptr, ptr }, ptr %t168, i32 0, i32 1
  store ptr %t140, ptr %t169
  %t170 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t168, ptr %t170
  %t171 = getelementptr { ptr, ptr }, ptr %t170, i32 0, i32 1
  store ptr %t141, ptr %t171
  %t172 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t170, ptr %t172
  %t173 = getelementptr { ptr, ptr }, ptr %t172, i32 0, i32 1
  store ptr %t142, ptr %t173
  %t174 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 16, i64 8)
  store ptr %t172, ptr %t174
  %t175 = getelementptr { ptr, ptr }, ptr %t174, i32 0, i32 1
  store ptr %t143, ptr %t175
  %t176 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t161, i32 0, i32 2
  store ptr %t174, ptr %t176
  %t177 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t161, i32 0, i32 1
  store i64 0, ptr %t177
  %t178 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t161, i32 0, i32 3
  store i64 0, ptr %t178
  %t179 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t161, i32 0, i32 4
  store ptr null, ptr %t179
  %t180 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t180, ptr @olang_task20, ptr %t146, ptr %t161)
  %t181 = load ptr, ptr %jh5
  store ptr %t181, ptr %t161
  store ptr %t161, ptr %jh5
  br label %bb35
bb35:
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l15, !tbaa !24
  br label %bb31
bb36:
  %t187 = call i64 @__olang_join_tasks_keep(ptr %jh5, i1 false)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t188 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t188, ptr %l84, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  store i64 %t191, ptr %l85, !tbaa !24
  %t192 = load i64, ptr %l85, !tbaa !24
  %t193 = mul i64 %t192, 16
  %t194 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l86, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = load i64, ptr %l85, !tbaa !24
  %t202 = mul i64 %t201, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t198, ptr %t200, i64 %t202, i1 false)
  %t203 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t203, ptr %l84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t204 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t204, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ffix_2ebuildTool(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i32, { i64, [2 x i64] } }
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l9 = alloca [2 x { i64, ptr }]
  %l10 = alloca [5 x { i64, ptr }]
  %l11 = alloca { i32, { i64, [2 x i64] } }
  %l12 = alloca %"std/os:Output"
  %l13 = alloca { i32, { i64, [2 x i64] } }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca [2 x { i64, ptr }]
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i32, { i64, [2 x i64] } }
  %l31 = alloca { i32, { i64, [2 x i64] } }
  %l32 = alloca i32
  %l37 = alloca { i32, { i64, [2 x i64] } }
  %l38 = alloca { i32, { i64, [2 x i64] } }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i32, { i64, [2 x i64] } }
  %l44 = alloca { i32, { i64, [2 x i64] } }
  %l45 = alloca i32
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, [2 x i64] }
  %l62 = alloca i64
  %l64 = alloca { i64, [2 x i64] }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"std/os:Output"
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l91 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"std/os:Output"
  %l99 = alloca i32
  %l101 = alloca i1
  %l102 = alloca { i32, { i64, [2 x i64] } }
  %l103 = alloca { i32, { i64, [2 x i64] } }
  %l104 = alloca i32
  %l109 = alloca { i32, { i64, [2 x i64] } }
  %l110 = alloca { i32, { i64, [2 x i64] } }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i32, { i64, [2 x i64] } }
  %l116 = alloca { i32, { i64, [2 x i64] } }
  %l117 = alloca i32
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, [2 x i64] }
  %l134 = alloca i64
  %l136 = alloca { i64, [2 x i64] }
  %l138 = alloca i32
  %l140 = alloca i32
  %l142 = alloca i1
  %l151 = alloca { i64, [2 x i64] }
  %l152 = alloca i64
  %l154 = alloca { i64, [2 x i64] }
  %l156 = alloca i32
  %l158 = alloca i32
  %l160 = alloca i1
  %l165 = alloca i32
  %l167 = alloca i1
  %l168 = alloca { i32, { i64, [2 x i64] } }
  %l169 = alloca { i32, { i64, [2 x i64] } }
  %l170 = alloca i32
  %l175 = alloca { i32, { i64, [2 x i64] } }
  %l176 = alloca { i32, { i64, [2 x i64] } }
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i32, { i64, [2 x i64] } }
  %l182 = alloca { i32, { i64, [2 x i64] } }
  %l183 = alloca i32
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, [2 x i64] }
  %l200 = alloca i64
  %l202 = alloca { i64, [2 x i64] }
  %l204 = alloca i32
  %l206 = alloca i32
  %l208 = alloca i1
  %l211 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i32
  %l227 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l240 = alloca i1
  %l241 = alloca i1
  %l244 = alloca i1
  %l247 = alloca i32
  %l249 = alloca i1
  %l256 = alloca i32
  %l258 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %rv = alloca i32
  %t91 = alloca { i64, [2 x i64] }, align 8
  %t411 = alloca { i64, [2 x i64] }, align 8
  %t610 = alloca { i64, [2 x i64] }, align 8
  %t714 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t20 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t16)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l27
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb2, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l26
  br label %bb1
bb1:
  %t25 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  br label %bb26
bb2:
  %t26 = load i32, ptr %l27, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  store i1 %t29, ptr %l29, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l5
  %t30 = load i32, ptr %l27, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t39 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l5, i32 0, i32 0
  store i32 %t38, ptr %t39, !tbaa !23
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load { i32, { i64, [2 x i64] } }, ptr %l5
  store { i32, { i64, [2 x i64] } } %t40, ptr %l30
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l31
  %t41 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l30, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  store i32 %t42, ptr %l32, !tbaa !23
  %t43 = load i32, ptr %l32, !tbaa !23
  %t44 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l31, i32 0, i32 0
  store i32 %t43, ptr %t44, !tbaa !23
  %t45 = load i32, ptr %l32, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  br i1 %t48, label %bb4, label %bb5
bb4:
  %t50 = call ptr @__olang_errpay_top_get()
  %t52 = load { i64, [2 x i64] }, ptr %t50
  %t53 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l31, i32 0, i32 1
  store { i64, [2 x i64] } %t52, ptr %t53
  br label %bb5
bb5:
  %t55 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l31)
  store { i32, { i64, [2 x i64] } } %t55, ptr %l37
  br label %bb6
bb6:
  %t56 = load { i32, { i64, [2 x i64] } }, ptr %l37
  store { i32, { i64, [2 x i64] } } %t56, ptr %l5
  %t57 = load { i32, { i64, [2 x i64] } }, ptr %l5
  store { i32, { i64, [2 x i64] } } %t57, ptr %l38
  %t58 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l38, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  br i1 %t62, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t64, ptr %l41, !tbaa !27
  %t65 = load { i32, { i64, [2 x i64] } }, ptr %l5
  store { i32, { i64, [2 x i64] } } %t65, ptr %l42
  %t67 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s2, ptr %l42)
  store { i32, { i64, [2 x i64] } } %t67, ptr %l44
  br label %bb9
bb9:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t68 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t68, i64 %t69)
  %t70 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  call void @__olang_sb_put(ptr %s3, ptr %t71, i64 %t72)
  %t73 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t73, i64 %t74)
  %t75 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  store i32 %t76, ptr %l45, !tbaa !23
  %t77 = load i32, ptr %l45, !tbaa !23
  %t78 = icmp eq i32 %t77, 0
  br i1 %t78, label %bb11, label %bb12
bb10:
  %t80 = load ptr, ptr %s3
  %t81 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t82 = load i64, ptr %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t80, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l60, !tbaa !27
  %t86 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t87 = load ptr, ptr %t86
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %sbgrew.89, label %sbdone.90
sbgrew.89:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.90
sbdone.90:
  store { i64, [2 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [2 x i64] }, ptr %t91, i32 0, i32 0
  store i64 0, ptr %t92
  %t93 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t94 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t93, 0
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t91, i32 0, i32 1
  store { { i64, ptr } } %t94, ptr %t95
  %t96 = load { i64, [2 x i64] }, ptr %t91
  store { i64, [2 x i64] } %t96, ptr %l61
  %t97 = call ptr @__olang_errpay_push()
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l62, !tbaa !24
  %t99 = load i64, ptr %l62
  %t100 = inttoptr i64 %t99 to ptr
  %t102 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %t100, ptr %l61)
  store { i64, [2 x i64] } %t102, ptr %l64
  br label %bb25
bb11:
  %t103 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t103, i64 %t104)
  br label %bb10
bb12:
  %t105 = load i32, ptr %l45, !tbaa !23
  %t106 = icmp eq i32 %t105, 65536
  br i1 %t106, label %bb13, label %bb14
bb13:
  %t108 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t108, i64 %t109)
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t110, i64 %t111)
  %t112 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t113 = getelementptr { i64, [2 x i64] }, ptr %t112, i32 0, i32 1
  %t114 = getelementptr { { i64, ptr } }, ptr %t113, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = extractvalue { i64, ptr } %t115, 0
  %t119 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t117, i64 %t118, i8 34)
  %t120 = call ptr @__olang_sb_room(ptr %s3, i64 %t119)
  %t121 = call i64 @__olang_rd_quote(ptr %t120, i64 0, ptr %t117, i64 %t118, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t119)
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t122, i64 %t123)
  br label %bb10
bb14:
  %t124 = load i32, ptr %l45, !tbaa !23
  %t125 = icmp eq i32 %t124, 65537
  br i1 %t125, label %bb15, label %bb16
bb15:
  %t127 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t127, i64 %t128)
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t129, i64 %t130)
  %t131 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t132 = getelementptr { i64, [2 x i64] }, ptr %t131, i32 0, i32 1
  %t133 = getelementptr { { i64, ptr } }, ptr %t132, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133
  %t136 = extractvalue { i64, ptr } %t134, 1
  %t137 = extractvalue { i64, ptr } %t134, 0
  %t138 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t136, i64 %t137, i8 34)
  %t139 = call ptr @__olang_sb_room(ptr %s3, i64 %t138)
  %t140 = call i64 @__olang_rd_quote(ptr %t139, i64 0, ptr %t136, i64 %t137, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t138)
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t141, i64 %t142)
  br label %bb10
bb16:
  %t143 = load i32, ptr %l45, !tbaa !23
  %t144 = icmp eq i32 %t143, 65538
  br i1 %t144, label %bb17, label %bb18
bb17:
  %t146 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t146, i64 %t147)
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t148, i64 %t149)
  %t150 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t151 = getelementptr { i64, [2 x i64] }, ptr %t150, i32 0, i32 1
  %t152 = getelementptr { { i64, ptr } }, ptr %t151, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = extractvalue { i64, ptr } %t153, 0
  %t157 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t155, i64 %t156, i8 34)
  %t158 = call ptr @__olang_sb_room(ptr %s3, i64 %t157)
  %t159 = call i64 @__olang_rd_quote(ptr %t158, i64 0, ptr %t155, i64 %t156, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t157)
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t160, i64 %t161)
  br label %bb10
bb18:
  %t162 = load i32, ptr %l45, !tbaa !23
  %t163 = icmp eq i32 %t162, 65539
  br i1 %t163, label %bb19, label %bb20
bb19:
  %t165 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t165, i64 %t166)
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t167, i64 %t168)
  %t169 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t170 = getelementptr { i64, [2 x i64] }, ptr %t169, i32 0, i32 1
  %t171 = getelementptr { { i64, ptr } }, ptr %t170, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171
  %t174 = extractvalue { i64, ptr } %t172, 1
  %t175 = extractvalue { i64, ptr } %t172, 0
  %t176 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t174, i64 %t175, i8 34)
  %t177 = call ptr @__olang_sb_room(ptr %s3, i64 %t176)
  %t178 = call i64 @__olang_rd_quote(ptr %t177, i64 0, ptr %t174, i64 %t175, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t176)
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t179, i64 %t180)
  br label %bb10
bb20:
  %t181 = load i32, ptr %l45, !tbaa !23
  %t182 = icmp eq i32 %t181, 65540
  br i1 %t182, label %bb21, label %bb22
bb21:
  %t184 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t184, i64 %t185)
  %t186 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t186, i64 %t187)
  %t188 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t189 = getelementptr { i64, [2 x i64] }, ptr %t188, i32 0, i32 1
  %t190 = getelementptr { { i64, ptr } }, ptr %t189, i32 0, i32 0
  %t191 = load { i64, ptr }, ptr %t190
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = extractvalue { i64, ptr } %t191, 0
  %t195 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t193, i64 %t194, i8 34)
  %t196 = call ptr @__olang_sb_room(ptr %s3, i64 %t195)
  %t197 = call i64 @__olang_rd_quote(ptr %t196, i64 0, ptr %t193, i64 %t194, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t195)
  %t198 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t198, i64 %t199)
  br label %bb10
bb22:
  %t200 = load i32, ptr %l45, !tbaa !23
  %t201 = icmp eq i32 %t200, 65541
  br i1 %t201, label %bb23, label %bb24
bb23:
  %t203 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t203, i64 %t204)
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t205, i64 %t206)
  %t207 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t208 = getelementptr { i64, [2 x i64] }, ptr %t207, i32 0, i32 1
  %t209 = getelementptr { { i64, ptr } }, ptr %t208, i32 0, i32 0
  %t210 = load { i64, ptr }, ptr %t209
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = extractvalue { i64, ptr } %t210, 0
  %t214 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t212, i64 %t213, i8 34)
  %t215 = call ptr @__olang_sb_room(ptr %s3, i64 %t214)
  %t216 = call i64 @__olang_rd_quote(ptr %t215, i64 0, ptr %t212, i64 %t213, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t214)
  %t217 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t217, i64 %t218)
  br label %bb10
bb24:
  %t219 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t219, i64 %t220)
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t221, i64 %t222)
  %t223 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l44, i32 0, i32 1
  %t224 = getelementptr { i64, [2 x i64] }, ptr %t223, i32 0, i32 1
  %t225 = getelementptr { { i64, ptr } }, ptr %t224, i32 0, i32 0
  %t226 = load { i64, ptr }, ptr %t225
  %t228 = extractvalue { i64, ptr } %t226, 1
  %t229 = extractvalue { i64, ptr } %t226, 0
  %t230 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t228, i64 %t229, i8 34)
  %t231 = call ptr @__olang_sb_room(ptr %s3, i64 %t230)
  %t232 = call i64 @__olang_rd_quote(ptr %t231, i64 0, ptr %t228, i64 %t229, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t230)
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t233, i64 %t234)
  br label %bb10
bb25:
  %t235 = load { i64, [2 x i64] }, ptr %l64
  %t236 = load i64, ptr %l62
  %t237 = inttoptr i64 %t236 to ptr
  %t238 = call ptr @__olang_scope_alloc_a(ptr %t237, i64 24, i64 8)
  store { i64, [2 x i64] } %t235, ptr %t238
  call void @__olang_errpay_set(ptr %t238)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb26:
  %t241 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t241, ptr %l6, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t242, ptr %l67, !tbaa !27
  %t243 = call ptr @__olang_scope_hold(ptr %s0)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l68, !tbaa !24
  %t245 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t245, label %bb27, label %bb28
bb27:
  %t247 = call ptr @__olang_region_make(ptr %s0)
  %t248 = ptrtoint ptr %t247 to i64
  store i64 %t248, ptr %l68, !tbaa !24
  br label %bb28
bb28:
  %t249 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t250 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t253 = extractvalue { i64, ptr } %t249, 1
  %t254 = extractvalue { i64, ptr } %t249, 0
  %t255 = add i64 %t251, %t254
  %t256 = load i64, ptr %l68
  %t257 = inttoptr i64 %t256 to ptr
  %t258 = call ptr @__olang_held_alloc(ptr %t257, i64 %t255)
  call void @olang_textcopy(ptr %t258, ptr %t250, i64 %t251)
  %t259 = getelementptr i8, ptr %t258, i64 %t251
  call void @olang_textcopy(ptr %t259, ptr %t253, i64 %t254)
  %t260 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t258, 1
  %t263 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t264 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t263, 0
  %t266 = insertvalue [2 x { i64, ptr }] %t264, { i64, ptr } %t261, 1
  store [2 x { i64, ptr }] %t266, ptr %l7
  %t269 = insertvalue { i64, ptr } undef, i64 2, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %l7, 1
  %t272 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t270)
  store { i64, ptr } %t272, ptr %l76
  br label %bb29
bb29:
  %t273 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t273, ptr %l8, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t274, ptr %l78, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t275, ptr %l79, !tbaa !27
  %t276 = call ptr @__olang_scope_hold(ptr %s0)
  %t277 = ptrtoint ptr %t276 to i64
  store i64 %t277, ptr %l80, !tbaa !24
  %t278 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_205_3e_2e_2d1
  br i1 %t278, label %bb30, label %bb31
bb30:
  %t280 = call ptr @__olang_region_make(ptr %s0)
  %t281 = ptrtoint ptr %t280 to i64
  store i64 %t281, ptr %l80, !tbaa !24
  br label %bb31
bb31:
  store { i64, ptr } %a1, ptr %l82, !tbaa !27
  %t283 = call ptr @__olang_scope_hold(ptr %s0)
  %t284 = ptrtoint ptr %t283 to i64
  store i64 %t284, ptr %l83, !tbaa !24
  %t285 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t285, label %bb32, label %bb33
bb32:
  %t287 = call ptr @__olang_region_make(ptr %s0)
  %t288 = ptrtoint ptr %t287 to i64
  store i64 %t288, ptr %l83, !tbaa !24
  br label %bb33
bb33:
  %t289 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t289, 1
  %t292 = extractvalue { i64, ptr } %t289, 0
  %t293 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t296 = load i64, ptr %l83
  %t297 = inttoptr i64 %t296 to ptr
  %t298 = call ptr @__olang_held_alloc(ptr %t297, i64 %t295)
  call void @olang_textcopy(ptr %t298, ptr %t291, i64 %t292)
  %t299 = getelementptr i8, ptr %t298, i64 %t292
  call void @olang_textcopy(ptr %t299, ptr %t293, i64 %t294)
  %t300 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t298, 1
  %t303 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t304 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t303, 0
  %t306 = insertvalue [2 x { i64, ptr }] %t304, { i64, ptr } %t301, 1
  store [2 x { i64, ptr }] %t306, ptr %l9
  %t309 = insertvalue { i64, ptr } undef, i64 2, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %l9, 1
  %t311 = load i64, ptr %l80
  %t312 = inttoptr i64 %t311 to ptr
  %t314 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %t312, { i64, ptr } %t310)
  store { i64, ptr } %t314, ptr %l91
  br label %bb34
bb34:
  %t315 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t316 = load i64, ptr %l80
  %t317 = inttoptr i64 %t316 to ptr
  %t318 = extractvalue { i64, ptr } %t315, 0
  %t319 = extractvalue { i64, ptr } %t315, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_held_alloc(ptr %t317, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  %t324 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t325 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } %t324, 0
  %t326 = insertvalue [5 x { i64, ptr }] %t325, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t327 = insertvalue [5 x { i64, ptr }] %t326, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) }, 2
  %t328 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t329 = insertvalue [5 x { i64, ptr }] %t327, { i64, ptr } %t328, 3
  %t331 = insertvalue [5 x { i64, ptr }] %t329, { i64, ptr } %t323, 4
  store [5 x { i64, ptr }] %t331, ptr %l10
  %t334 = insertvalue { i64, ptr } undef, i64 5, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %l10, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l96, !tbaa !27
  %t336 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t340 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t335, { i64, ptr } %t338, i1 true, { i64, ptr } %t336)
  %t341 = extractvalue { i32, %"std/os:Output" } %t340, 1
  %t342 = extractvalue { i32, %"std/os:Output" } %t340, 0
  store i32 %t342, ptr %l99
  %t343 = icmp ne i32 %t342, 0
  br i1 %t343, label %bb36, label %ok.344, !prof !99
ok.344:
  store %"std/os:Output" %t341, ptr %l98
  br label %bb35
bb35:
  %t345 = load %"std/os:Output", ptr %l98
  store %"std/os:Output" %t345, ptr %l77
  br label %bb66
bb36:
  %t346 = load i32, ptr %l99, !tbaa !23
  %t347 = ashr i32 %t346, 16
  %t349 = icmp eq i32 %t347, 1
  store i1 %t349, ptr %l101, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l11
  %t350 = load i32, ptr %l99, !tbaa !23
  %t351 = lshr i32 %t350, 16
  %t352 = and i32 %t350, 65535
  %t353 = icmp eq i32 %t351, 1
  %t354 = select i1 %t353, i32 1, i32 0
  %t355 = icmp eq i32 %t350, 0
  %t356 = shl i32 %t354, 16
  %t357 = or i32 %t356, %t352
  %t358 = select i1 %t355, i32 0, i32 %t357
  %t359 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l11, i32 0, i32 0
  store i32 %t358, ptr %t359, !tbaa !23
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t360 = load { i32, { i64, [2 x i64] } }, ptr %l11
  store { i32, { i64, [2 x i64] } } %t360, ptr %l102
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l103
  %t361 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l102, i32 0, i32 0
  %t362 = load i32, ptr %t361, !tbaa !23
  store i32 %t362, ptr %l104, !tbaa !23
  %t363 = load i32, ptr %l104, !tbaa !23
  %t364 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l103, i32 0, i32 0
  store i32 %t363, ptr %t364, !tbaa !23
  %t365 = load i32, ptr %l104, !tbaa !23
  %t366 = ashr i32 %t365, 16
  %t368 = icmp eq i32 %t366, 1
  br i1 %t368, label %bb38, label %bb39
bb38:
  %t370 = call ptr @__olang_errpay_top_get()
  %t372 = load { i64, [2 x i64] }, ptr %t370
  %t373 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l103, i32 0, i32 1
  store { i64, [2 x i64] } %t372, ptr %t373
  br label %bb39
bb39:
  %t375 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l103)
  store { i32, { i64, [2 x i64] } } %t375, ptr %l109
  br label %bb40
bb40:
  %t376 = load { i32, { i64, [2 x i64] } }, ptr %l109
  store { i32, { i64, [2 x i64] } } %t376, ptr %l11
  %t377 = load { i32, { i64, [2 x i64] } }, ptr %l11
  store { i32, { i64, [2 x i64] } } %t377, ptr %l110
  %t378 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l110, i32 0, i32 0
  %t379 = load i32, ptr %t378, !tbaa !23
  %t380 = ashr i32 %t379, 16
  %t382 = icmp eq i32 %t380, 1
  br i1 %t382, label %bb41, label %bb42
bb41:
  call void @__olang_errpay_pop()
  br label %bb42
bb42:
  %t384 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t384, ptr %l113, !tbaa !27
  %t385 = load { i32, { i64, [2 x i64] } }, ptr %l11
  store { i32, { i64, [2 x i64] } } %t385, ptr %l114
  %t387 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s6, ptr %l114)
  store { i32, { i64, [2 x i64] } } %t387, ptr %l116
  br label %bb43
bb43:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t388 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t389 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t388, i64 %t389)
  %t390 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  call void @__olang_sb_put(ptr %s7, ptr %t391, i64 %t392)
  %t393 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t394 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t393, i64 %t394)
  %t395 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 0
  %t396 = load i32, ptr %t395, !tbaa !23
  store i32 %t396, ptr %l117, !tbaa !23
  %t397 = load i32, ptr %l117, !tbaa !23
  %t398 = icmp eq i32 %t397, 0
  br i1 %t398, label %bb45, label %bb46
bb44:
  %t400 = load ptr, ptr %s7
  %t401 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t402 = load i64, ptr %t401
  %t403 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t400, i64 %t402)
  %t404 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  store { i64, ptr } %t405, ptr %l132, !tbaa !27
  %t406 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t407 = load ptr, ptr %t406
  %t408 = icmp ne ptr %t407, null
  br i1 %t408, label %sbgrew.409, label %sbdone.410
sbgrew.409:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.410
sbdone.410:
  store { i64, [2 x i64] } zeroinitializer, ptr %t411
  %t412 = getelementptr { i64, [2 x i64] }, ptr %t411, i32 0, i32 0
  store i64 0, ptr %t412
  %t413 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t414 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t413, 0
  %t415 = getelementptr { i64, [2 x i64] }, ptr %t411, i32 0, i32 1
  store { { i64, ptr } } %t414, ptr %t415
  %t416 = load { i64, [2 x i64] }, ptr %t411
  store { i64, [2 x i64] } %t416, ptr %l133
  %t417 = call ptr @__olang_errpay_push()
  %t418 = ptrtoint ptr %t417 to i64
  store i64 %t418, ptr %l134, !tbaa !24
  %t419 = load i64, ptr %l134
  %t420 = inttoptr i64 %t419 to ptr
  %t422 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %t420, ptr %l133)
  store { i64, [2 x i64] } %t422, ptr %l136
  br label %bb59
bb45:
  %t423 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t424 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t423, i64 %t424)
  br label %bb44
bb46:
  %t425 = load i32, ptr %l117, !tbaa !23
  %t426 = icmp eq i32 %t425, 65536
  br i1 %t426, label %bb47, label %bb48
bb47:
  %t428 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t429 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t428, i64 %t429)
  %t430 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t431 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t430, i64 %t431)
  %t432 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t433 = getelementptr { i64, [2 x i64] }, ptr %t432, i32 0, i32 1
  %t434 = getelementptr { { i64, ptr } }, ptr %t433, i32 0, i32 0
  %t435 = load { i64, ptr }, ptr %t434
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = extractvalue { i64, ptr } %t435, 0
  %t439 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t437, i64 %t438, i8 34)
  %t440 = call ptr @__olang_sb_room(ptr %s7, i64 %t439)
  %t441 = call i64 @__olang_rd_quote(ptr %t440, i64 0, ptr %t437, i64 %t438, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t439)
  %t442 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t442, i64 %t443)
  br label %bb44
bb48:
  %t444 = load i32, ptr %l117, !tbaa !23
  %t445 = icmp eq i32 %t444, 65537
  br i1 %t445, label %bb49, label %bb50
bb49:
  %t447 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t447, i64 %t448)
  %t449 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t449, i64 %t450)
  %t451 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t452 = getelementptr { i64, [2 x i64] }, ptr %t451, i32 0, i32 1
  %t453 = getelementptr { { i64, ptr } }, ptr %t452, i32 0, i32 0
  %t454 = load { i64, ptr }, ptr %t453
  %t456 = extractvalue { i64, ptr } %t454, 1
  %t457 = extractvalue { i64, ptr } %t454, 0
  %t458 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t456, i64 %t457, i8 34)
  %t459 = call ptr @__olang_sb_room(ptr %s7, i64 %t458)
  %t460 = call i64 @__olang_rd_quote(ptr %t459, i64 0, ptr %t456, i64 %t457, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t458)
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t461, i64 %t462)
  br label %bb44
bb50:
  %t463 = load i32, ptr %l117, !tbaa !23
  %t464 = icmp eq i32 %t463, 65538
  br i1 %t464, label %bb51, label %bb52
bb51:
  %t466 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t466, i64 %t467)
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t468, i64 %t469)
  %t470 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t471 = getelementptr { i64, [2 x i64] }, ptr %t470, i32 0, i32 1
  %t472 = getelementptr { { i64, ptr } }, ptr %t471, i32 0, i32 0
  %t473 = load { i64, ptr }, ptr %t472
  %t475 = extractvalue { i64, ptr } %t473, 1
  %t476 = extractvalue { i64, ptr } %t473, 0
  %t477 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t475, i64 %t476, i8 34)
  %t478 = call ptr @__olang_sb_room(ptr %s7, i64 %t477)
  %t479 = call i64 @__olang_rd_quote(ptr %t478, i64 0, ptr %t475, i64 %t476, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t477)
  %t480 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t481 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t480, i64 %t481)
  br label %bb44
bb52:
  %t482 = load i32, ptr %l117, !tbaa !23
  %t483 = icmp eq i32 %t482, 65539
  br i1 %t483, label %bb53, label %bb54
bb53:
  %t485 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t486 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t485, i64 %t486)
  %t487 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t488 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t487, i64 %t488)
  %t489 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t490 = getelementptr { i64, [2 x i64] }, ptr %t489, i32 0, i32 1
  %t491 = getelementptr { { i64, ptr } }, ptr %t490, i32 0, i32 0
  %t492 = load { i64, ptr }, ptr %t491
  %t494 = extractvalue { i64, ptr } %t492, 1
  %t495 = extractvalue { i64, ptr } %t492, 0
  %t496 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t494, i64 %t495, i8 34)
  %t497 = call ptr @__olang_sb_room(ptr %s7, i64 %t496)
  %t498 = call i64 @__olang_rd_quote(ptr %t497, i64 0, ptr %t494, i64 %t495, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t496)
  %t499 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t500 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t499, i64 %t500)
  br label %bb44
bb54:
  %t501 = load i32, ptr %l117, !tbaa !23
  %t502 = icmp eq i32 %t501, 65540
  br i1 %t502, label %bb55, label %bb56
bb55:
  %t504 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t504, i64 %t505)
  %t506 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t507 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t506, i64 %t507)
  %t508 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t509 = getelementptr { i64, [2 x i64] }, ptr %t508, i32 0, i32 1
  %t510 = getelementptr { { i64, ptr } }, ptr %t509, i32 0, i32 0
  %t511 = load { i64, ptr }, ptr %t510
  %t513 = extractvalue { i64, ptr } %t511, 1
  %t514 = extractvalue { i64, ptr } %t511, 0
  %t515 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t513, i64 %t514, i8 34)
  %t516 = call ptr @__olang_sb_room(ptr %s7, i64 %t515)
  %t517 = call i64 @__olang_rd_quote(ptr %t516, i64 0, ptr %t513, i64 %t514, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t515)
  %t518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t519 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t518, i64 %t519)
  br label %bb44
bb56:
  %t520 = load i32, ptr %l117, !tbaa !23
  %t521 = icmp eq i32 %t520, 65541
  br i1 %t521, label %bb57, label %bb58
bb57:
  %t523 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t524 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t523, i64 %t524)
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t525, i64 %t526)
  %t527 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t528 = getelementptr { i64, [2 x i64] }, ptr %t527, i32 0, i32 1
  %t529 = getelementptr { { i64, ptr } }, ptr %t528, i32 0, i32 0
  %t530 = load { i64, ptr }, ptr %t529
  %t532 = extractvalue { i64, ptr } %t530, 1
  %t533 = extractvalue { i64, ptr } %t530, 0
  %t534 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t532, i64 %t533, i8 34)
  %t535 = call ptr @__olang_sb_room(ptr %s7, i64 %t534)
  %t536 = call i64 @__olang_rd_quote(ptr %t535, i64 0, ptr %t532, i64 %t533, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t534)
  %t537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t537, i64 %t538)
  br label %bb44
bb58:
  %t539 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t540 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t539, i64 %t540)
  %t541 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t542 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t541, i64 %t542)
  %t543 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l116, i32 0, i32 1
  %t544 = getelementptr { i64, [2 x i64] }, ptr %t543, i32 0, i32 1
  %t545 = getelementptr { { i64, ptr } }, ptr %t544, i32 0, i32 0
  %t546 = load { i64, ptr }, ptr %t545
  %t548 = extractvalue { i64, ptr } %t546, 1
  %t549 = extractvalue { i64, ptr } %t546, 0
  %t550 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t548, i64 %t549, i8 34)
  %t551 = call ptr @__olang_sb_room(ptr %s7, i64 %t550)
  %t552 = call i64 @__olang_rd_quote(ptr %t551, i64 0, ptr %t548, i64 %t549, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t550)
  %t553 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t554 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t553, i64 %t554)
  br label %bb44
bb59:
  %t555 = load { i64, [2 x i64] }, ptr %l136
  %t556 = load i64, ptr %l134
  %t557 = inttoptr i64 %t556 to ptr
  %t558 = call ptr @__olang_scope_alloc_a(ptr %t557, i64 24, i64 8)
  store { i64, [2 x i64] } %t555, ptr %t558
  call void @__olang_errpay_set(ptr %t558)
  store i32 65536, ptr %l138, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  %t560 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t562 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t560)
  store i32 %t562, ptr %l140
  %t563 = icmp ne i32 %t562, 0
  br i1 %t563, label %bb61, label %ok.564, !prof !99
ok.564:
  br label %bb60
bb60:
  br label %bb65
bb61:
  %t565 = load i32, ptr %l140, !tbaa !23
  %t566 = ashr i32 %t565, 16
  %t568 = icmp eq i32 %t566, 1
  store i1 %t568, ptr %l142, !tbaa !21
  %t569 = load i32, ptr %l140, !tbaa !23
  %t570 = ashr i32 %t569, 16
  %t572 = icmp eq i32 %t570, 1
  br i1 %t572, label %bb62, label %bb63
bb62:
  call void @__olang_errpay_pop()
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t574 = load i32, ptr %l138, !tbaa !23
  store i32 %t574, ptr %rv
  br label %ret
bb66:
  %t575 = load %"std/os:Output", ptr %l77
  store %"std/os:Output" %t575, ptr %l12
  %t576 = getelementptr %"std/os:Output", ptr %l12, i32 0, i32 0
  %t577 = load i32, ptr %t576, !tbaa !23
  %t579 = icmp ne i32 %t577, 0
  br i1 %t579, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t581 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t582 = getelementptr %"std/os:Output", ptr %l12, i32 0, i32 1
  %t583 = load { i64, ptr }, ptr %t582, !tbaa !27
  %t584 = getelementptr %"std/os:Output", ptr %l12, i32 0, i32 2
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  %t586 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t587 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t589 = extractvalue { i64, ptr } %t581, 1
  %t590 = extractvalue { i64, ptr } %t581, 0
  %t591 = add i64 %t587, %t590
  %t592 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t593 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t594 = add i64 %t591, %t593
  %t596 = extractvalue { i64, ptr } %t583, 1
  %t597 = extractvalue { i64, ptr } %t583, 0
  %t598 = add i64 %t594, %t597
  %t600 = extractvalue { i64, ptr } %t585, 1
  %t601 = extractvalue { i64, ptr } %t585, 0
  %t602 = add i64 %t598, %t601
  %t603 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t602)
  call void @olang_textcopy(ptr %t603, ptr %t586, i64 %t587)
  %t604 = getelementptr i8, ptr %t603, i64 %t587
  call void @olang_textcopy(ptr %t604, ptr %t589, i64 %t590)
  %t605 = getelementptr i8, ptr %t604, i64 %t590
  call void @olang_textcopy(ptr %t605, ptr %t592, i64 %t593)
  %t606 = getelementptr i8, ptr %t605, i64 %t593
  call void @olang_textcopy(ptr %t606, ptr %t596, i64 %t597)
  %t607 = getelementptr i8, ptr %t606, i64 %t597
  call void @olang_textcopy(ptr %t607, ptr %t600, i64 %t601)
  %t608 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t603, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t610
  %t611 = getelementptr { i64, [2 x i64] }, ptr %t610, i32 0, i32 0
  store i64 0, ptr %t611
  %t613 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t609, 0
  %t614 = getelementptr { i64, [2 x i64] }, ptr %t610, i32 0, i32 1
  store { { i64, ptr } } %t613, ptr %t614
  %t615 = load { i64, [2 x i64] }, ptr %t610
  store { i64, [2 x i64] } %t615, ptr %l151
  %t616 = call ptr @__olang_errpay_push()
  %t617 = ptrtoint ptr %t616 to i64
  store i64 %t617, ptr %l152, !tbaa !24
  %t618 = load i64, ptr %l152
  %t619 = inttoptr i64 %t618 to ptr
  %t621 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %t619, ptr %l151)
  store { i64, [2 x i64] } %t621, ptr %l154
  br label %bb69
bb68:
  br label %bb76
bb69:
  %t622 = load { i64, [2 x i64] }, ptr %l154
  %t623 = load i64, ptr %l152
  %t624 = inttoptr i64 %t623 to ptr
  %t625 = call ptr @__olang_scope_alloc_a(ptr %t624, i64 24, i64 8)
  store { i64, [2 x i64] } %t622, ptr %t625
  call void @__olang_errpay_set(ptr %t625)
  store i32 65536, ptr %l156, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  %t627 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t629 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t627)
  store i32 %t629, ptr %l158
  %t630 = icmp ne i32 %t629, 0
  br i1 %t630, label %bb71, label %ok.631, !prof !99
ok.631:
  br label %bb70
bb70:
  br label %bb75
bb71:
  %t632 = load i32, ptr %l158, !tbaa !23
  %t633 = ashr i32 %t632, 16
  %t635 = icmp eq i32 %t633, 1
  store i1 %t635, ptr %l160, !tbaa !21
  %t636 = load i32, ptr %l158, !tbaa !23
  %t637 = ashr i32 %t636, 16
  %t639 = icmp eq i32 %t637, 1
  br i1 %t639, label %bb72, label %bb73
bb72:
  call void @__olang_errpay_pop()
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t641 = load i32, ptr %l156, !tbaa !23
  store i32 %t641, ptr %rv
  br label %ret
bb76:
  %t642 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t643 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t646 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v4, { i64, ptr } %t642, { i64, ptr } %t643)
  store i32 %t646, ptr %l165
  %t647 = icmp ne i32 %t646, 0
  br i1 %t647, label %bb78, label %ok.648, !prof !99
ok.648:
  br label %bb77
bb77:
  br label %bb108
bb78:
  %t649 = load i32, ptr %l165, !tbaa !23
  %t650 = ashr i32 %t649, 16
  %t652 = icmp eq i32 %t650, 1
  store i1 %t652, ptr %l167, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l13
  %t653 = load i32, ptr %l165, !tbaa !23
  %t654 = lshr i32 %t653, 16
  %t655 = and i32 %t653, 65535
  %t656 = icmp eq i32 %t654, 1
  %t657 = select i1 %t656, i32 1, i32 0
  %t658 = icmp eq i32 %t653, 0
  %t659 = shl i32 %t657, 16
  %t660 = or i32 %t659, %t655
  %t661 = select i1 %t658, i32 0, i32 %t660
  %t662 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l13, i32 0, i32 0
  store i32 %t661, ptr %t662, !tbaa !23
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t663 = load { i32, { i64, [2 x i64] } }, ptr %l13
  store { i32, { i64, [2 x i64] } } %t663, ptr %l168
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l169
  %t664 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l168, i32 0, i32 0
  %t665 = load i32, ptr %t664, !tbaa !23
  store i32 %t665, ptr %l170, !tbaa !23
  %t666 = load i32, ptr %l170, !tbaa !23
  %t667 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l169, i32 0, i32 0
  store i32 %t666, ptr %t667, !tbaa !23
  %t668 = load i32, ptr %l170, !tbaa !23
  %t669 = ashr i32 %t668, 16
  %t671 = icmp eq i32 %t669, 1
  br i1 %t671, label %bb80, label %bb81
bb80:
  %t673 = call ptr @__olang_errpay_top_get()
  %t675 = load { i64, [2 x i64] }, ptr %t673
  %t676 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l169, i32 0, i32 1
  store { i64, [2 x i64] } %t675, ptr %t676
  br label %bb81
bb81:
  %t678 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l169)
  store { i32, { i64, [2 x i64] } } %t678, ptr %l175
  br label %bb82
bb82:
  %t679 = load { i32, { i64, [2 x i64] } }, ptr %l175
  store { i32, { i64, [2 x i64] } } %t679, ptr %l13
  %t680 = load { i32, { i64, [2 x i64] } }, ptr %l13
  store { i32, { i64, [2 x i64] } } %t680, ptr %l176
  %t681 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l176, i32 0, i32 0
  %t682 = load i32, ptr %t681, !tbaa !23
  %t683 = ashr i32 %t682, 16
  %t685 = icmp eq i32 %t683, 1
  br i1 %t685, label %bb83, label %bb84
bb83:
  call void @__olang_errpay_pop()
  br label %bb84
bb84:
  %t687 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t687, ptr %l179, !tbaa !27
  %t688 = load { i32, { i64, [2 x i64] } }, ptr %l13
  store { i32, { i64, [2 x i64] } } %t688, ptr %l180
  %t690 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s14, ptr %l180)
  store { i32, { i64, [2 x i64] } } %t690, ptr %l182
  br label %bb85
bb85:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t691 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t692 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t691, i64 %t692)
  %t693 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t694 = extractvalue { i64, ptr } %t693, 1
  %t695 = extractvalue { i64, ptr } %t693, 0
  call void @__olang_sb_put(ptr %s15, ptr %t694, i64 %t695)
  %t696 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t697 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t696, i64 %t697)
  %t698 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 0
  %t699 = load i32, ptr %t698, !tbaa !23
  store i32 %t699, ptr %l183, !tbaa !23
  %t700 = load i32, ptr %l183, !tbaa !23
  %t701 = icmp eq i32 %t700, 0
  br i1 %t701, label %bb87, label %bb88
bb86:
  %t703 = load ptr, ptr %s15
  %t704 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t705 = load i64, ptr %t704
  %t706 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t705)
  call void @olang_textcopy(ptr %t706, ptr %t703, i64 %t705)
  %t707 = insertvalue { i64, ptr } undef, i64 %t705, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t706, 1
  store { i64, ptr } %t708, ptr %l198, !tbaa !27
  %t709 = getelementptr %olang.builder, ptr %s15, i32 0, i32 3
  %t710 = load ptr, ptr %t709
  %t711 = icmp ne ptr %t710, null
  br i1 %t711, label %sbgrew.712, label %sbdone.713
sbgrew.712:
  call void @__olang_sb_done(ptr %s15)
  br label %sbdone.713
sbdone.713:
  store { i64, [2 x i64] } zeroinitializer, ptr %t714
  %t715 = getelementptr { i64, [2 x i64] }, ptr %t714, i32 0, i32 0
  store i64 0, ptr %t715
  %t716 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t717 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t716, 0
  %t718 = getelementptr { i64, [2 x i64] }, ptr %t714, i32 0, i32 1
  store { { i64, ptr } } %t717, ptr %t718
  %t719 = load { i64, [2 x i64] }, ptr %t714
  store { i64, [2 x i64] } %t719, ptr %l199
  %t720 = call ptr @__olang_errpay_push()
  %t721 = ptrtoint ptr %t720 to i64
  store i64 %t721, ptr %l200, !tbaa !24
  %t722 = load i64, ptr %l200
  %t723 = inttoptr i64 %t722 to ptr
  %t725 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %t723, ptr %l199)
  store { i64, [2 x i64] } %t725, ptr %l202
  br label %bb101
bb87:
  %t726 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t727 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t726, i64 %t727)
  br label %bb86
bb88:
  %t728 = load i32, ptr %l183, !tbaa !23
  %t729 = icmp eq i32 %t728, 65536
  br i1 %t729, label %bb89, label %bb90
bb89:
  %t731 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t732 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t731, i64 %t732)
  %t733 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t733, i64 %t734)
  %t735 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t736 = getelementptr { i64, [2 x i64] }, ptr %t735, i32 0, i32 1
  %t737 = getelementptr { { i64, ptr } }, ptr %t736, i32 0, i32 0
  %t738 = load { i64, ptr }, ptr %t737
  %t740 = extractvalue { i64, ptr } %t738, 1
  %t741 = extractvalue { i64, ptr } %t738, 0
  %t742 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t740, i64 %t741, i8 34)
  %t743 = call ptr @__olang_sb_room(ptr %s15, i64 %t742)
  %t744 = call i64 @__olang_rd_quote(ptr %t743, i64 0, ptr %t740, i64 %t741, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t742)
  %t745 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t745, i64 %t746)
  br label %bb86
bb90:
  %t747 = load i32, ptr %l183, !tbaa !23
  %t748 = icmp eq i32 %t747, 65537
  br i1 %t748, label %bb91, label %bb92
bb91:
  %t750 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t751 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t750, i64 %t751)
  %t752 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t753 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t752, i64 %t753)
  %t754 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t755 = getelementptr { i64, [2 x i64] }, ptr %t754, i32 0, i32 1
  %t756 = getelementptr { { i64, ptr } }, ptr %t755, i32 0, i32 0
  %t757 = load { i64, ptr }, ptr %t756
  %t759 = extractvalue { i64, ptr } %t757, 1
  %t760 = extractvalue { i64, ptr } %t757, 0
  %t761 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t759, i64 %t760, i8 34)
  %t762 = call ptr @__olang_sb_room(ptr %s15, i64 %t761)
  %t763 = call i64 @__olang_rd_quote(ptr %t762, i64 0, ptr %t759, i64 %t760, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t761)
  %t764 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t765 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t764, i64 %t765)
  br label %bb86
bb92:
  %t766 = load i32, ptr %l183, !tbaa !23
  %t767 = icmp eq i32 %t766, 65538
  br i1 %t767, label %bb93, label %bb94
bb93:
  %t769 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t769, i64 %t770)
  %t771 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t772 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t771, i64 %t772)
  %t773 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t774 = getelementptr { i64, [2 x i64] }, ptr %t773, i32 0, i32 1
  %t775 = getelementptr { { i64, ptr } }, ptr %t774, i32 0, i32 0
  %t776 = load { i64, ptr }, ptr %t775
  %t778 = extractvalue { i64, ptr } %t776, 1
  %t779 = extractvalue { i64, ptr } %t776, 0
  %t780 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t778, i64 %t779, i8 34)
  %t781 = call ptr @__olang_sb_room(ptr %s15, i64 %t780)
  %t782 = call i64 @__olang_rd_quote(ptr %t781, i64 0, ptr %t778, i64 %t779, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t780)
  %t783 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t784 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t783, i64 %t784)
  br label %bb86
bb94:
  %t785 = load i32, ptr %l183, !tbaa !23
  %t786 = icmp eq i32 %t785, 65539
  br i1 %t786, label %bb95, label %bb96
bb95:
  %t788 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t788, i64 %t789)
  %t790 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t791 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t790, i64 %t791)
  %t792 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t793 = getelementptr { i64, [2 x i64] }, ptr %t792, i32 0, i32 1
  %t794 = getelementptr { { i64, ptr } }, ptr %t793, i32 0, i32 0
  %t795 = load { i64, ptr }, ptr %t794
  %t797 = extractvalue { i64, ptr } %t795, 1
  %t798 = extractvalue { i64, ptr } %t795, 0
  %t799 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t797, i64 %t798, i8 34)
  %t800 = call ptr @__olang_sb_room(ptr %s15, i64 %t799)
  %t801 = call i64 @__olang_rd_quote(ptr %t800, i64 0, ptr %t797, i64 %t798, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t799)
  %t802 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t803 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t802, i64 %t803)
  br label %bb86
bb96:
  %t804 = load i32, ptr %l183, !tbaa !23
  %t805 = icmp eq i32 %t804, 65540
  br i1 %t805, label %bb97, label %bb98
bb97:
  %t807 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t808 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t807, i64 %t808)
  %t809 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t810 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t809, i64 %t810)
  %t811 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t812 = getelementptr { i64, [2 x i64] }, ptr %t811, i32 0, i32 1
  %t813 = getelementptr { { i64, ptr } }, ptr %t812, i32 0, i32 0
  %t814 = load { i64, ptr }, ptr %t813
  %t816 = extractvalue { i64, ptr } %t814, 1
  %t817 = extractvalue { i64, ptr } %t814, 0
  %t818 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t816, i64 %t817, i8 34)
  %t819 = call ptr @__olang_sb_room(ptr %s15, i64 %t818)
  %t820 = call i64 @__olang_rd_quote(ptr %t819, i64 0, ptr %t816, i64 %t817, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t818)
  %t821 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t822 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t821, i64 %t822)
  br label %bb86
bb98:
  %t823 = load i32, ptr %l183, !tbaa !23
  %t824 = icmp eq i32 %t823, 65541
  br i1 %t824, label %bb99, label %bb100
bb99:
  %t826 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t827 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t826, i64 %t827)
  %t828 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t829 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t828, i64 %t829)
  %t830 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t831 = getelementptr { i64, [2 x i64] }, ptr %t830, i32 0, i32 1
  %t832 = getelementptr { { i64, ptr } }, ptr %t831, i32 0, i32 0
  %t833 = load { i64, ptr }, ptr %t832
  %t835 = extractvalue { i64, ptr } %t833, 1
  %t836 = extractvalue { i64, ptr } %t833, 0
  %t837 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t835, i64 %t836, i8 34)
  %t838 = call ptr @__olang_sb_room(ptr %s15, i64 %t837)
  %t839 = call i64 @__olang_rd_quote(ptr %t838, i64 0, ptr %t835, i64 %t836, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t837)
  %t840 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t841 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t840, i64 %t841)
  br label %bb86
bb100:
  %t842 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t843 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t842, i64 %t843)
  %t844 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t845 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t844, i64 %t845)
  %t846 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l182, i32 0, i32 1
  %t847 = getelementptr { i64, [2 x i64] }, ptr %t846, i32 0, i32 1
  %t848 = getelementptr { { i64, ptr } }, ptr %t847, i32 0, i32 0
  %t849 = load { i64, ptr }, ptr %t848
  %t851 = extractvalue { i64, ptr } %t849, 1
  %t852 = extractvalue { i64, ptr } %t849, 0
  %t853 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t851, i64 %t852, i8 34)
  %t854 = call ptr @__olang_sb_room(ptr %s15, i64 %t853)
  %t855 = call i64 @__olang_rd_quote(ptr %t854, i64 0, ptr %t851, i64 %t852, i8 34)
  call void @__olang_sb_add(ptr %s15, i64 %t853)
  %t856 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t857 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t856, i64 %t857)
  br label %bb86
bb101:
  %t858 = load { i64, [2 x i64] }, ptr %l202
  %t859 = load i64, ptr %l200
  %t860 = inttoptr i64 %t859 to ptr
  %t861 = call ptr @__olang_scope_alloc_a(ptr %t860, i64 24, i64 8)
  store { i64, [2 x i64] } %t858, ptr %t861
  call void @__olang_errpay_set(ptr %t861)
  store i32 65536, ptr %l204, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  %t863 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t865 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t863)
  store i32 %t865, ptr %l206
  %t866 = icmp ne i32 %t865, 0
  br i1 %t866, label %bb103, label %ok.867, !prof !99
ok.867:
  br label %bb102
bb102:
  br label %bb107
bb103:
  %t868 = load i32, ptr %l206, !tbaa !23
  %t869 = ashr i32 %t868, 16
  %t871 = icmp eq i32 %t869, 1
  store i1 %t871, ptr %l208, !tbaa !21
  %t872 = load i32, ptr %l206, !tbaa !23
  %t873 = ashr i32 %t872, 16
  %t875 = icmp eq i32 %t873, 1
  br i1 %t875, label %bb104, label %bb105
bb104:
  call void @__olang_errpay_pop()
  br label %bb105
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  %t877 = load i32, ptr %l204, !tbaa !23
  store i32 %t877, ptr %rv
  br label %ret
bb108:
  %t878 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t880 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v2, ptr %s0, { i64, ptr } %t878)
  %t881 = extractvalue { i32, { i64, ptr } } %t880, 1
  %t882 = extractvalue { i32, { i64, ptr } } %t880, 0
  store i32 %t882, ptr %l214
  %t883 = icmp ne i32 %t882, 0
  br i1 %t883, label %bb110, label %ok.884, !prof !99
ok.884:
  store { i64, ptr } %t881, ptr %l213
  br label %bb109
bb109:
  %t885 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t885, ptr %l211, !tbaa !27
  br label %bb118
bb110:
  %t886 = load i32, ptr %l214, !tbaa !23
  %t887 = ashr i32 %t886, 16
  %t889 = icmp eq i32 %t887, 1
  br i1 %t889, label %bb111, label %bb112
bb111:
  call void @__olang_errpay_pop()
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t891 = icmp sge i64 0, 0
  br i1 %t891, label %bb114, label %bb115
bb114:
  %t893 = icmp sle i64 0, 576460752303423487
  br i1 %t893, label %bb116, label %bb117
bb115:
  call void @__olang_check_failed(ptr @olang_loc_233d982910cd3e61_6bc76ac40e1a9c3d)
  unreachable
bb116:
  %t895 = mul i64 0, 16
  %t896 = insertvalue { i64, ptr } undef, i64 0, 0
  %t897 = insertvalue { i64, ptr } %t896, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t897, ptr %l211, !tbaa !27
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_233d982910cd3e61_6bc76ac40e1a9c3d)
  unreachable
bb118:
  %t899 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t899, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t902 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t902, 0
  store i64 %t904, ptr %l17, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s19
  %t906 = load i64, ptr %l16, !tbaa !24
  %t907 = load i64, ptr %l17, !tbaa !24
  %t910 = icmp slt i64 %t906, %t907
  %t912 = xor i1 %t910, true
  br i1 %t912, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s19)
  br label %bb139
bb121:
  br label %bb122
bb122:
  %t914 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t914, ptr %l227, !tbaa !27
  %t915 = load i64, ptr %l16, !tbaa !24
  %t917 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t918 = load ptr, ptr %t917, !tbaa !27
  %t919 = getelementptr { i64, ptr }, ptr %t918, i64 %t915
  %t920 = load { i64, ptr }, ptr %t919, !tbaa !37
  store { i64, ptr } %t920, ptr %l18, !tbaa !27
  %t922 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t923 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t925 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t922, 0
  %t927 = insertvalue [2 x { i64, ptr }] %t925, { i64, ptr } %t923, 1
  store [2 x { i64, ptr }] %t927, ptr %l19
  %t930 = insertvalue { i64, ptr } undef, i64 2, 0
  %t931 = insertvalue { i64, ptr } %t930, ptr %l19, 1
  %t933 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s19, ptr %s19, { i64, ptr } %t931)
  store { i64, ptr } %t933, ptr %l235
  br label %bb123
bb123:
  %t934 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t934, ptr %l20, !tbaa !27
  %t935 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t936 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t937 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t938 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t940 = extractvalue { i64, ptr } %t936, 1
  %t941 = extractvalue { i64, ptr } %t936, 0
  %t942 = add i64 %t938, %t941
  %t943 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t944 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t945 = add i64 %t942, %t944
  %t946 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t945)
  call void @olang_textcopy(ptr %t946, ptr %t937, i64 %t938)
  %t947 = getelementptr i8, ptr %t946, i64 %t938
  call void @olang_textcopy(ptr %t947, ptr %t940, i64 %t941)
  %t948 = getelementptr i8, ptr %t947, i64 %t941
  call void @olang_textcopy(ptr %t948, ptr %t943, i64 %t944)
  %t949 = insertvalue { i64, ptr } undef, i64 %t945, 0
  %t950 = insertvalue { i64, ptr } %t949, ptr %t946, 1
  %t954 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s19, { i64, ptr } %t935, { i64, ptr } %t950)
  store i1 %t954, ptr %l240
  br label %bb124
bb124:
  %t955 = load i1, ptr %l240, !tbaa !21
  br i1 %t955, label %bb125, label %bb126
bb125:
  %t956 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t957 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t960 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %v4, { i64, ptr } %t956, { i64, ptr } %t957)
  store i1 %t960, ptr %l244
  br label %bb127
bb126:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb128
bb127:
  %t961 = load i1, ptr %l244, !tbaa !21
  %t962 = xor i1 %t961, true
  store i1 %t962, ptr %l241, !tbaa !21
  br label %bb128
bb128:
  %t964 = load i1, ptr %l241, !tbaa !21
  br i1 %t964, label %bb129, label %bb130
bb129:
  %t965 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t967 = call i32 @std_2fos_2eRemoveAll(ptr %s19, { i64, ptr } %t965)
  store i32 %t967, ptr %l247
  %t968 = icmp ne i32 %t967, 0
  br i1 %t968, label %bb132, label %ok.969, !prof !99
ok.969:
  br label %bb131
bb130:
  br label %bb137
bb131:
  br label %bb136
bb132:
  %t970 = load i32, ptr %l247, !tbaa !23
  %t971 = ashr i32 %t970, 16
  %t973 = icmp eq i32 %t971, 1
  store i1 %t973, ptr %l249, !tbaa !21
  %t974 = load i32, ptr %l247, !tbaa !23
  %t975 = ashr i32 %t974, 16
  %t977 = icmp eq i32 %t975, 1
  br i1 %t977, label %bb133, label %bb134
bb133:
  call void @__olang_errpay_pop()
  br label %bb134
bb134:
  br label %bb135
bb135:
  br label %bb136
bb136:
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s19)
  br label %bb138
bb138:
  %t979 = load i64, ptr %l16, !tbaa !24
  %t982 = add i64 %t979, 1
  store i64 %t982, ptr %l16, !tbaa !24
  br label %bb119
bb139:
  %t984 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t986 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t984)
  store i32 %t986, ptr %l256
  %t987 = icmp ne i32 %t986, 0
  br i1 %t987, label %bb141, label %ok.988, !prof !99
ok.988:
  br label %bb140
bb140:
  br label %bb145
bb141:
  %t989 = load i32, ptr %l256, !tbaa !23
  %t990 = ashr i32 %t989, 16
  %t992 = icmp eq i32 %t990, 1
  store i1 %t992, ptr %l258, !tbaa !21
  %t993 = load i32, ptr %l256, !tbaa !23
  %t994 = ashr i32 %t993, 16
  %t996 = icmp eq i32 %t994, 1
  br i1 %t996, label %bb142, label %bb143
bb142:
  call void @__olang_errpay_pop()
  br label %bb143
bb143:
  br label %bb144
bb144:
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/os:FileInfo"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l1, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s0, { i64, ptr } %t24)
  %t27 = extractvalue { i32, %"std/os:FileInfo" } %t26, 1
  %t28 = extractvalue { i32, %"std/os:FileInfo" } %t26, 0
  store i32 %t28, ptr %l15
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb8, label %ok.30, !prof !99
ok.30:
  store %"std/os:FileInfo" %t27, ptr %l14
  br label %bb7
bb7:
  %t31 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t31, ptr %l12
  br label %bb12
bb8:
  %t32 = load i32, ptr %l15, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l17, !tbaa !21
  %t36 = load i32, ptr %l15, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb12:
  %t49 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t49, ptr %l2
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = getelementptr %"std/os:FileInfo", ptr %l2, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = getelementptr %"std/os:FileInfo", ptr %l2, i32 0, i32 2
  %t54 = load i64, ptr %t53, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t50, 1
  %t57 = extractvalue { i64, ptr } %t50, 0
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t52)
  %t63 = add i64 %t60, %t62
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t54)
  %t69 = add i64 %t66, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t56, i64 %t57)
  %t71 = getelementptr i8, ptr %t70, i64 %t57
  call void @olang_textcopy(ptr %t71, ptr %t58, i64 %t59)
  %t72 = getelementptr i8, ptr %t71, i64 %t59
  %t73 = call i64 @__olang_fmt_i64(ptr %t72, i64 %t52)
  %t74 = getelementptr i8, ptr %t72, i64 %t62
  call void @olang_textcopy(ptr %t74, ptr %t64, i64 %t65)
  %t75 = getelementptr i8, ptr %t74, i64 %t65
  %t76 = call i64 @__olang_fmt_i64(ptr %t75, i64 %t54)
  %t77 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t70, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t78, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffix_2ebyHand(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l6
  store %"std/prelude/text:LineIter" %t4, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l10
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l9
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = add i64 %t21, 1
  store i64 %t24, ptr %l1, !tbaa !24
  br label %bb21
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t26, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb20
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t30 = load i1, ptr %l2, !tbaa !21
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t32, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t34, ptr %l23
  br label %bb15
bb14:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb16
bb15:
  %t35 = load i1, ptr %l23, !tbaa !21
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = add i64 %t37, 1
  store i64 %t40, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb2
bb23:
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffix_2eclosure(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %l15 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l30 = alloca %"std/prelude/text:LineIter"
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l36 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l62 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hb38d151ad2865ce380f5e3d42761bdf3(ptr %v1, ptr %t3, { i64, ptr } %t1)
  store i1 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v1, ptr %t10, { i64, ptr } %t17, i1 true)
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v2, { i64, ptr } %t20)
  %t23 = extractvalue { i32, { i64, ptr } } %t22, 1
  %t24 = extractvalue { i32, { i64, ptr } } %t22, 0
  store i32 %t24, ptr %l22
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb7, label %ok.26, !prof !99
ok.26:
  store { i64, ptr } %t23, ptr %l21
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t27, ptr %l19, !tbaa !27
  br label %bb11
bb7:
  %t28 = load i32, ptr %l22, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v0, ptr %t34, { i64, ptr } %t35)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t38, { i64, ptr } %t39)
  br label %bb13
bb13:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v2, ptr %v2, { i64, ptr } %t42)
  store %"std/prelude/text:LineIter" %t44, ptr %l30
  br label %bb14
bb14:
  %t45 = load %"std/prelude/text:LineIter", ptr %l30
  store %"std/prelude/text:LineIter" %t45, ptr %l5
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v2, ptr %v2, ptr %l5)
  %t48 = extractvalue { i32, { i64, ptr } } %t47, 1
  %t49 = extractvalue { i32, { i64, ptr } } %t47, 0
  store i32 %t49, ptr %l34
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb17, label %ok.51, !prof !99
ok.51:
  store { i64, ptr } %t48, ptr %l33
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  br label %bb19
bb17:
  %t53 = load i32, ptr %l34, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  store i1 %t56, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb19:
  %t57 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v2, ptr %v2, { i64, ptr } %t57)
  store { i64, ptr } %t60, ptr %l38
  br label %bb20
bb20:
  %t61 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t61, ptr %l7, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s4, { i64, ptr } %t62, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t64, ptr %l40
  br label %bb21
bb21:
  %t65 = load i1, ptr %l40, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb25
bb23:
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s4, { i64, ptr } %t68, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t70, ptr %l44
  br label %bb24
bb24:
  %t71 = load i1, ptr %l44, !tbaa !21
  %t72 = xor i1 %t71, true
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb27:
  br label %bb28
bb28:
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v2, ptr %s4, { i64, ptr } %t75, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l49
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb30, label %ok.81, !prof !99
ok.81:
  store i64 %t78, ptr %l48
  br label %bb29
bb29:
  %t82 = load i64, ptr %l48, !tbaa !24
  store i64 %t82, ptr %l46, !tbaa !24
  br label %bb32
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb32:
  %t83 = load i64, ptr %l46, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t87 = add i64 %t83, 1
  store i64 %t87, ptr %l52, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = sub i64 %t90, 1
  store i64 %t92, ptr %l55, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l56, !tbaa !24
  %t95 = load i64, ptr %l52, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb33, label %bb34
bb33:
  %t98 = load i64, ptr %l52, !tbaa !24
  %t99 = load i64, ptr %l55, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d81bb51d20d074b4_82b493c82ed1c1e0)
  unreachable
bb35:
  %t102 = load i64, ptr %l55, !tbaa !24
  %t103 = load i64, ptr %l56, !tbaa !24
  %t104 = icmp sle i64 %t102, %t103
  br i1 %t104, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d81bb51d20d074b4_82b493c82ed1c1e0)
  unreachable
bb37:
  %t106 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l52, !tbaa !24
  %t109 = load i64, ptr %l55, !tbaa !24
  %t110 = getelementptr i8, ptr %t107, i64 %t108
  %t111 = sub i64 %t109, %t108
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  store { i64, ptr } %t113, ptr %l9, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s4, { i64, ptr } %t115, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t117, ptr %l62
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d81bb51d20d074b4_82b493c82ed1c1e0)
  unreachable
bb39:
  %t118 = load i1, ptr %l62, !tbaa !21
  br i1 %t118, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb43
bb41:
  %t119 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s4, { i64, ptr } %t119, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t121, ptr %l65
  br label %bb42
bb42:
  %t122 = load i1, ptr %l65, !tbaa !21
  store i1 %t122, ptr %l63, !tbaa !21
  br label %bb43
bb43:
  %t123 = load i1, ptr %l63, !tbaa !21
  br i1 %t123, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb47
bb45:
  %t124 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s4, { i64, ptr } %t124, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t126, ptr %l68
  br label %bb46
bb46:
  %t127 = load i1, ptr %l68, !tbaa !21
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb47
bb47:
  %t128 = load i1, ptr %l66, !tbaa !21
  br i1 %t128, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb49:
  br label %bb50
bb50:
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t131 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %s4, { i64, ptr } %t129)
  store { i64, ptr } %t131, ptr %l70
  br label %bb51
bb51:
  %t132 = call ptr @__olang_scope_hold(ptr %s4)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l71, !tbaa !24
  %t134 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t134, label %bb52, label %bb53
bb52:
  %t136 = call ptr @__olang_region_make(ptr %s4)
  %t137 = ptrtoint ptr %t136 to i64
  store i64 %t137, ptr %l71, !tbaa !24
  br label %bb53
bb53:
  %t138 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 1
  %t141 = extractvalue { i64, ptr } %t138, 0
  %t142 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t145 = load i64, ptr %l71
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = call ptr @__olang_held_alloc(ptr %t146, i64 %t144)
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = getelementptr i8, ptr %t147, i64 %t141
  call void @olang_textcopy(ptr %t148, ptr %t142, i64 %t143)
  %t149 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  %t152 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t153 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t152, 0
  %t155 = insertvalue [2 x { i64, ptr }] %t153, { i64, ptr } %t150, 1
  store [2 x { i64, ptr }] %t155, ptr %l10
  %t158 = insertvalue { i64, ptr } undef, i64 2, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %l10, 1
  %t161 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s4, ptr %v2, { i64, ptr } %t159)
  store { i64, ptr } %t161, ptr %l79
  br label %bb54
bb54:
  %t162 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t170 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffix_2eclosure(ptr %v2, ptr %v1, ptr %v2, { i64, ptr } %t168, ptr %t169, ptr %t170)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb56:
  br label %bb15
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffix_2ecompiles(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca [2 x { i64, ptr }]
  %l5 = alloca [6 x { i64, ptr }]
  %l6 = alloca %"std/os:Output"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l24 = alloca %"std/os:Output"
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l32 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"std/os:Output"
  %l41 = alloca i32
  %l43 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i32
  %l50 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i32
  %l58 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d81, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l9
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l9, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l11, !tbaa !21
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t18)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l18
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb8, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l17
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t25, ptr %l15, !tbaa !27
  br label %bb12
bb8:
  %t26 = load i32, ptr %l18, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = extractvalue { i64, ptr } %t31, 0
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t33, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l15, !tbaa !27
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store { i64, ptr } %a0, ptr %l25, !tbaa !27
  %t42 = call ptr @__olang_scope_hold(ptr %s0)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l26, !tbaa !24
  %t44 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_206_3e_2e_2d1
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t46 = call ptr @__olang_region_make(ptr %s0)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t48, 0
  %t51 = insertvalue [2 x { i64, ptr }] %t50, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t51, ptr %l4
  %t54 = insertvalue { i64, ptr } undef, i64 2, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %l4, 1
  %t56 = load i64, ptr %l26
  %t57 = inttoptr i64 %t56 to ptr
  %t59 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %t57, { i64, ptr } %t55)
  store { i64, ptr } %t59, ptr %l32
  br label %bb15
bb15:
  %t60 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t61 = load i64, ptr %l26
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = extractvalue { i64, ptr } %t60, 0
  %t64 = extractvalue { i64, ptr } %t60, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_held_alloc(ptr %t62, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t71 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } %t70, 0
  %t72 = insertvalue [6 x { i64, ptr }] %t71, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t73 = insertvalue [6 x { i64, ptr }] %t72, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d84, i32 0, i32 1) }, 2
  %t74 = insertvalue [6 x { i64, ptr }] %t73, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d85, i32 0, i32 1) }, 3
  %t76 = insertvalue [6 x { i64, ptr }] %t74, { i64, ptr } %t68, 4
  %t78 = insertvalue [6 x { i64, ptr }] %t76, { i64, ptr } %t69, 5
  store [6 x { i64, ptr }] %t78, ptr %l5
  %t81 = insertvalue { i64, ptr } undef, i64 6, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %l5, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t87 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t82, { i64, ptr } %t85, i1 true, { i64, ptr } %t83)
  %t88 = extractvalue { i32, %"std/os:Output" } %t87, 1
  %t89 = extractvalue { i32, %"std/os:Output" } %t87, 0
  store i32 %t89, ptr %l41
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb17, label %ok.91, !prof !99
ok.91:
  store %"std/os:Output" %t88, ptr %l40
  br label %bb16
bb16:
  %t92 = load %"std/os:Output", ptr %l40
  store %"std/os:Output" %t92, ptr %l24
  br label %bb27
bb17:
  %t93 = load i32, ptr %l41, !tbaa !23
  %t94 = ashr i32 %t93, 16
  %t96 = icmp eq i32 %t94, 1
  store i1 %t96, ptr %l43, !tbaa !21
  %t97 = load i32, ptr %l41, !tbaa !23
  %t98 = ashr i32 %t97, 16
  %t100 = icmp eq i32 %t98, 1
  br i1 %t100, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  store i1 false, ptr %l46, !tbaa !21
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t104 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t102)
  store i32 %t104, ptr %l48
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb22, label %ok.106, !prof !99
ok.106:
  br label %bb21
bb21:
  br label %bb26
bb22:
  %t107 = load i32, ptr %l48, !tbaa !23
  %t108 = ashr i32 %t107, 16
  %t110 = icmp eq i32 %t108, 1
  store i1 %t110, ptr %l50, !tbaa !21
  %t111 = load i32, ptr %l48, !tbaa !23
  %t112 = ashr i32 %t111, 16
  %t114 = icmp eq i32 %t112, 1
  br i1 %t114, label %bb23, label %bb24
bb23:
  call void @__olang_errpay_pop()
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t116 = load i1, ptr %l46, !tbaa !21
  store i1 %t116, ptr %rv
  br label %ret
bb27:
  %t117 = load %"std/os:Output", ptr %l24
  store %"std/os:Output" %t117, ptr %l6
  %t118 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t119 = load i32, ptr %t118, !tbaa !23
  %t121 = icmp eq i32 %t119, 0
  store i1 %t121, ptr %l54, !tbaa !21
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t122)
  store i32 %t124, ptr %l56
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb29, label %ok.126, !prof !99
ok.126:
  br label %bb28
bb28:
  br label %bb33
bb29:
  %t127 = load i32, ptr %l56, !tbaa !23
  %t128 = ashr i32 %t127, 16
  %t130 = icmp eq i32 %t128, 1
  store i1 %t130, ptr %l58, !tbaa !21
  %t131 = load i32, ptr %l56, !tbaa !23
  %t132 = ashr i32 %t131, 16
  %t134 = icmp eq i32 %t132, 1
  br i1 %t134, label %bb30, label %bb31
bb30:
  call void @__olang_errpay_pop()
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t136 = load i1, ptr %l54, !tbaa !21
  store i1 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2eexpand(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t27)
  store i1 %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %lp1
  call void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb9
bb8:
  %t35 = load ptr, ptr %lp1
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %t35, { i64, ptr } %t36)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  %t44 = load ptr, ptr %lp1
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2efailing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %lp13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l30 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %jh1 = alloca ptr
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l21, !tbaa !24
  %t4 = load i64, ptr %l21, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l21, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  %t13 = icmp sge i64 1, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_40dc5ad5899010ef_fc275eeb26e8323)
  unreachable
bb3:
  %t15 = icmp sle i64 1, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_20258a28ab60401a_640e38b19bcc26ae)
  unreachable
bb5:
  %t17 = mul i64 1, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 1, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  store ptr null, ptr %jh1
  store i64 0, ptr %l7, !tbaa !24
  %t22 = load i64, ptr @G_2ecompiler_2ffix_2eCheckWidth, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t22, i64 %t25)
  store i64 %t28, ptr %l30
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_20258a28ab60401a_640e38b19bcc26ae)
  unreachable
bb7:
  %t29 = load i64, ptr %l30, !tbaa !24
  store i64 %t29, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l9, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l9, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l11, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l11, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l12, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t90 = call ptr @__olang_standin_in(ptr %v0, ptr %s1)
  %t91 = call ptr @__olang_standin_in(ptr %v1, ptr %s1)
  %t92 = call ptr @__olang_standin_in(ptr %s0, ptr %s1)
  %t93 = call ptr @__olang_standin_in(ptr %s0, ptr %s1)
  %t94 = call ptr @__olang_standin_in(ptr %v2, ptr %s1)
  %t95 = call ptr @__olang_standin_in(ptr %v3, ptr %s1)
  %t96 = call ptr @__olang_standin_in(ptr %v4, ptr %s1)
  %t97 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t98 = ptrtoint ptr %t97 to i64
  %t99 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 %t98, i64 8)
  %t100 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %a0, ptr %t100
  %t101 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 1
  store { i64, ptr } %t77, ptr %t101
  %t102 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 2
  store { i64, ptr } %t78, ptr %t102
  %t103 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 3
  store { i64, ptr } %t79, ptr %t103
  %t104 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 4
  store { i64, ptr } %a2, ptr %t104
  %t105 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 5
  store { i64, ptr } %a3, ptr %t105
  %t106 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 6
  store { i64, ptr } %a4, ptr %t106
  %t107 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 7
  store ptr %t90, ptr %t107
  %t108 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 8
  store ptr %t91, ptr %t108
  %t109 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 9
  store ptr %t92, ptr %t109
  %t110 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 10
  store ptr %t93, ptr %t110
  %t111 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 11
  store ptr %t94, ptr %t111
  %t112 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 12
  store ptr %t95, ptr %t112
  %t113 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t99, i32 0, i32 13
  store ptr %t96, ptr %t113
  %t114 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 40, i64 8)
  %t115 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr null, ptr %t115
  %t116 = getelementptr { ptr, ptr }, ptr %t115, i32 0, i32 1
  store ptr %t90, ptr %t116
  %t117 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t115, ptr %t117
  %t118 = getelementptr { ptr, ptr }, ptr %t117, i32 0, i32 1
  store ptr %t91, ptr %t118
  %t119 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t117, ptr %t119
  %t120 = getelementptr { ptr, ptr }, ptr %t119, i32 0, i32 1
  store ptr %t92, ptr %t120
  %t121 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t119, ptr %t121
  %t122 = getelementptr { ptr, ptr }, ptr %t121, i32 0, i32 1
  store ptr %t93, ptr %t122
  %t123 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t121, ptr %t123
  %t124 = getelementptr { ptr, ptr }, ptr %t123, i32 0, i32 1
  store ptr %t94, ptr %t124
  %t125 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t123, ptr %t125
  %t126 = getelementptr { ptr, ptr }, ptr %t125, i32 0, i32 1
  store ptr %t95, ptr %t126
  %t127 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store ptr %t125, ptr %t127
  %t128 = getelementptr { ptr, ptr }, ptr %t127, i32 0, i32 1
  store ptr %t96, ptr %t128
  %t129 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t114, i32 0, i32 2
  store ptr %t127, ptr %t129
  %t130 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t114, i32 0, i32 1
  store i64 0, ptr %t130
  %t131 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t114, i32 0, i32 3
  store i64 0, ptr %t131
  %t132 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t114, i32 0, i32 4
  store ptr null, ptr %t132
  %t133 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t133, ptr @olang_task86, ptr %t99, ptr %t114)
  %t134 = load ptr, ptr %jh1
  store ptr %t134, ptr %t114
  store ptr %t114, ptr %jh1
  br label %bb18
bb18:
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l11, !tbaa !24
  br label %bb14
bb19:
  %t140 = call i64 @__olang_join_tasks_keep(ptr %jh1, i1 false)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  %t141 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t141, ptr %l65
  br label %bb22
bb22:
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store ptr %t142, ptr %lp13
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  %t144 = load ptr, ptr %lp13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %t144
  store i64 0, ptr %l14, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t149 = load i64, ptr %l15, !tbaa !24
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = icmp sgt i64 %t149, %t150
  br i1 %t153, label %bb23, label %bb24
bb23:
  %t155 = load i64, ptr %l16, !tbaa !24
  %t157 = icmp sgt i64 %t155, 0
  br i1 %t157, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb28
bb25:
  %t159 = load i64, ptr %l15, !tbaa !24
  %t160 = load i64, ptr %l14, !tbaa !24
  %t163 = sub i64 %t159, %t160
  %t164 = load i64, ptr %l16, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t169 = sub i64 %t167, 1
  %t170 = load i64, ptr %l16, !tbaa !24
  %t173 = sdiv i64 %t169, %t170
  store i64 %t173, ptr %l74, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb27
bb27:
  %t175 = load i64, ptr %l74, !tbaa !24
  store i64 %t175, ptr %l71, !tbaa !24
  br label %bb28
bb28:
  %t176 = load i64, ptr %l71, !tbaa !24
  store i64 %t176, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb29
bb29:
  %t177 = load i64, ptr %l18, !tbaa !24
  %t178 = load i64, ptr %l17, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb30, label %bb31
bb30:
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t185 = load i64, ptr %l14, !tbaa !24
  %t186 = load i64, ptr %l18, !tbaa !24
  %t187 = load i64, ptr %l16, !tbaa !24
  %t190 = mul i64 %t186, %t187
  %t193 = add i64 %t185, %t190
  store i64 %t193, ptr %l19, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t195, ptr %l92, !tbaa !27
  %t196 = load i64, ptr %l19, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i1, ptr %t199, i64 %t196
  %t201 = load i1, ptr %t200, !tbaa !31
  br i1 %t201, label %bb33, label %bb34
bb33:
  %t203 = load ptr, ptr %lp13
  %t204 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t204, ptr %l96, !tbaa !27
  %t205 = load i64, ptr %l19, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v5, ptr %v1, ptr %t203, { i64, ptr } %t210)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t213 = load i64, ptr %l18, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l18, !tbaa !24
  br label %bb29
bb38:
  %t218 = load ptr, ptr %lp13
  %t220 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v5, ptr %v5, ptr %t218)
  store { i64, ptr } %t220, ptr %l103
  br label %bb39
bb39:
  %t221 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t221, ptr %l104, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  store i64 %t223, ptr %l105, !tbaa !24
  %t224 = load i64, ptr %l105, !tbaa !24
  %t225 = mul i64 %t224, 16
  %t226 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t225)
  %t227 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  store { i64, ptr } %t228, ptr %l106, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = load i64, ptr %l105, !tbaa !24
  %t234 = mul i64 %t233, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t230, ptr %t232, i64 %t234, i1 false)
  %t235 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t235, ptr %l104, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t236 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t236, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffix_2emigrationTool(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 6
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = icmp sle i64 0, %t11
  br i1 %t12, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_565177cd6d363dc5_57077917db9ab2b9)
  unreachable
bb3:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sle i64 %t14, %t15
  br i1 %t16, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_565177cd6d363dc5_57077917db9ab2b9)
  unreachable
bb5:
  %t18 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = getelementptr i8, ptr %t19, i64 0
  %t22 = sub i64 %t20, 0
  %t23 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  %t27 = insertvalue { i64, ptr } undef, i64 46, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr @G_2ecompiler_2ffix_2eToolNames, 1
  %t30 = load ptr, ptr @__olang_prog_scope
  %t33 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t30, ptr %v0, { i64, ptr } %t28, { i64, ptr } %t24)
  store i1 %t33, ptr %l16
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_565177cd6d363dc5_57077917db9ab2b9)
  unreachable
bb7:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t36, ptr %l18, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = sub i64 %t39, 6
  store i64 %t41, ptr %l21, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l22, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 0, %t46
  br i1 %t47, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_aba33d98e166d1e8_68a02edac36c0e8c)
  unreachable
bb13:
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_aba33d98e166d1e8_68a02edac36c0e8c)
  unreachable
bb15:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l21, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 0
  %t57 = sub i64 %t55, 0
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  %t60 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t63 = extractvalue { i64, ptr } %t59, 1
  %t64 = extractvalue { i64, ptr } %t59, 0
  %t65 = add i64 %t61, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t60, i64 %t61)
  %t67 = getelementptr i8, ptr %t66, i64 %t61
  call void @olang_textcopy(ptr %t67, ptr %t63, i64 %t64)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t66, 1
  store { i64, ptr } %t69, ptr %l3, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t74 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = getelementptr i8, ptr %t84, i64 %t78
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  %t90 = extractvalue { i64, ptr } %t87, 0
  %t91 = extractvalue { i64, ptr } %t87, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t98 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t71, { i64, ptr } %t95)
  store i1 %t98, ptr %l34
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_aba33d98e166d1e8_68a02edac36c0e8c)
  unreachable
bb17:
  %t99 = load i1, ptr %l34, !tbaa !21
  br i1 %t99, label %bb18, label %bb19
bb18:
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = extractvalue { i64, ptr } %t102, 0
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = getelementptr i8, ptr %t109, i64 %t105
  call void @olang_textcopy(ptr %t110, ptr %t106, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t109, 1
  %t115 = extractvalue { i64, ptr } %t112, 0
  %t116 = extractvalue { i64, ptr } %t112, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t123 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t100, { i64, ptr } %t120)
  store i1 %t123, ptr %l42
  br label %bb20
bb19:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb25
bb20:
  %t124 = load i1, ptr %l42, !tbaa !21
  br i1 %t124, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb24
bb22:
  %t125 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t129, i64 %t130)
  %t135 = getelementptr i8, ptr %t134, i64 %t130
  call void @olang_textcopy(ptr %t135, ptr %t131, i64 %t132)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t134, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = extractvalue { i64, ptr } %t137, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t148 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t125, { i64, ptr } %t145)
  store i1 %t148, ptr %l50
  br label %bb23
bb23:
  %t149 = load i1, ptr %l50, !tbaa !21
  store i1 %t149, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t150 = load i1, ptr %l43, !tbaa !21
  store i1 %t150, ptr %l35, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t151 = load i1, ptr %l35, !tbaa !21
  store i1 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffix_2emustFail(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb6:
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t17, ptr %l9
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ffix_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i32, { i64, [2 x i64] } }
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l62 = alloca i1
  %l64 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca [46 x { i64, ptr }]
  %l70 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca [46 x { i64, ptr }]
  %l80 = alloca i64
  %l83 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca i64
  %l111 = alloca { i64, ptr }
  %l116 = alloca i1
  %l127 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca [46 x { i64, ptr }]
  %l135 = alloca i64
  %l136 = alloca i64
  %l144 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l157 = alloca i1
  %l158 = alloca i1
  %l166 = alloca { i64, ptr }
  %l180 = alloca i1
  %l182 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l185 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l187 = alloca i1
  %l193 = alloca i1
  %l195 = alloca i1
  %l196 = alloca { i64, ptr }
  %l199 = alloca i1
  %l203 = alloca i1
  %l208 = alloca { i64, ptr }
  %l211 = alloca i32
  %l213 = alloca i1
  %l214 = alloca { i32, { i64, [2 x i64] } }
  %l215 = alloca { i32, { i64, [2 x i64] } }
  %l216 = alloca i32
  %l221 = alloca { i32, { i64, [2 x i64] } }
  %l222 = alloca { i32, { i64, [2 x i64] } }
  %l225 = alloca i64
  %l226 = alloca i64
  %l233 = alloca i1
  %l242 = alloca i64
  %l244 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l252 = alloca i64
  %l254 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l256 = alloca i64
  %l278 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca i32
  %t119 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2ffix_2eToolsDir(ptr %v2, ptr %v3, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t2)
  store { i64, ptr } %t5, ptr %l34
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t7)
  store i1 %t9, ptr %l36
  br label %bb2
bb2:
  %t10 = load i1, ptr %l36, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t18 = extractvalue { i64, ptr } %t14, 1
  %t19 = extractvalue { i64, ptr } %t14, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t15, i64 %t16)
  %t25 = getelementptr i8, ptr %t24, i64 %t16
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t24, 1
  %t31 = extractvalue { i64, ptr } %t28, 0
  %t32 = extractvalue { i64, ptr } %t28, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s1, ptr %t13, { i64, ptr } %t36)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb6:
  %t40 = call { i64, ptr } @compiler_2ffix_2eBinDir(ptr %s0)
  store { i64, ptr } %t40, ptr %l44
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t42)
  store i32 %t44, ptr %l46
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb9, label %ok.46, !prof !99
ok.46:
  br label %bb8
bb8:
  br label %bb14
bb9:
  %t47 = load i32, ptr %l46, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  store i1 %t50, ptr %l48, !tbaa !21
  %t51 = load i32, ptr %l46, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t61 = extractvalue { i64, ptr } %t57, 1
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t58, i64 %t59)
  %t68 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t68, ptr %t61, i64 %t62)
  %t69 = getelementptr i8, ptr %t68, i64 %t62
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t74 = extractvalue { i64, ptr } %t71, 0
  %t75 = extractvalue { i64, ptr } %t71, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s3, ptr %t56, { i64, ptr } %t79)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb14:
  %t83 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d98, i32 0, i32 1) })
  %t84 = extractvalue { i32, { i64, ptr } } %t83, 1
  %t85 = extractvalue { i32, { i64, ptr } } %t83, 0
  store i32 %t85, ptr %l59
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb16, label %ok.87, !prof !99
ok.87:
  store { i64, ptr } %t84, ptr %l58
  br label %bb15
bb15:
  %t88 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t88, ptr %l57, !tbaa !27
  br label %bb20
bb16:
  %t89 = load i32, ptr %l59, !tbaa !23
  %t90 = ashr i32 %t89, 16
  %t92 = icmp eq i32 %t90, 1
  br i1 %t92, label %bb17, label %bb18
bb17:
  call void @__olang_errpay_pop()
  br label %bb18
bb18:
  br label %bb19
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l57, !tbaa !27
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t94, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t95, ptr %l62
  br label %bb21
bb21:
  %t96 = load i1, ptr %l62, !tbaa !21
  %t97 = xor i1 %t96, true
  store i1 %t97, ptr %l7, !tbaa !21
  %t99 = call i64 @std_2ftime_2eNow()
  store i64 %t99, ptr %l64
  br label %bb22
bb22:
  %t100 = load i64, ptr %l64, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = call { i64, ptr } @compiler_2ffix_2ebuiltBy(ptr %v2, ptr %s0, { i64, ptr } %t101)
  store { i64, ptr } %t103, ptr %l66
  br label %bb23
bb23:
  %t104 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t104, ptr %l9, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t107 = call { i64, ptr } @compiler_2ffix_2estdKey(ptr %v3, ptr %s0, { i64, ptr } %t105)
  store { i64, ptr } %t107, ptr %l68
  br label %bb24
bb24:
  %t108 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t108, ptr %l10, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %l69, ptr @G_2ecompiler_2ffix_2eToolNames, i64 736, i1 false)
  %t109 = load [46 x { i64, ptr }], ptr %l69
  store i64 46, ptr %l70, !tbaa !24
  %t110 = load i64, ptr %l70, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb25, label %bb26
bb25:
  %t113 = load i64, ptr %l70, !tbaa !24
  %t114 = icmp sle i64 %t113, 576460752303423487
  br i1 %t114, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7ff6490bc64d8e4c_ced9be9374cda200)
  unreachable
bb27:
  %t116 = load i64, ptr %l70, !tbaa !24
  %t117 = mul i64 %t116, 16
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  store i64 0, ptr %t119
  br label %fill.120
fill.120:
  %t123 = load i64, ptr %t119
  %t124 = icmp slt i64 %t123, %t116
  br i1 %t124, label %fillb.121, label %filld.122
fillb.121:
  %t125 = getelementptr { i64, ptr }, ptr %t118, i64 %t123
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %t125
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %t119
  br label %fill.120
filld.122:
  %t127 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t118, 1
  store { i64, ptr } %t128, ptr %l11, !tbaa !27
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l74
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_7ff6490bc64d8e4c_ced9be9374cda200)
  unreachable
bb29:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr @G_2ecompiler_2ffix_2eToolNames, i64 736, i1 false)
  %t132 = load [46 x { i64, ptr }], ptr %l75
  store i64 46, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb30, label %bb31
bb30:
  %t140 = load i64, ptr %l15, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb35
bb32:
  %t144 = load i64, ptr %l14, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l15, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l83, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb34
bb34:
  %t160 = load i64, ptr %l83, !tbaa !24
  store i64 %t160, ptr %l80, !tbaa !24
  br label %bb35
bb35:
  %t161 = load i64, ptr %l80, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb36
bb36:
  %t162 = load i64, ptr %l17, !tbaa !24
  %t163 = load i64, ptr %l16, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb37, label %bb38
bb37:
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t171 = load i64, ptr %l17, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l18, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t180, ptr %l101, !tbaa !27
  %t181 = load i64, ptr %l18, !tbaa !24
  store i64 %t181, ptr %l102, !tbaa !24
  %t182 = call ptr @__olang_scope_hold(ptr %s0)
  %t183 = ptrtoint ptr %t182 to i64
  store i64 %t183, ptr %l103, !tbaa !24
  %t184 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t184, label %bb40, label %bb41
bb40:
  %t186 = call ptr @__olang_region_make(ptr %s0)
  %t187 = ptrtoint ptr %t186 to i64
  store i64 %t187, ptr %l103, !tbaa !24
  br label %bb41
bb41:
  %t188 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t189 = load i64, ptr %l18, !tbaa !24
  %t191 = getelementptr [46 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t189
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !37
  %t193 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t196 = load ptr, ptr @__olang_prog_scope
  %t197 = load i64, ptr %l103
  %t198 = inttoptr i64 %t197 to ptr
  %t204 = call { i64, ptr } @compiler_2ffix_2eProgramOf(ptr %s0, ptr %t196, ptr %s0, ptr %s0, ptr %s0, ptr %t198, { i64, ptr } %t188, { i64, ptr } %t192, { i64, ptr } %t193, { i64, ptr } %t194, { i64, ptr } %t195)
  store { i64, ptr } %t204, ptr %l111
  br label %bb42
bb42:
  %t205 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t206 = load i64, ptr %l103
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = extractvalue { i64, ptr } %t205, 0
  %t209 = extractvalue { i64, ptr } %t205, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_held_alloc(ptr %t207, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = load i64, ptr %l102, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %t217, i64 %t215
  store { i64, ptr } %t213, ptr %t218, !tbaa !37
  %t219 = load i64, ptr %l18, !tbaa !24
  %t221 = getelementptr [46 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolTriggers, i64 0, i64 %t219
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !37
  %t224 = load ptr, ptr @__olang_prog_scope
  %t227 = call i1 @compiler_2ffix_2etriggered(ptr %t224, ptr %v1, { i64, ptr } %t222, ptr %a1)
  store i1 %t227, ptr %l116
  br label %bb43
bb43:
  %t228 = load i1, ptr %l116, !tbaa !21
  br i1 %t228, label %bb44, label %bb45
bb44:
  %t229 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l12, i64 %t229)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t232 = load i64, ptr %l17, !tbaa !24
  %t235 = add i64 %t232, 1
  store i64 %t235, ptr %l17, !tbaa !24
  br label %bb36
bb49:
  %t237 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t246 = call { i64, ptr } @compiler_2ffix_2ebuildAll(ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t237, { i64, ptr } %t238, { i64, ptr } %t239, ptr %l12, { i64, ptr } %t240)
  store { i64, ptr } %t246, ptr %l127
  br label %bb50
bb50:
  %t247 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t247, ptr %l19, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ffix_2etrimBin(ptr %s0, ptr %s0, { i64, ptr } %t248, { i64, ptr } %t249)
  br label %bb51
bb51:
  %t252 = load i1, ptr %l7, !tbaa !21
  br i1 %t252, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t254 = load ptr, ptr %l4, !tbaa !29
  store ptr %t254, ptr %l131, !tbaa !29
  %t256 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l12)
  store i64 %t256, ptr %l133
  br label %bb54
bb53:
  br label %bb57
bb54:
  call void @llvm.memmove.p0.p0.i64(ptr %l134, ptr @G_2ecompiler_2ffix_2eToolNames, i64 736, i1 false)
  %t257 = load [46 x { i64, ptr }], ptr %l134
  store i64 46, ptr %l135, !tbaa !24
  %t258 = call i64 @std_2ftime_2eNow()
  store i64 %t258, ptr %l136
  br label %bb55
bb55:
  %t259 = load i64, ptr %l8, !tbaa !24
  %t260 = load i64, ptr %l136, !tbaa !24
  %t262 = sub i64 %t260, %t259
  %t264 = sdiv i64 %t262, 1000000
  %t265 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t267 = load i64, ptr %l133, !tbaa !24
  %t268 = call i64 @__olang_fmt_i64(ptr null, i64 %t267)
  %t269 = add i64 %t266, %t268
  %t270 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load i64, ptr %l135, !tbaa !24
  %t274 = call i64 @__olang_fmt_i64(ptr null, i64 %t273)
  %t275 = add i64 %t272, %t274
  %t276 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t278 = add i64 %t275, %t277
  %t280 = call i64 @__olang_fmt_i64(ptr null, i64 %t264)
  %t281 = add i64 %t278, %t280
  %t282 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t283 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t284 = add i64 %t281, %t283
  %t285 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t265, i64 %t266)
  %t286 = getelementptr i8, ptr %t285, i64 %t266
  %t287 = call i64 @__olang_fmt_i64(ptr %t286, i64 %t267)
  %t288 = getelementptr i8, ptr %t286, i64 %t268
  call void @olang_textcopy(ptr %t288, ptr %t270, i64 %t271)
  %t289 = getelementptr i8, ptr %t288, i64 %t271
  %t290 = call i64 @__olang_fmt_i64(ptr %t289, i64 %t273)
  %t291 = getelementptr i8, ptr %t289, i64 %t274
  call void @olang_textcopy(ptr %t291, ptr %t276, i64 %t277)
  %t292 = getelementptr i8, ptr %t291, i64 %t277
  %t293 = call i64 @__olang_fmt_i64(ptr %t292, i64 %t264)
  %t294 = getelementptr i8, ptr %t292, i64 %t280
  call void @olang_textcopy(ptr %t294, ptr %t282, i64 %t283)
  %t295 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t285, 1
  %t299 = extractvalue { i64, ptr } %t296, 0
  %t300 = extractvalue { i64, ptr } %t296, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t305 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s9, ptr %t305, { i64, ptr } %t304)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  store i64 0, ptr %l20, !tbaa !24
  store i1 false, ptr %l21, !tbaa !21
  %t307 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t307, ptr %l22, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s11
  %t309 = call { i64, ptr } @compiler_2ffix_2eOrder(ptr %s11)
  store { i64, ptr } %t309, ptr %l144
  br label %bb58
bb58:
  %t310 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t310, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t312 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  store i64 %t314, ptr %l25, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s12
  %t316 = load i64, ptr %l24, !tbaa !24
  %t317 = load i64, ptr %l25, !tbaa !24
  %t320 = icmp slt i64 %t316, %t317
  %t322 = xor i1 %t320, true
  br i1 %t322, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb122
bb61:
  br label %bb62
bb62:
  %t324 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t324, ptr %l152, !tbaa !27
  %t325 = load i64, ptr %l24, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr i64, ptr %t328, i64 %t325
  %t330 = load i64, ptr %t329, !tbaa !34
  store i64 %t330, ptr %l26, !tbaa !24
  %t332 = load i64, ptr %l26, !tbaa !24
  %t334 = getelementptr [46 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t332
  %t335 = load i64, ptr %t334, !tbaa !34
  %t337 = call i1 @compiler_2ffix_2edriven(i64 %t335)
  store i1 %t337, ptr %l157
  br label %bb63
bb63:
  %t338 = load i1, ptr %l157, !tbaa !21
  br i1 %t338, label %bb64, label %bb65
bb64:
  %t339 = load i1, ptr %l21, !tbaa !21
  %t341 = xor i1 %t339, true
  store i1 %t341, ptr %l158, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb66
bb66:
  %t343 = load i1, ptr %l158, !tbaa !21
  br i1 %t343, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l21, !tbaa !21
  %t344 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t347 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t354 = call { i64, ptr } @compiler_2ffix_2efailing(ptr %v2, ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t344, { i64, ptr } %t345, { i64, ptr } %t346, { i64, ptr } %t347, { i64, ptr } %t348)
  store { i64, ptr } %t354, ptr %l166
  br label %bb69
bb68:
  br label %bb74
bb69:
  %t355 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t355, ptr %l22, !tbaa !27
  %t357 = load i1, ptr %l7, !tbaa !21
  br i1 %t357, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t359 = load ptr, ptr %l4, !tbaa !29
  %t360 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t360, 0
  %t363 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t363, 0
  %t366 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t367 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t369 = call i64 @__olang_fmt_i64(ptr null, i64 %t362)
  %t370 = add i64 %t367, %t369
  %t371 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t372 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t373 = add i64 %t370, %t372
  %t375 = call i64 @__olang_fmt_i64(ptr null, i64 %t365)
  %t376 = add i64 %t373, %t375
  %t377 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t379 = add i64 %t376, %t378
  %t380 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t379)
  call void @olang_textcopy(ptr %t380, ptr %t366, i64 %t367)
  %t381 = getelementptr i8, ptr %t380, i64 %t367
  %t382 = call i64 @__olang_fmt_i64(ptr %t381, i64 %t362)
  %t383 = getelementptr i8, ptr %t381, i64 %t369
  call void @olang_textcopy(ptr %t383, ptr %t371, i64 %t372)
  %t384 = getelementptr i8, ptr %t383, i64 %t372
  %t385 = call i64 @__olang_fmt_i64(ptr %t384, i64 %t365)
  %t386 = getelementptr i8, ptr %t384, i64 %t375
  call void @olang_textcopy(ptr %t386, ptr %t377, i64 %t378)
  %t387 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t380, 1
  %t391 = extractvalue { i64, ptr } %t388, 0
  %t392 = extractvalue { i64, ptr } %t388, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s14, ptr %t359, { i64, ptr } %t396)
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t399 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t403 = icmp eq i64 %t401, 0
  br i1 %t403, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb79
bb76:
  %t405 = load i64, ptr %l26, !tbaa !24
  %t407 = getelementptr [46 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolTriggers, i64 0, i64 %t405
  %t408 = load { i64, ptr }, ptr %t407, !tbaa !37
  store { i64, ptr } %t408, ptr %l182, !tbaa !27
  %t409 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t409, ptr %l183, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = call ptr @__olang_scope_of(ptr %t411, ptr null)
  %t413 = call ptr @__olang_scope_hold(ptr %t412)
  %t414 = ptrtoint ptr %t413 to i64
  %t416 = inttoptr i64 %t414 to ptr
  %t417 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t418 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2etextsOf(ptr %t416, ptr %s12, { i64, ptr } %t417)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t418, ptr %l185
  br label %bb77
bb77:
  %t419 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l185
  %t420 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t419, ptr %t420
  %t421 = load ptr, ptr @__olang_prog_scope
  %t422 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t424 = call i1 @compiler_2ffix_2etriggered(ptr %t421, ptr %s12, { i64, ptr } %t422, ptr %t420)
  store i1 %t424, ptr %l187
  br label %bb78
bb78:
  %t425 = load i1, ptr %l187, !tbaa !21
  %t426 = xor i1 %t425, true
  store i1 %t426, ptr %l180, !tbaa !21
  br label %bb79
bb79:
  %t428 = load i1, ptr %l180, !tbaa !21
  br i1 %t428, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s12)
  br label %bb121
bb81:
  br label %bb82
bb82:
  %t429 = load i64, ptr %l26, !tbaa !24
  %t431 = getelementptr [46 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t429
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !37
  store { i64, ptr } %t432, ptr %l27, !tbaa !27
  %t434 = load i64, ptr %l26, !tbaa !24
  %t436 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = getelementptr { i64, ptr }, ptr %t437, i64 %t434
  %t439 = load { i64, ptr }, ptr %t438, !tbaa !37
  %t441 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s12, { i64, ptr } %t439, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) })
  store i1 %t441, ptr %l193
  br label %bb83
bb83:
  %t442 = load i1, ptr %l193, !tbaa !21
  %t443 = xor i1 %t442, true
  br i1 %t443, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb87
bb85:
  %t445 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t445, ptr %l196, !tbaa !27
  %t446 = load i64, ptr %l26, !tbaa !24
  %t448 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = getelementptr { i64, ptr }, ptr %t449, i64 %t446
  %t451 = load { i64, ptr }, ptr %t450, !tbaa !37
  %t453 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t451)
  store i1 %t453, ptr %l199
  br label %bb86
bb86:
  %t454 = load i1, ptr %l199, !tbaa !21
  %t455 = xor i1 %t454, true
  store i1 %t455, ptr %l195, !tbaa !21
  br label %bb87
bb87:
  %t457 = load i1, ptr %l195, !tbaa !21
  br i1 %t457, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s17
  %t458 = load i64, ptr %l26, !tbaa !24
  %t460 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr { i64, ptr }, ptr %t461, i64 %t458
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !37
  %t465 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s17, { i64, ptr } %t463, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store i1 %t465, ptr %l203
  br label %bb90
bb89:
  br label %bb110
bb90:
  %t466 = load i1, ptr %l203, !tbaa !21
  br i1 %t466, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s18
  %t467 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t468 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t469 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t470 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t471 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t471, ptr %l208, !tbaa !27
  %t472 = load i64, ptr %l26, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr { i64, ptr }, ptr %t475, i64 %t472
  %t477 = load { i64, ptr }, ptr %t476, !tbaa !37
  %t478 = load ptr, ptr @__olang_prog_scope
  %t484 = call i32 @compiler_2ffix_2ebuildTool(ptr %v2, ptr %s0, ptr %s0, ptr %t478, ptr %s0, { i64, ptr } %t467, { i64, ptr } %t468, { i64, ptr } %t469, { i64, ptr } %t470, { i64, ptr } %t477)
  store i32 %t484, ptr %l211
  %t485 = icmp ne i32 %t484, 0
  br i1 %t485, label %bb94, label %ok.486, !prof !99
ok.486:
  br label %bb93
bb92:
  br label %bb104
bb93:
  br label %bb103
bb94:
  %t487 = load i32, ptr %l211, !tbaa !23
  %t488 = ashr i32 %t487, 16
  %t490 = icmp eq i32 %t488, 1
  store i1 %t490, ptr %l213, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l28
  %t491 = load i32, ptr %l211, !tbaa !23
  %t492 = lshr i32 %t491, 16
  %t493 = and i32 %t491, 65535
  %t494 = icmp eq i32 %t492, 1
  %t495 = select i1 %t494, i32 1, i32 0
  %t496 = icmp eq i32 %t491, 0
  %t497 = shl i32 %t495, 16
  %t498 = or i32 %t497, %t493
  %t499 = select i1 %t496, i32 0, i32 %t498
  %t500 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l28, i32 0, i32 0
  store i32 %t499, ptr %t500, !tbaa !23
  br label %bb95
bb95:
  %t501 = load { i32, { i64, [2 x i64] } }, ptr %l28
  store { i32, { i64, [2 x i64] } } %t501, ptr %l214
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l215
  %t502 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l214, i32 0, i32 0
  %t503 = load i32, ptr %t502, !tbaa !23
  store i32 %t503, ptr %l216, !tbaa !23
  %t504 = load i32, ptr %l216, !tbaa !23
  %t505 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l215, i32 0, i32 0
  store i32 %t504, ptr %t505, !tbaa !23
  %t506 = load i32, ptr %l216, !tbaa !23
  %t507 = ashr i32 %t506, 16
  %t509 = icmp eq i32 %t507, 1
  br i1 %t509, label %bb96, label %bb97
bb96:
  %t511 = call ptr @__olang_errpay_top_get()
  %t513 = load { i64, [2 x i64] }, ptr %t511
  %t514 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l215, i32 0, i32 1
  store { i64, [2 x i64] } %t513, ptr %t514
  br label %bb97
bb97:
  %t516 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bcompiler_2ffix_3aNotBuilt_7d(ptr %s18, ptr %l215)
  store { i32, { i64, [2 x i64] } } %t516, ptr %l221
  br label %bb98
bb98:
  %t517 = load { i32, { i64, [2 x i64] } }, ptr %l221
  store { i32, { i64, [2 x i64] } } %t517, ptr %l28
  %t518 = load { i32, { i64, [2 x i64] } }, ptr %l28
  store { i32, { i64, [2 x i64] } } %t518, ptr %l222
  %t519 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l222, i32 0, i32 0
  %t520 = load i32, ptr %t519, !tbaa !23
  %t521 = ashr i32 %t520, 16
  %t523 = icmp eq i32 %t521, 1
  br i1 %t523, label %bb99, label %bb100
bb99:
  call void @__olang_errpay_pop()
  br label %bb100
bb100:
  %t525 = load i64, ptr %l26, !tbaa !24
  store i64 %t525, ptr %l225, !tbaa !24
  %t526 = call ptr @__olang_scope_hold(ptr %s0)
  %t527 = ptrtoint ptr %t526 to i64
  store i64 %t527, ptr %l226, !tbaa !24
  %t528 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t528, label %bb101, label %bb102
bb101:
  %t530 = call ptr @__olang_region_make(ptr %s0)
  %t531 = ptrtoint ptr %t530 to i64
  store i64 %t531, ptr %l226, !tbaa !24
  br label %bb102
bb102:
  %t532 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l28, i32 0, i32 1
  %t533 = getelementptr { i64, [2 x i64] }, ptr %t532, i32 0, i32 1
  %t534 = getelementptr { { i64, ptr } }, ptr %t533, i32 0, i32 0
  %t535 = load { i64, ptr }, ptr %t534
  %t537 = extractvalue { i64, ptr } %t535, 1
  %t538 = extractvalue { i64, ptr } %t535, 0
  %t539 = load i64, ptr %l226
  %t540 = inttoptr i64 %t539 to ptr
  %t541 = call ptr @__olang_held_alloc(ptr %t540, i64 %t538)
  call void @olang_textcopy(ptr %t541, ptr %t537, i64 %t538)
  %t542 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t541, 1
  %t546 = load i64, ptr %l225, !tbaa !24
  %t547 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t548 = load ptr, ptr %t547, !tbaa !27
  %t549 = getelementptr { i64, ptr }, ptr %t548, i64 %t546
  store { i64, ptr } %t543, ptr %t549, !tbaa !37
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s18)
  br label %bb104
bb104:
  %t550 = load i64, ptr %l26, !tbaa !24
  %t552 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !27
  %t554 = getelementptr { i64, ptr }, ptr %t553, i64 %t550
  %t555 = load { i64, ptr }, ptr %t554, !tbaa !37
  %t557 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s17, { i64, ptr } %t555, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t557, ptr %l233
  br label %bb105
bb105:
  %t558 = load i1, ptr %l233, !tbaa !21
  %t559 = xor i1 %t558, true
  br i1 %t559, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s21
  %t561 = load ptr, ptr %l4, !tbaa !29
  %t562 = load i64, ptr %l26, !tbaa !24
  %t564 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = getelementptr { i64, ptr }, ptr %t565, i64 %t562
  %t567 = load { i64, ptr }, ptr %t566, !tbaa !37
  %t568 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t569 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t571 = extractvalue { i64, ptr } %t567, 1
  %t572 = extractvalue { i64, ptr } %t567, 0
  %t573 = add i64 %t569, %t572
  %t574 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t575 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t576 = add i64 %t573, %t575
  %t577 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t576)
  call void @olang_textcopy(ptr %t577, ptr %t568, i64 %t569)
  %t578 = getelementptr i8, ptr %t577, i64 %t569
  call void @olang_textcopy(ptr %t578, ptr %t571, i64 %t572)
  %t579 = getelementptr i8, ptr %t578, i64 %t572
  call void @olang_textcopy(ptr %t579, ptr %t574, i64 %t575)
  %t580 = insertvalue { i64, ptr } undef, i64 %t576, 0
  %t581 = insertvalue { i64, ptr } %t580, ptr %t577, 1
  %t584 = extractvalue { i64, ptr } %t581, 0
  %t585 = extractvalue { i64, ptr } %t581, 1
  %t586 = mul i64 %t584, 1
  %t587 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t586)
  call void @llvm.memcpy.p0.p0.i64(ptr %t587, ptr %t585, i64 %t586, i1 false)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s21, ptr %t561, { i64, ptr } %t589)
  br label %bb108
bb107:
  br label %bb109
bb108:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s17)
  br label %bb110
bb110:
  %t593 = call i64 @std_2ftime_2eNow()
  store i64 %t593, ptr %l242
  br label %bb111
bb111:
  %t594 = load i64, ptr %l242, !tbaa !24
  store i64 %t594, ptr %l29, !tbaa !24
  %t595 = load i64, ptr %l26, !tbaa !24
  %t596 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t596, ptr %l244, !tbaa !27
  %t597 = load i64, ptr %l26, !tbaa !24
  %t599 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = getelementptr { i64, ptr }, ptr %t600, i64 %t597
  %t602 = load { i64, ptr }, ptr %t601, !tbaa !37
  %t603 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t604 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t605 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t605, ptr %l249, !tbaa !27
  %t606 = load ptr, ptr %l4, !tbaa !29
  %t607 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t607, 1
  %t609 = call ptr @__olang_scope_of(ptr %t608, ptr null)
  %t610 = call ptr @__olang_scope_hold(ptr %t609)
  %t611 = ptrtoint ptr %t610 to i64
  %t613 = inttoptr i64 %t611 to ptr
  %t618 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t620 = call i64 @compiler_2ffix_2erunTool(ptr %s0, ptr %v2, ptr %v3, ptr %t613, ptr %v4, i64 %t595, { i64, ptr } %t602, { i64, ptr } %t603, { i64, ptr } %t604, { i64, ptr } %t618, ptr %t606)
  store i64 %t620, ptr %l252
  br label %bb112
bb112:
  %t621 = load i64, ptr %l252, !tbaa !24
  store i64 %t621, ptr %l30, !tbaa !24
  %t622 = load i1, ptr %l7, !tbaa !21
  br i1 %t622, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s23
  %t624 = load ptr, ptr %l4, !tbaa !29
  store ptr %t624, ptr %l254, !tbaa !29
  %t625 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t625, ptr %l255, !tbaa !27
  %t626 = call i64 @std_2ftime_2eNow()
  store i64 %t626, ptr %l256
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t627 = load i64, ptr %l29, !tbaa !24
  %t628 = load i64, ptr %l256, !tbaa !24
  %t630 = sub i64 %t628, %t627
  %t632 = sdiv i64 %t630, 1000000
  %t633 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t634 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t635 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t636 = extractvalue { i64, ptr } %t635, 1
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t638 = add i64 %t634, %t637
  %t639 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t640 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t641 = add i64 %t638, %t640
  %t643 = call i64 @__olang_fmt_i64(ptr null, i64 %t632)
  %t644 = add i64 %t641, %t643
  %t645 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t646 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t647 = add i64 %t644, %t646
  %t648 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t647)
  call void @olang_textcopy(ptr %t648, ptr %t633, i64 %t634)
  %t649 = getelementptr i8, ptr %t648, i64 %t634
  call void @olang_textcopy(ptr %t649, ptr %t636, i64 %t637)
  %t650 = getelementptr i8, ptr %t649, i64 %t637
  call void @olang_textcopy(ptr %t650, ptr %t639, i64 %t640)
  %t651 = getelementptr i8, ptr %t650, i64 %t640
  %t652 = call i64 @__olang_fmt_i64(ptr %t651, i64 %t632)
  %t653 = getelementptr i8, ptr %t651, i64 %t643
  call void @olang_textcopy(ptr %t653, ptr %t645, i64 %t646)
  %t654 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr %t648, 1
  %t658 = extractvalue { i64, ptr } %t655, 0
  %t659 = extractvalue { i64, ptr } %t655, 1
  %t660 = mul i64 %t658, 1
  %t661 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t660)
  call void @llvm.memcpy.p0.p0.i64(ptr %t661, ptr %t659, i64 %t660, i1 false)
  %t662 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  %t664 = load ptr, ptr %l254, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s23, ptr %t664, { i64, ptr } %t663)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s23)
  br label %bb117
bb117:
  %t666 = load i64, ptr %l30, !tbaa !24
  %t668 = icmp slt i64 %t666, 0
  br i1 %t668, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 2, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t671 = load i64, ptr %l20, !tbaa !24
  %t673 = load i64, ptr %l30, !tbaa !24
  %t676 = add i64 %t671, %t673
  store i64 %t676, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb121
bb121:
  %t678 = load i64, ptr %l24, !tbaa !24
  %t681 = add i64 %t678, 1
  store i64 %t681, ptr %l24, !tbaa !24
  br label %bb59
bb122:
  call void @__olang_scope_close(ptr %s11)
  %t683 = load i64, ptr %l20, !tbaa !24
  %t685 = icmp eq i64 %t683, 0
  br i1 %t685, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t688 = load i64, ptr %l20, !tbaa !24
  %t690 = icmp eq i64 %t688, 1
  br i1 %t690, label %bb126, label %bb127
bb126:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %l278, !tbaa !27
  br label %bb128
bb127:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %l278, !tbaa !27
  br label %bb128
bb128:
  %t692 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t693 = load ptr, ptr %l4, !tbaa !29
  %t694 = load i64, ptr %l20, !tbaa !24
  %t696 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t697 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t699 = call i64 @__olang_fmt_i64(ptr null, i64 %t694)
  %t700 = add i64 %t697, %t699
  %t701 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t702 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t703 = add i64 %t700, %t702
  %t705 = extractvalue { i64, ptr } %t692, 1
  %t706 = extractvalue { i64, ptr } %t692, 0
  %t707 = add i64 %t703, %t706
  %t708 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t709 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t710 = add i64 %t707, %t709
  %t711 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t710)
  call void @olang_textcopy(ptr %t711, ptr %t696, i64 %t697)
  %t712 = getelementptr i8, ptr %t711, i64 %t697
  %t713 = call i64 @__olang_fmt_i64(ptr %t712, i64 %t694)
  %t714 = getelementptr i8, ptr %t712, i64 %t699
  call void @olang_textcopy(ptr %t714, ptr %t701, i64 %t702)
  %t715 = getelementptr i8, ptr %t714, i64 %t702
  call void @olang_textcopy(ptr %t715, ptr %t705, i64 %t706)
  %t716 = getelementptr i8, ptr %t715, i64 %t706
  call void @olang_textcopy(ptr %t716, ptr %t708, i64 %t709)
  %t717 = insertvalue { i64, ptr } undef, i64 %t710, 0
  %t718 = insertvalue { i64, ptr } %t717, ptr %t711, 1
  %t721 = extractvalue { i64, ptr } %t718, 0
  %t722 = extractvalue { i64, ptr } %t718, 1
  %t723 = mul i64 %t721, 1
  %t724 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t723)
  call void @llvm.memcpy.p0.p0.i64(ptr %t724, ptr %t722, i64 %t723, i1 false)
  %t725 = insertvalue { i64, ptr } undef, i64 %t721, 0
  %t726 = insertvalue { i64, ptr } %t725, ptr %t724, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s0, ptr %t693, { i64, ptr } %t726)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ffix_2erunTool(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i32, { i64, [2 x i64] } }
  %l16 = alloca %"std/os:Output"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"std/os:Output"
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca %"std/os:Output"
  %l72 = alloca i32
  %l74 = alloca i1
  %l75 = alloca { i32, { i64, [2 x i64] } }
  %l76 = alloca { i32, { i64, [2 x i64] } }
  %l77 = alloca i32
  %l82 = alloca { i32, { i64, [2 x i64] } }
  %l83 = alloca { i32, { i64, [2 x i64] } }
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i32, { i64, [2 x i64] } }
  %l90 = alloca { i32, { i64, [2 x i64] } }
  %l91 = alloca i32
  %l106 = alloca { i64, ptr }
  %l114 = alloca i64
  %l117 = alloca i1
  %l127 = alloca i1
  %l130 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = getelementptr [46 x { i64, ptr }], ptr @G_2ecompiler_2ffix_2eToolNames, i64 0, i64 %t1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !37
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l9, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l10, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb3:
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l10, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l10, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l30, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb5
bb5:
  %t38 = load i64, ptr %l30, !tbaa !24
  store i64 %t38, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l12, !tbaa !24
  %t41 = load i64, ptr %l11, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l12, !tbaa !24
  %t50 = load i64, ptr %l10, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l13, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l48, !tbaa !27
  %t59 = load i64, ptr %l13, !tbaa !24
  store i64 %t59, ptr %l49, !tbaa !24
  %t60 = load i64, ptr %l13, !tbaa !24
  %t61 = load i64, ptr @G_2ecompiler_2ffix_2eBatch, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t70 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t64, i64 %t67)
  store i64 %t70, ptr %l55
  br label %bb11
bb11:
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l56, !tbaa !24
  %t73 = load i64, ptr %l49, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb12, label %bb13
bb12:
  %t76 = load i64, ptr %l49, !tbaa !24
  %t77 = load i64, ptr %l55, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4ea6f09d5973466a_f399989f0872f916)
  unreachable
bb14:
  %t80 = load i64, ptr %l55, !tbaa !24
  %t81 = load i64, ptr %l56, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4ea6f09d5973466a_f399989f0872f916)
  unreachable
bb16:
  %t84 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l49, !tbaa !24
  %t87 = load i64, ptr %l55, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %t85, i64 %t86
  %t89 = sub i64 %t87, %t86
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t93 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t94 = load i64, ptr %l0, !tbaa !24
  %t96 = getelementptr [46 x i64], ptr @G_2ecompiler_2ffix_2eToolKinds, i64 0, i64 %t94
  %t97 = load i64, ptr %t96, !tbaa !34
  %t106 = call { i64, ptr } @compiler_2ffix_2earguments(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s2, { i64, ptr } %t93, i64 %t97, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %t91)
  store { i64, ptr } %t106, ptr %l68
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4ea6f09d5973466a_f399989f0872f916)
  unreachable
bb18:
  %t107 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l70, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t110 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t107, { i64, ptr } %t109, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d122, i32 0, i32 1) })
  %t111 = extractvalue { i32, %"std/os:Output" } %t110, 1
  %t112 = extractvalue { i32, %"std/os:Output" } %t110, 0
  store i32 %t112, ptr %l72
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb20, label %ok.114, !prof !99
ok.114:
  store %"std/os:Output" %t111, ptr %l71
  br label %bb19
bb19:
  %t115 = load %"std/os:Output", ptr %l71
  store %"std/os:Output" %t115, ptr %l61
  br label %bb44
bb20:
  %t116 = load i32, ptr %l72, !tbaa !23
  %t117 = ashr i32 %t116, 16
  %t119 = icmp eq i32 %t117, 1
  store i1 %t119, ptr %l74, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l15
  %t120 = load i32, ptr %l72, !tbaa !23
  %t121 = lshr i32 %t120, 16
  %t122 = and i32 %t120, 65535
  %t123 = icmp eq i32 %t121, 1
  %t124 = select i1 %t123, i32 1, i32 0
  %t125 = icmp eq i32 %t120, 0
  %t126 = shl i32 %t124, 16
  %t127 = or i32 %t126, %t122
  %t128 = select i1 %t125, i32 0, i32 %t127
  %t129 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l15, i32 0, i32 0
  store i32 %t128, ptr %t129, !tbaa !23
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t130 = load { i32, { i64, [2 x i64] } }, ptr %l15
  store { i32, { i64, [2 x i64] } } %t130, ptr %l75
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l76
  %t131 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l75, i32 0, i32 0
  %t132 = load i32, ptr %t131, !tbaa !23
  store i32 %t132, ptr %l77, !tbaa !23
  %t133 = load i32, ptr %l77, !tbaa !23
  %t134 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l76, i32 0, i32 0
  store i32 %t133, ptr %t134, !tbaa !23
  %t135 = load i32, ptr %l77, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  br i1 %t138, label %bb22, label %bb23
bb22:
  %t140 = call ptr @__olang_errpay_top_get()
  %t142 = load { i64, [2 x i64] }, ptr %t140
  %t143 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l76, i32 0, i32 1
  store { i64, [2 x i64] } %t142, ptr %t143
  br label %bb23
bb23:
  %t145 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s2, ptr %l76)
  store { i32, { i64, [2 x i64] } } %t145, ptr %l82
  br label %bb24
bb24:
  %t146 = load { i32, { i64, [2 x i64] } }, ptr %l82
  store { i32, { i64, [2 x i64] } } %t146, ptr %l15
  %t147 = load { i32, { i64, [2 x i64] } }, ptr %l15
  store { i32, { i64, [2 x i64] } } %t147, ptr %l83
  %t148 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l83, i32 0, i32 0
  %t149 = load i32, ptr %t148, !tbaa !23
  %t150 = ashr i32 %t149, 16
  %t152 = icmp eq i32 %t150, 1
  br i1 %t152, label %bb25, label %bb26
bb25:
  call void @__olang_errpay_pop()
  br label %bb26
bb26:
  %t154 = load ptr, ptr %l5, !tbaa !29
  store ptr %t154, ptr %l86, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t155, ptr %l87, !tbaa !27
  %t156 = load { i32, { i64, [2 x i64] } }, ptr %l15
  store { i32, { i64, [2 x i64] } } %t156, ptr %l88
  %t158 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s3, ptr %l88)
  store { i32, { i64, [2 x i64] } } %t158, ptr %l90
  br label %bb27
bb27:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t159 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t159, i64 %t160)
  %t161 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  call void @__olang_sb_put(ptr %s4, ptr %t162, i64 %t163)
  %t164 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t164, i64 %t165)
  %t166 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  store i32 %t167, ptr %l91, !tbaa !23
  %t168 = load i32, ptr %l91, !tbaa !23
  %t169 = icmp eq i32 %t168, 0
  br i1 %t169, label %bb29, label %bb30
bb28:
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t171, i64 %t172)
  %t173 = load ptr, ptr %s4
  %t174 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t175 = load i64, ptr %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t173, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l106, !tbaa !27
  %t179 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t180 = load ptr, ptr %t179
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %sbgrew.182, label %sbdone.183
sbgrew.182:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.183
sbdone.183:
  %t184 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = extractvalue { i64, ptr } %t184, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  %t192 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s3, ptr %t192, { i64, ptr } %t191)
  br label %bb43
bb29:
  %t194 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t194, i64 %t195)
  br label %bb28
bb30:
  %t196 = load i32, ptr %l91, !tbaa !23
  %t197 = icmp eq i32 %t196, 65536
  br i1 %t197, label %bb31, label %bb32
bb31:
  %t199 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t199, i64 %t200)
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t201, i64 %t202)
  %t203 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t204 = getelementptr { i64, [2 x i64] }, ptr %t203, i32 0, i32 1
  %t205 = getelementptr { { i64, ptr } }, ptr %t204, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205
  %t208 = extractvalue { i64, ptr } %t206, 1
  %t209 = extractvalue { i64, ptr } %t206, 0
  %t210 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t208, i64 %t209, i8 34)
  %t211 = call ptr @__olang_sb_room(ptr %s4, i64 %t210)
  %t212 = call i64 @__olang_rd_quote(ptr %t211, i64 0, ptr %t208, i64 %t209, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t210)
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t213, i64 %t214)
  br label %bb28
bb32:
  %t215 = load i32, ptr %l91, !tbaa !23
  %t216 = icmp eq i32 %t215, 65537
  br i1 %t216, label %bb33, label %bb34
bb33:
  %t218 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t218, i64 %t219)
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t220, i64 %t221)
  %t222 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t223 = getelementptr { i64, [2 x i64] }, ptr %t222, i32 0, i32 1
  %t224 = getelementptr { { i64, ptr } }, ptr %t223, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224
  %t227 = extractvalue { i64, ptr } %t225, 1
  %t228 = extractvalue { i64, ptr } %t225, 0
  %t229 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t227, i64 %t228, i8 34)
  %t230 = call ptr @__olang_sb_room(ptr %s4, i64 %t229)
  %t231 = call i64 @__olang_rd_quote(ptr %t230, i64 0, ptr %t227, i64 %t228, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t229)
  %t232 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t232, i64 %t233)
  br label %bb28
bb34:
  %t234 = load i32, ptr %l91, !tbaa !23
  %t235 = icmp eq i32 %t234, 65538
  br i1 %t235, label %bb35, label %bb36
bb35:
  %t237 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t237, i64 %t238)
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t239, i64 %t240)
  %t241 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t242 = getelementptr { i64, [2 x i64] }, ptr %t241, i32 0, i32 1
  %t243 = getelementptr { { i64, ptr } }, ptr %t242, i32 0, i32 0
  %t244 = load { i64, ptr }, ptr %t243
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = extractvalue { i64, ptr } %t244, 0
  %t248 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t246, i64 %t247, i8 34)
  %t249 = call ptr @__olang_sb_room(ptr %s4, i64 %t248)
  %t250 = call i64 @__olang_rd_quote(ptr %t249, i64 0, ptr %t246, i64 %t247, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t248)
  %t251 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t251, i64 %t252)
  br label %bb28
bb36:
  %t253 = load i32, ptr %l91, !tbaa !23
  %t254 = icmp eq i32 %t253, 65539
  br i1 %t254, label %bb37, label %bb38
bb37:
  %t256 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t256, i64 %t257)
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t258, i64 %t259)
  %t260 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t261 = getelementptr { i64, [2 x i64] }, ptr %t260, i32 0, i32 1
  %t262 = getelementptr { { i64, ptr } }, ptr %t261, i32 0, i32 0
  %t263 = load { i64, ptr }, ptr %t262
  %t265 = extractvalue { i64, ptr } %t263, 1
  %t266 = extractvalue { i64, ptr } %t263, 0
  %t267 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t265, i64 %t266, i8 34)
  %t268 = call ptr @__olang_sb_room(ptr %s4, i64 %t267)
  %t269 = call i64 @__olang_rd_quote(ptr %t268, i64 0, ptr %t265, i64 %t266, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t267)
  %t270 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t270, i64 %t271)
  br label %bb28
bb38:
  %t272 = load i32, ptr %l91, !tbaa !23
  %t273 = icmp eq i32 %t272, 65540
  br i1 %t273, label %bb39, label %bb40
bb39:
  %t275 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t276 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t275, i64 %t276)
  %t277 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t277, i64 %t278)
  %t279 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t280 = getelementptr { i64, [2 x i64] }, ptr %t279, i32 0, i32 1
  %t281 = getelementptr { { i64, ptr } }, ptr %t280, i32 0, i32 0
  %t282 = load { i64, ptr }, ptr %t281
  %t284 = extractvalue { i64, ptr } %t282, 1
  %t285 = extractvalue { i64, ptr } %t282, 0
  %t286 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t284, i64 %t285, i8 34)
  %t287 = call ptr @__olang_sb_room(ptr %s4, i64 %t286)
  %t288 = call i64 @__olang_rd_quote(ptr %t287, i64 0, ptr %t284, i64 %t285, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t286)
  %t289 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t289, i64 %t290)
  br label %bb28
bb40:
  %t291 = load i32, ptr %l91, !tbaa !23
  %t292 = icmp eq i32 %t291, 65541
  br i1 %t292, label %bb41, label %bb42
bb41:
  %t294 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t294, i64 %t295)
  %t296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t297 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t296, i64 %t297)
  %t298 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t299 = getelementptr { i64, [2 x i64] }, ptr %t298, i32 0, i32 1
  %t300 = getelementptr { { i64, ptr } }, ptr %t299, i32 0, i32 0
  %t301 = load { i64, ptr }, ptr %t300
  %t303 = extractvalue { i64, ptr } %t301, 1
  %t304 = extractvalue { i64, ptr } %t301, 0
  %t305 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t303, i64 %t304, i8 34)
  %t306 = call ptr @__olang_sb_room(ptr %s4, i64 %t305)
  %t307 = call i64 @__olang_rd_quote(ptr %t306, i64 0, ptr %t303, i64 %t304, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t305)
  %t308 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t308, i64 %t309)
  br label %bb28
bb42:
  %t310 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t310, i64 %t311)
  %t312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t312, i64 %t313)
  %t314 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l90, i32 0, i32 1
  %t315 = getelementptr { i64, [2 x i64] }, ptr %t314, i32 0, i32 1
  %t316 = getelementptr { { i64, ptr } }, ptr %t315, i32 0, i32 0
  %t317 = load { i64, ptr }, ptr %t316
  %t319 = extractvalue { i64, ptr } %t317, 1
  %t320 = extractvalue { i64, ptr } %t317, 0
  %t321 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t319, i64 %t320, i8 34)
  %t322 = call ptr @__olang_sb_room(ptr %s4, i64 %t321)
  %t323 = call i64 @__olang_rd_quote(ptr %t322, i64 0, ptr %t319, i64 %t320, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t321)
  %t324 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t324, i64 %t325)
  br label %bb28
bb43:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb44:
  %t327 = load %"std/os:Output", ptr %l61
  store %"std/os:Output" %t327, ptr %l16
  %t328 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 1
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  %t330 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 2
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t329, 1
  %t334 = extractvalue { i64, ptr } %t329, 0
  %t336 = extractvalue { i64, ptr } %t331, 1
  %t337 = extractvalue { i64, ptr } %t331, 0
  %t338 = add i64 %t334, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t333, i64 %t334)
  %t340 = getelementptr i8, ptr %t339, i64 %t334
  call void @olang_textcopy(ptr %t340, ptr %t336, i64 %t337)
  %t341 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t339, 1
  store { i64, ptr } %t342, ptr %l17, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t346 = call i64 @compiler_2ffix_2ebyHand(ptr %s2, { i64, ptr } %t344)
  store i64 %t346, ptr %l114
  br label %bb45
bb45:
  %t347 = load i64, ptr %l114, !tbaa !24
  store i64 %t347, ptr %l18, !tbaa !24
  %t348 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 0
  %t349 = load i32, ptr %t348, !tbaa !23
  %t351 = icmp sgt i32 %t349, 1
  br i1 %t351, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb48
bb47:
  %t353 = load i64, ptr %l18, !tbaa !24
  %t355 = icmp sgt i64 %t353, 0
  store i1 %t355, ptr %l117, !tbaa !21
  br label %bb48
bb48:
  %t357 = load i1, ptr %l117, !tbaa !21
  br i1 %t357, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s6
  %t358 = load ptr, ptr %l5, !tbaa !29
  %t359 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t360 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t359, 1
  %t363 = extractvalue { i64, ptr } %t359, 0
  %t364 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t366 = add i64 %t363, %t365
  %t368 = extractvalue { i64, ptr } %t360, 1
  %t369 = extractvalue { i64, ptr } %t360, 0
  %t370 = add i64 %t366, %t369
  %t371 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t370)
  call void @olang_textcopy(ptr %t371, ptr %t362, i64 %t363)
  %t372 = getelementptr i8, ptr %t371, i64 %t363
  call void @olang_textcopy(ptr %t372, ptr %t364, i64 %t365)
  %t373 = getelementptr i8, ptr %t372, i64 %t365
  call void @olang_textcopy(ptr %t373, ptr %t368, i64 %t369)
  %t374 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t371, 1
  %t378 = extractvalue { i64, ptr } %t375, 0
  %t379 = extractvalue { i64, ptr } %t375, 1
  %t380 = mul i64 %t378, 1
  %t381 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t380)
  call void @llvm.memcpy.p0.p0.i64(ptr %t381, ptr %t379, i64 %t380, i1 false)
  %t382 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t381, 1
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s6, ptr %t358, { i64, ptr } %t383)
  br label %bb51
bb50:
  br label %bb57
bb51:
  %t386 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s2, ptr %s6, { i64, ptr } %t386, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i1 %t388, ptr %l127
  br label %bb52
bb52:
  %t389 = load i1, ptr %l127, !tbaa !21
  %t390 = xor i1 %t389, true
  br i1 %t390, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s8
  %t392 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d138, i32 0, i32 1) }, ptr %l130, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l130, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v4, ptr %s8, ptr %t392, { i64, ptr } %t394)
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb57:
  %t395 = getelementptr %"std/os:Output", ptr %l16, i32 0, i32 0
  %t396 = load i32, ptr %t395, !tbaa !23
  %t398 = icmp sgt i32 %t396, 1
  br i1 %t398, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t401 = load i64, ptr %l7, !tbaa !24
  %t403 = load i64, ptr %l18, !tbaa !24
  %t406 = add i64 %t401, %t403
  store i64 %t406, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t408 = load i64, ptr %l12, !tbaa !24
  %t411 = add i64 %t408, 1
  store i64 %t411, ptr %l12, !tbaa !24
  br label %bb7
bb62:
  %t413 = load i64, ptr %l7, !tbaa !24
  store i64 %t413, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffix_2estdKey(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca [2 x { i64, ptr }]
  %l3 = alloca [2 x { i64, ptr }]
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca [2 x { i64, ptr }]
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l31 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l60 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i32
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l16, !tbaa !27
  %t4 = call ptr @__olang_scope_hold(ptr %s1)
  %t5 = ptrtoint ptr %t4 to i64
  store i64 %t5, ptr %l17, !tbaa !24
  %t6 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_203_3e_2e_2d1
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = call ptr @__olang_region_make(ptr %s1)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l17, !tbaa !24
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t10, 0
  %t13 = insertvalue [2 x { i64, ptr }] %t12, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t13, ptr %l2
  %t16 = insertvalue { i64, ptr } undef, i64 2, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %l2, 1
  %t18 = load i64, ptr %l17
  %t19 = inttoptr i64 %t18 to ptr
  %t21 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s1, ptr %t19, { i64, ptr } %t17)
  store { i64, ptr } %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t23 = load i64, ptr %l17
  %t24 = inttoptr i64 %t23 to ptr
  %t25 = extractvalue { i64, ptr } %t22, 0
  %t26 = extractvalue { i64, ptr } %t22, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_held_alloc(ptr %t24, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l24, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %s1)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_203_3e_2e_2d1
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = call ptr @__olang_region_make(ptr %s1)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t37, 0
  %t40 = insertvalue [2 x { i64, ptr }] %t39, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t40, ptr %l3
  %t43 = insertvalue { i64, ptr } undef, i64 2, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %l3, 1
  %t45 = load i64, ptr %l25
  %t46 = inttoptr i64 %t45 to ptr
  %t48 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s1, ptr %t46, { i64, ptr } %t44)
  store { i64, ptr } %t48, ptr %l31
  br label %bb7
bb7:
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t50 = load i64, ptr %l25
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = extractvalue { i64, ptr } %t49, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_held_alloc(ptr %t51, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t59 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t58, 0
  %t60 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t61 = insertvalue [3 x { i64, ptr }] %t59, { i64, ptr } %t60, 1
  %t63 = insertvalue [3 x { i64, ptr }] %t61, { i64, ptr } %t57, 2
  %t65 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 48, i64 8)
  store [3 x { i64, ptr }] %t63, ptr %t65
  store ptr %t65, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t67 = load ptr, ptr %l4
  store i64 3, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t78 = load ptr, ptr %l4
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = getelementptr [3 x { i64, ptr }], ptr %t78, i64 0, i64 %t79
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !37
  store { i64, ptr } %t83, ptr %l7, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s1, ptr %s2, { i64, ptr } %t85)
  %t88 = extractvalue { i32, { i64, ptr } } %t87, 1
  %t89 = extractvalue { i32, { i64, ptr } } %t87, 0
  store i32 %t89, ptr %l47
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb13, label %ok.91, !prof !99
ok.91:
  store { i64, ptr } %t88, ptr %l46
  br label %bb12
bb12:
  %t92 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t92, ptr %l44, !tbaa !27
  br label %bb21
bb13:
  %t93 = load i32, ptr %l47, !tbaa !23
  %t94 = ashr i32 %t93, 16
  %t96 = icmp eq i32 %t94, 1
  br i1 %t96, label %bb14, label %bb15
bb14:
  call void @__olang_errpay_pop()
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t98 = icmp sge i64 0, 0
  br i1 %t98, label %bb17, label %bb18
bb17:
  %t100 = icmp sle i64 0, 576460752303423487
  br i1 %t100, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e9114cb26b1b823b_db9b8e7e24054f2f)
  unreachable
bb19:
  %t102 = mul i64 0, 16
  %t103 = insertvalue { i64, ptr } undef, i64 0, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t104, ptr %l44, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e9114cb26b1b823b_db9b8e7e24054f2f)
  unreachable
bb21:
  %t106 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t106, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb24:
  br label %bb25
bb25:
  %t121 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t121, ptr %l60, !tbaa !27
  %t122 = load i64, ptr %l10, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %t125, i64 %t122
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !37
  %t129 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t132 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t129, 0
  %t134 = insertvalue [2 x { i64, ptr }] %t132, { i64, ptr } %t127, 1
  store [2 x { i64, ptr }] %t134, ptr %l13
  %t137 = insertvalue { i64, ptr } undef, i64 2, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %l13, 1
  %t140 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s4, ptr %s0, { i64, ptr } %t138)
  store { i64, ptr } %t140, ptr %l68
  br label %bb26
bb26:
  %t141 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t141, ptr %l14, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t144 = call i1 @std_2fos_2eIsDir(ptr %s0, { i64, ptr } %t142)
  store i1 %t144, ptr %l70
  br label %bb27
bb27:
  %t145 = load i1, ptr %l70, !tbaa !21
  br i1 %t145, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb29:
  br label %bb30
bb30:
  %t146 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t146)
  br label %bb31
bb31:
  store ptr %l1, ptr %l73, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t151 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t149)
  %t152 = extractvalue { i32, { i64, ptr } } %t151, 1
  %t153 = extractvalue { i32, { i64, ptr } } %t151, 0
  store i32 %t153, ptr %l77
  %t154 = icmp ne i32 %t153, 0
  br i1 %t154, label %bb33, label %ok.155, !prof !99
ok.155:
  store { i64, ptr } %t152, ptr %l76
  br label %bb32
bb32:
  %t156 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t156, ptr %l74, !tbaa !27
  br label %bb37
bb33:
  %t157 = load i32, ptr %l77, !tbaa !23
  %t158 = ashr i32 %t157, 16
  %t160 = icmp eq i32 %t158, 1
  br i1 %t160, label %bb34, label %bb35
bb34:
  call void @__olang_errpay_pop()
  br label %bb35
bb35:
  br label %bb36
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l74, !tbaa !27
  br label %bb37
bb37:
  %t162 = load ptr, ptr %l73, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l74, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t162, { i64, ptr } %t163)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  %t164 = load i64, ptr %l10, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l10, !tbaa !24
  br label %bb22
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t169 = load i64, ptr %l5, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l5, !tbaa !24
  br label %bb8
bb42:
  call void @__olang_scope_close(ptr %s1)
  %t175 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t175, ptr %l87
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t176, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffix_2etextsOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store ptr %l1, ptr %l17, !tbaa !29
  %t27 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %t23)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l21
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb7, label %ok.31, !prof !99
ok.31:
  store { i64, ptr } %t28, ptr %l20
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  br label %bb11
bb7:
  %t33 = load i32, ptr %l21, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l17, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t38, { i64, ptr } %t39)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffix_2etriggered(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l36 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb6
bb6:
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb7, label %bb8
bb7:
  br label %bb23
bb8:
  br label %bb9
bb9:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t18, i64 %t19)
  store { i64, ptr } %t22, ptr %l20
  br label %bb10
bb10:
  %t23 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s4
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t24, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) })
  store { i64, ptr } %t26, ptr %l22
  br label %bb11
bb11:
  %t27 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l29, !tbaa !27
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %t44, i64 %t41
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !37
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t54 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t48, { i64, ptr } %t46)
  store i1 %t54, ptr %l36
  br label %bb16
bb16:
  %t55 = load i1, ptr %l36, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = add i64 %t57, 1
  store i64 %t60, ptr %l6, !tbaa !24
  br label %bb12
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t62, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb5
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffix_2etrimBin(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %s0 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l16, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2eTouch(ptr %v1, { i64, ptr } %t25)
  br label %bb6
bb6:
  store ptr %l2, ptr %l20, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %v1, { i64, ptr } %t27)
  store { i64, ptr } %t29, ptr %l22
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %v1, ptr %t30, { i64, ptr } %t31, i1 true)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb2
bb10:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %s0, { i64, ptr } %t37, i64 0, i1 true)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l27
  br label %bb11
bb11:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l7
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t41, ptr %l28, !tbaa !27
  store ptr %l7, ptr %l29, !tbaa !29
  store ptr %l2, ptr %l30, !tbaa !29
  %t42 = call i64 @compiler_2fbuild_2eRecent()
  store i64 %t42, ptr %l31
  br label %bb12
bb12:
  %t43 = load i64, ptr @G_2ecompiler_2ffix_2eFixCacheCap, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t45 = load ptr, ptr %l29, !tbaa !29
  %t46 = load ptr, ptr %l30, !tbaa !29
  %t47 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fbuild_2eTrim(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t44, ptr %t45, ptr %t46, i64 %t47, i64 %t43)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffix_2everdict(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l47 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l5, { i64, ptr } %a3)
  br label %bb2
bb2:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v4, ptr %l5, { i64, ptr } %a4)
  br label %bb3
bb3:
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l15
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l6
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2ffix_2eclosure(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t11, ptr %l6, ptr %l5)
  br label %bb5
bb5:
  store { i64, ptr } %a2, ptr %l19, !tbaa !27
  %t16 = call ptr @__olang_scope_hold(ptr %s0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = call ptr @__olang_region_make(ptr %s0)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t23 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t23, ptr %l23
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l24, !tbaa !24
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = icmp sle i64 0, 16
  br i1 %t28, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_185b32af6c165790_8de4f2366fa38afc)
  unreachable
bb11:
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = icmp sle i64 16, %t30
  br i1 %t31, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_185b32af6c165790_8de4f2366fa38afc)
  unreachable
bb13:
  %t33 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i8, ptr %t34, i64 0
  %t36 = sub i64 16, 0
  %t37 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t35, 1
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t42 = extractvalue { i64, ptr } %t38, 1
  %t43 = extractvalue { i64, ptr } %t38, 0
  %t44 = add i64 %t40, %t43
  %t45 = load i64, ptr %l20
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call ptr @__olang_held_alloc(ptr %t46, i64 %t44)
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  %t52 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t53 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t52, 0
  %t55 = insertvalue [2 x { i64, ptr }] %t53, { i64, ptr } %t50, 1
  store [2 x { i64, ptr }] %t55, ptr %l7
  %t58 = insertvalue { i64, ptr } undef, i64 2, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %l7, 1
  %t61 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t59)
  store { i64, ptr } %t61, ptr %l34
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_185b32af6c165790_8de4f2366fa38afc)
  unreachable
bb15:
  %t62 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t62, ptr %l8, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t65 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t63)
  store i1 %t65, ptr %l36
  br label %bb16
bb16:
  %t66 = load i1, ptr %l36, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fbuild_2eTouch(ptr %s0, { i64, ptr } %t67)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb20:
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t74 = call i1 @compiler_2ffix_2ecompiles(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %t71)
  store i1 %t74, ptr %l41
  br label %bb21
bb21:
  %t75 = load i1, ptr %l41, !tbaa !21
  store i1 %t75, ptr %l9, !tbaa !21
  %t76 = load i1, ptr %l9, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d146, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t81 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s3, { i64, ptr } %t78, { i64, ptr } %t80)
  store i32 %t81, ptr %l45
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb25, label %ok.83, !prof !99
ok.83:
  br label %bb24
bb23:
  br label %bb30
bb24:
  br label %bb29
bb25:
  %t84 = load i32, ptr %l45, !tbaa !23
  %t85 = ashr i32 %t84, 16
  %t87 = icmp eq i32 %t85, 1
  store i1 %t87, ptr %l47, !tbaa !21
  %t88 = load i32, ptr %l45, !tbaa !23
  %t89 = ashr i32 %t88, 16
  %t91 = icmp eq i32 %t89, 1
  br i1 %t91, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t93 = load i1, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffix_2ewalk(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca [2 x { i64, ptr }]
  %l3 = alloca { i64, ptr }
  %l4 = alloca [2 x { i64, ptr }]
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %lp11 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l73 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t1, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t4, ptr %l2
  %t7 = insertvalue { i64, ptr } undef, i64 2, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %l2, 1
  %t10 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t8)
  store { i64, ptr } %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t19 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t17)
  store i1 %t19, ptr %l18
  br label %bb2
bb2:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t21)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l22
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb7, label %ok.27, !prof !99
ok.27:
  store { i64, ptr } %t24, ptr %l21
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  br label %bb15
bb7:
  %t29 = load i32, ptr %l22, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  br i1 %t32, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = icmp sle i64 0, 576460752303423487
  br i1 %t36, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb13:
  %t38 = mul i64 0, 16
  %t39 = insertvalue { i64, ptr } undef, i64 0, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t40, ptr %l19, !tbaa !27
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9433da86f750b978_3ff5b65d50af9d4)
  unreachable
bb15:
  %t42 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t45 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t43, 0
  %t46 = insertvalue [2 x { i64, ptr }] %t45, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t46, ptr %l4
  %t49 = insertvalue { i64, ptr } undef, i64 2, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %l4, 1
  %t52 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t50)
  store { i64, ptr } %t52, ptr %l33
  br label %bb16
bb16:
  %t53 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t59)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l36
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb18, label %ok.65, !prof !99
ok.65:
  store { i64, ptr } %t62, ptr %l35
  br label %bb17
bb17:
  %t66 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t66, ptr %l28, !tbaa !27
  br label %bb22
bb18:
  %t67 = load i32, ptr %l36, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb19, label %bb20
bb19:
  call void @__olang_errpay_pop()
  br label %bb20
bb20:
  br label %bb21
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb22
bb22:
  %t72 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t72, ptr %l5, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t73, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb25:
  br label %bb26
bb26:
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l46, !tbaa !27
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %t91, i64 %t88
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  store { i64, ptr } %t93, ptr %l9, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t95, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) })
  store i1 %t97, ptr %l50
  br label %bb27
bb27:
  %t98 = load i1, ptr %l50, !tbaa !21
  br i1 %t98, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb31
bb29:
  %t99 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s3, { i64, ptr } %t99, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i1 %t101, ptr %l53
  br label %bb30
bb30:
  %t102 = load i1, ptr %l53, !tbaa !21
  store i1 %t102, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l51, !tbaa !21
  br i1 %t103, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb33:
  br label %bb34
bb34:
  %t104 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t107 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t104, 0
  %t109 = insertvalue [2 x { i64, ptr }] %t107, { i64, ptr } %t105, 1
  store [2 x { i64, ptr }] %t109, ptr %l10
  %t112 = insertvalue { i64, ptr } undef, i64 2, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %l10, 1
  %t115 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s3, ptr %v1, { i64, ptr } %t113)
  store { i64, ptr } %t115, ptr %l59
  br label %bb35
bb35:
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t116, ptr %lp11
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t118 = load ptr, ptr %lp11
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  %t119 = load ptr, ptr %lp11
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t122 = call i1 @std_2fos_2eIsDir(ptr %v1, { i64, ptr } %t120)
  store i1 %t122, ptr %l61
  br label %bb36
bb36:
  %t123 = load i1, ptr %l61, !tbaa !21
  br i1 %t123, label %bb37, label %bb38
bb37:
  %t124 = load ptr, ptr %lp11
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t126 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffix_2ewalk(ptr %v1, ptr %v1, { i64, ptr } %t125, ptr %t126)
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s6, { i64, ptr } %t129, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t131, ptr %l65
  br label %bb40
bb39:
  br label %bb53
bb40:
  %t132 = load i1, ptr %l65, !tbaa !21
  br i1 %t132, label %bb41, label %bb42
bb41:
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = call i1 @compiler_2ffix_2emigrationTool(ptr %s0, ptr %s0, { i64, ptr } %t133, { i64, ptr } %t134)
  store i1 %t137, ptr %l69
  br label %bb43
bb42:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb44
bb43:
  %t138 = load i1, ptr %l69, !tbaa !21
  %t139 = xor i1 %t138, true
  store i1 %t139, ptr %l66, !tbaa !21
  br label %bb44
bb44:
  %t141 = load i1, ptr %l66, !tbaa !21
  br i1 %t141, label %bb45, label %bb46
bb45:
  %t142 = load ptr, ptr %lp11
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t145 = call i1 @compiler_2ffix_2emustFail(ptr %v1, { i64, ptr } %t143)
  store i1 %t145, ptr %l73
  br label %bb47
bb46:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb48
bb47:
  %t146 = load i1, ptr %l73, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l71, !tbaa !21
  br label %bb48
bb48:
  %t149 = load i1, ptr %l71, !tbaa !21
  br i1 %t149, label %bb49, label %bb50
bb49:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t151 = load ptr, ptr %lp11
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t150, { i64, ptr } %t152)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb54:
  %t155 = load i64, ptr %l7, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l7, !tbaa !24
  br label %bb23
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2etable_2eI32_7cstd_2fio_3aDescriptor = linkonce_odr constant [4 x ptr] [ptr @olang_2etypeid_2eI32, ptr @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0]
declare void @__olang_errpay_pop()
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d2 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be read\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d4 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d5 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"driven" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d12 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TOOLS" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"tools" }>, align 8
@.d16 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/../tools" }>, align 8
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"--std" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"--olang" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare ptr @__olang_standin_in(ptr, ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task20(ptr %env) #0 {
entry:
  %f0 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %f8 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 8
  %f9 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 9
  %f10 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 10
  %f11 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 11
  %f12 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 12
  %f13 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 13
  %sc0 = load ptr, ptr %f7
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f8
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f9
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f10
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %sc4 = load ptr, ptr %f11
  %sn4 = icmp eq ptr %sc4, null
  %sg4 = load ptr, ptr @__olang_prog_scope
  %ss4 = select i1 %sn4, ptr %sg4, ptr %sc4
  %sc5 = load ptr, ptr %f12
  %sn5 = icmp eq ptr %sc5, null
  %sg5 = load ptr, ptr @__olang_prog_scope
  %ss5 = select i1 %sn5, ptr %sg5, ptr %sc5
  %sc6 = load ptr, ptr %f13
  %sn6 = icmp eq ptr %sc6, null
  %sg6 = load ptr, ptr @__olang_prog_scope
  %ss6 = select i1 %sn6, ptr %sg6, ptr %sc6
  %a0 = load { i64, ptr }, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load ptr, ptr %f3
  %a4 = load { i64, ptr }, ptr %f4
  %a5 = load { i64, ptr }, ptr %f5
  %a6 = load { i64, ptr }, ptr %f6
  call void @compiler_2ffix_2ebuilder(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %ss4, ptr %ss5, ptr %ss6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6)
  ret ptr null
}

declare i64 @__olang_join_tasks_keep(ptr, i1)
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare ptr @__olang_errpay_top_get()
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d23 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"cannot build tools/" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d24 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".olang: " }>, align 8
declare void @__olang_sb_done(ptr)
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 1}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d26 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_rd_quote(ptr, i64, ptr, i64, i8)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d29 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d30 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d31 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d32 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d33 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d34 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
declare void @__olang_errpay_set(ptr) cold
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_205_3e_2e_2d1 = weak hidden constant i1 false
@.d36 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"cannot run " }>, align 8
@.d41 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d43 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d46 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d47 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d48 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d49 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d50 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d51 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools/" }>, align 8
@.d53 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c".olang does not build:\0A" }>, align 8
@.d54 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"cannot put tools_" }>, align 8
@.d55 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" in place: " }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d57 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d60 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d61 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d62 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d63 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d64 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d65 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d66 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d69 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"by hand:" }>, align 8
@.d70 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"for a person:" }>, align 8
@.d71 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d76 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d77 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d78 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@.d79 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"olang-fix." }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_206_3e_2e_2d1 = weak hidden constant i1 false
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"m.o" }>, align 8
@.d83 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d84 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-quick" }>, align 8
@.d85 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
define internal ptr @olang_task86(ptr %env) #0 {
entry:
  %f0 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %f8 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 8
  %f9 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 9
  %f10 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 10
  %f11 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 11
  %f12 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 12
  %f13 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 13
  %sc0 = load ptr, ptr %f7
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f8
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f9
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f10
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %sc4 = load ptr, ptr %f11
  %sn4 = icmp eq ptr %sc4, null
  %sg4 = load ptr, ptr @__olang_prog_scope
  %ss4 = select i1 %sn4, ptr %sg4, ptr %sc4
  %sc5 = load ptr, ptr %f12
  %sn5 = icmp eq ptr %sc5, null
  %sg5 = load ptr, ptr @__olang_prog_scope
  %ss5 = select i1 %sn5, ptr %sg5, ptr %sc5
  %sc6 = load ptr, ptr %f13
  %sn6 = icmp eq ptr %sc6, null
  %sg6 = load ptr, ptr @__olang_prog_scope
  %ss6 = select i1 %sn6, ptr %sg6, ptr %sc6
  %a0 = load { i64, ptr }, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  %a4 = load { i64, ptr }, ptr %f4
  %a5 = load { i64, ptr }, ptr %f5
  %a6 = load { i64, ptr }, ptr %f6
  call void @compiler_2ffix_2echecker(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %ss4, ptr %ss5, ptr %ss6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6)
  ret ptr null
}

@.d87 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tools_" }>, align 8
@.d88 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"| `" }>, align 8
@.d89 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"` |" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"`" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"# check: fail" }>, align 8
@.d94 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang: fix: no tools directory at " }>, align 8
@.d95 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" (OLANG_TOOLS names another)\0A" }>, align 8
@.d96 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"olang: fix: cannot make " }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d98 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TIMES" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d102 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
@.d103 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d104 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" tools wanted, built in " }>, align 8
@.d105 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
@.d106 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
@.d107 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d108 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" files the compiler reports an error in\0A" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bcompiler_2ffix_3aNotBuilt_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffix_3aNotBuilt_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d111 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d112 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"olang: fix: " }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d114 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d116 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d119 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang fix: " }>, align 8
@.d120 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d121 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c" above may mean something else in the language of today than when written - look at each\0A" }>, align 8
@.d122 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d123 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang: fix: cannot run " }>, align 8
@.d124 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d126 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d127 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d130 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d131 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d132 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d133 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d134 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d135 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d136 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d138 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_203_3e_2e_2d1 = weak hidden constant i1 false
@.d139 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d140 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"runtime" }>, align 8
@.d141 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d142 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d143 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d145 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"compiles-" }>, align 8
@.d146 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d147 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c".olangfix" }>, align 8
@.d148 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"README.md" }>, align 8
@.d149 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d151 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d152 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_2etypeid_2eI32 = linkonce_odr constant i8 0
define linkonce_odr void @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t6 = call i64 @__olang_fmt_i64(ptr %t5, i64 %t4)
  call void @__olang_sb_add(ptr %v0, i64 %t6)
  br label %ret
ret:
  ret void
}

define linkonce_odr void @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t3 = sext i32 %t2 to i64
  %t4 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %v0, i64 %t5)
  br label %ret
ret:
  ret void
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 7}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
bb4:
  %t44 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, ptr } }, ptr %t61, i32 0, i32 0
  store { i64, ptr } %t60, ptr %t62
  br label %bb1
bb5:
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { { i64, ptr } }, ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81
  br label %bb1
bb6:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l17, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, ptr } }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100
  br label %bb1
bb7:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l18, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l19, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l20, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, ptr } }, ptr %t118, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t119
  br label %bb1
bb8:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { { i64, ptr } }, ptr %t120, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l21, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l22, !tbaa !24
  %t125 = load i64, ptr %l22, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l23, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l22, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t137 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t138
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2estd_2fio_2eStderr = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"std/io:Writer" @std_2fio_3aWriter_2ector(ptr %v0, ptr %v1, { ptr, ptr } %a0, i64 %a1)
@G_2estd_2fio_2eStdout = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2estd_2fio_3aWriter_2eFlush(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2ffix_2eToolNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2ffix_2eToolKinds = available_externally constant <{ [368 x i8] }> <{ [368 x i8] c"\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
declare i1 @compiler_2ffix_2edriven(i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_cce2230832d6a50c_2dcd918d424b1980 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2ffix_2eStdTool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenOpt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffix_2eDrivenArg = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_f01e9d7c18290f7e_330799ec5065ffa2 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
@olang_loc_5136839c006764b3_5260dfbee4468c57 = external constant [0 x i8]
@G_2ecompiler_2ffix_2eBuildWidth = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_233d982910cd3e61_6bc76ac40e1a9c3d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hb38d151ad2865ce380f5e3d42761bdf3(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v0, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d81bb51d20d074b4_82b493c82ed1c1e0 = external constant [0 x i8]
@olang_loc_40dc5ad5899010ef_fc275eeb26e8323 = external constant [0 x i8]
@olang_loc_20258a28ab60401a_640e38b19bcc26ae = external constant [0 x i8]
@G_2ecompiler_2ffix_2eCheckWidth = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_565177cd6d363dc5_57077917db9ab2b9 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_aba33d98e166d1e8_68a02edac36c0e8c = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2ftime_2eNow()
@olang_loc_7ff6490bc64d8e4c_ced9be9374cda200 = external constant [0 x i8]
@G_2ecompiler_2ffix_2eToolTriggers = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2ffix_2eBatch = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\C8\00\00\00\00\00\00\00" }>, align 8
@olang_loc_4ea6f09d5973466a_f399989f0872f916 = external constant [0 x i8]
@olang_loc_e9114cb26b1b823b_db9b8e7e24054f2f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fbuild_2eTouch(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2eHoldings(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2fbuild_2eRecent()
@G_2ecompiler_2ffix_2eFixCacheCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\08\00\00\00\00" }>, align 8
declare void @compiler_2fbuild_2eTrim(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
@olang_loc_185b32af6c165790_8de4f2366fa38afc = external constant [0 x i8]
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = external constant [0 x i8]
declare i32 @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2ffix_2ebuilder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare void @compiler_2ffix_2echecker(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
