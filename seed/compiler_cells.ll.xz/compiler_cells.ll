; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/cells:Worker" = type { i1, i32, i32, i32, i32, i32, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/cells:Outcome" = type { i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
@G_2ecompiler_2fcells_2eBuilder = global <{ [16 x i8] }> <{ [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eCellsCacheCap = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\20\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameData = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameDone = constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameFailure = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameMime = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFramePid = constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameShown = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eFrameStopped = constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eHelperIr = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\CF\08\00\00\00\00\00\00", ptr @G_2ecompiler_2fcells_2eHelperIr.k1 }>, align 8
@G_2ecompiler_2fcells_2eHelperIr.k1 = internal constant <{ [2255 x i8] }> <{ [2255 x i8] c"\40\73\74\64\6F\75\74\20\3D\20\65\78\74\65\72\6E\61\6C\20\67\6C\6F\62\61\6C\20\70\74\72\0A\40\5F\5F\6F\6C\61\6E\67\5F\6A\6D\70\5F\74\61\72\67\65\74\20\3D\20\65\78\74\65\72\6E\61\6C\20\74\68\72\65\61\64\5F\6C\6F\63\61\6C\28\69\6E\69\74\69\61\6C\65\78\65\63\29\20\67\6C\6F\62\61\6C\20\70\74\72\0A\40\5F\5F\6F\6C\61\6E\67\5F\75\6E\77\69\6E\64\5F\74\6F\70\20\3D\20\65\78\74\65\72\6E\61\6C\20\74\68\72\65\61\64\5F\6C\6F\63\61\6C\28\69\6E\69\74\69\61\6C\65\78\65\63\29\20\67\6C\6F\62\61\6C\20\70\74\72\0A\40\5F\5F\6F\6C\61\6E\67\5F\75\6E\77\69\6E\64\5F\6D\61\72\6B\20\3D\20\65\78\74\65\72\6E\61\6C\20\74\68\72\65\61\64\5F\6C\6F\63\61\6C\28\69\6E\69\74\69\61\6C\65\78\65\63\29\20\67\6C\6F\62\61\6C\20\70\74\72\0A\40\5F\5F\6F\6C\61\6E\67\5F\77\6F\72\6B\65\72\5F\66\72\65\65\20\3D\20\65\78\74\65\72\6E\61\6C\20\67\6C\6F\62\61\6C\20\70\74\72\0A\40\5F\5F\6F\6C\61\6E\67\5F\77\6F\72\6B\65\72\5F\69\64\6C\65\20\3D\20\65\78\74\65\72\6E\61\6C\20\67\6C\6F\62\61\6C\20\69\36\34\0A\40\6F\6C\61\6E\67\2E\63\65\6C\6C\2E\77\20\3D\20\70\72\69\76\61\74\65\20\75\6E\6E\61\6D\65\64\5F\61\64\64\72\20\63\6F\6E\73\74\61\6E\74\20\5B\32\20\78\20\69\38\5D\20\63\22\77\5C\30\30\22\0A\64\65\63\6C\61\72\65\20\69\33\32\20\40\73\65\74\6A\6D\70\28\70\74\72\29\20\72\65\74\75\72\6E\73\5F\74\77\69\63\65\0A\64\65\63\6C\61\72\65\20\70\74\72\20\40\66\64\6F\70\65\6E\28\69\33\32\2C\20\70\74\72\29\0A\64\65\63\6C\61\72\65\20\69\33\32\20\40\66\63\6C\6F\73\65\28\70\74\72\29\0A\0A\64\65\66\69\6E\65\20\69\33\32\20\40\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\63\61\6C\6C\28\70\74\72\20\25\73\74\61\72\74\2C\20\70\74\72\20\25\72\75\6E\2C\20\69\33\32\20\25\66\64\29\20\7B\0A\65\6E\74\72\79\3A\0A\20\20\25\6A\62\20\3D\20\61\6C\6C\6F\63\61\20\5B\31\30\32\34\20\78\20\69\38\5D\2C\20\61\6C\69\67\6E\20\31\36\0A\20\20\25\66\20\3D\20\63\61\6C\6C\20\70\74\72\20\40\66\64\6F\70\65\6E\28\69\33\32\20\25\66\64\2C\20\70\74\72\20\40\6F\6C\61\6E\67\2E\63\65\6C\6C\2E\77\29\0A\20\20\25\6F\6C\64\20\3D\20\6C\6F\61\64\20\70\74\72\2C\20\70\74\72\20\40\73\74\64\6F\75\74\0A\20\20\25\73\6F\6D\65\20\3D\20\69\63\6D\70\20\6E\65\20\70\74\72\20\25\66\2C\20\6E\75\6C\6C\0A\20\20\62\72\20\69\31\20\25\73\6F\6D\65\2C\20\6C\61\62\65\6C\20\25\73\77\61\70\2C\20\6C\61\62\65\6C\20\25\67\75\61\72\64\0A\73\77\61\70\3A\0A\20\20\73\74\6F\72\65\20\70\74\72\20\25\66\2C\20\70\74\72\20\40\73\74\64\6F\75\74\0A\20\20\62\72\20\6C\61\62\65\6C\20\25\67\75\61\72\64\0A\67\75\61\72\64\3A\0A\20\20\25\74\6F\70\20\3D\20\6C\6F\61\64\20\70\74\72\2C\20\70\74\72\20\40\5F\5F\6F\6C\61\6E\67\5F\75\6E\77\69\6E\64\5F\74\6F\70\0A\20\20\73\74\6F\72\65\20\70\74\72\20\25\74\6F\70\2C\20\70\74\72\20\40\5F\5F\6F\6C\61\6E\67\5F\75\6E\77\69\6E\64\5F\6D\61\72\6B\0A\20\20\73\74\6F\72\65\20\70\74\72\20\25\6A\62\2C\20\70\74\72\20\40\5F\5F\6F\6C\61\6E\67\5F\6A\6D\70\5F\74\61\72\67\65\74\0A\20\20\25\72\20\3D\20\63\61\6C\6C\20\69\33\32\20\40\73\65\74\6A\6D\70\28\70\74\72\20\25\6A\62\29\0A\20\20\25\66\69\72\73\74\20\3D\20\69\63\6D\70\20\65\71\20\69\33\32\20\25\72\2C\20\30\0A\20\20\62\72\20\69\31\20\25\66\69\72\73\74\2C\20\6C\61\62\65\6C\20\25\67\6F\2C\20\6C\61\62\65\6C\20\25\64\6F\6E\65\0A\67\6F\3A\0A\20\20\63\61\6C\6C\20\76\6F\69\64\20\25\73\74\61\72\74\28\29\0A\20\20\63\61\6C\6C\20\76\6F\69\64\20\25\72\75\6E\28\29\0A\20\20\62\72\20\6C\61\62\65\6C\20\25\64\6F\6E\65\0A\64\6F\6E\65\3A\0A\20\20\25\72\63\20\3D\20\70\68\69\20\69\33\32\20\5B\20\30\2C\20\25\67\6F\20\5D\2C\20\5B\20\25\72\2C\20\25\67\75\61\72\64\20\5D\0A\20\20\73\74\6F\72\65\20\70\74\72\20\6E\75\6C\6C\2C\20\70\74\72\20\40\5F\5F\6F\6C\61\6E\67\5F\6A\6D\70\5F\74\61\72\67\65\74\0A\20\20\73\74\6F\72\65\20\70\74\72\20\25\6F\6C\64\2C\20\70\74\72\20\40\73\74\64\6F\75\74\0A\20\20\62\72\20\69\31\20\25\73\6F\6D\65\2C\20\6C\61\62\65\6C\20\25\63\6C\6F\73\65\2C\20\6C\61\62\65\6C\20\25\6F\75\74\0A\63\6C\6F\73\65\3A\0A\20\20\63\61\6C\6C\20\69\33\32\20\40\66\63\6C\6F\73\65\28\70\74\72\20\25\66\29\0A\20\20\62\72\20\6C\61\62\65\6C\20\25\6F\75\74\0A\6F\75\74\3A\0A\20\20\72\65\74\20\69\33\32\20\25\72\63\0A\7D\0A\0A\64\65\66\69\6E\65\20\76\6F\69\64\20\40\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\61\66\74\65\72\66\6F\72\6B\28\29\20\7B\0A\65\6E\74\72\79\3A\0A\20\20\73\74\6F\72\65\20\70\74\72\20\6E\75\6C\6C\2C\20\70\74\72\20\40\5F\5F\6F\6C\61\6E\67\5F\77\6F\72\6B\65\72\5F\66\72\65\65\0A\20\20\73\74\6F\72\65\20\69\36\34\20\30\2C\20\70\74\72\20\40\5F\5F\6F\6C\61\6E\67\5F\77\6F\72\6B\65\72\5F\69\64\6C\65\0A\20\20\72\65\74\20\76\6F\69\64\0A\7D\0A\0A\64\65\66\69\6E\65\20\76\6F\69\64\20\40\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\73\61\79\28\69\36\34\20\25\6B\69\6E\64\2C\20\70\74\72\20\25\64\61\74\61\2C\20\69\36\34\20\25\6E\29\20\7B\0A\65\6E\74\72\79\3A\0A\20\20\25\68\20\3D\20\61\6C\6C\6F\63\61\20\5B\32\20\78\20\69\36\34\5D\2C\20\61\6C\69\67\6E\20\38\0A\20\20\73\74\6F\72\65\20\69\36\34\20\25\6B\69\6E\64\2C\20\70\74\72\20\25\68\0A\20\20\25\68\6E\20\3D\20\67\65\74\65\6C\65\6D\65\6E\74\70\74\72\20\5B\32\20\78\20\69\36\34\5D\2C\20\70\74\72\20\25\68\2C\20\69\36\34\20\30\2C\20\69\36\34\20\31\0A\20\20\73\74\6F\72\65\20\69\36\34\20\25\6E\2C\20\70\74\72\20\25\68\6E\0A\20\20\63\61\6C\6C\20\76\6F\69\64\20\40\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\61\6C\6C\28\70\74\72\20\25\68\2C\20\69\36\34\20\31\36\29\0A\20\20\63\61\6C\6C\20\76\6F\69\64\20\40\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\61\6C\6C\28\70\74\72\20\25\64\61\74\61\2C\20\69\36\34\20\25\6E\29\0A\20\20\72\65\74\20\76\6F\69\64\0A\7D\0A\0A\64\65\63\6C\61\72\65\20\69\36\34\20\40\77\72\69\74\65\28\69\33\32\2C\20\70\74\72\2C\20\69\36\34\29\0A\0A\64\65\66\69\6E\65\20\76\6F\69\64\20\40\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\61\6C\6C\28\70\74\72\20\25\70\2C\20\69\36\34\20\25\6E\29\20\7B\0A\65\6E\74\72\79\3A\0A\20\20\62\72\20\6C\61\62\65\6C\20\25\6C\6F\6F\70\0A\6C\6F\6F\70\3A\0A\20\20\25\61\74\20\3D\20\70\68\69\20\69\36\34\20\5B\20\30\2C\20\25\65\6E\74\72\79\20\5D\2C\20\5B\20\25\6E\65\78\74\2C\20\25\6D\6F\72\65\20\5D\0A\20\20\25\6C\65\66\74\20\3D\20\73\75\62\20\69\36\34\20\25\6E\2C\20\25\61\74\0A\20\20\25\74\6F\64\6F\20\3D\20\69\63\6D\70\20\73\67\74\20\69\36\34\20\25\6C\65\66\74\2C\20\30\0A\20\20\62\72\20\69\31\20\25\74\6F\64\6F\2C\20\6C\61\62\65\6C\20\25\77\72\69\74\65\2C\20\6C\61\62\65\6C\20\25\6F\75\74\0A\77\72\69\74\65\3A\0A\20\20\25\71\20\3D\20\67\65\74\65\6C\65\6D\65\6E\74\70\74\72\20\69\38\2C\20\70\74\72\20\25\70\2C\20\69\36\34\20\25\61\74\0A\20\20\25\77\20\3D\20\63\61\6C\6C\20\69\36\34\20\40\77\72\69\74\65\28\69\33\32\20\34\2C\20\70\74\72\20\25\71\2C\20\69\36\34\20\25\6C\65\66\74\29\0A\20\20\25\6F\6B\20\3D\20\69\63\6D\70\20\73\67\74\20\69\36\34\20\25\77\2C\20\30\0A\20\20\62\72\20\69\31\20\25\6F\6B\2C\20\6C\61\62\65\6C\20\25\6D\6F\72\65\2C\20\6C\61\62\65\6C\20\25\6F\75\74\0A\6D\6F\72\65\3A\0A\20\20\25\6E\65\78\74\20\3D\20\61\64\64\20\69\36\34\20\25\61\74\2C\20\25\77\0A\20\20\62\72\20\6C\61\62\65\6C\20\25\6C\6F\6F\70\0A\6F\75\74\3A\0A\20\20\72\65\74\20\76\6F\69\64\0A\7D" }>, align 64
@G_2ecompiler_2fcells_2eWorkerSource = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\CC\0A\00\00\00\00\00\00", ptr @G_2ecompiler_2fcells_2eWorkerSource.k1 }>, align 8
@G_2ecompiler_2fcells_2eWorkerSource.k1 = internal constant <{ [2764 x i8] }> <{ [2764 x i8] c"\69\6D\70\6F\72\74\20\22\73\74\64\2F\69\6F\22\0A\69\6D\70\6F\72\74\20\75\6E\69\73\74\64\20\22\75\6E\69\73\74\64\2E\68\22\0A\69\6D\70\6F\72\74\20\73\79\73\77\61\69\74\20\22\73\79\73\2F\77\61\69\74\2E\68\22\0A\69\6D\70\6F\72\74\20\64\6C\66\63\6E\20\22\64\6C\66\63\6E\2E\68\22\0A\69\6D\70\6F\72\74\20\6D\6D\61\6E\20\22\73\79\73\2F\6D\6D\61\6E\2E\68\22\0A\69\6D\70\6F\72\74\20\66\63\6E\74\6C\20\22\66\63\6E\74\6C\2E\68\22\0A\0A\65\78\74\65\72\6E\20\7B\0A\20\20\20\20\66\6E\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\63\61\6C\6C\28\73\74\61\72\74\20\43\56\6F\69\64\3F\26\2C\20\65\6E\74\72\79\20\43\56\6F\69\64\3F\26\2C\20\66\64\20\49\33\32\29\20\49\33\32\0A\20\20\20\20\66\6E\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\61\66\74\65\72\66\6F\72\6B\28\29\0A\20\20\20\20\66\6E\20\73\69\67\6E\61\6C\28\73\69\67\20\49\33\32\2C\20\68\61\6E\64\6C\65\72\20\49\36\34\29\20\49\36\34\0A\7D\0A\0A\66\6E\20\6D\61\69\6E\28\29\20\7B\0A\20\20\20\20\66\63\6E\74\6C\2E\66\63\6E\74\6C\28\33\2C\20\32\2C\20\31\29\0A\20\20\20\20\66\63\6E\74\6C\2E\66\63\6E\74\6C\28\34\2C\20\32\2C\20\31\29\0A\20\20\20\20\63\6D\64\73\20\3A\3D\20\69\6F\2E\4C\69\6E\65\73\28\49\33\32\28\33\29\29\0A\20\20\20\20\66\6F\72\20\7B\0A\20\20\20\20\20\20\20\20\6C\69\6E\65\20\3A\3D\20\74\72\79\20\63\6D\64\73\2E\4E\65\78\74\28\29\20\63\61\74\63\68\20\7B\20\62\72\65\61\6B\20\7D\0A\20\20\20\20\20\20\20\20\69\66\20\6C\69\6E\65\2E\53\74\61\72\74\73\57\69\74\68\28\22\63\65\6C\6C\20\22\29\3A\20\72\75\6E\28\6C\69\6E\65\5B\35\3A\5D\29\0A\20\20\20\20\20\20\20\20\69\66\20\6C\69\6E\65\20\3D\3D\20\22\65\6E\64\22\3A\20\62\72\65\61\6B\0A\20\20\20\20\7D\0A\7D\0A\0A\66\6E\20\73\61\79\28\6B\69\6E\64\20\49\36\34\2C\20\74\65\78\74\20\41\72\72\61\79\3C\55\38\3E\26\29\20\7B\0A\20\20\20\20\68\65\61\64\20\3A\3D\20\41\72\72\61\79\3C\55\38\3E\28\31\36\29\0A\20\20\20\20\66\6F\72\20\69\20\69\6E\20\72\61\6E\67\65\20\38\20\7B\0A\20\20\20\20\20\20\20\20\68\65\61\64\5B\69\5D\20\3D\20\55\38\28\28\6B\69\6E\64\20\3E\3E\20\28\38\20\2A\20\69\29\29\20\26\20\32\35\35\29\0A\20\20\20\20\20\20\20\20\68\65\61\64\5B\38\20\2B\20\69\5D\20\3D\20\55\38\28\28\74\65\78\74\2E\4C\65\6E\28\29\20\3E\3E\20\28\38\20\2A\20\69\29\29\20\26\20\32\35\35\29\0A\20\20\20\20\7D\0A\20\20\20\20\74\72\79\20\69\6F\2E\57\72\69\74\65\28\34\2C\20\68\65\61\64\29\20\63\61\74\63\68\20\69\6F\2E\45\72\72\6F\72\20\7B\20\7D\0A\20\20\20\20\74\72\79\20\69\6F\2E\57\72\69\74\65\28\34\2C\20\74\65\78\74\29\20\63\61\74\63\68\20\69\6F\2E\45\72\72\6F\72\20\7B\20\7D\0A\7D\0A\0A\66\6E\20\72\75\6E\28\70\61\74\68\20\53\74\72\69\6E\67\26\29\20\7B\0A\20\20\20\20\73\69\67\6E\61\6C\28\32\2C\20\31\29\0A\20\20\20\20\73\79\6E\63\20\3A\3D\20\41\72\72\61\79\3C\49\33\32\3E\28\32\29\0A\20\20\20\20\69\66\20\75\6E\69\73\74\64\2E\70\69\70\65\32\28\73\79\6E\63\2C\20\35\32\34\32\38\38\29\20\21\3D\20\30\20\7B\0A\20\20\20\20\20\20\20\20\73\61\79\28\31\32\2C\20\22\74\68\65\20\73\65\73\73\69\6F\6E\20\63\61\6E\6E\6F\74\20\72\75\6E\20\74\68\65\20\63\65\6C\6C\3A\20\6E\6F\20\70\69\70\65\22\29\0A\20\20\20\20\20\20\20\20\72\65\74\75\72\6E\0A\20\20\20\20\7D\0A\20\20\20\20\70\69\64\20\3A\3D\20\75\6E\69\73\74\64\2E\66\6F\72\6B\28\29\0A\20\20\20\20\69\66\20\70\69\64\20\3C\20\30\20\7B\0A\20\20\20\20\20\20\20\20\73\61\79\28\31\32\2C\20\22\74\68\65\20\73\65\73\73\69\6F\6E\20\63\61\6E\6E\6F\74\20\72\75\6E\20\74\68\65\20\63\65\6C\6C\3A\20\6E\6F\20\70\72\6F\63\65\73\73\22\29\0A\20\20\20\20\20\20\20\20\72\65\74\75\72\6E\0A\20\20\20\20\7D\0A\20\20\20\20\69\66\20\70\69\64\20\3D\3D\20\30\20\7B\0A\20\20\20\20\20\20\20\20\75\6E\69\73\74\64\2E\63\6C\6F\73\65\28\73\79\6E\63\5B\30\5D\29\0A\20\20\20\20\20\20\20\20\63\65\6C\6C\28\70\61\74\68\29\0A\20\20\20\20\20\20\20\20\74\72\79\20\69\6F\2E\57\72\69\74\65\28\73\79\6E\63\5B\31\5D\2C\20\22\6B\22\29\20\63\61\74\63\68\20\69\6F\2E\45\72\72\6F\72\20\7B\20\7D\0A\20\20\20\20\20\20\20\20\75\6E\69\73\74\64\2E\63\6C\6F\73\65\28\73\79\6E\63\5B\31\5D\29\0A\20\20\20\20\20\20\20\20\72\65\74\75\72\6E\0A\20\20\20\20\7D\0A\20\20\20\20\75\6E\69\73\74\64\2E\63\6C\6F\73\65\28\73\79\6E\63\5B\31\5D\29\0A\20\20\20\20\62\20\3A\3D\20\41\72\72\61\79\3C\55\38\3E\28\31\29\0A\20\20\20\20\69\66\20\75\6E\69\73\74\64\2E\72\65\61\64\28\73\79\6E\63\5B\30\5D\2C\20\62\2C\20\31\29\20\3D\3D\20\31\3A\20\75\6E\69\73\74\64\2E\5F\65\78\69\74\28\30\29\0A\20\20\20\20\75\6E\69\73\74\64\2E\63\6C\6F\73\65\28\73\79\6E\63\5B\30\5D\29\0A\20\20\20\20\73\74\20\3A\3D\20\41\72\72\61\79\3C\49\33\32\3E\28\31\29\0A\20\20\20\20\73\79\73\77\61\69\74\2E\77\61\69\74\70\69\64\28\70\69\64\2C\20\73\74\2C\20\30\29\0A\20\20\20\20\73\61\79\28\31\32\2C\20\65\6E\64\69\6E\67\28\73\74\5B\30\5D\29\29\0A\7D\0A\0A\66\6E\20\65\6E\64\69\6E\67\28\72\61\77\20\49\33\32\29\20\53\74\72\69\6E\67\20\7B\0A\20\20\20\20\73\69\67\20\3A\3D\20\72\61\77\20\26\20\31\32\37\0A\20\20\20\20\69\66\20\73\69\67\20\3D\3D\20\30\3A\20\72\65\74\75\72\6E\20\24\22\65\78\69\74\65\64\20\22\20\2B\20\24\28\28\72\61\77\20\3E\3E\20\38\29\20\26\20\32\35\35\29\0A\20\20\20\20\69\66\20\73\69\67\20\3D\3D\20\32\20\6F\72\20\73\69\67\20\3D\3D\20\39\3A\20\72\65\74\75\72\6E\20\22\69\6E\74\65\72\72\75\70\74\65\64\22\0A\20\20\20\20\72\65\74\75\72\6E\20\24\22\73\69\67\6E\61\6C\20\22\20\2B\20\24\73\69\67\0A\7D\0A\0A\66\6E\20\63\65\6C\6C\28\70\61\74\68\20\53\74\72\69\6E\67\26\29\20\7B\0A\20\20\20\20\73\69\67\6E\61\6C\28\32\2C\20\30\29\0A\20\20\20\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\61\66\74\65\72\66\6F\72\6B\28\29\0A\20\20\20\20\73\61\79\28\31\30\2C\20\24\75\6E\69\73\74\64\2E\67\65\74\70\69\64\28\29\29\0A\20\20\20\20\68\20\3A\7E\20\64\6C\66\63\6E\2E\64\6C\6F\70\65\6E\28\70\61\74\68\2E\54\6F\43\28\29\2C\20\32\35\38\29\0A\20\20\20\20\69\66\20\68\20\69\73\20\6E\75\6C\6C\20\7B\0A\20\20\20\20\20\20\20\20\65\20\3A\7E\20\64\6C\66\63\6E\2E\64\6C\65\72\72\6F\72\28\29\0A\20\20\20\20\20\20\20\20\73\61\79\28\32\2C\20\24\22\74\68\65\20\63\65\6C\6C\20\63\61\6E\6E\6F\74\20\62\65\20\6C\6F\61\64\65\64\3A\20\22\20\2B\20\24\28\53\74\72\69\6E\67\2E\46\72\6F\6D\43\28\65\2C\20\34\30\30\29\20\69\66\20\65\20\69\73\20\6E\6F\74\20\6E\75\6C\6C\20\65\6C\73\65\20\70\61\74\68\29\20\2B\20\22\5C\6E\22\29\0A\20\20\20\20\20\20\20\20\73\61\79\28\31\31\2C\20\22\22\29\0A\20\20\20\20\20\20\20\20\72\65\74\75\72\6E\0A\20\20\20\20\7D\0A\20\20\20\20\73\74\61\72\74\20\3A\7E\20\64\6C\66\63\6E\2E\64\6C\73\79\6D\28\68\2C\20\22\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\69\6E\69\74\22\2E\54\6F\43\28\29\29\0A\20\20\20\20\65\6E\74\72\79\20\3A\7E\20\64\6C\66\63\6E\2E\64\6C\73\79\6D\28\68\2C\20\22\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\72\75\6E\22\2E\54\6F\43\28\29\29\0A\20\20\20\20\69\66\20\73\74\61\72\74\20\69\73\20\6E\75\6C\6C\20\6F\72\20\65\6E\74\72\79\20\69\73\20\6E\75\6C\6C\20\7B\0A\20\20\20\20\20\20\20\20\73\61\79\28\32\2C\20\22\74\68\65\20\63\65\6C\6C\27\73\20\6F\62\6A\65\63\74\20\68\61\73\20\6E\6F\20\65\6E\74\72\79\5C\6E\22\29\0A\20\20\20\20\20\20\20\20\73\61\79\28\31\31\2C\20\22\22\29\0A\20\20\20\20\20\20\20\20\72\65\74\75\72\6E\0A\20\20\20\20\7D\0A\20\20\20\20\66\64\20\3A\3D\20\6D\6D\61\6E\2E\6D\65\6D\66\64\5F\63\72\65\61\74\65\28\22\6F\6C\61\6E\67\2D\63\65\6C\6C\5C\30\22\2C\20\31\29\0A\20\20\20\20\69\66\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\63\61\6C\6C\28\73\74\61\72\74\2C\20\65\6E\74\72\79\2C\20\75\6E\69\73\74\64\2E\64\75\70\28\66\64\29\29\20\21\3D\20\30\3A\20\73\61\79\28\32\2C\20\66\61\69\6C\75\72\65\28\66\64\29\29\0A\20\20\20\20\75\6E\69\73\74\64\2E\63\6C\6F\73\65\28\66\64\29\0A\20\20\20\20\73\61\79\28\31\31\2C\20\22\22\29\0A\7D\0A\0A\66\6E\20\66\61\69\6C\75\72\65\28\66\64\20\49\33\32\29\20\53\74\72\69\6E\67\20\7B\0A\20\20\20\20\73\69\7A\65\20\3A\3D\20\75\6E\69\73\74\64\2E\6C\73\65\65\6B\28\66\64\2C\20\30\2C\20\32\29\0A\20\20\20\20\75\6E\69\73\74\64\2E\6C\73\65\65\6B\28\66\64\2C\20\30\2C\20\30\29\0A\20\20\20\20\74\65\78\74\20\3A\3D\20\41\72\72\61\79\3C\55\38\3E\28\73\69\7A\65\20\69\66\20\73\69\7A\65\20\3E\20\30\20\65\6C\73\65\20\30\29\0A\20\20\20\20\67\6F\74\20\49\36\34\20\3D\20\30\0A\20\20\20\20\66\6F\72\20\67\6F\74\20\3C\20\74\65\78\74\2E\4C\65\6E\28\29\20\7B\0A\20\20\20\20\20\20\20\20\6E\20\3A\3D\20\75\6E\69\73\74\64\2E\72\65\61\64\28\66\64\2C\20\74\65\78\74\5B\67\6F\74\3A\5D\2C\20\55\36\34\28\74\65\78\74\2E\4C\65\6E\28\29\20\2D\20\67\6F\74\29\29\0A\20\20\20\20\20\20\20\20\69\66\20\6E\20\3C\3D\20\30\3A\20\62\72\65\61\6B\0A\20\20\20\20\20\20\20\20\67\6F\74\20\2B\3D\20\6E\0A\20\20\20\20\7D\0A\20\20\20\20\72\65\74\75\72\6E\20\53\74\72\69\6E\67\28\74\65\78\74\5B\3A\67\6F\74\5D\29\0A\7D" }>, align 64
define dso_local i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eRunning(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/cells:Worker", ptr %a0, i32 0, i32 3
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp sge i32 %t4, 0
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eclose(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cells:Worker", ptr %t1, i32 0, i32 3
  %t4 = load i32, ptr %t3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/cells:Worker", ptr %t5, i32 0, i32 4
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/cells:Worker", ptr %t9, i32 0, i32 5
  %t12 = load i32, ptr %t11, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/cells:Worker", ptr %t13, i32 0, i32 6
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = insertvalue [4 x i32] undef, i32 %t4, 0
  %t20 = insertvalue [4 x i32] %t18, i32 %t8, 1
  %t22 = insertvalue [4 x i32] %t20, i32 %t12, 2
  %t24 = insertvalue [4 x i32] %t22, i32 %t16, 3
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 16, i64 8)
  store [4 x i32] %t24, ptr %t26
  store ptr %t26, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t28 = load ptr, ptr %l1
  store i64 4, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l1
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = getelementptr [4 x i32], ptr %t39, i64 0, i64 %t40
  %t44 = load i32, ptr %t43, !tbaa !33
  call void @compiler_2fsession_2eCloseFd(i32 %t44)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb1
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/cells:Worker", ptr %t53, i32 0, i32 3
  store i32 -1, ptr %t57, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/cells:Worker", ptr %t58, i32 0, i32 4
  store i32 -1, ptr %t62, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/cells:Worker", ptr %t63, i32 0, i32 5
  store i32 -1, ptr %t67, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/cells:Worker", ptr %t68, i32 0, i32 6
  store i32 -1, ptr %t72, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/cells:Worker", ptr %t73, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eClear_3cU8_3e(ptr %v0, ptr %t75)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2elost(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l10 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/cells:Outcome", ptr %t1, i32 0, i32 6
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/cells:Outcome", ptr %t4, i32 0, i32 7
  store i1 true, ptr %t6, !tbaa !21
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eclose(ptr %v0, ptr %t7)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/cells:Worker", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = icmp sgt i32 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/cells:Worker", ptr %t16, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = call i32 @compiler_2fsession_2eReap(i32 %t19)
  store i32 %t21, ptr %l10
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/cells:Worker", ptr %t22, i32 0, i32 1
  store i32 -1, ptr %t24, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2erelay(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca [65536 x i8]
  %l4 = alloca i64
  %l7 = alloca i32
  %l12 = alloca [65536 x i8]
  %l15 = alloca [65536 x i8]
  %l18 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i32
  %l31 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/cells:Worker", ptr %t5, i32 0, i32 5
  %t8 = load i32, ptr %t7, !tbaa !23
  store i32 %t8, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/cells:Worker", ptr %t10, i32 0, i32 6
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l7, !tbaa !23
  br label %bb3
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  br label %fill.19
fill.19:
  br label %fill.16
fill.16:
  %t20 = phi i64 [ 0, %fill.19 ], [ %t21, %fill.17 ]
  %t22 = icmp slt i64 %t20, 65536
  br i1 %t22, label %fill.17, label %fill.18
fill.17:
  %t23 = getelementptr [65536 x i8], ptr %l12, i64 0, i64 %t20
  store i8 0, ptr %t23
  %t21 = add i64 %t20, 1
  br label %fill.16
fill.18:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l12, i64 65536, i1 false)
  %t24 = load i32, ptr %l2, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l3, i64 65536, i1 false)
  %t25 = load [65536 x i8], ptr %l15
  %t30 = call i64 @read(i32 %t24, ptr %l3, i64 65536)
  store i64 %t30, ptr %l18
  br label %bb4
bb4:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb5, label %bb6
bb5:
  call void @compiler_2fspin_2eEnd()
  br label %bb7
bb6:
  br label %bb20
bb7:
  %t36 = load i64, ptr %l1, !tbaa !24
  %t38 = trunc i64 %t36 to i32
  store i32 %t38, ptr %l22, !tbaa !23
  %t39 = load i64, ptr %l4, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  %t40 = load [65536 x i8], ptr %l3
  store i64 65536, ptr %l24, !tbaa !24
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load i64, ptr %l23, !tbaa !24
  %t44 = icmp sle i64 0, %t43
  br i1 %t44, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_d5164bbf2a35422c_5d9a5374fc012700)
  unreachable
bb10:
  %t46 = load i64, ptr %l23, !tbaa !24
  %t47 = load i64, ptr %l24, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_d5164bbf2a35422c_5d9a5374fc012700)
  unreachable
bb12:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = getelementptr i8, ptr %l3, i64 0
  %t52 = sub i64 %t50, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t55 = load i32, ptr %l22, !tbaa !23
  %t57 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t55, { i64, ptr } %t54)
  store i32 %t57, ptr %l29
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb15, label %ok.59, !prof !99
ok.59:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_d5164bbf2a35422c_5d9a5374fc012700)
  unreachable
bb14:
  br label %bb19
bb15:
  %t60 = load i32, ptr %l29, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  store i1 %t63, ptr %l31, !tbaa !21
  %t64 = load i32, ptr %l29, !tbaa !23
  %t65 = ashr i32 %t64, 16
  %t67 = icmp eq i32 %t65, 1
  br i1 %t67, label %bb16, label %bb17
bb16:
  call void @__olang_errpay_pop()
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/cells:Worker", ptr %t69, i32 0, i32 7
  store i1 true, ptr %t71, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb20:
  %t73 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t73)
  br label %bb21
bb21:
  %t75 = load i64, ptr %l1, !tbaa !24
  %t77 = icmp eq i64 %t75, 1
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/cells:Worker", ptr %t79, i32 0, i32 5
  store i32 -1, ptr %t81, !tbaa !23
  br label %bb24
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/cells:Worker", ptr %t82, i32 0, i32 6
  store i32 -1, ptr %t84, !tbaa !23
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcells_2elink(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca %"std/os:Output"
  %l4 = alloca %"std/os:Output"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/os:Output"
  %l9 = alloca i32
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca { i64, [3 x i64] }
  %l17 = alloca %"compiler/diagmsg:Msg"
  %l24 = alloca i32
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca { i64, [3 x i64] }
  %l32 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t22 = alloca { i64, [3 x i64] }, align 8
  %t67 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %a0)
  store { i64, ptr } %t3, ptr %l6
  br label %bb1
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t6 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t4, { i64, ptr } %t5, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  %t7 = extractvalue { i32, %"std/os:Output" } %t6, 1
  %t8 = extractvalue { i32, %"std/os:Output" } %t6, 0
  store i32 %t8, ptr %l9
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb3, label %ok.10, !prof !99
ok.10:
  store %"std/os:Output" %t7, ptr %l8
  br label %bb2
bb2:
  %t11 = load %"std/os:Output", ptr %l8
  store %"std/os:Output" %t11, ptr %l4
  br label %bb9
bb3:
  %t12 = load i32, ptr %l9, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l11, !tbaa !21
  %t16 = load i32, ptr %l9, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t22
  store { i64, [3 x i64] } %t24, ptr %l15
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v1, ptr %v2, { i64, ptr } %t25)
  store %"compiler/diagmsg:Msg" %t27, ptr %l17
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load { i64, [3 x i64] }, ptr %l15
  %t30 = load %"compiler/diagmsg:Msg", ptr %l17
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v2, ptr %t28, { i64, [3 x i64] } %t29, %"compiler/diagmsg:Msg" %t30)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb9:
  %t32 = load %"std/os:Output", ptr %l4
  store %"std/os:Output" %t32, ptr %l3
  %t33 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = icmp eq i32 %t34, 0
  br i1 %t36, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t38 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t39, 1
  %t44 = extractvalue { i64, ptr } %t39, 0
  %t46 = extractvalue { i64, ptr } %t41, 1
  %t47 = extractvalue { i64, ptr } %t41, 0
  %t48 = add i64 %t44, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t43, i64 %t44)
  %t50 = getelementptr i8, ptr %t49, i64 %t44
  call void @olang_textcopy(ptr %t50, ptr %t46, i64 %t47)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  %t54 = call i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t52)
  store i32 %t54, ptr %l24
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb14, label %ok.56, !prof !99
ok.56:
  br label %bb13
bb13:
  br label %bb18
bb14:
  %t57 = load i32, ptr %l24, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l26, !tbaa !21
  %t61 = load i32, ptr %l24, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  br i1 %t64, label %bb15, label %bb16
bb15:
  call void @__olang_errpay_pop()
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %l29, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [3 x i64] }, ptr %t67, i32 0, i32 0
  store i64 0, ptr %t68
  %t69 = load { i64, [3 x i64] }, ptr %t67
  store { i64, [3 x i64] } %t69, ptr %l30
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v1, ptr %v2, { i64, ptr } %t70)
  store %"compiler/diagmsg:Msg" %t72, ptr %l32
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l29, !tbaa !29
  %t74 = load { i64, [3 x i64] }, ptr %l30
  %t75 = load %"compiler/diagmsg:Msg", ptr %l32
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v2, ptr %t73, { i64, [3 x i64] } %t74, %"compiler/diagmsg:Msg" %t75)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcells_2esymbolAt(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i1 @compiler_2fcells_2esymbolChar(i8 %t17)
  store i1 %t19, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l12, !tbaa !21
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = add i64 %t24, 1
  store i64 %t27, ptr %l2, !tbaa !24
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l17, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l18, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l19, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l20, !tbaa !24
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load i64, ptr %l18, !tbaa !24
  %t38 = load i64, ptr %l19, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_1fa7a91fdba5f63e_9e2724382c24a02)
  unreachable
bb13:
  %t41 = load i64, ptr %l19, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_1fa7a91fdba5f63e_9e2724382c24a02)
  unreachable
bb15:
  %t45 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l18, !tbaa !24
  %t48 = load i64, ptr %l19, !tbaa !24
  %t49 = getelementptr i8, ptr %t46, i64 %t47
  %t50 = sub i64 %t48, %t47
  %t51 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_1fa7a91fdba5f63e_9e2724382c24a02)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcells_2esymbolChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb10:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 46
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb14
bb13:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 36
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb14
bb14:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb16:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 45
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cells:Worker" @compiler_2fcells_3aWorker_2ector(ptr %v0, i1 %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/cells:Worker"
  br label %start
start:
  br label %bb0
bb0:
  store i1 %a0, ptr %l1, !tbaa !21
  store i32 -1, ptr %l2, !tbaa !23
  store i32 -1, ptr %l3, !tbaa !23
  store i32 -1, ptr %l4, !tbaa !23
  store i32 -1, ptr %l5, !tbaa !23
  store i32 -1, ptr %l6, !tbaa !23
  store i32 -1, ptr %l7, !tbaa !23
  store i1 false, ptr %l8, !tbaa !21
  %t3 = call ptr @__olang_scope_hold(ptr %v0)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l11, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aWorker_2e8
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v0)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l11, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l11
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %t10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l13
  br label %bb3
bb3:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aWorker_2e8
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l11
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  call void @__olang_region_settle_in(ptr %t15, ptr %t22)
  br label %bb5
bb5:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t24 = load i1, ptr %l1, !tbaa !21
  %t25 = insertvalue %"compiler/cells:Worker" undef, i1 %t24, 0
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = insertvalue %"compiler/cells:Worker" %t25, i32 %t26, 1
  %t28 = load i32, ptr %l3, !tbaa !23
  %t29 = insertvalue %"compiler/cells:Worker" %t27, i32 %t28, 2
  %t30 = load i32, ptr %l4, !tbaa !23
  %t31 = insertvalue %"compiler/cells:Worker" %t29, i32 %t30, 3
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = insertvalue %"compiler/cells:Worker" %t31, i32 %t32, 4
  %t34 = load i32, ptr %l6, !tbaa !23
  %t35 = insertvalue %"compiler/cells:Worker" %t33, i32 %t34, 5
  %t36 = load i32, ptr %l7, !tbaa !23
  %t37 = insertvalue %"compiler/cells:Worker" %t35, i32 %t36, 6
  %t38 = load i1, ptr %l8, !tbaa !21
  %t39 = insertvalue %"compiler/cells:Worker" %t37, i1 %t38, 7
  %t41 = insertvalue %"compiler/cells:Worker" %t39, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, 8
  store %"compiler/cells:Worker" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cells:Worker", ptr %rv
  ret %"compiler/cells:Worker" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i64 @read(i32, ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
declare void @__olang_errpay_pop()
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fcells_3aWorker_2e8 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare void @compiler_2fsession_2eCloseFd(i32 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eClear_3cU8_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fsession_2eReap(i32 %a0)
declare void @compiler_2fspin_2eEnd()
@olang_loc_d5164bbf2a35422c_5d9a5374fc012700 = external constant [0 x i8]
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
@olang_loc_1fa7a91fdba5f63e_9e2724382c24a02 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
