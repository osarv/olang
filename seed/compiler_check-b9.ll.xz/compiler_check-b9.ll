; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:fieldSet" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
define dso_local i1 @compiler_2fcheck_2ecompares(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 95 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 96 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t14 = trunc i64 98 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t20 = trunc i64 99 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t26 = trunc i64 100 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t32 = trunc i64 101 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtBinding(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/typed:Local"
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca ptr
  %l29 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca %"compiler/typed:Local"
  %l57 = alloca ptr
  %l62 = alloca i32
  %l67 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i32
  %l76 = alloca ptr
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l5, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l5, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l16
  br label %bb3
bb3:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l20
  br label %bb6
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i1, ptr %l20, !tbaa !21
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l17, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  store ptr %t32, ptr %l24, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l34
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l24, !tbaa !29
  %t54 = load i32, ptr %l29, !tbaa !23
  %t55 = load i32, ptr %l34, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t53, i32 %t54, i32 %t55)
  store i1 %t56, ptr %l35
  br label %bb12
bb12:
  %t57 = load i1, ptr %l35, !tbaa !21
  store i1 %t57, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l21, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l37, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l38
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s1, ptr %t63, i32 %a2)
  store { i64, ptr } %t67, ptr %l41
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t68 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t68, ptr %l42, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l45
  br label %bb17
bb17:
  %t74 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t77 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %s1, ptr %s1, ptr %v0, { i64, ptr } %t75, { i64, ptr } %t74)
  store %"compiler/diagmsg:Msg" %t77, ptr %l47
  br label %bb18
bb18:
  %t78 = load ptr, ptr %l37, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l38
  %t80 = load %"compiler/diagmsg:Msg", ptr %l47
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t78, %"compiler/source:Span" %t79, %"compiler/diagmsg:Msg" %t80)
  store i64 %t81, ptr %l48
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb20:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t82)
  store ptr %t84, ptr %l50
  br label %bb21
bb21:
  %t85 = load ptr, ptr %l50, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 7
  %t88 = load i64, ptr %l3, !tbaa !24
  %t91 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t87, i64 %t88)
  store %"compiler/typed:Local" %t91, ptr %l54
  br label %bb22
bb22:
  %t92 = load %"compiler/typed:Local", ptr %l54
  store %"compiler/typed:Local" %t92, ptr %l6
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l57, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l5, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l62
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l5, !tbaa !23
  %t118 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t114, i32 %t115)
  store i64 %t118, ptr %l67
  br label %bb24
bb24:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l4, !tbaa !23
  %t128 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t124, i32 %t125)
  store i64 %t128, ptr %l72
  br label %bb25
bb25:
  %t129 = load i64, ptr %l67, !tbaa !24
  %t130 = load i64, ptr %l72, !tbaa !24
  %t131 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t129, i64 %t130)
  store i64 %t131, ptr %l73
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l57, !tbaa !29
  %t133 = load i32, ptr %l62, !tbaa !23
  %t134 = load i64, ptr %l73, !tbaa !24
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t132, i32 %t133, i64 %t134)
  store i32 %t135, ptr %l74
  br label %bb27
bb27:
  %t136 = load i32, ptr %l74, !tbaa !23
  %t137 = getelementptr %"compiler/typed:Local", ptr %l6, i32 0, i32 2
  store i32 %t136, ptr %t137, !tbaa !23
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t138)
  store ptr %t140, ptr %l76
  br label %bb28
bb28:
  %t141 = load ptr, ptr %l76, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Body", ptr %t141, i32 0, i32 7
  %t144 = load i64, ptr %l3, !tbaa !24
  %t145 = load %"compiler/typed:Local", ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t143, i64 %t144, %"compiler/typed:Local" %t145)
  br label %bb29
bb29:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca { i64, [3 x i64] }
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, [3 x i64] }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i32
  %l46 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i32
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l76 = alloca i32
  %l81 = alloca i32
  %l84 = alloca i1
  %l89 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/source:Span"
  %l99 = alloca i64
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i64
  %l108 = alloca i32
  %l111 = alloca i64
  %l122 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l133 = alloca i1
  %l135 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l140 = alloca %"compiler/source:Span"
  %l142 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l146 = alloca %"compiler/source:Span"
  %l155 = alloca ptr
  %l157 = alloca ptr
  %l159 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i32
  %l169 = alloca i32
  %l172 = alloca i1
  %l177 = alloca i64
  %l185 = alloca i1
  %l188 = alloca i1
  %l190 = alloca ptr
  %l194 = alloca ptr
  %l201 = alloca i1
  %l204 = alloca i1
  %l206 = alloca ptr
  %l210 = alloca ptr
  %l216 = alloca ptr
  %l222 = alloca { i64, ptr }
  %l226 = alloca i1
  %l230 = alloca i1
  %l233 = alloca ptr
  %l238 = alloca i32
  %l239 = alloca i32
  %l243 = alloca i1
  %l248 = alloca i1
  %l251 = alloca %"compiler/source:Span"
  %l252 = alloca i32
  %l253 = alloca i32
  %l254 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l260 = alloca i32
  %l263 = alloca %"compiler/typed:Make"
  %rv = alloca ptr
  %t205 = alloca { i64, [3 x i64] }, align 8
  %t344 = alloca { i64, [3 x i64] }, align 8
  %t506 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i32 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %l23, !tbaa !27
  %t4 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr ptr, ptr %t5, i64 0
  %t7 = load ptr, ptr %t6, !tbaa !39
  %t10 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t2, ptr %t7)
  store %"compiler/source:Span" %t10, ptr %l25
  br label %bb1
bb1:
  %t11 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = sext i32 %t12 to i64
  %t16 = load ptr, ptr %l21, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 147
  store i64 %t14, ptr %t17, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l28, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l29, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 0
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l30, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l32
  br label %bb2
bb2:
  %t27 = load ptr, ptr %l28, !tbaa !29
  %t28 = load ptr, ptr %l30, !tbaa !29
  %t29 = load i32, ptr %l32, !tbaa !23
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v3, ptr %t27, ptr %t28, i32 %t29)
  store ptr %t30, ptr %l33
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l33, !tbaa !29
  store ptr %t31, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 147
  store i64 -1, ptr %t34, !tbaa !24
  store i32 0, ptr %l7, !tbaa !23
  %t35 = load i32, ptr %l4, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp ne i32 %t35, %t36
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l4, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l41
  br label %bb6
bb5:
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t46, ptr %l38, !tbaa !23
  br label %bb7
bb6:
  %t48 = load i32, ptr %l41, !tbaa !23
  store i32 %t48, ptr %l38, !tbaa !23
  br label %bb7
bb7:
  %t49 = load i32, ptr %l38, !tbaa !23
  store i32 %t49, ptr %l8, !tbaa !23
  %t50 = load i32, ptr %l8, !tbaa !23
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t54 = icmp ne i32 %t50, %t51
  br i1 %t54, label %bb8, label %bb9
bb8:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l49, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l8, !tbaa !23
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l52
  br label %bb10
bb9:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb12
bb10:
  %t67 = load ptr, ptr %l49, !tbaa !29
  %t68 = load i32, ptr %l52, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t69, ptr %l53
  br label %bb11
bb11:
  %t70 = load i32, ptr %l53, !range !{i32 0, i32 33}
  %t72 = trunc i64 19 to i32
  %t73 = icmp eq i32 %t70, %t72
  store i1 %t73, ptr %l46, !tbaa !21
  br label %bb12
bb12:
  %t75 = load i1, ptr %l46, !tbaa !21
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  store ptr %t81, ptr %l59, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l8, !tbaa !23
  %t86 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l62
  br label %bb15
bb14:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb17
bb15:
  %t87 = load ptr, ptr %l59, !tbaa !29
  %t88 = load i32, ptr %l62, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l63
  br label %bb16
bb16:
  %t90 = load i32, ptr %l63, !tbaa !23
  %t91 = icmp eq i32 %t90, 0
  store i1 %t91, ptr %l56, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l56, !tbaa !21
  %t96 = xor i1 %t93, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l68, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t102)
  store ptr %t104, ptr %l70
  br label %bb20
bb19:
  br label %bb34
bb20:
  %t105 = load ptr, ptr %l70, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 4
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t108, ptr %l73, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = load ptr, ptr %l68, !tbaa !29
  %t117 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldLength(ptr %v0, ptr %v0, ptr %v1, ptr %t114, ptr %t107, ptr %t112)
  store i32 %t117, ptr %l76
  br label %bb21
bb21:
  %t118 = load i32, ptr %l76, !tbaa !23
  store i32 %t118, ptr %l10, !tbaa !23
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l10, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l81
  br label %bb22
bb22:
  %t129 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t131 = trunc i64 26 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb23, label %bb24
bb23:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l10, !tbaa !23
  %t143 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t139, i32 %t140)
  store i64 %t143, ptr %l89
  br label %bb25
bb24:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb26
bb25:
  %t144 = load i64, ptr %l89, !tbaa !24
  %t145 = icmp slt i64 %t144, 0
  store i1 %t145, ptr %l84, !tbaa !21
  br label %bb26
bb26:
  %t147 = load i1, ptr %l84, !tbaa !21
  br i1 %t147, label %bb27, label %bb28
bb27:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l91, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t149, ptr %l92, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr ptr, ptr %t151, i64 0
  %t153 = load ptr, ptr %t152, !tbaa !39
  %t155 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t153)
  store %"compiler/source:Span" %t155, ptr %l94
  br label %bb29
bb28:
  %t156 = load i32, ptr %l10, !tbaa !23
  store i32 %t156, ptr %l7, !tbaa !23
  br label %bb33
bb29:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l10, !tbaa !23
  %t167 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t163, i32 %t164)
  store i64 %t167, ptr %l99
  br label %bb30
bb30:
  %t168 = load i64, ptr %l99, !tbaa !24
  %t169 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %v0, i64 %t168)
  store %"compiler/diagmsg:Msg" %t169, ptr %l100
  br label %bb31
bb31:
  %t170 = load ptr, ptr %l91, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l94
  %t172 = load %"compiler/diagmsg:Msg", ptr %l100
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t170, %"compiler/source:Span" %t171, %"compiler/diagmsg:Msg" %t172)
  store i64 %t173, ptr %l101
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %l2, !tbaa !23
  %t181 = load i32, ptr %l7, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t179, i32 %t180, i32 %t181)
  store i32 %t185, ptr %l108
  br label %bb35
bb35:
  %t186 = load i32, ptr %l108, !tbaa !23
  store i32 %t186, ptr %l11, !tbaa !23
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 47
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l111
  br label %bb36
bb36:
  %t192 = load i64, ptr %l111, !tbaa !24
  store i64 %t192, ptr %l12, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t197 = icmp eq i64 %t195, 2
  br i1 %t197, label %bb37, label %bb38
bb37:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 18
  %t202 = load { i64, [3 x i64] }, ptr %t201
  store { i64, [3 x i64] } %t202, ptr %l13
  %t204 = load ptr, ptr %l0, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t207 = load { i64, [3 x i64] }, ptr %t205
  %t210 = getelementptr %"compiler/check:Checker", ptr %t204, i32 0, i32 18
  store { i64, [3 x i64] } %t207, ptr %t210
  %t211 = load ptr, ptr %l5, !tbaa !29
  %t213 = icmp eq ptr %t211, null
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb39, label %bb40
bb38:
  br label %bb52
bb39:
  %t217 = load ptr, ptr %l5, !tbaa !29
  store ptr %t217, ptr %l122, !tbaa !29
  br label %bb42
bb40:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t220, ptr %l125, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr ptr, ptr %t222, i64 1
  %t224 = load ptr, ptr %t223, !tbaa !39
  %t225 = load i32, ptr %l2, !tbaa !23
  %t229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %t219, ptr %t224, i32 %t225)
  store ptr %t229, ptr %l128
  br label %bb41
bb41:
  %t230 = load ptr, ptr %l128, !tbaa !29
  store ptr %t230, ptr %l122, !tbaa !29
  br label %bb42
bb42:
  %t231 = load ptr, ptr %l122, !tbaa !29
  store ptr %t231, ptr %l14, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load { i64, [3 x i64] }, ptr %l13
  %t236 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 18
  store { i64, [3 x i64] } %t233, ptr %t236
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i32, ptr %l2, !tbaa !23
  %t241 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t237, i32 %t238)
  store i1 %t241, ptr %l133
  br label %bb43
bb43:
  %t242 = load i1, ptr %l133, !tbaa !21
  %t243 = xor i1 %t242, true
  br i1 %t243, label %bb44, label %bb45
bb44:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l135, !tbaa !29
  %t246 = load ptr, ptr %l14, !tbaa !29
  store ptr %t246, ptr %l137, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t248, ptr %l138, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr ptr, ptr %t250, i64 1
  %t252 = load ptr, ptr %t251, !tbaa !39
  %t254 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t252)
  store %"compiler/source:Span" %t254, ptr %l140
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t255 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t256 = load ptr, ptr %l135, !tbaa !29
  %t257 = load ptr, ptr %l137, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l140
  %t260 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v2, ptr %t256, ptr %t257, %"compiler/source:Span" %t258, i64 %t255)
  store i1 %t260, ptr %l142
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l143, !tbaa !29
  %t262 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t262, ptr %l144, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr ptr, ptr %t264, i64 1
  %t266 = load ptr, ptr %t265, !tbaa !39
  %t268 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t266)
  store %"compiler/source:Span" %t268, ptr %l146
  br label %bb49
bb49:
  %t269 = load i32, ptr %l2, !tbaa !23
  %t270 = load ptr, ptr %l143, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l146
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueFill(ptr %v0, ptr %t270, %"compiler/source:Span" %t271, i32 %t269)
  br label %bb50
bb50:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 47
  %t276 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t275, ptr %t276)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t279 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t283 = icmp eq i64 %t281, 1
  br i1 %t283, label %bb53, label %bb54
bb53:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  store ptr %t288, ptr %l155, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t289)
  store ptr %t291, ptr %l157
  br label %bb55
bb54:
  br label %bb86
bb55:
  %t292 = load ptr, ptr %l157, !tbaa !29
  %t294 = getelementptr %"compiler/check:frame", ptr %t292, i32 0, i32 4
  store ptr %t294, ptr %l159, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t295, ptr %l160, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr ptr, ptr %t297, i64 0
  %t299 = load ptr, ptr %t298, !tbaa !39
  store ptr %t299, ptr %l161, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t300)
  store i32 %t302, ptr %l163
  br label %bb56
bb56:
  %t303 = load ptr, ptr %l155, !tbaa !29
  %t304 = load ptr, ptr %l159, !tbaa !29
  %t305 = load ptr, ptr %l161, !tbaa !29
  %t306 = load i32, ptr %l163, !tbaa !23
  %t307 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t303, ptr %t304, ptr %t305, i32 %t306)
  store i32 %t307, ptr %l164
  br label %bb57
bb57:
  %t308 = load i32, ptr %l164, !tbaa !23
  store i32 %t308, ptr %l15, !tbaa !23
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/generic:Program", ptr %t312, i32 0, i32 2
  %t315 = load i32, ptr %l15, !tbaa !23
  %t318 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t314, i32 %t315)
  store i32 %t318, ptr %l169
  br label %bb58
bb58:
  %t319 = load i32, ptr %l169, !range !{i32 0, i32 33}
  %t321 = trunc i64 26 to i32
  %t322 = icmp eq i32 %t319, %t321
  br i1 %t322, label %bb59, label %bb60
bb59:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/check:Checker", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = getelementptr %"compiler/generic:Program", ptr %t327, i32 0, i32 2
  %t330 = load i32, ptr %l15, !tbaa !23
  %t333 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t329, i32 %t330)
  store i64 %t333, ptr %l177
  br label %bb61
bb60:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb62
bb61:
  %t334 = load i64, ptr %l177, !tbaa !24
  %t335 = icmp eq i64 %t334, 0
  store i1 %t335, ptr %l172, !tbaa !21
  br label %bb62
bb62:
  %t337 = load i1, ptr %l172, !tbaa !21
  store i1 %t337, ptr %l16, !tbaa !21
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 18
  %t341 = load { i64, [3 x i64] }, ptr %t340
  store { i64, [3 x i64] } %t341, ptr %l17
  %t343 = load ptr, ptr %l0, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t344
  %t345 = getelementptr { i64, [3 x i64] }, ptr %t344, i32 0, i32 0
  store i64 0, ptr %t345
  %t346 = load { i64, [3 x i64] }, ptr %t344
  %t349 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 18
  store { i64, [3 x i64] } %t346, ptr %t349
  %t350 = load i1, ptr %l16, !tbaa !21
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb63, label %bb64
bb63:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l2, !tbaa !23
  %t358 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t354, i32 %t355)
  store i1 %t358, ptr %l188
  br label %bb65
bb64:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb66
bb65:
  %t359 = load i1, ptr %l188, !tbaa !21
  store i1 %t359, ptr %l185, !tbaa !21
  br label %bb66
bb66:
  %t360 = load i1, ptr %l185, !tbaa !21
  br i1 %t360, label %bb67, label %bb68
bb67:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/check:Checker", ptr %t361, i32 0, i32 47
  store ptr %t363, ptr %l190, !tbaa !29
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l1
  %t366 = load i32, ptr %l2, !tbaa !23
  %t370 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t364, %"compiler/source:Span" %t365, i32 %t366)
  store ptr %t370, ptr %l194
  br label %bb69
bb68:
  %t371 = load i1, ptr %l16, !tbaa !21
  %t373 = xor i1 %t371, true
  br i1 %t373, label %bb72, label %bb73
bb69:
  %t375 = load ptr, ptr %l190, !tbaa !29
  %t376 = load ptr, ptr %l194, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t375, ptr %t376)
  br label %bb70
bb70:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l1
  %t379 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v0, ptr %t377, i32 2, %"compiler/source:Span" %t378, i32 %t379, ptr null)
  br label %bb71
bb71:
  br label %bb85
bb72:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l2, !tbaa !23
  %t388 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %t384, i32 %t385)
  store i1 %t388, ptr %l204
  br label %bb74
bb73:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb75
bb74:
  %t389 = load i1, ptr %l204, !tbaa !21
  store i1 %t389, ptr %l201, !tbaa !21
  br label %bb75
bb75:
  %t390 = load i1, ptr %l201, !tbaa !21
  br i1 %t390, label %bb76, label %bb77
bb76:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/check:Checker", ptr %t391, i32 0, i32 47
  store ptr %t393, ptr %l206, !tbaa !29
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load %"compiler/source:Span", ptr %l1
  %t396 = load i32, ptr %l2, !tbaa !23
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v0, ptr %t394, %"compiler/source:Span" %t395, i32 %t396)
  store ptr %t400, ptr %l210
  br label %bb78
bb77:
  %t401 = load i1, ptr %l16, !tbaa !21
  %t403 = xor i1 %t401, true
  br i1 %t403, label %bb80, label %bb81
bb78:
  %t405 = load ptr, ptr %l206, !tbaa !29
  %t406 = load ptr, ptr %l210, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t405, ptr %t406)
  br label %bb79
bb79:
  br label %bb84
bb80:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load %"compiler/source:Span", ptr %l1
  %t409 = load i32, ptr %l2, !tbaa !23
  %t413 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t407, %"compiler/source:Span" %t408, i32 %t409)
  store ptr %t413, ptr %l216
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb83
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load { i64, [3 x i64] }, ptr %l17
  %t418 = getelementptr %"compiler/check:Checker", ptr %t414, i32 0, i32 18
  store { i64, [3 x i64] } %t415, ptr %t418
  br label %bb86
bb86:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"compiler/check:Checker", ptr %t419, i32 0, i32 47
  %t422 = load i64, ptr %l12, !tbaa !24
  %t425 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t421, i64 %t422)
  store { i64, ptr } %t425, ptr %l222
  br label %bb87
bb87:
  %t426 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t426, ptr %l18, !tbaa !27
  store i32 1, ptr %l19
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/check:Checker", ptr %t428, i32 0, i32 148
  %t431 = load i1, ptr %t430, !tbaa !21
  br i1 %t431, label %bb88, label %bb89
bb88:
  %t433 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t433, 0
  %t437 = icmp eq i64 %t435, 1
  store i1 %t437, ptr %l226, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb90
bb90:
  %t439 = load i1, ptr %l226, !tbaa !21
  br i1 %t439, label %bb91, label %bb92
bb91:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/check:Checker", ptr %t440, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !29
  %t445 = getelementptr %"compiler/generic:Program", ptr %t443, i32 0, i32 2
  store ptr %t445, ptr %l233, !tbaa !29
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/check:Checker", ptr %t446, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t451 = getelementptr %"compiler/generic:Program", ptr %t449, i32 0, i32 2
  %t452 = load i32, ptr %l2, !tbaa !23
  %t455 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t451, i32 %t452)
  store i32 %t455, ptr %l238
  br label %bb93
bb92:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb95
bb93:
  %t456 = load ptr, ptr %l233, !tbaa !29
  %t457 = load i32, ptr %l238, !tbaa !23
  %t458 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t456, i32 %t457)
  store i32 %t458, ptr %l239
  br label %bb94
bb94:
  %t459 = load i32, ptr %l239, !range !{i32 0, i32 33}
  %t461 = trunc i64 19 to i32
  %t462 = icmp eq i32 %t459, %t461
  %t464 = xor i1 %t462, true
  store i1 %t464, ptr %l230, !tbaa !21
  br label %bb95
bb95:
  %t466 = load i1, ptr %l230, !tbaa !21
  br i1 %t466, label %bb96, label %bb97
bb96:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/check:Checker", ptr %t467, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t472 = getelementptr %"compiler/generic:Program", ptr %t470, i32 0, i32 2
  %t473 = load i32, ptr %l2, !tbaa !23
  %t476 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t472, i32 %t473)
  store i1 %t476, ptr %l248
  br label %bb98
bb97:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb99
bb98:
  %t477 = load i1, ptr %l248, !tbaa !21
  %t478 = xor i1 %t477, true
  store i1 %t478, ptr %l243, !tbaa !21
  br label %bb99
bb99:
  %t480 = load i1, ptr %l243, !tbaa !21
  store i1 %t480, ptr %l20, !tbaa !21
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/check:Checker", ptr %t481, i32 0, i32 148
  store i1 false, ptr %t483, !tbaa !21
  %t484 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t484, ptr %l251
  %t485 = load i32, ptr %l11, !tbaa !23
  store i32 %t485, ptr %l252, !tbaa !23
  store i32 3, ptr %l253
  %t486 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t486, ptr %l254, !tbaa !27
  %t487 = load ptr, ptr %l6, !tbaa !29
  store ptr %t487, ptr %l256, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load %"compiler/source:Span", ptr %l1
  %t494 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t489, i32 1, %"compiler/source:Span" %t490)
  store i32 %t494, ptr %l260
  br label %bb100
bb100:
  %t495 = load i32, ptr %l19, !range !{i32 0, i32 4}
  %t496 = load i1, ptr %l20, !tbaa !21
  %t497 = load i32, ptr %l253, !range !{i32 0, i32 5}
  %t498 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t499 = load ptr, ptr %l256, !tbaa !29
  %t500 = load i32, ptr %l260, !tbaa !23
  %t503 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t497, i64 0, { i64, ptr } %t498, ptr %t499, i32 %t500, i32 %t495, i1 %t496)
  store %"compiler/typed:Make" %t503, ptr %l263
  br label %bb101
bb101:
  %t504 = load %"compiler/typed:Make", ptr %l263
  %t505 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/typed:Make" %t504, ptr %t505
  store { i64, [5 x i64] } zeroinitializer, ptr %t506
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t506, i32 0, i32 0
  store i64 7, ptr %t507
  %t508 = load %"compiler/source:Span", ptr %l251
  %t509 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t508, 0
  %t510 = load i32, ptr %l252, !tbaa !23
  %t511 = insertvalue { %"compiler/source:Span", i32, ptr } %t509, i32 %t510, 1
  %t513 = insertvalue { %"compiler/source:Span", i32, ptr } %t511, ptr %t505, 2
  %t514 = getelementptr { i64, [5 x i64] }, ptr %t506, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t513, ptr %t514
  %t515 = load { i64, [5 x i64] }, ptr %t506
  %t517 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t515, ptr %t517
  store ptr %t517, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l6 = alloca %"compiler/check:fixedInit"
  %l7 = alloca i32
  %l9 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l10 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l12 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l13 = alloca i32
  %l15 = alloca i1
  %l19 = alloca i1
  %l20 = alloca %"compiler/check:fixedInit"
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l29 = alloca %"compiler/check:fixedInit"
  %l30 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l46 = alloca i32
  %l51 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t3 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v2, ptr %v2, ptr %a2)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l9
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t4, ptr %l4
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v2, ptr %l4)
  %t7 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t6, 1
  %t8 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t6, 0
  store i32 %t8, ptr %l13
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t7, ptr %l12
  br label %bb3
bb3:
  %t11 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l12
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t11, ptr %l10
  br label %bb6
bb4:
  %t12 = load i32, ptr %l13, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb6:
  %t16 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l10
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t16, ptr %l5
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Context", ptr %t17, i32 0, i32 2
  %t20 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  %t24 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v1, ptr %t19, i32 %t21)
  store i1 %t24, ptr %l19
  br label %bb7
bb7:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 164
  store ptr %t28, ptr %l22, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l24
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l24, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t35, i64 %t37)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t40, ptr %l28
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l28
  %t43 = call { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v0, ptr %t41, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t42)
  %t44 = extractvalue { i32, %"compiler/check:fixedInit" } %t43, 1
  %t45 = extractvalue { i32, %"compiler/check:fixedInit" } %t43, 0
  store i32 %t45, ptr %l30
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb14, label %ok.47, !prof !99
ok.47:
  store %"compiler/check:fixedInit" %t44, ptr %l29
  br label %bb13
bb13:
  %t48 = load %"compiler/check:fixedInit", ptr %l29
  store %"compiler/check:fixedInit" %t48, ptr %l20
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  store i64 0, ptr %rv
  br label %ret
bb16:
  %t50 = load %"compiler/check:fixedInit", ptr %l20
  store %"compiler/check:fixedInit" %t50, ptr %l6
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:fixedInit", ptr %l6, i32 0, i32 1
  %t53 = load i32, ptr %t52, !tbaa !23
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t51, i32 %t53)
  store i1 %t56, ptr %l34
  br label %bb17
bb17:
  %t57 = load i1, ptr %l34, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb21
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:fixedInit", ptr %l6, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsLength(ptr %v0, ptr %v0, ptr %t60, ptr %t62, i64 0)
  store i1 %t65, ptr %l39
  br label %bb20
bb20:
  %t66 = load i1, ptr %l39, !tbaa !21
  store i1 %t66, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i64 0, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/check:fixedInit", ptr %l6, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t76 = getelementptr %"compiler/check:fixedInit", ptr %l6, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t82 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v0, ptr %t72, ptr %t73, ptr %t75, i32 %t77)
  store i32 %t82, ptr %l46
  br label %bb25
bb25:
  %t83 = load i32, ptr %l46, !tbaa !23
  store i32 %t83, ptr %l7, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l7, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l51
  br label %bb26
bb26:
  %t94 = load i32, ptr %l51, !range !{i32 0, i32 33}
  %t96 = trunc i64 26 to i32
  %t97 = icmp eq i32 %t94, %t96
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Context", ptr %t101, i32 0, i32 2
  %t104 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t106 = load i32, ptr %l7, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v1, ptr %t103, i32 %t105, i32 %t106)
  br label %bb30
bb30:
  %t110 = load i64, ptr %l3, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  br label %bb2
bb32:
  %t115 = load i64, ptr %l3, !tbaa !24
  store i64 %t115, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, i32 %a4, ptr %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca %"compiler/typed:Local"
  %l46 = alloca i1
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l70 = alloca ptr
  %l77 = alloca ptr
  %l79 = alloca ptr
  %l83 = alloca %"compiler/typed:Local"
  %l86 = alloca i1
  %l88 = alloca i1
  %l100 = alloca ptr
  %l102 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i1
  %l107 = alloca i1
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l125 = alloca %"compiler/typed:Bind"
  %l130 = alloca ptr
  %rv = alloca ptr
  %t91 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l1
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t2, %"compiler/source:Span" %t3, ptr %t4)
  store ptr %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load %"compiler/source:Span", ptr %l1
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load ptr, ptr %l14, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v0, ptr %t10, ptr %t11, %"compiler/source:Span" %t9, i1 false, i1 false)
  store ptr %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l16, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l17, !tbaa !29
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t16)
  store i32 %t19, ptr %l20
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = load i32, ptr %l20, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l25
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t29 = load i1, ptr %l25, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t36 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t33)
  store i32 %t36, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t37 = load i32, ptr %l29, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t38, i32 %t39)
  store i64 %t42, ptr %l32
  br label %bb13
bb13:
  %t43 = load i64, ptr %l32, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp slt i64 %t44, 0
  br i1 %t46, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb18
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t48)
  store ptr %t50, ptr %l37
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l37, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t51, i32 0, i32 7
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t53, i64 %t54)
  store %"compiler/typed:Local" %t57, ptr %l41
  br label %bb17
bb17:
  %t58 = getelementptr %"compiler/typed:Local", ptr %l41, i32 0, i32 3
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t65 = icmp ne i64 %t61, %a6
  store i1 %t65, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb23
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t68)
  store ptr %t70, ptr %l48
  br label %bb21
bb21:
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 7
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/typed:Local" %t77, ptr %l52
  br label %bb22
bb22:
  %t78 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 4
  %t79 = load i32, ptr %t78, !range !{i32 0, i32 7}
  %t81 = trunc i64 4 to i32
  %t82 = icmp eq i32 %t79, %t81
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l2, !tbaa !23
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [1 x i64] }, ptr %t91, i32 0, i32 0
  store i64 4, ptr %t92
  %t93 = load { i64, [1 x i64] }, ptr %t91
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t87, i32 %t88, %"compiler/source:Span" %t89, i32 %t90, i32 4, { i64, [1 x i64] } %t93)
  store i64 %t100, ptr %l62
  br label %bb26
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l77, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t107)
  store ptr %t109, ptr %l79
  br label %bb33
bb26:
  %t110 = load i64, ptr %l62, !tbaa !24
  store i64 %t110, ptr %l8, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t115 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  store { i64, [3 x i64] } %t115, ptr %l65
  br label %bb27
bb27:
  %t116 = load { i64, [3 x i64] }, ptr %l65
  store { i64, [3 x i64] } %t116, ptr %l9
  %t117 = load { i64, [3 x i64] }, ptr %l9
  %t119 = extractvalue { i64, [3 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 0
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb28, label %bb29
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t124)
  store ptr %t126, ptr %l70
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 3
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load { i64, [3 x i64] }, ptr %l9
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t129, i64 %t130, { i64, [3 x i64] } %t131)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb43
bb33:
  %t135 = load ptr, ptr %l79, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 7
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t137, i64 %t138)
  store %"compiler/typed:Local" %t141, ptr %l83
  br label %bb34
bb34:
  %t142 = getelementptr %"compiler/typed:Local", ptr %l83, i32 0, i32 2
  %t143 = load i32, ptr %t142, !tbaa !23
  %t144 = load i32, ptr %l4, !tbaa !23
  %t145 = load ptr, ptr %l77, !tbaa !29
  %t148 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t145, i32 %t143, i32 %t144)
  store i1 %t148, ptr %l86
  br label %bb35
bb35:
  %t149 = load i1, ptr %l86, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb36, label %bb37
bb36:
  %t152 = load i32, ptr %l4, !tbaa !23
  %t153 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t156 = icmp ne i32 %t152, %t153
  store i1 %t156, ptr %l88, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb38
bb38:
  %t158 = load i1, ptr %l88, !tbaa !21
  br i1 %t158, label %bb39, label %bb40
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load i32, ptr %l2, !tbaa !23
  %t162 = load i64, ptr %l8, !tbaa !24
  %t163 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtBinding(ptr %v0, ptr %t159, %"compiler/source:Span" %t160, i32 %t161, i64 %t162, i32 %t163)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i64, ptr %l8, !tbaa !24
  %t171 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t169, i64 %t170, ptr %t171)
  br label %bb44
bb44:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l100, !tbaa !29
  %t176 = load ptr, ptr %l7, !tbaa !29
  store ptr %t176, ptr %l102, !tbaa !29
  %t178 = load ptr, ptr %l102, !tbaa !29
  %t179 = call ptr @__olang_scope_of(ptr %t178, ptr null)
  %t180 = call ptr @__olang_scope_hold(ptr %t179)
  %t181 = ptrtoint ptr %t180 to i64
  %t183 = inttoptr i64 %t181 to ptr
  %t184 = load ptr, ptr %l102, !tbaa !29
  %t185 = call i32 @compiler_2fcheck_2etypeOf(ptr %t183, ptr %t184)
  store i32 %t185, ptr %l104
  br label %bb45
bb45:
  %t186 = load ptr, ptr %l100, !tbaa !29
  %t187 = load i32, ptr %l104, !tbaa !23
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t186, i32 %t187)
  store i1 %t188, ptr %l105
  br label %bb46
bb46:
  %t189 = load i1, ptr %l105, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb47, label %bb48
bb47:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 2
  store ptr %t197, ptr %l110, !tbaa !29
  %t198 = load ptr, ptr %l7, !tbaa !29
  store ptr %t198, ptr %l112, !tbaa !29
  %t200 = load ptr, ptr %l112, !tbaa !29
  %t201 = call ptr @__olang_scope_of(ptr %t200, ptr null)
  %t202 = call ptr @__olang_scope_hold(ptr %t201)
  %t203 = ptrtoint ptr %t202 to i64
  %t205 = inttoptr i64 %t203 to ptr
  %t206 = load ptr, ptr %l112, !tbaa !29
  %t207 = call i32 @compiler_2fcheck_2etypeOf(ptr %t205, ptr %t206)
  store i32 %t207, ptr %l114
  br label %bb49
bb48:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb51
bb49:
  %t208 = load ptr, ptr %l110, !tbaa !29
  %t209 = load i32, ptr %l114, !tbaa !23
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t208, i32 %t209)
  store i1 %t210, ptr %l115
  br label %bb50
bb50:
  %t211 = load i1, ptr %l115, !tbaa !21
  store i1 %t211, ptr %l107, !tbaa !21
  br label %bb51
bb51:
  %t212 = load i1, ptr %l107, !tbaa !21
  br i1 %t212, label %bb52, label %bb53
bb52:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l7, !tbaa !29
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v0, ptr %v2, ptr %t213, ptr %t214)
  store ptr %t217, ptr %l118
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t218 = load ptr, ptr %l118, !tbaa !29
  store ptr %t218, ptr %l7, !tbaa !29
  br label %bb55
bb55:
  store ptr %a5, ptr %l119, !tbaa !29
  %t220 = load i64, ptr %l8, !tbaa !24
  %t222 = trunc i64 %t220 to i32
  %t224 = load ptr, ptr %l7, !tbaa !29
  store ptr %t224, ptr %l123, !tbaa !29
  %t225 = load ptr, ptr %l123, !tbaa !29
  %t226 = call ptr @__olang_scope_of(ptr %t225, ptr null)
  %t227 = call ptr @__olang_scope_hold(ptr %t226)
  %t228 = ptrtoint ptr %t227 to i64
  %t230 = inttoptr i64 %t228 to ptr
  %t232 = load ptr, ptr %l123, !tbaa !29
  %t233 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %t230, ptr %v2, i32 %t222, ptr %t232)
  store %"compiler/typed:Bind" %t233, ptr %l125
  br label %bb56
bb56:
  %t234 = load %"compiler/typed:Bind", ptr %l125
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/typed:Bind" %t234, ptr %t235
  %t236 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v2, ptr %v2, ptr %t236, ptr %t235)
  br label %bb57
bb57:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l1
  %t240 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t244 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t238, %"compiler/source:Span" %t239, i32 %t240, i64 1)
  store ptr %t244, ptr %l130
  br label %bb58
bb58:
  %t245 = load ptr, ptr %l130, !tbaa !29
  store ptr %t245, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:CaseDecl", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"compiler/source:Span", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:CaseDecl", ptr %t6, i32 0, i32 0
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:CaseDecl", ptr %t12, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %a0, i32 %t15)
  store { i64, ptr } %t18, ptr %l9
  br label %bb1
bb1:
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t22 = trunc i64 %t20 to i32
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t23, %t22
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t26, i32 %t25)
  store %"compiler/source:Span" %t28, ptr %l13
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, i32 }
  %l21 = alloca i64
  %l22 = alloca i32
  %l27 = alloca i1
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l43 = alloca i32
  %l48 = alloca i32
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l78 = alloca i1
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l86 = alloca i32
  %l93 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca %"compiler/typed:Item"
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca i32
  %l119 = alloca i32
  %l123 = alloca ptr
  %l125 = alloca %"compiler/typed:Item"
  %l130 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l156 = alloca i64
  %l160 = alloca ptr
  %l165 = alloca i32
  %l167 = alloca %"compiler/typed:Item"
  %l176 = alloca { i64, i32 }
  %l182 = alloca ptr
  %l184 = alloca ptr
  %l188 = alloca i1
  %l189 = alloca ptr
  %l192 = alloca %"compiler/typed:Item"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Path", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 1
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l29
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l29, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 4
  %t16 = getelementptr %"compiler/generic:Context", ptr %t15, i32 0, i32 2
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Path", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l33, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  %t24 = load i32, ptr %t23, !tbaa !33
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t16, i32 %t24)
  store i1 %t27, ptr %l35
  br label %bb4
bb4:
  %t28 = load i1, ptr %l35, !tbaa !21
  store i1 %t28, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l27, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l37, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t34)
  store ptr %t36, ptr %l39
  br label %bb8
bb7:
  br label %bb27
bb8:
  %t37 = load ptr, ptr %l39, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 4
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t41 = load ptr, ptr %l37, !tbaa !29
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v0, ptr %v1, ptr %t41, ptr %t39, ptr %t40)
  store i32 %t44, ptr %l43
  br label %bb9
bb9:
  %t45 = load i32, ptr %l43, !tbaa !23
  store i32 %t45, ptr %l3, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l48
  br label %bb10
bb10:
  %t56 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t58 = trunc i64 30 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l53, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l58
  br label %bb13
bb12:
  br label %bb22
bb13:
  %t77 = load ptr, ptr %l53, !tbaa !29
  %t78 = load i32, ptr %l58, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l59
  br label %bb14
bb14:
  %t80 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l66, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t94
  %t99 = load i32, ptr %t98, !tbaa !33
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryItems(ptr %v0, ptr %v2, ptr %t101, i32 %t99, ptr %t103)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t107 = load i64, ptr %l5, !tbaa !24
  %t110 = add i64 %t107, 1
  store i64 %t110, ptr %l5, !tbaa !24
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t115, i32 %t116)
  store i1 %t119, ptr %l78
  br label %bb23
bb23:
  %t120 = load i1, ptr %l78, !tbaa !21
  br i1 %t120, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l80, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t125)
  store ptr %t127, ptr %l82
  br label %bb28
bb28:
  %t128 = load ptr, ptr %l82, !tbaa !29
  %t130 = getelementptr %"compiler/check:frame", ptr %t128, i32 0, i32 4
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t132 = load ptr, ptr %l80, !tbaa !29
  %t135 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t132, ptr %t130, ptr %t131)
  store i32 %t135, ptr %l86
  br label %bb29
bb29:
  %t136 = load i32, ptr %l86, !tbaa !23
  store i32 %t136, ptr %l8, !tbaa !23
  %t137 = load i32, ptr %l8, !tbaa !23
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t141 = icmp ne i32 %t137, %t138
  br i1 %t141, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i32, ptr %l8, !tbaa !23
  %t150 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l93
  br label %bb32
bb31:
  br label %bb76
bb32:
  %t151 = load i1, ptr %l93, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t154 = load ptr, ptr %l2, !tbaa !29
  store ptr %t154, ptr %l95, !tbaa !29
  %t155 = load i32, ptr %l8, !tbaa !23
  %t157 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s8, i32 %t155, i64 -1)
  store %"compiler/typed:Item" %t157, ptr %l97
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t158 = load ptr, ptr %l95, !tbaa !29
  %t159 = load %"compiler/typed:Item", ptr %l97
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t158, %"compiler/typed:Item" %t159)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  %t160 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %l98
  br label %bb38
bb38:
  %t161 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %l9
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t166 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %s7, ptr %t165, i32 %t166, ptr %l9)
  br label %bb39
bb39:
  store ptr %l9, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb40
bb40:
  %t171 = load i64, ptr %l11, !tbaa !24
  store i64 %t171, ptr %l104, !tbaa !24
  %t172 = load ptr, ptr %l10, !tbaa !29
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s7, ptr %t172)
  store i64 %t174, ptr %l106
  br label %bb41
bb41:
  %t175 = load i64, ptr %l104, !tbaa !24
  %t176 = load i64, ptr %l106, !tbaa !24
  %t177 = icmp slt i64 %t175, %t176
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb42, label %bb43
bb42:
  br label %bb75
bb43:
  br label %bb44
bb44:
  %t181 = load ptr, ptr %l10, !tbaa !29
  %t182 = load i64, ptr %l11, !tbaa !24
  %t185 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s7, ptr %t181, i64 %t182)
  store i32 %t185, ptr %l111
  br label %bb45
bb45:
  %t186 = load i32, ptr %l111, !tbaa !23
  store i32 %t186, ptr %l12, !tbaa !23
  %t187 = load i32, ptr %l12, !tbaa !23
  %t188 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t191 = icmp eq i32 %t187, %t188
  br i1 %t191, label %bb46, label %bb47
bb46:
  br label %bb74
bb47:
  br label %bb48
bb48:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  %t199 = load i32, ptr %l12, !tbaa !23
  %t202 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t198, i32 %t199)
  store i32 %t202, ptr %l119
  br label %bb49
bb49:
  %t203 = load i32, ptr %l119, !range !{i32 0, i32 33}
  %t205 = trunc i64 28 to i32
  %t206 = icmp eq i32 %t203, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t210 = load ptr, ptr %l2, !tbaa !29
  store ptr %t210, ptr %l123, !tbaa !29
  %t211 = load i32, ptr %l12, !tbaa !23
  %t213 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s12, i32 %t211, i64 -1)
  store %"compiler/typed:Item" %t213, ptr %l125
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t214 = load ptr, ptr %l123, !tbaa !29
  %t215 = load %"compiler/typed:Item", ptr %l125
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t214, %"compiler/typed:Item" %t215)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s12)
  br label %bb74
bb54:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 2
  %t222 = load i32, ptr %l12, !tbaa !23
  %t225 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t221, i32 %t222)
  store i64 %t225, ptr %l130
  br label %bb55
bb55:
  %t226 = load i64, ptr %l130, !tbaa !65
  store i64 %t226, ptr %l13, !tbaa !65
  store i64 0, ptr %l14, !tbaa !24
  store i64 64, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t227 = load i64, ptr %l15, !tbaa !24
  %t228 = load i64, ptr %l14, !tbaa !24
  %t231 = icmp sgt i64 %t227, %t228
  br i1 %t231, label %bb56, label %bb57
bb56:
  %t233 = load i64, ptr %l16, !tbaa !24
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb61
bb58:
  %t237 = load i64, ptr %l15, !tbaa !24
  %t238 = load i64, ptr %l14, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t242 = load i64, ptr %l16, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = sub i64 %t245, 1
  %t248 = load i64, ptr %l16, !tbaa !24
  %t251 = sdiv i64 %t247, %t248
  store i64 %t251, ptr %l137, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb60
bb60:
  %t253 = load i64, ptr %l137, !tbaa !24
  store i64 %t253, ptr %l134, !tbaa !24
  br label %bb61
bb61:
  %t254 = load i64, ptr %l134, !tbaa !24
  store i64 %t254, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb62
bb62:
  %t255 = load i64, ptr %l18, !tbaa !24
  %t256 = load i64, ptr %l17, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb63, label %bb64
bb63:
  br label %bb73
bb64:
  br label %bb65
bb65:
  %t263 = load i64, ptr %l14, !tbaa !24
  %t264 = load i64, ptr %l18, !tbaa !24
  %t265 = load i64, ptr %l16, !tbaa !24
  %t268 = mul i64 %t264, %t265
  %t271 = add i64 %t263, %t268
  store i64 %t271, ptr %l19, !tbaa !24
  %t273 = load i64, ptr %l13, !tbaa !65
  %t274 = load i64, ptr %l19, !tbaa !24
  store i64 %t274, ptr %l156, !tbaa !24
  %t275 = load i64, ptr %l156, !tbaa !24
  %t276 = load i64, ptr %l156, !tbaa !24
  %t277 = shl i64 1, %t276
  %t280 = and i64 %t273, %t277
  %t282 = icmp ne i64 %t280, 0
  br i1 %t282, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s15
  %t284 = load ptr, ptr %l2, !tbaa !29
  store ptr %t284, ptr %l160, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %l12, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l165
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t295 = load i64, ptr %l19, !tbaa !24
  %t296 = load i32, ptr %l165, !tbaa !23
  %t298 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s15, i32 %t296, i64 %t295)
  store %"compiler/typed:Item" %t298, ptr %l167
  br label %bb69
bb69:
  %t299 = load ptr, ptr %l160, !tbaa !29
  %t300 = load %"compiler/typed:Item", ptr %l167
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t299, %"compiler/typed:Item" %t300)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s15)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t301 = load i64, ptr %l18, !tbaa !24
  %t304 = add i64 %t301, 1
  store i64 %t304, ptr %l18, !tbaa !24
  br label %bb62
bb73:
  br label %bb74
bb74:
  %t306 = load i64, ptr %l11, !tbaa !24
  %t309 = add i64 %t306, 1
  store i64 %t309, ptr %l11, !tbaa !24
  br label %bb40
bb75:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb76:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t315 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t311, ptr %t312)
  store { i64, i32 } %t315, ptr %l176
  br label %bb77
bb77:
  %t316 = load { i64, i32 }, ptr %l176
  store { i64, i32 } %t316, ptr %l20
  %t317 = getelementptr { i64, i32 }, ptr %l20, i32 0, i32 0
  %t318 = load i64, ptr %t317, !tbaa !24
  store i64 %t318, ptr %l21, !tbaa !24
  %t320 = getelementptr { i64, i32 }, ptr %l20, i32 0, i32 1
  %t321 = load i32, ptr %t320, !tbaa !23
  store i32 %t321, ptr %l22, !tbaa !23
  %t323 = load i64, ptr %l21, !tbaa !24
  %t325 = icmp slt i64 %t323, 0
  br i1 %t325, label %bb78, label %bb79
bb78:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/check:Checker", ptr %t327, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !29
  store ptr %t330, ptr %l182, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t331)
  store ptr %t333, ptr %l184
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t334 = load ptr, ptr %l184, !tbaa !29
  %t336 = getelementptr %"compiler/check:frame", ptr %t334, i32 0, i32 4
  %t337 = load ptr, ptr %l1, !tbaa !29
  %t338 = load ptr, ptr %l182, !tbaa !29
  %t341 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t338, ptr %t336, ptr %t337)
  store i1 %t341, ptr %l188
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb82:
  %t342 = load ptr, ptr %l2, !tbaa !29
  store ptr %t342, ptr %l189, !tbaa !29
  %t343 = load i32, ptr %l22, !tbaa !23
  %t344 = load i64, ptr %l21, !tbaa !24
  %t347 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t343, i64 %t344)
  store %"compiler/typed:Item" %t347, ptr %l192
  br label %bb83
bb83:
  %t348 = load ptr, ptr %l189, !tbaa !29
  %t349 = load %"compiler/typed:Item", ptr %l192
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t348, %"compiler/typed:Item" %t349)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %lp26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/diagmsg:Msg"
  %l57 = alloca i64
  %l61 = alloca i32
  %l68 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca i64
  %l86 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i64
  %l100 = alloca %"compiler/generic:Context"
  %l101 = alloca %"compiler/generic:Context"
  %l102 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca i64
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %l118 = alloca i64
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %l126 = alloca i64
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %l134 = alloca i64
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %l142 = alloca i64
  %l144 = alloca { i64, ptr }
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l151 = alloca %"compiler/generic:Context"
  %l165 = alloca ptr
  %l169 = alloca i32
  %l171 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l179 = alloca i64
  %l189 = alloca { i64, ptr }
  %l201 = alloca i1
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l211 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l222 = alloca i32
  %l225 = alloca { i64, ptr }
  %l228 = alloca ptr
  %l233 = alloca i32
  %l234 = alloca { i64, ptr }
  %l244 = alloca ptr
  %l246 = alloca %"compiler/source:Span"
  %l252 = alloca %"compiler/diagmsg:Msg"
  %l253 = alloca i64
  %l256 = alloca i64
  %l262 = alloca i64
  %l265 = alloca i64
  %l284 = alloca ptr
  %l287 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l293 = alloca ptr
  %l300 = alloca { i64, ptr }
  %l301 = alloca ptr
  %l303 = alloca %"compiler/source:Span"
  %l305 = alloca %"compiler/source:Span"
  %l306 = alloca i32
  %l310 = alloca %"compiler/typed:Make"
  %l319 = alloca { i64, ptr }
  %l320 = alloca %"compiler/typed:Block"
  %l322 = alloca ptr
  %l327 = alloca i1
  %l330 = alloca i1
  %l332 = alloca ptr
  %l336 = alloca i1
  %l338 = alloca i1
  %l340 = alloca ptr
  %l342 = alloca %"compiler/source:Span"
  %l343 = alloca %"compiler/diagmsg:Msg"
  %l344 = alloca i64
  %l346 = alloca ptr
  %l349 = alloca { i64, ptr }
  %l355 = alloca %"compiler/source:Span"
  %l356 = alloca i32
  %l359 = alloca i32
  %l360 = alloca { i64, ptr }
  %l365 = alloca i32
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t99 = alloca { i64, [2 x i64] }, align 8
  %t774 = alloca { i64, [3 x i64] }, align 8
  %t967 = alloca { i64, [5 x i64] }, align 8
  %t979 = alloca { i64, [3 x i64] }, align 8
  %t1084 = alloca { i64, [4 x i64] }, align 8
  %t1096 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Catch", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l30, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Catch", ptr %t16, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  store i1 %t23, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i1, ptr %l5, !tbaa !21
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l41, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l44, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l44, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i1, ptr %l5, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp eq i64 %t42, 0
  store i1 %t44, ptr %l49, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l49, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l52, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store %"compiler/source:Span" %t52, ptr %l55
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t53 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0)
  store %"compiler/diagmsg:Msg" %t53, ptr %l56
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l52, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l55
  %t56 = load %"compiler/diagmsg:Msg", ptr %l56
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t54, %"compiler/source:Span" %t55, %"compiler/diagmsg:Msg" %t56)
  store i64 %t57, ptr %l57
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb21:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l61, !tbaa !23
  br label %bb24
bb23:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t65, ptr %l61, !tbaa !23
  br label %bb24
bb24:
  %t67 = load i32, ptr %l61, !tbaa !23
  store i32 %t67, ptr %l6, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l6, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 0, i32 %t74, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t77, ptr %l68
  br label %bb25
bb25:
  %t78 = load i32, ptr %l68, !tbaa !23
  store i32 %t78, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t79)
  store ptr %t81, ptr %l70
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l70, !tbaa !29
  store ptr %t82, ptr %l8, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 21
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l73
  br label %bb27
bb27:
  %t88 = load i64, ptr %l73, !tbaa !24
  %t89 = sub i64 %t88, 1
  store i64 %t89, ptr %l9, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 0
  store i64 4, ptr %t100
  %t102 = insertvalue { i32 } undef, i32 %t97, 0
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  store { i32 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t99
  %t105 = load i32, ptr %l7, !tbaa !23
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Catch", ptr %t110, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t91, { i64, [2 x i64] } %t104, i32 %t105, i64 %t109, %"compiler/source:Span" %t113)
  store i64 %t119, ptr %l86
  br label %bb28
bb28:
  %t120 = load i64, ptr %l86, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 24
  %t124 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t123, i64 %t124, i64 1)
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/check:frame", ptr %t129, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = load i32, ptr %l6, !tbaa !23
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t127, i64 %t128, i64 %t132, i32 %t133, i32 0)
  store ptr %t138, ptr %l95
  br label %bb30
bb30:
  %t139 = load ptr, ptr %l95, !tbaa !29
  store ptr %t139, ptr %l11, !tbaa !29
  %t140 = load ptr, ptr %l11, !tbaa !29
  store ptr %t140, ptr %l96, !tbaa !29
  %t141 = call ptr @__olang_scope_hold(ptr %v0)
  %t142 = ptrtoint ptr %t141 to i64
  store i64 %t142, ptr %l97, !tbaa !24
  %t143 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t143, label %bb31, label %bb32
bb31:
  %t145 = call ptr @__olang_region_make(ptr %v0)
  %t146 = ptrtoint ptr %t145 to i64
  store i64 %t146, ptr %l97, !tbaa !24
  br label %bb32
bb32:
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = getelementptr %"compiler/check:frame", ptr %t147, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %t149, i64 160, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l101, ptr %l100, i64 160, i1 false)
  %t150 = load i64, ptr %l97
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = call ptr @__olang_scope_hold(ptr %t151)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l102, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t154, label %bb33, label %bb34
bb33:
  %t156 = load i64, ptr %l97
  %t157 = inttoptr i64 %t156 to ptr
  %t158 = call ptr @__olang_region_make_part(ptr %t157)
  %t159 = ptrtoint ptr %t158 to i64
  store i64 %t159, ptr %l102, !tbaa !24
  br label %bb34
bb34:
  %t160 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t161 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t160, i32 0, i32 0
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l104, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l105, !tbaa !24
  %t165 = load i64, ptr %l105, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l102
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l106, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = load i64, ptr %l105, !tbaa !24
  %t177 = mul i64 %t176, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t173, ptr %t175, i64 %t177, i1 false)
  %t178 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t179 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t180 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t179, i32 0, i32 0
  store { i64, ptr } %t178, ptr %t180, !tbaa !27
  %t181 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t181, label %bb35, label %bb36
bb35:
  %t183 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t184 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t183, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t188 = icmp eq i64 %t186, 0
  br i1 %t188, label %bb37, label %bb38
bb36:
  %t190 = load i64, ptr %l97
  %t191 = inttoptr i64 %t190 to ptr
  %t192 = call ptr @__olang_scope_hold(ptr %t191)
  %t193 = ptrtoint ptr %t192 to i64
  store i64 %t193, ptr %l110, !tbaa !24
  %t194 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t194, label %bb39, label %bb40
bb37:
  %t196 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t197 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t196, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t197, !tbaa !27
  br label %bb38
bb38:
  %t198 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t199 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t198, i32 0, i32 0
  %t200 = load i64, ptr %l102
  %t201 = inttoptr i64 %t200 to ptr
  %t202 = load { i64, ptr }, ptr %t199
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = call ptr @__olang_region_or(ptr %t203, ptr null)
  %t205 = icmp ne ptr %t204, null
  %t206 = select i1 %t205, ptr %t204, ptr null
  call void @__olang_region_settle_in(ptr %t201, ptr %t206)
  br label %bb36
bb39:
  %t207 = load i64, ptr %l97
  %t208 = inttoptr i64 %t207 to ptr
  %t209 = call ptr @__olang_region_make_part(ptr %t208)
  %t210 = ptrtoint ptr %t209 to i64
  store i64 %t210, ptr %l110, !tbaa !24
  br label %bb40
bb40:
  %t211 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t212 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t211, i32 0, i32 1
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l112, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  store i64 %t215, ptr %l113, !tbaa !24
  %t216 = load i64, ptr %l113, !tbaa !24
  %t217 = mul i64 %t216, 8
  %t218 = load i64, ptr %l110
  %t219 = inttoptr i64 %t218 to ptr
  %t220 = call ptr @__olang_held_alloc(ptr %t219, i64 %t217)
  %t221 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  store { i64, ptr } %t222, ptr %l114, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l113, !tbaa !24
  %t228 = mul i64 %t227, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t224, ptr %t226, i64 %t228, i1 false)
  %t229 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t230 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t231 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t230, i32 0, i32 1
  store { i64, ptr } %t229, ptr %t231, !tbaa !27
  %t232 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t232, label %bb41, label %bb42
bb41:
  %t234 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t235 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t234, i32 0, i32 1
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  %t239 = icmp eq i64 %t237, 0
  br i1 %t239, label %bb43, label %bb44
bb42:
  %t241 = load i64, ptr %l97
  %t242 = inttoptr i64 %t241 to ptr
  %t243 = call ptr @__olang_scope_hold(ptr %t242)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l118, !tbaa !24
  %t245 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t245, label %bb45, label %bb46
bb43:
  %t247 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t248 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t247, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t248, !tbaa !27
  br label %bb44
bb44:
  %t249 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t250 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t249, i32 0, i32 1
  %t251 = load i64, ptr %l110
  %t252 = inttoptr i64 %t251 to ptr
  %t253 = load { i64, ptr }, ptr %t250
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = call ptr @__olang_region_or(ptr %t254, ptr null)
  %t256 = icmp ne ptr %t255, null
  %t257 = select i1 %t256, ptr %t255, ptr null
  call void @__olang_region_settle_in(ptr %t252, ptr %t257)
  br label %bb42
bb45:
  %t258 = load i64, ptr %l97
  %t259 = inttoptr i64 %t258 to ptr
  %t260 = call ptr @__olang_region_make_part(ptr %t259)
  %t261 = ptrtoint ptr %t260 to i64
  store i64 %t261, ptr %l118, !tbaa !24
  br label %bb46
bb46:
  %t262 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t263 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t262, i32 0, i32 2
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l120, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l121, !tbaa !24
  %t267 = load i64, ptr %l121, !tbaa !24
  %t268 = mul i64 %t267, 8
  %t269 = load i64, ptr %l118
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = call ptr @__olang_held_alloc(ptr %t270, i64 %t268)
  %t272 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  store { i64, ptr } %t273, ptr %l122, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = load i64, ptr %l121, !tbaa !24
  %t279 = mul i64 %t278, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t275, ptr %t277, i64 %t279, i1 false)
  %t280 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t281 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t282 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t281, i32 0, i32 2
  store { i64, ptr } %t280, ptr %t282, !tbaa !27
  %t283 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t283, label %bb47, label %bb48
bb47:
  %t285 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t286 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t285, i32 0, i32 2
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 0
  %t290 = icmp eq i64 %t288, 0
  br i1 %t290, label %bb49, label %bb50
bb48:
  %t292 = load i64, ptr %l97
  %t293 = inttoptr i64 %t292 to ptr
  %t294 = call ptr @__olang_scope_hold(ptr %t293)
  %t295 = ptrtoint ptr %t294 to i64
  store i64 %t295, ptr %l126, !tbaa !24
  %t296 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t296, label %bb51, label %bb52
bb49:
  %t298 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t299 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t298, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t299, !tbaa !27
  br label %bb50
bb50:
  %t300 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t301 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t300, i32 0, i32 2
  %t302 = load i64, ptr %l118
  %t303 = inttoptr i64 %t302 to ptr
  %t304 = load { i64, ptr }, ptr %t301
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = call ptr @__olang_region_or(ptr %t305, ptr null)
  %t307 = icmp ne ptr %t306, null
  %t308 = select i1 %t307, ptr %t306, ptr null
  call void @__olang_region_settle_in(ptr %t303, ptr %t308)
  br label %bb48
bb51:
  %t309 = load i64, ptr %l97
  %t310 = inttoptr i64 %t309 to ptr
  %t311 = call ptr @__olang_region_make_part(ptr %t310)
  %t312 = ptrtoint ptr %t311 to i64
  store i64 %t312, ptr %l126, !tbaa !24
  br label %bb52
bb52:
  %t313 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t314 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t313, i32 0, i32 0
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  store { i64, ptr } %t315, ptr %l128, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l129, !tbaa !24
  %t318 = load i64, ptr %l129, !tbaa !24
  %t319 = mul i64 %t318, 8
  %t320 = load i64, ptr %l126
  %t321 = inttoptr i64 %t320 to ptr
  %t322 = call ptr @__olang_held_alloc(ptr %t321, i64 %t319)
  %t323 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  store { i64, ptr } %t324, ptr %l130, !tbaa !27
  %t325 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = load i64, ptr %l129, !tbaa !24
  %t330 = mul i64 %t329, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t326, ptr %t328, i64 %t330, i1 false)
  %t331 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t332 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t333 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t332, i32 0, i32 0
  store { i64, ptr } %t331, ptr %t333, !tbaa !27
  %t334 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t334, label %bb53, label %bb54
bb53:
  %t336 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t337 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t336, i32 0, i32 0
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  %t341 = icmp eq i64 %t339, 0
  br i1 %t341, label %bb55, label %bb56
bb54:
  %t343 = load i64, ptr %l97
  %t344 = inttoptr i64 %t343 to ptr
  %t345 = call ptr @__olang_scope_hold(ptr %t344)
  %t346 = ptrtoint ptr %t345 to i64
  store i64 %t346, ptr %l134, !tbaa !24
  %t347 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t347, label %bb57, label %bb58
bb55:
  %t349 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t350 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t349, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t350, !tbaa !27
  br label %bb56
bb56:
  %t351 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t352 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t351, i32 0, i32 0
  %t353 = load i64, ptr %l126
  %t354 = inttoptr i64 %t353 to ptr
  %t355 = load { i64, ptr }, ptr %t352
  %t356 = extractvalue { i64, ptr } %t355, 1
  %t357 = call ptr @__olang_region_or(ptr %t356, ptr null)
  %t358 = icmp ne ptr %t357, null
  %t359 = select i1 %t358, ptr %t357, ptr null
  call void @__olang_region_settle_in(ptr %t354, ptr %t359)
  br label %bb54
bb57:
  %t360 = load i64, ptr %l97
  %t361 = inttoptr i64 %t360 to ptr
  %t362 = call ptr @__olang_region_make_part(ptr %t361)
  %t363 = ptrtoint ptr %t362 to i64
  store i64 %t363, ptr %l134, !tbaa !24
  br label %bb58
bb58:
  %t364 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t365 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t364, i32 0, i32 1
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  store { i64, ptr } %t366, ptr %l136, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 0
  store i64 %t368, ptr %l137, !tbaa !24
  %t369 = load i64, ptr %l137, !tbaa !24
  %t370 = mul i64 %t369, 8
  %t371 = load i64, ptr %l134
  %t372 = inttoptr i64 %t371 to ptr
  %t373 = call ptr @__olang_held_alloc(ptr %t372, i64 %t370)
  %t374 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  store { i64, ptr } %t375, ptr %l138, !tbaa !27
  %t376 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !27
  %t380 = load i64, ptr %l137, !tbaa !24
  %t381 = mul i64 %t380, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t377, ptr %t379, i64 %t381, i1 false)
  %t382 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t383 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t384 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t383, i32 0, i32 1
  store { i64, ptr } %t382, ptr %t384, !tbaa !27
  %t385 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t385, label %bb59, label %bb60
bb59:
  %t387 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t388 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t387, i32 0, i32 1
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t392 = icmp eq i64 %t390, 0
  br i1 %t392, label %bb61, label %bb62
bb60:
  %t394 = load i64, ptr %l97
  %t395 = inttoptr i64 %t394 to ptr
  %t396 = call ptr @__olang_scope_hold(ptr %t395)
  %t397 = ptrtoint ptr %t396 to i64
  store i64 %t397, ptr %l142, !tbaa !24
  %t398 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t398, label %bb63, label %bb64
bb61:
  %t400 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t401 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t400, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t401, !tbaa !27
  br label %bb62
bb62:
  %t402 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t403 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t402, i32 0, i32 1
  %t404 = load i64, ptr %l134
  %t405 = inttoptr i64 %t404 to ptr
  %t406 = load { i64, ptr }, ptr %t403
  %t407 = extractvalue { i64, ptr } %t406, 1
  %t408 = call ptr @__olang_region_or(ptr %t407, ptr null)
  %t409 = icmp ne ptr %t408, null
  %t410 = select i1 %t409, ptr %t408, ptr null
  call void @__olang_region_settle_in(ptr %t405, ptr %t410)
  br label %bb60
bb63:
  %t411 = load i64, ptr %l97
  %t412 = inttoptr i64 %t411 to ptr
  %t413 = call ptr @__olang_region_make_part(ptr %t412)
  %t414 = ptrtoint ptr %t413 to i64
  store i64 %t414, ptr %l142, !tbaa !24
  br label %bb64
bb64:
  %t415 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t416 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t415, i32 0, i32 2
  %t417 = load { i64, ptr }, ptr %t416, !tbaa !27
  store { i64, ptr } %t417, ptr %l144, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t418, 0
  store i64 %t419, ptr %l145, !tbaa !24
  %t420 = load i64, ptr %l145, !tbaa !24
  %t421 = mul i64 %t420, 8
  %t422 = load i64, ptr %l142
  %t423 = inttoptr i64 %t422 to ptr
  %t424 = call ptr @__olang_held_alloc(ptr %t423, i64 %t421)
  %t425 = insertvalue { i64, ptr } undef, i64 %t420, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  store { i64, ptr } %t426, ptr %l146, !tbaa !27
  %t427 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = load i64, ptr %l145, !tbaa !24
  %t432 = mul i64 %t431, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t428, ptr %t430, i64 %t432, i1 false)
  %t433 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t434 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t435 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t434, i32 0, i32 2
  store { i64, ptr } %t433, ptr %t435, !tbaa !27
  %t436 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t436, label %bb65, label %bb66
bb65:
  %t438 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t439 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t438, i32 0, i32 2
  %t440 = load { i64, ptr }, ptr %t439, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 0
  %t443 = icmp eq i64 %t441, 0
  br i1 %t443, label %bb67, label %bb68
bb66:
  %t445 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t445, label %bb69, label %bb70
bb67:
  %t447 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t448 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t447, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t448, !tbaa !27
  br label %bb68
bb68:
  %t449 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t450 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t449, i32 0, i32 2
  %t451 = load i64, ptr %l142
  %t452 = inttoptr i64 %t451 to ptr
  %t453 = load { i64, ptr }, ptr %t450
  %t454 = extractvalue { i64, ptr } %t453, 1
  %t455 = call ptr @__olang_region_or(ptr %t454, ptr null)
  %t456 = icmp ne ptr %t455, null
  %t457 = select i1 %t456, ptr %t455, ptr null
  call void @__olang_region_settle_in(ptr %t452, ptr %t457)
  br label %bb66
bb69:
  %t458 = load i64, ptr %l97
  %t459 = inttoptr i64 %t458 to ptr
  %t460 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t461 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t460, i32 0, i32 2
  %t462 = load { i64, ptr }, ptr %t461
  %t463 = extractvalue { i64, ptr } %t462, 1
  %t464 = call ptr @__olang_region_or(ptr %t463, ptr null)
  %t465 = call ptr @__olang_region_home(ptr %t464)
  %t466 = icmp ne ptr %t465, null
  %t467 = select i1 %t466, ptr %t465, ptr null
  %t468 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t469 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t468, i32 0, i32 1
  %t470 = load { i64, ptr }, ptr %t469
  %t471 = extractvalue { i64, ptr } %t470, 1
  %t472 = call ptr @__olang_region_or(ptr %t471, ptr null)
  %t473 = call ptr @__olang_region_home(ptr %t472)
  %t474 = icmp ne ptr %t473, null
  %t475 = select i1 %t474, ptr %t473, ptr %t467
  %t476 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 3
  %t477 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t476, i32 0, i32 0
  %t478 = load { i64, ptr }, ptr %t477
  %t479 = extractvalue { i64, ptr } %t478, 1
  %t480 = call ptr @__olang_region_or(ptr %t479, ptr null)
  %t481 = call ptr @__olang_region_home(ptr %t480)
  %t482 = icmp ne ptr %t481, null
  %t483 = select i1 %t482, ptr %t481, ptr %t475
  %t484 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t485 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t484, i32 0, i32 2
  %t486 = load { i64, ptr }, ptr %t485
  %t487 = extractvalue { i64, ptr } %t486, 1
  %t488 = call ptr @__olang_region_or(ptr %t487, ptr null)
  %t489 = call ptr @__olang_region_home(ptr %t488)
  %t490 = icmp ne ptr %t489, null
  %t491 = select i1 %t490, ptr %t489, ptr %t483
  %t492 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t493 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t492, i32 0, i32 1
  %t494 = load { i64, ptr }, ptr %t493
  %t495 = extractvalue { i64, ptr } %t494, 1
  %t496 = call ptr @__olang_region_or(ptr %t495, ptr null)
  %t497 = call ptr @__olang_region_home(ptr %t496)
  %t498 = icmp ne ptr %t497, null
  %t499 = select i1 %t498, ptr %t497, ptr %t491
  %t500 = getelementptr %"compiler/generic:Context", ptr %l101, i32 0, i32 2
  %t501 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t500, i32 0, i32 0
  %t502 = load { i64, ptr }, ptr %t501
  %t503 = extractvalue { i64, ptr } %t502, 1
  %t504 = call ptr @__olang_region_or(ptr %t503, ptr null)
  %t505 = call ptr @__olang_region_home(ptr %t504)
  %t506 = icmp ne ptr %t505, null
  %t507 = select i1 %t506, ptr %t505, ptr %t499
  call void @__olang_region_settle_in(ptr %t459, ptr %t507)
  br label %bb70
bb70:
  %t508 = load ptr, ptr %l96, !tbaa !29
  %t509 = getelementptr %"compiler/check:frame", ptr %t508, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l151, ptr %t509, i64 160, i1 false)
  %t510 = load ptr, ptr %l96, !tbaa !29
  %t511 = getelementptr %"compiler/check:frame", ptr %t510, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t511, ptr %l101, i64 160, i1 false)
  %t512 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t512, label %bb71, label %bb72
bb71:
  %t514 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 3
  %t515 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t514, i32 0, i32 2
  %t516 = load { i64, ptr }, ptr %t515
  %t517 = extractvalue { i64, ptr } %t516, 1
  %t518 = call ptr @__olang_region_or(ptr %t517, ptr null)
  %t519 = call ptr @__olang_region_home(ptr %t518)
  %t520 = icmp ne ptr %t519, null
  %t521 = select i1 %t520, ptr %t519, ptr null
  %t522 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 3
  %t523 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t522, i32 0, i32 1
  %t524 = load { i64, ptr }, ptr %t523
  %t525 = extractvalue { i64, ptr } %t524, 1
  %t526 = call ptr @__olang_region_or(ptr %t525, ptr null)
  %t527 = call ptr @__olang_region_home(ptr %t526)
  %t528 = icmp ne ptr %t527, null
  %t529 = select i1 %t528, ptr %t527, ptr %t521
  %t530 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 3
  %t531 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t530, i32 0, i32 0
  %t532 = load { i64, ptr }, ptr %t531
  %t533 = extractvalue { i64, ptr } %t532, 1
  %t534 = call ptr @__olang_region_or(ptr %t533, ptr null)
  %t535 = call ptr @__olang_region_home(ptr %t534)
  %t536 = icmp ne ptr %t535, null
  %t537 = select i1 %t536, ptr %t535, ptr %t529
  %t538 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 2
  %t539 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t538, i32 0, i32 2
  %t540 = load { i64, ptr }, ptr %t539
  %t541 = extractvalue { i64, ptr } %t540, 1
  %t542 = call ptr @__olang_region_or(ptr %t541, ptr null)
  %t543 = call ptr @__olang_region_home(ptr %t542)
  %t544 = icmp ne ptr %t543, null
  %t545 = select i1 %t544, ptr %t543, ptr %t537
  %t546 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 2
  %t547 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t546, i32 0, i32 1
  %t548 = load { i64, ptr }, ptr %t547
  %t549 = extractvalue { i64, ptr } %t548, 1
  %t550 = call ptr @__olang_region_or(ptr %t549, ptr null)
  %t551 = call ptr @__olang_region_home(ptr %t550)
  %t552 = icmp ne ptr %t551, null
  %t553 = select i1 %t552, ptr %t551, ptr %t545
  %t554 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 2
  %t555 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t554, i32 0, i32 0
  %t556 = load { i64, ptr }, ptr %t555
  %t557 = extractvalue { i64, ptr } %t556, 1
  %t558 = call ptr @__olang_region_or(ptr %t557, ptr null)
  %t559 = call ptr @__olang_region_home(ptr %t558)
  %t560 = icmp ne ptr %t559, null
  %t561 = select i1 %t560, ptr %t559, ptr %t553
  call void @__olang_region_drop(ptr %t561)
  store %"compiler/generic:Context" zeroinitializer, ptr %l151
  br label %bb72
bb72:
  %t562 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e2
  br i1 %t562, label %bb73, label %bb74
bb73:
  %t564 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 2
  %t565 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t564, i32 0, i32 2
  %t566 = load { i64, ptr }, ptr %t565
  %t567 = extractvalue { i64, ptr } %t566, 1
  %t568 = call ptr @__olang_region_or(ptr %t567, ptr null)
  %t569 = call ptr @__olang_region_home(ptr %t568)
  %t570 = icmp ne ptr %t569, null
  %t571 = select i1 %t570, ptr %t569, ptr null
  %t572 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t564, i32 0, i32 1
  %t573 = load { i64, ptr }, ptr %t572
  %t574 = extractvalue { i64, ptr } %t573, 1
  %t575 = call ptr @__olang_region_or(ptr %t574, ptr null)
  %t576 = call ptr @__olang_region_home(ptr %t575)
  %t577 = icmp ne ptr %t576, null
  %t578 = select i1 %t577, ptr %t576, ptr %t571
  %t579 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t564, i32 0, i32 0
  %t580 = load { i64, ptr }, ptr %t579
  %t581 = extractvalue { i64, ptr } %t580, 1
  %t582 = call ptr @__olang_region_or(ptr %t581, ptr null)
  %t583 = call ptr @__olang_region_home(ptr %t582)
  %t584 = icmp ne ptr %t583, null
  %t585 = select i1 %t584, ptr %t583, ptr %t578
  call void @__olang_region_drop(ptr %t585)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t564
  br label %bb74
bb74:
  %t586 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e3
  br i1 %t586, label %bb75, label %bb76
bb75:
  %t588 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 3
  %t589 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t588, i32 0, i32 2
  %t590 = load { i64, ptr }, ptr %t589
  %t591 = extractvalue { i64, ptr } %t590, 1
  %t592 = call ptr @__olang_region_or(ptr %t591, ptr null)
  %t593 = call ptr @__olang_region_home(ptr %t592)
  %t594 = icmp ne ptr %t593, null
  %t595 = select i1 %t594, ptr %t593, ptr null
  %t596 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t588, i32 0, i32 1
  %t597 = load { i64, ptr }, ptr %t596
  %t598 = extractvalue { i64, ptr } %t597, 1
  %t599 = call ptr @__olang_region_or(ptr %t598, ptr null)
  %t600 = call ptr @__olang_region_home(ptr %t599)
  %t601 = icmp ne ptr %t600, null
  %t602 = select i1 %t601, ptr %t600, ptr %t595
  %t603 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t588, i32 0, i32 0
  %t604 = load { i64, ptr }, ptr %t603
  %t605 = extractvalue { i64, ptr } %t604, 1
  %t606 = call ptr @__olang_region_or(ptr %t605, ptr null)
  %t607 = call ptr @__olang_region_home(ptr %t606)
  %t608 = icmp ne ptr %t607, null
  %t609 = select i1 %t608, ptr %t607, ptr %t602
  call void @__olang_region_drop(ptr %t609)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t588
  br label %bb76
bb76:
  %t610 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t610, label %bb77, label %bb78
bb77:
  %t612 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 2
  %t613 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t612, i32 0, i32 0
  %t614 = load { i64, ptr }, ptr %t613
  %t615 = extractvalue { i64, ptr } %t614, 0
  %t616 = extractvalue { i64, ptr } %t614, 1
  call void @__olang_region_release_part(ptr %t616, i64 %t615)
  store { i64, ptr } zeroinitializer, ptr %t613
  br label %bb78
bb78:
  %t617 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t617, label %bb79, label %bb80
bb79:
  %t619 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 2
  %t620 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t619, i32 0, i32 1
  %t621 = load { i64, ptr }, ptr %t620
  %t622 = extractvalue { i64, ptr } %t621, 0
  %t623 = extractvalue { i64, ptr } %t621, 1
  call void @__olang_region_release_part(ptr %t623, i64 %t622)
  store { i64, ptr } zeroinitializer, ptr %t620
  br label %bb80
bb80:
  %t624 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t624, label %bb81, label %bb82
bb81:
  %t626 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 2
  %t627 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t626, i32 0, i32 2
  %t628 = load { i64, ptr }, ptr %t627
  %t629 = extractvalue { i64, ptr } %t628, 0
  %t630 = extractvalue { i64, ptr } %t628, 1
  call void @__olang_region_release_part(ptr %t630, i64 %t629)
  store { i64, ptr } zeroinitializer, ptr %t627
  br label %bb82
bb82:
  %t631 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t631, label %bb83, label %bb84
bb83:
  %t633 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 3
  %t634 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t633, i32 0, i32 0
  %t635 = load { i64, ptr }, ptr %t634
  %t636 = extractvalue { i64, ptr } %t635, 0
  %t637 = extractvalue { i64, ptr } %t635, 1
  call void @__olang_region_release_part(ptr %t637, i64 %t636)
  store { i64, ptr } zeroinitializer, ptr %t634
  br label %bb84
bb84:
  %t638 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t638, label %bb85, label %bb86
bb85:
  %t640 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 3
  %t641 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t640, i32 0, i32 1
  %t642 = load { i64, ptr }, ptr %t641
  %t643 = extractvalue { i64, ptr } %t642, 0
  %t644 = extractvalue { i64, ptr } %t642, 1
  call void @__olang_region_release_part(ptr %t644, i64 %t643)
  store { i64, ptr } zeroinitializer, ptr %t641
  br label %bb86
bb86:
  %t645 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t645, label %bb87, label %bb88
bb87:
  %t647 = getelementptr %"compiler/generic:Context", ptr %l151, i32 0, i32 3
  %t648 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t647, i32 0, i32 2
  %t649 = load { i64, ptr }, ptr %t648
  %t650 = extractvalue { i64, ptr } %t649, 0
  %t651 = extractvalue { i64, ptr } %t649, 1
  call void @__olang_region_release_part(ptr %t651, i64 %t650)
  store { i64, ptr } zeroinitializer, ptr %t648
  br label %bb88
bb88:
  %t652 = load ptr, ptr %l11, !tbaa !29
  %t653 = load i64, ptr %l9, !tbaa !24
  %t656 = getelementptr %"compiler/check:frame", ptr %t652, i32 0, i32 19
  store i64 %t653, ptr %t656, !tbaa !24
  %t657 = load ptr, ptr %l11, !tbaa !29
  %t659 = getelementptr %"compiler/check:frame", ptr %t657, i32 0, i32 32
  store i1 true, ptr %t659, !tbaa !21
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t662 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t660)
  store ptr %t662, ptr %l165
  br label %bb89
bb89:
  %t663 = load ptr, ptr %l1, !tbaa !29
  %t665 = getelementptr %"compiler/ast:Catch", ptr %t663, i32 0, i32 0
  %t666 = load %"compiler/source:Span", ptr %t665
  %t667 = load ptr, ptr %l165, !tbaa !29
  %t670 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t667, i32 -1, i32 0, %"compiler/source:Span" %t666)
  store i32 %t670, ptr %l169
  br label %bb90
bb90:
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t673 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t671)
  store ptr %t673, ptr %l171
  br label %bb91
bb91:
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t676 = getelementptr %"compiler/check:Checker", ptr %t674, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !29
  %t678 = load i32, ptr %l7, !tbaa !23
  %t681 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t677, i32 %t678)
  store { i64, ptr } %t681, ptr %l175
  br label %bb92
bb92:
  %t682 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t683 = load ptr, ptr %l171, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t683, { i64, ptr } %t682)
  br label %bb93
bb93:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t687 = getelementptr %"compiler/check:Checker", ptr %t685, i32 0, i32 48
  %t689 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t687)
  store i64 %t689, ptr %l179
  br label %bb94
bb94:
  %t690 = load i64, ptr %l179, !tbaa !24
  store i64 %t690, ptr %l12, !tbaa !24
  %t691 = load i1, ptr %l4, !tbaa !21
  br i1 %t691, label %bb95, label %bb96
bb95:
  %t693 = load ptr, ptr %l1, !tbaa !29
  %t695 = getelementptr %"compiler/ast:Catch", ptr %t693, i32 0, i32 2
  %t696 = load { i64, ptr }, ptr %t695, !tbaa !27
  store { i64, ptr } %t696, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t698 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t698, 0
  store i64 %t700, ptr %l15, !tbaa !24
  br label %bb97
bb96:
  br label %bb104
bb97:
  %t702 = load i64, ptr %l14, !tbaa !24
  %t703 = load i64, ptr %l15, !tbaa !24
  %t706 = icmp slt i64 %t702, %t703
  %t708 = xor i1 %t706, true
  br i1 %t708, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t710 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t710, ptr %l189, !tbaa !27
  %t711 = load i64, ptr %l14, !tbaa !24
  %t713 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !27
  %t715 = getelementptr ptr, ptr %t714, i64 %t711
  %t716 = load ptr, ptr %t715, !tbaa !39
  %t718 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t718, ptr %t716)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t723 = load i64, ptr %l14, !tbaa !24
  %t726 = add i64 %t723, 1
  store i64 %t726, ptr %l14, !tbaa !24
  br label %bb97
bb103:
  br label %bb104
bb104:
  %t728 = load i1, ptr %l5, !tbaa !21
  br i1 %t728, label %bb105, label %bb106
bb105:
  %t730 = load i64, ptr %l3, !tbaa !24
  %t732 = icmp eq i64 %t730, 1
  br i1 %t732, label %bb107, label %bb108
bb106:
  br label %bb148
bb107:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb109
bb108:
  %t734 = load ptr, ptr %l1, !tbaa !29
  %t736 = getelementptr %"compiler/ast:Catch", ptr %t734, i32 0, i32 3
  %t737 = load { i64, ptr }, ptr %t736, !tbaa !27
  %t739 = extractvalue { i64, ptr } %t737, 0
  %t741 = icmp eq i64 %t739, 1
  store i1 %t741, ptr %l201, !tbaa !21
  br label %bb109
bb109:
  %t743 = load i1, ptr %l201, !tbaa !21
  br i1 %t743, label %bb110, label %bb111
bb110:
  %t744 = load ptr, ptr %l0, !tbaa !29
  store ptr %t744, ptr %l206, !tbaa !29
  %t745 = load ptr, ptr %l1, !tbaa !29
  %t747 = getelementptr %"compiler/ast:Catch", ptr %t745, i32 0, i32 0
  %t748 = load %"compiler/source:Span", ptr %t747
  store %"compiler/source:Span" %t748, ptr %l208
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load ptr, ptr %l1, !tbaa !29
  %t752 = getelementptr %"compiler/ast:Catch", ptr %t750, i32 0, i32 3
  %t753 = load { i64, ptr }, ptr %t752, !tbaa !27
  store { i64, ptr } %t753, ptr %l211, !tbaa !27
  %t754 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !27
  %t756 = getelementptr ptr, ptr %t755, i64 0
  %t757 = load ptr, ptr %t756, !tbaa !39
  %t758 = load i32, ptr %l2, !tbaa !23
  %t762 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v0, ptr %t749, ptr %t757, i32 %t758)
  store ptr %t762, ptr %l214
  br label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s9
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = getelementptr %"compiler/check:Checker", ptr %t763, i32 0, i32 1
  %t766 = load ptr, ptr %t765, !tbaa !29
  %t768 = getelementptr %"compiler/generic:Program", ptr %t766, i32 0, i32 2
  %t769 = load i32, ptr %l2, !tbaa !23
  %t772 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t768, i32 %t769)
  store i32 %t772, ptr %l222
  br label %bb114
bb112:
  %t773 = load ptr, ptr %l214, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t774
  %t775 = getelementptr { i64, [3 x i64] }, ptr %t774, i32 0, i32 0
  store i64 6, ptr %t775
  %t776 = load %"compiler/source:Span", ptr %l208
  %t777 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t776, 0
  %t779 = insertvalue { %"compiler/source:Span", ptr } %t777, ptr %t773, 1
  %t780 = getelementptr { i64, [3 x i64] }, ptr %t774, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t779, ptr %t780
  %t781 = load { i64, [3 x i64] }, ptr %t774
  %t783 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t781, ptr %t783
  %t784 = load ptr, ptr %l206, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t784, ptr %t783)
  br label %bb113
bb113:
  br label %bb147
bb114:
  %t786 = load i32, ptr %l222, !range !{i32 0, i32 33}
  %t788 = trunc i64 22 to i32
  %t789 = icmp eq i32 %t786, %t788
  br i1 %t789, label %bb115, label %bb116
bb115:
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t793 = getelementptr %"compiler/check:Checker", ptr %t791, i32 0, i32 1
  %t794 = load ptr, ptr %t793, !tbaa !29
  %t796 = getelementptr %"compiler/generic:Program", ptr %t794, i32 0, i32 2
  store ptr %t796, ptr %l228, !tbaa !29
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = getelementptr %"compiler/check:Checker", ptr %t797, i32 0, i32 1
  %t800 = load ptr, ptr %t799, !tbaa !29
  %t802 = getelementptr %"compiler/generic:Program", ptr %t800, i32 0, i32 2
  %t803 = load i32, ptr %l2, !tbaa !23
  %t806 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t802, i32 %t803)
  store i32 %t806, ptr %l233
  br label %bb117
bb116:
  %t807 = icmp sge i64 0, 0
  br i1 %t807, label %bb119, label %bb120
bb117:
  %t809 = load ptr, ptr %l228, !tbaa !29
  %t810 = load i32, ptr %l233, !tbaa !23
  %t811 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s9, ptr %t809, i32 %t810)
  store { i64, ptr } %t811, ptr %l234
  br label %bb118
bb118:
  %t812 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t812, ptr %l225, !tbaa !27
  br label %bb123
bb119:
  %t813 = icmp sle i64 0, 2305843009213693951
  br i1 %t813, label %bb121, label %bb122
bb120:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb121:
  %t815 = mul i64 0, 4
  %t816 = insertvalue { i64, ptr } undef, i64 0, 0
  %t817 = insertvalue { i64, ptr } %t816, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t817, ptr %l225, !tbaa !27
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb123:
  %t819 = load { i64, ptr }, ptr %l225, !tbaa !27
  store { i64, ptr } %t819, ptr %l17, !tbaa !27
  %t820 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t822 = extractvalue { i64, ptr } %t820, 0
  %t823 = load ptr, ptr %l1, !tbaa !29
  %t825 = getelementptr %"compiler/ast:Catch", ptr %t823, i32 0, i32 3
  %t826 = load { i64, ptr }, ptr %t825, !tbaa !27
  %t828 = extractvalue { i64, ptr } %t826, 0
  %t831 = icmp ne i64 %t822, %t828
  br i1 %t831, label %bb124, label %bb125
bb124:
  %t833 = load ptr, ptr %l0, !tbaa !29
  store ptr %t833, ptr %l244, !tbaa !29
  %t834 = load ptr, ptr %l1, !tbaa !29
  %t836 = getelementptr %"compiler/ast:Catch", ptr %t834, i32 0, i32 0
  %t837 = load %"compiler/source:Span", ptr %t836
  store %"compiler/source:Span" %t837, ptr %l246
  %t838 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t840 = extractvalue { i64, ptr } %t838, 0
  %t841 = load ptr, ptr %l1, !tbaa !29
  %t843 = getelementptr %"compiler/ast:Catch", ptr %t841, i32 0, i32 3
  %t844 = load { i64, ptr }, ptr %t843, !tbaa !27
  %t846 = extractvalue { i64, ptr } %t844, 0
  %t849 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %t840, i64 %t846)
  store %"compiler/diagmsg:Msg" %t849, ptr %l252
  br label %bb126
bb125:
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/check:Checker", ptr %t850, i32 0, i32 47
  %t854 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t852)
  store i64 %t854, ptr %l256
  br label %bb128
bb126:
  %t855 = load ptr, ptr %l244, !tbaa !29
  %t856 = load %"compiler/source:Span", ptr %l246
  %t857 = load %"compiler/diagmsg:Msg", ptr %l252
  %t858 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t855, %"compiler/source:Span" %t856, %"compiler/diagmsg:Msg" %t857)
  store i64 %t858, ptr %l253
  br label %bb127
bb127:
  br label %bb146
bb128:
  %t859 = load i64, ptr %l256, !tbaa !24
  store i64 %t859, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t860 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t862 = extractvalue { i64, ptr } %t860, 0
  store i64 %t862, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t864 = load i64, ptr %l20, !tbaa !24
  %t865 = load i64, ptr %l19, !tbaa !24
  %t868 = icmp sgt i64 %t864, %t865
  br i1 %t868, label %bb129, label %bb130
bb129:
  %t870 = load i64, ptr %l21, !tbaa !24
  %t872 = icmp sgt i64 %t870, 0
  br i1 %t872, label %bb131, label %bb132
bb130:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb134
bb131:
  %t874 = load i64, ptr %l20, !tbaa !24
  %t875 = load i64, ptr %l19, !tbaa !24
  %t878 = sub i64 %t874, %t875
  %t879 = load i64, ptr %l21, !tbaa !24
  %t882 = add i64 %t878, %t879
  %t884 = sub i64 %t882, 1
  %t885 = load i64, ptr %l21, !tbaa !24
  %t888 = sdiv i64 %t884, %t885
  store i64 %t888, ptr %l265, !tbaa !24
  br label %bb133
bb132:
  store i64 0, ptr %l265, !tbaa !24
  br label %bb133
bb133:
  %t890 = load i64, ptr %l265, !tbaa !24
  store i64 %t890, ptr %l262, !tbaa !24
  br label %bb134
bb134:
  %t891 = load i64, ptr %l262, !tbaa !24
  store i64 %t891, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb135
bb135:
  %t892 = load i64, ptr %l23, !tbaa !24
  %t893 = load i64, ptr %l22, !tbaa !24
  %t896 = icmp slt i64 %t892, %t893
  %t898 = xor i1 %t896, true
  br i1 %t898, label %bb136, label %bb137
bb136:
  br label %bb142
bb137:
  br label %bb138
bb138:
  %t900 = load i64, ptr %l19, !tbaa !24
  %t901 = load i64, ptr %l23, !tbaa !24
  %t902 = load i64, ptr %l21, !tbaa !24
  %t905 = mul i64 %t901, %t902
  %t908 = add i64 %t900, %t905
  store i64 %t908, ptr %l24, !tbaa !24
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t912 = getelementptr %"compiler/check:Checker", ptr %t910, i32 0, i32 47
  store ptr %t912, ptr %l284, !tbaa !29
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t914 = load ptr, ptr %l1, !tbaa !29
  %t916 = getelementptr %"compiler/ast:Catch", ptr %t914, i32 0, i32 3
  %t917 = load { i64, ptr }, ptr %t916, !tbaa !27
  store { i64, ptr } %t917, ptr %l287, !tbaa !27
  %t918 = load i64, ptr %l24, !tbaa !24
  %t920 = getelementptr { i64, ptr }, ptr %l287, i32 0, i32 1
  %t921 = load ptr, ptr %t920, !tbaa !27
  %t922 = getelementptr ptr, ptr %t921, i64 %t918
  %t923 = load ptr, ptr %t922, !tbaa !39
  %t924 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t924, ptr %l290, !tbaa !27
  %t925 = load i64, ptr %l24, !tbaa !24
  %t927 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t928 = load ptr, ptr %t927, !tbaa !27
  %t929 = getelementptr i32, ptr %t928, i64 %t925
  %t930 = load i32, ptr %t929, !tbaa !33
  %t934 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v0, ptr %t913, ptr %t923, i32 %t930)
  store ptr %t934, ptr %l293
  br label %bb139
bb139:
  %t935 = load ptr, ptr %l284, !tbaa !29
  %t936 = load ptr, ptr %l293, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t935, ptr %t936)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t937 = load i64, ptr %l23, !tbaa !24
  %t940 = add i64 %t937, 1
  store i64 %t940, ptr %l23, !tbaa !24
  br label %bb135
bb142:
  %t942 = load ptr, ptr %l0, !tbaa !29
  %t944 = getelementptr %"compiler/check:Checker", ptr %t942, i32 0, i32 47
  %t945 = load i64, ptr %l18, !tbaa !24
  %t948 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t944, i64 %t945)
  store { i64, ptr } %t948, ptr %l300
  br label %bb143
bb143:
  %t949 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t950 = load ptr, ptr %l0, !tbaa !29
  store ptr %t950, ptr %l301, !tbaa !29
  %t951 = load ptr, ptr %l1, !tbaa !29
  %t953 = getelementptr %"compiler/ast:Catch", ptr %t951, i32 0, i32 0
  %t954 = load %"compiler/source:Span", ptr %t953
  store %"compiler/source:Span" %t954, ptr %l303
  %t955 = load ptr, ptr %l1, !tbaa !29
  %t957 = getelementptr %"compiler/ast:Catch", ptr %t955, i32 0, i32 0
  %t958 = load %"compiler/source:Span", ptr %t957
  store %"compiler/source:Span" %t958, ptr %l305
  %t959 = load i32, ptr %l2, !tbaa !23
  store i32 %t959, ptr %l306, !tbaa !23
  %t964 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t949, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t964, ptr %l310
  br label %bb144
bb144:
  %t965 = load %"compiler/typed:Make", ptr %l310
  %t966 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t965, ptr %t966
  store { i64, [5 x i64] } zeroinitializer, ptr %t967
  %t968 = getelementptr { i64, [5 x i64] }, ptr %t967, i32 0, i32 0
  store i64 7, ptr %t968
  %t969 = load %"compiler/source:Span", ptr %l305
  %t970 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t969, 0
  %t971 = load i32, ptr %l306, !tbaa !23
  %t972 = insertvalue { %"compiler/source:Span", i32, ptr } %t970, i32 %t971, 1
  %t974 = insertvalue { %"compiler/source:Span", i32, ptr } %t972, ptr %t966, 2
  %t975 = getelementptr { i64, [5 x i64] }, ptr %t967, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t974, ptr %t975
  %t976 = load { i64, [5 x i64] }, ptr %t967
  %t978 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t976, ptr %t978
  store { i64, [3 x i64] } zeroinitializer, ptr %t979
  %t980 = getelementptr { i64, [3 x i64] }, ptr %t979, i32 0, i32 0
  store i64 6, ptr %t980
  %t981 = load %"compiler/source:Span", ptr %l303
  %t982 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t981, 0
  %t984 = insertvalue { %"compiler/source:Span", ptr } %t982, ptr %t978, 1
  %t985 = getelementptr { i64, [3 x i64] }, ptr %t979, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t984, ptr %t985
  %t986 = load { i64, [3 x i64] }, ptr %t979
  %t988 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t986, ptr %t988
  %t989 = load ptr, ptr %l301, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t989, ptr %t988)
  br label %bb145
bb145:
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s9)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t991 = load ptr, ptr %l0, !tbaa !29
  %t993 = getelementptr %"compiler/check:Checker", ptr %t991, i32 0, i32 48
  %t994 = load i64, ptr %l12, !tbaa !24
  %t997 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t993, i64 %t994)
  store { i64, ptr } %t997, ptr %l319
  br label %bb149
bb149:
  %t998 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t999 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t998)
  store %"compiler/typed:Block" %t999, ptr %l320
  br label %bb150
bb150:
  %t1000 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t1000, ptr %lp26
  %t1001 = load %"compiler/typed:Block", ptr %l320
  %t1002 = load ptr, ptr %lp26
  store %"compiler/typed:Block" %t1001, ptr %t1002
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1005 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1003)
  store ptr %t1005, ptr %l322
  br label %bb151
bb151:
  %t1006 = load ptr, ptr %l322, !tbaa !29
  %t1007 = load ptr, ptr %lp26
  %t1010 = getelementptr %"compiler/typed:Body", ptr %t1006, i32 0, i32 11
  store ptr %t1007, ptr %t1010, !tbaa !29
  %t1011 = load i64, ptr %l3, !tbaa !24
  %t1013 = icmp sgt i64 %t1011, 0
  br i1 %t1013, label %bb152, label %bb153
bb152:
  %t1015 = load i1, ptr %l5, !tbaa !21
  %t1017 = xor i1 %t1015, true
  store i1 %t1017, ptr %l327, !tbaa !21
  br label %bb154
bb153:
  store i1 false, ptr %l327, !tbaa !21
  br label %bb154
bb154:
  %t1019 = load i1, ptr %l327, !tbaa !21
  br i1 %t1019, label %bb155, label %bb156
bb155:
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1022 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1020)
  store ptr %t1022, ptr %l332
  br label %bb157
bb156:
  store i1 false, ptr %l330, !tbaa !21
  br label %bb158
bb157:
  %t1023 = load ptr, ptr %l332, !tbaa !29
  %t1025 = getelementptr %"compiler/check:frame", ptr %t1023, i32 0, i32 18
  %t1026 = load i1, ptr %t1025, !tbaa !21
  %t1028 = xor i1 %t1026, true
  store i1 %t1028, ptr %l330, !tbaa !21
  br label %bb158
bb158:
  %t1030 = load i1, ptr %l330, !tbaa !21
  br i1 %t1030, label %bb159, label %bb160
bb159:
  %t1031 = load ptr, ptr %lp26
  %t1033 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1031)
  store i1 %t1033, ptr %l338
  br label %bb161
bb160:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb162
bb161:
  %t1034 = load i1, ptr %l338, !tbaa !21
  %t1035 = xor i1 %t1034, true
  store i1 %t1035, ptr %l336, !tbaa !21
  br label %bb162
bb162:
  %t1037 = load i1, ptr %l336, !tbaa !21
  br i1 %t1037, label %bb163, label %bb164
bb163:
  %t1038 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1038, ptr %l340, !tbaa !29
  %t1039 = load ptr, ptr %l1, !tbaa !29
  %t1041 = getelementptr %"compiler/ast:Catch", ptr %t1039, i32 0, i32 0
  %t1042 = load %"compiler/source:Span", ptr %t1041
  store %"compiler/source:Span" %t1042, ptr %l342
  %t1043 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0)
  store %"compiler/diagmsg:Msg" %t1043, ptr %l343
  br label %bb165
bb164:
  br label %bb167
bb165:
  %t1044 = load ptr, ptr %l340, !tbaa !29
  %t1045 = load %"compiler/source:Span", ptr %l342
  %t1046 = load %"compiler/diagmsg:Msg", ptr %l343
  %t1047 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1044, %"compiler/source:Span" %t1045, %"compiler/diagmsg:Msg" %t1046)
  store i64 %t1047, ptr %l344
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t1048 = load ptr, ptr %l0, !tbaa !29
  %t1050 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1048)
  store ptr %t1050, ptr %l346
  br label %bb168
bb168:
  %t1051 = load ptr, ptr %l346, !tbaa !29
  %t1053 = getelementptr %"compiler/check:frame", ptr %t1051, i32 0, i32 30
  %t1055 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v2, ptr %t1053)
  store { i64, ptr } %t1055, ptr %l349
  br label %bb169
bb169:
  %t1056 = load { i64, ptr }, ptr %l349, !tbaa !27
  store { i64, ptr } %t1056, ptr %l27, !tbaa !27
  %t1057 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t1057)
  br label %bb170
bb170:
  %t1059 = load ptr, ptr %l0, !tbaa !29
  %t1061 = getelementptr %"compiler/check:Checker", ptr %t1059, i32 0, i32 24
  %t1062 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t1061, i64 %t1062, i64 2)
  br label %bb171
bb171:
  %t1065 = load ptr, ptr %l1, !tbaa !29
  %t1067 = getelementptr %"compiler/ast:Catch", ptr %t1065, i32 0, i32 0
  %t1068 = load %"compiler/source:Span", ptr %t1067
  store %"compiler/source:Span" %t1068, ptr %l355
  %t1069 = load i32, ptr %l7, !tbaa !23
  store i32 %t1069, ptr %l356, !tbaa !23
  %t1070 = load i64, ptr %l10, !tbaa !24
  %t1072 = trunc i64 %t1070 to i32
  store i32 %t1072, ptr %l359, !tbaa !23
  %t1074 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t1074, ptr %l360, !tbaa !27
  %t1075 = load ptr, ptr %l0, !tbaa !29
  %t1076 = load ptr, ptr %l1, !tbaa !29
  %t1078 = getelementptr %"compiler/ast:Catch", ptr %t1076, i32 0, i32 0
  %t1079 = load %"compiler/source:Span", ptr %t1078
  %t1083 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1075, i32 5, %"compiler/source:Span" %t1079)
  store i32 %t1083, ptr %l365
  br label %bb172
bb172:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1084
  %t1085 = getelementptr { i64, [4 x i64] }, ptr %t1084, i32 0, i32 0
  store i64 1, ptr %t1085
  %t1086 = load i32, ptr %l359, !tbaa !23
  %t1087 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t1086, 0
  %t1088 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t1089 = insertvalue { i32, { i64, ptr }, i32 } %t1087, { i64, ptr } %t1088, 1
  %t1090 = load i32, ptr %l365, !tbaa !23
  %t1091 = insertvalue { i32, { i64, ptr }, i32 } %t1089, i32 %t1090, 2
  %t1092 = getelementptr { i64, [4 x i64] }, ptr %t1084, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t1091, ptr %t1092
  %t1093 = load { i64, [4 x i64] }, ptr %t1084
  %t1095 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t1093, ptr %t1095
  store { i64, [5 x i64] } zeroinitializer, ptr %t1096
  %t1097 = getelementptr { i64, [5 x i64] }, ptr %t1096, i32 0, i32 0
  store i64 15, ptr %t1097
  %t1098 = load %"compiler/source:Span", ptr %l355
  %t1099 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1098, 0
  %t1100 = load i32, ptr %l356, !tbaa !23
  %t1101 = insertvalue { %"compiler/source:Span", i32, ptr } %t1099, i32 %t1100, 1
  %t1103 = insertvalue { %"compiler/source:Span", i32, ptr } %t1101, ptr %t1095, 2
  %t1104 = getelementptr { i64, [5 x i64] }, ptr %t1096, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1103, ptr %t1104
  %t1105 = load { i64, [5 x i64] }, ptr %t1096
  %t1107 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t1105, ptr %t1107
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1107, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l22 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca i1
  %l67 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i64
  %l82 = alloca ptr
  %l89 = alloca ptr
  %l96 = alloca i32
  %l100 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l101 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i32
  %l115 = alloca i64
  %l116 = alloca i32
  %l120 = alloca i32
  %l121 = alloca i32
  %l128 = alloca ptr
  %l139 = alloca i32
  %l142 = alloca %"compiler/source:Span"
  %l148 = alloca i32
  %l155 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t268 = alloca { i64, [4 x i64] }, align 8
  %t312 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 19
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t11)
  store ptr %t14, ptr %l22
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l22, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 1
  %t18 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t18, ptr %l5
  %t20 = load { i64, [2 x i64] }, ptr %l5
  %t22 = extractvalue { i64, [2 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 6
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t26 = getelementptr { i64, i32 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  store i64 %t27, ptr %l6, !tbaa !24
  %t29 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t30 = getelementptr { i64, i32 }, ptr %t29, i32 0, i32 1
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i32, ptr %l7, !tbaa !23
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t36, i64 %t37, i32 %t38)
  store ptr %t42, ptr %l33
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l33, !tbaa !29
  store ptr %t43, ptr %l8, !tbaa !29
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i32, ptr %l7, !tbaa !23
  %t59 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsSynth(ptr %v0, ptr %t53, i64 %t54, i32 %t55)
  store i1 %t59, ptr %l42
  br label %bb9
bb8:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb10
bb9:
  %t60 = load i1, ptr %l42, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t63 = load i1, ptr %l37, !tbaa !21
  br i1 %t63, label %bb11, label %bb12
bb11:
  %t64 = load ptr, ptr %l8, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 3
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  store i1 %t71, ptr %l44, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb13
bb13:
  %t73 = load i1, ptr %l44, !tbaa !21
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr %"compiler/ast:VarDecl", ptr %t74, i32 0, i32 3
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l51, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 0
  %t81 = load ptr, ptr %t80, !tbaa !39
  %t83 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t81)
  store %"compiler/source:Span" %t83, ptr %l53
  br label %bb16
bb15:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb18
bb16:
  %t84 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t84, ptr %l55
  %t87 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l53, ptr %l55)
  store i1 %t87, ptr %l57
  br label %bb17
bb17:
  %t88 = load i1, ptr %l57, !tbaa !21
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 157
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/check:frame", ptr %t93, i32 0, i32 0
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load %"compiler/source:Span", ptr %l1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_H19fded22be32a91ca4084130356a325d(ptr %v0, ptr %t92, i64 %t96, %"compiler/source:Span" %t97)
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, i32 %t104)
  store ptr %t108, ptr %l67
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load ptr, ptr %l67, !tbaa !29
  store ptr %t109, ptr %rv
  br label %ret
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fa3c94e3a612a0dd_4761343759351551)
  unreachable
bb29:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %s0, ptr %t110)
  store { i64, ptr } %t112, ptr %l69
  br label %bb30
bb30:
  %t113 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t113, ptr %l9, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t116 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t114, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t116, ptr %l71
  br label %bb31
bb31:
  %t117 = load i1, ptr %l71, !tbaa !21
  br i1 %t117, label %bb32, label %bb33
bb32:
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/check:frame", ptr %t118, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l72, !tbaa !24
  br label %bb34
bb33:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 12
  %t132 = load i64, ptr %t131, !tbaa !24
  store i64 %t132, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t134 = load i64, ptr %l72, !tbaa !24
  store i64 %t134, ptr %l10, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/load:Loader", ptr %t141, i32 0, i32 3
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 0
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/load:Loader", ptr %t151, i32 0, i32 10
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 1
  %t157 = load i64, ptr %t156, !tbaa !24
  %t160 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t153, i64 %t157)
  store ptr %t160, ptr %l89
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l89, !tbaa !29
  %t163 = getelementptr %"compiler/load:Module", ptr %t161, i32 0, i32 2
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t165 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t166 = load i32, ptr %t165, !tbaa !23
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t171 = extractvalue { i64, ptr } %t164, 1
  %t172 = extractvalue { i64, ptr } %t164, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t178 = sext i32 %t166 to i64
  %t179 = call i64 @__olang_fmt_i64(ptr null, i64 %t178)
  %t180 = add i64 %t176, %t179
  %t182 = extractvalue { i64, ptr } %t167, 1
  %t183 = extractvalue { i64, ptr } %t167, 0
  %t184 = add i64 %t180, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t168, i64 %t169)
  %t186 = getelementptr i8, ptr %t185, i64 %t169
  call void @olang_textcopy(ptr %t186, ptr %t171, i64 %t172)
  %t187 = getelementptr i8, ptr %t186, i64 %t172
  call void @olang_textcopy(ptr %t187, ptr %t174, i64 %t175)
  %t188 = getelementptr i8, ptr %t187, i64 %t175
  %t189 = call i64 @__olang_fmt_i64(ptr %t188, i64 %t178)
  %t190 = getelementptr i8, ptr %t188, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t182, i64 %t183)
  %t191 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t185, 1
  %t194 = load ptr, ptr %l82, !tbaa !29
  %t196 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t194, { i64, ptr } %t192)
  store i32 %t196, ptr %l96
  br label %bb36
bb36:
  %t197 = load i32, ptr %l96, !tbaa !23
  store i32 %t197, ptr %l11, !tbaa !23
  %t198 = load i64, ptr %l10, !tbaa !24
  %t199 = load i32, ptr %l11, !tbaa !23
  %t201 = sext i32 %t199 to i64
  %t204 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t198, i64 %t201)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t204, ptr %l100
  br label %bb37
bb37:
  %t205 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l100
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t205, ptr %l12
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 33
  %t209 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  %t212 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t208, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t209)
  %t213 = extractvalue { i32, i64 } %t212, 1
  %t214 = extractvalue { i32, i64 } %t212, 0
  store i32 %t214, ptr %l106
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb39, label %ok.216, !prof !99
ok.216:
  store i64 %t213, ptr %l105
  br label %bb38
bb38:
  %t217 = load i64, ptr %l105, !tbaa !24
  store i64 %t217, ptr %l101, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  store i64 -1, ptr %l101, !tbaa !24
  br label %bb41
bb41:
  %t218 = load i64, ptr %l101, !tbaa !24
  store i64 %t218, ptr %l13, !tbaa !24
  %t219 = load i64, ptr %l13, !tbaa !24
  %t221 = icmp slt i64 %t219, 0
  br i1 %t221, label %bb42, label %bb43
bb42:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l1
  %t225 = load ptr, ptr %l2, !tbaa !29
  %t226 = load i32, ptr %l3, !tbaa !23
  %t227 = load i64, ptr %l10, !tbaa !24
  %t228 = load i32, ptr %l11, !tbaa !23
  %t235 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeBody(ptr %v0, ptr %v1, ptr %t223, %"compiler/source:Span" %t224, ptr %t225, i32 %t226, i64 %t227, i32 %t228)
  store i64 %t235, ptr %l115
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t236 = load i64, ptr %l115, !tbaa !24
  store i64 %t236, ptr %l13, !tbaa !24
  br label %bb45
bb45:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 34
  %t240 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  %t243 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %t239, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t240)
  %t244 = extractvalue { i32, i32 } %t243, 1
  %t245 = extractvalue { i32, i32 } %t243, 0
  store i32 %t245, ptr %l121
  %t246 = icmp ne i32 %t245, 0
  br i1 %t246, label %bb47, label %ok.247, !prof !99
ok.247:
  store i32 %t244, ptr %l120
  br label %bb46
bb46:
  %t248 = load i32, ptr %l120, !tbaa !23
  store i32 %t248, ptr %l116, !tbaa !23
  br label %bb49
bb47:
  br label %bb48
bb48:
  %t249 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t249, ptr %l116, !tbaa !23
  br label %bb49
bb49:
  %t251 = load i32, ptr %l116, !tbaa !23
  store i32 %t251, ptr %l14, !tbaa !23
  %t252 = load i32, ptr %l14, !tbaa !23
  %t253 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t256 = icmp eq i32 %t252, %t253
  br i1 %t256, label %bb50, label %bb51
bb50:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l1
  %t262 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t258, %"compiler/source:Span" %t259)
  store ptr %t262, ptr %l128
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t263 = load ptr, ptr %l128, !tbaa !29
  store ptr %t263, ptr %rv
  br label %ret
bb53:
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i32, ptr %l14, !tbaa !23
  %t266 = load i64, ptr %l10, !tbaa !24
  %t267 = load i32, ptr %l11, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 0
  store i64 1, ptr %t269
  %t271 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t264, 0
  %t273 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t271, i32 %t265, 1
  %t275 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t273, i64 %t266, 2
  %t277 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t275, i32 %t267, 3
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t277, ptr %t278
  %t279 = load { i64, [4 x i64] }, ptr %t268
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t279, ptr %t281
  store ptr %t281, ptr %l15, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t288 = getelementptr %"compiler/generic:Program", ptr %t286, i32 0, i32 2
  %t289 = load i32, ptr %l14, !tbaa !23
  %t292 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t288, i32 %t289)
  store i32 %t292, ptr %l139
  br label %bb54
bb54:
  %t293 = load i32, ptr %l139, !range !{i32 0, i32 33}
  %t295 = trunc i64 19 to i32
  %t296 = icmp eq i32 %t293, %t295
  br i1 %t296, label %bb55, label %bb56
bb55:
  %t298 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t298, ptr %l142
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/generic:Program", ptr %t302, i32 0, i32 2
  %t305 = load i32, ptr %l14, !tbaa !23
  %t306 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t310 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t304, i32 %t305, i64 %t306)
  store i32 %t310, ptr %l148
  br label %bb57
bb56:
  br label %bb58
bb57:
  %t311 = load ptr, ptr %l15, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t312
  %t313 = getelementptr { i64, [5 x i64] }, ptr %t312, i32 0, i32 0
  store i64 3, ptr %t313
  %t314 = load %"compiler/source:Span", ptr %l142
  %t315 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t314, 0
  %t316 = load i32, ptr %l148, !tbaa !23
  %t317 = insertvalue { %"compiler/source:Span", i32, ptr } %t315, i32 %t316, 1
  %t319 = insertvalue { %"compiler/source:Span", i32, ptr } %t317, ptr %t311, 2
  %t320 = getelementptr { i64, [5 x i64] }, ptr %t312, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t319, ptr %t320
  %t321 = load { i64, [5 x i64] }, ptr %t312
  %t323 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t321, ptr %t323
  call void @__olang_scope_close(ptr %s0)
  store ptr %t323, ptr %rv
  br label %ret
bb58:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l1
  %t327 = load ptr, ptr %l15, !tbaa !29
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t325, %"compiler/source:Span" %t326, ptr %t327)
  store ptr %t331, ptr %l155
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t332 = load ptr, ptr %l155, !tbaa !29
  store ptr %t332, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversStruct(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l74 = alloca i1
  %l83 = alloca i32
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l131 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructFields(ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  store ptr %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l26, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l29, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l34
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l29, !tbaa !29
  %t24 = load i32, ptr %l34, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t23, i32 %t24)
  store { i64, ptr } %t25, ptr %l35
  br label %bb3
bb3:
  %t26 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t26, ptr %l6, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/check:fieldSet", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp ne i64 %t29, %t35
  br i1 %t38, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l47
  br label %bb7
bb7:
  %t51 = load i32, ptr %l47, !tbaa !23
  store i32 %t51, ptr %l7, !tbaa !23
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l48
  br label %bb8
bb8:
  %t53 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %t54
  store ptr %t54, ptr %l8, !tbaa !29
  store ptr %a1, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  %t58 = load i64, ptr %l10, !tbaa !24
  store i64 %t58, ptr %l51, !tbaa !24
  %t59 = load ptr, ptr %l9, !tbaa !29
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t59)
  store i64 %t61, ptr %l53
  br label %bb10
bb10:
  %t62 = load i64, ptr %l51, !tbaa !24
  %t63 = load i64, ptr %l53, !tbaa !24
  %t64 = icmp slt i64 %t62, %t63
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb42
bb12:
  br label %bb13
bb13:
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t68, i64 %t69)
  store { i64, ptr } %t72, ptr %l58
  br label %bb14
bb14:
  %t73 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t73, ptr %l11, !tbaa !27
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t75, ptr %l60, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr ptr, ptr %t77, i64 0
  %t79 = load ptr, ptr %t78, !tbaa !39
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t74, ptr %t79)
  store i1 %t82, ptr %l62
  br label %bb15
bb15:
  %t83 = load i1, ptr %l62, !tbaa !21
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l8, !tbaa !29
  store ptr %t84, ptr %l63, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t85, ptr %l64, !tbaa !27
  %t86 = icmp sge i64 0, 0
  br i1 %t86, label %bb18, label %bb19
bb17:
  br label %bb24
bb18:
  %t88 = icmp sle i64 0, 1152921504606846975
  br i1 %t88, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_26959ece93e3b5d7_ef6153c643f98adb)
  unreachable
bb20:
  %t90 = mul i64 0, 8
  %t91 = insertvalue { i64, ptr } undef, i64 0, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t96, { i64, ptr } %t92, i64 %t95)
  store { i64, ptr } %t99, ptr %l70
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_26959ece93e3b5d7_ef6153c643f98adb)
  unreachable
bb22:
  %t100 = load ptr, ptr %l63, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l70, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %t100, { i64, ptr } %t101)
  br label %bb23
bb23:
  br label %bb41
bb24:
  %t102 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t102, ptr %l71, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 0
  %t106 = load ptr, ptr %t105, !tbaa !39
  store ptr %t106, ptr %l12, !tbaa !29
  %t108 = load ptr, ptr %l12, !tbaa !29
  store ptr %t108, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t109 = load ptr, ptr %l73, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t112 = load ptr, ptr %l73, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 9}
  %t115 = icmp eq i64 %t113, 2
  store i1 %t115, ptr %l74, !tbaa !21
  br label %bb26
bb26:
  %t116 = load i1, ptr %l74, !tbaa !21
  br i1 %t116, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l12, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l13, !tbaa !29
  %t123 = load ptr, ptr %l12, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t125, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126
  store { i64, ptr } %t127, ptr %l14, !tbaa !27
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t133 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructDecl(ptr %v0, ptr %v1, ptr %t129, ptr %t130)
  store i32 %t133, ptr %l83
  br label %bb30
bb30:
  %t134 = load i32, ptr %l7, !tbaa !23
  %t135 = load i32, ptr %l83, !tbaa !23
  %t137 = icmp eq i32 %t135, %t134
  br i1 %t137, label %bb31, label %bb32
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l8, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t143 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyFieldRow(ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %s0, ptr %t139, ptr %t140, { i64, ptr } %t141, { i64, ptr } %t142, ptr %t143)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_dcaa30bcf0ceb4b1_7307533feb398e7d)
  unreachable
bb40:
  br label %bb41
bb41:
  %t149 = load i64, ptr %l10, !tbaa !24
  %t152 = add i64 %t149, 1
  store i64 %t152, ptr %l10, !tbaa !24
  br label %bb9
bb42:
  %t154 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l94
  br label %bb43
bb43:
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %l15
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t156, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  store i64 %t160, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  %t162 = load i64, ptr %l17, !tbaa !24
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t170 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t170, ptr %l102, !tbaa !27
  %t171 = load i64, ptr %l17, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr i32, ptr %t174, i64 %t171
  %t176 = load i32, ptr %t175, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l15, i32 %t176)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t181 = load i64, ptr %l17, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l17, !tbaa !24
  br label %bb44
bb50:
  store { i64, ptr } %a3, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t188, 0
  store i64 %t190, ptr %l22, !tbaa !24
  br label %bb51
bb51:
  %t192 = load i64, ptr %l21, !tbaa !24
  %t193 = load i64, ptr %l22, !tbaa !24
  %t196 = icmp slt i64 %t192, %t193
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb52, label %bb53
bb52:
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t200 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t200, ptr %l117, !tbaa !27
  %t201 = load i64, ptr %l21, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i32, ptr %t204, i64 %t201
  %t206 = load i32, ptr %t205, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l15, i32 %t206)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t211 = load i64, ptr %l21, !tbaa !24
  %t214 = add i64 %t211, 1
  store i64 %t214, ptr %l21, !tbaa !24
  br label %bb51
bb57:
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l125, !tbaa !29
  %t217 = load ptr, ptr %l8, !tbaa !29
  store ptr %t217, ptr %l126, !tbaa !29
  %t219 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l15)
  store { i64, ptr } %t219, ptr %l128
  br label %bb58
bb58:
  %t222 = add i64 %a4, 1
  %t223 = load ptr, ptr %l125, !tbaa !29
  %t224 = load ptr, ptr %l126, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t227 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v0, ptr %s0, ptr %t223, ptr %t224, { i64, ptr } %t225, i64 %t222)
  store i1 %t227, ptr %l131
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t228 = load i1, ptr %l131, !tbaa !21
  store i1 %t228, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i32
  %l17 = alloca ptr
  %l19 = alloca %"compiler/typed:Item"
  %l24 = alloca i32
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca i64
  %l62 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca %"compiler/typed:Item"
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l17, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t19 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s1, i32 %t17, i64 -1)
  store %"compiler/typed:Item" %t19, ptr %l19
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = load %"compiler/typed:Item", ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v1, ptr %t20, %"compiler/typed:Item" %t21)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l24
  br label %bb7
bb7:
  %t32 = load i32, ptr %l24, !range !{i32 0, i32 33}
  %t34 = trunc i64 28 to i32
  %t35 = icmp eq i32 %t32, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l32
  br label %bb11
bb11:
  %t49 = load i64, ptr %l32, !tbaa !65
  store i64 %t49, ptr %l3, !tbaa !65
  store i64 0, ptr %l4, !tbaa !24
  store i64 64, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb17
bb14:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l39, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb16
bb16:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l36, !tbaa !24
  br label %bb17
bb17:
  %t77 = load i64, ptr %l36, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb19, label %bb20
bb19:
  br label %bb29
bb20:
  br label %bb21
bb21:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l3, !tbaa !65
  %t97 = load i64, ptr %l9, !tbaa !24
  store i64 %t97, ptr %l58, !tbaa !24
  %t98 = load i64, ptr %l58, !tbaa !24
  %t99 = load i64, ptr %l58, !tbaa !24
  %t100 = shl i64 1, %t99
  %t103 = and i64 %t96, %t100
  %t105 = icmp ne i64 %t103, 0
  br i1 %t105, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l2, !tbaa !29
  store ptr %t107, ptr %l62, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l67
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t118 = load i64, ptr %l9, !tbaa !24
  %t119 = load i32, ptr %l67, !tbaa !23
  %t121 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s5, i32 %t119, i64 %t118)
  store %"compiler/typed:Item" %t121, ptr %l69
  br label %bb25
bb25:
  %t122 = load ptr, ptr %l62, !tbaa !29
  %t123 = load %"compiler/typed:Item", ptr %l69
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v1, ptr %t122, %"compiler/typed:Item" %t123)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = add i64 %t124, 1
  store i64 %t127, ptr %l8, !tbaa !24
  br label %bb18
bb29:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %lp19 = alloca ptr
  %lp20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l66 = alloca i64
  %l69 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca i32
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l108 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l118 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca { i64, ptr }
  %l124 = alloca i32
  %l128 = alloca %"compiler/typed:Payload"
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca { i64, ptr }
  %l134 = alloca i32
  %l138 = alloca %"compiler/typed:Payload"
  %l146 = alloca i64
  %l149 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca %"compiler/source:Span"
  %l169 = alloca i32
  %l173 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l197 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca %"compiler/source:Span"
  %l203 = alloca i32
  %l204 = alloca i32
  %l208 = alloca ptr
  %l209 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l212 = alloca i32
  %l214 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca %"compiler/source:Span"
  %l218 = alloca i32
  %l223 = alloca %"compiler/typed:Cond"
  %l232 = alloca i64
  %l235 = alloca %"compiler/source:Span"
  %l236 = alloca i32
  %l240 = alloca { i64, ptr }
  %l243 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t202 = alloca { i64, [4 x i64] }, align 8
  %t231 = alloca { i64, [4 x i64] }, align 8
  %t308 = alloca { i64, [4 x i64] }, align 8
  %t338 = alloca { i64, [4 x i64] }, align 8
  %t420 = alloca { i64, [5 x i64] }, align 8
  %t464 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 48
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i64, ptr %l31, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l32, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l33
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t12 = load %"compiler/source:Span", ptr %l1
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v3, ptr %t9, ptr %a2, i32 %t11, %"compiler/source:Span" %t12)
  store ptr %t17, ptr %l38
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l32, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l33
  %t20 = load ptr, ptr %l38, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v3, ptr %v3, ptr %t18, %"compiler/source:Span" %t19, ptr %t20)
  store ptr %t21, ptr %l39
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l39, !tbaa !29
  store ptr %t22, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l40, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l41
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t28 = load %"compiler/source:Span", ptr %l1
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v3, ptr %t25, ptr %a3, i32 %t27, %"compiler/source:Span" %t28)
  store ptr %t33, ptr %l46
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l40, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l41
  %t36 = load ptr, ptr %l46, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v3, ptr %v3, ptr %t34, %"compiler/source:Span" %t35, ptr %t36)
  store ptr %t37, ptr %l47
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l47, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l50, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l55
  br label %bb6
bb6:
  %t55 = load ptr, ptr %l50, !tbaa !29
  %t56 = load i32, ptr %l55, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l56
  br label %bb7
bb7:
  %t58 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i64 0)
  store ptr %t65, ptr %l60
  br label %bb8
bb8:
  %t66 = load ptr, ptr %l60, !tbaa !29
  store ptr %t66, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb9, label %bb10
bb9:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb14
bb11:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l69, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb13
bb13:
  %t97 = load i64, ptr %l69, !tbaa !24
  store i64 %t97, ptr %l66, !tbaa !24
  br label %bb14
bb14:
  %t98 = load i64, ptr %l66, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb15
bb15:
  %t99 = load i64, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb16, label %bb17
bb16:
  br label %bb50
bb17:
  br label %bb18
bb18:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = sub i64 %t119, 1
  %t125 = sub i64 %t121, %t115
  store i64 %t125, ptr %l16, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  store ptr %t132, ptr %l94, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  store ptr %t138, ptr %l97, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load i32, ptr %l4, !tbaa !23
  %t144 = load i64, ptr %l16, !tbaa !24
  %t148 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t142, i32 %t143, i64 %t144)
  store i32 %t148, ptr %l102
  br label %bb19
bb19:
  %t149 = load ptr, ptr %l97, !tbaa !29
  %t150 = load i32, ptr %l102, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t151, ptr %l103
  br label %bb20
bb20:
  %t152 = load ptr, ptr %l94, !tbaa !29
  %t153 = load i32, ptr %l103, !tbaa !23
  %t154 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t152, i32 %t153)
  store { i64, ptr } %t154, ptr %l104
  br label %bb21
bb21:
  %t155 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t155, ptr %l17, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l105, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l106
  %t158 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t158, ptr %l107, !tbaa !23
  store i32 23, ptr %l108
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t159, %"compiler/source:Span" %t160, ptr %t161)
  store ptr %t165, ptr %l112
  br label %bb22
bb22:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l113, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t167, ptr %l114
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t168)
  store i32 %t170, ptr %l116
  br label %bb23
bb23:
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load ptr, ptr %l113, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l114
  %t174 = load i32, ptr %l116, !tbaa !23
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t172, %"compiler/source:Span" %t173, i32 %t174, i64 %t171)
  store ptr %t176, ptr %l118
  br label %bb24
bb24:
  %t177 = load ptr, ptr %l118, !tbaa !29
  %t178 = load ptr, ptr %l105, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l106
  %t180 = load i32, ptr %l107, !tbaa !23
  %t181 = load i32, ptr %l108, !range !{i32 0, i32 54}
  %t182 = load ptr, ptr %l112, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t178, %"compiler/source:Span" %t179, i32 %t180, i32 %t181, ptr %t182, ptr %t177)
  store ptr %t184, ptr %l120
  br label %bb25
bb25:
  %t185 = load ptr, ptr %l120, !tbaa !29
  store ptr %t185, ptr %l18, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l121
  %t187 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t187, ptr %l122, !tbaa !27
  %t188 = load i64, ptr %l16, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i32, ptr %t191, i64 %t188
  %t193 = load i32, ptr %t192, !tbaa !33
  store i32 %t193, ptr %l124, !tbaa !23
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t195 = load i64, ptr %l16, !tbaa !24
  %t199 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v3, ptr %v3, ptr %t194, i64 %t195, i32 0)
  store %"compiler/typed:Payload" %t199, ptr %l128
  br label %bb26
bb26:
  %t200 = load %"compiler/typed:Payload", ptr %l128
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Payload" %t200, ptr %t201
  store { i64, [4 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 0
  store i64 5, ptr %t203
  %t204 = load %"compiler/source:Span", ptr %l121
  %t205 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t204, 0
  %t206 = load i32, ptr %l124, !tbaa !23
  %t207 = insertvalue { %"compiler/source:Span", i32, ptr } %t205, i32 %t206, 1
  %t209 = insertvalue { %"compiler/source:Span", i32, ptr } %t207, ptr %t201, 2
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t209, ptr %t210
  %t211 = load { i64, [4 x i64] }, ptr %t202
  %t212 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t212, ptr %lp19
  %t214 = load ptr, ptr %lp19
  store { i64, [4 x i64] } %t211, ptr %t214
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l131
  %t216 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t216, ptr %l132, !tbaa !27
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i32, ptr %t220, i64 %t217
  %t222 = load i32, ptr %t221, !tbaa !33
  store i32 %t222, ptr %l134, !tbaa !23
  %t223 = load ptr, ptr %l7, !tbaa !29
  %t224 = load i64, ptr %l16, !tbaa !24
  %t228 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v3, ptr %v3, ptr %t223, i64 %t224, i32 0)
  store %"compiler/typed:Payload" %t228, ptr %l138
  br label %bb27
bb27:
  %t229 = load %"compiler/typed:Payload", ptr %l138
  %t230 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Payload" %t229, ptr %t230
  store { i64, [4 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 0
  store i64 5, ptr %t232
  %t233 = load %"compiler/source:Span", ptr %l131
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t233, 0
  %t235 = load i32, ptr %l134, !tbaa !23
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, i32 %t235, 1
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } %t236, ptr %t230, 2
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t238, ptr %t239
  %t240 = load { i64, [4 x i64] }, ptr %t231
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t241, ptr %lp20
  %t243 = load ptr, ptr %lp20
  store { i64, [4 x i64] } %t240, ptr %t243
  store i64 0, ptr %l21, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t248 = load i64, ptr %l22, !tbaa !24
  %t249 = load i64, ptr %l21, !tbaa !24
  %t252 = icmp sgt i64 %t248, %t249
  br i1 %t252, label %bb28, label %bb29
bb28:
  %t254 = load i64, ptr %l23, !tbaa !24
  %t256 = icmp sgt i64 %t254, 0
  br i1 %t256, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb33
bb30:
  %t258 = load i64, ptr %l22, !tbaa !24
  %t259 = load i64, ptr %l21, !tbaa !24
  %t262 = sub i64 %t258, %t259
  %t263 = load i64, ptr %l23, !tbaa !24
  %t266 = add i64 %t262, %t263
  %t268 = sub i64 %t266, 1
  %t269 = load i64, ptr %l23, !tbaa !24
  %t272 = sdiv i64 %t268, %t269
  store i64 %t272, ptr %l149, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb32
bb32:
  %t274 = load i64, ptr %l149, !tbaa !24
  store i64 %t274, ptr %l146, !tbaa !24
  br label %bb33
bb33:
  %t275 = load i64, ptr %l146, !tbaa !24
  store i64 %t275, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb34
bb34:
  %t276 = load i64, ptr %l25, !tbaa !24
  %t277 = load i64, ptr %l24, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t284 = load i64, ptr %l21, !tbaa !24
  %t285 = load i64, ptr %l25, !tbaa !24
  %t286 = load i64, ptr %l23, !tbaa !24
  %t289 = mul i64 %t285, %t286
  %t292 = add i64 %t284, %t289
  store i64 %t292, ptr %l26, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l167, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t295, ptr %l168
  store i32 95, ptr %l169
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l1
  %t298 = load %"compiler/source:Span", ptr %l1
  %t299 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t299, ptr %l173, !tbaa !27
  %t300 = load i64, ptr %l26, !tbaa !24
  %t302 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr i32, ptr %t303, i64 %t300
  %t305 = load i32, ptr %t304, !tbaa !33
  %t306 = load ptr, ptr %lp19
  %t307 = load i64, ptr %l26, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t308
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t308, i32 0, i32 0
  store i64 3, ptr %t309
  %t311 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t298, 0
  %t313 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t311, i32 %t305, 1
  %t315 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t313, ptr %t306, 2
  %t317 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t315, i64 %t307, 3
  %t318 = getelementptr { i64, [4 x i64] }, ptr %t308, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t317, ptr %t318
  %t319 = load { i64, [4 x i64] }, ptr %t308
  %t321 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t319, ptr %t321
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t296, %"compiler/source:Span" %t297, ptr %t321)
  store ptr %t325, ptr %l180
  br label %bb38
bb38:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l1
  %t328 = load %"compiler/source:Span", ptr %l1
  %t329 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t329, ptr %l184, !tbaa !27
  %t330 = load i64, ptr %l26, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr i32, ptr %t333, i64 %t330
  %t335 = load i32, ptr %t334, !tbaa !33
  %t336 = load ptr, ptr %lp20
  %t337 = load i64, ptr %l26, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t338
  %t339 = getelementptr { i64, [4 x i64] }, ptr %t338, i32 0, i32 0
  store i64 3, ptr %t339
  %t341 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t328, 0
  %t343 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t341, i32 %t335, 1
  %t345 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t343, ptr %t336, 2
  %t347 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t345, i64 %t337, 3
  %t348 = getelementptr { i64, [4 x i64] }, ptr %t338, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t347, ptr %t348
  %t349 = load { i64, [4 x i64] }, ptr %t338
  %t351 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t349, ptr %t351
  %t355 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t326, %"compiler/source:Span" %t327, ptr %t351)
  store ptr %t355, ptr %l191
  br label %bb39
bb39:
  %t356 = load ptr, ptr %l167, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l168
  %t358 = load i32, ptr %l169, !range !{i32 0, i32 116}
  %t359 = load ptr, ptr %l180, !tbaa !29
  %t360 = load ptr, ptr %l191, !tbaa !29
  %t361 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, ptr %t359, ptr %t360, i1 false)
  store ptr %t361, ptr %l192
  br label %bb40
bb40:
  %t362 = load ptr, ptr %l192, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load %"compiler/source:Span", ptr %l1
  %t365 = load ptr, ptr %l18, !tbaa !29
  %t371 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t363, %"compiler/source:Span" %t364, ptr %t365, ptr %t362)
  store ptr %t371, ptr %l197
  br label %bb41
bb41:
  %t372 = load ptr, ptr %l197, !tbaa !29
  store ptr %t372, ptr %l18, !tbaa !29
  br label %bb42
bb42:
  %t373 = load i64, ptr %l25, !tbaa !24
  %t376 = add i64 %t373, 1
  store i64 %t376, ptr %l25, !tbaa !24
  br label %bb34
bb43:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l201, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t379, ptr %l202
  %t380 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t380, ptr %l203, !tbaa !23
  store i32 23, ptr %l204
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load %"compiler/source:Span", ptr %l1
  %t383 = load ptr, ptr %l6, !tbaa !29
  %t387 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t381, %"compiler/source:Span" %t382, ptr %t383)
  store ptr %t387, ptr %l208
  br label %bb44
bb44:
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l209, !tbaa !29
  %t389 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t389, ptr %l210
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t390)
  store i32 %t392, ptr %l212
  br label %bb45
bb45:
  %t393 = load i64, ptr %l16, !tbaa !24
  %t394 = load ptr, ptr %l209, !tbaa !29
  %t395 = load %"compiler/source:Span", ptr %l210
  %t396 = load i32, ptr %l212, !tbaa !23
  %t398 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t394, %"compiler/source:Span" %t395, i32 %t396, i64 %t393)
  store ptr %t398, ptr %l214
  br label %bb46
bb46:
  %t399 = load ptr, ptr %l214, !tbaa !29
  %t400 = load ptr, ptr %l201, !tbaa !29
  %t401 = load %"compiler/source:Span", ptr %l202
  %t402 = load i32, ptr %l203, !tbaa !23
  %t403 = load i32, ptr %l204, !range !{i32 0, i32 54}
  %t404 = load ptr, ptr %l208, !tbaa !29
  %t406 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t400, %"compiler/source:Span" %t401, i32 %t402, i32 %t403, ptr %t404, ptr %t399)
  store ptr %t406, ptr %l216
  br label %bb47
bb47:
  %t407 = load ptr, ptr %l216, !tbaa !29
  %t408 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t408, ptr %l217
  %t409 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t409, ptr %l218, !tbaa !23
  %t411 = load ptr, ptr %l18, !tbaa !29
  %t413 = load ptr, ptr %l9, !tbaa !29
  %t417 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t407, ptr %t411, ptr %t413)
  store %"compiler/typed:Cond" %t417, ptr %l223
  br label %bb48
bb48:
  %t418 = load %"compiler/typed:Cond", ptr %l223
  %t419 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t418, ptr %t419
  store { i64, [5 x i64] } zeroinitializer, ptr %t420
  %t421 = getelementptr { i64, [5 x i64] }, ptr %t420, i32 0, i32 0
  store i64 11, ptr %t421
  %t422 = load %"compiler/source:Span", ptr %l217
  %t423 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t422, 0
  %t424 = load i32, ptr %l218, !tbaa !23
  %t425 = insertvalue { %"compiler/source:Span", i32, ptr } %t423, i32 %t424, 1
  %t427 = insertvalue { %"compiler/source:Span", i32, ptr } %t425, ptr %t419, 2
  %t428 = getelementptr { i64, [5 x i64] }, ptr %t420, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t427, ptr %t428
  %t429 = load { i64, [5 x i64] }, ptr %t420
  %t431 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t429, ptr %t431
  store ptr %t431, ptr %l9, !tbaa !29
  br label %bb49
bb49:
  %t433 = load i64, ptr %l14, !tbaa !24
  %t436 = add i64 %t433, 1
  store i64 %t436, ptr %l14, !tbaa !24
  br label %bb15
bb50:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/check:Checker", ptr %t438, i32 0, i32 48
  %t442 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t440)
  store i64 %t442, ptr %l232
  br label %bb51
bb51:
  %t443 = load i64, ptr %l5, !tbaa !24
  %t444 = load i64, ptr %l232, !tbaa !24
  %t446 = icmp sgt i64 %t444, %t443
  br i1 %t446, label %bb52, label %bb53
bb52:
  %t448 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t448, ptr %l235
  %t449 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t449, ptr %l236, !tbaa !23
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/check:Checker", ptr %t450, i32 0, i32 48
  %t453 = load i64, ptr %l5, !tbaa !24
  %t456 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t452, i64 %t453)
  store { i64, ptr } %t456, ptr %l240
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t457 = load ptr, ptr %l9, !tbaa !29
  %t459 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t461 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t459, ptr %t457, i1 false)
  store %"compiler/typed:Seq" %t461, ptr %l243
  br label %bb55
bb55:
  %t462 = load %"compiler/typed:Seq", ptr %l243
  %t463 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t462, ptr %t463
  store { i64, [5 x i64] } zeroinitializer, ptr %t464
  %t465 = getelementptr { i64, [5 x i64] }, ptr %t464, i32 0, i32 0
  store i64 12, ptr %t465
  %t466 = load %"compiler/source:Span", ptr %l235
  %t467 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t466, 0
  %t468 = load i32, ptr %l236, !tbaa !23
  %t469 = insertvalue { %"compiler/source:Span", i32, ptr } %t467, i32 %t468, 1
  %t471 = insertvalue { %"compiler/source:Span", i32, ptr } %t469, ptr %t463, 2
  %t472 = getelementptr { i64, [5 x i64] }, ptr %t464, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t471, ptr %t472
  %t473 = load { i64, [5 x i64] }, ptr %t464
  %t475 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t473, ptr %t475
  store ptr %t475, ptr %rv
  br label %ret
bb56:
  %t477 = load ptr, ptr %l9, !tbaa !29
  store ptr %t477, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l19 = alloca %"compiler/names:Ref"
  %l24 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca i32
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/ast:Path"
  %l66 = alloca i32
  %l71 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca { i64, ptr }
  %l84 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %a1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t17)
  store ptr %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 2
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Path", ptr %t24, i32 0, i32 0
  %t27 = getelementptr %"compiler/source:Span", ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t32 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t29, i64 %t23, i32 %t28)
  store %"compiler/names:Ref" %t32, ptr %l19
  br label %bb6
bb6:
  %t33 = getelementptr %"compiler/names:Ref", ptr %l19, i32 0, i32 0
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 9}
  store i32 %t34, ptr %l3
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t45 = trunc i64 5 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l30, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l32
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 4
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load ptr, ptr %l30, !tbaa !29
  %t66 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t63, ptr %t61, ptr %t62)
  store i32 %t66, ptr %l36
  br label %bb14
bb14:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = load i32, ptr %l36, !tbaa !23
  %t70 = icmp ne i32 %t68, %t67
  br i1 %t70, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Path", ptr %t73, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp slt i64 %t78, 2
  br i1 %t80, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t87)
  store ptr %t89, ptr %l48
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t92 = getelementptr %"compiler/check:frame", ptr %t90, i32 0, i32 4
  store ptr %t92, ptr %l50, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Path", ptr %t93, i32 0, i32 0
  %t96 = load %"compiler/source:Span", ptr %t95
  store %"compiler/source:Span" %t96, ptr %l52
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Path", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l54, !tbaa !27
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/ast:Path", ptr %t101, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = sub i64 %t106, 1
  store i64 %t108, ptr %l58, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l59, !tbaa !24
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb22, label %bb23
bb22:
  %t113 = load i64, ptr %l58, !tbaa !24
  %t114 = icmp sle i64 0, %t113
  br i1 %t114, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb24:
  %t116 = load i64, ptr %l58, !tbaa !24
  %t117 = load i64, ptr %l59, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb26:
  %t120 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l58, !tbaa !24
  %t123 = getelementptr i32, ptr %t121, i64 0
  %t124 = sub i64 %t122, 0
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t127 = load %"compiler/source:Span", ptr %l52
  %t129 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %s0, ptr %s0, %"compiler/source:Span" %t127, { i64, ptr } %t126)
  store %"compiler/ast:Path" %t129, ptr %l64
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb28:
  %t130 = load ptr, ptr %l46, !tbaa !29
  %t131 = load ptr, ptr %l50, !tbaa !29
  %t133 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t130, ptr %t131, ptr %l64)
  store i32 %t133, ptr %l66
  br label %bb29
bb29:
  %t134 = load i32, ptr %l66, !tbaa !23
  store i32 %t134, ptr %l4, !tbaa !23
  %t135 = load i32, ptr %l4, !tbaa !23
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t139 = icmp eq i32 %t135, %t136
  br i1 %t139, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l71, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l4, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l76
  br label %bb33
bb33:
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = getelementptr %"compiler/ast:Path", ptr %t153, i32 0, i32 1
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l78, !tbaa !27
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/ast:Path", ptr %t157, i32 0, i32 1
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t164 = sub i64 %t162, 1
  %t166 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t164
  %t169 = load i32, ptr %t168, !tbaa !33
  %t170 = load ptr, ptr %l71, !tbaa !29
  %t171 = load i32, ptr %l76, !tbaa !23
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %t170, i32 %t171, i32 %t169)
  store i64 %t173, ptr %l84
  br label %bb34
bb34:
  %t174 = load i64, ptr %l84, !tbaa !24
  %t175 = icmp sge i64 %t174, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t175, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i1
  %l25 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load i32, ptr %l1, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l11
  br label %bb5
bb5:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l16
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l2, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t27, i32 %t28, i64 0)
  store i1 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l25
  br label %bb14
bb14:
  %t44 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l34
  br label %bb18
bb18:
  %t62 = load i32, ptr %l34, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t63, i32 %t62)
  store i1 %t67, ptr %l37
  br label %bb19
bb19:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/diagmsg:Msg"
  %l17 = alloca i32
  %l18 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca ptr
  %l26 = alloca i64
  %l30 = alloca i32
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i1
  %l50 = alloca ptr
  %l60 = alloca i64
  %l63 = alloca i64
  %l85 = alloca { i64, ptr }
  %l91 = alloca i1
  %l94 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l102 = alloca i1
  %l107 = alloca i32
  %l110 = alloca i1
  %l113 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca { i64, ptr }
  %l122 = alloca i1
  %l127 = alloca i32
  %l130 = alloca i1
  %l133 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca i1
  %l155 = alloca %"compiler/diagmsg:Msg"
  %l158 = alloca { i64, ptr }
  %l160 = alloca %"compiler/diagmsg:Msg"
  %l163 = alloca { i64, ptr }
  %l165 = alloca %"compiler/diagmsg:Msg"
  %l169 = alloca ptr
  %l170 = alloca i64
  %l172 = alloca i64
  %l174 = alloca i64
  %l178 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l187 = alloca i64
  %l195 = alloca i32
  %l199 = alloca i1
  %l203 = alloca i1
  %l207 = alloca i1
  %l218 = alloca i1
  %l221 = alloca i1
  %l225 = alloca ptr
  %l228 = alloca i32
  %l229 = alloca i1
  %l230 = alloca i1
  %l236 = alloca %"compiler/diagmsg:Msg"
  %l239 = alloca { i64, ptr }
  %l241 = alloca %"compiler/diagmsg:Msg"
  %l244 = alloca { i64, ptr }
  %l246 = alloca %"compiler/diagmsg:Msg"
  %l250 = alloca ptr
  %l251 = alloca i64
  %l254 = alloca { i64, ptr }
  %l256 = alloca %"compiler/source:Span"
  %l258 = alloca i64
  %l261 = alloca { i64, ptr }
  %l268 = alloca %"compiler/source:Span"
  %l273 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t352 = alloca { i64, [3 x i64] }, align 8
  %t541 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l22, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l26
  br label %bb2
bb2:
  %t18 = load i64, ptr %l26, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l30
  br label %bb3
bb3:
  %t27 = load i32, ptr %l30, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l33, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l4, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l38
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l33, !tbaa !29
  %t45 = load i32, ptr %l38, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t44, i32 %t45)
  store { i64, ptr } %t46, ptr %l39
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l43
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t57, ptr %l44
  br label %bb7
bb7:
  %t58 = load i1, ptr %l44, !tbaa !21
  store i1 %t58, ptr %l6, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l3, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l50
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l50, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Sig", ptr %t80, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb9, label %bb10
bb9:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb14
bb11:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l63, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb13
bb13:
  %t113 = load i64, ptr %l63, !tbaa !24
  store i64 %t113, ptr %l60, !tbaa !24
  br label %bb14
bb14:
  %t114 = load i64, ptr %l60, !tbaa !24
  store i64 %t114, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb69
bb17:
  br label %bb18
bb18:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp sge i64 %t133, %t136
  br i1 %t139, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb69
bb20:
  br label %bb21
bb21:
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t141, ptr %l85, !tbaa !27
  %t142 = load i64, ptr %l13, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 %t142
  %t147 = load i32, ptr %t146, !tbaa !33
  store i32 %t147, ptr %l14, !tbaa !23
  %t149 = load i32, ptr %l14, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb25
bb23:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l14, !tbaa !23
  %t159 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l94
  br label %bb24
bb24:
  %t160 = load i1, ptr %l94, !tbaa !21
  store i1 %t160, ptr %l91, !tbaa !21
  br label %bb25
bb25:
  %t161 = load i1, ptr %l91, !tbaa !21
  br i1 %t161, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb27:
  br label %bb28
bb28:
  %t162 = load i1, ptr %l6, !tbaa !21
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %t166, i32 %t167)
  store i1 %t170, ptr %l100
  br label %bb31
bb30:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb32
bb31:
  %t171 = load i1, ptr %l100, !tbaa !21
  store i1 %t171, ptr %l97, !tbaa !21
  br label %bb32
bb32:
  %t172 = load i1, ptr %l97, !tbaa !21
  br i1 %t172, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb34:
  br label %bb35
bb35:
  %t173 = load i1, ptr %l6, !tbaa !21
  br i1 %t173, label %bb36, label %bb37
bb36:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load i32, ptr %l14, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t184, ptr %l107
  br label %bb38
bb37:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb39
bb38:
  %t185 = load i32, ptr %l107, !range !{i32 0, i32 33}
  %t187 = trunc i64 21 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l102, !tbaa !21
  br label %bb39
bb39:
  %t190 = load i1, ptr %l102, !tbaa !21
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l113, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l14, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l118
  br label %bb42
bb41:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb44
bb42:
  %t207 = load ptr, ptr %l113, !tbaa !29
  %t208 = load i32, ptr %l118, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l119
  br label %bb43
bb43:
  %t210 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t213 = icmp eq i64 %t211, 0
  store i1 %t213, ptr %l110, !tbaa !21
  br label %bb44
bb44:
  %t215 = load i1, ptr %l110, !tbaa !21
  br i1 %t215, label %bb45, label %bb46
bb45:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 2
  %t222 = load i32, ptr %l14, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l127
  br label %bb47
bb46:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb48
bb47:
  %t226 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t227 = load i32, ptr %l127, !tbaa !23
  %t229 = icmp eq i32 %t227, %t226
  store i1 %t229, ptr %l122, !tbaa !21
  br label %bb48
bb48:
  %t231 = load i1, ptr %l122, !tbaa !21
  br i1 %t231, label %bb49, label %bb50
bb49:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  store ptr %t237, ptr %l133, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 2
  %t244 = load i32, ptr %l14, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l138
  br label %bb51
bb50:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb53
bb51:
  %t248 = load ptr, ptr %l133, !tbaa !29
  %t249 = load i32, ptr %l138, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l139
  br label %bb52
bb52:
  %t251 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t254 = icmp eq i64 %t252, 0
  store i1 %t254, ptr %l130, !tbaa !21
  br label %bb53
bb53:
  %t256 = load i1, ptr %l130, !tbaa !21
  br i1 %t256, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb55:
  br label %bb56
bb56:
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Func", ptr %t257, i32 0, i32 3
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/ast:Sig", ptr %t260, i32 0, i32 0
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l144, !tbaa !27
  %t264 = load i64, ptr %l13, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr ptr, ptr %t267, i64 %t264
  %t269 = load ptr, ptr %t268, !tbaa !39
  %t271 = getelementptr %"compiler/ast:Param", ptr %t269, i32 0, i32 0
  %t272 = load %"compiler/source:Span", ptr %t271
  store %"compiler/source:Span" %t272, ptr %l15
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l150, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l14, !tbaa !23
  %t284 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t280, i32 %t281)
  store i32 %t284, ptr %l153
  br label %bb57
bb57:
  %t285 = load ptr, ptr %l150, !tbaa !29
  %t286 = load i32, ptr %l153, !tbaa !23
  %t287 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t285, i32 %t286)
  store i1 %t287, ptr %l154
  br label %bb58
bb58:
  %t288 = load i1, ptr %l154, !tbaa !21
  br i1 %t288, label %bb59, label %bb60
bb59:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l14, !tbaa !23
  %t293 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t289, i32 %t290)
  store { i64, ptr } %t293, ptr %l158
  br label %bb61
bb60:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l14, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t294, i32 %t295)
  store { i64, ptr } %t298, ptr %l163
  br label %bb63
bb61:
  %t299 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t301 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedByValueC(ptr %s2, ptr %v0, { i64, ptr } %t299)
  store %"compiler/diagmsg:Msg" %t301, ptr %l160
  br label %bb62
bb62:
  %t302 = load %"compiler/diagmsg:Msg", ptr %l160
  store %"compiler/diagmsg:Msg" %t302, ptr %l155
  br label %bb65
bb63:
  %t303 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t305 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExternType(ptr %s2, ptr %v0, { i64, ptr } %t303)
  store %"compiler/diagmsg:Msg" %t305, ptr %l165
  br label %bb64
bb64:
  %t306 = load %"compiler/diagmsg:Msg", ptr %l165
  store %"compiler/diagmsg:Msg" %t306, ptr %l155
  br label %bb65
bb65:
  %t307 = load %"compiler/diagmsg:Msg", ptr %l155
  store %"compiler/diagmsg:Msg" %t307, ptr %l16
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/check:Checker", ptr %t308, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = getelementptr %"compiler/generic:Program", ptr %t311, i32 0, i32 0
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/load:Loader", ptr %t314, i32 0, i32 4
  %t317 = load ptr, ptr %t316, !tbaa !29
  store ptr %t317, ptr %l169, !tbaa !29
  %t318 = load i64, ptr %l7, !tbaa !24
  store i64 %t318, ptr %l170, !tbaa !24
  %t319 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t320 = load i32, ptr %t319, !tbaa !23
  %t322 = sext i32 %t320 to i64
  store i64 %t322, ptr %l172, !tbaa !24
  %t323 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t324 = load i32, ptr %t323, !tbaa !23
  %t326 = sext i32 %t324 to i64
  store i64 %t326, ptr %l174, !tbaa !24
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l2, !tbaa !29
  %t330 = getelementptr %"compiler/ast:Func", ptr %t328, i32 0, i32 3
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = getelementptr %"compiler/ast:Sig", ptr %t331, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  store { i64, ptr } %t334, ptr %l178, !tbaa !27
  %t335 = load i64, ptr %l13, !tbaa !24
  %t337 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr ptr, ptr %t338, i64 %t335
  %t340 = load ptr, ptr %t339, !tbaa !39
  %t342 = getelementptr %"compiler/ast:Param", ptr %t340, i32 0, i32 1
  %t343 = load i32, ptr %t342, !tbaa !23
  %t346 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t327, i32 %t343)
  store { i64, ptr } %t346, ptr %l182
  br label %bb66
bb66:
  %t347 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t347, 0
  %t349 = load i64, ptr %l174, !tbaa !24
  %t351 = add i64 %t349, %t348
  store { i64, [3 x i64] } zeroinitializer, ptr %t352
  %t353 = getelementptr { i64, [3 x i64] }, ptr %t352, i32 0, i32 0
  store i64 3, ptr %t353
  %t354 = load i64, ptr %l170, !tbaa !24
  %t355 = insertvalue { i64, i64, i64 } undef, i64 %t354, 0
  %t356 = load i64, ptr %l172, !tbaa !24
  %t357 = insertvalue { i64, i64, i64 } %t355, i64 %t356, 1
  %t359 = insertvalue { i64, i64, i64 } %t357, i64 %t351, 2
  %t360 = getelementptr { i64, [3 x i64] }, ptr %t352, i32 0, i32 1
  store { i64, i64, i64 } %t359, ptr %t360
  %t361 = load { i64, [3 x i64] }, ptr %t352
  %t362 = load %"compiler/diagmsg:Msg", ptr %l16
  %t363 = load ptr, ptr %l169, !tbaa !29
  %t366 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t363, { i64, [3 x i64] } %t361, %"compiler/diagmsg:Msg" %t362)
  store i64 %t366, ptr %l187
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb68:
  %t367 = load i64, ptr %l12, !tbaa !24
  %t370 = add i64 %t367, 1
  store i64 %t370, ptr %l12, !tbaa !24
  br label %bb15
bb69:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 2
  %t378 = load i32, ptr %l4, !tbaa !23
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t377, i32 %t378)
  store i32 %t381, ptr %l195
  br label %bb70
bb70:
  %t382 = load i32, ptr %l195, !tbaa !23
  store i32 %t382, ptr %l17, !tbaa !23
  %t383 = load i32, ptr %l17, !tbaa !23
  %t384 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t387 = icmp eq i32 %t383, %t384
  br i1 %t387, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l199, !tbaa !21
  br label %bb73
bb72:
  %t389 = load i32, ptr %l17, !tbaa !23
  %t390 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t393 = icmp eq i32 %t389, %t390
  store i1 %t393, ptr %l199, !tbaa !21
  br label %bb73
bb73:
  %t395 = load i1, ptr %l199, !tbaa !21
  br i1 %t395, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l203, !tbaa !21
  br label %bb76
bb75:
  %t396 = load i32, ptr %l17, !tbaa !23
  %t397 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t400 = icmp eq i32 %t396, %t397
  store i1 %t400, ptr %l203, !tbaa !21
  br label %bb76
bb76:
  %t402 = load i1, ptr %l203, !tbaa !21
  br i1 %t402, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb79
bb78:
  %t403 = load ptr, ptr %l2, !tbaa !29
  %t405 = getelementptr %"compiler/ast:Func", ptr %t403, i32 0, i32 3
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = getelementptr %"compiler/ast:Sig", ptr %t406, i32 0, i32 1
  %t409 = load { i64, ptr }, ptr %t408, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t409, 0
  %t413 = icmp eq i64 %t411, 0
  store i1 %t413, ptr %l207, !tbaa !21
  br label %bb79
bb79:
  %t415 = load i1, ptr %l207, !tbaa !21
  br i1 %t415, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  br label %bb82
bb82:
  %t416 = load ptr, ptr %l2, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Func", ptr %t416, i32 0, i32 3
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t421 = getelementptr %"compiler/ast:Sig", ptr %t419, i32 0, i32 1
  %t422 = load { i64, ptr }, ptr %t421, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t422, 0
  %t426 = icmp sgt i64 %t424, 1
  br i1 %t426, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb86
bb84:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i32, ptr %l17, !tbaa !23
  %t432 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t428, i32 %t429)
  store i1 %t432, ptr %l221
  br label %bb85
bb85:
  %t433 = load i1, ptr %l221, !tbaa !21
  %t434 = xor i1 %t433, true
  store i1 %t434, ptr %l218, !tbaa !21
  br label %bb86
bb86:
  %t436 = load i1, ptr %l218, !tbaa !21
  br i1 %t436, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s9
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t442 = getelementptr %"compiler/generic:Program", ptr %t440, i32 0, i32 2
  store ptr %t442, ptr %l225, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load i32, ptr %l17, !tbaa !23
  %t447 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t443, i32 %t444)
  store i32 %t447, ptr %l228
  br label %bb89
bb88:
  br label %bb104
bb89:
  %t448 = load ptr, ptr %l225, !tbaa !29
  %t449 = load i32, ptr %l228, !tbaa !23
  %t450 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t448, i32 %t449)
  store i1 %t450, ptr %l229
  br label %bb90
bb90:
  %t451 = load i1, ptr %l229, !tbaa !21
  br i1 %t451, label %bb91, label %bb92
bb91:
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t454 = getelementptr %"compiler/ast:Func", ptr %t452, i32 0, i32 3
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = getelementptr %"compiler/ast:Sig", ptr %t455, i32 0, i32 1
  %t458 = load { i64, ptr }, ptr %t457, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t458, 0
  %t462 = icmp eq i64 %t460, 1
  store i1 %t462, ptr %l230, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb93
bb93:
  %t464 = load i1, ptr %l230, !tbaa !21
  br i1 %t464, label %bb94, label %bb95
bb94:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load i32, ptr %l17, !tbaa !23
  %t469 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t465, i32 %t466)
  store { i64, ptr } %t469, ptr %l239
  br label %bb96
bb95:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i32, ptr %l17, !tbaa !23
  %t474 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t470, i32 %t471)
  store { i64, ptr } %t474, ptr %l244
  br label %bb98
bb96:
  %t475 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t477 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedByValueC(ptr %s9, ptr %v0, { i64, ptr } %t475)
  store %"compiler/diagmsg:Msg" %t477, ptr %l241
  br label %bb97
bb97:
  %t478 = load %"compiler/diagmsg:Msg", ptr %l241
  store %"compiler/diagmsg:Msg" %t478, ptr %l236
  br label %bb100
bb98:
  %t479 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t481 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExternResult(ptr %s9, ptr %v0, { i64, ptr } %t479)
  store %"compiler/diagmsg:Msg" %t481, ptr %l246
  br label %bb99
bb99:
  %t482 = load %"compiler/diagmsg:Msg", ptr %l246
  store %"compiler/diagmsg:Msg" %t482, ptr %l236
  br label %bb100
bb100:
  %t483 = load %"compiler/diagmsg:Msg", ptr %l236
  store %"compiler/diagmsg:Msg" %t483, ptr %l18
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = getelementptr %"compiler/check:Checker", ptr %t484, i32 0, i32 1
  %t487 = load ptr, ptr %t486, !tbaa !29
  %t489 = getelementptr %"compiler/generic:Program", ptr %t487, i32 0, i32 0
  %t490 = load ptr, ptr %t489, !tbaa !29
  %t492 = getelementptr %"compiler/load:Loader", ptr %t490, i32 0, i32 4
  %t493 = load ptr, ptr %t492, !tbaa !29
  store ptr %t493, ptr %l250, !tbaa !29
  %t494 = load i64, ptr %l7, !tbaa !24
  store i64 %t494, ptr %l251, !tbaa !24
  %t495 = load ptr, ptr %l2, !tbaa !29
  %t497 = getelementptr %"compiler/ast:Func", ptr %t495, i32 0, i32 3
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t500 = getelementptr %"compiler/ast:Sig", ptr %t498, i32 0, i32 1
  %t501 = load { i64, ptr }, ptr %t500, !tbaa !27
  store { i64, ptr } %t501, ptr %l254, !tbaa !27
  %t502 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !27
  %t504 = getelementptr ptr, ptr %t503, i64 0
  %t505 = load ptr, ptr %t504, !tbaa !39
  %t507 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t505)
  store %"compiler/source:Span" %t507, ptr %l256
  br label %bb101
bb101:
  %t508 = getelementptr %"compiler/source:Span", ptr %l256, i32 0, i32 0
  %t509 = load i32, ptr %t508, !tbaa !23
  %t511 = sext i32 %t509 to i64
  store i64 %t511, ptr %l258, !tbaa !24
  %t512 = load ptr, ptr %l2, !tbaa !29
  %t514 = getelementptr %"compiler/ast:Func", ptr %t512, i32 0, i32 3
  %t515 = load ptr, ptr %t514, !tbaa !29
  %t517 = getelementptr %"compiler/ast:Sig", ptr %t515, i32 0, i32 1
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  store { i64, ptr } %t518, ptr %l261, !tbaa !27
  %t519 = load ptr, ptr %l2, !tbaa !29
  %t521 = getelementptr %"compiler/ast:Func", ptr %t519, i32 0, i32 3
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = getelementptr %"compiler/ast:Sig", ptr %t522, i32 0, i32 1
  %t525 = load { i64, ptr }, ptr %t524, !tbaa !27
  %t527 = extractvalue { i64, ptr } %t525, 0
  %t529 = sub i64 %t527, 1
  %t531 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr ptr, ptr %t532, i64 %t529
  %t534 = load ptr, ptr %t533, !tbaa !39
  %t536 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t534)
  store %"compiler/source:Span" %t536, ptr %l268
  br label %bb102
bb102:
  %t537 = getelementptr %"compiler/source:Span", ptr %l268, i32 0, i32 1
  %t538 = load i32, ptr %t537, !tbaa !23
  %t540 = sext i32 %t538 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t541
  %t542 = getelementptr { i64, [3 x i64] }, ptr %t541, i32 0, i32 0
  store i64 3, ptr %t542
  %t543 = load i64, ptr %l251, !tbaa !24
  %t544 = insertvalue { i64, i64, i64 } undef, i64 %t543, 0
  %t545 = load i64, ptr %l258, !tbaa !24
  %t546 = insertvalue { i64, i64, i64 } %t544, i64 %t545, 1
  %t548 = insertvalue { i64, i64, i64 } %t546, i64 %t540, 2
  %t549 = getelementptr { i64, [3 x i64] }, ptr %t541, i32 0, i32 1
  store { i64, i64, i64 } %t548, ptr %t549
  %t550 = load { i64, [3 x i64] }, ptr %t541
  %t551 = load %"compiler/diagmsg:Msg", ptr %l18
  %t552 = load ptr, ptr %l250, !tbaa !29
  %t555 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t552, { i64, [3 x i64] } %t550, %"compiler/diagmsg:Msg" %t551)
  store i64 %t555, ptr %l273
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s9)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efixedInt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l6 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l7 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l8 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca i32
  %l26 = alloca i1
  %l27 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l32 = alloca i64
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca i64
  %l44 = alloca ptr
  %l47 = alloca %"compiler/generic:Context"
  %l49 = alloca ptr
  %l52 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l53 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l55 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l56 = alloca i32
  %l58 = alloca i1
  %l65 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l66 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l68 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l69 = alloca i32
  %l71 = alloca i1
  %l76 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i64
  %l104 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l120 = alloca i32
  %l123 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t60 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 166
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t12 = call { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %s0, ptr %t7, ptr %t8)
  %t13 = extractvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t12, 1
  %t14 = extractvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t12, 0
  store i32 %t14, ptr %l24
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16, !prof !99
ok.16:
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t13, ptr %l23
  br label %bb2
bb2:
  %t17 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l19
  br label %bb6
bb3:
  %t18 = load i32, ptr %l24, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  store i1 %t21, ptr %l26, !tbaa !21
  br label %bb4
bb4:
  %t22 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %l27
  br label %bb5
bb5:
  %t23 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t23, ptr %l19
  br label %bb6
bb6:
  %t24 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t24, ptr %l3
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 166
  %t28 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb7
bb7:
  %t32 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H51b81a00fa8bf5fab3fd9fdb4d8e9d32(ptr %s0, ptr %l3)
  store i64 %t32, ptr %l32
  br label %bb8
bb8:
  %t33 = load i64, ptr %l32, !tbaa !24
  %t34 = icmp eq i64 %t33, 0
  br i1 %t34, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb12
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsLength(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i64 0)
  store i1 %t40, ptr %l37
  br label %bb11
bb11:
  %t41 = load i1, ptr %l37, !tbaa !21
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l34, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t44)
  store ptr %t46, ptr %l40
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l40, !tbaa !29
  %t49 = getelementptr %"compiler/check:frame", ptr %t47, i32 0, i32 4
  %t50 = getelementptr %"compiler/generic:Context", ptr %t49, i32 0, i32 0
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l42, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t52)
  store ptr %t54, ptr %l44
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l44, !tbaa !29
  %t57 = getelementptr %"compiler/check:frame", ptr %t55, i32 0, i32 4
  %t58 = getelementptr %"compiler/generic:Context", ptr %t57, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = load i64, ptr %l42, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t60, ptr %s0, i64 %t61, i64 %t59)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t60, i64 160, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l47, i64 160, i1 false)
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l49
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l49, !tbaa !29
  %t68 = getelementptr %"compiler/check:frame", ptr %t66, i32 0, i32 4
  %t69 = getelementptr %"compiler/generic:Context", ptr %t68, i32 0, i32 2
  %t71 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t69)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t71, ptr %l52
  br label %bb20
bb20:
  %t72 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l52
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t72, ptr %l5
  br label %bb21
bb21:
  %t74 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l5)
  %t75 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t74, 1
  %t76 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t74, 0
  store i32 %t76, ptr %l56
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb23, label %ok.78, !prof !99
ok.78:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t75, ptr %l55
  br label %bb22
bb22:
  %t79 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l55
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t79, ptr %l53
  br label %bb25
bb23:
  %t80 = load i32, ptr %l56, !tbaa !23
  %t81 = ashr i32 %t80, 16
  %t83 = icmp eq i32 %t81, 1
  store i1 %t83, ptr %l58, !tbaa !21
  br label %bb24
bb24:
  br label %bb28
bb25:
  %t84 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l53
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t84, ptr %l6
  %t85 = getelementptr %"compiler/generic:Context", ptr %l4, i32 0, i32 2
  %t86 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l6, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l6, i32 0, i32 1
  %t89 = load i32, ptr %t88, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t85, i32 %t87, i32 %t89)
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb21
bb28:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t95)
  br label %bb29
bb29:
  %t98 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %s0, ptr %s0, ptr %l3)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t98, ptr %l65
  br label %bb30
bb30:
  %t99 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l65
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t99, ptr %l7
  br label %bb31
bb31:
  %t101 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %s0, ptr %l7)
  %t102 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t101, 1
  %t103 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t101, 0
  store i32 %t103, ptr %l69
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb33, label %ok.105, !prof !99
ok.105:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t102, ptr %l68
  br label %bb32
bb32:
  %t106 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l68
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t106, ptr %l66
  br label %bb35
bb33:
  %t107 = load i32, ptr %l69, !tbaa !23
  %t108 = ashr i32 %t107, 16
  %t110 = icmp eq i32 %t108, 1
  store i1 %t110, ptr %l71, !tbaa !21
  br label %bb34
bb34:
  br label %bb38
bb35:
  %t111 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l66
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t111, ptr %l8
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 46
  %t115 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l8, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t114, i64 %t116)
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb31
bb38:
  store i64 0, ptr %l9, !tbaa !24
  %t120 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H51b81a00fa8bf5fab3fd9fdb4d8e9d32(ptr %s0, ptr %l3)
  store i64 %t120, ptr %l76
  br label %bb39
bb39:
  %t121 = load i64, ptr %l76, !tbaa !24
  store i64 %t121, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb40, label %bb41
bb40:
  %t128 = load i64, ptr %l11, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb45
bb42:
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l83, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb44
bb44:
  %t148 = load i64, ptr %l83, !tbaa !24
  store i64 %t148, ptr %l80, !tbaa !24
  br label %bb45
bb45:
  %t149 = load i64, ptr %l80, !tbaa !24
  store i64 %t149, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb46
bb46:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb47, label %bb48
bb47:
  br label %bb55
bb48:
  br label %bb49
bb49:
  %t158 = load i64, ptr %l9, !tbaa !24
  %t159 = load i64, ptr %l13, !tbaa !24
  %t160 = load i64, ptr %l11, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l14, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindFixed(ptr %v0, ptr %s0, ptr %s0, ptr %t168, ptr %l4, ptr %l3)
  store i64 %t172, ptr %l104
  br label %bb50
bb50:
  %t173 = load i64, ptr %l104, !tbaa !24
  %t174 = icmp eq i64 %t173, 0
  br i1 %t174, label %bb51, label %bb52
bb51:
  br label %bb55
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t176 = load i64, ptr %l13, !tbaa !24
  %t179 = add i64 %t176, 1
  store i64 %t179, ptr %l13, !tbaa !24
  br label %bb46
bb55:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/check:Checker", ptr %t181, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !29
  store ptr %t184, ptr %l110, !tbaa !29
  store ptr %l4, ptr %l111, !tbaa !29
  %t185 = load ptr, ptr %l1, !tbaa !29
  store ptr %t185, ptr %l112, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t186)
  store i32 %t188, ptr %l114
  br label %bb56
bb56:
  %t189 = load ptr, ptr %l110, !tbaa !29
  %t190 = load ptr, ptr %l111, !tbaa !29
  %t191 = load ptr, ptr %l112, !tbaa !29
  %t192 = load i32, ptr %l114, !tbaa !23
  %t193 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %s0, ptr %v1, ptr %t189, ptr %t190, ptr %t191, i32 %t192)
  store i32 %t193, ptr %l115
  br label %bb57
bb57:
  %t194 = load i32, ptr %l115, !tbaa !23
  store i32 %t194, ptr %l15, !tbaa !23
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l15, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l120
  br label %bb58
bb58:
  %t205 = load i32, ptr %l120, !range !{i32 0, i32 33}
  %t207 = trunc i64 26 to i32
  %t208 = icmp eq i32 %t205, %t207
  br i1 %t208, label %bb59, label %bb60
bb59:
  %t210 = load i32, ptr %l15, !tbaa !23
  store i32 %t210, ptr %l123, !tbaa !23
  br label %bb61
bb60:
  store i32 -1, ptr %l123, !tbaa !23
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t212 = load i32, ptr %l123, !tbaa !23
  store i32 %t212, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca %"compiler/source:Span"
  %l21 = alloca { i64, ptr }
  %l23 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca i32
  %l39 = alloca i32
  %l43 = alloca i1
  %l49 = alloca ptr
  %l54 = alloca i32
  %l57 = alloca i1
  %l62 = alloca i32
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l74 = alloca ptr
  %l77 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l87 = alloca ptr
  %l90 = alloca ptr
  %l93 = alloca i32
  %l96 = alloca i32
  %l101 = alloca i1
  %l103 = alloca i1
  %l106 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca ptr
  %l113 = alloca i1
  %l114 = alloca i32
  %l117 = alloca { i64, ptr }
  %l119 = alloca %"compiler/diagmsg:Msg"
  %l120 = alloca i64
  %l124 = alloca ptr
  %l127 = alloca i32
  %l130 = alloca i32
  %l136 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca %"compiler/diagmsg:Msg"
  %l149 = alloca i64
  %l153 = alloca ptr
  %l161 = alloca ptr
  %l164 = alloca ptr
  %l168 = alloca ptr
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t2)
  store %"compiler/source:Span" %t4, ptr %l17
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t5)
  store %"compiler/source:Span" %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t10 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t8)
  store { i64, ptr } %t10, ptr %l21
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = load ptr, ptr %l15, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l17
  %t15 = load %"compiler/source:Span", ptr %l19
  %t17 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t13, %"compiler/source:Span" %t14, %"compiler/source:Span" %t15, i64 %t12)
  store %"compiler/source:Span" %t17, ptr %l23
  br label %bb4
bb4:
  %t18 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t18, ptr %l5
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t26 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t19, ptr %t20, i32 %t22)
  store ptr %t26, ptr %l28
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l28, !tbaa !29
  store ptr %t27, ptr %l6, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t28, ptr %t29, i32 %t31)
  store ptr %t35, ptr %l33
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l33, !tbaa !29
  store ptr %t36, ptr %l7, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t40 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t37)
  store i32 %t40, ptr %l36
  br label %bb7
bb7:
  %t41 = load i32, ptr %l36, !tbaa !23
  store i32 %t41, ptr %l8, !tbaa !23
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t45 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t42)
  store i32 %t45, ptr %l39
  br label %bb8
bb8:
  %t46 = load i32, ptr %l39, !tbaa !23
  store i32 %t46, ptr %l9, !tbaa !23
  %t47 = load i32, ptr %l8, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t51 = icmp eq i32 %t47, %t48
  br i1 %t51, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb11
bb10:
  %t53 = load i32, ptr %l9, !tbaa !23
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = icmp eq i32 %t53, %t54
  store i1 %t57, ptr %l43, !tbaa !21
  br label %bb11
bb11:
  %t59 = load i1, ptr %l43, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t60, %"compiler/source:Span" %t61)
  store ptr %t64, ptr %l49
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load ptr, ptr %l49, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb15:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l8, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l54
  br label %bb16
bb16:
  %t76 = load i32, ptr %l54, !range !{i32 0, i32 33}
  %t78 = trunc i64 21 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l9, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l62
  br label %bb19
bb18:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb20
bb19:
  %t91 = load i32, ptr %l62, !range !{i32 0, i32 33}
  %t93 = trunc i64 21 to i32
  %t94 = icmp eq i32 %t91, %t93
  store i1 %t94, ptr %l57, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l57, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l65, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t98, ptr %l66
  %t99 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t101 = trunc i64 28 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb23, label %bb24
bb22:
  br label %bb27
bb23:
  store i32 95, ptr %l69
  br label %bb25
bb24:
  store i32 96, ptr %l69
  br label %bb25
bb25:
  %t106 = load ptr, ptr %l6, !tbaa !29
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t108 = load ptr, ptr %l65, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l66
  %t110 = load i32, ptr %l69, !range !{i32 0, i32 116}
  %t113 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t108, %"compiler/source:Span" %t109, i32 %t110, ptr %t106, ptr %t107, i1 false)
  store ptr %t113, ptr %l74
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t114 = load ptr, ptr %l74, !tbaa !29
  store ptr %t114, ptr %rv
  br label %ret
bb27:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l8, !tbaa !23
  %t119 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t115, i32 %t116)
  store i1 %t119, ptr %l77
  br label %bb28
bb28:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l9, !tbaa !23
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l80
  br label %bb29
bb29:
  %t125 = load i1, ptr %l77, !tbaa !21
  %t126 = load i1, ptr %l80, !tbaa !21
  %t127 = icmp ne i1 %t125, %t126
  br i1 %t127, label %bb30, label %bb31
bb30:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l8, !tbaa !23
  %t133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t133, ptr %l84
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t134 = load i1, ptr %l84, !tbaa !21
  br i1 %t134, label %bb33, label %bb34
bb33:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l7, !tbaa !29
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceObject(ptr %v0, ptr %v3, ptr %v3, ptr %t135, ptr %t136)
  store ptr %t139, ptr %l87
  br label %bb35
bb34:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l6, !tbaa !29
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceObject(ptr %v0, ptr %v3, ptr %v3, ptr %t140, ptr %t141)
  store ptr %t144, ptr %l90
  br label %bb36
bb35:
  %t145 = load ptr, ptr %l87, !tbaa !29
  store ptr %t145, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  %t146 = load ptr, ptr %l90, !tbaa !29
  store ptr %t146, ptr %l6, !tbaa !29
  br label %bb37
bb37:
  %t147 = load ptr, ptr %l6, !tbaa !29
  %t150 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t147)
  store i32 %t150, ptr %l93
  br label %bb38
bb38:
  %t151 = load i32, ptr %l93, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  %t152 = load ptr, ptr %l7, !tbaa !29
  %t155 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t152)
  store i32 %t155, ptr %l96
  br label %bb39
bb39:
  %t156 = load i32, ptr %l96, !tbaa !23
  %t157 = load i32, ptr %l10, !tbaa !23
  store i32 %t157, ptr %l8, !tbaa !23
  store i32 %t156, ptr %l9, !tbaa !23
  br label %bb40
bb40:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l8, !tbaa !23
  %t165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t161, i32 %t162)
  store i1 %t165, ptr %l101
  br label %bb41
bb41:
  %t166 = load i1, ptr %l101, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb45
bb43:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l9, !tbaa !23
  %t173 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l106
  br label %bb44
bb44:
  %t174 = load i1, ptr %l106, !tbaa !21
  %t175 = xor i1 %t174, true
  store i1 %t175, ptr %l103, !tbaa !21
  br label %bb45
bb45:
  %t177 = load i1, ptr %l103, !tbaa !21
  br i1 %t177, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s6
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l108, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t179, ptr %l109
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l110, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l8, !tbaa !23
  %t185 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t181, i32 %t182)
  store i1 %t185, ptr %l113
  br label %bb48
bb47:
  br label %bb56
bb48:
  %t186 = load i1, ptr %l113, !tbaa !21
  br i1 %t186, label %bb49, label %bb50
bb49:
  %t187 = load i32, ptr %l9, !tbaa !23
  store i32 %t187, ptr %l114, !tbaa !23
  br label %bb51
bb50:
  %t189 = load i32, ptr %l8, !tbaa !23
  store i32 %t189, ptr %l114, !tbaa !23
  br label %bb51
bb51:
  %t191 = load ptr, ptr %l110, !tbaa !29
  %t192 = load i32, ptr %l114, !tbaa !23
  %t193 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t191, i32 %t192)
  store { i64, ptr } %t193, ptr %l117
  br label %bb52
bb52:
  %t194 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t196 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIdentityOfValue(ptr %s6, ptr %v0, { i64, ptr } %t194)
  store %"compiler/diagmsg:Msg" %t196, ptr %l119
  br label %bb53
bb53:
  %t197 = load ptr, ptr %l108, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l109
  %t199 = load %"compiler/diagmsg:Msg", ptr %l119
  %t200 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t197, %"compiler/source:Span" %t198, %"compiler/diagmsg:Msg" %t199)
  store i64 %t200, ptr %l120
  br label %bb54
bb54:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t203 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t207 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t201, %"compiler/source:Span" %t202, i32 %t203, i64 0)
  store ptr %t207, ptr %l124
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t208 = load ptr, ptr %l124, !tbaa !29
  store ptr %t208, ptr %rv
  br label %ret
bb56:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l8, !tbaa !23
  %t213 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t209, i32 %t210)
  store i32 %t213, ptr %l127
  br label %bb57
bb57:
  %t214 = load i32, ptr %l127, !tbaa !23
  store i32 %t214, ptr %l12, !tbaa !23
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr %l9, !tbaa !23
  %t219 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t215, i32 %t216)
  store i32 %t219, ptr %l130
  br label %bb58
bb58:
  %t220 = load i32, ptr %l130, !tbaa !23
  store i32 %t220, ptr %l13, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t224, i32 0, i32 2
  %t227 = load i32, ptr %l12, !tbaa !23
  %t228 = load i32, ptr %l13, !tbaa !23
  %t232 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t226, i32 %t227, i32 %t228)
  store i1 %t232, ptr %l136
  br label %bb59
bb59:
  %t233 = load i1, ptr %l136, !tbaa !21
  %t234 = xor i1 %t233, true
  br i1 %t234, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s7
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l138, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t237, ptr %l139
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i32, ptr %l12, !tbaa !23
  %t242 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t238, i32 %t239)
  store { i64, ptr } %t242, ptr %l142
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t243 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t243, ptr %l143, !tbaa !27
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l13, !tbaa !23
  %t248 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t244, i32 %t245)
  store { i64, ptr } %t248, ptr %l146
  br label %bb63
bb63:
  %t249 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t252 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s7, ptr %s7, ptr %v0, { i64, ptr } %t250, { i64, ptr } %t249)
  store %"compiler/diagmsg:Msg" %t252, ptr %l148
  br label %bb64
bb64:
  %t253 = load ptr, ptr %l138, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l139
  %t255 = load %"compiler/diagmsg:Msg", ptr %l148
  %t256 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t253, %"compiler/source:Span" %t254, %"compiler/diagmsg:Msg" %t255)
  store i64 %t256, ptr %l149
  br label %bb65
bb65:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l1
  %t259 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t257, %"compiler/source:Span" %t258, i32 %t259, i64 0)
  store ptr %t263, ptr %l153
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t264 = load ptr, ptr %l153, !tbaa !29
  store ptr %t264, ptr %rv
  br label %ret
bb67:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  %t267 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t268 = load ptr, ptr %l6, !tbaa !29
  %t269 = load ptr, ptr %l7, !tbaa !29
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t265, %"compiler/source:Span" %t266, i32 %t267, i32 19, ptr %t268, ptr %t269)
  store ptr %t277, ptr %l161
  br label %bb68
bb68:
  %t278 = load ptr, ptr %l161, !tbaa !29
  store ptr %t278, ptr %l14, !tbaa !29
  %t279 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t281 = trunc i64 106 to i32
  %t282 = icmp eq i32 %t279, %t281
  br i1 %t282, label %bb69, label %bb70
bb69:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l1
  %t286 = load ptr, ptr %l14, !tbaa !29
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t284, %"compiler/source:Span" %t285, ptr %t286)
  store ptr %t290, ptr %l168
  br label %bb71
bb70:
  %t291 = load ptr, ptr %l14, !tbaa !29
  store ptr %t291, ptr %l164, !tbaa !29
  br label %bb72
bb71:
  %t293 = load ptr, ptr %l168, !tbaa !29
  store ptr %t293, ptr %l164, !tbaa !29
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t294 = load ptr, ptr %l164, !tbaa !29
  store ptr %t294, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:AnySlot"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l116 = alloca i32
  %l119 = alloca ptr
  %l126 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l157 = alloca ptr
  %l161 = alloca i32
  %l162 = alloca i32
  %l165 = alloca ptr
  %l169 = alloca i32
  %l177 = alloca i64
  %l179 = alloca i64
  %l184 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t96 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i32 %t10, ptr %l29
  br label %bb2
bb2:
  %t11 = load i32, ptr %l29, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 28
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l32
  br label %bb3
bb3:
  %t17 = load i64, ptr %l32, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l33, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 15
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = add i64 %t21, 1
  %t26 = load ptr, ptr %l33, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 15
  store i64 %t24, ptr %t27, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 57
  store i32 0, ptr %t30, !tbaa !23
  store ptr null, ptr %l8, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = icmp slt i64 %t31, -1
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  store ptr %t40, ptr %l42, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t44 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t41)
  store i32 %t44, ptr %l45
  br label %bb6
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l78, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %l79
  %t47 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t47, ptr %l80
  %t48 = load i64, ptr %l2, !tbaa !24
  store i64 %t48, ptr %l81, !tbaa !24
  %t49 = load ptr, ptr %l3, !tbaa !29
  store ptr %t49, ptr %l83, !tbaa !29
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb15, label %bb16
bb6:
  %t53 = load ptr, ptr %l42, !tbaa !29
  %t54 = load i32, ptr %l45, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t55, ptr %l46
  br label %bb7
bb7:
  %t56 = load i32, ptr %l46, !tbaa !23
  store i32 %t56, ptr %l9, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i32, ptr %l9, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t60, i32 %t61)
  store { i64, ptr } %t64, ptr %l50
  br label %bb8
bb8:
  %t65 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t65, ptr %l51, !tbaa !27
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = sub i64 -2, %t66
  %t70 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr %"compiler/generic:AnySlot", ptr %t71, i64 %t68
  %t73 = load %"compiler/generic:AnySlot", ptr %t72
  store %"compiler/generic:AnySlot" %t73, ptr %l10
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l9, !tbaa !23
  %t77 = load i64, ptr %l2, !tbaa !24
  %t79 = sub i64 -2, %t77
  %t80 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t75, i32 %t76, i64 %t79, %"compiler/source:Span" %t80)
  br label %bb9
bb9:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l60, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t86, ptr %l61
  %t87 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t87, ptr %l62
  %t88 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t89 = load i32, ptr %t88, !tbaa !23
  store i32 %t89, ptr %l63, !tbaa !23
  %t90 = load i32, ptr %l9, !tbaa !23
  %t91 = load i64, ptr %l2, !tbaa !24
  %t93 = sub i64 -2, %t91
  %t94 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t95 = load i32, ptr %t94, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 0
  store i64 3, ptr %t97
  %t99 = insertvalue { i32, i64, i32 } undef, i32 %t90, 0
  %t101 = insertvalue { i32, i64, i32 } %t99, i64 %t93, 1
  %t103 = insertvalue { i32, i64, i32 } %t101, i32 %t95, 2
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  store { i32, i64, i32 } %t103, ptr %t104
  %t105 = load { i64, [3 x i64] }, ptr %t96
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store { i64, [3 x i64] } %t105, ptr %t107
  store ptr %t107, ptr %l69, !tbaa !29
  %t108 = load ptr, ptr %l3, !tbaa !29
  store ptr %t108, ptr %l71, !tbaa !29
  %t110 = icmp sge i64 0, 0
  br i1 %t110, label %bb10, label %bb11
bb10:
  %t112 = icmp sle i64 0, 1152921504606846975
  br i1 %t112, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb12:
  %t114 = mul i64 0, 8
  %t115 = insertvalue { i64, ptr } undef, i64 0, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t117 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t118 = load ptr, ptr %l60, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l61
  %t120 = load %"compiler/source:Span", ptr %l62
  %t121 = load i32, ptr %l63, !tbaa !23
  %t122 = load ptr, ptr %l69, !tbaa !29
  %t123 = load ptr, ptr %l71, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v3, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %t118, %"compiler/source:Span" %t119, %"compiler/source:Span" %t120, i32 %t121, ptr %t122, i64 -1, ptr %t123, { i64, ptr } %t116, { i64, ptr } %t117)
  store ptr %t126, ptr %l76
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb14:
  %t127 = load ptr, ptr %l76, !tbaa !29
  store ptr %t127, ptr %l8, !tbaa !29
  br label %bb24
bb15:
  %t129 = icmp sle i64 0, 1152921504606846975
  br i1 %t129, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb17:
  %t131 = mul i64 0, 8
  %t132 = insertvalue { i64, ptr } undef, i64 0, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t133, ptr %l86, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t134, ptr %l87, !tbaa !27
  %t135 = icmp sge i64 0, 0
  br i1 %t135, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb19:
  %t137 = icmp sle i64 0, 2305843009213693951
  br i1 %t137, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb21:
  %t139 = mul i64 0, 4
  %t140 = insertvalue { i64, ptr } undef, i64 0, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t142 = load ptr, ptr %l78, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l79
  %t144 = load %"compiler/source:Span", ptr %l80
  %t145 = load i64, ptr %l81, !tbaa !24
  %t146 = load ptr, ptr %l83, !tbaa !29
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t150 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %t142, %"compiler/source:Span" %t143, %"compiler/source:Span" %t144, i64 %t145, ptr %t146, { i64, ptr } %t147, { i64, ptr } %t148, { i64, ptr } %t141)
  store ptr %t150, ptr %l91
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb23:
  %t151 = load ptr, ptr %l91, !tbaa !29
  store ptr %t151, ptr %l8, !tbaa !29
  br label %bb24
bb24:
  %t153 = load ptr, ptr %l5, !tbaa !29
  store ptr %t153, ptr %l93, !tbaa !29
  %t154 = load ptr, ptr %l93, !tbaa !29
  %t155 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 15
  %t156 = load i64, ptr %t155, !tbaa !24
  %t159 = sub i64 %t156, 1
  %t161 = load ptr, ptr %l93, !tbaa !29
  %t162 = getelementptr %"compiler/check:frame", ptr %t161, i32 0, i32 15
  store i64 %t159, ptr %t162, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 57
  %t172 = load i32, ptr %t171, !tbaa !23
  %t175 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t168, i32 %t172)
  store { i64, ptr } %t175, ptr %l102
  br label %bb25
bb25:
  %t176 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t176, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t181 = load i64, ptr %l12, !tbaa !24
  %t182 = load i64, ptr %l13, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t189 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t189, ptr %l109, !tbaa !27
  %t190 = load i64, ptr %l12, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i32, ptr %t193, i64 %t190
  %t195 = load i32, ptr %t194, !tbaa !33
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t202, i32 %t195)
  store i32 %t206, ptr %l116
  br label %bb30
bb30:
  %t207 = load i32, ptr %l6, !tbaa !23
  %t208 = load i32, ptr %l116, !tbaa !23
  %t210 = icmp ne i32 %t208, %t207
  br i1 %t210, label %bb31, label %bb32
bb31:
  %t212 = load ptr, ptr %l5, !tbaa !29
  store ptr %t212, ptr %l119, !tbaa !29
  %t213 = load ptr, ptr %l119, !tbaa !29
  %t214 = getelementptr %"compiler/check:frame", ptr %t213, i32 0, i32 17
  %t215 = load i64, ptr %t214, !tbaa !24
  %t218 = add i64 %t215, 1
  %t220 = load ptr, ptr %l119, !tbaa !29
  %t221 = getelementptr %"compiler/check:frame", ptr %t220, i32 0, i32 17
  store i64 %t218, ptr %t221, !tbaa !24
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t222 = load i64, ptr %l12, !tbaa !24
  %t225 = add i64 %t222, 1
  store i64 %t225, ptr %l12, !tbaa !24
  br label %bb26
bb35:
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l126
  br label %bb36
bb36:
  %t228 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l15
  %t229 = load i64, ptr %l7, !tbaa !24
  store i64 %t229, ptr %l16, !tbaa !24
  %t231 = load ptr, ptr %l5, !tbaa !29
  %t233 = getelementptr %"compiler/check:frame", ptr %t231, i32 0, i32 28
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t233)
  store i64 %t235, ptr %l130
  br label %bb37
bb37:
  %t236 = load i64, ptr %l130, !tbaa !24
  store i64 %t236, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t237 = load i64, ptr %l17, !tbaa !24
  %t238 = load i64, ptr %l16, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb38, label %bb39
bb38:
  %t243 = load i64, ptr %l18, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb43
bb40:
  %t247 = load i64, ptr %l17, !tbaa !24
  %t248 = load i64, ptr %l16, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l18, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l18, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l137, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb42
bb42:
  %t263 = load i64, ptr %l137, !tbaa !24
  store i64 %t263, ptr %l134, !tbaa !24
  br label %bb43
bb43:
  %t264 = load i64, ptr %l134, !tbaa !24
  store i64 %t264, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  %t265 = load i64, ptr %l20, !tbaa !24
  %t266 = load i64, ptr %l19, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb45, label %bb46
bb45:
  br label %bb56
bb46:
  br label %bb47
bb47:
  %t273 = load i64, ptr %l16, !tbaa !24
  %t274 = load i64, ptr %l20, !tbaa !24
  %t275 = load i64, ptr %l18, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l21, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t288 = getelementptr %"compiler/generic:Program", ptr %t286, i32 0, i32 2
  store ptr %t288, ptr %l157, !tbaa !29
  %t289 = load ptr, ptr %l5, !tbaa !29
  %t291 = getelementptr %"compiler/check:frame", ptr %t289, i32 0, i32 28
  %t292 = load i64, ptr %l21, !tbaa !24
  %t295 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t291, i64 %t292)
  store i32 %t295, ptr %l161
  br label %bb48
bb48:
  %t296 = load ptr, ptr %l157, !tbaa !29
  %t297 = load i32, ptr %l161, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t296, i32 %t297)
  store i32 %t298, ptr %l162
  br label %bb49
bb49:
  %t299 = load i32, ptr %l6, !tbaa !23
  %t300 = load i32, ptr %l162, !tbaa !23
  %t302 = icmp ne i32 %t300, %t299
  br i1 %t302, label %bb50, label %bb51
bb50:
  store ptr %l15, ptr %l165, !tbaa !29
  %t304 = load ptr, ptr %l5, !tbaa !29
  %t306 = getelementptr %"compiler/check:frame", ptr %t304, i32 0, i32 28
  %t307 = load i64, ptr %l21, !tbaa !24
  %t310 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t306, i64 %t307)
  store i32 %t310, ptr %l169
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t311 = load ptr, ptr %l165, !tbaa !29
  %t312 = load i32, ptr %l169, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t311, i32 %t312)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t313 = load i64, ptr %l20, !tbaa !24
  %t316 = add i64 %t313, 1
  store i64 %t316, ptr %l20, !tbaa !24
  br label %bb44
bb56:
  %t318 = load ptr, ptr %l5, !tbaa !29
  %t320 = getelementptr %"compiler/check:frame", ptr %t318, i32 0, i32 28
  %t321 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t320, i64 %t321)
  br label %bb57
bb57:
  store ptr %l15, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t325 = load i64, ptr %l23, !tbaa !24
  store i64 %t325, ptr %l177, !tbaa !24
  %t326 = load ptr, ptr %l22, !tbaa !29
  %t328 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t326)
  store i64 %t328, ptr %l179
  br label %bb59
bb59:
  %t329 = load i64, ptr %l177, !tbaa !24
  %t330 = load i64, ptr %l179, !tbaa !24
  %t331 = icmp slt i64 %t329, %t330
  %t333 = xor i1 %t331, true
  br i1 %t333, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t335 = load ptr, ptr %l22, !tbaa !29
  %t336 = load i64, ptr %l23, !tbaa !24
  %t339 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t335, i64 %t336)
  store i32 %t339, ptr %l184
  br label %bb63
bb63:
  %t340 = load i32, ptr %l184, !tbaa !23
  %t341 = load ptr, ptr %l5, !tbaa !29
  %t343 = getelementptr %"compiler/check:frame", ptr %t341, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t343, i32 %t340)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t347 = load i64, ptr %l23, !tbaa !24
  %t350 = add i64 %t347, 1
  store i64 %t350, ptr %l23, !tbaa !24
  br label %bb58
bb66:
  %t352 = load ptr, ptr %l8, !tbaa !29
  %t354 = icmp eq ptr %t352, null
  br i1 %t354, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3)
  unreachable
bb68:
  br label %bb69
bb69:
  %t356 = load ptr, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t356, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberOwnerArgs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l40 = alloca i64
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/diagmsg:Msg"
  %l50 = alloca i64
  %l53 = alloca i64
  %l57 = alloca i64
  %l66 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l82 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca %"compiler/names:Ref"
  %l103 = alloca ptr
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l112 = alloca %"compiler/diagmsg:Msg"
  %l113 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l19
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l19, !tbaa !29
  %t10 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t9)
  store %"compiler/source:Span" %t10, ptr %l20
  br label %bb2
bb2:
  %t11 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t11, ptr %l4
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %s0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l24
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l24, !tbaa !29
  store ptr %t20, ptr %l5, !tbaa !29
  %t21 = load ptr, ptr %l5, !tbaa !29
  store ptr %t21, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t22 = load ptr, ptr %l26, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l26, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 8}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l27, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t32, i32 0, i32 2
  %t34 = load { i64, ptr }, ptr %t33
  store { i64, ptr } %t34, ptr %l6, !tbaa !27
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t36, ptr %l25, !tbaa !27
  br label %bb18
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t38 = icmp sge i64 0, 0
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t40 = icmp sle i64 0, 1152921504606846975
  br i1 %t40, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_ef037029164a29a_21fd292be875b5ee)
  unreachable
bb15:
  %t42 = mul i64 0, 8
  %t43 = insertvalue { i64, ptr } undef, i64 0, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t44, ptr %l25, !tbaa !27
  br label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_ef037029164a29a_21fd292be875b5ee)
  unreachable
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bb01d10f777a4448_96828c8732d8ad84)
  unreachable
bb18:
  %t46 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t46, ptr %l7, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l40
  br label %bb19
bb19:
  %t57 = load i64, ptr %l40, !tbaa !24
  %t58 = icmp eq i64 %t57, 0
  br i1 %t58, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i64, ptr %l1, !tbaa !24
  %t68 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberInPlace(ptr %v0, ptr %t64, i64 %t65)
  store i1 %t68, ptr %l46
  br label %bb23
bb23:
  %t69 = load i1, ptr %l46, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l47, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t71, ptr %l48
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberInPlaceKind(ptr %s4, ptr %v0, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t72, ptr %l49
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t73 = load ptr, ptr %l47, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l48
  %t75 = load %"compiler/diagmsg:Msg", ptr %l49
  %t76 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t73, %"compiler/source:Span" %t74, %"compiler/diagmsg:Msg" %t75)
  store i64 %t76, ptr %l50
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb28:
  %t78 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l53, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load i32, ptr %l2, !tbaa !23
  %t88 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l57
  br label %bb29
bb29:
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = load i64, ptr %l57, !tbaa !24
  %t91 = icmp eq i64 %t89, %t90
  store i1 %t91, ptr %l8, !tbaa !21
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  %t99 = load i64, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l11, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb31, label %bb32
bb31:
  br label %bb56
bb32:
  br label %bb33
bb33:
  %t107 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t107, ptr %l66, !tbaa !27
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr ptr, ptr %t111, i64 %t108
  %t113 = load ptr, ptr %t112, !tbaa !39
  store ptr %t113, ptr %l12, !tbaa !29
  %t115 = load ptr, ptr %l12, !tbaa !29
  store ptr %t115, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t116 = load ptr, ptr %l69, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb34, label %bb35
bb34:
  %t119 = load ptr, ptr %l69, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 8}
  %t122 = icmp eq i64 %t120, 0
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb35
bb35:
  %t123 = load i1, ptr %l70, !tbaa !21
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t124 = load ptr, ptr %l12, !tbaa !29
  %t126 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t126, i32 0, i32 0
  %t128 = load %"compiler/source:Span", ptr %t127
  store %"compiler/source:Span" %t128, ptr %l13
  %t130 = load ptr, ptr %l12, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t132, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133
  store { i64, ptr } %t134, ptr %l14, !tbaa !27
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t138 = getelementptr { i64, [5 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  store { i64, ptr } %t140, ptr %l15, !tbaa !27
  br label %bb38
bb37:
  br label %bb49
bb38:
  %t142 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t146 = icmp eq i64 %t144, 1
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t148 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t152 = icmp eq i64 %t150, 0
  store i1 %t152, ptr %l82, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb41
bb41:
  %t154 = load i1, ptr %l82, !tbaa !21
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l88, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t162)
  store ptr %t164, ptr %l90
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t165 = load ptr, ptr %l90, !tbaa !29
  %t167 = getelementptr %"compiler/check:frame", ptr %t165, i32 0, i32 2
  %t168 = load i64, ptr %t167, !tbaa !24
  %t169 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t170 = load i32, ptr %t169, !tbaa !23
  %t171 = load ptr, ptr %l88, !tbaa !29
  %t174 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t171, i64 %t168, i32 %t170)
  store %"compiler/names:Ref" %t174, ptr %l94
  br label %bb45
bb45:
  %t175 = getelementptr %"compiler/names:Ref", ptr %l94, i32 0, i32 0
  %t176 = load i32, ptr %t175, !range !{i32 0, i32 9}
  %t178 = trunc i64 8 to i32
  %t179 = icmp eq i32 %t176, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb46, label %bb47
bb46:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_ad750d80deeaf923_2ed747fea17822bf)
  unreachable
bb54:
  br label %bb55
bb55:
  %t183 = load i64, ptr %l10, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l10, !tbaa !24
  br label %bb30
bb56:
  %t188 = load i1, ptr %l8, !tbaa !21
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb57, label %bb58
bb57:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l103, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t193, ptr %l104
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l105, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l2, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l110
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t205 = load ptr, ptr %l105, !tbaa !29
  %t206 = load i32, ptr %l110, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t205, i32 %t206)
  store { i64, ptr } %t207, ptr %l111
  br label %bb60
bb60:
  %t208 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t209 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberOwnerArgs(ptr %v0, ptr %v0, { i64, ptr } %t208)
  store %"compiler/diagmsg:Msg" %t209, ptr %l112
  br label %bb61
bb61:
  %t210 = load ptr, ptr %l103, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l104
  %t212 = load %"compiler/diagmsg:Msg", ptr %l112
  %t213 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t210, %"compiler/source:Span" %t211, %"compiler/diagmsg:Msg" %t212)
  store i64 %t213, ptr %l113
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t214 = load i1, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t214, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i1
  %l35 = alloca i32
  %l38 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l56 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l63 = alloca i64
  %l65 = alloca i1
  %l67 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i1
  %l86 = alloca i64
  %l88 = alloca i1
  %l89 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i1
  %l94 = alloca i1
  %l95 = alloca ptr
  %l98 = alloca i32
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l111 = alloca ptr
  %l114 = alloca ptr
  %l117 = alloca ptr
  %l120 = alloca i32
  %l123 = alloca i32
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l133 = alloca ptr
  %l135 = alloca i1
  %l136 = alloca i1
  %l140 = alloca i1
  %l144 = alloca i1
  %l147 = alloca i1
  %l148 = alloca i1
  %l151 = alloca i1
  %l154 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l168 = alloca %"compiler/diagmsg:Msg"
  %l169 = alloca i64
  %l173 = alloca ptr
  %l177 = alloca i1
  %l183 = alloca i1
  %l186 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca i32
  %l193 = alloca i32
  %l194 = alloca ptr
  %l196 = alloca ptr
  %l199 = alloca ptr
  %l200 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l203 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l206 = alloca %"compiler/diagmsg:Msg"
  %l207 = alloca i64
  %l210 = alloca ptr
  %l213 = alloca ptr
  %l214 = alloca %"compiler/source:Span"
  %l217 = alloca { i64, ptr }
  %l219 = alloca %"compiler/diagmsg:Msg"
  %l220 = alloca i64
  %l223 = alloca ptr
  %l227 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca ptr
  %l239 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca ptr
  %l252 = alloca ptr
  %l259 = alloca ptr
  %l262 = alloca i32
  %l264 = alloca i1
  %l266 = alloca ptr
  %l267 = alloca %"compiler/source:Span"
  %l270 = alloca { i64, ptr }
  %l272 = alloca %"compiler/diagmsg:Msg"
  %l273 = alloca i64
  %l276 = alloca ptr
  %l279 = alloca i1
  %l282 = alloca i1
  %l285 = alloca i1
  %l286 = alloca i1
  %l292 = alloca i1
  %l293 = alloca i1
  %l296 = alloca i64
  %l300 = alloca i1
  %l302 = alloca i1
  %l305 = alloca i1
  %l307 = alloca i1
  %l311 = alloca i1
  %l321 = alloca ptr
  %l322 = alloca ptr
  %l325 = alloca ptr
  %l330 = alloca { i64, ptr }
  %l331 = alloca i1
  %l333 = alloca i1
  %l334 = alloca ptr
  %l337 = alloca i32
  %l339 = alloca { i64, ptr }
  %l340 = alloca %"compiler/source:Span"
  %l342 = alloca { i64, ptr }
  %l343 = alloca { i64, ptr }
  %l345 = alloca i1
  %l348 = alloca ptr
  %l351 = alloca i1
  %l352 = alloca i1
  %l355 = alloca i1
  %l356 = alloca ptr
  %l357 = alloca %"compiler/source:Span"
  %l359 = alloca { i64, ptr }
  %l360 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l364 = alloca { i64, ptr }
  %l365 = alloca { i64, ptr }
  %l368 = alloca { i64, ptr }
  %l370 = alloca %"compiler/diagmsg:Msg"
  %l371 = alloca i64
  %l372 = alloca ptr
  %l373 = alloca %"compiler/source:Span"
  %l374 = alloca i32
  %l376 = alloca { i64, ptr }
  %l377 = alloca { i64, ptr }
  %l379 = alloca { i64, ptr }
  %l380 = alloca { i64, ptr }
  %l381 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l386 = alloca %"compiler/diagmsg:Msg"
  %l387 = alloca i64
  %l390 = alloca ptr
  %l393 = alloca i1
  %l398 = alloca i1
  %l400 = alloca ptr
  %l401 = alloca %"compiler/source:Span"
  %l403 = alloca { i64, ptr }
  %l404 = alloca { i64, ptr }
  %l405 = alloca { i64, ptr }
  %l408 = alloca { i64, ptr }
  %l410 = alloca %"compiler/diagmsg:Msg"
  %l411 = alloca i64
  %l414 = alloca i1
  %l416 = alloca ptr
  %l417 = alloca %"compiler/source:Span"
  %l419 = alloca { i64, ptr }
  %l420 = alloca { i64, ptr }
  %l421 = alloca { i64, ptr }
  %l424 = alloca { i64, ptr }
  %l426 = alloca %"compiler/diagmsg:Msg"
  %l427 = alloca i64
  %l429 = alloca i1
  %l431 = alloca i1
  %l434 = alloca i1
  %l435 = alloca i1
  %l439 = alloca i1
  %l441 = alloca ptr
  %l442 = alloca %"compiler/source:Span"
  %l445 = alloca { i64, ptr }
  %l446 = alloca { i64, ptr }
  %l448 = alloca { i64, ptr }
  %l449 = alloca { i64, ptr }
  %l450 = alloca { i64, ptr }
  %l452 = alloca { i64, ptr }
  %l455 = alloca %"compiler/diagmsg:Msg"
  %l456 = alloca i64
  %l459 = alloca ptr
  %l462 = alloca ptr
  %l465 = alloca i1
  %l469 = alloca ptr
  %l470 = alloca ptr
  %l471 = alloca %"compiler/source:Span"
  %l472 = alloca i32
  %l474 = alloca i32
  %l475 = alloca ptr
  %l476 = alloca ptr
  %l479 = alloca ptr
  %l488 = alloca i32
  %l491 = alloca ptr
  %l492 = alloca %"compiler/source:Span"
  %l495 = alloca { i64, ptr }
  %l496 = alloca { i64, ptr }
  %l499 = alloca { i64, ptr }
  %l501 = alloca %"compiler/diagmsg:Msg"
  %l502 = alloca i64
  %l505 = alloca ptr
  %l511 = alloca ptr
  %l514 = alloca ptr
  %l520 = alloca ptr
  %l523 = alloca ptr
  %l525 = alloca i1
  %l526 = alloca i1
  %l529 = alloca i1
  %l531 = alloca ptr
  %l532 = alloca %"compiler/source:Span"
  %l534 = alloca { i64, ptr }
  %l535 = alloca { i64, ptr }
  %l536 = alloca { i64, ptr }
  %l539 = alloca { i64, ptr }
  %l541 = alloca %"compiler/diagmsg:Msg"
  %l542 = alloca i64
  %l545 = alloca ptr
  %l547 = alloca i1
  %l549 = alloca i1
  %l552 = alloca i1
  %l553 = alloca i1
  %l557 = alloca i1
  %l559 = alloca ptr
  %l560 = alloca %"compiler/source:Span"
  %l563 = alloca { i64, ptr }
  %l564 = alloca { i64, ptr }
  %l566 = alloca { i64, ptr }
  %l567 = alloca { i64, ptr }
  %l568 = alloca { i64, ptr }
  %l570 = alloca { i64, ptr }
  %l573 = alloca %"compiler/diagmsg:Msg"
  %l574 = alloca i64
  %l577 = alloca ptr
  %l579 = alloca i1
  %l580 = alloca ptr
  %l581 = alloca %"compiler/source:Span"
  %l582 = alloca i32
  %l584 = alloca i32
  %l585 = alloca ptr
  %l587 = alloca ptr
  %l590 = alloca ptr
  %l591 = alloca ptr
  %l592 = alloca %"compiler/source:Span"
  %l593 = alloca i32
  %l595 = alloca i32
  %l596 = alloca ptr
  %l597 = alloca ptr
  %l600 = alloca ptr
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  store %"compiler/source:Span" %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l20
  br label %bb1
bb1:
  %t5 = load i32, ptr %l20, !tbaa !23
  store i32 %t5, ptr %l8, !tbaa !23
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t6)
  store i32 %t9, ptr %l23
  br label %bb2
bb2:
  %t10 = load i32, ptr %l23, !tbaa !23
  store i32 %t10, ptr %l9, !tbaa !23
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i32, ptr %l9, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = icmp eq i32 %t17, %t18
  store i1 %t21, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l27, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l31, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l32
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t28 = call i1 @compiler_2fcheck_2ecompares(i32 %t26)
  store i1 %t28, ptr %l34
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t29 = load i1, ptr %l34, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t30, ptr %l35, !tbaa !23
  br label %bb11
bb10:
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t32, ptr %l35, !tbaa !23
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l31, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l32
  %t36 = load i32, ptr %l35, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t34, %"compiler/source:Span" %t35, i32 %t36, i64 0)
  store ptr %t37, ptr %l38
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l38, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l8, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l43
  br label %bb14
bb14:
  %t49 = load i1, ptr %l43, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l9, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l49
  br label %bb17
bb17:
  %t60 = load i1, ptr %l49, !tbaa !21
  store i1 %t60, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t61 = load i1, ptr %l44, !tbaa !21
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  %t64 = load %"compiler/source:Span", ptr %l2
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t62, %"compiler/source:Span" %t63, %"compiler/source:Span" %t64, i32 %t65, ptr %t66, ptr %t67)
  store ptr %t74, ptr %l56
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t75 = load ptr, ptr %l56, !tbaa !29
  store ptr %t75, ptr %rv
  br label %ret
bb22:
  %t76 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t78 = call i1 @compiler_2fcheck_2elaneTok(i32 %t76)
  store i1 %t78, ptr %l58
  br label %bb23
bb23:
  %t79 = load i1, ptr %l58, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l4, !tbaa !29
  store ptr %t81, ptr %l61, !tbaa !29
  %t82 = load ptr, ptr %l61, !tbaa !29
  %t83 = call ptr @__olang_scope_of(ptr %t82, ptr null)
  %t84 = call ptr @__olang_scope_hold(ptr %t83)
  %t85 = ptrtoint ptr %t84 to i64
  %t87 = inttoptr i64 %t85 to ptr
  %t89 = load ptr, ptr %l61, !tbaa !29
  %t90 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %t87, ptr %t80, ptr %t89)
  store i64 %t90, ptr %l63
  br label %bb26
bb25:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb39
bb26:
  %t91 = load i64, ptr %l63, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  br i1 %t92, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb30
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l5, !tbaa !29
  store ptr %t95, ptr %l67, !tbaa !29
  %t96 = load ptr, ptr %l67, !tbaa !29
  %t97 = call ptr @__olang_scope_of(ptr %t96, ptr null)
  %t98 = call ptr @__olang_scope_hold(ptr %t97)
  %t99 = ptrtoint ptr %t98 to i64
  %t101 = inttoptr i64 %t99 to ptr
  %t103 = load ptr, ptr %l67, !tbaa !29
  %t104 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %t101, ptr %t94, ptr %t103)
  store i64 %t104, ptr %l69
  br label %bb29
bb29:
  %t105 = load i64, ptr %l69, !tbaa !24
  %t106 = icmp sge i64 %t105, 0
  store i1 %t106, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t108 = load i1, ptr %l65, !tbaa !21
  br i1 %t108, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb34
bb32:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l8, !tbaa !23
  %t113 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t109, i32 %t110)
  store i1 %t113, ptr %l74
  br label %bb33
bb33:
  %t114 = load i1, ptr %l74, !tbaa !21
  store i1 %t114, ptr %l71, !tbaa !21
  br label %bb34
bb34:
  %t115 = load i1, ptr %l71, !tbaa !21
  br i1 %t115, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb38
bb36:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l9, !tbaa !23
  %t120 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t116, i32 %t117)
  store i1 %t120, ptr %l78
  br label %bb37
bb37:
  %t121 = load i1, ptr %l78, !tbaa !21
  store i1 %t121, ptr %l75, !tbaa !21
  br label %bb38
bb38:
  %t122 = load i1, ptr %l75, !tbaa !21
  store i1 %t122, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t123 = load i1, ptr %l59, !tbaa !21
  br i1 %t123, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s3
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l8, !tbaa !23
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l81
  br label %bb42
bb41:
  br label %bb66
bb42:
  %t129 = load i1, ptr %l81, !tbaa !21
  %t130 = xor i1 %t129, true
  br i1 %t130, label %bb43, label %bb44
bb43:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l4, !tbaa !29
  %t136 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  store i64 %t136, ptr %l86
  br label %bb45
bb44:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb46
bb45:
  %t137 = load i64, ptr %l86, !tbaa !24
  %t138 = icmp slt i64 %t137, 0
  store i1 %t138, ptr %l83, !tbaa !21
  br label %bb46
bb46:
  %t140 = load i1, ptr %l83, !tbaa !21
  br i1 %t140, label %bb47, label %bb48
bb47:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l89, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l8, !tbaa !23
  %t146 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l92
  br label %bb49
bb48:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb51
bb49:
  %t147 = load ptr, ptr %l89, !tbaa !29
  %t148 = load i32, ptr %l92, !tbaa !23
  %t149 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t147, i32 %t148)
  store i1 %t149, ptr %l93
  br label %bb50
bb50:
  %t150 = load i1, ptr %l93, !tbaa !21
  store i1 %t150, ptr %l88, !tbaa !21
  br label %bb51
bb51:
  %t151 = load i1, ptr %l88, !tbaa !21
  br i1 %t151, label %bb52, label %bb53
bb52:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l95, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l8, !tbaa !23
  %t157 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t153, i32 %t154)
  store i32 %t157, ptr %l98
  br label %bb54
bb53:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb57
bb54:
  %t158 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t160 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s3, i32 %t158)
  store { i64, ptr } %t160, ptr %l100
  br label %bb55
bb55:
  %t161 = load ptr, ptr %l95, !tbaa !29
  %t162 = load i32, ptr %l98, !tbaa !23
  %t163 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t164 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s3, ptr %t161, i32 %t162, { i64, ptr } %t163, i64 1)
  store i64 %t164, ptr %l101
  br label %bb56
bb56:
  %t165 = load i64, ptr %l101, !tbaa !24
  %t166 = icmp sge i64 %t165, 0
  store i1 %t166, ptr %l94, !tbaa !21
  br label %bb57
bb57:
  %t168 = load i1, ptr %l94, !tbaa !21
  %t171 = xor i1 %t168, true
  br i1 %t171, label %bb58, label %bb59
bb58:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  %t175 = load %"compiler/source:Span", ptr %l2
  %t176 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t177 = load ptr, ptr %l4, !tbaa !29
  %t178 = load ptr, ptr %l5, !tbaa !29
  %t185 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t173, %"compiler/source:Span" %t174, %"compiler/source:Span" %t175, i32 %t176, ptr %t177, ptr %t178)
  store ptr %t185, ptr %l111
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s3)
  %t186 = load ptr, ptr %l111, !tbaa !29
  store ptr %t186, ptr %rv
  br label %ret
bb61:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v1, ptr %v0, ptr %t187, ptr %t188)
  store ptr %t191, ptr %l114
  br label %bb62
bb62:
  %t192 = load ptr, ptr %l114, !tbaa !29
  store ptr %t192, ptr %l4, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l5, !tbaa !29
  %t197 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v2, ptr %v0, ptr %t193, ptr %t194)
  store ptr %t197, ptr %l117
  br label %bb63
bb63:
  %t198 = load ptr, ptr %l117, !tbaa !29
  store ptr %t198, ptr %l5, !tbaa !29
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t202 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t199)
  store i32 %t202, ptr %l120
  br label %bb64
bb64:
  %t203 = load i32, ptr %l120, !tbaa !23
  store i32 %t203, ptr %l8, !tbaa !23
  %t204 = load ptr, ptr %l5, !tbaa !29
  %t207 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t204)
  store i32 %t207, ptr %l123
  br label %bb65
bb65:
  %t208 = load i32, ptr %l123, !tbaa !23
  store i32 %t208, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  br label %bb66
bb66:
  %t209 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t211 = trunc i64 71 to i32
  %t212 = icmp eq i32 %t209, %t211
  br i1 %t212, label %bb67, label %bb68
bb67:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  %t216 = load %"compiler/source:Span", ptr %l2
  %t217 = load ptr, ptr %l4, !tbaa !29
  store ptr %t217, ptr %l129, !tbaa !29
  %t218 = load ptr, ptr %l5, !tbaa !29
  store ptr %t218, ptr %l130, !tbaa !29
  %t219 = load ptr, ptr %l129, !tbaa !29
  %t220 = call ptr @__olang_scope_of(ptr %t219, ptr null)
  %t221 = call ptr @__olang_scope_hold(ptr %t220)
  %t222 = ptrtoint ptr %t221 to i64
  %t223 = load ptr, ptr %l130, !tbaa !29
  %t224 = call ptr @__olang_scope_of(ptr %t223, ptr null)
  %t225 = call ptr @__olang_scope_hold(ptr %t224)
  %t226 = ptrtoint ptr %t225 to i64
  %t228 = inttoptr i64 %t222 to ptr
  %t230 = inttoptr i64 %t226 to ptr
  %t234 = load ptr, ptr %l129, !tbaa !29
  %t235 = load ptr, ptr %l130, !tbaa !29
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %t228, ptr %t230, ptr %v3, ptr %t214, %"compiler/source:Span" %t215, %"compiler/source:Span" %t216, ptr %t234, ptr %t235)
  store ptr %t236, ptr %l133
  br label %bb69
bb68:
  br label %bb70
bb69:
  %t237 = load ptr, ptr %l133, !tbaa !29
  store ptr %t237, ptr %rv
  br label %ret
bb70:
  %t238 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t240 = call i1 @compiler_2fcheck_2ecompares(i32 %t238)
  store i1 %t240, ptr %l135
  br label %bb71
bb71:
  %t241 = load i1, ptr %l135, !tbaa !21
  br i1 %t241, label %bb72, label %bb73
bb72:
  %t242 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t244 = trunc i64 95 to i32
  %t245 = icmp eq i32 %t242, %t244
  %t247 = xor i1 %t245, true
  store i1 %t247, ptr %l136, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb74
bb74:
  %t249 = load i1, ptr %l136, !tbaa !21
  br i1 %t249, label %bb75, label %bb76
bb75:
  %t250 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t252 = trunc i64 96 to i32
  %t253 = icmp eq i32 %t250, %t252
  %t255 = xor i1 %t253, true
  store i1 %t255, ptr %l140, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb77
bb77:
  %t257 = load i1, ptr %l140, !tbaa !21
  br i1 %t257, label %bb78, label %bb79
bb78:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l8, !tbaa !23
  %t262 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t258, i32 %t259)
  store i1 %t262, ptr %l147
  br label %bb80
bb79:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb85
bb80:
  %t263 = load i1, ptr %l147, !tbaa !21
  br i1 %t263, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb84
bb82:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l9, !tbaa !23
  %t268 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t268, ptr %l151
  br label %bb83
bb83:
  %t269 = load i1, ptr %l151, !tbaa !21
  store i1 %t269, ptr %l148, !tbaa !21
  br label %bb84
bb84:
  %t270 = load i1, ptr %l148, !tbaa !21
  store i1 %t270, ptr %l144, !tbaa !21
  br label %bb85
bb85:
  %t271 = load i1, ptr %l144, !tbaa !21
  br i1 %t271, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s6
  %t272 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t274 = trunc i64 98 to i32
  %t275 = icmp eq i32 %t272, %t274
  br i1 %t275, label %bb88, label %bb89
bb87:
  br label %bb102
bb88:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l154, !tbaa !27
  br label %bb96
bb89:
  %t277 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t279 = trunc i64 100 to i32
  %t280 = icmp eq i32 %t277, %t279
  br i1 %t280, label %bb90, label %bb91
bb90:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l157, !tbaa !27
  br label %bb95
bb91:
  %t282 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t284 = trunc i64 99 to i32
  %t285 = icmp eq i32 %t282, %t284
  br i1 %t285, label %bb92, label %bb93
bb92:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l160, !tbaa !27
  br label %bb94
bb93:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l160, !tbaa !27
  br label %bb94
bb94:
  %t287 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t287, ptr %l157, !tbaa !27
  br label %bb95
bb95:
  %t288 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t288, ptr %l154, !tbaa !27
  br label %bb96
bb96:
  %t289 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t289, ptr %l11, !tbaa !27
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l161, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t291, ptr %l162
  %t292 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t294 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s6, i32 %t292)
  store { i64, ptr } %t294, ptr %l164
  br label %bb97
bb97:
  %t295 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t296 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s6, ptr %s6, { i64, ptr } %t295)
  store { i64, ptr } %t296, ptr %l165
  br label %bb98
bb98:
  %t297 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t299 = load ptr, ptr @__olang_prog_scope
  %t302 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneCompare(ptr %s6, ptr %t299, ptr %v0, { i64, ptr } %t297, { i64, ptr } %t298)
  store %"compiler/diagmsg:Msg" %t302, ptr %l168
  br label %bb99
bb99:
  %t303 = load ptr, ptr %l161, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l162
  %t305 = load %"compiler/diagmsg:Msg", ptr %l168
  %t306 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t303, %"compiler/source:Span" %t304, %"compiler/diagmsg:Msg" %t305)
  store i64 %t306, ptr %l169
  br label %bb100
bb100:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l1
  %t309 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t313 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t307, %"compiler/source:Span" %t308, i32 %t309, i64 0)
  store ptr %t313, ptr %l173
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s6)
  %t314 = load ptr, ptr %l173, !tbaa !29
  store ptr %t314, ptr %rv
  br label %ret
bb102:
  %t315 = load i32, ptr %l8, !tbaa !23
  %t316 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t319 = icmp eq i32 %t315, %t316
  br i1 %t319, label %bb103, label %bb104
bb103:
  %t321 = load i32, ptr %l9, !tbaa !23
  %t322 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t325 = icmp eq i32 %t321, %t322
  store i1 %t325, ptr %l177, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb105
bb105:
  %t327 = load i1, ptr %l177, !tbaa !21
  br i1 %t327, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s7
  %t328 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t330 = trunc i64 95 to i32
  %t331 = icmp eq i32 %t328, %t330
  br i1 %t331, label %bb108, label %bb109
bb107:
  br label %bb124
bb108:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb110
bb109:
  %t333 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t335 = trunc i64 96 to i32
  %t336 = icmp eq i32 %t333, %t335
  store i1 %t336, ptr %l183, !tbaa !21
  br label %bb110
bb110:
  %t338 = load i1, ptr %l183, !tbaa !21
  br i1 %t338, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb113
bb112:
  %t339 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t341 = trunc i64 47 to i32
  %t342 = icmp eq i32 %t339, %t341
  store i1 %t342, ptr %l186, !tbaa !21
  br label %bb113
bb113:
  %t344 = load i1, ptr %l186, !tbaa !21
  br i1 %t344, label %bb114, label %bb115
bb114:
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l189, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t346, ptr %l190
  %t347 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t347, ptr %l191, !tbaa !23
  %t348 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t350 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t348)
  store i32 %t350, ptr %l193
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t351 = load ptr, ptr %l4, !tbaa !29
  store ptr %t351, ptr %l194, !tbaa !29
  %t352 = load ptr, ptr %l5, !tbaa !29
  store ptr %t352, ptr %l196, !tbaa !29
  %t354 = load ptr, ptr %l194, !tbaa !29
  %t355 = call ptr @__olang_scope_of(ptr %t354, ptr null)
  %t356 = call ptr @__olang_scope_hold(ptr %t355)
  %t357 = ptrtoint ptr %t356 to i64
  %t358 = load ptr, ptr %l196, !tbaa !29
  %t359 = call ptr @__olang_scope_of(ptr %t358, ptr null)
  %t360 = call ptr @__olang_scope_hold(ptr %t359)
  %t361 = ptrtoint ptr %t360 to i64
  %t363 = inttoptr i64 %t357 to ptr
  %t365 = inttoptr i64 %t361 to ptr
  %t366 = load ptr, ptr %l189, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l190
  %t368 = load i32, ptr %l191, !tbaa !23
  %t369 = load i32, ptr %l193, !range !{i32 0, i32 54}
  %t370 = load ptr, ptr %l194, !tbaa !29
  %t371 = load ptr, ptr %l196, !tbaa !29
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t363, ptr %t365, ptr %v3, ptr %t366, %"compiler/source:Span" %t367, i32 %t368, i32 %t369, ptr %t370, ptr %t371)
  store ptr %t372, ptr %l199
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s7)
  %t373 = load ptr, ptr %l199, !tbaa !29
  store ptr %t373, ptr %rv
  br label %ret
bb118:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l200, !tbaa !29
  %t375 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t375, ptr %l201
  %t376 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t378 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s7, i32 %t376)
  store { i64, ptr } %t378, ptr %l203
  br label %bb119
bb119:
  %t379 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t380 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s7, ptr %s7, { i64, ptr } %t379)
  store { i64, ptr } %t380, ptr %l204
  br label %bb120
bb120:
  %t381 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t383 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s7, ptr %s7, ptr %v0, { i64, ptr } %t381, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t383, ptr %l206
  br label %bb121
bb121:
  %t384 = load ptr, ptr %l200, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l201
  %t386 = load %"compiler/diagmsg:Msg", ptr %l206
  %t387 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t384, %"compiler/source:Span" %t385, %"compiler/diagmsg:Msg" %t386)
  store i64 %t387, ptr %l207
  br label %bb122
bb122:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load %"compiler/source:Span", ptr %l1
  %t392 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t388, %"compiler/source:Span" %t389)
  store ptr %t392, ptr %l210
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s7)
  %t393 = load ptr, ptr %l210, !tbaa !29
  store ptr %t393, ptr %rv
  br label %ret
bb124:
  %t394 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t396 = trunc i64 47 to i32
  %t397 = icmp eq i32 %t394, %t396
  br i1 %t397, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s9
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l213, !tbaa !29
  %t400 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t400, ptr %l214
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i32, ptr %l8, !tbaa !23
  %t405 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t401, i32 %t402)
  store { i64, ptr } %t405, ptr %l217
  br label %bb127
bb126:
  br label %bb131
bb127:
  %t406 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t408 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %s9, ptr %s9, ptr %v0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) }, { i64, ptr } %t406)
  store %"compiler/diagmsg:Msg" %t408, ptr %l219
  br label %bb128
bb128:
  %t409 = load ptr, ptr %l213, !tbaa !29
  %t410 = load %"compiler/source:Span", ptr %l214
  %t411 = load %"compiler/diagmsg:Msg", ptr %l219
  %t412 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t409, %"compiler/source:Span" %t410, %"compiler/diagmsg:Msg" %t411)
  store i64 %t412, ptr %l220
  br label %bb129
bb129:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load %"compiler/source:Span", ptr %l1
  %t417 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t413, %"compiler/source:Span" %t414)
  store ptr %t417, ptr %l223
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s9)
  %t418 = load ptr, ptr %l223, !tbaa !29
  store ptr %t418, ptr %rv
  br label %ret
bb131:
  %t419 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t421 = trunc i64 95 to i32
  %t422 = icmp eq i32 %t419, %t421
  %t424 = xor i1 %t422, true
  br i1 %t424, label %bb132, label %bb133
bb132:
  %t426 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t428 = trunc i64 96 to i32
  %t429 = icmp eq i32 %t426, %t428
  %t431 = xor i1 %t429, true
  store i1 %t431, ptr %l227, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb134
bb134:
  %t433 = load i1, ptr %l227, !tbaa !21
  br i1 %t433, label %bb135, label %bb136
bb135:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load %"compiler/source:Span", ptr %l1
  %t436 = load %"compiler/source:Span", ptr %l2
  %t437 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t438 = load ptr, ptr %l4, !tbaa !29
  store ptr %t438, ptr %l235, !tbaa !29
  %t439 = load ptr, ptr %l5, !tbaa !29
  store ptr %t439, ptr %l236, !tbaa !29
  %t440 = load ptr, ptr %l235, !tbaa !29
  %t441 = call ptr @__olang_scope_of(ptr %t440, ptr null)
  %t442 = call ptr @__olang_scope_hold(ptr %t441)
  %t443 = ptrtoint ptr %t442 to i64
  %t444 = load ptr, ptr %l236, !tbaa !29
  %t445 = call ptr @__olang_scope_of(ptr %t444, ptr null)
  %t446 = call ptr @__olang_scope_hold(ptr %t445)
  %t447 = ptrtoint ptr %t446 to i64
  %t449 = inttoptr i64 %t443 to ptr
  %t451 = inttoptr i64 %t447 to ptr
  %t456 = load ptr, ptr %l235, !tbaa !29
  %t457 = load ptr, ptr %l236, !tbaa !29
  %t458 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %t449, ptr %t451, ptr %v3, ptr %t434, %"compiler/source:Span" %t435, %"compiler/source:Span" %t436, i32 %t437, ptr %t456, ptr %t457)
  store ptr %t458, ptr %l239
  br label %bb137
bb136:
  br label %bb145
bb137:
  %t459 = load ptr, ptr %l239, !tbaa !29
  store ptr %t459, ptr %l12, !tbaa !29
  %t460 = load ptr, ptr %l12, !tbaa !29
  %t462 = icmp eq ptr %t460, null
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb138, label %bb139
bb138:
  %t466 = load ptr, ptr %l12, !tbaa !29
  store ptr %t466, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l1
  %t470 = load %"compiler/source:Span", ptr %l2
  %t471 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t472 = load ptr, ptr %l4, !tbaa !29
  store ptr %t472, ptr %l248, !tbaa !29
  %t473 = load ptr, ptr %l5, !tbaa !29
  store ptr %t473, ptr %l249, !tbaa !29
  %t474 = load ptr, ptr %l248, !tbaa !29
  %t475 = call ptr @__olang_scope_of(ptr %t474, ptr null)
  %t476 = call ptr @__olang_scope_hold(ptr %t475)
  %t477 = ptrtoint ptr %t476 to i64
  %t478 = load ptr, ptr %l249, !tbaa !29
  %t479 = call ptr @__olang_scope_of(ptr %t478, ptr null)
  %t480 = call ptr @__olang_scope_hold(ptr %t479)
  %t481 = ptrtoint ptr %t480 to i64
  %t483 = inttoptr i64 %t477 to ptr
  %t485 = inttoptr i64 %t481 to ptr
  %t490 = load ptr, ptr %l248, !tbaa !29
  %t491 = load ptr, ptr %l249, !tbaa !29
  %t492 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutedCall(ptr %v0, ptr %t483, ptr %t485, ptr %v3, ptr %t468, %"compiler/source:Span" %t469, %"compiler/source:Span" %t470, i32 %t471, ptr %t490, ptr %t491)
  store ptr %t492, ptr %l252
  br label %bb141
bb141:
  %t493 = load ptr, ptr %l252, !tbaa !29
  store ptr %t493, ptr %l13, !tbaa !29
  %t494 = load ptr, ptr %l13, !tbaa !29
  %t496 = icmp eq ptr %t494, null
  %t498 = xor i1 %t496, true
  br i1 %t498, label %bb142, label %bb143
bb142:
  %t500 = load ptr, ptr %l13, !tbaa !29
  store ptr %t500, ptr %rv
  br label %ret
bb143:
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t502 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t504 = trunc i64 74 to i32
  %t505 = icmp eq i32 %t502, %t504
  br i1 %t505, label %bb146, label %bb147
bb146:
  store %olang.scope zeroinitializer, ptr %s13
  %t507 = load ptr, ptr %l0, !tbaa !29
  store ptr %t507, ptr %l259, !tbaa !29
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load i32, ptr %l8, !tbaa !23
  %t512 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t508, i32 %t509)
  store i32 %t512, ptr %l262
  br label %bb148
bb147:
  br label %bb157
bb148:
  %t513 = load %"compiler/source:Span", ptr %l2
  %t514 = load ptr, ptr %l259, !tbaa !29
  %t515 = load i32, ptr %l262, !tbaa !23
  %t517 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s13, ptr %s13, ptr %t514, i32 %t515, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, %"compiler/source:Span" %t513, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, i64 1, i1 false)
  store i1 %t517, ptr %l264
  br label %bb149
bb149:
  %t518 = load i1, ptr %l264, !tbaa !21
  %t519 = xor i1 %t518, true
  br i1 %t519, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s14
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l266, !tbaa !29
  %t522 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t522, ptr %l267
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t524 = load i32, ptr %l8, !tbaa !23
  %t527 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s14, ptr %t523, i32 %t524)
  store { i64, ptr } %t527, ptr %l270
  br label %bb152
bb151:
  br label %bb155
bb152:
  %t528 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t530 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %s14, ptr %v0, { i64, ptr } %t528)
  store %"compiler/diagmsg:Msg" %t530, ptr %l272
  br label %bb153
bb153:
  %t531 = load ptr, ptr %l266, !tbaa !29
  %t532 = load %"compiler/source:Span", ptr %l267
  %t533 = load %"compiler/diagmsg:Msg", ptr %l272
  %t534 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t531, %"compiler/source:Span" %t532, %"compiler/diagmsg:Msg" %t533)
  store i64 %t534, ptr %l273
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s14)
  br label %bb155
bb155:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load %"compiler/source:Span", ptr %l1
  %t539 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t535, %"compiler/source:Span" %t536)
  store ptr %t539, ptr %l276
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s13)
  %t540 = load ptr, ptr %l276, !tbaa !29
  store ptr %t540, ptr %rv
  br label %ret
bb157:
  %t541 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t543 = trunc i64 95 to i32
  %t544 = icmp eq i32 %t541, %t543
  br i1 %t544, label %bb158, label %bb159
bb158:
  store i1 true, ptr %l279, !tbaa !21
  br label %bb160
bb159:
  %t546 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t548 = trunc i64 96 to i32
  %t549 = icmp eq i32 %t546, %t548
  store i1 %t549, ptr %l279, !tbaa !21
  br label %bb160
bb160:
  %t551 = load i1, ptr %l279, !tbaa !21
  br i1 %t551, label %bb161, label %bb162
bb161:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load i32, ptr %l8, !tbaa !23
  %t556 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t552, i32 %t553)
  store i1 %t556, ptr %l285
  br label %bb163
bb162:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb164
bb163:
  %t557 = load i1, ptr %l285, !tbaa !21
  store i1 %t557, ptr %l282, !tbaa !21
  br label %bb164
bb164:
  %t558 = load i1, ptr %l282, !tbaa !21
  br i1 %t558, label %bb165, label %bb166
bb165:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !29
  %t564 = getelementptr %"compiler/generic:Program", ptr %t562, i32 0, i32 2
  %t565 = load i32, ptr %l8, !tbaa !23
  %t566 = load i32, ptr %l9, !tbaa !23
  %t570 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t564, i32 %t565, i32 %t566)
  store i1 %t570, ptr %l292
  br label %bb167
bb166:
  store i1 false, ptr %l286, !tbaa !21
  br label %bb168
bb167:
  %t571 = load i1, ptr %l292, !tbaa !21
  store i1 %t571, ptr %l286, !tbaa !21
  br label %bb168
bb168:
  %t572 = load i1, ptr %l286, !tbaa !21
  br i1 %t572, label %bb169, label %bb170
bb169:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load i32, ptr %l8, !tbaa !23
  %t577 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %t573, i32 %t574)
  store i64 %t577, ptr %l296
  br label %bb171
bb170:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb172
bb171:
  %t578 = load i64, ptr %l296, !tbaa !24
  %t579 = icmp ne i64 %t578, -1
  store i1 %t579, ptr %l293, !tbaa !21
  br label %bb172
bb172:
  %t581 = load i1, ptr %l293, !tbaa !21
  store i1 %t581, ptr %l14, !tbaa !21
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load i32, ptr %l8, !tbaa !23
  %t586 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t582, i32 %t583)
  store i1 %t586, ptr %l300
  br label %bb173
bb173:
  %t587 = load i1, ptr %l300, !tbaa !21
  %t588 = xor i1 %t587, true
  br i1 %t588, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l302, !tbaa !21
  br label %bb177
bb175:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load i32, ptr %l9, !tbaa !23
  %t594 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t590, i32 %t591)
  store i1 %t594, ptr %l305
  br label %bb176
bb176:
  %t595 = load i1, ptr %l305, !tbaa !21
  %t596 = xor i1 %t595, true
  store i1 %t596, ptr %l302, !tbaa !21
  br label %bb177
bb177:
  %t598 = load i1, ptr %l302, !tbaa !21
  br i1 %t598, label %bb178, label %bb179
bb178:
  store i1 true, ptr %l307, !tbaa !21
  br label %bb180
bb179:
  %t599 = load i1, ptr %l14, !tbaa !21
  store i1 %t599, ptr %l307, !tbaa !21
  br label %bb180
bb180:
  %t601 = load i1, ptr %l307, !tbaa !21
  br i1 %t601, label %bb181, label %bb182
bb181:
  store %olang.scope zeroinitializer, ptr %s15
  %t602 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t604 = trunc i64 95 to i32
  %t605 = icmp eq i32 %t602, %t604
  br i1 %t605, label %bb183, label %bb184
bb182:
  br label %bb225
bb183:
  store i1 true, ptr %l311, !tbaa !21
  br label %bb185
bb184:
  %t607 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t609 = trunc i64 96 to i32
  %t610 = icmp eq i32 %t607, %t609
  store i1 %t610, ptr %l311, !tbaa !21
  br label %bb185
bb185:
  %t612 = load i1, ptr %l311, !tbaa !21
  br i1 %t612, label %bb186, label %bb187
bb186:
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t615 = getelementptr %"compiler/check:Checker", ptr %t613, i32 0, i32 60
  %t616 = load %"compiler/source:Span", ptr %t615
  store %"compiler/source:Span" %t616, ptr %l15
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load %"compiler/source:Span", ptr %l2
  %t622 = getelementptr %"compiler/check:Checker", ptr %t618, i32 0, i32 60
  store %"compiler/source:Span" %t619, ptr %t622
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load %"compiler/source:Span", ptr %l1
  %t625 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t626 = load ptr, ptr %l4, !tbaa !29
  store ptr %t626, ptr %l321, !tbaa !29
  %t627 = load ptr, ptr %l5, !tbaa !29
  store ptr %t627, ptr %l322, !tbaa !29
  %t628 = load ptr, ptr %l321, !tbaa !29
  %t629 = call ptr @__olang_scope_of(ptr %t628, ptr null)
  %t630 = call ptr @__olang_scope_hold(ptr %t629)
  %t631 = ptrtoint ptr %t630 to i64
  %t632 = load ptr, ptr %l322, !tbaa !29
  %t633 = call ptr @__olang_scope_of(ptr %t632, ptr null)
  %t634 = call ptr @__olang_scope_hold(ptr %t633)
  %t635 = ptrtoint ptr %t634 to i64
  %t637 = inttoptr i64 %t631 to ptr
  %t639 = inttoptr i64 %t635 to ptr
  %t643 = load ptr, ptr %l321, !tbaa !29
  %t644 = load ptr, ptr %l322, !tbaa !29
  %t645 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t637, ptr %t639, ptr %v3, ptr %t623, %"compiler/source:Span" %t624, i32 %t625, ptr %t643, ptr %t644, i1 true)
  store ptr %t645, ptr %l325
  br label %bb188
bb187:
  br label %bb189
bb188:
  %t646 = load ptr, ptr %l325, !tbaa !29
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load %"compiler/source:Span", ptr %l15
  %t651 = getelementptr %"compiler/check:Checker", ptr %t647, i32 0, i32 60
  store %"compiler/source:Span" %t648, ptr %t651
  call void @__olang_scope_close(ptr %s15)
  store ptr %t646, ptr %rv
  br label %ret
bb189:
  %t654 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t656 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s15, i32 %t654)
  store { i64, ptr } %t656, ptr %l330
  br label %bb190
bb190:
  %t657 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t658 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t657, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t658, ptr %l331
  br label %bb191
bb191:
  %t659 = load i1, ptr %l331, !tbaa !21
  %t660 = xor i1 %t659, true
  br i1 %t660, label %bb192, label %bb193
bb192:
  %t662 = load ptr, ptr %l0, !tbaa !29
  store ptr %t662, ptr %l334, !tbaa !29
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load i32, ptr %l8, !tbaa !23
  %t667 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t663, i32 %t664)
  store i32 %t667, ptr %l337
  br label %bb194
bb193:
  store i1 false, ptr %l333, !tbaa !21
  br label %bb199
bb194:
  %t668 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t670 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s15, i32 %t668)
  store { i64, ptr } %t670, ptr %l339
  br label %bb195
bb195:
  %t671 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t671, ptr %l340
  %t672 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t674 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s15, i32 %t672)
  store { i64, ptr } %t674, ptr %l342
  br label %bb196
bb196:
  %t675 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t676 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s15, ptr %s15, { i64, ptr } %t675)
  store { i64, ptr } %t676, ptr %l343
  br label %bb197
bb197:
  %t677 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t678 = load ptr, ptr %l334, !tbaa !29
  %t679 = load i32, ptr %l337, !tbaa !23
  %t680 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t681 = load %"compiler/source:Span", ptr %l340
  %t683 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s15, ptr %s15, ptr %t678, i32 %t679, { i64, ptr } %t680, %"compiler/source:Span" %t681, { i64, ptr } %t677, i64 1, i1 false)
  store i1 %t683, ptr %l345
  br label %bb198
bb198:
  %t684 = load i1, ptr %l345, !tbaa !21
  store i1 %t684, ptr %l333, !tbaa !21
  br label %bb199
bb199:
  %t685 = load i1, ptr %l333, !tbaa !21
  br i1 %t685, label %bb200, label %bb201
bb200:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load %"compiler/source:Span", ptr %l1
  %t690 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t686, %"compiler/source:Span" %t687)
  store ptr %t690, ptr %l348
  br label %bb202
bb201:
  br label %bb203
bb202:
  call void @__olang_scope_close(ptr %s15)
  %t691 = load ptr, ptr %l348, !tbaa !29
  store ptr %t691, ptr %rv
  br label %ret
bb203:
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = load i32, ptr %l8, !tbaa !23
  %t696 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t692, i32 %t693)
  store i1 %t696, ptr %l351
  br label %bb204
bb204:
  %t697 = load i1, ptr %l351, !tbaa !21
  br i1 %t697, label %bb205, label %bb206
bb205:
  store i1 true, ptr %l352, !tbaa !21
  br label %bb208
bb206:
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load i32, ptr %l9, !tbaa !23
  %t702 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t698, i32 %t699)
  store i1 %t702, ptr %l355
  br label %bb207
bb207:
  %t703 = load i1, ptr %l355, !tbaa !21
  store i1 %t703, ptr %l352, !tbaa !21
  br label %bb208
bb208:
  %t704 = load i1, ptr %l352, !tbaa !21
  br i1 %t704, label %bb209, label %bb210
bb209:
  store %olang.scope zeroinitializer, ptr %s18
  %t705 = load ptr, ptr %l0, !tbaa !29
  store ptr %t705, ptr %l356, !tbaa !29
  %t706 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t706, ptr %l357
  %t707 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t709 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s18, i32 %t707)
  store { i64, ptr } %t709, ptr %l359
  br label %bb211
bb210:
  store %olang.scope zeroinitializer, ptr %s19
  %t710 = load ptr, ptr %l0, !tbaa !29
  store ptr %t710, ptr %l372, !tbaa !29
  %t711 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t711, ptr %l373
  %t712 = load i32, ptr %l8, !tbaa !23
  store i32 %t712, ptr %l374, !tbaa !23
  %t713 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t715 = call { i64, ptr } @compiler_2fcheck_2eopNeed(ptr %s19, i32 %t713)
  store { i64, ptr } %t715, ptr %l376
  br label %bb217
bb211:
  %t716 = load { i64, ptr }, ptr %l359, !tbaa !27
  %t717 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s18, ptr %s18, { i64, ptr } %t716)
  store { i64, ptr } %t717, ptr %l360
  br label %bb212
bb212:
  %t718 = load { i64, ptr }, ptr %l360, !tbaa !27
  store { i64, ptr } %t718, ptr %l361, !tbaa !27
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load i32, ptr %l8, !tbaa !23
  %t723 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t719, i32 %t720)
  store { i64, ptr } %t723, ptr %l364
  br label %bb213
bb213:
  %t724 = load { i64, ptr }, ptr %l364, !tbaa !27
  store { i64, ptr } %t724, ptr %l365, !tbaa !27
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t726 = load i32, ptr %l9, !tbaa !23
  %t729 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t725, i32 %t726)
  store { i64, ptr } %t729, ptr %l368
  br label %bb214
bb214:
  %t730 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t731 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t732 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t734 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %s18, ptr %s18, ptr %s18, ptr %v0, { i64, ptr } %t731, { i64, ptr } %t732, { i64, ptr } %t730)
  store %"compiler/diagmsg:Msg" %t734, ptr %l370
  br label %bb215
bb215:
  %t735 = load ptr, ptr %l356, !tbaa !29
  %t736 = load %"compiler/source:Span", ptr %l357
  %t737 = load %"compiler/diagmsg:Msg", ptr %l370
  %t738 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t735, %"compiler/source:Span" %t736, %"compiler/diagmsg:Msg" %t737)
  store i64 %t738, ptr %l371
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s18)
  br label %bb223
bb217:
  %t739 = load { i64, ptr }, ptr %l376, !tbaa !27
  store { i64, ptr } %t739, ptr %l377, !tbaa !27
  %t740 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t742 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s19, i32 %t740)
  store { i64, ptr } %t742, ptr %l379
  br label %bb218
bb218:
  %t743 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t744 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s19, ptr %s19, { i64, ptr } %t743)
  store { i64, ptr } %t744, ptr %l380
  br label %bb219
bb219:
  %t745 = load { i64, ptr }, ptr %l380, !tbaa !27
  store { i64, ptr } %t745, ptr %l381, !tbaa !27
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t747 = load i32, ptr %l8, !tbaa !23
  %t750 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s19, ptr %t746, i32 %t747)
  store { i64, ptr } %t750, ptr %l384
  br label %bb220
bb220:
  %t751 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t752 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t754 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s19, ptr %s19, ptr %v0, { i64, ptr } %t752, { i64, ptr } %t751)
  store %"compiler/diagmsg:Msg" %t754, ptr %l386
  br label %bb221
bb221:
  %t755 = load ptr, ptr %l372, !tbaa !29
  %t756 = load %"compiler/source:Span", ptr %l373
  %t757 = load i32, ptr %l374, !tbaa !23
  %t758 = load { i64, ptr }, ptr %l377, !tbaa !27
  %t759 = load %"compiler/diagmsg:Msg", ptr %l386
  %t760 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s19, ptr %v0, ptr %t755, %"compiler/source:Span" %t756, i32 %t757, { i64, ptr } %t758, %"compiler/diagmsg:Msg" %t759)
  store i64 %t760, ptr %l387
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s19)
  br label %bb223
bb223:
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t762 = load %"compiler/source:Span", ptr %l1
  %t765 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t761, %"compiler/source:Span" %t762)
  store ptr %t765, ptr %l390
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s15)
  %t766 = load ptr, ptr %l390, !tbaa !29
  store ptr %t766, ptr %rv
  br label %ret
bb225:
  %t767 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t769 = trunc i64 108 to i32
  %t770 = icmp eq i32 %t767, %t769
  br i1 %t770, label %bb226, label %bb227
bb226:
  store i1 true, ptr %l393, !tbaa !21
  br label %bb228
bb227:
  %t772 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t774 = trunc i64 109 to i32
  %t775 = icmp eq i32 %t772, %t774
  store i1 %t775, ptr %l393, !tbaa !21
  br label %bb228
bb228:
  %t777 = load i1, ptr %l393, !tbaa !21
  br i1 %t777, label %bb229, label %bb230
bb229:
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t779 = load i32, ptr %l8, !tbaa !23
  %t782 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t778, i32 %t779)
  store i1 %t782, ptr %l398
  br label %bb231
bb230:
  br label %bb275
bb231:
  %t783 = load i1, ptr %l398, !tbaa !21
  %t784 = xor i1 %t783, true
  br i1 %t784, label %bb232, label %bb233
bb232:
  store %olang.scope zeroinitializer, ptr %s21
  %t786 = load ptr, ptr %l0, !tbaa !29
  store ptr %t786, ptr %l400, !tbaa !29
  %t787 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t787, ptr %l401
  %t788 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t790 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s21, i32 %t788)
  store { i64, ptr } %t790, ptr %l403
  br label %bb234
bb233:
  br label %bb239
bb234:
  %t791 = load { i64, ptr }, ptr %l403, !tbaa !27
  %t792 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s21, ptr %s21, { i64, ptr } %t791)
  store { i64, ptr } %t792, ptr %l404
  br label %bb235
bb235:
  %t793 = load { i64, ptr }, ptr %l404, !tbaa !27
  store { i64, ptr } %t793, ptr %l405, !tbaa !27
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t795 = load i32, ptr %l8, !tbaa !23
  %t798 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s21, ptr %t794, i32 %t795)
  store { i64, ptr } %t798, ptr %l408
  br label %bb236
bb236:
  %t799 = load { i64, ptr }, ptr %l408, !tbaa !27
  %t800 = load { i64, ptr }, ptr %l405, !tbaa !27
  %t802 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s21, ptr %s21, ptr %v0, { i64, ptr } %t800, { i64, ptr } %t799)
  store %"compiler/diagmsg:Msg" %t802, ptr %l410
  br label %bb237
bb237:
  %t803 = load ptr, ptr %l400, !tbaa !29
  %t804 = load %"compiler/source:Span", ptr %l401
  %t805 = load %"compiler/diagmsg:Msg", ptr %l410
  %t806 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t803, %"compiler/source:Span" %t804, %"compiler/diagmsg:Msg" %t805)
  store i64 %t806, ptr %l411
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s21)
  br label %bb239
bb239:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = load i32, ptr %l9, !tbaa !23
  %t811 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t807, i32 %t808)
  store i1 %t811, ptr %l414
  br label %bb240
bb240:
  %t812 = load i1, ptr %l414, !tbaa !21
  %t813 = xor i1 %t812, true
  br i1 %t813, label %bb241, label %bb242
bb241:
  store %olang.scope zeroinitializer, ptr %s22
  %t815 = load ptr, ptr %l0, !tbaa !29
  store ptr %t815, ptr %l416, !tbaa !29
  %t816 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t816, ptr %l417
  %t817 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t819 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s22, i32 %t817)
  store { i64, ptr } %t819, ptr %l419
  br label %bb243
bb242:
  br label %bb248
bb243:
  %t820 = load { i64, ptr }, ptr %l419, !tbaa !27
  %t821 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s22, ptr %s22, { i64, ptr } %t820)
  store { i64, ptr } %t821, ptr %l420
  br label %bb244
bb244:
  %t822 = load { i64, ptr }, ptr %l420, !tbaa !27
  store { i64, ptr } %t822, ptr %l421, !tbaa !27
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load i32, ptr %l9, !tbaa !23
  %t827 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s22, ptr %t823, i32 %t824)
  store { i64, ptr } %t827, ptr %l424
  br label %bb245
bb245:
  %t828 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t829 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t831 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s22, ptr %s22, ptr %v0, { i64, ptr } %t829, { i64, ptr } %t828)
  store %"compiler/diagmsg:Msg" %t831, ptr %l426
  br label %bb246
bb246:
  %t832 = load ptr, ptr %l416, !tbaa !29
  %t833 = load %"compiler/source:Span", ptr %l417
  %t834 = load %"compiler/diagmsg:Msg", ptr %l426
  %t835 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t832, %"compiler/source:Span" %t833, %"compiler/diagmsg:Msg" %t834)
  store i64 %t835, ptr %l427
  br label %bb247
bb247:
  call void @__olang_scope_close(ptr %s22)
  br label %bb248
bb248:
  %t836 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t838 = call i1 @compiler_2fcheck_2ecompares(i32 %t836)
  store i1 %t838, ptr %l429
  br label %bb249
bb249:
  %t839 = load i1, ptr %l429, !tbaa !21
  %t840 = xor i1 %t839, true
  br i1 %t840, label %bb250, label %bb251
bb250:
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t843 = load i32, ptr %l8, !tbaa !23
  %t846 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t842, i32 %t843)
  store i1 %t846, ptr %l434
  br label %bb252
bb251:
  store i1 false, ptr %l431, !tbaa !21
  br label %bb253
bb252:
  %t847 = load i1, ptr %l434, !tbaa !21
  store i1 %t847, ptr %l431, !tbaa !21
  br label %bb253
bb253:
  %t848 = load i1, ptr %l431, !tbaa !21
  br i1 %t848, label %bb254, label %bb255
bb254:
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t851 = getelementptr %"compiler/check:Checker", ptr %t849, i32 0, i32 1
  %t852 = load ptr, ptr %t851, !tbaa !29
  %t853 = load i32, ptr %l8, !tbaa !23
  %t856 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t852, i32 %t853)
  store i1 %t856, ptr %l439
  br label %bb256
bb255:
  store i1 false, ptr %l435, !tbaa !21
  br label %bb257
bb256:
  %t857 = load i1, ptr %l439, !tbaa !21
  %t858 = xor i1 %t857, true
  store i1 %t858, ptr %l435, !tbaa !21
  br label %bb257
bb257:
  %t860 = load i1, ptr %l435, !tbaa !21
  br i1 %t860, label %bb258, label %bb259
bb258:
  store %olang.scope zeroinitializer, ptr %s23
  %t861 = load ptr, ptr %l0, !tbaa !29
  store ptr %t861, ptr %l441, !tbaa !29
  %t862 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t862, ptr %l442
  %t863 = load ptr, ptr %l0, !tbaa !29
  %t864 = load i32, ptr %l8, !tbaa !23
  %t867 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s23, ptr %t863, i32 %t864)
  store { i64, ptr } %t867, ptr %l445
  br label %bb260
bb259:
  br label %bb267
bb260:
  %t868 = load { i64, ptr }, ptr %l445, !tbaa !27
  store { i64, ptr } %t868, ptr %l446, !tbaa !27
  %t869 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t871 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s23, i32 %t869)
  store { i64, ptr } %t871, ptr %l448
  br label %bb261
bb261:
  %t872 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t873 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s23, ptr %s23, { i64, ptr } %t872)
  store { i64, ptr } %t873, ptr %l449
  br label %bb262
bb262:
  %t874 = load { i64, ptr }, ptr %l449, !tbaa !27
  store { i64, ptr } %t874, ptr %l450, !tbaa !27
  %t875 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t877 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s23, i32 %t875)
  store { i64, ptr } %t877, ptr %l452
  br label %bb263
bb263:
  %t878 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t879 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t880 = load { i64, ptr }, ptr %l452, !tbaa !27
  %t881 = extractvalue { i64, ptr } %t880, 1
  %t882 = extractvalue { i64, ptr } %t880, 0
  %t883 = add i64 %t879, %t882
  %t884 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t885 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t886 = add i64 %t883, %t885
  %t887 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t886)
  call void @olang_textcopy(ptr %t887, ptr %t878, i64 %t879)
  %t888 = getelementptr i8, ptr %t887, i64 %t879
  call void @olang_textcopy(ptr %t888, ptr %t881, i64 %t882)
  %t889 = getelementptr i8, ptr %t888, i64 %t882
  call void @olang_textcopy(ptr %t889, ptr %t884, i64 %t885)
  %t890 = insertvalue { i64, ptr } undef, i64 %t886, 0
  %t891 = insertvalue { i64, ptr } %t890, ptr %t887, 1
  %t893 = load { i64, ptr }, ptr %l446, !tbaa !27
  %t894 = load { i64, ptr }, ptr %l450, !tbaa !27
  %t896 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s23, ptr %s23, ptr %s23, ptr %v0, { i64, ptr } %t893, { i64, ptr } %t894, { i64, ptr } %t891)
  store %"compiler/diagmsg:Msg" %t896, ptr %l455
  br label %bb264
bb264:
  %t897 = load ptr, ptr %l441, !tbaa !29
  %t898 = load %"compiler/source:Span", ptr %l442
  %t899 = load %"compiler/diagmsg:Msg", ptr %l455
  %t900 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t897, %"compiler/source:Span" %t898, %"compiler/diagmsg:Msg" %t899)
  store i64 %t900, ptr %l456
  br label %bb265
bb265:
  %t901 = load ptr, ptr %l0, !tbaa !29
  %t902 = load %"compiler/source:Span", ptr %l1
  %t905 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t901, %"compiler/source:Span" %t902)
  store ptr %t905, ptr %l459
  br label %bb266
bb266:
  call void @__olang_scope_close(ptr %s23)
  %t906 = load ptr, ptr %l459, !tbaa !29
  store ptr %t906, ptr %rv
  br label %ret
bb267:
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t908 = load i32, ptr %l8, !tbaa !23
  %t909 = load ptr, ptr %l5, !tbaa !29
  store ptr %t909, ptr %l462, !tbaa !29
  %t910 = load %"compiler/source:Span", ptr %l7
  %t911 = load ptr, ptr %l462, !tbaa !29
  %t912 = call ptr @__olang_scope_of(ptr %t911, ptr null)
  %t913 = call ptr @__olang_scope_hold(ptr %t912)
  %t914 = ptrtoint ptr %t913 to i64
  %t916 = inttoptr i64 %t914 to ptr
  %t919 = load ptr, ptr %l462, !tbaa !29
  %t921 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %t916, ptr %t907, i32 %t908, ptr %t919, %"compiler/source:Span" %t910)
  store i1 %t921, ptr %l465
  br label %bb268
bb268:
  %t922 = load i1, ptr %l465, !tbaa !21
  %t923 = xor i1 %t922, true
  br i1 %t923, label %bb269, label %bb270
bb269:
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t926 = load %"compiler/source:Span", ptr %l1
  %t929 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t925, %"compiler/source:Span" %t926)
  store ptr %t929, ptr %l469
  br label %bb271
bb270:
  br label %bb272
bb271:
  %t930 = load ptr, ptr %l469, !tbaa !29
  store ptr %t930, ptr %rv
  br label %ret
bb272:
  %t931 = load ptr, ptr %l0, !tbaa !29
  store ptr %t931, ptr %l470, !tbaa !29
  %t932 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t932, ptr %l471
  %t933 = load i32, ptr %l8, !tbaa !23
  store i32 %t933, ptr %l472, !tbaa !23
  %t934 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t936 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t934)
  store i32 %t936, ptr %l474
  br label %bb273
bb273:
  %t937 = load ptr, ptr %l4, !tbaa !29
  store ptr %t937, ptr %l475, !tbaa !29
  %t938 = load ptr, ptr %l5, !tbaa !29
  store ptr %t938, ptr %l476, !tbaa !29
  %t939 = load ptr, ptr %l475, !tbaa !29
  %t940 = call ptr @__olang_scope_of(ptr %t939, ptr null)
  %t941 = call ptr @__olang_scope_hold(ptr %t940)
  %t942 = ptrtoint ptr %t941 to i64
  %t943 = load ptr, ptr %l476, !tbaa !29
  %t944 = call ptr @__olang_scope_of(ptr %t943, ptr null)
  %t945 = call ptr @__olang_scope_hold(ptr %t944)
  %t946 = ptrtoint ptr %t945 to i64
  %t948 = inttoptr i64 %t942 to ptr
  %t950 = inttoptr i64 %t946 to ptr
  %t951 = load ptr, ptr %l470, !tbaa !29
  %t952 = load %"compiler/source:Span", ptr %l471
  %t953 = load i32, ptr %l472, !tbaa !23
  %t954 = load i32, ptr %l474, !range !{i32 0, i32 54}
  %t955 = load ptr, ptr %l475, !tbaa !29
  %t956 = load ptr, ptr %l476, !tbaa !29
  %t957 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %t948, ptr %t950, ptr %v3, ptr %t951, %"compiler/source:Span" %t952, i32 %t953, i32 %t954, ptr %t955, ptr %t956)
  store ptr %t957, ptr %l479
  br label %bb274
bb274:
  %t958 = load ptr, ptr %l479, !tbaa !29
  store ptr %t958, ptr %rv
  br label %ret
bb275:
  %t959 = load i32, ptr %l8, !tbaa !23
  store i32 %t959, ptr %l17, !tbaa !23
  %t961 = load i32, ptr %l8, !tbaa !23
  %t962 = load i32, ptr %l9, !tbaa !23
  %t965 = icmp ne i32 %t961, %t962
  br i1 %t965, label %bb276, label %bb277
bb276:
  %t967 = load ptr, ptr %l0, !tbaa !29
  %t969 = getelementptr %"compiler/check:Checker", ptr %t967, i32 0, i32 1
  %t970 = load ptr, ptr %t969, !tbaa !29
  %t971 = load i32, ptr %l8, !tbaa !23
  %t972 = load i32, ptr %l9, !tbaa !23
  %t976 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t970, i32 %t971, i32 %t972)
  store i32 %t976, ptr %l488
  br label %bb278
bb277:
  br label %bb295
bb278:
  %t977 = load i32, ptr %l488, !tbaa !23
  store i32 %t977, ptr %l17, !tbaa !23
  %t978 = load i32, ptr %l17, !tbaa !23
  %t980 = icmp slt i32 %t978, 0
  br i1 %t980, label %bb279, label %bb280
bb279:
  store %olang.scope zeroinitializer, ptr %s27
  %t982 = load ptr, ptr %l0, !tbaa !29
  store ptr %t982, ptr %l491, !tbaa !29
  %t983 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t983, ptr %l492
  %t984 = load ptr, ptr %l0, !tbaa !29
  %t985 = load i32, ptr %l8, !tbaa !23
  %t988 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s27, ptr %t984, i32 %t985)
  store { i64, ptr } %t988, ptr %l495
  br label %bb281
bb280:
  br label %bb286
bb281:
  %t989 = load { i64, ptr }, ptr %l495, !tbaa !27
  store { i64, ptr } %t989, ptr %l496, !tbaa !27
  %t990 = load ptr, ptr %l0, !tbaa !29
  %t991 = load i32, ptr %l9, !tbaa !23
  %t994 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s27, ptr %t990, i32 %t991)
  store { i64, ptr } %t994, ptr %l499
  br label %bb282
bb282:
  %t995 = load { i64, ptr }, ptr %l499, !tbaa !27
  %t996 = load { i64, ptr }, ptr %l496, !tbaa !27
  %t998 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %s27, ptr %s27, ptr %v0, { i64, ptr } %t996, { i64, ptr } %t995)
  store %"compiler/diagmsg:Msg" %t998, ptr %l501
  br label %bb283
bb283:
  %t999 = load ptr, ptr %l491, !tbaa !29
  %t1000 = load %"compiler/source:Span", ptr %l492
  %t1001 = load %"compiler/diagmsg:Msg", ptr %l501
  %t1002 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t999, %"compiler/source:Span" %t1000, %"compiler/diagmsg:Msg" %t1001)
  store i64 %t1002, ptr %l502
  br label %bb284
bb284:
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1004 = load %"compiler/source:Span", ptr %l1
  %t1007 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t1003, %"compiler/source:Span" %t1004)
  store ptr %t1007, ptr %l505
  br label %bb285
bb285:
  call void @__olang_scope_close(ptr %s27)
  %t1008 = load ptr, ptr %l505, !tbaa !29
  store ptr %t1008, ptr %rv
  br label %ret
bb286:
  %t1009 = load i32, ptr %l17, !tbaa !23
  %t1010 = load i32, ptr %l8, !tbaa !23
  %t1013 = icmp ne i32 %t1009, %t1010
  br i1 %t1013, label %bb287, label %bb288
bb287:
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1017 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1017, ptr %l511, !tbaa !29
  %t1018 = load i32, ptr %l17, !tbaa !23
  %t1019 = load ptr, ptr %l511, !tbaa !29
  %t1020 = call ptr @__olang_scope_of(ptr %t1019, ptr null)
  %t1021 = call ptr @__olang_scope_hold(ptr %t1020)
  %t1022 = ptrtoint ptr %t1021 to i64
  %t1024 = inttoptr i64 %t1022 to ptr
  %t1027 = load ptr, ptr %l511, !tbaa !29
  %t1029 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t1024, ptr %v0, ptr %t1015, %"compiler/source:Span" %a6, ptr %t1027, i32 %t1018)
  store ptr %t1029, ptr %l514
  br label %bb289
bb288:
  br label %bb290
bb289:
  %t1030 = load ptr, ptr %l514, !tbaa !29
  store ptr %t1030, ptr %l4, !tbaa !29
  br label %bb290
bb290:
  %t1031 = load i32, ptr %l17, !tbaa !23
  %t1032 = load i32, ptr %l9, !tbaa !23
  %t1035 = icmp ne i32 %t1031, %t1032
  br i1 %t1035, label %bb291, label %bb292
bb291:
  %t1037 = load ptr, ptr %l0, !tbaa !29
  %t1038 = load %"compiler/source:Span", ptr %l7
  %t1039 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1039, ptr %l520, !tbaa !29
  %t1040 = load i32, ptr %l17, !tbaa !23
  %t1041 = load ptr, ptr %l520, !tbaa !29
  %t1042 = call ptr @__olang_scope_of(ptr %t1041, ptr null)
  %t1043 = call ptr @__olang_scope_hold(ptr %t1042)
  %t1044 = ptrtoint ptr %t1043 to i64
  %t1046 = inttoptr i64 %t1044 to ptr
  %t1049 = load ptr, ptr %l520, !tbaa !29
  %t1051 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t1046, ptr %v0, ptr %t1037, %"compiler/source:Span" %t1038, ptr %t1049, i32 %t1040)
  store ptr %t1051, ptr %l523
  br label %bb293
bb292:
  br label %bb294
bb293:
  %t1052 = load ptr, ptr %l523, !tbaa !29
  store ptr %t1052, ptr %l5, !tbaa !29
  br label %bb294
bb294:
  br label %bb295
bb295:
  %t1053 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t1055 = call i1 @compiler_2fcheck_2eintOnly(i32 %t1053)
  store i1 %t1055, ptr %l525
  br label %bb296
bb296:
  %t1056 = load i1, ptr %l525, !tbaa !21
  br i1 %t1056, label %bb297, label %bb298
bb297:
  %t1057 = load ptr, ptr %l0, !tbaa !29
  %t1058 = load i32, ptr %l17, !tbaa !23
  %t1061 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t1057, i32 %t1058)
  store i1 %t1061, ptr %l529
  br label %bb299
bb298:
  store i1 false, ptr %l526, !tbaa !21
  br label %bb300
bb299:
  %t1062 = load i1, ptr %l529, !tbaa !21
  %t1063 = xor i1 %t1062, true
  store i1 %t1063, ptr %l526, !tbaa !21
  br label %bb300
bb300:
  %t1065 = load i1, ptr %l526, !tbaa !21
  br i1 %t1065, label %bb301, label %bb302
bb301:
  store %olang.scope zeroinitializer, ptr %s30
  %t1066 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1066, ptr %l531, !tbaa !29
  %t1067 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1067, ptr %l532
  %t1068 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t1070 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s30, i32 %t1068)
  store { i64, ptr } %t1070, ptr %l534
  br label %bb303
bb302:
  br label %bb309
bb303:
  %t1071 = load { i64, ptr }, ptr %l534, !tbaa !27
  %t1072 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s30, ptr %s30, { i64, ptr } %t1071)
  store { i64, ptr } %t1072, ptr %l535
  br label %bb304
bb304:
  %t1073 = load { i64, ptr }, ptr %l535, !tbaa !27
  store { i64, ptr } %t1073, ptr %l536, !tbaa !27
  %t1074 = load ptr, ptr %l0, !tbaa !29
  %t1075 = load i32, ptr %l17, !tbaa !23
  %t1078 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s30, ptr %t1074, i32 %t1075)
  store { i64, ptr } %t1078, ptr %l539
  br label %bb305
bb305:
  %t1079 = load { i64, ptr }, ptr %l539, !tbaa !27
  %t1080 = load { i64, ptr }, ptr %l536, !tbaa !27
  %t1082 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s30, ptr %s30, ptr %v0, { i64, ptr } %t1080, { i64, ptr } %t1079)
  store %"compiler/diagmsg:Msg" %t1082, ptr %l541
  br label %bb306
bb306:
  %t1083 = load ptr, ptr %l531, !tbaa !29
  %t1084 = load %"compiler/source:Span", ptr %l532
  %t1085 = load %"compiler/diagmsg:Msg", ptr %l541
  %t1086 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1083, %"compiler/source:Span" %t1084, %"compiler/diagmsg:Msg" %t1085)
  store i64 %t1086, ptr %l542
  br label %bb307
bb307:
  %t1087 = load ptr, ptr %l0, !tbaa !29
  %t1088 = load %"compiler/source:Span", ptr %l1
  %t1091 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t1087, %"compiler/source:Span" %t1088)
  store ptr %t1091, ptr %l545
  br label %bb308
bb308:
  call void @__olang_scope_close(ptr %s30)
  %t1092 = load ptr, ptr %l545, !tbaa !29
  store ptr %t1092, ptr %rv
  br label %ret
bb309:
  %t1093 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t1095 = call i1 @compiler_2fcheck_2ecompares(i32 %t1093)
  store i1 %t1095, ptr %l547
  br label %bb310
bb310:
  %t1096 = load i1, ptr %l547, !tbaa !21
  %t1097 = xor i1 %t1096, true
  br i1 %t1097, label %bb311, label %bb312
bb311:
  %t1099 = load ptr, ptr %l0, !tbaa !29
  %t1100 = load i32, ptr %l17, !tbaa !23
  %t1103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1099, i32 %t1100)
  store i1 %t1103, ptr %l552
  br label %bb313
bb312:
  store i1 false, ptr %l549, !tbaa !21
  br label %bb314
bb313:
  %t1104 = load i1, ptr %l552, !tbaa !21
  store i1 %t1104, ptr %l549, !tbaa !21
  br label %bb314
bb314:
  %t1105 = load i1, ptr %l549, !tbaa !21
  br i1 %t1105, label %bb315, label %bb316
bb315:
  %t1106 = load ptr, ptr %l0, !tbaa !29
  %t1108 = getelementptr %"compiler/check:Checker", ptr %t1106, i32 0, i32 1
  %t1109 = load ptr, ptr %t1108, !tbaa !29
  %t1110 = load i32, ptr %l17, !tbaa !23
  %t1113 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t1109, i32 %t1110)
  store i1 %t1113, ptr %l557
  br label %bb317
bb316:
  store i1 false, ptr %l553, !tbaa !21
  br label %bb318
bb317:
  %t1114 = load i1, ptr %l557, !tbaa !21
  %t1115 = xor i1 %t1114, true
  store i1 %t1115, ptr %l553, !tbaa !21
  br label %bb318
bb318:
  %t1117 = load i1, ptr %l553, !tbaa !21
  br i1 %t1117, label %bb319, label %bb320
bb319:
  store %olang.scope zeroinitializer, ptr %s31
  %t1118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1118, ptr %l559, !tbaa !29
  %t1119 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1119, ptr %l560
  %t1120 = load ptr, ptr %l0, !tbaa !29
  %t1121 = load i32, ptr %l17, !tbaa !23
  %t1124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s31, ptr %t1120, i32 %t1121)
  store { i64, ptr } %t1124, ptr %l563
  br label %bb321
bb320:
  br label %bb328
bb321:
  %t1125 = load { i64, ptr }, ptr %l563, !tbaa !27
  store { i64, ptr } %t1125, ptr %l564, !tbaa !27
  %t1126 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t1128 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s31, i32 %t1126)
  store { i64, ptr } %t1128, ptr %l566
  br label %bb322
bb322:
  %t1129 = load { i64, ptr }, ptr %l566, !tbaa !27
  %t1130 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s31, ptr %s31, { i64, ptr } %t1129)
  store { i64, ptr } %t1130, ptr %l567
  br label %bb323
bb323:
  %t1131 = load { i64, ptr }, ptr %l567, !tbaa !27
  store { i64, ptr } %t1131, ptr %l568, !tbaa !27
  %t1132 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t1134 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s31, i32 %t1132)
  store { i64, ptr } %t1134, ptr %l570
  br label %bb324
bb324:
  %t1135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t1136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t1137 = load { i64, ptr }, ptr %l570, !tbaa !27
  %t1138 = extractvalue { i64, ptr } %t1137, 1
  %t1139 = extractvalue { i64, ptr } %t1137, 0
  %t1140 = add i64 %t1136, %t1139
  %t1141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t1142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t1143 = add i64 %t1140, %t1142
  %t1144 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1143)
  call void @olang_textcopy(ptr %t1144, ptr %t1135, i64 %t1136)
  %t1145 = getelementptr i8, ptr %t1144, i64 %t1136
  call void @olang_textcopy(ptr %t1145, ptr %t1138, i64 %t1139)
  %t1146 = getelementptr i8, ptr %t1145, i64 %t1139
  call void @olang_textcopy(ptr %t1146, ptr %t1141, i64 %t1142)
  %t1147 = insertvalue { i64, ptr } undef, i64 %t1143, 0
  %t1148 = insertvalue { i64, ptr } %t1147, ptr %t1144, 1
  %t1150 = load { i64, ptr }, ptr %l564, !tbaa !27
  %t1151 = load { i64, ptr }, ptr %l568, !tbaa !27
  %t1153 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s31, ptr %s31, ptr %s31, ptr %v0, { i64, ptr } %t1150, { i64, ptr } %t1151, { i64, ptr } %t1148)
  store %"compiler/diagmsg:Msg" %t1153, ptr %l573
  br label %bb325
bb325:
  %t1154 = load ptr, ptr %l559, !tbaa !29
  %t1155 = load %"compiler/source:Span", ptr %l560
  %t1156 = load %"compiler/diagmsg:Msg", ptr %l573
  %t1157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1154, %"compiler/source:Span" %t1155, %"compiler/diagmsg:Msg" %t1156)
  store i64 %t1157, ptr %l574
  br label %bb326
bb326:
  %t1158 = load ptr, ptr %l0, !tbaa !29
  %t1159 = load %"compiler/source:Span", ptr %l1
  %t1162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t1158, %"compiler/source:Span" %t1159)
  store ptr %t1162, ptr %l577
  br label %bb327
bb327:
  call void @__olang_scope_close(ptr %s31)
  %t1163 = load ptr, ptr %l577, !tbaa !29
  store ptr %t1163, ptr %rv
  br label %ret
bb328:
  %t1164 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t1166 = call i1 @compiler_2fcheck_2ecompares(i32 %t1164)
  store i1 %t1166, ptr %l579
  br label %bb329
bb329:
  %t1167 = load i1, ptr %l579, !tbaa !21
  br i1 %t1167, label %bb330, label %bb331
bb330:
  %t1168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1168, ptr %l580, !tbaa !29
  %t1169 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1169, ptr %l581
  %t1170 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1170, ptr %l582, !tbaa !23
  %t1171 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t1173 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t1171)
  store i32 %t1173, ptr %l584
  br label %bb332
bb331:
  br label %bb334
bb332:
  %t1174 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1174, ptr %l585, !tbaa !29
  %t1175 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1175, ptr %l587, !tbaa !29
  %t1177 = load ptr, ptr %l585, !tbaa !29
  %t1178 = call ptr @__olang_scope_of(ptr %t1177, ptr null)
  %t1179 = call ptr @__olang_scope_hold(ptr %t1178)
  %t1180 = ptrtoint ptr %t1179 to i64
  %t1181 = load ptr, ptr %l587, !tbaa !29
  %t1182 = call ptr @__olang_scope_of(ptr %t1181, ptr null)
  %t1183 = call ptr @__olang_scope_hold(ptr %t1182)
  %t1184 = ptrtoint ptr %t1183 to i64
  %t1186 = inttoptr i64 %t1180 to ptr
  %t1188 = inttoptr i64 %t1184 to ptr
  %t1189 = load ptr, ptr %l580, !tbaa !29
  %t1190 = load %"compiler/source:Span", ptr %l581
  %t1191 = load i32, ptr %l582, !tbaa !23
  %t1192 = load i32, ptr %l584, !range !{i32 0, i32 54}
  %t1193 = load ptr, ptr %l585, !tbaa !29
  %t1194 = load ptr, ptr %l587, !tbaa !29
  %t1195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t1186, ptr %t1188, ptr %v3, ptr %t1189, %"compiler/source:Span" %t1190, i32 %t1191, i32 %t1192, ptr %t1193, ptr %t1194)
  store ptr %t1195, ptr %l590
  br label %bb333
bb333:
  %t1196 = load ptr, ptr %l590, !tbaa !29
  store ptr %t1196, ptr %rv
  br label %ret
bb334:
  %t1197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1197, ptr %l591, !tbaa !29
  %t1198 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1198, ptr %l592
  %t1199 = load i32, ptr %l17, !tbaa !23
  store i32 %t1199, ptr %l593, !tbaa !23
  %t1200 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t1202 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t1200)
  store i32 %t1202, ptr %l595
  br label %bb335
bb335:
  %t1203 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1203, ptr %l596, !tbaa !29
  %t1204 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1204, ptr %l597, !tbaa !29
  %t1205 = load ptr, ptr %l596, !tbaa !29
  %t1206 = call ptr @__olang_scope_of(ptr %t1205, ptr null)
  %t1207 = call ptr @__olang_scope_hold(ptr %t1206)
  %t1208 = ptrtoint ptr %t1207 to i64
  %t1209 = load ptr, ptr %l597, !tbaa !29
  %t1210 = call ptr @__olang_scope_of(ptr %t1209, ptr null)
  %t1211 = call ptr @__olang_scope_hold(ptr %t1210)
  %t1212 = ptrtoint ptr %t1211 to i64
  %t1214 = inttoptr i64 %t1208 to ptr
  %t1216 = inttoptr i64 %t1212 to ptr
  %t1217 = load ptr, ptr %l591, !tbaa !29
  %t1218 = load %"compiler/source:Span", ptr %l592
  %t1219 = load i32, ptr %l593, !tbaa !23
  %t1220 = load i32, ptr %l595, !range !{i32 0, i32 54}
  %t1221 = load ptr, ptr %l596, !tbaa !29
  %t1222 = load ptr, ptr %l597, !tbaa !29
  %t1223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %t1214, ptr %t1216, ptr %v3, ptr %t1217, %"compiler/source:Span" %t1218, i32 %t1219, i32 %t1220, ptr %t1221, ptr %t1222)
  store ptr %t1223, ptr %l600
  br label %bb336
bb336:
  %t1224 = load ptr, ptr %l600, !tbaa !29
  store ptr %t1224, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l70 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = trunc i64 %t4 to i32
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t8, i32 %t6)
  store %"compiler/typed:Local" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t11, ptr %l2
  %t12 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t13 = load i32, ptr %t12, !range !{i32 0, i32 7}
  %t15 = trunc i64 0 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t22)
  store i1 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i1, ptr %l22, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load i1, ptr %l26, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t39)
  store ptr %t41, ptr %l30
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t42, i32 0, i32 5
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l33
  %t47 = call ptr @__olang_scope_hold(ptr %s0)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l34, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = call ptr @__olang_region_make_part(ptr %s0)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t53 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l37, !tbaa !24
  %t57 = load i64, ptr %l37, !tbaa !24
  %t58 = mul i64 %t57, 4
  %t59 = load i64, ptr %l34
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = call ptr @__olang_held_alloc(ptr %t60, i64 %t58)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l38, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l37, !tbaa !24
  %t69 = mul i64 %t68, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %t67, i64 %t69, i1 false)
  %t70 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t71 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  store { i64, ptr } %t70, ptr %t71, !tbaa !27
  %t72 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t74 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t78 = icmp eq i64 %t76, 0
  br i1 %t78, label %bb19, label %bb20
bb18:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t82, ptr %l43
  br label %bb21
bb19:
  %t83 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t83, !tbaa !27
  br label %bb20
bb20:
  %t84 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t85 = load i64, ptr %l34
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = load { i64, ptr }, ptr %t84
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = call ptr @__olang_region_or(ptr %t88, ptr null)
  %t90 = icmp ne ptr %t89, null
  %t91 = select i1 %t90, ptr %t89, ptr null
  call void @__olang_region_settle_in(ptr %t86, ptr %t91)
  br label %bb18
bb21:
  %t92 = load i64, ptr %l43, !tbaa !24
  store i64 %t92, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t93 = load i64, ptr %l5, !tbaa !24
  %t94 = load i64, ptr %l4, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb22, label %bb23
bb22:
  %t99 = load i64, ptr %l6, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb27
bb24:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t104 = load i64, ptr %l4, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l6, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l6, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l50, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t119 = load i64, ptr %l50, !tbaa !24
  store i64 %t119, ptr %l47, !tbaa !24
  br label %bb27
bb27:
  %t120 = load i64, ptr %l47, !tbaa !24
  store i64 %t120, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb28
bb28:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t122 = load i64, ptr %l7, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t129 = load i64, ptr %l4, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t131 = load i64, ptr %l6, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l9, !tbaa !24
  %t139 = load i64, ptr %l9, !tbaa !24
  %t142 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 %t139)
  store i32 %t142, ptr %l70
  br label %bb32
bb32:
  %t143 = load i32, ptr %l70, !tbaa !23
  %t144 = sext i32 %t143 to i64
  %t145 = load i64, ptr %l1, !tbaa !24
  %t148 = icmp eq i64 %t144, %t145
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t150 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t150, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t152 = load i64, ptr %l8, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l8, !tbaa !24
  br label %bb28
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceHere(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %lp14 = alloca ptr
  %lp15 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/diagmsg:Msg"
  %l30 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca i32
  %l39 = alloca i32
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l77 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l90 = alloca i32
  %l92 = alloca i32
  %l94 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l105 = alloca i32
  %l109 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l114 = alloca i32
  %l118 = alloca i64
  %l119 = alloca ptr
  %l123 = alloca i64
  %l128 = alloca ptr
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca i32
  %l136 = alloca ptr
  %l142 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t174 = alloca { i64, [2 x i64] }, align 8
  %t182 = alloca { i64, [5 x i64] }, align 8
  %t263 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i1, ptr %l22, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l24, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t12, ptr %l25
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l28
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t18 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t19 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlaceMember(ptr %v0, ptr %v0, { i64, ptr } %t18)
  store %"compiler/diagmsg:Msg" %t19, ptr %l29
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l25
  %t22 = load %"compiler/diagmsg:Msg", ptr %l29
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t20, %"compiler/source:Span" %t21, %"compiler/diagmsg:Msg" %t22)
  store i64 %t23, ptr %l30
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t24, %"compiler/source:Span" %t25)
  store ptr %t28, ptr %l33
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load ptr, ptr %l33, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceType(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l35
  br label %bb10
bb10:
  %t33 = load i32, ptr %l35, !tbaa !23
  store i32 %t33, ptr %l4, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l4, !tbaa !23
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l39
  br label %bb11
bb11:
  %t42 = load i32, ptr %l39, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = icmp eq i32 %t43, %t44
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t49, %"compiler/source:Span" %t50)
  store ptr %t53, ptr %l45
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load ptr, ptr %l45, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t55)
  store ptr %t57, ptr %l47
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l47, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t58, i32 0, i32 2
  %t61 = load i64, ptr %t60, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t63 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 30
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 30
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 31
  %t83 = getelementptr %"compiler/source:Span", ptr %t82, i32 0, i32 0
  %t84 = load i32, ptr %t83, !tbaa !23
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/load:Loader", ptr %t94, i32 0, i32 4
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l8, !tbaa !29
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %s0, ptr %t99, i64 %t100)
  store { i64, ptr } %t103, ptr %l66
  br label %bb20
bb20:
  %t104 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t104, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l71, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t125, ptr %l77, !tbaa !27
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 %t126
  %t131 = load i8, ptr %t130, !tbaa !32
  %t136 = load i64, ptr %l72, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t136
  store i8 %t131, ptr %t139, !tbaa !32
  %t140 = load i64, ptr %l72, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l72, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l11, !tbaa !24
  br label %bb21
bb26:
  %t147 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t147, ptr %lp14
  %t148 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t149 = load ptr, ptr %lp14
  store { i64, ptr } %t148, ptr %t149, !tbaa !27
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l85
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  store ptr %t156, ptr %l88, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t157)
  store i32 %t159, ptr %l90
  br label %bb27
bb27:
  %t160 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t161 = load ptr, ptr %l88, !tbaa !29
  %t162 = load i32, ptr %l90, !tbaa !23
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t161, i32 %t162, i64 %t160)
  store i32 %t164, ptr %l92
  br label %bb28
bb28:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t165)
  store ptr %t167, ptr %l94
  br label %bb29
bb29:
  %t168 = load ptr, ptr %l94, !tbaa !29
  %t170 = getelementptr %"compiler/check:frame", ptr %t168, i32 0, i32 2
  %t171 = load i64, ptr %t170, !tbaa !24
  %t172 = load ptr, ptr %lp14
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t174
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 0
  store i64 1, ptr %t175
  %t177 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t173, 0
  %t178 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 1
  store { { i64, ptr } } %t177, ptr %t178
  %t179 = load { i64, [2 x i64] }, ptr %t174
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t179, ptr %t181
  store { i64, [5 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 0
  store i64 1, ptr %t183
  %t184 = load %"compiler/source:Span", ptr %l85
  %t185 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t184, 0
  %t186 = load i32, ptr %l92, !tbaa !23
  %t187 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t185, i32 %t186, 1
  %t189 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t187, i64 %t171, 2
  %t191 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t189, ptr %t181, 3
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t191, ptr %t192
  %t193 = load { i64, [5 x i64] }, ptr %t182
  %t195 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t193, ptr %t195
  store ptr %t195, ptr %l101, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l102, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t197, ptr %l103
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t198)
  store i32 %t200, ptr %l105
  br label %bb30
bb30:
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t202 = load i64, ptr %l6, !tbaa !24
  %t203 = load i64, ptr %l7, !tbaa !24
  %t207 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t201, i64 %t202, i64 %t203)
  store i64 %t207, ptr %l109
  br label %bb31
bb31:
  %t208 = load ptr, ptr %l102, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l103
  %t210 = load i32, ptr %l105, !tbaa !23
  %t211 = load i64, ptr %l109, !tbaa !24
  %t212 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t208, %"compiler/source:Span" %t209, i32 %t210, i64 %t211)
  store ptr %t212, ptr %l110
  br label %bb32
bb32:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l111, !tbaa !29
  %t214 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t214, ptr %l112
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t215)
  store i32 %t217, ptr %l114
  br label %bb33
bb33:
  %t218 = load ptr, ptr %l8, !tbaa !29
  %t219 = load i64, ptr %l6, !tbaa !24
  %t220 = load i64, ptr %l7, !tbaa !24
  %t224 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eColumnAt(ptr %v0, ptr %t218, i64 %t219, i64 %t220)
  store i64 %t224, ptr %l118
  br label %bb34
bb34:
  %t225 = load ptr, ptr %l111, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l112
  %t227 = load i32, ptr %l114, !tbaa !23
  %t228 = load i64, ptr %l118, !tbaa !24
  %t229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t225, %"compiler/source:Span" %t226, i32 %t227, i64 %t228)
  store ptr %t229, ptr %l119
  br label %bb35
bb35:
  %t230 = load ptr, ptr %l101, !tbaa !29
  %t231 = insertvalue [3 x ptr] undef, ptr %t230, 0
  %t232 = load ptr, ptr %l110, !tbaa !29
  %t233 = insertvalue [3 x ptr] %t231, ptr %t232, 1
  %t234 = load ptr, ptr %l119, !tbaa !29
  %t235 = insertvalue [3 x ptr] %t233, ptr %t234, 2
  %t236 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store ptr %t236, ptr %lp15
  %t238 = load ptr, ptr %lp15
  store [3 x ptr] %t235, ptr %t238
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l4, !tbaa !23
  %t243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t239, i32 %t240)
  store i64 %t243, ptr %l123
  br label %bb36
bb36:
  %t244 = load i64, ptr %l123, !tbaa !24
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 29
  %t248 = load i32, ptr %t247, !tbaa !23
  store i32 %t248, ptr %l17, !tbaa !23
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l4, !tbaa !23
  %t254 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 29
  store i32 %t251, ptr %t254, !tbaa !23
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l128, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t256, ptr %l129
  %t257 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t257, ptr %l130
  %t258 = load i32, ptr %l5, !tbaa !23
  store i32 %t258, ptr %l131, !tbaa !23
  %t261 = trunc i64 %t244 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t263, i32 0, i32 0
  store i64 0, ptr %t264
  %t266 = insertvalue { i32 } undef, i32 %t261, 0
  %t267 = getelementptr { i64, [3 x i64] }, ptr %t263, i32 0, i32 1
  store { i32 } %t266, ptr %t267
  %t268 = load { i64, [3 x i64] }, ptr %t263
  %t270 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store { i64, [3 x i64] } %t268, ptr %t270
  store ptr %t270, ptr %l136, !tbaa !29
  %t271 = icmp sge i64 0, 0
  br i1 %t271, label %bb37, label %bb38
bb37:
  %t273 = icmp sle i64 0, 1152921504606846975
  br i1 %t273, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd)
  unreachable
bb39:
  %t275 = mul i64 0, 8
  %t276 = insertvalue { i64, ptr } undef, i64 0, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t278 = load ptr, ptr %lp15
  %t280 = insertvalue { i64, ptr } undef, i64 3, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t278, 1
  %t282 = load ptr, ptr %l128, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l129
  %t284 = load %"compiler/source:Span", ptr %l130
  %t285 = load i32, ptr %l131, !tbaa !23
  %t286 = load ptr, ptr %l136, !tbaa !29
  %t289 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t282, %"compiler/source:Span" %t283, %"compiler/source:Span" %t284, i32 %t285, ptr %t286, i64 -1, ptr null, { i64, ptr } %t277, { i64, ptr } %t281)
  store ptr %t289, ptr %l142
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd)
  unreachable
bb41:
  %t290 = load ptr, ptr %l142, !tbaa !29
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l17, !tbaa !23
  %t295 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 29
  store i32 %t292, ptr %t295, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t290, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceObject(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l26 = alloca i32
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i32, ptr %l6, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %s0, ptr %t6)
  store ptr %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = icmp eq ptr %t9, null
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t24 = trunc i64 21 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l10, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t28, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t37, i32 %t38, i64 %t39)
  store i32 %t43, ptr %l26
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t44)
  store %"compiler/source:Span" %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l19, !tbaa !29
  %t48 = load ptr, ptr %l20, !tbaa !29
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = load %"compiler/source:Span", ptr %l28
  %t51 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %t47, ptr %t48, i32 %t49, %"compiler/source:Span" %t50)
  store ptr %t51, ptr %l29
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l29, !tbaa !29
  store ptr %t52, ptr %l3, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = call i1 @compiler_2fcheck_2efreshValue(ptr %v2, ptr %t53)
  store i1 %t55, ptr %l31
  br label %bb13
bb13:
  %t56 = load i1, ptr %l31, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  br label %bb16
bb15:
  %t59 = load ptr, ptr %l3, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load ptr, ptr %l32, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushPayload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l36 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca %"compiler/diagmsg:Msg"
  %l47 = alloca i64
  %l51 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %l65 = alloca i32
  %l71 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l88 = alloca %"compiler/diagmsg:Msg"
  %l89 = alloca i64
  %l92 = alloca [0 x ptr]
  %l93 = alloca { i64, ptr }
  %l97 = alloca i1
  %l103 = alloca { i64, ptr }
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l117 = alloca i1
  %l126 = alloca i1
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %l146 = alloca i1
  %l151 = alloca i1
  %l156 = alloca i1
  %l160 = alloca i32
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l168 = alloca i64
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l175 = alloca i32
  %l179 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l181 = alloca %"compiler/source:Span"
  %l182 = alloca i32
  %l186 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l196 = alloca i32
  %l199 = alloca ptr
  %l200 = alloca %"compiler/source:Span"
  %l206 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t446 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l20
  br label %bb1
bb1:
  %t11 = load i32, ptr %l20, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = load i64, ptr %l4, !tbaa !24
  %t21 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v0, ptr %t15, i32 %t16, i64 %t17)
  store { i64, ptr } %t21, ptr %l25
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t22, ptr %l7, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %t23, ptr %t24, i64 0)
  store %"compiler/source:Span" %t27, ptr %l28
  br label %bb3
bb3:
  %t28 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t28, ptr %l8
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t31 = load i64, ptr %l4, !tbaa !24
  %t35 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s0, ptr %t29, i32 %t30, i64 %t31)
  store { i64, ptr } %t35, ptr %l32
  br label %bb4
bb4:
  %t36 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t36, ptr %l9, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb5, label %bb6
bb5:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t47 = icmp eq i64 %t45, %t46
  %t48 = extractvalue { i64, ptr } %t43, 1
  %t49 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t50 = icmp eq ptr %t48, %t49
  %t51 = and i1 %t47, %t50
  store i1 %t51, ptr %l36, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb7
bb7:
  %t53 = load i1, ptr %l36, !tbaa !21
  br i1 %t53, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l39, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t55, ptr %l40
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l41, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fcheck_2efieldNames(ptr %v0, ptr %v0, ptr %s1, ptr %t57, { i64, ptr } %t58)
  store { i64, ptr } %t61, ptr %l44
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t62 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t65 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadWordBare(ptr %s0, ptr %s1, ptr %v0, { i64, ptr } %t63, { i64, ptr } %t62)
  store %"compiler/diagmsg:Msg" %t65, ptr %l46
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l40
  %t68 = load %"compiler/diagmsg:Msg", ptr %l46
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t66, %"compiler/source:Span" %t67, %"compiler/diagmsg:Msg" %t68)
  store i64 %t69, ptr %l47
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t74 = icmp eq i64 %t72, 0
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t80 = icmp eq i64 %t78, %t79
  %t81 = extractvalue { i64, ptr } %t76, 1
  %t82 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t83 = icmp eq ptr %t81, %t82
  %t84 = and i1 %t80, %t83
  %t86 = xor i1 %t84, true
  store i1 %t86, ptr %l51, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t88 = load i1, ptr %l51, !tbaa !21
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t90, ptr %l56
  %t91 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %s0, ptr %v0, { i64, ptr } %t91)
  store %"compiler/diagmsg:Msg" %t93, ptr %l58
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t94 = load ptr, ptr %l55, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l56
  %t96 = load %"compiler/diagmsg:Msg", ptr %l58
  %t97 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t94, %"compiler/source:Span" %t95, %"compiler/diagmsg:Msg" %t96)
  store i64 %t97, ptr %l59
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t98, { i64, ptr } %t99)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i32, ptr %l3, !tbaa !23
  %t109 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l65
  br label %bb23
bb23:
  %t110 = load i32, ptr %l65, !tbaa !23
  store i32 %t110, ptr %l10, !tbaa !23
  %t111 = load i32, ptr %l10, !tbaa !23
  %t112 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t115 = icmp eq i32 %t111, %t112
  br i1 %t115, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t121 = icmp eq i64 %t119, %t120
  %t122 = extractvalue { i64, ptr } %t117, 1
  %t123 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t124 = icmp eq ptr %t122, %t123
  %t125 = and i1 %t121, %t124
  br i1 %t125, label %bb27, label %bb28
bb27:
  %t127 = icmp sge i64 0, 0
  br i1 %t127, label %bb29, label %bb30
bb28:
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t129, ptr %l71, !tbaa !27
  br label %bb33
bb29:
  %t131 = icmp sle i64 0, 1152921504606846975
  br i1 %t131, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_97f728d69fa9714_fb4d660b7b54b10)
  unreachable
bb31:
  %t133 = mul i64 0, 8
  %t134 = insertvalue { i64, ptr } undef, i64 0, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t135, ptr %l71, !tbaa !27
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_97f728d69fa9714_fb4d660b7b54b10)
  unreachable
bb33:
  %t137 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t137, ptr %l11, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t146 = icmp ne i64 %t140, %t143
  br i1 %t146, label %bb34, label %bb35
bb34:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l81, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t149, ptr %l82
  %t150 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t160 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %s0, ptr %v0, { i64, ptr } %t150, i64 %t153, i64 %t156)
  store %"compiler/diagmsg:Msg" %t160, ptr %l88
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t161 = load ptr, ptr %l81, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l82
  %t163 = load %"compiler/diagmsg:Msg", ptr %l88
  %t164 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t161, %"compiler/source:Span" %t162, %"compiler/diagmsg:Msg" %t163)
  store i64 %t164, ptr %l89
  br label %bb37
bb37:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t165, { i64, ptr } %t166)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  store [0 x ptr] zeroinitializer, ptr %l92
  %t169 = mul i64 0, 8
  %t170 = insertvalue { i64, ptr } undef, i64 0, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t171, ptr %l93, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t173, ptr %l92, i64 %t174, i1 false)
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t175, ptr %lp12
  %t176 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t177 = load ptr, ptr %lp12
  store { i64, ptr } %t176, ptr %t177, !tbaa !27
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t182 = load i32, ptr %l6, !tbaa !23
  %t185 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %t181, i32 %t182)
  store i1 %t185, ptr %l97
  br label %bb40
bb40:
  %t186 = load i1, ptr %l97, !tbaa !21
  br i1 %t186, label %bb41, label %bb42
bb41:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l8
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t197 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraisedArgs(ptr %v0, ptr %s0, ptr %v0, ptr %v2, ptr %v0, ptr %t187, %"compiler/source:Span" %t188, { i64, ptr } %t189, { i64, ptr } %t190, { i64, ptr } %t191)
  store { i64, ptr } %t197, ptr %l103
  br label %bb43
bb42:
  br label %bb82
bb43:
  %t198 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t198, ptr %l11, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t207 = icmp ne i64 %t201, %t204
  br i1 %t207, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  br label %bb46
bb46:
  %t209 = load ptr, ptr %l2, !tbaa !29
  %t211 = getelementptr %"compiler/ast:Path", ptr %t209, i32 0, i32 0
  %t212 = load %"compiler/source:Span", ptr %t211
  store %"compiler/source:Span" %t212, ptr %l110
  store ptr %l110, ptr %l111, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t217 = load i32, ptr %l6, !tbaa !23
  %t220 = call %"compiler/source:Span" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedAt(ptr %v0, ptr %t216, i32 %t217)
  store %"compiler/source:Span" %t220, ptr %l115
  br label %bb47
bb47:
  %t221 = load ptr, ptr %l111, !tbaa !29
  %t223 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t221, ptr %l115)
  store i1 %t223, ptr %l117
  br label %bb48
bb48:
  %t224 = load i1, ptr %l117, !tbaa !21
  store i1 %t224, ptr %l13, !tbaa !21
  %t225 = load i1, ptr %l13, !tbaa !21
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb49, label %bb50
bb49:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i32, ptr %l3, !tbaa !23
  %t231 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleRaised(ptr %v0, ptr %t229, i32 %t230, i32 %t231)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t239 = load i32, ptr %l10, !tbaa !23
  %t242 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedSettled(ptr %v0, ptr %t238, i32 %t239)
  store i1 %t242, ptr %l126
  br label %bb53
bb53:
  %t243 = load i1, ptr %l126, !tbaa !21
  %t244 = xor i1 %t243, true
  br i1 %t244, label %bb54, label %bb55
bb54:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i32, ptr %l10, !tbaa !23
  %t248 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t254 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleBy(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t246, i32 %t247, { i64, ptr } %t248, { i64, ptr } %t249)
  store { i64, ptr } %t254, ptr %l132
  br label %bb56
bb55:
  %t255 = load i1, ptr %l13, !tbaa !21
  br i1 %t255, label %bb64, label %bb65
bb56:
  %t257 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t257, ptr %l133, !tbaa !27
  %t258 = load ptr, ptr %lp12
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  %t261 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  store i64 %t262, ptr %l135, !tbaa !24
  %t264 = load i64, ptr %l135, !tbaa !24
  %t265 = icmp eq i64 %t260, %t264
  br i1 %t265, label %bb57, label %bb58
bb57:
  %t267 = load ptr, ptr %lp12
  %t268 = getelementptr { i64, ptr }, ptr %t267, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = load i64, ptr %l135, !tbaa !24
  %t273 = mul i64 %t272, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t269, ptr %t271, i64 %t273, i1 false)
  br label %bb59
bb58:
  %t274 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l137, !tbaa !24
  %t276 = load i64, ptr %l137, !tbaa !24
  %t277 = mul i64 %t276, 8
  %t278 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t277)
  %t279 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  store { i64, ptr } %t280, ptr %l138, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = load i64, ptr %l137, !tbaa !24
  %t286 = mul i64 %t285, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t282, ptr %t284, i64 %t286, i1 false)
  %t287 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t288 = load ptr, ptr %lp12
  store { i64, ptr } %t287, ptr %t288, !tbaa !27
  br label %bb59
bb59:
  %t289 = load i1, ptr %l13, !tbaa !21
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb60, label %bb61
bb60:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 79
  %t296 = load i32, ptr %l6, !tbaa !23
  %t298 = sext i32 %t296 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t295, i64 %t298, i1 true)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb81
bb64:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 79
  %t304 = load i32, ptr %l6, !tbaa !23
  %t306 = sext i32 %t304 to i64
  %t309 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t303, i64 %t306)
  store i1 %t309, ptr %l151
  br label %bb66
bb65:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb67
bb66:
  %t310 = load i1, ptr %l151, !tbaa !21
  store i1 %t310, ptr %l146, !tbaa !21
  br label %bb67
bb67:
  %t311 = load i1, ptr %l146, !tbaa !21
  br i1 %t311, label %bb68, label %bb69
bb68:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t312, i32 0, i32 79
  %t315 = load i32, ptr %l6, !tbaa !23
  %t317 = sext i32 %t315 to i64
  %t320 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %t314, i64 %t317)
  store i1 %t320, ptr %l156
  br label %bb70
bb69:
  br label %bb80
bb70:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/check:Checker", ptr %t321, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t325 = load i32, ptr %l10, !tbaa !23
  %t328 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedFields(ptr %v0, ptr %t324, i32 %t325)
  store i32 %t328, ptr %l160
  br label %bb71
bb71:
  %t329 = load i32, ptr %l160, !tbaa !23
  store i32 %t329, ptr %l14, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i32, ptr %l10, !tbaa !23
  %t332 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t338 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleBy(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t330, i32 %t331, { i64, ptr } %t332, { i64, ptr } %t333)
  store { i64, ptr } %t338, ptr %l165
  br label %bb72
bb72:
  %t339 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t339, ptr %l166, !tbaa !27
  %t340 = load ptr, ptr %lp12
  %t341 = load { i64, ptr }, ptr %t340, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 0
  %t343 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  store i64 %t344, ptr %l168, !tbaa !24
  %t346 = load i64, ptr %l168, !tbaa !24
  %t347 = icmp eq i64 %t342, %t346
  br i1 %t347, label %bb73, label %bb74
bb73:
  %t349 = load ptr, ptr %lp12
  %t350 = getelementptr { i64, ptr }, ptr %t349, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = load i64, ptr %l168, !tbaa !24
  %t355 = mul i64 %t354, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t351, ptr %t353, i64 %t355, i1 false)
  br label %bb75
bb74:
  %t356 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t356, 0
  store i64 %t357, ptr %l170, !tbaa !24
  %t358 = load i64, ptr %l170, !tbaa !24
  %t359 = mul i64 %t358, 8
  %t360 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t359)
  %t361 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  store { i64, ptr } %t362, ptr %l171, !tbaa !27
  %t363 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = load i64, ptr %l170, !tbaa !24
  %t368 = mul i64 %t367, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t364, ptr %t366, i64 %t368, i1 false)
  %t369 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t370 = load ptr, ptr %lp12
  store { i64, ptr } %t369, ptr %t370, !tbaa !27
  br label %bb75
bb75:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t371, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t375 = load i32, ptr %l10, !tbaa !23
  %t378 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedFields(ptr %v0, ptr %t374, i32 %t375)
  store i32 %t378, ptr %l175
  br label %bb76
bb76:
  %t379 = load i32, ptr %l14, !tbaa !23
  %t380 = load i32, ptr %l175, !tbaa !23
  %t382 = icmp ne i32 %t380, %t379
  br i1 %t382, label %bb77, label %bb78
bb77:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/check:Checker", ptr %t384, i32 0, i32 80
  store i1 true, ptr %t386, !tbaa !21
  br label %bb79
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l179, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t388, ptr %l180
  %t389 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t389, ptr %l181
  %t390 = load i32, ptr %l10, !tbaa !23
  store i32 %t390, ptr %l182, !tbaa !23
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/check:Checker", ptr %t391, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !29
  %t395 = load i32, ptr %l6, !tbaa !23
  %t398 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t394, i32 %t395)
  store { i64, ptr } %t398, ptr %l186
  br label %bb83
bb83:
  %t399 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t399, ptr %l187, !tbaa !27
  %t400 = load i64, ptr %l4, !tbaa !24
  %t402 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr i32, ptr %t403, i64 %t400
  %t405 = load i32, ptr %t404, !tbaa !33
  %t406 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t406, ptr %l190, !tbaa !27
  %t407 = load ptr, ptr %lp12
  %t408 = load { i64, ptr }, ptr %t407, !tbaa !27
  %t409 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t409, 1
  %t411 = call ptr @__olang_scope_of(ptr %t410, ptr null)
  %t412 = call ptr @__olang_scope_hold(ptr %t411)
  %t413 = ptrtoint ptr %t412 to i64
  %t415 = inttoptr i64 %t413 to ptr
  %t416 = load ptr, ptr %l179, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l180
  %t418 = load %"compiler/source:Span", ptr %l181
  %t419 = load i32, ptr %l182, !tbaa !23
  %t421 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %t415, ptr %v0, ptr %v0, ptr %t416, %"compiler/source:Span" %t417, %"compiler/source:Span" %t418, i32 %t419, i32 %t405, { i64, ptr } %t421, { i64, ptr } %t408)
  store ptr %t423, ptr %l193
  br label %bb84
bb84:
  %t424 = load ptr, ptr %l193, !tbaa !29
  store ptr %t424, ptr %l15, !tbaa !29
  %t425 = load ptr, ptr %l15, !tbaa !29
  %t428 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t425)
  store i32 %t428, ptr %l196
  br label %bb85
bb85:
  %t429 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t430 = load i32, ptr %l196, !tbaa !23
  %t432 = icmp eq i32 %t430, %t429
  br i1 %t432, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb87:
  br label %bb88
bb88:
  %t434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t434, ptr %l199, !tbaa !29
  %t435 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t435, ptr %l200
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load %"compiler/source:Span", ptr %l1
  %t438 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t439 = load ptr, ptr %l15, !tbaa !29
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t436, %"compiler/source:Span" %t437, i32 %t438, i32 47, ptr %t439, ptr null)
  store ptr %t445, ptr %l206
  br label %bb89
bb89:
  store { i64, [3 x i64] } zeroinitializer, ptr %t446
  %t447 = getelementptr { i64, [3 x i64] }, ptr %t446, i32 0, i32 0
  store i64 2, ptr %t447
  %t448 = load %"compiler/source:Span", ptr %l200
  %t449 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t448, 0
  %t450 = load ptr, ptr %l206, !tbaa !29
  %t451 = insertvalue { %"compiler/source:Span", ptr } %t449, ptr %t450, 1
  %t452 = getelementptr { i64, [3 x i64] }, ptr %t446, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t451, ptr %t452
  %t453 = load { i64, [3 x i64] }, ptr %t446
  %t455 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t453, ptr %t455
  %t456 = load ptr, ptr %l199, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t456, ptr %t455)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraisedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i64
  %l73 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb37
bb4:
  br label %bb5
bb5:
  %t19 = load i64, ptr %l7, !tbaa !24
  store i64 %t19, ptr %l9, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t21, ptr %l25, !tbaa !27
  %t22 = load i64, ptr %l7, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l10, !tbaa !29
  store i32 0, ptr %l11, !tbaa !23
  %t29 = load ptr, ptr %l10, !tbaa !29
  store ptr %t29, ptr %l12, !tbaa !29
  %t31 = load ptr, ptr %l10, !tbaa !29
  store ptr %t31, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t32 = load ptr, ptr %l29, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l29, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 28}
  %t38 = icmp eq i64 %t36, 24
  store i1 %t38, ptr %l30, !tbaa !21
  br label %bb7
bb7:
  %t39 = load i1, ptr %l30, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load ptr, ptr %l10, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l13, !tbaa !23
  %t46 = load ptr, ptr %l10, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l14, !tbaa !29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t52 = load i32, ptr %l13, !tbaa !23
  store i32 %t52, ptr %l11, !tbaa !23
  %t54 = load ptr, ptr %l14, !tbaa !29
  store ptr %t54, ptr %l12, !tbaa !29
  br label %bb22
bb11:
  %t56 = load ptr, ptr %l10, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t57 = load ptr, ptr %l39, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 28}
  %t63 = icmp eq i64 %t61, 0
  store i1 %t63, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t64 = load i1, ptr %l40, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t65 = load ptr, ptr %l10, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32 }, ptr %t67, i32 0, i32 1
  %t69 = load i32, ptr %t68
  store i32 %t69, ptr %l15, !tbaa !23
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t71 = load i32, ptr %l15, !tbaa !23
  store i32 %t71, ptr %l11, !tbaa !23
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_761ecce271a1def0_6ef2889dc9577e64)
  unreachable
bb22:
  %t73 = load i32, ptr %l11, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t74, ptr %l47, !tbaa !27
  %t75 = load i64, ptr %l9, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  %t82 = getelementptr %"compiler/ast:Param", ptr %t80, i32 0, i32 1
  %t83 = load i32, ptr %t82, !tbaa !23
  %t86 = icmp ne i32 %t73, %t83
  br i1 %t86, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load ptr, ptr %l10, !tbaa !29
  %t91 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t89)
  store %"compiler/source:Span" %t91, ptr %l54
  br label %bb25
bb24:
  br label %bb34
bb25:
  store { i64, ptr } %a2, ptr %l55, !tbaa !27
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = call { i64, ptr } @compiler_2fcheck_2efieldNames(ptr %v0, ptr %v2, ptr %s6, ptr %t93, { i64, ptr } %t94)
  store { i64, ptr } %t97, ptr %l58
  br label %bb26
bb26:
  %t98 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t101 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaisedFieldsDiffer(ptr %v1, ptr %s6, ptr %v0, { i64, ptr } %t99, { i64, ptr } %t98)
  store %"compiler/diagmsg:Msg" %t101, ptr %l60
  br label %bb27
bb27:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l54
  %t104 = load %"compiler/diagmsg:Msg", ptr %l60
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t102, %"compiler/source:Span" %t103, %"compiler/diagmsg:Msg" %t104)
  store i64 %t105, ptr %l61
  br label %bb28
bb28:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t106, { i64, ptr } %t107)
  br label %bb29
bb29:
  %t110 = icmp sge i64 0, 0
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t112 = icmp sle i64 0, 1152921504606846975
  br i1 %t112, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_a7c6fed1dc036a32_295e341353c4274e)
  unreachable
bb32:
  %t114 = mul i64 0, 8
  %t115 = insertvalue { i64, ptr } undef, i64 0, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s6)
  store { i64, ptr } %t116, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a7c6fed1dc036a32_295e341353c4274e)
  unreachable
bb34:
  %t118 = load ptr, ptr %lp5
  %t119 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v3, ptr %t118, ptr %t119)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t125 = add i64 %t122, 1
  store i64 %t125, ptr %l7, !tbaa !24
  br label %bb2
bb37:
  %t127 = load ptr, ptr %lp5
  %t129 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t127)
  store { i64, ptr } %t129, ptr %l73
  br label %bb38
bb38:
  %t130 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t130, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawEnum(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i1
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i64
  %lp13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/check:litv"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca %"compiler/check:litv"
  %l33 = alloca %"compiler/check:signMag"
  %l34 = alloca i1
  %l35 = alloca i128
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i32
  %l43 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l53 = alloca %"compiler/check:rawTable"
  %l56 = alloca i1
  %l59 = alloca i1
  %l69 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca %"compiler/diagmsg:Msg"
  %l84 = alloca i64
  %l91 = alloca i32
  %l93 = alloca i32
  %l95 = alloca ptr
  %l99 = alloca %"compiler/generic:Context"
  %l103 = alloca i32
  %l110 = alloca ptr
  %l111 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i1
  %l117 = alloca i1
  %l120 = alloca i1
  %l123 = alloca i1
  %l127 = alloca ptr
  %l129 = alloca %"compiler/source:Span"
  %l132 = alloca { i64, ptr }
  %l134 = alloca %"compiler/diagmsg:Msg"
  %l135 = alloca i64
  %l139 = alloca i64
  %l143 = alloca i64
  %l145 = alloca { i64, ptr }
  %l149 = alloca i64
  %l152 = alloca %"compiler/check:litv"
  %l157 = alloca i64
  %l160 = alloca i64
  %l178 = alloca { i64, ptr }
  %l182 = alloca i1
  %l186 = alloca { i64, ptr }
  %l187 = alloca i1
  %l188 = alloca ptr
  %l191 = alloca %"compiler/source:Span"
  %l192 = alloca %"compiler/diagmsg:Msg"
  %l193 = alloca i64
  %l197 = alloca %"compiler/source:Span"
  %l200 = alloca %"compiler/source:Span"
  %l206 = alloca %"compiler/source:Span"
  %l211 = alloca i64
  %l212 = alloca i64
  %l217 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca ptr
  %l227 = alloca %"compiler/source:Span"
  %l228 = alloca i32
  %l230 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca %"compiler/source:Span"
  %l236 = alloca { i64, ptr }
  %l238 = alloca %"compiler/diagmsg:Msg"
  %l239 = alloca i64
  %l240 = alloca i64
  %l241 = alloca i64
  %l245 = alloca { i64, ptr }
  %l251 = alloca i64
  %l254 = alloca i64
  %l274 = alloca i1
  %l276 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l281 = alloca i1
  %l283 = alloca ptr
  %l284 = alloca %"compiler/source:Span"
  %l288 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l292 = alloca i64
  %l293 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l303 = alloca %"compiler/diagmsg:Msg"
  %l304 = alloca i64
  %l308 = alloca %"compiler/check:litv"
  %l313 = alloca %"compiler/check:signMag"
  %l317 = alloca %"compiler/check:litv"
  %l320 = alloca %"compiler/check:litv"
  %l321 = alloca %"compiler/check:litv"
  %l328 = alloca i1
  %l329 = alloca i1
  %l335 = alloca i1
  %l336 = alloca ptr
  %l342 = alloca %"compiler/check:litv"
  %l345 = alloca i1
  %l348 = alloca ptr
  %l349 = alloca %"compiler/source:Span"
  %l354 = alloca %"compiler/diagmsg:Msg"
  %l357 = alloca { i64, ptr }
  %l359 = alloca %"compiler/diagmsg:Msg"
  %l362 = alloca { i64, ptr }
  %l364 = alloca %"compiler/diagmsg:Msg"
  %l365 = alloca i64
  %l366 = alloca %"compiler/check:litv"
  %l371 = alloca i1
  %l374 = alloca ptr
  %l375 = alloca %"compiler/source:Span"
  %l377 = alloca { i64, ptr }
  %l378 = alloca { i64, ptr }
  %l381 = alloca { i64, ptr }
  %l383 = alloca %"compiler/diagmsg:Msg"
  %l384 = alloca i64
  %l392 = alloca i64
  %l395 = alloca i64
  %l415 = alloca i1
  %l422 = alloca ptr
  %l423 = alloca %"compiler/source:Span"
  %l427 = alloca { i64, ptr }
  %l429 = alloca { i64, ptr }
  %l430 = alloca { i64, ptr }
  %l432 = alloca { i64, ptr }
  %l436 = alloca { i64, ptr }
  %l437 = alloca %"compiler/diagmsg:Msg"
  %l438 = alloca i64
  %l449 = alloca %"compiler/check:rawTable"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca ptr
  %t127 = alloca %"compiler/generic:Context", align 8
  %t238 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1, ptr %l42, !tbaa !23
  %t2 = call ptr @__olang_scope_hold(ptr %v3)
  %t3 = ptrtoint ptr %t2 to i64
  store i64 %t3, ptr %l43, !tbaa !24
  %t4 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3arawTable_2e2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = call ptr @__olang_region_make(ptr %v3)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l43, !tbaa !24
  br label %bb2
bb2:
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t10 = icmp sle i64 0, 1152921504606846975
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ff4549fd04ada907_b78a4102fd7994db)
  unreachable
bb5:
  %t12 = mul i64 0, 8
  %t13 = load i64, ptr %l43
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t16, ptr %l47, !tbaa !27
  %t17 = call ptr @__olang_scope_hold(ptr %v3)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l48, !tbaa !24
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3arawTable_2e3
  br i1 %t19, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_ff4549fd04ada907_b78a4102fd7994db)
  unreachable
bb7:
  %t21 = call ptr @__olang_region_make(ptr %v3)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l48, !tbaa !24
  br label %bb8
bb8:
  %t23 = icmp sge i64 0, 0
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = icmp sle i64 0, 576460752303423487
  br i1 %t25, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ff4549fd04ada907_b78a4102fd7994db)
  unreachable
bb11:
  %t27 = mul i64 0, 16
  %t28 = load i64, ptr %l48
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = insertvalue { i64, ptr } undef, i64 0, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t32 = load i32, ptr %l42, !tbaa !23
  %t33 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t35 = call %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t32, i1 false, { i64, ptr } %t33, { i64, ptr } %t31)
  store %"compiler/check:rawTable" %t35, ptr %l53
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ff4549fd04ada907_b78a4102fd7994db)
  unreachable
bb13:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t36, ptr %lp5
  %t37 = load %"compiler/check:rawTable", ptr %l53
  %t38 = load ptr, ptr %lp5
  store %"compiler/check:rawTable" %t37, ptr %t38
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValued(ptr %v0, ptr %v1, ptr %t43, { i64, ptr } %t44)
  store i1 %t47, ptr %l59
  br label %bb16
bb15:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb17
bb16:
  %t48 = load i1, ptr %l59, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l56, !tbaa !21
  br label %bb17
bb17:
  %t51 = load i1, ptr %l56, !tbaa !21
  br i1 %t51, label %bb18, label %bb19
bb18:
  %t52 = load i1, ptr %l4, !tbaa !21
  br i1 %t52, label %bb20, label %bb21
bb19:
  br label %bb38
bb20:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l8, !tbaa !24
  br label %bb22
bb21:
  br label %bb37
bb22:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb23, label %bb24
bb23:
  br label %bb36
bb24:
  br label %bb25
bb25:
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t68, ptr %l69, !tbaa !27
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  store ptr %t74, ptr %l9, !tbaa !29
  %t76 = load ptr, ptr %l9, !tbaa !29
  %t78 = getelementptr %"compiler/ast:CaseDecl", ptr %t76, i32 0, i32 4
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l76, !tbaa !29
  %t86 = load ptr, ptr %l9, !tbaa !29
  %t88 = getelementptr %"compiler/ast:CaseDecl", ptr %t86, i32 0, i32 4
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb28, label %bb29
bb27:
  br label %bb34
bb28:
  call void @__olang_check_failed(ptr @olang_loc_674ca34a4d5f8d72_a138681dd06a86e)
  unreachable
bb29:
  br label %bb30
bb30:
  %t93 = load ptr, ptr %l9, !tbaa !29
  %t95 = getelementptr %"compiler/ast:CaseDecl", ptr %t93, i32 0, i32 4
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t96)
  store %"compiler/source:Span" %t98, ptr %l82
  br label %bb31
bb31:
  %t99 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawWithoutType(ptr %v0)
  store %"compiler/diagmsg:Msg" %t99, ptr %l83
  br label %bb32
bb32:
  %t100 = load ptr, ptr %l76, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l82
  %t102 = load %"compiler/diagmsg:Msg", ptr %l83
  %t103 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t100, %"compiler/source:Span" %t101, %"compiler/diagmsg:Msg" %t102)
  store i64 %t103, ptr %l84
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb22
bb36:
  br label %bb37
bb37:
  %t109 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s0)
  store ptr %t109, ptr %rv
  br label %ret
bb38:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb39, label %bb40
bb39:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t115)
  store i32 %t117, ptr %l93
  br label %bb41
bb40:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  store ptr %t121, ptr %l95, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t127, ptr %v0, ptr %s0, ptr %t125, i32 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l99, ptr %t127, i64 160, i1 false)
  br label %bb42
bb41:
  %t130 = load i32, ptr %l93, !tbaa !23
  store i32 %t130, ptr %l91, !tbaa !23
  br label %bb44
bb42:
  %t131 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %l99, i64 160, i1 false)
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t134 = load ptr, ptr %l95, !tbaa !29
  %t137 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s0, ptr %v2, ptr %t134, ptr %t131, ptr %t132)
  store i32 %t137, ptr %l103
  br label %bb43
bb43:
  %t138 = load i32, ptr %l103, !tbaa !23
  store i32 %t138, ptr %l91, !tbaa !23
  br label %bb44
bb44:
  %t139 = load i32, ptr %l91, !tbaa !23
  store i32 %t139, ptr %l10, !tbaa !23
  %t140 = load i32, ptr %l10, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  br i1 %t144, label %bb45, label %bb46
bb45:
  %t146 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s0)
  store ptr %t146, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  store ptr %t153, ptr %l110, !tbaa !29
  %t154 = load i32, ptr %l10, !tbaa !23
  store i32 %t154, ptr %l111, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t155)
  store i32 %t157, ptr %l113
  br label %bb48
bb48:
  %t158 = load ptr, ptr %l110, !tbaa !29
  %t159 = load i32, ptr %l111, !tbaa !23
  %t160 = load i32, ptr %l113, !tbaa !23
  %t161 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t158, i32 %t159, i32 %t160)
  store i1 %t161, ptr %l114
  br label %bb49
bb49:
  %t162 = load i1, ptr %l114, !tbaa !21
  store i1 %t162, ptr %l11, !tbaa !21
  %t163 = load i1, ptr %l11, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb50, label %bb51
bb50:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l10, !tbaa !23
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t167, i32 %t168)
  store i1 %t171, ptr %l120
  br label %bb52
bb51:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb53
bb52:
  %t172 = load i1, ptr %l120, !tbaa !21
  %t173 = xor i1 %t172, true
  store i1 %t173, ptr %l117, !tbaa !21
  br label %bb53
bb53:
  %t175 = load i1, ptr %l117, !tbaa !21
  br i1 %t175, label %bb54, label %bb55
bb54:
  %t176 = load i1, ptr %l4, !tbaa !21
  br i1 %t176, label %bb56, label %bb57
bb55:
  br label %bb66
bb56:
  %t178 = load ptr, ptr %l3, !tbaa !29
  %t180 = icmp eq ptr %t178, null
  %t182 = xor i1 %t180, true
  store i1 %t182, ptr %l123, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb58
bb58:
  %t184 = load i1, ptr %l123, !tbaa !21
  br i1 %t184, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s9
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l127, !tbaa !29
  %t186 = load ptr, ptr %l3, !tbaa !29
  %t188 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t186)
  store %"compiler/source:Span" %t188, ptr %l129
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l10, !tbaa !23
  %t193 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t189, i32 %t190)
  store { i64, ptr } %t193, ptr %l132
  br label %bb62
bb62:
  %t194 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t196 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawType(ptr %s9, ptr %v0, { i64, ptr } %t194)
  store %"compiler/diagmsg:Msg" %t196, ptr %l134
  br label %bb63
bb63:
  %t197 = load ptr, ptr %l127, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l129
  %t199 = load %"compiler/diagmsg:Msg", ptr %l134
  %t200 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t197, %"compiler/source:Span" %t198, %"compiler/diagmsg:Msg" %t199)
  store i64 %t200, ptr %l135
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  %t201 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s0)
  store ptr %t201, ptr %rv
  br label %ret
bb66:
  %t203 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  store i64 %t205, ptr %l12, !tbaa !24
  %t207 = load i64, ptr %l12, !tbaa !24
  store i64 %t207, ptr %l139, !tbaa !24
  %t208 = load i64, ptr %l139, !tbaa !24
  %t209 = icmp sge i64 %t208, 0
  br i1 %t209, label %bb67, label %bb68
bb67:
  %t211 = load i64, ptr %l139, !tbaa !24
  %t212 = icmp sle i64 %t211, 1152921504606846975
  br i1 %t212, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_5479af00bceefeb1_f5b0eb753f441165)
  unreachable
bb69:
  %t214 = load i64, ptr %l139, !tbaa !24
  %t215 = mul i64 %t214, 8
  %t216 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t215)
  %t217 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t219 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t219, ptr %lp13
  %t221 = load ptr, ptr %lp13
  store { i64, ptr } %t218, ptr %t221, !tbaa !27
  %t222 = load i64, ptr %l12, !tbaa !24
  store i64 %t222, ptr %l143, !tbaa !24
  %t223 = icmp sge i64 0, 0
  br i1 %t223, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_5479af00bceefeb1_f5b0eb753f441165)
  unreachable
bb71:
  %t225 = mul i64 0, 1
  %t226 = insertvalue { i64, ptr } undef, i64 0, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t227, ptr %l145, !tbaa !27
  %t228 = load i64, ptr %l143, !tbaa !24
  %t229 = icmp sge i64 %t228, 0
  br i1 %t229, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_4e17f4aa3948dea4_42025b20baf190f8)
  unreachable
bb73:
  %t231 = load i64, ptr %l143, !tbaa !24
  %t232 = icmp sle i64 %t231, 576460752303423487
  br i1 %t232, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_4e17f4aa3948dea4_42025b20baf190f8)
  unreachable
bb75:
  %t234 = load i64, ptr %l143, !tbaa !24
  %t235 = mul i64 %t234, 16
  %t236 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t235)
  %t237 = load { i64, ptr }, ptr %l145, !tbaa !27
  store i64 0, ptr %t238
  br label %fill.239
fill.239:
  %t242 = load i64, ptr %t238
  %t243 = icmp slt i64 %t242, %t234
  br i1 %t243, label %fillb.240, label %filld.241
fillb.240:
  %t244 = getelementptr { i64, ptr }, ptr %t236, i64 %t242
  store { i64, ptr } %t237, ptr %t244
  %t245 = add i64 %t242, 1
  store i64 %t245, ptr %t238
  br label %fill.239
filld.241:
  %t246 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t236, 1
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t248, ptr %lp14
  %t250 = load ptr, ptr %lp14
  store { i64, ptr } %t247, ptr %t250, !tbaa !27
  %t251 = load i64, ptr %l12, !tbaa !24
  store i64 %t251, ptr %l149, !tbaa !24
  %t252 = load i64, ptr %l149, !tbaa !24
  %t253 = icmp sge i64 %t252, 0
  br i1 %t253, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_4e17f4aa3948dea4_42025b20baf190f8)
  unreachable
bb77:
  %t255 = load i64, ptr %l149, !tbaa !24
  %t256 = mul i64 %t255, 1
  %t257 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t256)
  %t258 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, ptr } %t259, ptr %l15, !tbaa !27
  %t261 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 -1)
  store %"compiler/check:litv" %t261, ptr %l152
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_15162faa0a6b8e7b_16d808b76471f267)
  unreachable
bb79:
  %t262 = load %"compiler/check:litv", ptr %l152
  store %"compiler/check:litv" %t262, ptr %l16
  store i64 0, ptr %l17, !tbaa !24
  %t263 = load i64, ptr %l12, !tbaa !24
  store i64 %t263, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t265 = load i64, ptr %l18, !tbaa !24
  %t266 = load i64, ptr %l17, !tbaa !24
  %t269 = icmp sgt i64 %t265, %t266
  br i1 %t269, label %bb80, label %bb81
bb80:
  %t271 = load i64, ptr %l19, !tbaa !24
  %t273 = icmp sgt i64 %t271, 0
  br i1 %t273, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l157, !tbaa !24
  br label %bb85
bb82:
  %t275 = load i64, ptr %l18, !tbaa !24
  %t276 = load i64, ptr %l17, !tbaa !24
  %t279 = sub i64 %t275, %t276
  %t280 = load i64, ptr %l19, !tbaa !24
  %t283 = add i64 %t279, %t280
  %t285 = sub i64 %t283, 1
  %t286 = load i64, ptr %l19, !tbaa !24
  %t289 = sdiv i64 %t285, %t286
  store i64 %t289, ptr %l160, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb84
bb84:
  %t291 = load i64, ptr %l160, !tbaa !24
  store i64 %t291, ptr %l157, !tbaa !24
  br label %bb85
bb85:
  %t292 = load i64, ptr %l157, !tbaa !24
  store i64 %t292, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s11
  %t293 = load i64, ptr %l21, !tbaa !24
  %t294 = load i64, ptr %l20, !tbaa !24
  %t297 = icmp slt i64 %t293, %t294
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s11)
  br label %bb245
bb88:
  br label %bb89
bb89:
  %t301 = load i64, ptr %l17, !tbaa !24
  %t302 = load i64, ptr %l21, !tbaa !24
  %t303 = load i64, ptr %l19, !tbaa !24
  %t306 = mul i64 %t302, %t303
  %t309 = add i64 %t301, %t306
  store i64 %t309, ptr %l22, !tbaa !24
  %t311 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t311, ptr %l178, !tbaa !27
  %t312 = load i64, ptr %l22, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr ptr, ptr %t315, i64 %t312
  %t317 = load ptr, ptr %t316, !tbaa !39
  store ptr %t317, ptr %l23, !tbaa !29
  %t319 = load i1, ptr %l4, !tbaa !21
  br i1 %t319, label %bb90, label %bb91
bb90:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l23, !tbaa !29
  %t324 = getelementptr %"compiler/ast:CaseDecl", ptr %t322, i32 0, i32 1
  %t325 = load i32, ptr %t324, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t321, i32 %t325)
  store { i64, ptr } %t328, ptr %l186
  br label %bb92
bb91:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb94
bb92:
  %t329 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t330 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t329, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t330, ptr %l187
  br label %bb93
bb93:
  %t331 = load i1, ptr %l187, !tbaa !21
  store i1 %t331, ptr %l182, !tbaa !21
  br label %bb94
bb94:
  %t332 = load i1, ptr %l182, !tbaa !21
  br i1 %t332, label %bb95, label %bb96
bb95:
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l188, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l23, !tbaa !29
  %t338 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %t334, ptr %t335)
  store %"compiler/source:Span" %t338, ptr %l191
  br label %bb97
bb96:
  br label %bb100
bb97:
  %t339 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFromCaseName(ptr %v0)
  store %"compiler/diagmsg:Msg" %t339, ptr %l192
  br label %bb98
bb98:
  %t340 = load ptr, ptr %l188, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l191
  %t342 = load %"compiler/diagmsg:Msg", ptr %l192
  %t343 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t340, %"compiler/source:Span" %t341, %"compiler/diagmsg:Msg" %t342)
  store i64 %t343, ptr %l193
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t344 = load ptr, ptr %l23, !tbaa !29
  %t346 = getelementptr %"compiler/ast:CaseDecl", ptr %t344, i32 0, i32 4
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t349 = icmp eq ptr %t347, null
  br i1 %t349, label %bb101, label %bb102
bb101:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load ptr, ptr %l23, !tbaa !29
  %t355 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %t351, ptr %t352)
  store %"compiler/source:Span" %t355, ptr %l200
  br label %bb103
bb102:
  %t356 = load ptr, ptr %l23, !tbaa !29
  %t358 = getelementptr %"compiler/ast:CaseDecl", ptr %t356, i32 0, i32 4
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = icmp eq ptr %t359, null
  br i1 %t361, label %bb104, label %bb105
bb103:
  %t363 = load %"compiler/source:Span", ptr %l200
  store %"compiler/source:Span" %t363, ptr %l197
  br label %bb108
bb104:
  call void @__olang_check_failed(ptr @olang_loc_c9b25feecc9d128e_1218ffeebcd03452)
  unreachable
bb105:
  br label %bb106
bb106:
  %t364 = load ptr, ptr %l23, !tbaa !29
  %t366 = getelementptr %"compiler/ast:CaseDecl", ptr %t364, i32 0, i32 4
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t369 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t367)
  store %"compiler/source:Span" %t369, ptr %l206
  br label %bb107
bb107:
  %t370 = load %"compiler/source:Span", ptr %l206
  store %"compiler/source:Span" %t370, ptr %l197
  br label %bb108
bb108:
  %t371 = load %"compiler/source:Span", ptr %l197
  store %"compiler/source:Span" %t371, ptr %l24
  %t372 = load i1, ptr %l11, !tbaa !21
  br i1 %t372, label %bb109, label %bb110
bb109:
  %t374 = load ptr, ptr %l23, !tbaa !29
  %t376 = getelementptr %"compiler/ast:CaseDecl", ptr %t374, i32 0, i32 4
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = icmp eq ptr %t377, null
  br i1 %t379, label %bb111, label %bb112
bb110:
  br label %bb160
bb111:
  %t381 = load i64, ptr %l22, !tbaa !24
  store i64 %t381, ptr %l211, !tbaa !24
  %t382 = call ptr @__olang_scope_hold(ptr %v3)
  %t383 = ptrtoint ptr %t382 to i64
  store i64 %t383, ptr %l212, !tbaa !24
  %t384 = load i1, ptr @olang_2esole_2eArray_3cArray_3cU8_3e_26_3e_2e_2d1
  br i1 %t384, label %bb113, label %bb114
bb112:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l221, !tbaa !29
  %t387 = load ptr, ptr %l23, !tbaa !29
  %t389 = getelementptr %"compiler/ast:CaseDecl", ptr %t387, i32 0, i32 4
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = icmp eq ptr %t390, null
  br i1 %t392, label %bb117, label %bb118
bb113:
  %t394 = call ptr @__olang_region_make(ptr %v3)
  %t395 = ptrtoint ptr %t394 to i64
  store i64 %t395, ptr %l212, !tbaa !24
  br label %bb114
bb114:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l23, !tbaa !29
  %t399 = getelementptr %"compiler/ast:CaseDecl", ptr %t397, i32 0, i32 1
  %t400 = load i32, ptr %t399, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t396, i32 %t400)
  store { i64, ptr } %t403, ptr %l217
  br label %bb115
bb115:
  %t404 = load i64, ptr %l212
  %t405 = inttoptr i64 %t404 to ptr
  %t406 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t407 = call { i64, ptr } @compiler_2fcheck_2etextBytes(ptr %v0, ptr %t405, { i64, ptr } %t406)
  store { i64, ptr } %t407, ptr %l218
  br label %bb116
bb116:
  %t408 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t410 = load ptr, ptr %lp14
  %t411 = load i64, ptr %l211, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %t410, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr { i64, ptr }, ptr %t413, i64 %t411
  store { i64, ptr } %t408, ptr %t414, !tbaa !37
  br label %bb133
bb117:
  call void @__olang_check_failed(ptr @olang_loc_7a0bf9c228cd53f_3b674c8d006cd93)
  unreachable
bb118:
  br label %bb119
bb119:
  %t415 = load ptr, ptr %l23, !tbaa !29
  %t417 = getelementptr %"compiler/ast:CaseDecl", ptr %t415, i32 0, i32 4
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t419 = load ptr, ptr %l221, !tbaa !29
  %t421 = call { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %t419, ptr %t418)
  %t422 = extractvalue { i32, %"compiler/source:Span" } %t421, 1
  %t423 = extractvalue { i32, %"compiler/source:Span" } %t421, 0
  store i32 %t423, ptr %l228
  %t424 = icmp ne i32 %t423, 0
  br i1 %t424, label %bb121, label %ok.425, !prof !99
ok.425:
  store %"compiler/source:Span" %t422, ptr %l227
  br label %bb120
bb120:
  %t426 = load %"compiler/source:Span", ptr %l227
  store %"compiler/source:Span" %t426, ptr %l220
  br label %bb129
bb121:
  %t427 = load i32, ptr %l228, !tbaa !23
  %t428 = ashr i32 %t427, 16
  %t430 = icmp eq i32 %t428, 1
  store i1 %t430, ptr %l230, !tbaa !21
  br label %bb122
bb122:
  %t431 = load i1, ptr %l4, !tbaa !21
  br i1 %t431, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s17
  %t433 = load ptr, ptr %l0, !tbaa !29
  store ptr %t433, ptr %l232, !tbaa !29
  %t434 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t434, ptr %l233
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load i32, ptr %l10, !tbaa !23
  %t439 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t435, i32 %t436)
  store { i64, ptr } %t439, ptr %l236
  br label %bb125
bb124:
  br label %bb128
bb125:
  %t440 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t442 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNotLiteral(ptr %s17, ptr %v0, { i64, ptr } %t440)
  store %"compiler/diagmsg:Msg" %t442, ptr %l238
  br label %bb126
bb126:
  %t443 = load ptr, ptr %l232, !tbaa !29
  %t444 = load %"compiler/source:Span", ptr %l233
  %t445 = load %"compiler/diagmsg:Msg", ptr %l238
  %t446 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t443, %"compiler/source:Span" %t444, %"compiler/diagmsg:Msg" %t445)
  store i64 %t446, ptr %l239
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s17)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s11)
  br label %bb244
bb129:
  %t447 = load %"compiler/source:Span", ptr %l220
  store %"compiler/source:Span" %t447, ptr %l25
  %t448 = load i64, ptr %l22, !tbaa !24
  store i64 %t448, ptr %l240, !tbaa !24
  %t449 = call ptr @__olang_scope_hold(ptr %v3)
  %t450 = ptrtoint ptr %t449 to i64
  store i64 %t450, ptr %l241, !tbaa !24
  %t451 = load i1, ptr @olang_2esole_2eArray_3cArray_3cU8_3e_26_3e_2e_2d1
  br i1 %t451, label %bb130, label %bb131
bb130:
  %t453 = call ptr @__olang_region_make(ptr %v3)
  %t454 = ptrtoint ptr %t453 to i64
  store i64 %t454, ptr %l241, !tbaa !24
  br label %bb131
bb131:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load %"compiler/source:Span", ptr %l25
  %t457 = load i64, ptr %l241
  %t458 = inttoptr i64 %t457 to ptr
  %t461 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %t458, ptr %t455, %"compiler/source:Span" %t456)
  store { i64, ptr } %t461, ptr %l245
  br label %bb132
bb132:
  %t462 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t463 = load ptr, ptr %lp14
  %t464 = load i64, ptr %l240, !tbaa !24
  %t465 = getelementptr { i64, ptr }, ptr %t463, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr { i64, ptr }, ptr %t466, i64 %t464
  store { i64, ptr } %t462, ptr %t467, !tbaa !37
  br label %bb133
bb133:
  %t468 = load i64, ptr %l22, !tbaa !24
  %t470 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !27
  %t472 = getelementptr i1, ptr %t471, i64 %t468
  store i1 true, ptr %t472, !tbaa !31
  store i64 0, ptr %l26, !tbaa !24
  %t473 = load i64, ptr %l22, !tbaa !24
  store i64 %t473, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t475 = load i64, ptr %l27, !tbaa !24
  %t476 = load i64, ptr %l26, !tbaa !24
  %t479 = icmp sgt i64 %t475, %t476
  br i1 %t479, label %bb134, label %bb135
bb134:
  %t481 = load i64, ptr %l28, !tbaa !24
  %t483 = icmp sgt i64 %t481, 0
  br i1 %t483, label %bb136, label %bb137
bb135:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb139
bb136:
  %t485 = load i64, ptr %l27, !tbaa !24
  %t486 = load i64, ptr %l26, !tbaa !24
  %t489 = sub i64 %t485, %t486
  %t490 = load i64, ptr %l28, !tbaa !24
  %t493 = add i64 %t489, %t490
  %t495 = sub i64 %t493, 1
  %t496 = load i64, ptr %l28, !tbaa !24
  %t499 = sdiv i64 %t495, %t496
  store i64 %t499, ptr %l254, !tbaa !24
  br label %bb138
bb137:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb138
bb138:
  %t501 = load i64, ptr %l254, !tbaa !24
  store i64 %t501, ptr %l251, !tbaa !24
  br label %bb139
bb139:
  %t502 = load i64, ptr %l251, !tbaa !24
  store i64 %t502, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb140
bb140:
  %t503 = load i64, ptr %l30, !tbaa !24
  %t504 = load i64, ptr %l29, !tbaa !24
  %t507 = icmp slt i64 %t503, %t504
  %t509 = xor i1 %t507, true
  br i1 %t509, label %bb141, label %bb142
bb141:
  br label %bb159
bb142:
  br label %bb143
bb143:
  %t511 = load i64, ptr %l26, !tbaa !24
  %t512 = load i64, ptr %l30, !tbaa !24
  %t513 = load i64, ptr %l28, !tbaa !24
  %t516 = mul i64 %t512, %t513
  %t519 = add i64 %t511, %t516
  store i64 %t519, ptr %l31, !tbaa !24
  %t521 = load i64, ptr %l31, !tbaa !24
  %t523 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !27
  %t525 = getelementptr i1, ptr %t524, i64 %t521
  %t526 = load i1, ptr %t525, !tbaa !31
  br i1 %t526, label %bb144, label %bb145
bb144:
  %t528 = load i64, ptr %l31, !tbaa !24
  %t529 = load ptr, ptr %lp14
  %t531 = getelementptr { i64, ptr }, ptr %t529, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr { i64, ptr }, ptr %t532, i64 %t528
  %t534 = load { i64, ptr }, ptr %t533, !tbaa !37
  store { i64, ptr } %t534, ptr %l276, !tbaa !27
  %t535 = load i64, ptr %l22, !tbaa !24
  %t536 = load ptr, ptr %lp14
  %t538 = getelementptr { i64, ptr }, ptr %t536, i32 0, i32 1
  %t539 = load ptr, ptr %t538, !tbaa !27
  %t540 = getelementptr { i64, ptr }, ptr %t539, i64 %t535
  %t541 = load { i64, ptr }, ptr %t540, !tbaa !37
  store { i64, ptr } %t541, ptr %l279, !tbaa !27
  %t544 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cU8_3e_26(ptr %l276, ptr %l279)
  store i1 %t544, ptr %l281
  br label %bb146
bb145:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb147
bb146:
  %t545 = load i1, ptr %l281, !tbaa !21
  store i1 %t545, ptr %l274, !tbaa !21
  br label %bb147
bb147:
  %t546 = load i1, ptr %l274, !tbaa !21
  br i1 %t546, label %bb148, label %bb149
bb148:
  %t547 = load i1, ptr %l4, !tbaa !21
  br i1 %t547, label %bb150, label %bb151
bb149:
  br label %bb157
bb150:
  store %olang.scope zeroinitializer, ptr %s21
  %t549 = load ptr, ptr %l0, !tbaa !29
  store ptr %t549, ptr %l283, !tbaa !29
  %t550 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t550, ptr %l284
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t552 = load ptr, ptr %l23, !tbaa !29
  %t554 = getelementptr %"compiler/ast:CaseDecl", ptr %t552, i32 0, i32 1
  %t555 = load i32, ptr %t554, !tbaa !23
  %t558 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t551, i32 %t555)
  store { i64, ptr } %t558, ptr %l288
  br label %bb152
bb151:
  br label %bb156
bb152:
  %t559 = load i64, ptr %l22, !tbaa !24
  %t560 = load ptr, ptr %lp14
  %t562 = getelementptr { i64, ptr }, ptr %t560, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr { i64, ptr }, ptr %t563, i64 %t559
  %t565 = load { i64, ptr }, ptr %t564, !tbaa !37
  store { i64, ptr } %t565, ptr %l291, !tbaa !27
  %t567 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 0
  store i64 %t568, ptr %l292, !tbaa !24
  %t569 = load i64, ptr %l292, !tbaa !24
  %t570 = mul i64 %t569, 1
  %t571 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t570)
  %t572 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  store { i64, ptr } %t573, ptr %l293, !tbaa !27
  %t574 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = load i64, ptr %l292, !tbaa !24
  %t579 = mul i64 %t578, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t575, ptr %t577, i64 %t579, i1 false)
  %t580 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t581 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t582 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t584 = extractvalue { i64, ptr } %t580, 1
  %t585 = extractvalue { i64, ptr } %t580, 0
  %t586 = add i64 %t582, %t585
  %t587 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t588 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t589 = add i64 %t586, %t588
  %t590 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t589)
  call void @olang_textcopy(ptr %t590, ptr %t581, i64 %t582)
  %t591 = getelementptr i8, ptr %t590, i64 %t582
  call void @olang_textcopy(ptr %t591, ptr %t584, i64 %t585)
  %t592 = getelementptr i8, ptr %t591, i64 %t585
  call void @olang_textcopy(ptr %t592, ptr %t587, i64 %t588)
  %t593 = insertvalue { i64, ptr } undef, i64 %t589, 0
  %t594 = insertvalue { i64, ptr } %t593, ptr %t590, 1
  store { i64, ptr } %t594, ptr %l296, !tbaa !27
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t597, ptr %l298, !tbaa !27
  %t598 = load i64, ptr %l31, !tbaa !24
  %t600 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t601 = load ptr, ptr %t600, !tbaa !27
  %t602 = getelementptr ptr, ptr %t601, i64 %t598
  %t603 = load ptr, ptr %t602, !tbaa !39
  %t605 = getelementptr %"compiler/ast:CaseDecl", ptr %t603, i32 0, i32 1
  %t606 = load i32, ptr %t605, !tbaa !23
  %t609 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t596, i32 %t606)
  store { i64, ptr } %t609, ptr %l302
  br label %bb153
bb153:
  %t610 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t611 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t612 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t613 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawRepeated(ptr %v0, ptr %s21, ptr %v0, ptr %v0, { i64, ptr } %t610, { i64, ptr } %t611, { i64, ptr } %t612)
  store %"compiler/diagmsg:Msg" %t613, ptr %l303
  br label %bb154
bb154:
  %t614 = load ptr, ptr %l283, !tbaa !29
  %t615 = load %"compiler/source:Span", ptr %l284
  %t616 = load %"compiler/diagmsg:Msg", ptr %l303
  %t617 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t614, %"compiler/source:Span" %t615, %"compiler/diagmsg:Msg" %t616)
  store i64 %t617, ptr %l304
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s21)
  br label %bb156
bb156:
  br label %bb159
bb157:
  br label %bb158
bb158:
  %t618 = load i64, ptr %l30, !tbaa !24
  %t621 = add i64 %t618, 1
  store i64 %t621, ptr %l30, !tbaa !24
  br label %bb140
bb159:
  call void @__olang_scope_close(ptr %s11)
  br label %bb244
bb160:
  %t623 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t623, ptr %l308
  br label %bb161
bb161:
  %t624 = load %"compiler/check:litv", ptr %l308
  store %"compiler/check:litv" %t624, ptr %l32
  %t625 = load ptr, ptr %l23, !tbaa !29
  %t627 = getelementptr %"compiler/ast:CaseDecl", ptr %t625, i32 0, i32 4
  %t628 = load ptr, ptr %t627, !tbaa !29
  %t630 = icmp eq ptr %t628, null
  br i1 %t630, label %bb162, label %bb163
bb162:
  %t632 = load %"compiler/check:litv", ptr %l16
  %t634 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %t632)
  store %"compiler/check:signMag" %t634, ptr %l313
  br label %bb164
bb163:
  %t635 = load ptr, ptr %l23, !tbaa !29
  %t637 = getelementptr %"compiler/ast:CaseDecl", ptr %t635, i32 0, i32 4
  %t638 = load ptr, ptr %t637, !tbaa !29
  %t640 = icmp eq ptr %t638, null
  br i1 %t640, label %bb170, label %bb171
bb164:
  %t642 = load %"compiler/check:signMag", ptr %l313
  store %"compiler/check:signMag" %t642, ptr %l33
  %t643 = getelementptr %"compiler/check:signMag", ptr %l33, i32 0, i32 0
  %t644 = load i1, ptr %t643, !tbaa !21
  store i1 %t644, ptr %l34, !tbaa !21
  %t646 = getelementptr %"compiler/check:signMag", ptr %l33, i32 0, i32 1
  %t647 = load i128, ptr %t646
  store i128 %t647, ptr %l35
  %t649 = getelementptr %"compiler/check:litv", ptr %l16, i32 0, i32 0
  %t650 = load i1, ptr %t649, !tbaa !21
  br i1 %t650, label %bb165, label %bb166
bb165:
  %t652 = load i1, ptr %l34, !tbaa !21
  %t653 = load i128, ptr %l35
  %t656 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eaddMag(i1 %t652, i128 %t653, i1 false, i128 1)
  store %"compiler/check:litv" %t656, ptr %l320
  br label %bb167
bb166:
  %t657 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t657, ptr %l321
  br label %bb168
bb167:
  %t658 = load %"compiler/check:litv", ptr %l320
  store %"compiler/check:litv" %t658, ptr %l317
  br label %bb169
bb168:
  %t659 = load %"compiler/check:litv", ptr %l321
  store %"compiler/check:litv" %t659, ptr %l317
  br label %bb169
bb169:
  %t660 = load %"compiler/check:litv", ptr %l317
  store %"compiler/check:litv" %t660, ptr %l32
  br label %bb188
bb170:
  call void @__olang_check_failed(ptr @olang_loc_bdfafd86356a320_3271504b736459c4)
  unreachable
bb171:
  br label %bb172
bb172:
  %t661 = load ptr, ptr %l23, !tbaa !29
  %t663 = getelementptr %"compiler/ast:CaseDecl", ptr %t661, i32 0, i32 4
  %t664 = load ptr, ptr %t663, !tbaa !29
  %t667 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v1, ptr %t664)
  store i1 %t667, ptr %l328
  br label %bb173
bb173:
  %t668 = load i1, ptr %l328, !tbaa !21
  br i1 %t668, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l329, !tbaa !21
  br label %bb180
bb175:
  %t669 = load ptr, ptr %l23, !tbaa !29
  %t671 = getelementptr %"compiler/ast:CaseDecl", ptr %t669, i32 0, i32 4
  %t672 = load ptr, ptr %t671, !tbaa !29
  %t674 = icmp eq ptr %t672, null
  br i1 %t674, label %bb176, label %bb177
bb176:
  call void @__olang_check_failed(ptr @olang_loc_bdfafd86356a320_3271504b736459c4)
  unreachable
bb177:
  br label %bb178
bb178:
  %t676 = load ptr, ptr %l23, !tbaa !29
  %t678 = getelementptr %"compiler/ast:CaseDecl", ptr %t676, i32 0, i32 4
  %t679 = load ptr, ptr %t678, !tbaa !29
  %t681 = call i1 @compiler_2fcheck_2eisCharLit(ptr %v1, ptr %t679)
  store i1 %t681, ptr %l335
  br label %bb179
bb179:
  %t682 = load i1, ptr %l335, !tbaa !21
  store i1 %t682, ptr %l329, !tbaa !21
  br label %bb180
bb180:
  %t683 = load i1, ptr %l329, !tbaa !21
  br i1 %t683, label %bb181, label %bb182
bb181:
  %t684 = load ptr, ptr %l0, !tbaa !29
  store ptr %t684, ptr %l336, !tbaa !29
  %t685 = load ptr, ptr %l23, !tbaa !29
  %t687 = getelementptr %"compiler/ast:CaseDecl", ptr %t685, i32 0, i32 4
  %t688 = load ptr, ptr %t687, !tbaa !29
  %t690 = icmp eq ptr %t688, null
  br i1 %t690, label %bb183, label %bb184
bb182:
  br label %bb187
bb183:
  call void @__olang_check_failed(ptr @olang_loc_cf3f79d848e44ed1_488edda033e9ba8d)
  unreachable
bb184:
  br label %bb185
bb185:
  %t692 = load ptr, ptr %l23, !tbaa !29
  %t694 = getelementptr %"compiler/ast:CaseDecl", ptr %t692, i32 0, i32 4
  %t695 = load ptr, ptr %t694, !tbaa !29
  %t696 = load ptr, ptr %l336, !tbaa !29
  %t698 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t696, ptr %t695)
  store %"compiler/check:litv" %t698, ptr %l342
  br label %bb186
bb186:
  %t699 = load %"compiler/check:litv", ptr %l342
  store %"compiler/check:litv" %t699, ptr %l32
  br label %bb187
bb187:
  br label %bb188
bb188:
  %t700 = getelementptr %"compiler/check:litv", ptr %l32, i32 0, i32 0
  %t701 = load i1, ptr %t700, !tbaa !21
  %t703 = xor i1 %t701, true
  br i1 %t703, label %bb189, label %bb190
bb189:
  store i1 true, ptr %l345, !tbaa !21
  br label %bb191
bb190:
  %t705 = getelementptr %"compiler/check:litv", ptr %l32, i32 0, i32 1
  %t706 = load i1, ptr %t705, !tbaa !21
  store i1 %t706, ptr %l345, !tbaa !21
  br label %bb191
bb191:
  %t708 = load i1, ptr %l345, !tbaa !21
  br i1 %t708, label %bb192, label %bb193
bb192:
  %t709 = load i1, ptr %l4, !tbaa !21
  br i1 %t709, label %bb194, label %bb195
bb193:
  br label %bb206
bb194:
  store %olang.scope zeroinitializer, ptr %s28
  %t711 = load ptr, ptr %l0, !tbaa !29
  store ptr %t711, ptr %l348, !tbaa !29
  %t712 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t712, ptr %l349
  %t713 = load ptr, ptr %l23, !tbaa !29
  %t715 = getelementptr %"compiler/ast:CaseDecl", ptr %t713, i32 0, i32 4
  %t716 = load ptr, ptr %t715, !tbaa !29
  %t718 = icmp eq ptr %t716, null
  %t720 = xor i1 %t718, true
  br i1 %t720, label %bb196, label %bb197
bb195:
  br label %bb204
bb196:
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load i32, ptr %l10, !tbaa !23
  %t726 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s28, ptr %t722, i32 %t723)
  store { i64, ptr } %t726, ptr %l357
  br label %bb198
bb197:
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t728 = load i32, ptr %l10, !tbaa !23
  %t731 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s28, ptr %t727, i32 %t728)
  store { i64, ptr } %t731, ptr %l362
  br label %bb200
bb198:
  %t732 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t734 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNotLiteral(ptr %s28, ptr %v0, { i64, ptr } %t732)
  store %"compiler/diagmsg:Msg" %t734, ptr %l359
  br label %bb199
bb199:
  %t735 = load %"compiler/diagmsg:Msg", ptr %l359
  store %"compiler/diagmsg:Msg" %t735, ptr %l354
  br label %bb202
bb200:
  %t736 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t738 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNoFit(ptr %s28, ptr %s28, ptr %v0, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } %t736)
  store %"compiler/diagmsg:Msg" %t738, ptr %l364
  br label %bb201
bb201:
  %t739 = load %"compiler/diagmsg:Msg", ptr %l364
  store %"compiler/diagmsg:Msg" %t739, ptr %l354
  br label %bb202
bb202:
  %t740 = load ptr, ptr %l348, !tbaa !29
  %t741 = load %"compiler/source:Span", ptr %l349
  %t742 = load %"compiler/diagmsg:Msg", ptr %l354
  %t743 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t740, %"compiler/source:Span" %t741, %"compiler/diagmsg:Msg" %t742)
  store i64 %t743, ptr %l365
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s28)
  br label %bb204
bb204:
  %t744 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t744, ptr %l366
  br label %bb205
bb205:
  %t745 = load %"compiler/check:litv", ptr %l366
  store %"compiler/check:litv" %t745, ptr %l16
  call void @__olang_scope_close(ptr %s11)
  br label %bb244
bb206:
  %t746 = load %"compiler/check:litv", ptr %l32
  store %"compiler/check:litv" %t746, ptr %l16
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = load %"compiler/check:litv", ptr %l32
  %t750 = load i32, ptr %l10, !tbaa !23
  %t754 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawFits(ptr %v0, ptr %t748, %"compiler/check:litv" %t749, i32 %t750)
  store i1 %t754, ptr %l371
  br label %bb207
bb207:
  %t755 = load i1, ptr %l371, !tbaa !21
  %t756 = xor i1 %t755, true
  br i1 %t756, label %bb208, label %bb209
bb208:
  %t758 = load i1, ptr %l4, !tbaa !21
  br i1 %t758, label %bb210, label %bb211
bb209:
  br label %bb217
bb210:
  store %olang.scope zeroinitializer, ptr %s30
  %t760 = load ptr, ptr %l0, !tbaa !29
  store ptr %t760, ptr %l374, !tbaa !29
  %t761 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t761, ptr %l375
  %t762 = load %"compiler/check:litv", ptr %l32
  %t764 = call { i64, ptr } @compiler_2fcheck_2elitText(ptr %s30, %"compiler/check:litv" %t762)
  store { i64, ptr } %t764, ptr %l377
  br label %bb212
bb211:
  br label %bb216
bb212:
  %t765 = load { i64, ptr }, ptr %l377, !tbaa !27
  store { i64, ptr } %t765, ptr %l378, !tbaa !27
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load i32, ptr %l10, !tbaa !23
  %t770 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s30, ptr %t766, i32 %t767)
  store { i64, ptr } %t770, ptr %l381
  br label %bb213
bb213:
  %t771 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t772 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t774 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNoFit(ptr %s30, ptr %s30, ptr %v0, { i64, ptr } %t772, { i64, ptr } %t771)
  store %"compiler/diagmsg:Msg" %t774, ptr %l383
  br label %bb214
bb214:
  %t775 = load ptr, ptr %l374, !tbaa !29
  %t776 = load %"compiler/source:Span", ptr %l375
  %t777 = load %"compiler/diagmsg:Msg", ptr %l383
  %t778 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t775, %"compiler/source:Span" %t776, %"compiler/diagmsg:Msg" %t777)
  store i64 %t778, ptr %l384
  br label %bb215
bb215:
  call void @__olang_scope_close(ptr %s30)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s11)
  br label %bb244
bb217:
  %t779 = load i64, ptr %l22, !tbaa !24
  %t780 = getelementptr %"compiler/check:litv", ptr %l32, i32 0, i32 3
  %t781 = load i64, ptr %t780, !tbaa !24
  %t783 = load ptr, ptr %lp13
  %t785 = getelementptr { i64, ptr }, ptr %t783, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !27
  %t787 = getelementptr i64, ptr %t786, i64 %t779
  store i64 %t781, ptr %t787, !tbaa !34
  %t788 = load i64, ptr %l22, !tbaa !24
  %t790 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t791 = load ptr, ptr %t790, !tbaa !27
  %t792 = getelementptr i1, ptr %t791, i64 %t788
  store i1 true, ptr %t792, !tbaa !31
  store i64 0, ptr %l36, !tbaa !24
  %t793 = load i64, ptr %l22, !tbaa !24
  store i64 %t793, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t795 = load i64, ptr %l37, !tbaa !24
  %t796 = load i64, ptr %l36, !tbaa !24
  %t799 = icmp sgt i64 %t795, %t796
  br i1 %t799, label %bb218, label %bb219
bb218:
  %t801 = load i64, ptr %l38, !tbaa !24
  %t803 = icmp sgt i64 %t801, 0
  br i1 %t803, label %bb220, label %bb221
bb219:
  store i64 0, ptr %l392, !tbaa !24
  br label %bb223
bb220:
  %t805 = load i64, ptr %l37, !tbaa !24
  %t806 = load i64, ptr %l36, !tbaa !24
  %t809 = sub i64 %t805, %t806
  %t810 = load i64, ptr %l38, !tbaa !24
  %t813 = add i64 %t809, %t810
  %t815 = sub i64 %t813, 1
  %t816 = load i64, ptr %l38, !tbaa !24
  %t819 = sdiv i64 %t815, %t816
  store i64 %t819, ptr %l395, !tbaa !24
  br label %bb222
bb221:
  store i64 0, ptr %l395, !tbaa !24
  br label %bb222
bb222:
  %t821 = load i64, ptr %l395, !tbaa !24
  store i64 %t821, ptr %l392, !tbaa !24
  br label %bb223
bb223:
  %t822 = load i64, ptr %l392, !tbaa !24
  store i64 %t822, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb224
bb224:
  %t823 = load i64, ptr %l40, !tbaa !24
  %t824 = load i64, ptr %l39, !tbaa !24
  %t827 = icmp slt i64 %t823, %t824
  %t829 = xor i1 %t827, true
  br i1 %t829, label %bb225, label %bb226
bb225:
  br label %bb243
bb226:
  br label %bb227
bb227:
  %t831 = load i64, ptr %l36, !tbaa !24
  %t832 = load i64, ptr %l40, !tbaa !24
  %t833 = load i64, ptr %l38, !tbaa !24
  %t836 = mul i64 %t832, %t833
  %t839 = add i64 %t831, %t836
  store i64 %t839, ptr %l41, !tbaa !24
  %t841 = load i64, ptr %l41, !tbaa !24
  %t843 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t844 = load ptr, ptr %t843, !tbaa !27
  %t845 = getelementptr i1, ptr %t844, i64 %t841
  %t846 = load i1, ptr %t845, !tbaa !31
  br i1 %t846, label %bb228, label %bb229
bb228:
  %t848 = load i64, ptr %l41, !tbaa !24
  %t849 = load ptr, ptr %lp13
  %t851 = getelementptr { i64, ptr }, ptr %t849, i32 0, i32 1
  %t852 = load ptr, ptr %t851, !tbaa !27
  %t853 = getelementptr i64, ptr %t852, i64 %t848
  %t854 = load i64, ptr %t853, !tbaa !34
  %t855 = load i64, ptr %l22, !tbaa !24
  %t856 = load ptr, ptr %lp13
  %t858 = getelementptr { i64, ptr }, ptr %t856, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !27
  %t860 = getelementptr i64, ptr %t859, i64 %t855
  %t861 = load i64, ptr %t860, !tbaa !34
  %t864 = icmp eq i64 %t854, %t861
  store i1 %t864, ptr %l415, !tbaa !21
  br label %bb230
bb229:
  store i1 false, ptr %l415, !tbaa !21
  br label %bb230
bb230:
  %t866 = load i1, ptr %l415, !tbaa !21
  br i1 %t866, label %bb231, label %bb232
bb231:
  %t867 = load i1, ptr %l4, !tbaa !21
  br i1 %t867, label %bb233, label %bb234
bb232:
  br label %bb241
bb233:
  store %olang.scope zeroinitializer, ptr %s34
  %t869 = load ptr, ptr %l0, !tbaa !29
  store ptr %t869, ptr %l422, !tbaa !29
  %t870 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t870, ptr %l423
  %t871 = load ptr, ptr %l0, !tbaa !29
  %t872 = load ptr, ptr %l23, !tbaa !29
  %t874 = getelementptr %"compiler/ast:CaseDecl", ptr %t872, i32 0, i32 1
  %t875 = load i32, ptr %t874, !tbaa !23
  %t878 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t871, i32 %t875)
  store { i64, ptr } %t878, ptr %l427
  br label %bb235
bb234:
  br label %bb240
bb235:
  %t879 = load %"compiler/check:litv", ptr %l32
  %t881 = call { i64, ptr } @compiler_2fcheck_2elitText(ptr %s34, %"compiler/check:litv" %t879)
  store { i64, ptr } %t881, ptr %l429
  br label %bb236
bb236:
  %t882 = load { i64, ptr }, ptr %l429, !tbaa !27
  store { i64, ptr } %t882, ptr %l430, !tbaa !27
  %t883 = load ptr, ptr %l0, !tbaa !29
  %t884 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t884, ptr %l432, !tbaa !27
  %t885 = load i64, ptr %l41, !tbaa !24
  %t887 = getelementptr { i64, ptr }, ptr %l432, i32 0, i32 1
  %t888 = load ptr, ptr %t887, !tbaa !27
  %t889 = getelementptr ptr, ptr %t888, i64 %t885
  %t890 = load ptr, ptr %t889, !tbaa !39
  %t892 = getelementptr %"compiler/ast:CaseDecl", ptr %t890, i32 0, i32 1
  %t893 = load i32, ptr %t892, !tbaa !23
  %t896 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t883, i32 %t893)
  store { i64, ptr } %t896, ptr %l436
  br label %bb237
bb237:
  %t897 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t898 = load { i64, ptr }, ptr %l430, !tbaa !27
  %t899 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t900 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawRepeated(ptr %v0, ptr %s34, ptr %v0, ptr %v0, { i64, ptr } %t897, { i64, ptr } %t898, { i64, ptr } %t899)
  store %"compiler/diagmsg:Msg" %t900, ptr %l437
  br label %bb238
bb238:
  %t901 = load ptr, ptr %l422, !tbaa !29
  %t902 = load %"compiler/source:Span", ptr %l423
  %t903 = load %"compiler/diagmsg:Msg", ptr %l437
  %t904 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t901, %"compiler/source:Span" %t902, %"compiler/diagmsg:Msg" %t903)
  store i64 %t904, ptr %l438
  br label %bb239
bb239:
  call void @__olang_scope_close(ptr %s34)
  br label %bb240
bb240:
  br label %bb243
bb241:
  br label %bb242
bb242:
  %t905 = load i64, ptr %l40, !tbaa !24
  %t908 = add i64 %t905, 1
  store i64 %t908, ptr %l40, !tbaa !24
  br label %bb224
bb243:
  call void @__olang_scope_close(ptr %s11)
  br label %bb244
bb244:
  %t910 = load i64, ptr %l21, !tbaa !24
  %t913 = add i64 %t910, 1
  store i64 %t913, ptr %l21, !tbaa !24
  br label %bb86
bb245:
  %t915 = load i32, ptr %l10, !tbaa !23
  %t916 = load i1, ptr %l11, !tbaa !21
  %t917 = load ptr, ptr %lp13
  %t918 = load { i64, ptr }, ptr %t917, !tbaa !27
  %t919 = load ptr, ptr %lp14
  %t920 = load { i64, ptr }, ptr %t919, !tbaa !27
  %t925 = call %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v3, ptr %v3, ptr %v3, i32 %t915, i1 %t916, { i64, ptr } %t918, { i64, ptr } %t920)
  store %"compiler/check:rawTable" %t925, ptr %l449
  br label %bb246
bb246:
  %t926 = load %"compiler/check:rawTable", ptr %l449
  %t927 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store %"compiler/check:rawTable" %t926, ptr %t927
  call void @__olang_scope_close(ptr %s0)
  store ptr %t927, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i32
  %l13 = alloca i64
  %l15 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l36 = alloca i1
  %l41 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i64
  %l61 = alloca i64
  %l67 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t12, i32 %t13)
  store i64 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i64, ptr %l13, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 64
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb8, label %bb9
bb7:
  br label %bb19
bb8:
  %t31 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l27
  br label %bb12
bb11:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb13
bb12:
  %t44 = load i1, ptr %l27, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l22, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l20, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load %"compiler/check:litv", ptr %l1
  %t58 = load i32, ptr %l3, !tbaa !23
  %t62 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t56, %"compiler/check:litv" %t57, i32 %t58)
  store i1 %t62, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t63 = load i1, ptr %l36, !tbaa !21
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l30, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l3, !tbaa !23
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t74, ptr %l41
  br label %bb20
bb20:
  %t75 = load i1, ptr %l41, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  br i1 %t77, label %bb23, label %bb24
bb22:
  br label %bb32
bb23:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = icmp eq i64 %t79, 64
  store i1 %t81, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t83 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = icmp eq i64 %t89, 64
  br i1 %t91, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb31
bb30:
  %t93 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load i64, ptr %l4, !tbaa !24
  store i64 %t95, ptr %l52, !tbaa !24
  %t96 = load i64, ptr %l52, !tbaa !24
  %t97 = load i64, ptr %l52, !tbaa !24
  %t98 = shl i64 1, %t97
  %t101 = icmp slt i64 %t94, %t98
  store i1 %t101, ptr %l50, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l50, !tbaa !21
  store i1 %t103, ptr %rv
  br label %ret
bb32:
  %t104 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t105 = load i1, ptr %t104, !tbaa !21
  br i1 %t105, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = icmp eq i64 %t108, 64
  br i1 %t110, label %bb36, label %bb37
bb36:
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t113 = load i64, ptr %l4, !tbaa !24
  %t115 = sub i64 %t113, 1
  store i64 %t115, ptr %l61, !tbaa !24
  %t116 = load i64, ptr %l61, !tbaa !24
  %t117 = load i64, ptr %l61, !tbaa !24
  %t118 = shl i64 1, %t117
  store i64 %t118, ptr %l5, !tbaa !24
  %t120 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = sub i64 0, %t122
  %t127 = icmp sge i64 %t121, %t124
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i64, ptr %l5, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  store i1 %t134, ptr %l67, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb41
bb41:
  %t136 = load i1, ptr %l67, !tbaa !21
  store i1 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca i32
  %l46 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %s2, ptr %t9, i32 %a2)
  store { i64, ptr } %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  br label %bb22
bb7:
  br label %bb8
bb8:
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load i64, ptr %l5, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  store i32 %t34, ptr %l7, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l29
  br label %bb9
bb9:
  %t46 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t48 = trunc i64 18 to i32
  %t49 = icmp eq i32 %t46, %t48
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l7, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l37
  br label %bb13
bb13:
  %t63 = load i32, ptr %l1, !tbaa !23
  %t64 = load i32, ptr %l37, !tbaa !23
  %t66 = icmp eq i32 %t64, %t63
  br i1 %t66, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t71 = load i32, ptr %l7, !tbaa !23
  %t72 = load i64, ptr %l3, !tbaa !24
  %t74 = add i64 %t72, 1
  %t79 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t69, i32 %t70, i32 %t71, i64 %t74)
  store i1 %t79, ptr %l46
  br label %bb17
bb17:
  %t80 = load i1, ptr %l46, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb5
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/load:Import"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/names:Entry"
  %l26 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l36 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l55 = alloca { i64, ptr }
  %l57 = alloca i8
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l73 = alloca i32
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Nearest"
  %l88 = alloca ptr
  %l91 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l92 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l94 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l95 = alloca i32
  %l97 = alloca i1
  %l98 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l107 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca i64
  %l115 = alloca i64
  %l120 = alloca %"compiler/load:Import"
  %l128 = alloca [14 x { i64, ptr }]
  %l148 = alloca i64
  %l152 = alloca i64
  %l155 = alloca i64
  %l173 = alloca i64
  %l175 = alloca ptr
  %l179 = alloca i1
  %l185 = alloca ptr
  %l189 = alloca i64
  %l191 = alloca ptr
  %l200 = alloca ptr
  %l203 = alloca i64
  %l205 = alloca i64
  %l210 = alloca %"compiler/names:Entry"
  %l213 = alloca i1
  %l215 = alloca i1
  %l218 = alloca i1
  %l225 = alloca { i64, ptr }
  %l228 = alloca i1
  %l230 = alloca i1
  %l242 = alloca { i64, ptr }
  %l243 = alloca i64
  %l244 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l32, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = sub i64 %t10, 1
  %t14 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t17)
  store i1 %t19, ptr %l36
  br label %bb4
bb3:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l36, !tbaa !21
  store i1 %t20, ptr %l31, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l31, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t24, 1
  store i64 %t27, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t33 = icmp sge i64 %t31, 2
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t41 = icmp slt i64 %t35, %t38
  store i1 %t41, ptr %l44, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l44, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t52 = icmp slt i64 %t50, 8
  store i1 %t52, ptr %l49, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l49, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l55, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i8, ptr %t57, i64 0
  %t59 = load i8, ptr %t58, !tbaa !32
  %t61 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t59)
  store i8 %t61, ptr %l57
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t62, ptr %l58, !tbaa !27
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l59, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t64, 0
  store i64 %t67, ptr %l62, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l63, !tbaa !24
  %t70 = load i64, ptr %l59, !tbaa !24
  %t71 = icmp sge i64 %t70, 0
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t73 = load i64, ptr %l59, !tbaa !24
  %t74 = load i64, ptr %l62, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_fbd40b14c0771014_77084db5763620a0)
  unreachable
bb22:
  %t77 = load i64, ptr %l62, !tbaa !24
  %t78 = load i64, ptr %l63, !tbaa !24
  %t79 = icmp sle i64 %t77, %t78
  br i1 %t79, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fbd40b14c0771014_77084db5763620a0)
  unreachable
bb24:
  %t81 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l59, !tbaa !24
  %t84 = load i64, ptr %l62, !tbaa !24
  %t85 = getelementptr i8, ptr %t82, i64 %t83
  %t86 = sub i64 %t84, %t83
  %t87 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t85, 1
  %t89 = load i8, ptr %l57, !tbaa !22
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = extractvalue { i64, ptr } %t88, 0
  %t93 = add i64 1, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t93)
  store i8 %t89, ptr %t94
  %t95 = getelementptr i8, ptr %t94, i64 1
  call void @olang_textcopy(ptr %t95, ptr %t91, i64 %t92)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  store { i64, ptr } %t97, ptr %l4, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v2, ptr %t104, { i64, ptr } %t105)
  store i32 %t108, ptr %l73
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_fbd40b14c0771014_77084db5763620a0)
  unreachable
bb26:
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t110 = load i32, ptr %l73, !tbaa !23
  %t112 = icmp ne i32 %t110, %t109
  br i1 %t112, label %bb27, label %bb28
bb27:
  %t114 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t114, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t116 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t118, ptr %l78
  br label %bb31
bb31:
  %t119 = load i1, ptr %l78, !tbaa !21
  br i1 %t119, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l79, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t120, ptr %l80, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l81, !tbaa !24
  %t123 = load i64, ptr %l81, !tbaa !24
  %t124 = mul i64 %t123, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l82, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l81, !tbaa !24
  %t133 = mul i64 %t132, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t129, ptr %t131, i64 %t133, i1 false)
  %t134 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t134, ptr %l80, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t135 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t135, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t136 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t138 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v1, ptr %s0, { i64, ptr } %t136)
  store %"compiler/msgs:Nearest" %t138, ptr %l84
  br label %bb35
bb35:
  %t139 = load %"compiler/msgs:Nearest", ptr %l84
  %t140 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t139, ptr %t140
  store ptr %t140, ptr %l5, !tbaa !29
  %t142 = load i1, ptr %l2, !tbaa !21
  br i1 %t142, label %bb36, label %bb37
bb36:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t144)
  store ptr %t146, ptr %l88
  br label %bb38
bb37:
  br label %bb63
bb38:
  %t147 = load ptr, ptr %l88, !tbaa !29
  %t149 = getelementptr %"compiler/check:frame", ptr %t147, i32 0, i32 8
  %t151 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t149)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t151, ptr %l91
  br label %bb39
bb39:
  %t152 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l91
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t152, ptr %l6
  br label %bb40
bb40:
  %t154 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l6)
  %t155 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t154, 1
  %t156 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t154, 0
  store i32 %t156, ptr %l95
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb42, label %ok.158, !prof !99
ok.158:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t155, ptr %l94
  br label %bb41
bb41:
  %t159 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l94
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t159, ptr %l92
  br label %bb44
bb42:
  %t160 = load i32, ptr %l95, !tbaa !23
  %t161 = ashr i32 %t160, 16
  %t163 = icmp eq i32 %t161, 1
  store i1 %t163, ptr %l97, !tbaa !21
  br label %bb43
bb43:
  br label %bb48
bb44:
  %t164 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l92
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t164, ptr %l7
  %t165 = load ptr, ptr %l5, !tbaa !29
  store ptr %t165, ptr %l98, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 0
  %t168 = load i32, ptr %t167, !tbaa !23
  %t171 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t166, i32 %t168)
  store { i64, ptr } %t171, ptr %l101
  br label %bb45
bb45:
  %t172 = load ptr, ptr %l98, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l101, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t172, { i64, ptr } %t173)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb40
bb48:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/load:Loader", ptr %t180, i32 0, i32 10
  store ptr %t182, ptr %l105, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t183)
  store ptr %t185, ptr %l107
  br label %bb49
bb49:
  %t186 = load ptr, ptr %l107, !tbaa !29
  %t188 = getelementptr %"compiler/check:frame", ptr %t186, i32 0, i32 1
  %t189 = load i64, ptr %t188, !tbaa !24
  %t190 = load ptr, ptr %l105, !tbaa !29
  %t192 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t190, i64 %t189)
  store ptr %t192, ptr %l110
  br label %bb50
bb50:
  %t193 = load ptr, ptr %l110, !tbaa !29
  %t195 = getelementptr %"compiler/load:Module", ptr %t193, i32 0, i32 11
  store ptr %t195, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb51
bb51:
  %t197 = load i64, ptr %l9, !tbaa !24
  store i64 %t197, ptr %l113, !tbaa !24
  %t198 = load ptr, ptr %l8, !tbaa !29
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t198)
  store i64 %t200, ptr %l115
  br label %bb52
bb52:
  %t201 = load i64, ptr %l113, !tbaa !24
  %t202 = load i64, ptr %l115, !tbaa !24
  %t203 = icmp slt i64 %t201, %t202
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb53, label %bb54
bb53:
  br label %bb62
bb54:
  br label %bb55
bb55:
  %t207 = load ptr, ptr %l8, !tbaa !29
  %t208 = load i64, ptr %l9, !tbaa !24
  %t211 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t207, i64 %t208)
  store %"compiler/load:Import" %t211, ptr %l120
  br label %bb56
bb56:
  %t212 = load %"compiler/load:Import", ptr %l120
  store %"compiler/load:Import" %t212, ptr %l10
  %t213 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t214 = load i64, ptr %t213, !tbaa !24
  %t216 = icmp sge i64 %t214, 0
  br i1 %t216, label %bb57, label %bb58
bb57:
  %t218 = load ptr, ptr %l5, !tbaa !29
  %t219 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 2
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t218, { i64, ptr } %t220)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t223 = load i64, ptr %l9, !tbaa !24
  %t226 = add i64 %t223, 1
  store i64 %t226, ptr %l9, !tbaa !24
  br label %bb51
bb62:
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t228 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 0
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %t228, !tbaa !37
  %t229 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %t229, !tbaa !37
  %t230 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %t230, !tbaa !37
  %t231 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %t231, !tbaa !37
  %t232 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %t232, !tbaa !37
  %t233 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %t233, !tbaa !37
  %t234 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %t234, !tbaa !37
  %t235 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 7
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t235, !tbaa !37
  %t236 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t236, !tbaa !37
  %t237 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 9
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t237, !tbaa !37
  %t238 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t238, !tbaa !37
  %t239 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t239, !tbaa !37
  %t240 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t240, !tbaa !37
  %t241 = getelementptr [14 x { i64, ptr }], ptr %l128, i64 0, i64 13
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t241, !tbaa !37
  %t242 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 224, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t242, ptr %l128, i64 224, i1 false)
  store ptr %t242, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t244 = load ptr, ptr %l11
  store i64 14, ptr %l13, !tbaa !24
  br label %bb64
bb64:
  %t247 = load i64, ptr %l12, !tbaa !24
  %t248 = load i64, ptr %l13, !tbaa !24
  %t251 = icmp slt i64 %t247, %t248
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb65, label %bb66
bb65:
  br label %bb70
bb66:
  br label %bb67
bb67:
  %t255 = load ptr, ptr %l11
  %t256 = load i64, ptr %l12, !tbaa !24
  %t259 = getelementptr [14 x { i64, ptr }], ptr %t255, i64 0, i64 %t256
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !37
  %t262 = load ptr, ptr %l5, !tbaa !29
  %t264 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %t264, ptr %t262, { i64, ptr } %t260)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t267 = load i64, ptr %l12, !tbaa !24
  %t270 = add i64 %t267, 1
  store i64 %t270, ptr %l12, !tbaa !24
  br label %bb64
bb70:
  call void @__olang_scope_close(ptr %s13)
  store i64 0, ptr %l15, !tbaa !24
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t277 = getelementptr %"compiler/generic:Program", ptr %t275, i32 0, i32 0
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = getelementptr %"compiler/load:Loader", ptr %t278, i32 0, i32 10
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t280)
  store i64 %t282, ptr %l148
  br label %bb71
bb71:
  %t283 = load i64, ptr %l148, !tbaa !24
  store i64 %t283, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t284 = load i64, ptr %l16, !tbaa !24
  %t285 = load i64, ptr %l15, !tbaa !24
  %t288 = icmp sgt i64 %t284, %t285
  br i1 %t288, label %bb72, label %bb73
bb72:
  %t290 = load i64, ptr %l17, !tbaa !24
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb77
bb74:
  %t294 = load i64, ptr %l16, !tbaa !24
  %t295 = load i64, ptr %l15, !tbaa !24
  %t298 = sub i64 %t294, %t295
  %t299 = load i64, ptr %l17, !tbaa !24
  %t302 = add i64 %t298, %t299
  %t304 = sub i64 %t302, 1
  %t305 = load i64, ptr %l17, !tbaa !24
  %t308 = sdiv i64 %t304, %t305
  store i64 %t308, ptr %l155, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb76
bb76:
  %t310 = load i64, ptr %l155, !tbaa !24
  store i64 %t310, ptr %l152, !tbaa !24
  br label %bb77
bb77:
  %t311 = load i64, ptr %l152, !tbaa !24
  store i64 %t311, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb78
bb78:
  %t312 = load i64, ptr %l19, !tbaa !24
  %t313 = load i64, ptr %l18, !tbaa !24
  %t316 = icmp slt i64 %t312, %t313
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb79, label %bb80
bb79:
  br label %bb122
bb80:
  br label %bb81
bb81:
  %t320 = load i64, ptr %l15, !tbaa !24
  %t321 = load i64, ptr %l19, !tbaa !24
  %t322 = load i64, ptr %l17, !tbaa !24
  %t325 = mul i64 %t321, %t322
  %t328 = add i64 %t320, %t325
  store i64 %t328, ptr %l20, !tbaa !24
  %t330 = load i64, ptr %l20, !tbaa !24
  store i64 %t330, ptr %l173, !tbaa !24
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t331)
  store ptr %t333, ptr %l175
  br label %bb82
bb82:
  %t334 = load ptr, ptr %l175, !tbaa !29
  %t336 = getelementptr %"compiler/check:frame", ptr %t334, i32 0, i32 1
  %t337 = load i64, ptr %t336, !tbaa !24
  %t338 = load i64, ptr %l173, !tbaa !24
  %t340 = icmp ne i64 %t338, %t337
  br i1 %t340, label %bb83, label %bb84
bb83:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/check:Checker", ptr %t342, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t347 = getelementptr %"compiler/generic:Program", ptr %t345, i32 0, i32 0
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = getelementptr %"compiler/load:Loader", ptr %t348, i32 0, i32 10
  %t351 = load i64, ptr %l20, !tbaa !24
  %t354 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t350, i64 %t351)
  store ptr %t354, ptr %l185
  br label %bb85
bb84:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb86
bb85:
  %t355 = load ptr, ptr %l185, !tbaa !29
  %t357 = getelementptr %"compiler/load:Module", ptr %t355, i32 0, i32 3
  %t358 = load i1, ptr %t357, !tbaa !21
  %t360 = xor i1 %t358, true
  store i1 %t360, ptr %l179, !tbaa !21
  br label %bb86
bb86:
  %t362 = load i1, ptr %l179, !tbaa !21
  br i1 %t362, label %bb87, label %bb88
bb87:
  br label %bb121
bb88:
  br label %bb89
bb89:
  %t363 = load i64, ptr %l20, !tbaa !24
  store i64 %t363, ptr %l189, !tbaa !24
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t364)
  store ptr %t366, ptr %l191
  br label %bb90
bb90:
  %t367 = load ptr, ptr %l191, !tbaa !29
  %t369 = getelementptr %"compiler/check:frame", ptr %t367, i32 0, i32 1
  %t370 = load i64, ptr %t369, !tbaa !24
  %t371 = load i64, ptr %l189, !tbaa !24
  %t373 = icmp eq i64 %t371, %t370
  store i1 %t373, ptr %l21, !tbaa !21
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/check:Checker", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/generic:Program", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/names:Resolver", ptr %t381, i32 0, i32 1
  %t384 = load i64, ptr %l20, !tbaa !24
  %t387 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t383, i64 %t384)
  store ptr %t387, ptr %l200
  br label %bb91
bb91:
  %t388 = load ptr, ptr %l200, !tbaa !29
  %t390 = getelementptr %"compiler/names:Table", ptr %t388, i32 0, i32 0
  store ptr %t390, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb92
bb92:
  %t392 = load i64, ptr %l23, !tbaa !24
  store i64 %t392, ptr %l203, !tbaa !24
  %t393 = load ptr, ptr %l22, !tbaa !29
  %t395 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t393)
  store i64 %t395, ptr %l205
  br label %bb93
bb93:
  %t396 = load i64, ptr %l203, !tbaa !24
  %t397 = load i64, ptr %l205, !tbaa !24
  %t398 = icmp slt i64 %t396, %t397
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb94, label %bb95
bb94:
  br label %bb120
bb95:
  br label %bb96
bb96:
  %t402 = load ptr, ptr %l22, !tbaa !29
  %t403 = load i64, ptr %l23, !tbaa !24
  %t406 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t402, i64 %t403)
  store %"compiler/names:Entry" %t406, ptr %l210
  br label %bb97
bb97:
  %t407 = load %"compiler/names:Entry", ptr %l210
  store %"compiler/names:Entry" %t407, ptr %l24
  %t408 = getelementptr %"compiler/names:Entry", ptr %l24, i32 0, i32 2
  %t409 = load i32, ptr %t408, !range !{i32 0, i32 9}
  %t411 = trunc i64 4 to i32
  %t412 = icmp eq i32 %t409, %t411
  br i1 %t412, label %bb98, label %bb99
bb98:
  store i1 true, ptr %l213, !tbaa !21
  br label %bb106
bb99:
  %t414 = load i1, ptr %l2, !tbaa !21
  br i1 %t414, label %bb100, label %bb101
bb100:
  %t416 = getelementptr %"compiler/names:Entry", ptr %l24, i32 0, i32 2
  %t417 = load i32, ptr %t416, !range !{i32 0, i32 9}
  %t419 = trunc i64 2 to i32
  %t420 = icmp eq i32 %t417, %t419
  br i1 %t420, label %bb102, label %bb103
bb101:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb105
bb102:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb104
bb103:
  %t422 = getelementptr %"compiler/names:Entry", ptr %l24, i32 0, i32 2
  %t423 = load i32, ptr %t422, !range !{i32 0, i32 9}
  %t425 = trunc i64 3 to i32
  %t426 = icmp eq i32 %t423, %t425
  store i1 %t426, ptr %l218, !tbaa !21
  br label %bb104
bb104:
  %t428 = load i1, ptr %l218, !tbaa !21
  store i1 %t428, ptr %l215, !tbaa !21
  br label %bb105
bb105:
  %t429 = load i1, ptr %l215, !tbaa !21
  store i1 %t429, ptr %l213, !tbaa !21
  br label %bb106
bb106:
  %t430 = load i1, ptr %l213, !tbaa !21
  %t433 = xor i1 %t430, true
  br i1 %t433, label %bb107, label %bb108
bb107:
  br label %bb119
bb108:
  br label %bb109
bb109:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/names:Entry", ptr %l24, i32 0, i32 0
  %t437 = load i32, ptr %t436, !tbaa !23
  %t440 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t435, i32 %t437)
  store { i64, ptr } %t440, ptr %l225
  br label %bb110
bb110:
  %t441 = load { i64, ptr }, ptr %l225, !tbaa !27
  store { i64, ptr } %t441, ptr %l26, !tbaa !27
  %t442 = load i1, ptr %l21, !tbaa !21
  %t444 = xor i1 %t442, true
  br i1 %t444, label %bb111, label %bb112
bb111:
  %t446 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t448 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t446)
  store i1 %t448, ptr %l230
  br label %bb113
bb112:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb114
bb113:
  %t449 = load i1, ptr %l230, !tbaa !21
  %t450 = xor i1 %t449, true
  store i1 %t450, ptr %l228, !tbaa !21
  br label %bb114
bb114:
  %t452 = load i1, ptr %l228, !tbaa !21
  br i1 %t452, label %bb115, label %bb116
bb115:
  br label %bb119
bb116:
  br label %bb117
bb117:
  %t453 = load ptr, ptr %l5, !tbaa !29
  %t454 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t453, { i64, ptr } %t454)
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t457 = load i64, ptr %l23, !tbaa !24
  %t460 = add i64 %t457, 1
  store i64 %t460, ptr %l23, !tbaa !24
  br label %bb92
bb120:
  br label %bb121
bb121:
  %t462 = load i64, ptr %l19, !tbaa !24
  %t465 = add i64 %t462, 1
  store i64 %t465, ptr %l19, !tbaa !24
  br label %bb78
bb122:
  %t467 = load ptr, ptr %l5, !tbaa !29
  %t469 = getelementptr %"compiler/msgs:Nearest", ptr %t467, i32 0, i32 1
  %t470 = load { i64, ptr }, ptr %t469, !tbaa !27
  store { i64, ptr } %t470, ptr %l242, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t472, 0
  store i64 %t473, ptr %l243, !tbaa !24
  %t474 = load i64, ptr %l243, !tbaa !24
  %t475 = mul i64 %t474, 1
  %t476 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t475)
  %t477 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t476, 1
  store { i64, ptr } %t478, ptr %l244, !tbaa !27
  %t479 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !27
  %t481 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = load i64, ptr %l243, !tbaa !24
  %t484 = mul i64 %t483, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t480, ptr %t482, i64 %t484, i1 false)
  %t485 = load { i64, ptr }, ptr %l244, !tbaa !27
  store { i64, ptr } %t485, ptr %l242, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t486 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t486, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t2, ptr %t3, i32 %t5)
  store ptr %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i32, ptr %l2, !tbaa !23
  store i32 %t10, ptr %l9, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store %"compiler/source:Span" %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load i32, ptr %l9, !tbaa !23
  %t19 = load %"compiler/source:Span", ptr %l12
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v2, ptr %t16, ptr %t17, i32 %t18, %"compiler/source:Span" %t19)
  store ptr %t20, ptr %l13
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l13, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca i64
  %l29 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca { i64, ptr }
  %l68 = alloca i64
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l90 = alloca i32
  %l92 = alloca i32
  %l94 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l106 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca %"compiler/typed:Text"
  %rv = alloca ptr
  %t94 = alloca { i64, [2 x i64] }, align 8
  %t123 = alloca { i64, [2 x i64] }, align 8
  %t178 = alloca { i64, [2 x i64] }, align 8
  %t186 = alloca { i64, [5 x i64] }, align 8
  %t219 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  store ptr %a2, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l17, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eLen_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l19
  br label %bb3
bb3:
  %t11 = load i64, ptr %l17, !tbaa !24
  %t12 = load i64, ptr %l19, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eAt_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v1, ptr %v1, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l24
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l24, !tbaa !29
  store ptr %t22, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eLen_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v2, ptr %t23)
  store i64 %t25, ptr %l26
  br label %bb8
bb8:
  %t26 = load i64, ptr %l26, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t32 = load i64, ptr %l7, !tbaa !24
  %t34 = sub i64 %t32, 1
  %t37 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eAt_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v2, ptr %v1, ptr %t31, i64 %t34)
  store ptr %t37, ptr %l33
  br label %bb11
bb10:
  %t38 = load ptr, ptr %l6, !tbaa !29
  store ptr %t38, ptr %l29, !tbaa !29
  br label %bb12
bb11:
  %t40 = load ptr, ptr %l33, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l29, !tbaa !29
  store ptr %t41, ptr %l8, !tbaa !29
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l6, !tbaa !29
  store ptr %t46, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t47 = load ptr, ptr %l38, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb15:
  %t50 = load ptr, ptr %l38, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 2}
  %t53 = icmp eq i64 %t51, 0
  store i1 %t53, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l39, !tbaa !21
  store i1 %t54, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t55 = load i1, ptr %l37, !tbaa !21
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { { i64, ptr } }, ptr %t58, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59
  store { i64, ptr } %t60, ptr %l9, !tbaa !27
  %t62 = load ptr, ptr %l8, !tbaa !29
  store ptr %t62, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t63 = load ptr, ptr %l45, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb22
bb20:
  %t66 = load ptr, ptr %l45, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 2}
  %t69 = icmp eq i64 %t67, 0
  store i1 %t69, ptr %l46, !tbaa !21
  br label %bb21
bb21:
  %t70 = load i1, ptr %l46, !tbaa !21
  store i1 %t70, ptr %l42, !tbaa !21
  br label %bb22
bb22:
  %t71 = load i1, ptr %l42, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { { i64, ptr } }, ptr %t74, i32 0, i32 0
  %t76 = load { i64, ptr }, ptr %t75
  %t78 = load ptr, ptr %l8, !tbaa !29
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81
  %t84 = load ptr, ptr %l3, !tbaa !29
  store ptr %t84, ptr %l53, !tbaa !29
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l55, !tbaa !24
  %t92 = call { i64, ptr } @compiler_2fcheck_2ejoinBytes(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t82, { i64, ptr } %t76)
  store { i64, ptr } %t92, ptr %l58
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t93 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 0
  store i64 0, ptr %t95
  %t97 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t93, 0
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 1
  store { { i64, ptr } } %t97, ptr %t98
  %t99 = load { i64, [2 x i64] }, ptr %t94
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t99, ptr %t101
  %t102 = load ptr, ptr %l53, !tbaa !29
  %t103 = load i64, ptr %l55, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eSetAt_H0cacde38b1fa68c0147c90767fcd1b03(ptr %v2, ptr %v2, ptr %t102, i64 %t103, ptr %t101)
  br label %bb26
bb26:
  br label %bb29
bb27:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t106 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v2, ptr %v1, ptr %t105, ptr %t106)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb2
bb30:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eLen_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v2, ptr %t114)
  store i64 %t116, ptr %l68
  br label %bb31
bb31:
  %t117 = load i64, ptr %l68, !tbaa !24
  %t118 = icmp eq i64 %t117, 1
  br i1 %t118, label %bb32, label %bb33
bb32:
  %t120 = load ptr, ptr %l3, !tbaa !29
  %t122 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eAt_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v2, ptr %v2, ptr %t120, i64 0)
  store ptr %t122, ptr %l72
  br label %bb34
bb33:
  store { i64, [2 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [2 x i64] }, ptr %t123, i32 0, i32 0
  store i64 0, ptr %t124
  %t125 = insertvalue { { i64, ptr } } undef, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t126 = getelementptr { i64, [2 x i64] }, ptr %t123, i32 0, i32 1
  store { { i64, ptr } } %t125, ptr %t126
  %t127 = load { i64, [2 x i64] }, ptr %t123
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t127, ptr %t129
  store ptr %t129, ptr %l70, !tbaa !29
  br label %bb35
bb34:
  %t131 = load ptr, ptr %l72, !tbaa !29
  store ptr %t131, ptr %l70, !tbaa !29
  br label %bb35
bb35:
  %t132 = load ptr, ptr %l70, !tbaa !29
  store ptr %t132, ptr %l12, !tbaa !29
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eLen_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v2, ptr %t133)
  store i64 %t135, ptr %l76
  br label %bb36
bb36:
  %t136 = load i64, ptr %l76, !tbaa !24
  %t137 = icmp eq i64 %t136, 1
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t139 = load ptr, ptr %l12, !tbaa !29
  store ptr %t139, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t140 = load ptr, ptr %l79, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb39, label %bb40
bb38:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb41
bb39:
  %t143 = load ptr, ptr %l79, !tbaa !29
  %t144 = load i64, ptr %t143, !range !{i64 0, i64 2}
  %t146 = icmp eq i64 %t144, 0
  store i1 %t146, ptr %l80, !tbaa !21
  br label %bb40
bb40:
  %t147 = load i1, ptr %l80, !tbaa !21
  store i1 %t147, ptr %l78, !tbaa !21
  br label %bb41
bb41:
  %t148 = load i1, ptr %l78, !tbaa !21
  br i1 %t148, label %bb42, label %bb43
bb42:
  %t149 = load ptr, ptr %l12, !tbaa !29
  %t151 = getelementptr { i64, [2 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { { i64, ptr } }, ptr %t151, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152
  store { i64, ptr } %t153, ptr %l13, !tbaa !27
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l85
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  store ptr %t161, ptr %l88, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t162)
  store i32 %t164, ptr %l90
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t165 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = load i32, ptr %l90, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t166, i32 %t167, i64 %t165)
  store i32 %t169, ptr %l92
  br label %bb45
bb45:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t170)
  store ptr %t172, ptr %l94
  br label %bb46
bb46:
  %t173 = load ptr, ptr %l94, !tbaa !29
  %t175 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 2
  %t176 = load i64, ptr %t175, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 0
  store i64 1, ptr %t179
  %t181 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t177, 0
  %t182 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 1
  store { { i64, ptr } } %t181, ptr %t182
  %t183 = load { i64, [2 x i64] }, ptr %t178
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t183, ptr %t185
  store { i64, [5 x i64] } zeroinitializer, ptr %t186
  %t187 = getelementptr { i64, [5 x i64] }, ptr %t186, i32 0, i32 0
  store i64 1, ptr %t187
  %t188 = load %"compiler/source:Span", ptr %l85
  %t189 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t188, 0
  %t190 = load i32, ptr %l92, !tbaa !23
  %t191 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t189, i32 %t190, 1
  %t193 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t191, i64 %t176, 2
  %t195 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t193, ptr %t185, 3
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t186, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t195, ptr %t196
  %t197 = load { i64, [5 x i64] }, ptr %t186
  %t199 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t197, ptr %t199
  store ptr %t199, ptr %rv
  br label %ret
bb47:
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l102
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t202)
  store i32 %t204, ptr %l104
  br label %bb48
bb48:
  %t205 = load ptr, ptr %l3, !tbaa !29
  %t207 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v2, ptr %v2, ptr %t205)
  store { i64, ptr } %t207, ptr %l106
  br label %bb49
bb49:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l1
  %t213 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t208, i32 4, %"compiler/source:Span" %t209)
  store i32 %t213, ptr %l110
  br label %bb50
bb50:
  %t214 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t215 = load i32, ptr %l110, !tbaa !23
  %t216 = call %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v2, ptr %v2, { i64, ptr } %t214, i32 %t215)
  store %"compiler/typed:Text" %t216, ptr %l111
  br label %bb51
bb51:
  %t217 = load %"compiler/typed:Text", ptr %l111
  %t218 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Text" %t217, ptr %t218
  store { i64, [5 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t219, i32 0, i32 0
  store i64 16, ptr %t220
  %t221 = load %"compiler/source:Span", ptr %l102
  %t222 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t221, 0
  %t223 = load i32, ptr %l104, !tbaa !23
  %t224 = insertvalue { %"compiler/source:Span", i32, ptr } %t222, i32 %t223, 1
  %t226 = insertvalue { %"compiler/source:Span", i32, ptr } %t224, ptr %t218, 2
  %t227 = getelementptr { i64, [5 x i64] }, ptr %t219, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t226, ptr %t227
  %t228 = load { i64, [5 x i64] }, ptr %t219
  %t230 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t228, ptr %t230
  store ptr %t230, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValued(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l29 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = getelementptr %"compiler/ast:CaseDecl", ptr %t23, i32 0, i32 4
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  br label %bb7
bb7:
  store ptr %a0, ptr %l20, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/ast:CaseDecl", ptr %t31, i32 0, i32 4
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3b34ae24d6eb5f50_7a213241b294babc)
  unreachable
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/ast:CaseDecl", ptr %t38, i32 0, i32 4
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load ptr, ptr %l20, !tbaa !29
  %t44 = call { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %t42, ptr %t41)
  %t45 = extractvalue { i32, %"compiler/source:Span" } %t44, 1
  %t46 = extractvalue { i32, %"compiler/source:Span" } %t44, 0
  store i32 %t46, ptr %l27
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb12, label %ok.48, !prof !99
ok.48:
  store %"compiler/source:Span" %t45, ptr %l26
  br label %bb11
bb11:
  %t49 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t49, ptr %l19
  br label %bb14
bb12:
  %t50 = load i32, ptr %l27, !tbaa !23
  %t51 = ashr i32 %t50, 16
  %t53 = icmp eq i32 %t51, 1
  store i1 %t53, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca %"compiler/generic:Unmet"
  %l35 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l56 = alloca i64
  %l63 = alloca i32
  %l71 = alloca { i64, ptr }
  %l79 = alloca i1
  %l81 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca i32
  %l95 = alloca i32
  %l102 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca i64
  %l116 = alloca %"compiler/generic:Context"
  %l118 = alloca %"compiler/generic:Context"
  %l131 = alloca i32
  %l139 = alloca { i64, ptr }
  %l145 = alloca i1
  %l147 = alloca ptr
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca { i64, ptr }
  %l154 = alloca %"compiler/diagmsg:Msg"
  %l155 = alloca i64
  %l161 = alloca i1
  %l165 = alloca i1
  %l169 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l173 = alloca %"compiler/source:Span"
  %l177 = alloca { i64, ptr }
  %l179 = alloca %"compiler/diagmsg:Msg"
  %l180 = alloca i64
  %l183 = alloca i1
  %l195 = alloca { i64, ptr }
  %l201 = alloca i1
  %l204 = alloca i1
  %l207 = alloca i1
  %l210 = alloca i32
  %l212 = alloca ptr
  %l214 = alloca ptr
  %l219 = alloca i32
  %l223 = alloca i32
  %l227 = alloca i64
  %l230 = alloca [1 x i32]
  %l231 = alloca i64
  %l233 = alloca { i64, ptr }
  %l235 = alloca i1
  %l239 = alloca i1
  %l241 = alloca ptr
  %l243 = alloca %"compiler/source:Span"
  %l244 = alloca ptr
  %l246 = alloca %"compiler/source:Span"
  %l247 = alloca { i64, ptr }
  %l248 = alloca %"compiler/diagmsg:Msg"
  %l249 = alloca i64
  %l254 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l258 = alloca i64
  %l259 = alloca { i64, ptr }
  %l261 = alloca i64
  %l263 = alloca i64
  %l264 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l281 = alloca %"compiler/generic:Unmet"
  %l284 = alloca i1
  %l286 = alloca ptr
  %l288 = alloca %"compiler/source:Span"
  %l291 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l297 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l302 = alloca %"compiler/diagmsg:Msg"
  %l303 = alloca i64
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %t181 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l35, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l35, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t19 = load ptr, ptr %l41, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l41, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 5}
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l42, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l42, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t35, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [6 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t41, i32 0, i32 2
  %t43 = load { i64, ptr }, ptr %t42
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  br label %bb11
bb10:
  br label %bb168
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TypeDecl", ptr %t50, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t57 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t48, i64 %t49, i32 %t53)
  store i64 %t57, ptr %l56
  br label %bb12
bb12:
  %t58 = load i64, ptr %l56, !tbaa !24
  store i64 %t58, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t59, 0
  br i1 %t61, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t72 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t66, i64 %t67, i64 %t68)
  store i32 %t72, ptr %l63
  br label %bb16
bb16:
  %t73 = load i32, ptr %l63, !tbaa !23
  store i32 %t73, ptr %l8, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l11, !tbaa !24
  br label %bb17
bb17:
  %t80 = load i64, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l11, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb18, label %bb19
bb18:
  br label %bb32
bb19:
  br label %bb20
bb20:
  %t88 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t88, ptr %l71, !tbaa !27
  %t89 = load i64, ptr %l10, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 %t89
  %t94 = load ptr, ptr %t93, !tbaa !39
  store ptr %t94, ptr %l12, !tbaa !29
  %t96 = load ptr, ptr %l12, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Func", ptr %t96, i32 0, i32 3
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Sig", ptr %t99, i32 0, i32 7
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb21, label %bb22
bb21:
  %t108 = load ptr, ptr %l12, !tbaa !29
  %t110 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v1, ptr %t108)
  store i1 %t110, ptr %l81
  br label %bb23
bb22:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb24
bb23:
  %t111 = load i1, ptr %l81, !tbaa !21
  %t112 = xor i1 %t111, true
  store i1 %t112, ptr %l79, !tbaa !21
  br label %bb24
bb24:
  %t114 = load i1, ptr %l79, !tbaa !21
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l84, !tbaa !29
  %t119 = load i32, ptr %l8, !tbaa !23
  store i32 %t119, ptr %l85, !tbaa !23
  %t120 = load ptr, ptr %l12, !tbaa !29
  store ptr %t120, ptr %l86, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  store ptr %t126, ptr %l89, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load i32, ptr %l8, !tbaa !23
  %t134 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l93
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t135 = load ptr, ptr %l89, !tbaa !29
  %t136 = load i32, ptr %l93, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t137, ptr %l94
  br label %bb28
bb28:
  %t138 = load ptr, ptr %l84, !tbaa !29
  %t139 = load i32, ptr %l85, !tbaa !23
  %t140 = load ptr, ptr %l86, !tbaa !29
  %t141 = load i32, ptr %l94, !tbaa !23
  %t142 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTraitSig(ptr %v0, ptr %v1, ptr %t138, i32 %t139, ptr %t140, i32 %t141)
  store i32 %t142, ptr %l95
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb17
bb32:
  %t148 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t152 = icmp eq i64 %t150, 0
  br i1 %t152, label %bb33, label %bb34
bb33:
  %t154 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t158 = icmp eq i64 %t156, 0
  store i1 %t158, ptr %l102, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb35
bb35:
  %t160 = load i1, ptr %l102, !tbaa !21
  br i1 %t160, label %bb36, label %bb37
bb36:
  br label %ret
bb37:
  br label %bb38
bb38:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l1, !tbaa !24
  %t163 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t161, i64 -1, i64 %t162, i32 %t163, i32 0)
  store ptr %t167, ptr %l109
  br label %bb39
bb39:
  %t168 = load ptr, ptr %l109, !tbaa !29
  store ptr %t168, ptr %l110, !tbaa !29
  %t170 = call ptr @__olang_scope_hold(ptr %v0)
  %t171 = ptrtoint ptr %t170 to i64
  store i64 %t171, ptr %l111, !tbaa !24
  %t172 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t172, label %bb40, label %bb41
bb40:
  %t174 = call ptr @__olang_region_make(ptr %v0)
  %t175 = ptrtoint ptr %t174 to i64
  store i64 %t175, ptr %l111, !tbaa !24
  br label %bb41
bb41:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t180 = load i32, ptr %l8, !tbaa !23
  %t182 = load i64, ptr %l111
  %t183 = inttoptr i64 %t182 to ptr
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t181, ptr %v0, ptr %t183, ptr %t179, i32 %t180)
  call void @llvm.memmove.p0.p0.i64(ptr %l116, ptr %t181, i64 160, i1 false)
  br label %bb42
bb42:
  %t186 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t186, label %bb43, label %bb44
bb43:
  %t188 = load i64, ptr %l111
  %t189 = inttoptr i64 %t188 to ptr
  %t190 = getelementptr %"compiler/generic:Context", ptr %l116, i32 0, i32 3
  %t191 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t190, i32 0, i32 2
  %t192 = load { i64, ptr }, ptr %t191
  %t193 = extractvalue { i64, ptr } %t192, 1
  %t194 = call ptr @__olang_region_or(ptr %t193, ptr null)
  %t195 = call ptr @__olang_region_home(ptr %t194)
  %t196 = icmp ne ptr %t195, null
  %t197 = select i1 %t196, ptr %t195, ptr null
  %t198 = getelementptr %"compiler/generic:Context", ptr %l116, i32 0, i32 3
  %t199 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t198, i32 0, i32 1
  %t200 = load { i64, ptr }, ptr %t199
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = call ptr @__olang_region_or(ptr %t201, ptr null)
  %t203 = call ptr @__olang_region_home(ptr %t202)
  %t204 = icmp ne ptr %t203, null
  %t205 = select i1 %t204, ptr %t203, ptr %t197
  %t206 = getelementptr %"compiler/generic:Context", ptr %l116, i32 0, i32 3
  %t207 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t206, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = call ptr @__olang_region_home(ptr %t210)
  %t212 = icmp ne ptr %t211, null
  %t213 = select i1 %t212, ptr %t211, ptr %t205
  %t214 = getelementptr %"compiler/generic:Context", ptr %l116, i32 0, i32 2
  %t215 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t214, i32 0, i32 2
  %t216 = load { i64, ptr }, ptr %t215
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = call ptr @__olang_region_or(ptr %t217, ptr null)
  %t219 = call ptr @__olang_region_home(ptr %t218)
  %t220 = icmp ne ptr %t219, null
  %t221 = select i1 %t220, ptr %t219, ptr %t213
  %t222 = getelementptr %"compiler/generic:Context", ptr %l116, i32 0, i32 2
  %t223 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t222, i32 0, i32 1
  %t224 = load { i64, ptr }, ptr %t223
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = call ptr @__olang_region_home(ptr %t226)
  %t228 = icmp ne ptr %t227, null
  %t229 = select i1 %t228, ptr %t227, ptr %t221
  %t230 = getelementptr %"compiler/generic:Context", ptr %l116, i32 0, i32 2
  %t231 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t230, i32 0, i32 0
  %t232 = load { i64, ptr }, ptr %t231
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = call ptr @__olang_region_or(ptr %t233, ptr null)
  %t235 = call ptr @__olang_region_home(ptr %t234)
  %t236 = icmp ne ptr %t235, null
  %t237 = select i1 %t236, ptr %t235, ptr %t229
  call void @__olang_region_settle_in(ptr %t189, ptr %t237)
  br label %bb44
bb44:
  %t238 = load ptr, ptr %l110, !tbaa !29
  %t239 = getelementptr %"compiler/check:frame", ptr %t238, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l118, ptr %t239, i64 160, i1 false)
  %t240 = load ptr, ptr %l110, !tbaa !29
  %t241 = getelementptr %"compiler/check:frame", ptr %t240, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t241, ptr %l116, i64 160, i1 false)
  %t242 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t242, label %bb45, label %bb46
bb45:
  %t244 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 3
  %t245 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t244, i32 0, i32 2
  %t246 = load { i64, ptr }, ptr %t245
  %t247 = extractvalue { i64, ptr } %t246, 1
  %t248 = call ptr @__olang_region_or(ptr %t247, ptr null)
  %t249 = call ptr @__olang_region_home(ptr %t248)
  %t250 = icmp ne ptr %t249, null
  %t251 = select i1 %t250, ptr %t249, ptr null
  %t252 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 3
  %t253 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t252, i32 0, i32 1
  %t254 = load { i64, ptr }, ptr %t253
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = call ptr @__olang_region_or(ptr %t255, ptr null)
  %t257 = call ptr @__olang_region_home(ptr %t256)
  %t258 = icmp ne ptr %t257, null
  %t259 = select i1 %t258, ptr %t257, ptr %t251
  %t260 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 3
  %t261 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t260, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261
  %t263 = extractvalue { i64, ptr } %t262, 1
  %t264 = call ptr @__olang_region_or(ptr %t263, ptr null)
  %t265 = call ptr @__olang_region_home(ptr %t264)
  %t266 = icmp ne ptr %t265, null
  %t267 = select i1 %t266, ptr %t265, ptr %t259
  %t268 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 2
  %t269 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t268, i32 0, i32 2
  %t270 = load { i64, ptr }, ptr %t269
  %t271 = extractvalue { i64, ptr } %t270, 1
  %t272 = call ptr @__olang_region_or(ptr %t271, ptr null)
  %t273 = call ptr @__olang_region_home(ptr %t272)
  %t274 = icmp ne ptr %t273, null
  %t275 = select i1 %t274, ptr %t273, ptr %t267
  %t276 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 2
  %t277 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t276, i32 0, i32 1
  %t278 = load { i64, ptr }, ptr %t277
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = call ptr @__olang_region_or(ptr %t279, ptr null)
  %t281 = call ptr @__olang_region_home(ptr %t280)
  %t282 = icmp ne ptr %t281, null
  %t283 = select i1 %t282, ptr %t281, ptr %t275
  %t284 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 2
  %t285 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t284, i32 0, i32 0
  %t286 = load { i64, ptr }, ptr %t285
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = call ptr @__olang_region_or(ptr %t287, ptr null)
  %t289 = call ptr @__olang_region_home(ptr %t288)
  %t290 = icmp ne ptr %t289, null
  %t291 = select i1 %t290, ptr %t289, ptr %t283
  call void @__olang_region_drop(ptr %t291)
  store %"compiler/generic:Context" zeroinitializer, ptr %l118
  br label %bb46
bb46:
  %t292 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e2
  br i1 %t292, label %bb47, label %bb48
bb47:
  %t294 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 2
  %t295 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t294, i32 0, i32 2
  %t296 = load { i64, ptr }, ptr %t295
  %t297 = extractvalue { i64, ptr } %t296, 1
  %t298 = call ptr @__olang_region_or(ptr %t297, ptr null)
  %t299 = call ptr @__olang_region_home(ptr %t298)
  %t300 = icmp ne ptr %t299, null
  %t301 = select i1 %t300, ptr %t299, ptr null
  %t302 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t294, i32 0, i32 1
  %t303 = load { i64, ptr }, ptr %t302
  %t304 = extractvalue { i64, ptr } %t303, 1
  %t305 = call ptr @__olang_region_or(ptr %t304, ptr null)
  %t306 = call ptr @__olang_region_home(ptr %t305)
  %t307 = icmp ne ptr %t306, null
  %t308 = select i1 %t307, ptr %t306, ptr %t301
  %t309 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t294, i32 0, i32 0
  %t310 = load { i64, ptr }, ptr %t309
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = call ptr @__olang_region_or(ptr %t311, ptr null)
  %t313 = call ptr @__olang_region_home(ptr %t312)
  %t314 = icmp ne ptr %t313, null
  %t315 = select i1 %t314, ptr %t313, ptr %t308
  call void @__olang_region_drop(ptr %t315)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t294
  br label %bb48
bb48:
  %t316 = load i1, ptr @olang_2esole_2ecompiler_2fgeneric_3aContext_2e3
  br i1 %t316, label %bb49, label %bb50
bb49:
  %t318 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 3
  %t319 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t318, i32 0, i32 2
  %t320 = load { i64, ptr }, ptr %t319
  %t321 = extractvalue { i64, ptr } %t320, 1
  %t322 = call ptr @__olang_region_or(ptr %t321, ptr null)
  %t323 = call ptr @__olang_region_home(ptr %t322)
  %t324 = icmp ne ptr %t323, null
  %t325 = select i1 %t324, ptr %t323, ptr null
  %t326 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t318, i32 0, i32 1
  %t327 = load { i64, ptr }, ptr %t326
  %t328 = extractvalue { i64, ptr } %t327, 1
  %t329 = call ptr @__olang_region_or(ptr %t328, ptr null)
  %t330 = call ptr @__olang_region_home(ptr %t329)
  %t331 = icmp ne ptr %t330, null
  %t332 = select i1 %t331, ptr %t330, ptr %t325
  %t333 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t318, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333
  %t335 = extractvalue { i64, ptr } %t334, 1
  %t336 = call ptr @__olang_region_or(ptr %t335, ptr null)
  %t337 = call ptr @__olang_region_home(ptr %t336)
  %t338 = icmp ne ptr %t337, null
  %t339 = select i1 %t338, ptr %t337, ptr %t332
  call void @__olang_region_drop(ptr %t339)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t318
  br label %bb50
bb50:
  %t340 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t340, label %bb51, label %bb52
bb51:
  %t342 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 2
  %t343 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t342, i32 0, i32 0
  %t344 = load { i64, ptr }, ptr %t343
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = extractvalue { i64, ptr } %t344, 1
  call void @__olang_region_release_part(ptr %t346, i64 %t345)
  store { i64, ptr } zeroinitializer, ptr %t343
  br label %bb52
bb52:
  %t347 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t347, label %bb53, label %bb54
bb53:
  %t349 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 2
  %t350 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t349, i32 0, i32 1
  %t351 = load { i64, ptr }, ptr %t350
  %t352 = extractvalue { i64, ptr } %t351, 0
  %t353 = extractvalue { i64, ptr } %t351, 1
  call void @__olang_region_release_part(ptr %t353, i64 %t352)
  store { i64, ptr } zeroinitializer, ptr %t350
  br label %bb54
bb54:
  %t354 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t354, label %bb55, label %bb56
bb55:
  %t356 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 2
  %t357 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t356, i32 0, i32 2
  %t358 = load { i64, ptr }, ptr %t357
  %t359 = extractvalue { i64, ptr } %t358, 0
  %t360 = extractvalue { i64, ptr } %t358, 1
  call void @__olang_region_release_part(ptr %t360, i64 %t359)
  store { i64, ptr } zeroinitializer, ptr %t357
  br label %bb56
bb56:
  %t361 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0
  br i1 %t361, label %bb57, label %bb58
bb57:
  %t363 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 3
  %t364 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t363, i32 0, i32 0
  %t365 = load { i64, ptr }, ptr %t364
  %t366 = extractvalue { i64, ptr } %t365, 0
  %t367 = extractvalue { i64, ptr } %t365, 1
  call void @__olang_region_release_part(ptr %t367, i64 %t366)
  store { i64, ptr } zeroinitializer, ptr %t364
  br label %bb58
bb58:
  %t368 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1
  br i1 %t368, label %bb59, label %bb60
bb59:
  %t370 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 3
  %t371 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t370, i32 0, i32 1
  %t372 = load { i64, ptr }, ptr %t371
  %t373 = extractvalue { i64, ptr } %t372, 0
  %t374 = extractvalue { i64, ptr } %t372, 1
  call void @__olang_region_release_part(ptr %t374, i64 %t373)
  store { i64, ptr } zeroinitializer, ptr %t371
  br label %bb60
bb60:
  %t375 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2
  br i1 %t375, label %bb61, label %bb62
bb61:
  %t377 = getelementptr %"compiler/generic:Context", ptr %l118, i32 0, i32 3
  %t378 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t377, i32 0, i32 2
  %t379 = load { i64, ptr }, ptr %t378
  %t380 = extractvalue { i64, ptr } %t379, 0
  %t381 = extractvalue { i64, ptr } %t379, 1
  call void @__olang_region_release_part(ptr %t381, i64 %t380)
  store { i64, ptr } zeroinitializer, ptr %t378
  br label %bb62
bb62:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/check:Checker", ptr %t382, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !29
  %t386 = load i32, ptr %l8, !tbaa !23
  %t389 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t389, ptr %l131
  br label %bb63
bb63:
  %t390 = load i32, ptr %l131, !tbaa !23
  store i32 %t390, ptr %l14, !tbaa !23
  store i1 false, ptr %l15, !tbaa !21
  %t391 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t391, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t393 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t393, 0
  store i64 %t395, ptr %l18, !tbaa !24
  br label %bb64
bb64:
  %t397 = load i64, ptr %l17, !tbaa !24
  %t398 = load i64, ptr %l18, !tbaa !24
  %t401 = icmp slt i64 %t397, %t398
  %t403 = xor i1 %t401, true
  br i1 %t403, label %bb65, label %bb66
bb65:
  br label %bb78
bb66:
  br label %bb67
bb67:
  %t405 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t405, ptr %l139, !tbaa !27
  %t406 = load i64, ptr %l17, !tbaa !24
  %t408 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr ptr, ptr %t409, i64 %t406
  %t411 = load ptr, ptr %t410, !tbaa !39
  store ptr %t411, ptr %l19, !tbaa !29
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load i64, ptr %l1, !tbaa !24
  %t415 = load ptr, ptr %l19, !tbaa !29
  %t419 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t413, i64 %t414, ptr %t415)
  store i1 %t419, ptr %l145
  br label %bb68
bb68:
  %t420 = load i1, ptr %l145, !tbaa !21
  %t421 = xor i1 %t420, true
  br i1 %t421, label %bb69, label %bb70
bb69:
  %t423 = load ptr, ptr %l0, !tbaa !29
  store ptr %t423, ptr %l147, !tbaa !29
  %t424 = load ptr, ptr %l19, !tbaa !29
  %t426 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t424)
  store %"compiler/source:Span" %t426, ptr %l149
  br label %bb71
bb70:
  br label %bb76
bb71:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l150, !tbaa !29
  %t428 = load ptr, ptr %l19, !tbaa !29
  %t430 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t428)
  store %"compiler/source:Span" %t430, ptr %l152
  br label %bb72
bb72:
  %t431 = load ptr, ptr %l150, !tbaa !29
  %t432 = load %"compiler/source:Span", ptr %l152
  %t433 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t431, %"compiler/source:Span" %t432)
  store { i64, ptr } %t433, ptr %l153
  br label %bb73
bb73:
  %t434 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t435 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %v0, { i64, ptr } %t434)
  store %"compiler/diagmsg:Msg" %t435, ptr %l154
  br label %bb74
bb74:
  %t436 = load ptr, ptr %l147, !tbaa !29
  %t437 = load %"compiler/source:Span", ptr %l149
  %t438 = load %"compiler/diagmsg:Msg", ptr %l154
  %t439 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t436, %"compiler/source:Span" %t437, %"compiler/diagmsg:Msg" %t438)
  store i64 %t439, ptr %l155
  br label %bb75
bb75:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t440 = load i64, ptr %l17, !tbaa !24
  %t443 = add i64 %t440, 1
  store i64 %t443, ptr %l17, !tbaa !24
  br label %bb64
bb78:
  %t445 = load i1, ptr %l15, !tbaa !21
  %t447 = xor i1 %t445, true
  br i1 %t447, label %bb79, label %bb80
bb79:
  %t449 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t449, 0
  %t453 = icmp sgt i64 %t451, 0
  store i1 %t453, ptr %l161, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb81
bb81:
  %t455 = load i1, ptr %l161, !tbaa !21
  br i1 %t455, label %bb82, label %bb83
bb82:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i32, ptr %l8, !tbaa !23
  %t458 = load i32, ptr %l14, !tbaa !23
  %t462 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t456, i32 %t457, i32 %t458, i64 0)
  store i1 %t462, ptr %l169
  br label %bb84
bb83:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb85
bb84:
  %t463 = load i1, ptr %l169, !tbaa !21
  store i1 %t463, ptr %l165, !tbaa !21
  br label %bb85
bb85:
  %t464 = load i1, ptr %l165, !tbaa !21
  br i1 %t464, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s13
  %t465 = load ptr, ptr %l0, !tbaa !29
  store ptr %t465, ptr %l170, !tbaa !29
  %t466 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t466, ptr %l171, !tbaa !27
  %t467 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr ptr, ptr %t468, i64 0
  %t470 = load ptr, ptr %t469, !tbaa !39
  %t472 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t470)
  store %"compiler/source:Span" %t472, ptr %l173
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load ptr, ptr %l2, !tbaa !29
  %t476 = getelementptr %"compiler/ast:TypeDecl", ptr %t474, i32 0, i32 0
  %t477 = load i32, ptr %t476, !tbaa !23
  %t480 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t473, i32 %t477)
  store { i64, ptr } %t480, ptr %l177
  br label %bb89
bb89:
  %t481 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t483 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %s13, ptr %v0, { i64, ptr } %t481)
  store %"compiler/diagmsg:Msg" %t483, ptr %l179
  br label %bb90
bb90:
  %t484 = load ptr, ptr %l170, !tbaa !29
  %t485 = load %"compiler/source:Span", ptr %l173
  %t486 = load %"compiler/diagmsg:Msg", ptr %l179
  %t487 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t484, %"compiler/source:Span" %t485, %"compiler/diagmsg:Msg" %t486)
  store i64 %t487, ptr %l180
  br label %bb91
bb91:
  store i1 true, ptr %l15, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb92
bb92:
  %t488 = load i1, ptr %l15, !tbaa !21
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb93, label %bb94
bb93:
  %t492 = load ptr, ptr %l2, !tbaa !29
  %t494 = getelementptr %"compiler/ast:TypeDecl", ptr %t492, i32 0, i32 1
  %t495 = load { i64, ptr }, ptr %t494, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t499 = icmp eq i64 %t497, 0
  store i1 %t499, ptr %l183, !tbaa !21
  br label %bb95
bb94:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb95
bb95:
  %t501 = load i1, ptr %l183, !tbaa !21
  store i1 %t501, ptr %l20, !tbaa !21
  %t502 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t502, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t504 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t504, 0
  store i64 %t506, ptr %l23, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s15
  %t508 = load i64, ptr %l22, !tbaa !24
  %t509 = load i64, ptr %l23, !tbaa !24
  %t512 = icmp slt i64 %t508, %t509
  %t514 = xor i1 %t512, true
  br i1 %t514, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s15)
  br label %bb166
bb98:
  br label %bb99
bb99:
  %t516 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t516, ptr %l195, !tbaa !27
  %t517 = load i64, ptr %l22, !tbaa !24
  %t519 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr ptr, ptr %t520, i64 %t517
  %t522 = load ptr, ptr %t521, !tbaa !39
  store ptr %t522, ptr %l24, !tbaa !29
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load i64, ptr %l1, !tbaa !24
  %t526 = load ptr, ptr %l24, !tbaa !29
  %t530 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t524, i64 %t525, ptr %t526)
  store i1 %t530, ptr %l201
  br label %bb100
bb100:
  %t531 = load i1, ptr %l201, !tbaa !21
  store i1 %t531, ptr %l25, !tbaa !21
  %t532 = load i1, ptr %l25, !tbaa !21
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb101, label %bb102
bb101:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load ptr, ptr %l24, !tbaa !29
  %t540 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %t536, ptr %t537, i1 true)
  store i1 %t540, ptr %l207
  br label %bb103
bb102:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb104
bb103:
  %t541 = load i1, ptr %l207, !tbaa !21
  %t542 = xor i1 %t541, true
  store i1 %t542, ptr %l204, !tbaa !21
  br label %bb104
bb104:
  %t544 = load i1, ptr %l204, !tbaa !21
  br i1 %t544, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s15)
  br label %bb165
bb106:
  br label %bb107
bb107:
  %t545 = load i1, ptr %l25, !tbaa !21
  br i1 %t545, label %bb108, label %bb109
bb108:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/check:Checker", ptr %t547, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !29
  store ptr %t550, ptr %l212, !tbaa !29
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t551)
  store ptr %t553, ptr %l214
  br label %bb110
bb109:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l24, !tbaa !29
  %t559 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t554, ptr %t555)
  store i32 %t559, ptr %l223
  br label %bb112
bb110:
  %t560 = load ptr, ptr %l214, !tbaa !29
  %t562 = getelementptr %"compiler/check:frame", ptr %t560, i32 0, i32 4
  %t563 = load ptr, ptr %l24, !tbaa !29
  %t565 = load ptr, ptr %l212, !tbaa !29
  %t568 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t565, ptr %t562, ptr %t563)
  store i32 %t568, ptr %l219
  br label %bb111
bb111:
  %t569 = load i32, ptr %l219, !tbaa !23
  store i32 %t569, ptr %l210, !tbaa !23
  br label %bb113
bb112:
  %t570 = load i32, ptr %l223, !tbaa !23
  store i32 %t570, ptr %l210, !tbaa !23
  br label %bb113
bb113:
  %t571 = load i32, ptr %l210, !tbaa !23
  store i32 %t571, ptr %l26, !tbaa !23
  %t572 = load i32, ptr %l26, !tbaa !23
  %t573 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t576 = icmp eq i32 %t572, %t573
  br i1 %t576, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s15)
  br label %bb165
bb115:
  br label %bb116
bb116:
  %t578 = call ptr @__olang_scope_hold(ptr %s15)
  %t579 = ptrtoint ptr %t578 to i64
  store i64 %t579, ptr %l227, !tbaa !24
  %t580 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2etraitHeader_2elocal_2e27
  br i1 %t580, label %bb117, label %bb118
bb117:
  %t582 = call ptr @__olang_region_make(ptr %s15)
  %t583 = ptrtoint ptr %t582 to i64
  store i64 %t583, ptr %l227, !tbaa !24
  br label %bb118
bb118:
  %t584 = load i32, ptr %l26, !tbaa !23
  %t586 = insertvalue [1 x i32] undef, i32 %t584, 0
  store [1 x i32] %t586, ptr %l230
  %t587 = call ptr @__olang_scope_hold(ptr %s15)
  %t588 = ptrtoint ptr %t587 to i64
  store i64 %t588, ptr %l231, !tbaa !24
  %t589 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2etraitHeader_2elocal_2e27
  br i1 %t589, label %bb119, label %bb120
bb119:
  %t591 = call ptr @__olang_region_make(ptr %s15)
  %t592 = ptrtoint ptr %t591 to i64
  store i64 %t592, ptr %l231, !tbaa !24
  br label %bb120
bb120:
  %t593 = mul i64 1, 4
  %t594 = load i64, ptr %l231
  %t595 = inttoptr i64 %t594 to ptr
  %t596 = call ptr @__olang_held_alloc(ptr %t595, i64 %t593)
  %t597 = insertvalue { i64, ptr } undef, i64 1, 0
  %t598 = insertvalue { i64, ptr } %t597, ptr %t596, 1
  store { i64, ptr } %t598, ptr %l233, !tbaa !27
  %t599 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = mul i64 1, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t600, ptr %l230, i64 %t601, i1 false)
  %t602 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t602, ptr %l27, !tbaa !27
  %t603 = load i1, ptr %l25, !tbaa !21
  br i1 %t603, label %bb121, label %bb122
bb121:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = getelementptr %"compiler/check:Checker", ptr %t605, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !29
  %t609 = load i32, ptr %l26, !tbaa !23
  %t612 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t608, i32 %t609)
  store i1 %t612, ptr %l239
  br label %bb123
bb122:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb124
bb123:
  %t613 = load i1, ptr %l239, !tbaa !21
  %t614 = xor i1 %t613, true
  store i1 %t614, ptr %l235, !tbaa !21
  br label %bb124
bb124:
  %t616 = load i1, ptr %l235, !tbaa !21
  br i1 %t616, label %bb125, label %bb126
bb125:
  %t617 = load ptr, ptr %l0, !tbaa !29
  store ptr %t617, ptr %l241, !tbaa !29
  %t618 = load ptr, ptr %l24, !tbaa !29
  %t620 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t618)
  store %"compiler/source:Span" %t620, ptr %l243
  br label %bb127
bb126:
  br label %bb132
bb127:
  %t621 = load ptr, ptr %l0, !tbaa !29
  store ptr %t621, ptr %l244, !tbaa !29
  %t622 = load ptr, ptr %l24, !tbaa !29
  %t624 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t622)
  store %"compiler/source:Span" %t624, ptr %l246
  br label %bb128
bb128:
  %t625 = load ptr, ptr %l244, !tbaa !29
  %t626 = load %"compiler/source:Span", ptr %l246
  %t627 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t625, %"compiler/source:Span" %t626)
  store { i64, ptr } %t627, ptr %l247
  br label %bb129
bb129:
  %t628 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t629 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %v0, { i64, ptr } %t628)
  store %"compiler/diagmsg:Msg" %t629, ptr %l248
  br label %bb130
bb130:
  %t630 = load ptr, ptr %l241, !tbaa !29
  %t631 = load %"compiler/source:Span", ptr %l243
  %t632 = load %"compiler/diagmsg:Msg", ptr %l248
  %t633 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t630, %"compiler/source:Span" %t631, %"compiler/diagmsg:Msg" %t632)
  store i64 %t633, ptr %l249
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s15)
  br label %bb165
bb132:
  %t634 = load i1, ptr %l25, !tbaa !21
  br i1 %t634, label %bb133, label %bb134
bb133:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t638 = getelementptr %"compiler/check:Checker", ptr %t636, i32 0, i32 1
  %t639 = load ptr, ptr %t638, !tbaa !29
  %t640 = load i32, ptr %l26, !tbaa !23
  %t643 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v0, ptr %t639, i32 %t640)
  store { i64, ptr } %t643, ptr %l254
  br label %bb135
bb134:
  br label %bb142
bb135:
  %t644 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t644, ptr %l255, !tbaa !27
  %t645 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2etraitHeader_2elocal_2e27
  br i1 %t645, label %bb136, label %bb137
bb136:
  %t647 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t647, ptr %l257, !tbaa !27
  %t648 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t648, 0
  store i64 %t649, ptr %l258, !tbaa !24
  %t650 = load i64, ptr %l258, !tbaa !24
  %t651 = mul i64 %t650, 4
  %t652 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t651)
  %t653 = insertvalue { i64, ptr } undef, i64 %t650, 0
  %t654 = insertvalue { i64, ptr } %t653, ptr %t652, 1
  store { i64, ptr } %t654, ptr %l259, !tbaa !27
  %t655 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t656 = load ptr, ptr %t655, !tbaa !27
  %t657 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t658 = load ptr, ptr %t657, !tbaa !27
  %t659 = load i64, ptr %l258, !tbaa !24
  %t660 = mul i64 %t659, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t656, ptr %t658, i64 %t660, i1 false)
  %t661 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t661, ptr %l27, !tbaa !27
  %t662 = load { i64, ptr }, ptr %l257
  %t663 = extractvalue { i64, ptr } %t662, 1
  call void @__olang_region_release(ptr %t663)
  store { i64, ptr } zeroinitializer, ptr %l257
  br label %bb138
bb137:
  %t664 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t664, 0
  %t666 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t666, 0
  store i64 %t667, ptr %l261, !tbaa !24
  %t669 = load i64, ptr %l261, !tbaa !24
  %t670 = icmp eq i64 %t665, %t669
  br i1 %t670, label %bb139, label %bb140
bb138:
  br label %bb142
bb139:
  %t672 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t673 = load ptr, ptr %t672, !tbaa !27
  %t674 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t675 = load ptr, ptr %t674, !tbaa !27
  %t676 = load i64, ptr %l261, !tbaa !24
  %t677 = mul i64 %t676, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t673, ptr %t675, i64 %t677, i1 false)
  br label %bb141
bb140:
  %t678 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t678, 0
  store i64 %t679, ptr %l263, !tbaa !24
  %t680 = load i64, ptr %l263, !tbaa !24
  %t681 = mul i64 %t680, 4
  %t682 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t681)
  %t683 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t684 = insertvalue { i64, ptr } %t683, ptr %t682, 1
  store { i64, ptr } %t684, ptr %l264, !tbaa !27
  %t685 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t686 = load ptr, ptr %t685, !tbaa !27
  %t687 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t688 = load ptr, ptr %t687, !tbaa !27
  %t689 = load i64, ptr %l263, !tbaa !24
  %t690 = mul i64 %t689, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t686, ptr %t688, i64 %t690, i1 false)
  %t691 = load { i64, ptr }, ptr %l264, !tbaa !27
  store { i64, ptr } %t691, ptr %l27, !tbaa !27
  br label %bb141
bb141:
  br label %bb138
bb142:
  %t692 = load i1, ptr %l20, !tbaa !21
  %t694 = xor i1 %t692, true
  br i1 %t694, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s15)
  br label %bb165
bb144:
  br label %bb145
bb145:
  %t696 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t696, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t698 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t698, 0
  store i64 %t700, ptr %l30, !tbaa !24
  br label %bb146
bb146:
  %t702 = load i64, ptr %l29, !tbaa !24
  %t703 = load i64, ptr %l30, !tbaa !24
  %t706 = icmp slt i64 %t702, %t703
  %t708 = xor i1 %t706, true
  br i1 %t708, label %bb147, label %bb148
bb147:
  br label %bb164
bb148:
  br label %bb149
bb149:
  %t710 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t710, ptr %l274, !tbaa !27
  %t711 = load i64, ptr %l29, !tbaa !24
  %t713 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !27
  %t715 = getelementptr i32, ptr %t714, i64 %t711
  %t716 = load i32, ptr %t715, !tbaa !33
  store i32 %t716, ptr %l31, !tbaa !23
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t720 = getelementptr %"compiler/check:Checker", ptr %t718, i32 0, i32 1
  %t721 = load ptr, ptr %t720, !tbaa !29
  %t722 = load i32, ptr %l31, !tbaa !23
  %t723 = load i32, ptr %l14, !tbaa !23
  %t727 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t721, i32 %t722, i32 %t723, i1 false, i64 0)
  store %"compiler/generic:Unmet" %t727, ptr %l281
  br label %bb150
bb150:
  %t728 = load %"compiler/generic:Unmet", ptr %l281
  store %"compiler/generic:Unmet" %t728, ptr %l32
  %t729 = getelementptr %"compiler/generic:Unmet", ptr %l32, i32 0, i32 0
  %t730 = load i64, ptr %t729, !tbaa !24
  %t732 = icmp sge i64 %t730, 0
  br i1 %t732, label %bb151, label %bb152
bb151:
  %t734 = getelementptr %"compiler/generic:Unmet", ptr %l32, i32 0, i32 3
  %t735 = load i1, ptr %t734, !tbaa !21
  store i1 %t735, ptr %l284, !tbaa !21
  br label %bb153
bb152:
  store i1 false, ptr %l284, !tbaa !21
  br label %bb153
bb153:
  %t737 = load i1, ptr %l284, !tbaa !21
  br i1 %t737, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s23
  %t738 = load ptr, ptr %l0, !tbaa !29
  store ptr %t738, ptr %l286, !tbaa !29
  %t739 = load ptr, ptr %l24, !tbaa !29
  %t741 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t739)
  store %"compiler/source:Span" %t741, ptr %l288
  br label %bb156
bb155:
  br label %bb162
bb156:
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t743 = load i32, ptr %l31, !tbaa !23
  %t746 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s23, ptr %t742, i32 %t743)
  store { i64, ptr } %t746, ptr %l291
  br label %bb157
bb157:
  %t747 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t747, ptr %l292, !tbaa !27
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = load ptr, ptr %l2, !tbaa !29
  %t751 = getelementptr %"compiler/ast:TypeDecl", ptr %t749, i32 0, i32 0
  %t752 = load i32, ptr %t751, !tbaa !23
  %t755 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s23, ptr %t748, i32 %t752)
  store { i64, ptr } %t755, ptr %l296
  br label %bb158
bb158:
  %t756 = load { i64, ptr }, ptr %l296, !tbaa !27
  store { i64, ptr } %t756, ptr %l297, !tbaa !27
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t758 = getelementptr %"compiler/generic:Unmet", ptr %l32, i32 0, i32 2
  %t759 = load i32, ptr %t758, !tbaa !23
  %t762 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s23, ptr %t757, i32 %t759)
  store { i64, ptr } %t762, ptr %l300
  br label %bb159
bb159:
  %t763 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t764 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t765 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t767 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %s23, ptr %s23, ptr %s23, ptr %v0, { i64, ptr } %t764, { i64, ptr } %t765, { i64, ptr } %t763)
  store %"compiler/diagmsg:Msg" %t767, ptr %l302
  br label %bb160
bb160:
  %t768 = load ptr, ptr %l286, !tbaa !29
  %t769 = load %"compiler/source:Span", ptr %l288
  %t770 = load %"compiler/diagmsg:Msg", ptr %l302
  %t771 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t768, %"compiler/source:Span" %t769, %"compiler/diagmsg:Msg" %t770)
  store i64 %t771, ptr %l303
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s23)
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t772 = load i64, ptr %l29, !tbaa !24
  %t775 = add i64 %t772, 1
  store i64 %t775, ptr %l29, !tbaa !24
  br label %bb146
bb164:
  call void @__olang_scope_close(ptr %s15)
  br label %bb165
bb165:
  %t777 = load i64, ptr %l22, !tbaa !24
  %t780 = add i64 %t777, 1
  store i64 %t780, ptr %l22, !tbaa !24
  br label %bb96
bb166:
  %t782 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t782)
  br label %bb167
bb167:
  br label %bb173
bb168:
  br i1 true, label %bb169, label %bb170
bb169:
  br label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb173
bb172:
  call void @__olang_check_failed(ptr @olang_loc_21d2c8212e1ec20a_d97fbaae9e5bc606)
  unreachable
bb173:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/generic:Binding"
  %lp12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/check:litv"
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca i32
  %l37 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca { i64, ptr }
  %l83 = alloca %"compiler/generic:Binding"
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca i64
  %l93 = alloca i64
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/check:litv"
  %l118 = alloca i1
  %l120 = alloca { i64, ptr }
  %l123 = alloca i1
  %l125 = alloca i1
  %l128 = alloca { i64, ptr }
  %l131 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l139 = alloca i32
  %l141 = alloca i32
  %l145 = alloca i32
  %l147 = alloca i32
  %l149 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l171 = alloca i1
  %l176 = alloca i1
  %l179 = alloca i32
  %l182 = alloca i1
  %l185 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca i32
  %l194 = alloca i32
  %l213 = alloca i64
  %l216 = alloca i64
  %l234 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l240 = alloca %"compiler/source:Span"
  %l243 = alloca { i64, ptr }
  %l245 = alloca %"compiler/diagmsg:Msg"
  %l246 = alloca i64
  %l249 = alloca ptr
  %l257 = alloca i32
  %l262 = alloca i32
  %l268 = alloca ptr
  %l272 = alloca i64
  %l279 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca %"compiler/source:Span"
  %l282 = alloca i32
  %l287 = alloca ptr
  %l288 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l291 = alloca ptr
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t516 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l37
  br label %bb1
bb1:
  %t9 = load i32, ptr %l37, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l43
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load ptr, ptr %l43, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l48
  br label %bb6
bb6:
  %t32 = load i32, ptr %l48, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %v0, ptr %t33, i32 %t34, { i64, ptr } %t35)
  store { i64, ptr } %t39, ptr %l52
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t40, ptr %l4, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 177
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 177
  store i1 false, ptr %t48, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v0, ptr %t49, { i64, ptr } %t50)
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t53, %"compiler/source:Span" %t54)
  store ptr %t57, ptr %l60
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l60, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 178
  %t63 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %s0, ptr %t61)
  store { i64, ptr } %t63, ptr %l63
  br label %bb13
bb13:
  %t64 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 178
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t67)
  br label %bb14
bb14:
  %t69 = load i32, ptr %l6, !tbaa !23
  %t71 = call i64 @compiler_2fgeneric_2eCtorOwner(i32 %t69)
  store i64 %t71, ptr %l67
  br label %bb15
bb15:
  %t72 = load i64, ptr %l67, !tbaa !24
  store i64 %t72, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i32, ptr %l6, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t76, i32 %t77)
  store i64 %t80, ptr %l71
  br label %bb16
bb16:
  %t81 = load i64, ptr %l71, !tbaa !24
  store i64 %t81, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  store ptr %t87, ptr %l74, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l5, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l79
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l74, !tbaa !29
  %t99 = load i32, ptr %l79, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l80
  br label %bb18
bb18:
  %t101 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t102, i64 %t103)
  store %"compiler/generic:Binding" %t106, ptr %l83
  br label %bb19
bb19:
  %t107 = load %"compiler/generic:Binding", ptr %l83
  store %"compiler/generic:Binding" %t107, ptr %l11
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l84
  br label %bb20
bb20:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t109, ptr %lp12
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  %t111 = load ptr, ptr %lp12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t111
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb21, label %bb22
bb21:
  %t122 = load i64, ptr %l15, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb26
bb23:
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l15, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l15, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l93, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l93, !tbaa !24
  store i64 %t142, ptr %l90, !tbaa !24
  br label %bb26
bb26:
  %t143 = load i64, ptr %l90, !tbaa !24
  store i64 %t143, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb28, label %bb29
bb28:
  br label %bb90
bb29:
  br label %bb30
bb30:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t153 = load i64, ptr %l17, !tbaa !24
  %t154 = load i64, ptr %l15, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l18, !tbaa !24
  store ptr null, ptr %l19, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t163, ptr %l112, !tbaa !27
  %t164 = load i64, ptr %l18, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr ptr, ptr %t167, i64 %t164
  %t169 = load ptr, ptr %t168, !tbaa !39
  %t173 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v0, ptr %t162, ptr %t169)
  store %"compiler/check:litv" %t173, ptr %l116
  br label %bb31
bb31:
  %t174 = load %"compiler/check:litv", ptr %l116
  store %"compiler/check:litv" %t174, ptr %l20
  %t175 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t176 = load i1, ptr %t175, !tbaa !21
  br i1 %t176, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb35
bb33:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t179, ptr %l120, !tbaa !27
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v0, ptr %t178, ptr %t185)
  store i1 %t188, ptr %l123
  br label %bb34
bb34:
  %t189 = load i1, ptr %l123, !tbaa !21
  store i1 %t189, ptr %l118, !tbaa !21
  br label %bb35
bb35:
  %t190 = load i1, ptr %l118, !tbaa !21
  br i1 %t190, label %bb36, label %bb37
bb36:
  %t191 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t192 = load i1, ptr %t191, !tbaa !21
  br i1 %t192, label %bb38, label %bb39
bb37:
  %t194 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t194, ptr %l149, !tbaa !27
  %t195 = load i64, ptr %l18, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  store ptr %t200, ptr %l22, !tbaa !29
  %t202 = load ptr, ptr %l22, !tbaa !29
  store ptr %t202, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t203 = load ptr, ptr %l152, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb51, label %bb52
bb38:
  %t206 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 1
  %t207 = load i1, ptr %t206, !tbaa !21
  store i1 %t207, ptr %l125, !tbaa !21
  br label %bb41
bb39:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t210, ptr %l128, !tbaa !27
  %t211 = load i64, ptr %l18, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr ptr, ptr %t214, i64 %t211
  %t216 = load ptr, ptr %t215, !tbaa !39
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v0, ptr %t209, ptr %t216)
  store i1 %t219, ptr %l131
  br label %bb40
bb40:
  %t220 = load i1, ptr %l131, !tbaa !21
  store i1 %t220, ptr %l125, !tbaa !21
  br label %bb41
bb41:
  %t221 = load i1, ptr %l125, !tbaa !21
  store i1 %t221, ptr %l21, !tbaa !21
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t228 = icmp slt i64 %t222, %t225
  br i1 %t228, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l136, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t231, ptr %l137, !tbaa !27
  %t232 = load i64, ptr %l18, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  store i32 %t237, ptr %l139, !tbaa !23
  %t238 = load i1, ptr %l21, !tbaa !21
  br i1 %t238, label %bb44, label %bb45
bb43:
  br label %bb50
bb44:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i32 %t247, ptr %l145
  br label %bb46
bb45:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t248)
  store i32 %t250, ptr %l147
  br label %bb47
bb46:
  %t251 = load i32, ptr %l145, !tbaa !23
  store i32 %t251, ptr %l141, !tbaa !23
  br label %bb48
bb47:
  %t252 = load i32, ptr %l147, !tbaa !23
  store i32 %t252, ptr %l141, !tbaa !23
  br label %bb48
bb48:
  %t253 = load ptr, ptr %l136, !tbaa !29
  %t254 = load i32, ptr %l139, !tbaa !23
  %t255 = load i32, ptr %l141, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t253, i32 %t254, i32 %t255, ptr %l11, i1 true, i1 false)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  br label %bb67
bb51:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 28}
  %t260 = icmp eq i64 %t258, 20
  store i1 %t260, ptr %l153, !tbaa !21
  br label %bb52
bb52:
  %t261 = load i1, ptr %l153, !tbaa !21
  br i1 %t261, label %bb53, label %bb54
bb53:
  br label %bb59
bb54:
  %t262 = load ptr, ptr %l22, !tbaa !29
  store ptr %t262, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t263 = load ptr, ptr %l156, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb55, label %bb56
bb55:
  %t266 = load ptr, ptr %l156, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 28}
  %t269 = icmp eq i64 %t267, 23
  store i1 %t269, ptr %l157, !tbaa !21
  br label %bb56
bb56:
  %t270 = load i1, ptr %l157, !tbaa !21
  br i1 %t270, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb66
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t272, ptr %l161, !tbaa !27
  %t273 = load i64, ptr %l18, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr ptr, ptr %t276, i64 %t273
  %t278 = load ptr, ptr %t277, !tbaa !39
  %t280 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v0, ptr %v2, ptr %t271, ptr %t278, i32 %t280)
  store ptr %t284, ptr %l166
  br label %bb64
bb64:
  %t285 = load ptr, ptr %l166, !tbaa !29
  store ptr %t285, ptr %l19, !tbaa !29
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_86f2d648d7a819c5_fc1d6e84e063e4d9)
  unreachable
bb66:
  br label %bb67
bb67:
  %t287 = load ptr, ptr %l19, !tbaa !29
  %t289 = icmp eq ptr %t287, null
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb68, label %bb69
bb68:
  %t293 = load i64, ptr %l18, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t299 = icmp slt i64 %t293, %t296
  store i1 %t299, ptr %l171, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb70
bb70:
  %t301 = load i1, ptr %l171, !tbaa !21
  br i1 %t301, label %bb71, label %bb72
bb71:
  %t302 = load ptr, ptr %l19, !tbaa !29
  %t305 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t302)
  store i32 %t305, ptr %l179
  br label %bb73
bb72:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb74
bb73:
  %t306 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t307 = load i32, ptr %l179, !tbaa !23
  %t309 = icmp ne i32 %t307, %t306
  store i1 %t309, ptr %l176, !tbaa !21
  br label %bb74
bb74:
  %t311 = load i1, ptr %l176, !tbaa !21
  br i1 %t311, label %bb75, label %bb76
bb75:
  %t312 = load ptr, ptr %l19, !tbaa !29
  %t315 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t312)
  store i32 %t315, ptr %l185
  br label %bb77
bb76:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb78
bb77:
  %t316 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t317 = load i32, ptr %l185, !tbaa !23
  %t319 = icmp ne i32 %t317, %t316
  store i1 %t319, ptr %l182, !tbaa !21
  br label %bb78
bb78:
  %t321 = load i1, ptr %l182, !tbaa !21
  br i1 %t321, label %bb79, label %bb80
bb79:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l188, !tbaa !29
  %t323 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t323, ptr %l189, !tbaa !27
  %t324 = load i64, ptr %l18, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i32, ptr %t327, i64 %t324
  %t329 = load i32, ptr %t328, !tbaa !33
  store i32 %t329, ptr %l191, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t334 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v2, ptr %t330, ptr %t331)
  store i32 %t334, ptr %l194
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t335 = load ptr, ptr %l188, !tbaa !29
  %t336 = load i32, ptr %l191, !tbaa !23
  %t337 = load i32, ptr %l194, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t335, i32 %t336, i32 %t337, ptr %l11, i1 false, i1 false)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t339 = load ptr, ptr %l19, !tbaa !29
  %t341 = icmp eq ptr %t339, null
  br i1 %t341, label %bb84, label %bb85
bb84:
  %t343 = load ptr, ptr %lp12
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:Checker", ptr %t344, i32 0, i32 0
  %t347 = load ptr, ptr %t346, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v2, ptr %v0, ptr %t343, ptr %t347)
  br label %bb86
bb85:
  %t350 = load ptr, ptr %lp12
  %t351 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t350, ptr %t351)
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t354 = load i64, ptr %l17, !tbaa !24
  %t357 = add i64 %t354, 1
  store i64 %t357, ptr %l17, !tbaa !24
  br label %bb27
bb90:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/check:Checker", ptr %t359, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t362, ptr %l11)
  br label %bb91
bb91:
  store i64 0, ptr %l23, !tbaa !24
  %t365 = load i64, ptr %l9, !tbaa !24
  store i64 %t365, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t367 = load i64, ptr %l24, !tbaa !24
  %t368 = load i64, ptr %l23, !tbaa !24
  %t371 = icmp sgt i64 %t367, %t368
  br i1 %t371, label %bb92, label %bb93
bb92:
  %t373 = load i64, ptr %l25, !tbaa !24
  %t375 = icmp sgt i64 %t373, 0
  br i1 %t375, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l213, !tbaa !24
  br label %bb97
bb94:
  %t377 = load i64, ptr %l24, !tbaa !24
  %t378 = load i64, ptr %l23, !tbaa !24
  %t381 = sub i64 %t377, %t378
  %t382 = load i64, ptr %l25, !tbaa !24
  %t385 = add i64 %t381, %t382
  %t387 = sub i64 %t385, 1
  %t388 = load i64, ptr %l25, !tbaa !24
  %t391 = sdiv i64 %t387, %t388
  store i64 %t391, ptr %l216, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb96
bb96:
  %t393 = load i64, ptr %l216, !tbaa !24
  store i64 %t393, ptr %l213, !tbaa !24
  br label %bb97
bb97:
  %t394 = load i64, ptr %l213, !tbaa !24
  store i64 %t394, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb98
bb98:
  %t395 = load i64, ptr %l27, !tbaa !24
  %t396 = load i64, ptr %l26, !tbaa !24
  %t399 = icmp slt i64 %t395, %t396
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb99, label %bb100
bb99:
  br label %bb110
bb100:
  br label %bb101
bb101:
  %t403 = load i64, ptr %l23, !tbaa !24
  %t404 = load i64, ptr %l27, !tbaa !24
  %t405 = load i64, ptr %l25, !tbaa !24
  %t408 = mul i64 %t404, %t405
  %t411 = add i64 %t403, %t408
  %t413 = getelementptr %"compiler/generic:Binding", ptr %l11, i32 0, i32 2
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  store { i64, ptr } %t414, ptr %l234, !tbaa !27
  %t417 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr i32, ptr %t418, i64 %t411
  %t420 = load i32, ptr %t419, !tbaa !33
  %t421 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t424 = icmp eq i32 %t420, %t421
  br i1 %t424, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s16
  %t426 = load ptr, ptr %l0, !tbaa !29
  store ptr %t426, ptr %l239, !tbaa !29
  %t427 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t427, ptr %l240
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i32, ptr %l3, !tbaa !23
  %t432 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t428, i32 %t429)
  store { i64, ptr } %t432, ptr %l243
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t433 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t435 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %s16, ptr %v0, { i64, ptr } %t433)
  store %"compiler/diagmsg:Msg" %t435, ptr %l245
  br label %bb105
bb105:
  %t436 = load ptr, ptr %l239, !tbaa !29
  %t437 = load %"compiler/source:Span", ptr %l240
  %t438 = load %"compiler/diagmsg:Msg", ptr %l245
  %t439 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t436, %"compiler/source:Span" %t437, %"compiler/diagmsg:Msg" %t438)
  store i64 %t439, ptr %l246
  br label %bb106
bb106:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l1
  %t444 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t440, %"compiler/source:Span" %t441)
  store ptr %t444, ptr %l249
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t445 = load ptr, ptr %l249, !tbaa !29
  store ptr %t445, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  %t446 = load i64, ptr %l27, !tbaa !24
  %t449 = add i64 %t446, 1
  store i64 %t449, ptr %l27, !tbaa !24
  br label %bb98
bb110:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/check:Checker", ptr %t451, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t456 = getelementptr %"compiler/generic:Program", ptr %t454, i32 0, i32 2
  %t457 = getelementptr %"compiler/generic:Binding", ptr %l11, i32 0, i32 2
  %t458 = load { i64, ptr }, ptr %t457, !tbaa !27
  %t461 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t456, { i64, ptr } %t458)
  store i32 %t461, ptr %l257
  br label %bb111
bb111:
  %t462 = load i32, ptr %l257, !tbaa !23
  store i32 %t462, ptr %l29, !tbaa !23
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/check:Checker", ptr %t463, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !29
  %t467 = load i32, ptr %l3, !tbaa !23
  %t468 = load i32, ptr %l29, !tbaa !23
  %t472 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %t466, i32 %t467, i32 %t468)
  store i32 %t472, ptr %l262
  br label %bb112
bb112:
  %t473 = load i32, ptr %l262, !tbaa !23
  store i32 %t473, ptr %l30, !tbaa !23
  %t474 = load i32, ptr %l30, !tbaa !23
  %t475 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t478 = icmp eq i32 %t474, %t475
  br i1 %t478, label %bb113, label %bb114
bb113:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load %"compiler/source:Span", ptr %l1
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t480, %"compiler/source:Span" %t481)
  store ptr %t484, ptr %l268
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  %t485 = load ptr, ptr %l268, !tbaa !29
  store ptr %t485, ptr %rv
  br label %ret
bb116:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i32, ptr %l3, !tbaa !23
  %t488 = load i32, ptr %l29, !tbaa !23
  %t492 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %t486, i32 %t487, i32 %t488)
  store i64 %t492, ptr %l272
  br label %bb117
bb117:
  %t493 = load i64, ptr %l272, !tbaa !24
  store i64 %t493, ptr %l31, !tbaa !24
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/check:Checker", ptr %t494, i32 0, i32 29
  %t497 = load i32, ptr %t496, !tbaa !23
  store i32 %t497, ptr %l32, !tbaa !23
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load i32, ptr %l3, !tbaa !23
  %t503 = getelementptr %"compiler/check:Checker", ptr %t499, i32 0, i32 29
  store i32 %t500, ptr %t503, !tbaa !23
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %s0, ptr %t504, { i64, ptr } %t505)
  br label %bb118
bb118:
  %t508 = load ptr, ptr %l0, !tbaa !29
  store ptr %t508, ptr %l279, !tbaa !29
  %t509 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t509, ptr %l280
  %t510 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t510, ptr %l281
  %t511 = load i32, ptr %l30, !tbaa !23
  store i32 %t511, ptr %l282, !tbaa !23
  %t512 = load i64, ptr %l31, !tbaa !24
  %t514 = trunc i64 %t512 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t516
  %t517 = getelementptr { i64, [3 x i64] }, ptr %t516, i32 0, i32 0
  store i64 0, ptr %t517
  %t519 = insertvalue { i32 } undef, i32 %t514, 0
  %t520 = getelementptr { i64, [3 x i64] }, ptr %t516, i32 0, i32 1
  store { i32 } %t519, ptr %t520
  %t521 = load { i64, [3 x i64] }, ptr %t516
  %t523 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t521, ptr %t523
  store ptr %t523, ptr %l287, !tbaa !29
  %t524 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t524, ptr %l288, !tbaa !27
  %t525 = load ptr, ptr %lp12
  %t527 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v2, ptr %v2, ptr %t525)
  store { i64, ptr } %t527, ptr %l290
  br label %bb119
bb119:
  %t528 = load ptr, ptr %l279, !tbaa !29
  %t529 = load %"compiler/source:Span", ptr %l280
  %t530 = load %"compiler/source:Span", ptr %l281
  %t531 = load i32, ptr %l282, !tbaa !23
  %t532 = load ptr, ptr %l287, !tbaa !29
  %t533 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t534 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t535 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v2, ptr %v2, ptr %t528, %"compiler/source:Span" %t529, %"compiler/source:Span" %t530, i32 %t531, ptr %t532, i64 -1, ptr null, { i64, ptr } %t533, { i64, ptr } %t534)
  store ptr %t535, ptr %l291
  br label %bb120
bb120:
  %t536 = load ptr, ptr %l291, !tbaa !29
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load i32, ptr %l32, !tbaa !23
  %t541 = getelementptr %"compiler/check:Checker", ptr %t537, i32 0, i32 29
  store i32 %t538, ptr %t541, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t536, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseCovers(ptr %v0, ptr %a0, %"compiler/check:typeCase" %a1, %"compiler/check:typeCase" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:typeCase"
  %l2 = alloca %"compiler/check:typeCase"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l37 = alloca i1
  %l50 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i32
  %l62 = alloca ptr
  %l67 = alloca i32
  %l72 = alloca i64
  %l76 = alloca i32
  %l77 = alloca i1
  %l82 = alloca i32
  %l86 = alloca i1
  %l91 = alloca i32
  %l100 = alloca i32
  %l105 = alloca i32
  %l110 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l125 = alloca { i64, ptr }
  %l132 = alloca i32
  %l136 = alloca i1
  %l141 = alloca i64
  %l144 = alloca i1
  %l145 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i1
  %l153 = alloca ptr
  %l158 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:typeCase" %a1, ptr %l1
  store %"compiler/check:typeCase" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 0
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  br i1 %t6, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t9 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 1
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb7, label %bb8
bb7:
  %t12 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb9, label %bb10
bb8:
  br label %bb26
bb9:
  %t15 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp eq i64 %t16, 0
  br i1 %t18, label %bb11, label %bb12
bb10:
  br label %bb18
bb11:
  %t20 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t31, i32 %t33, i32 %t35)
  store i1 %t39, ptr %l26
  br label %bb16
bb15:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb17
bb16:
  %t40 = load i1, ptr %l26, !tbaa !21
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i1, ptr %l20, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
bb18:
  %t42 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t60 = load i32, ptr %t59, !tbaa !23
  %t64 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %t56, i32 %t58, i32 %t60)
  store i1 %t64, ptr %l37
  br label %bb24
bb23:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb25
bb24:
  %t65 = load i1, ptr %l37, !tbaa !21
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i1, ptr %l32, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
bb26:
  %t67 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 1
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t71 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp eq i64 %t72, 0
  br i1 %t74, label %bb30, label %bb31
bb30:
  %t76 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 3
  %t77 = load i64, ptr %t76, !tbaa !24
  %t79 = icmp ne i64 %t77, 0
  br i1 %t79, label %bb32, label %bb33
bb31:
  br label %bb47
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t95 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t87, i32 %t89, i32 %t91)
  store i1 %t95, ptr %l50
  br label %bb35
bb35:
  %t96 = load i1, ptr %l50, !tbaa !21
  br i1 %t96, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t98, i32 %t100)
  store i1 %t103, ptr %l54
  br label %bb39
bb39:
  %t104 = load i1, ptr %l54, !tbaa !21
  br i1 %t104, label %bb40, label %bb41
bb40:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  store ptr %t110, ptr %l58, !tbaa !29
  %t111 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t112 = load i32, ptr %t111, !tbaa !23
  store i32 %t112, ptr %l59, !tbaa !23
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  store ptr %t118, ptr %l62, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t126 = load i32, ptr %t125, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t124, i32 %t126)
  store i32 %t129, ptr %l67
  br label %bb42
bb41:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb46
bb42:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t137 = load i32, ptr %t136, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t135, i32 %t137)
  store i64 %t140, ptr %l72
  br label %bb43
bb43:
  %t141 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t143 = xor i64 %t141, -1
  %t144 = load i64, ptr %l72, !tbaa !24
  %t146 = and i64 %t144, %t143
  %t147 = load ptr, ptr %l62, !tbaa !29
  %t148 = load i32, ptr %l67, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t147, i32 %t148, i64 %t146)
  store i32 %t150, ptr %l76
  br label %bb44
bb44:
  %t151 = load ptr, ptr %l58, !tbaa !29
  %t152 = load i32, ptr %l59, !tbaa !23
  %t153 = load i32, ptr %l76, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t151, i32 %t152, i32 %t153)
  store i1 %t154, ptr %l77
  br label %bb45
bb45:
  %t155 = load i1, ptr %l77, !tbaa !21
  store i1 %t155, ptr %l55, !tbaa !21
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t156 = load i1, ptr %l55, !tbaa !21
  store i1 %t156, ptr %rv
  br label %ret
bb47:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t164 = load i32, ptr %t163, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t162, i32 %t164)
  store i32 %t167, ptr %l82
  br label %bb48
bb48:
  %t168 = load i32, ptr %l82, !range !{i32 0, i32 33}
  %t170 = trunc i64 18 to i32
  %t171 = icmp eq i32 %t168, %t170
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb52
bb50:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t182 = load i32, ptr %t181, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t180, i32 %t182)
  store i32 %t185, ptr %l91
  br label %bb51
bb51:
  %t186 = load i32, ptr %l91, !range !{i32 0, i32 33}
  %t188 = trunc i64 18 to i32
  %t189 = icmp eq i32 %t186, %t188
  %t191 = xor i1 %t189, true
  store i1 %t191, ptr %l86, !tbaa !21
  br label %bb52
bb52:
  %t193 = load i1, ptr %l86, !tbaa !21
  br i1 %t193, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t202 = load i32, ptr %t201, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t200, i32 %t202)
  store i32 %t205, ptr %l100
  br label %bb56
bb56:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = getelementptr %"compiler/check:typeCase", ptr %l2, i32 0, i32 2
  %t213 = load i32, ptr %t212, !tbaa !23
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t211, i32 %t213)
  store i32 %t216, ptr %l105
  br label %bb57
bb57:
  %t217 = load i32, ptr %l100, !tbaa !23
  %t218 = load i32, ptr %l105, !tbaa !23
  %t219 = icmp ne i32 %t217, %t218
  br i1 %t219, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  store ptr %t227, ptr %l110, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t233, i32 %t235)
  store i32 %t238, ptr %l115
  br label %bb61
bb61:
  %t239 = load ptr, ptr %l110, !tbaa !29
  %t240 = load i32, ptr %l115, !tbaa !23
  %t241 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t239, i32 %t240)
  store { i64, ptr } %t241, ptr %l116
  br label %bb62
bb62:
  %t242 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t242, ptr %l3, !tbaa !27
  %t243 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243, ptr %l117
  br label %bb63
bb63:
  %t244 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l4
  %t245 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t245, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  store i64 %t249, ptr %l7, !tbaa !24
  br label %bb64
bb64:
  %t251 = load i64, ptr %l6, !tbaa !24
  %t252 = load i64, ptr %l7, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb65, label %bb66
bb65:
  br label %bb84
bb66:
  br label %bb67
bb67:
  %t259 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t259, ptr %l125, !tbaa !27
  %t260 = load i64, ptr %l6, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  store i32 %t265, ptr %l8, !tbaa !23
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l8, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l132
  br label %bb68
bb68:
  %t277 = load i32, ptr %l132, !range !{i32 0, i32 33}
  %t279 = trunc i64 25 to i32
  %t280 = icmp eq i32 %t277, %t279
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb72
bb70:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t284, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/generic:Program", ptr %t287, i32 0, i32 2
  %t290 = load i32, ptr %l8, !tbaa !23
  %t293 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t289, i32 %t290)
  store i64 %t293, ptr %l141
  br label %bb71
bb71:
  %t294 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t295 = load i64, ptr %t294, !tbaa !24
  %t296 = load i64, ptr %l141, !tbaa !24
  %t298 = icmp ne i64 %t296, %t295
  store i1 %t298, ptr %l136, !tbaa !21
  br label %bb72
bb72:
  %t300 = load i1, ptr %l136, !tbaa !21
  br i1 %t300, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb77
bb74:
  store ptr %l4, ptr %l145, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/generic:Program", ptr %t304, i32 0, i32 2
  %t307 = load i32, ptr %l8, !tbaa !23
  %t310 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t306, i32 %t307)
  store i64 %t310, ptr %l150
  br label %bb75
bb75:
  %t311 = load ptr, ptr %l145, !tbaa !29
  %t312 = load i64, ptr %l150, !tbaa !24
  %t313 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %t311, i64 %t312)
  store i1 %t313, ptr %l151
  br label %bb76
bb76:
  %t314 = load i1, ptr %l151, !tbaa !21
  store i1 %t314, ptr %l144, !tbaa !21
  br label %bb77
bb77:
  %t315 = load i1, ptr %l144, !tbaa !21
  br i1 %t315, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  store ptr %l4, ptr %l153, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  %t323 = load i32, ptr %l8, !tbaa !23
  %t326 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t322, i32 %t323)
  store i64 %t326, ptr %l158
  br label %bb81
bb81:
  %t327 = load ptr, ptr %l153, !tbaa !29
  %t328 = load i64, ptr %l158, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t327, i64 %t328)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t329 = load i64, ptr %l6, !tbaa !24
  %t332 = add i64 %t329, 1
  store i64 %t332, ptr %l6, !tbaa !24
  br label %bb64
bb84:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l39 = alloca i32
  %l48 = alloca i32
  %l51 = alloca i1
  %l53 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l81 = alloca i32
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t160 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i1 %t21, ptr %l20
  br label %bb5
bb5:
  %t22 = load i1, ptr %l20, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t25 = load i64, ptr %l5, !tbaa !24
  %t29 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t23, i32 %t24, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, i64 %t25)
  store i64 %t29, ptr %l25
  br label %bb8
bb7:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  %t30 = load i64, ptr %l25, !tbaa !24
  store i64 %t30, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t31 = load i64, ptr %l21, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t38 = load i64, ptr %l5, !tbaa !24
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s2, ptr %t36, i32 %t37, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, i64 %t38)
  store i64 %t42, ptr %l31
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t43 = load i64, ptr %l31, !tbaa !24
  store i64 %t43, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t44, 0
  br i1 %t46, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t52, i64 %t53, i32 %t54)
  store i32 %t58, ptr %l39
  br label %bb17
bb17:
  %t59 = load i32, ptr %l39, !tbaa !23
  store i32 %t59, ptr %l7, !tbaa !23
  %t60 = load i32, ptr %l7, !tbaa !23
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t64 = icmp eq i32 %t60, %t61
  br i1 %t64, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l7, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l48
  br label %bb21
bb21:
  %t77 = load i32, ptr %l48, !tbaa !23
  store i32 %t77, ptr %l8, !tbaa !23
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l8, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l51
  br label %bb22
bb22:
  %t83 = load i1, ptr %l51, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb27
bb24:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l8, !tbaa !23
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l58
  br label %bb25
bb25:
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = load i32, ptr %l58, !tbaa !23
  %t97 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t97, ptr %l59
  br label %bb26
bb26:
  %t98 = load i1, ptr %l59, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l53, !tbaa !21
  br label %bb27
bb27:
  %t101 = load i1, ptr %l53, !tbaa !21
  br i1 %t101, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l62, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t104, ptr %l63
  %t105 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t105, ptr %l64
  %t106 = load i64, ptr %l6, !tbaa !24
  store i64 %t106, ptr %l65, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t113 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t107, %"compiler/source:Span" %t108, ptr %t109)
  store ptr %t113, ptr %l69
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l69, !tbaa !29
  store ptr %t114, ptr %l70, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t115, ptr %l71, !tbaa !27
  %t116 = icmp sge i64 0, 0
  br i1 %t116, label %bb32, label %bb33
bb32:
  %t118 = icmp sle i64 0, 1152921504606846975
  br i1 %t118, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a50575fe0cbf16d0_d0ac681a5111f894)
  unreachable
bb34:
  %t120 = mul i64 0, 8
  %t121 = insertvalue { i64, ptr } undef, i64 0, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t122, ptr %l74, !tbaa !27
  %t123 = icmp sge i64 0, 0
  br i1 %t123, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_a50575fe0cbf16d0_d0ac681a5111f894)
  unreachable
bb36:
  %t125 = icmp sle i64 0, 2305843009213693951
  br i1 %t125, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_60e1b0f1da45c3fd_13c1ffbfc1f1b5a1)
  unreachable
bb38:
  %t127 = mul i64 0, 4
  %t128 = insertvalue { i64, ptr } undef, i64 0, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t130 = load ptr, ptr %l62, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l63
  %t132 = load %"compiler/source:Span", ptr %l64
  %t133 = load i64, ptr %l65, !tbaa !24
  %t134 = load ptr, ptr %l70, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %v3, ptr %t130, %"compiler/source:Span" %t131, %"compiler/source:Span" %t132, i64 %t133, ptr %t134, { i64, ptr } %t135, { i64, ptr } %t136, { i64, ptr } %t129)
  store ptr %t138, ptr %l78
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_60e1b0f1da45c3fd_13c1ffbfc1f1b5a1)
  unreachable
bb40:
  %t139 = load ptr, ptr %l78, !tbaa !29
  store ptr %t139, ptr %l9, !tbaa !29
  %t140 = load ptr, ptr %l9, !tbaa !29
  %t143 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t140)
  store i32 %t143, ptr %l81
  br label %bb41
bb41:
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t145 = load i32, ptr %l81, !tbaa !23
  %t147 = icmp eq i32 %t145, %t144
  br i1 %t147, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l85
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l86, !tbaa !29
  %t152 = load ptr, ptr %l9, !tbaa !29
  %t155 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t152)
  store i32 %t155, ptr %l89
  br label %bb45
bb45:
  %t156 = load ptr, ptr %l86, !tbaa !29
  %t157 = load i32, ptr %l89, !tbaa !23
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t158, ptr %l90
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 0
  store i64 2, ptr %t161
  %t162 = load %"compiler/source:Span", ptr %l85
  %t163 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t162, 0
  %t164 = load i32, ptr %l90, !tbaa !23
  %t165 = insertvalue { %"compiler/source:Span", i32, ptr } %t163, i32 %t164, 1
  %t167 = insertvalue { %"compiler/source:Span", i32, ptr } %t165, ptr %t159, 2
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t167, ptr %t168
  %t169 = load { i64, [4 x i64] }, ptr %t160
  %t171 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t169, ptr %t171
  call void @__olang_scope_close(ptr %s0)
  store ptr %t171, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueFill(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l32 = alloca %"compiler/diagmsg:Msg"
  %l33 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb3
bb3:
  %t12 = load i1, ptr %l10, !tbaa !21
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l15
  br label %bb7
bb7:
  %t22 = load i1, ptr %l15, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l11, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %t26, i32 %t27)
  store i64 %t30, ptr %l19
  br label %bb12
bb12:
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  br i1 %t34, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load %"compiler/source:Span", ptr %l1
  %t39 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsCopy(ptr %v0, ptr %t36, i64 %t37, %"compiler/source:Span" %t38, i32 %t39)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t46, i32 %t47)
  store { i64, ptr } %t50, ptr %l30
  br label %bb17
bb17:
  %t51 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t53 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueFill(ptr %s0, ptr %v0, { i64, ptr } %t51)
  store %"compiler/diagmsg:Msg" %t53, ptr %l32
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l27
  %t56 = load %"compiler/diagmsg:Msg", ptr %l32
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t54, %"compiler/source:Span" %t55, %"compiler/diagmsg:Msg" %t56)
  store i64 %t57, ptr %l33
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca { i64, ptr }
  %l29 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l56 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i32
  %l65 = alloca ptr
  %l67 = alloca i32
  %l70 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i32
  %l84 = alloca i64
  %l87 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i64
  %l103 = alloca ptr
  %l106 = alloca i1
  %l108 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca i1
  %l136 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca i32
  %l143 = alloca ptr
  %l145 = alloca i32
  %l147 = alloca i32
  %l148 = alloca i32
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca i32
  %l151 = alloca i32
  %l152 = alloca { i64, ptr }
  %l156 = alloca i32
  %l158 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t282 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 4
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t5)
  store %"compiler/source:Span" %t7, ptr %l24
  br label %bb1
bb1:
  %t8 = load %"compiler/check:reflList", ptr %l3
  %t9 = load ptr, ptr %l21, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l24
  %t12 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t9, %"compiler/source:Span" %t10, %"compiler/check:reflList" %t8)
  store { i64, ptr } %t12, ptr %l26
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 47
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l29
  br label %bb3
bb3:
  %t19 = load i64, ptr %l29, !tbaa !24
  store i64 %t19, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l10, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb9
bb6:
  %t34 = load i64, ptr %l9, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l10, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l10, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l38, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l38, !tbaa !24
  store i64 %t50, ptr %l35, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l35, !tbaa !24
  store i64 %t51, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l12, !tbaa !24
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  br label %bb46
bb12:
  br label %bb13
bb13:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l13, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l56, !tbaa !29
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Compr", ptr %t71, i32 0, i32 3
  %t74 = load i32, ptr %t73, !tbaa !23
  store i32 %t74, ptr %l58, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load %"compiler/check:reflList", ptr %l3
  %t77 = load i64, ptr %l13, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t77
  %t82 = load i64, ptr %t81, !tbaa !34
  %t86 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t75, %"compiler/check:reflList" %t76, i64 %t82)
  store i32 %t86, ptr %l63
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l56, !tbaa !29
  %t88 = load i32, ptr %l58, !tbaa !23
  %t89 = load i32, ptr %l63, !tbaa !23
  %t90 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t87, i32 %t88, i32 %t89)
  store i32 %t90, ptr %l64
  br label %bb15
bb15:
  %t91 = load i32, ptr %l64, !tbaa !23
  store i32 %t91, ptr %l14, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l65, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Compr", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %t95, !tbaa !23
  store i32 %t96, ptr %l67, !tbaa !23
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l70, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t103)
  store i32 %t105, ptr %l72
  br label %bb16
bb16:
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load ptr, ptr %l70, !tbaa !29
  %t108 = load i32, ptr %l72, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t107, i32 %t108, i64 %t106)
  store i32 %t110, ptr %l74
  br label %bb17
bb17:
  %t111 = load ptr, ptr %l65, !tbaa !29
  %t112 = load i32, ptr %l67, !tbaa !23
  %t113 = load i32, ptr %l74, !tbaa !23
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t111, i32 %t112, i32 %t113)
  store i32 %t114, ptr %l75
  br label %bb18
bb18:
  %t115 = load i32, ptr %l75, !tbaa !23
  store i32 %t115, ptr %l15, !tbaa !23
  store i1 true, ptr %l16, !tbaa !21
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Compr", ptr %t116, i32 0, i32 5
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb19, label %bb20
bb19:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Compr", ptr %t126, i32 0, i32 5
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t125, ptr %t129)
  store i64 %t133, ptr %l84
  br label %bb21
bb20:
  br label %bb31
bb21:
  %t134 = load i64, ptr %l84, !tbaa !24
  store i64 %t134, ptr %l17, !tbaa !24
  %t135 = load i64, ptr %l17, !tbaa !24
  %t137 = icmp slt i64 %t135, 0
  br i1 %t137, label %bb22, label %bb23
bb22:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l87, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t142 = getelementptr %"compiler/ast:Compr", ptr %t140, i32 0, i32 5
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = icmp eq ptr %t143, null
  br i1 %t145, label %bb24, label %bb25
bb23:
  %t147 = load i64, ptr %l17, !tbaa !24
  %t149 = icmp eq i64 %t147, 1
  store i1 %t149, ptr %l16, !tbaa !21
  br label %bb30
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ef99e54d7427d8e6_6c42201a9dddf792)
  unreachable
bb25:
  br label %bb26
bb26:
  %t151 = load ptr, ptr %l2, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Compr", ptr %t151, i32 0, i32 5
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t154)
  store %"compiler/source:Span" %t156, ptr %l93
  br label %bb27
bb27:
  %t157 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0)
  store %"compiler/diagmsg:Msg" %t157, ptr %l94
  br label %bb28
bb28:
  %t158 = load ptr, ptr %l87, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l93
  %t160 = load %"compiler/diagmsg:Msg", ptr %l94
  %t161 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t158, %"compiler/source:Span" %t159, %"compiler/diagmsg:Msg" %t160)
  store i64 %t161, ptr %l95
  br label %bb29
bb29:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t162 = load i1, ptr %l16, !tbaa !21
  br i1 %t162, label %bb32, label %bb33
bb32:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t167 = getelementptr %"compiler/ast:Compr", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t169 = load i32, ptr %l4, !tbaa !23
  %t173 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t164, ptr %t168, i32 %t169)
  store ptr %t173, ptr %l103
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t174 = load ptr, ptr %l103, !tbaa !29
  store ptr %t174, ptr %l18, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l4, !tbaa !23
  %t179 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t175, i32 %t176)
  store i1 %t179, ptr %l106
  br label %bb35
bb35:
  %t180 = load i1, ptr %l106, !tbaa !21
  %t181 = xor i1 %t180, true
  br i1 %t181, label %bb36, label %bb37
bb36:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l108, !tbaa !29
  %t184 = load ptr, ptr %l18, !tbaa !29
  store ptr %t184, ptr %l110, !tbaa !29
  %t186 = load ptr, ptr %l2, !tbaa !29
  %t188 = getelementptr %"compiler/ast:Compr", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t189)
  store %"compiler/source:Span" %t191, ptr %l113
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t192 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t193 = load ptr, ptr %l108, !tbaa !29
  %t194 = load ptr, ptr %l110, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l113
  %t197 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t193, ptr %t194, %"compiler/source:Span" %t195, i64 %t192)
  store i1 %t197, ptr %l115
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 47
  %t201 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t200, ptr %t201)
  br label %bb41
bb41:
  %t204 = load i64, ptr %l7, !tbaa !24
  %t207 = add i64 %t204, 1
  store i64 %t207, ptr %l7, !tbaa !24
  br label %bb42
bb42:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l2, !tbaa !29
  %t212 = getelementptr %"compiler/ast:Compr", ptr %t210, i32 0, i32 2
  %t213 = load i32, ptr %t212, !tbaa !23
  %t214 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t209, i32 %t213, i32 %t214)
  br label %bb43
bb43:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l2, !tbaa !29
  %t221 = getelementptr %"compiler/ast:Compr", ptr %t219, i32 0, i32 3
  %t222 = load i32, ptr %t221, !tbaa !23
  %t223 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t218, i32 %t222, i32 %t223)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t227 = load i64, ptr %l12, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l12, !tbaa !24
  br label %bb10
bb46:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 47
  %t235 = load i64, ptr %l6, !tbaa !24
  %t238 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t234, i64 %t235)
  store { i64, ptr } %t238, ptr %l136
  br label %bb47
bb47:
  %t239 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t239, ptr %l19, !tbaa !27
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  store ptr %t245, ptr %l139, !tbaa !29
  %t246 = load i32, ptr %l4, !tbaa !23
  store i32 %t246, ptr %l140, !tbaa !23
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 2
  store ptr %t252, ptr %l143, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t253)
  store i32 %t255, ptr %l145
  br label %bb48
bb48:
  %t256 = load i64, ptr %l7, !tbaa !24
  %t257 = load ptr, ptr %l143, !tbaa !29
  %t258 = load i32, ptr %l145, !tbaa !23
  %t260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t257, i32 %t258, i64 %t256)
  store i32 %t260, ptr %l147
  br label %bb49
bb49:
  %t261 = load ptr, ptr %l139, !tbaa !29
  %t262 = load i32, ptr %l140, !tbaa !23
  %t263 = load i32, ptr %l147, !tbaa !23
  %t264 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t261, i32 %t262, i32 %t263)
  store i32 %t264, ptr %l148
  br label %bb50
bb50:
  %t265 = load i32, ptr %l148, !tbaa !23
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l149
  store i32 %t265, ptr %l150, !tbaa !23
  store i32 2, ptr %l151
  %t268 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t268, ptr %l152, !tbaa !27
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t274 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t269, i32 1, %"compiler/source:Span" %t270)
  store i32 %t274, ptr %l156
  br label %bb51
bb51:
  %t275 = load i32, ptr %l151, !range !{i32 0, i32 5}
  %t276 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t277 = load i32, ptr %l156, !tbaa !23
  %t279 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t275, i64 0, { i64, ptr } %t276, ptr null, i32 %t277, i32 0, i1 false)
  store %"compiler/typed:Make" %t279, ptr %l158
  br label %bb52
bb52:
  %t280 = load %"compiler/typed:Make", ptr %l158
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t280, ptr %t281
  store { i64, [5 x i64] } zeroinitializer, ptr %t282
  %t283 = getelementptr { i64, [5 x i64] }, ptr %t282, i32 0, i32 0
  store i64 7, ptr %t283
  %t284 = load %"compiler/source:Span", ptr %l149
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t284, 0
  %t286 = load i32, ptr %l150, !tbaa !23
  %t287 = insertvalue { %"compiler/source:Span", i32, ptr } %t285, i32 %t286, 1
  %t289 = insertvalue { %"compiler/source:Span", i32, ptr } %t287, ptr %t281, 2
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t282, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t289, ptr %t290
  %t291 = load { i64, [5 x i64] }, ptr %t282
  %t293 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t291, ptr %t293
  call void @__olang_scope_close(ptr %s0)
  store ptr %t293, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efoldBinary(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca %"compiler/check:litv"
  %l3 = alloca %"compiler/check:signMag"
  %l4 = alloca i1
  %l5 = alloca i128
  %l6 = alloca %"compiler/check:signMag"
  %l7 = alloca i1
  %l8 = alloca i128
  %l9 = alloca i128
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l17 = alloca %"compiler/check:litv"
  %l19 = alloca i1
  %l24 = alloca %"compiler/check:litv"
  %l26 = alloca %"compiler/check:signMag"
  %l30 = alloca %"compiler/check:signMag"
  %l39 = alloca %"compiler/check:litv"
  %l47 = alloca %"compiler/check:litv"
  %l52 = alloca i1
  %l58 = alloca %"compiler/check:litv"
  %l65 = alloca i1
  %l69 = alloca %"compiler/check:litv"
  %l72 = alloca i1
  %l75 = alloca i1
  %l81 = alloca %"compiler/check:litv"
  %l84 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l93 = alloca i1
  %l101 = alloca %"compiler/check:litv"
  %l103 = alloca i1
  %l107 = alloca %"compiler/check:litv"
  %l116 = alloca %"compiler/check:litv"
  %l123 = alloca %"compiler/check:litv"
  %l124 = alloca %"compiler/check:litv"
  %l126 = alloca i1
  %l128 = alloca %"compiler/check:litv"
  %l133 = alloca i1
  %l136 = alloca i1
  %l140 = alloca i1
  %l147 = alloca %"compiler/check:litv"
  %l150 = alloca i1
  %l153 = alloca i1
  %l159 = alloca %"compiler/check:litv"
  %l160 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 0
  %t2 = load i1, ptr %t1, !tbaa !21
  %t4 = xor i1 %t2, true
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t6 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 0
  %t7 = load i1, ptr %t6, !tbaa !21
  %t9 = xor i1 %t7, true
  store i1 %t9, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l14, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t12, ptr %l17
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t13 = load %"compiler/check:litv", ptr %l17
  store %"compiler/check:litv" %t13, ptr %rv
  br label %ret
bb7:
  %t14 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb9:
  %t17 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t18 = load i1, ptr %t17, !tbaa !21
  store i1 %t18, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t20 = load i1, ptr %l19, !tbaa !21
  br i1 %t20, label %bb11, label %bb12
bb11:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t22 = load %"compiler/check:litv", ptr %l1
  %t23 = load %"compiler/check:litv", ptr %l2
  %t27 = call %"compiler/check:litv" @compiler_2fcheck_2efoldFloat(i32 %t21, %"compiler/check:litv" %t22, %"compiler/check:litv" %t23)
  store %"compiler/check:litv" %t27, ptr %l24
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t28 = load %"compiler/check:litv", ptr %l24
  store %"compiler/check:litv" %t28, ptr %rv
  br label %ret
bb14:
  %t29 = load %"compiler/check:litv", ptr %l1
  %t31 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %t29)
  store %"compiler/check:signMag" %t31, ptr %l26
  br label %bb15
bb15:
  %t32 = load %"compiler/check:signMag", ptr %l26
  store %"compiler/check:signMag" %t32, ptr %l3
  %t33 = getelementptr %"compiler/check:signMag", ptr %l3, i32 0, i32 0
  %t34 = load i1, ptr %t33, !tbaa !21
  store i1 %t34, ptr %l4, !tbaa !21
  %t36 = getelementptr %"compiler/check:signMag", ptr %l3, i32 0, i32 1
  %t37 = load i128, ptr %t36
  store i128 %t37, ptr %l5
  %t39 = load %"compiler/check:litv", ptr %l2
  %t41 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %t39)
  store %"compiler/check:signMag" %t41, ptr %l30
  br label %bb16
bb16:
  %t42 = load %"compiler/check:signMag", ptr %l30
  store %"compiler/check:signMag" %t42, ptr %l6
  %t43 = getelementptr %"compiler/check:signMag", ptr %l6, i32 0, i32 0
  %t44 = load i1, ptr %t43, !tbaa !21
  store i1 %t44, ptr %l7, !tbaa !21
  %t46 = getelementptr %"compiler/check:signMag", ptr %l6, i32 0, i32 1
  %t47 = load i128, ptr %t46
  store i128 %t47, ptr %l8
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t51 = trunc i64 68 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load i1, ptr %l4, !tbaa !21
  %t55 = load i128, ptr %l5
  %t56 = load i1, ptr %l7, !tbaa !21
  %t57 = load i128, ptr %l8
  %t62 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eaddMag(i1 %t54, i128 %t55, i1 %t56, i128 %t57)
  store %"compiler/check:litv" %t62, ptr %l39
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t63 = load %"compiler/check:litv", ptr %l39
  store %"compiler/check:litv" %t63, ptr %rv
  br label %ret
bb20:
  %t64 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t66 = trunc i64 69 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load i1, ptr %l4, !tbaa !21
  %t70 = load i128, ptr %l5
  %t71 = load i1, ptr %l7, !tbaa !21
  %t73 = xor i1 %t71, true
  %t74 = load i128, ptr %l8
  %t79 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eaddMag(i1 %t69, i128 %t70, i1 %t73, i128 %t74)
  store %"compiler/check:litv" %t79, ptr %l47
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t80 = load %"compiler/check:litv", ptr %l47
  store %"compiler/check:litv" %t80, ptr %rv
  br label %ret
bb24:
  %t81 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t83 = trunc i64 70 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t86 = load i128, ptr %l5
  %t88 = icmp ne i128 %t86, 0
  br i1 %t88, label %bb27, label %bb28
bb26:
  br label %bb38
bb27:
  %t90 = load i128, ptr %l8
  %t91 = xor i128 0, -1
  %t92 = load i128, ptr %l5
  %t95 = udiv i128 %t91, %t92
  %t98 = icmp ugt i128 %t90, %t95
  store i1 %t98, ptr %l52, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb29
bb29:
  %t100 = load i1, ptr %l52, !tbaa !21
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t101 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t101, ptr %l58
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t102 = load %"compiler/check:litv", ptr %l58
  store %"compiler/check:litv" %t102, ptr %rv
  br label %ret
bb33:
  %t103 = load i128, ptr %l5
  %t104 = load i128, ptr %l8
  %t107 = mul i128 %t103, %t104
  store i128 %t107, ptr %l9
  %t109 = load i1, ptr %l4, !tbaa !21
  %t110 = load i1, ptr %l7, !tbaa !21
  %t113 = icmp ne i1 %t109, %t110
  br i1 %t113, label %bb34, label %bb35
bb34:
  %t115 = load i128, ptr %l9
  %t117 = icmp ne i128 %t115, 0
  store i1 %t117, ptr %l65, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb36
bb36:
  %t119 = load i128, ptr %l9
  %t120 = load i1, ptr %l65, !tbaa !21
  %t122 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %t120, i128 %t119)
  store %"compiler/check:litv" %t122, ptr %l69
  br label %bb37
bb37:
  %t123 = load %"compiler/check:litv", ptr %l69
  store %"compiler/check:litv" %t123, ptr %rv
  br label %ret
bb38:
  %t124 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t126 = trunc i64 102 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb41
bb40:
  %t129 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t131 = trunc i64 103 to i32
  %t132 = icmp eq i32 %t129, %t131
  store i1 %t132, ptr %l72, !tbaa !21
  br label %bb41
bb41:
  %t134 = load i1, ptr %l72, !tbaa !21
  br i1 %t134, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb44
bb43:
  %t135 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t137 = trunc i64 104 to i32
  %t138 = icmp eq i32 %t135, %t137
  store i1 %t138, ptr %l75, !tbaa !21
  br label %bb44
bb44:
  %t140 = load i1, ptr %l75, !tbaa !21
  br i1 %t140, label %bb45, label %bb46
bb45:
  %t141 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t142 = load %"compiler/check:litv", ptr %l1
  %t143 = load %"compiler/check:litv", ptr %l2
  %t147 = call %"compiler/check:litv" @compiler_2fcheck_2efoldBits(i32 %t141, %"compiler/check:litv" %t142, %"compiler/check:litv" %t143)
  store %"compiler/check:litv" %t147, ptr %l81
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t148 = load %"compiler/check:litv", ptr %l81
  store %"compiler/check:litv" %t148, ptr %rv
  br label %ret
bb48:
  %t149 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t151 = trunc i64 108 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb51
bb50:
  %t154 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t156 = trunc i64 109 to i32
  %t157 = icmp eq i32 %t154, %t156
  store i1 %t157, ptr %l84, !tbaa !21
  br label %bb51
bb51:
  %t159 = load i1, ptr %l84, !tbaa !21
  br i1 %t159, label %bb52, label %bb53
bb52:
  %t160 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t161 = load i1, ptr %t160, !tbaa !21
  %t163 = xor i1 %t161, true
  store i1 %t163, ptr %l87, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb54
bb54:
  %t165 = load i1, ptr %l87, !tbaa !21
  br i1 %t165, label %bb55, label %bb56
bb55:
  %t166 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t167 = load i64, ptr %t166, !tbaa !24
  %t169 = icmp sge i64 %t167, 0
  store i1 %t169, ptr %l90, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb57
bb57:
  %t171 = load i1, ptr %l90, !tbaa !21
  br i1 %t171, label %bb58, label %bb59
bb58:
  %t172 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t173 = load i64, ptr %t172, !tbaa !24
  %t175 = icmp slt i64 %t173, 128
  store i1 %t175, ptr %l93, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb60
bb60:
  %t177 = load i1, ptr %l93, !tbaa !21
  br i1 %t177, label %bb61, label %bb62
bb61:
  %t178 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t179 = load %"compiler/check:litv", ptr %l1
  %t180 = load %"compiler/check:litv", ptr %l2
  %t181 = load i1, ptr %l4, !tbaa !21
  %t182 = load i128, ptr %l5
  %t188 = call %"compiler/check:litv" @compiler_2fcheck_2efoldShift(i32 %t178, %"compiler/check:litv" %t179, %"compiler/check:litv" %t180, i1 %t181, i128 %t182)
  store %"compiler/check:litv" %t188, ptr %l101
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t189 = load %"compiler/check:litv", ptr %l101
  store %"compiler/check:litv" %t189, ptr %rv
  br label %ret
bb64:
  %t190 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t191 = load i1, ptr %t190, !tbaa !21
  br i1 %t191, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb67
bb66:
  %t193 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 6
  %t194 = load i1, ptr %t193, !tbaa !21
  store i1 %t194, ptr %l103, !tbaa !21
  br label %bb67
bb67:
  %t196 = load i1, ptr %l103, !tbaa !21
  br i1 %t196, label %bb68, label %bb69
bb68:
  %t197 = load i128, ptr %l8
  %t199 = icmp eq i128 %t197, 0
  br i1 %t199, label %bb70, label %bb71
bb69:
  br label %bb83
bb70:
  %t201 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t201, ptr %l107
  br label %bb72
bb71:
  br label %bb73
bb72:
  %t202 = load %"compiler/check:litv", ptr %l107
  store %"compiler/check:litv" %t202, ptr %rv
  br label %ret
bb73:
  %t203 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t205 = trunc i64 72 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb74, label %bb75
bb74:
  %t208 = load i1, ptr %l4, !tbaa !21
  %t209 = load i1, ptr %l7, !tbaa !21
  %t212 = icmp ne i1 %t208, %t209
  %t213 = load i128, ptr %l5
  %t214 = load i128, ptr %l8
  %t217 = udiv i128 %t213, %t214
  %t220 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %t212, i128 %t217)
  store %"compiler/check:litv" %t220, ptr %l116
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t221 = load %"compiler/check:litv", ptr %l116
  store %"compiler/check:litv" %t221, ptr %rv
  br label %ret
bb77:
  %t222 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t224 = trunc i64 73 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb78, label %bb79
bb78:
  %t227 = load i1, ptr %l4, !tbaa !21
  %t228 = load i128, ptr %l5
  %t229 = load i128, ptr %l8
  %t232 = urem i128 %t228, %t229
  %t235 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %t227, i128 %t232)
  store %"compiler/check:litv" %t235, ptr %l123
  br label %bb80
bb79:
  br label %bb81
bb80:
  %t236 = load %"compiler/check:litv", ptr %l123
  store %"compiler/check:litv" %t236, ptr %rv
  br label %ret
bb81:
  %t237 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t237, ptr %l124
  br label %bb82
bb82:
  %t238 = load %"compiler/check:litv", ptr %l124
  store %"compiler/check:litv" %t238, ptr %rv
  br label %ret
bb83:
  %t239 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t240 = load i1, ptr %t239, !tbaa !21
  br i1 %t240, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb86
bb85:
  %t242 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t243 = load i1, ptr %t242, !tbaa !21
  store i1 %t243, ptr %l126, !tbaa !21
  br label %bb86
bb86:
  %t245 = load i1, ptr %l126, !tbaa !21
  br i1 %t245, label %bb87, label %bb88
bb87:
  %t246 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t246, ptr %l128
  br label %bb89
bb88:
  br label %bb90
bb89:
  %t247 = load %"compiler/check:litv", ptr %l128
  store %"compiler/check:litv" %t247, ptr %rv
  br label %ret
bb90:
  %t248 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t249 = load i64, ptr %t248, !tbaa !24
  store i64 %t249, ptr %l10, !tbaa !24
  %t251 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t252 = load i64, ptr %t251, !tbaa !24
  store i64 %t252, ptr %l11, !tbaa !24
  %t254 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t256 = trunc i64 72 to i32
  %t257 = icmp eq i32 %t254, %t256
  br i1 %t257, label %bb91, label %bb92
bb91:
  %t259 = load i64, ptr %l11, !tbaa !24
  %t261 = icmp ne i64 %t259, 0
  store i1 %t261, ptr %l133, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb93
bb93:
  %t263 = load i1, ptr %l133, !tbaa !21
  br i1 %t263, label %bb94, label %bb95
bb94:
  %t264 = load i64, ptr %l10, !tbaa !24
  %t265 = sub i64 -9223372036854775807, 1
  %t268 = icmp eq i64 %t264, %t265
  br i1 %t268, label %bb96, label %bb97
bb95:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb99
bb96:
  %t270 = load i64, ptr %l11, !tbaa !24
  %t272 = icmp eq i64 %t270, -1
  store i1 %t272, ptr %l140, !tbaa !21
  br label %bb98
bb97:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb98
bb98:
  %t274 = load i1, ptr %l140, !tbaa !21
  %t275 = xor i1 %t274, true
  store i1 %t275, ptr %l136, !tbaa !21
  br label %bb99
bb99:
  %t277 = load i1, ptr %l136, !tbaa !21
  br i1 %t277, label %bb100, label %bb101
bb100:
  %t278 = load i64, ptr %l10, !tbaa !24
  %t279 = load i64, ptr %l11, !tbaa !24
  %t282 = sdiv i64 %t278, %t279
  %t284 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t282)
  store %"compiler/check:litv" %t284, ptr %l147
  br label %bb102
bb101:
  br label %bb103
bb102:
  %t285 = load %"compiler/check:litv", ptr %l147
  store %"compiler/check:litv" %t285, ptr %rv
  br label %ret
bb103:
  %t286 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t288 = trunc i64 73 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb104, label %bb105
bb104:
  %t291 = load i64, ptr %l11, !tbaa !24
  %t293 = icmp ne i64 %t291, 0
  store i1 %t293, ptr %l150, !tbaa !21
  br label %bb106
bb105:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb106
bb106:
  %t295 = load i1, ptr %l150, !tbaa !21
  br i1 %t295, label %bb107, label %bb108
bb107:
  %t296 = load i64, ptr %l11, !tbaa !24
  %t298 = icmp ne i64 %t296, -1
  store i1 %t298, ptr %l153, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb109
bb109:
  %t300 = load i1, ptr %l153, !tbaa !21
  br i1 %t300, label %bb110, label %bb111
bb110:
  %t301 = load i64, ptr %l10, !tbaa !24
  %t302 = load i64, ptr %l11, !tbaa !24
  %t305 = srem i64 %t301, %t302
  %t307 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t305)
  store %"compiler/check:litv" %t307, ptr %l159
  br label %bb112
bb111:
  br label %bb113
bb112:
  %t308 = load %"compiler/check:litv", ptr %l159
  store %"compiler/check:litv" %t308, ptr %rv
  br label %ret
bb113:
  %t309 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t309, ptr %l160
  br label %bb114
bb114:
  %t310 = load %"compiler/check:litv", ptr %l160
  store %"compiler/check:litv" %t310, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efoldBits(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca %"compiler/check:litv"
  %l3 = alloca i64
  %l4 = alloca %"compiler/check:litv"
  %l6 = alloca i1
  %l11 = alloca %"compiler/check:litv"
  %l14 = alloca i64
  %l20 = alloca i64
  %l28 = alloca %"compiler/check:litv"
  %l30 = alloca i1
  %l32 = alloca i1
  %l36 = alloca %"compiler/check:litv"
  %l38 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t4 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 6
  %t5 = load i1, ptr %t4, !tbaa !21
  store i1 %t5, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t8 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t9 = load %"compiler/check:litv", ptr %l1
  %t10 = load %"compiler/check:litv", ptr %l2
  %t14 = call %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %t8, %"compiler/check:litv" %t9, %"compiler/check:litv" %t10)
  store %"compiler/check:litv" %t14, ptr %l11
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t15 = load %"compiler/check:litv", ptr %l11
  store %"compiler/check:litv" %t15, ptr %rv
  br label %ret
bb7:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t18 = trunc i64 102 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = and i64 %t22, %t24
  store i64 %t27, ptr %l14, !tbaa !24
  br label %bb13
bb9:
  %t29 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t31 = trunc i64 103 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = or i64 %t35, %t37
  store i64 %t40, ptr %l20, !tbaa !24
  br label %bb12
bb11:
  %t42 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = xor i64 %t43, %t45
  store i64 %t48, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l20, !tbaa !24
  store i64 %t50, ptr %l14, !tbaa !24
  br label %bb13
bb13:
  %t51 = load i64, ptr %l14, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t52)
  store %"compiler/check:litv" %t54, ptr %l28
  br label %bb14
bb14:
  %t55 = load %"compiler/check:litv", ptr %l28
  store %"compiler/check:litv" %t55, ptr %l4
  %t56 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb16:
  %t59 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t60 = load i1, ptr %t59, !tbaa !21
  store i1 %t60, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l30, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l32, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s2, i1 true, i1 false, i1 true, i64 %t68, double 0x0000000000000000)
  store %"compiler/check:litv" %t70, ptr %l36
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t71 = load %"compiler/check:litv", ptr %l36
  store %"compiler/check:litv" %t71, ptr %l4
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t72 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 5
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb27
bb26:
  %t75 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 5
  %t76 = load i1, ptr %t75, !tbaa !21
  store i1 %t76, ptr %l38, !tbaa !21
  br label %bb27
bb27:
  %t78 = load i1, ptr %l38, !tbaa !21
  %t79 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 5
  store i1 %t78, ptr %t79, !tbaa !21
  %t80 = load %"compiler/check:litv", ptr %l4
  store %"compiler/check:litv" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efoldFloat(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca %"compiler/check:litv"
  %l3 = alloca double
  %l4 = alloca double
  %l6 = alloca i1
  %l8 = alloca %"compiler/check:litv"
  %l10 = alloca double
  %l15 = alloca double
  %l24 = alloca %"compiler/check:litv"
  %l30 = alloca %"compiler/check:litv"
  %l36 = alloca %"compiler/check:litv"
  %l42 = alloca %"compiler/check:litv"
  %l43 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t4 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t5 = load i1, ptr %t4, !tbaa !21
  store i1 %t5, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t8 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t8, ptr %l8
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t9 = load %"compiler/check:litv", ptr %l8
  store %"compiler/check:litv" %t9, ptr %rv
  br label %ret
bb7:
  %t10 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb8, label %bb9
bb8:
  %t13 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 4
  %t14 = load double, ptr %t13, !tbaa !26
  store double %t14, ptr %l10, !tbaa !26
  br label %bb10
bb9:
  %t16 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = sitofp i64 %t17 to double
  store double %t19, ptr %l10, !tbaa !26
  br label %bb10
bb10:
  %t21 = load double, ptr %l10, !tbaa !26
  store double %t21, ptr %l3, !tbaa !26
  %t22 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  %t25 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 4
  %t26 = load double, ptr %t25, !tbaa !26
  store double %t26, ptr %l15, !tbaa !26
  br label %bb13
bb12:
  %t28 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = sitofp i64 %t29 to double
  store double %t31, ptr %l15, !tbaa !26
  br label %bb13
bb13:
  %t33 = load double, ptr %l15, !tbaa !26
  store double %t33, ptr %l4, !tbaa !26
  %t34 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t36 = trunc i64 68 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load double, ptr %l3, !tbaa !26
  %t40 = load double, ptr %l4, !tbaa !26
  %t43 = fadd double %t39, %t40
  %t45 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %t43)
  store %"compiler/check:litv" %t45, ptr %l24
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t46 = load %"compiler/check:litv", ptr %l24
  store %"compiler/check:litv" %t46, ptr %rv
  br label %ret
bb17:
  %t47 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t49 = trunc i64 69 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb18, label %bb19
bb18:
  %t52 = load double, ptr %l3, !tbaa !26
  %t53 = load double, ptr %l4, !tbaa !26
  %t56 = fsub double %t52, %t53
  %t58 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %t56)
  store %"compiler/check:litv" %t58, ptr %l30
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t59 = load %"compiler/check:litv", ptr %l30
  store %"compiler/check:litv" %t59, ptr %rv
  br label %ret
bb21:
  %t60 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t62 = trunc i64 70 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb22, label %bb23
bb22:
  %t65 = load double, ptr %l3, !tbaa !26
  %t66 = load double, ptr %l4, !tbaa !26
  %t69 = fmul double %t65, %t66
  %t71 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %t69)
  store %"compiler/check:litv" %t71, ptr %l36
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t72 = load %"compiler/check:litv", ptr %l36
  store %"compiler/check:litv" %t72, ptr %rv
  br label %ret
bb25:
  %t73 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t75 = trunc i64 72 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb26, label %bb27
bb26:
  %t78 = load double, ptr %l3, !tbaa !26
  %t79 = load double, ptr %l4, !tbaa !26
  %t82 = fdiv double %t78, %t79
  %t84 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %t82)
  store %"compiler/check:litv" %t84, ptr %l42
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t85 = load %"compiler/check:litv", ptr %l42
  store %"compiler/check:litv" %t85, ptr %rv
  br label %ret
bb29:
  %t86 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t86, ptr %l43
  br label %bb30
bb30:
  %t87 = load %"compiler/check:litv", ptr %l43
  store %"compiler/check:litv" %t87, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efoldShift(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2, i1 %a3, i128 %a4) #0 {
entry:
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca %"compiler/check:litv"
  %l5 = alloca i1
  %l6 = alloca i128
  %l7 = alloca i128
  %l10 = alloca i128
  %l18 = alloca i1
  %l20 = alloca i1
  %l29 = alloca %"compiler/check:litv"
  %l31 = alloca i128
  %l34 = alloca i128
  %l38 = alloca %"compiler/check:litv"
  %l40 = alloca %"compiler/check:litv"
  %l42 = alloca i1
  %l44 = alloca i1
  %l50 = alloca i128
  %l52 = alloca %"compiler/check:litv"
  %l55 = alloca i128
  %l58 = alloca %"compiler/check:litv"
  %l60 = alloca i64
  %l62 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store %"compiler/check:litv" %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i1 %a3, ptr %l5, !tbaa !21
  store i128 %a4, ptr %l6
  %t5 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t6 = load i64, ptr %t5, !tbaa !24
  %t8 = sext i64 %t6 to i128
  store i128 %t8, ptr %l7
  %t12 = trunc i64 108 to i32
  %t13 = icmp eq i32 %a0, %t12
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i1, ptr %l5, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb21
bb3:
  %t17 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 5
  %t18 = load i1, ptr %t17, !tbaa !21
  store i1 %t18, ptr %l18, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t22 = load i1, ptr %t21, !tbaa !21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l20, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t28 = load i64, ptr %t27, !tbaa !24
  %t31 = zext i64 %t28 to i128
  store i1 false, ptr %l5, !tbaa !21
  store i128 %t31, ptr %l6
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t37 = load i1, ptr %l5, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t39, ptr %l29
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t40 = load %"compiler/check:litv", ptr %l29
  store %"compiler/check:litv" %t40, ptr %rv
  br label %ret
bb15:
  %t41 = load i128, ptr %l6
  %t42 = load i128, ptr %l7
  store i128 %t42, ptr %l31
  %t44 = load i128, ptr %l31
  %t45 = load i128, ptr %l31
  %t46 = shl i128 %t41, %t45
  store i128 %t46, ptr %l10
  %t48 = load i128, ptr %l10
  %t49 = load i128, ptr %l7
  store i128 %t49, ptr %l34
  %t51 = load i128, ptr %l34
  %t52 = load i128, ptr %l34
  %t53 = lshr i128 %t48, %t52
  %t54 = load i128, ptr %l6
  %t57 = icmp ne i128 %t53, %t54
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t59, ptr %l38
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t60 = load %"compiler/check:litv", ptr %l38
  store %"compiler/check:litv" %t60, ptr %rv
  br label %ret
bb19:
  %t61 = load i128, ptr %l10
  %t63 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 false, i128 %t61)
  store %"compiler/check:litv" %t63, ptr %l40
  br label %bb20
bb20:
  %t64 = load %"compiler/check:litv", ptr %l40
  store %"compiler/check:litv" %t64, ptr %rv
  br label %ret
bb21:
  %t65 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb24
bb23:
  %t68 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t69 = load i1, ptr %t68, !tbaa !21
  store i1 %t69, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t71 = load i1, ptr %l42, !tbaa !21
  br i1 %t71, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb27
bb26:
  %t72 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp sge i64 %t73, 64
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb27
bb27:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb28, label %bb29
bb28:
  %t78 = load i1, ptr %l5, !tbaa !21
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb30, label %bb31
bb29:
  br label %bb35
bb30:
  %t82 = load i128, ptr %l6
  %t83 = load i128, ptr %l7
  store i128 %t83, ptr %l50
  %t85 = load i128, ptr %l50
  %t86 = load i128, ptr %l50
  %t87 = lshr i128 %t82, %t86
  %t89 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 false, i128 %t87)
  store %"compiler/check:litv" %t89, ptr %l52
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t90 = load %"compiler/check:litv", ptr %l52
  store %"compiler/check:litv" %t90, ptr %rv
  br label %ret
bb33:
  %t91 = load i128, ptr %l6
  %t93 = sub i128 %t91, 1
  %t94 = load i128, ptr %l7
  store i128 %t94, ptr %l55
  %t96 = load i128, ptr %l55
  %t97 = load i128, ptr %l55
  %t98 = lshr i128 %t93, %t97
  %t100 = add i128 %t98, 1
  %t102 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 true, i128 %t100)
  store %"compiler/check:litv" %t102, ptr %l58
  br label %bb34
bb34:
  %t103 = load %"compiler/check:litv", ptr %l58
  store %"compiler/check:litv" %t103, ptr %rv
  br label %ret
bb35:
  %t104 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l60, !tbaa !24
  %t110 = load i64, ptr %l60, !tbaa !24
  %t111 = ashr i64 %t105, %t110
  %t113 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t111)
  store %"compiler/check:litv" %t113, ptr %l62
  br label %bb36
bb36:
  %t114 = load %"compiler/check:litv", ptr %l62
  store %"compiler/check:litv" %t114, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eisCharLit(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 116}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 4 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_83df14ccfb59caa2_79e7c0956b45666e)
  unreachable
bb11:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elitText(ptr %v0, %"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l3 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 7
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  %t7 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t8 = load i128, ptr %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t12 = call i64 @__olang_fmt_u128(ptr null, i128 %t8)
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  %t16 = call i64 @__olang_fmt_u128(ptr %t15, i128 %t8)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t14, 1
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  %t20 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t21 = load i128, ptr %t20
  %t23 = call i64 @__olang_fmt_u128(ptr null, i128 %t21)
  %t24 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t23)
  %t25 = call i64 @__olang_fmt_u128(ptr %t24, i128 %t21)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb6:
  %t30 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = call i64 @__olang_fmt_u64(ptr null, i64 %t34)
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  %t39 = call i64 @__olang_fmt_u64(ptr %t38, i64 %t34)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  %t43 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t47 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t46)
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l9, !tbaa !27
  br label %bb9
bb9:
  %t52 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eopNeed(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t11 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t9)
  store { i64, ptr } %t11, ptr %l8
  br label %bb5
bb4:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l11, !tbaa !27
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t15 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t13)
  store { i64, ptr } %t15, ptr %l13
  br label %bb7
bb5:
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t17 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t16)
  store { i64, ptr } %t17, ptr %l9
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t19, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  br label %bb9
bb7:
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t26 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t25)
  store { i64, ptr } %t26, ptr %l14
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t28, i64 %t29)
  %t41 = getelementptr i8, ptr %t40, i64 %t29
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = getelementptr i8, ptr %t41, i64 %t31
  call void @olang_textcopy(ptr %t42, ptr %t34, i64 %t35)
  %t43 = getelementptr i8, ptr %t42, i64 %t35
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2etwos(%"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l1 = alloca %"compiler/check:signMag"
  %l3 = alloca i1
  %l9 = alloca %"compiler/check:signMag"
  %l11 = alloca %"compiler/check:signMag"
  %l15 = alloca %"compiler/check:signMag"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/check:signMag"
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 5
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 6
  %t5 = load i1, ptr %t4, !tbaa !21
  %t7 = xor i1 %t5, true
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t14 = zext i64 %t11 to i128
  %t16 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s1, i1 false, i128 %t14)
  store %"compiler/check:signMag" %t16, ptr %l9
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  %t17 = load %"compiler/check:signMag", ptr %l9
  store %"compiler/check:signMag" %t17, ptr %rv
  br label %ret
bb7:
  %t18 = load %"compiler/check:litv", ptr %l0
  %t20 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %t18)
  store %"compiler/check:signMag" %t20, ptr %l11
  br label %bb8
bb8:
  %t21 = load %"compiler/check:signMag", ptr %l11
  store %"compiler/check:signMag" %t21, ptr %l1
  %t22 = getelementptr %"compiler/check:signMag", ptr %l1, i32 0, i32 0
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = getelementptr %"compiler/check:signMag", ptr %l1, i32 0, i32 1
  %t26 = load i128, ptr %t25
  %t28 = sub i128 0, %t26
  %t30 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s2, i1 true, i128 %t28)
  store %"compiler/check:signMag" %t30, ptr %l15
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t31 = load %"compiler/check:signMag", ptr %l15
  store %"compiler/check:signMag" %t31, ptr %rv
  br label %ret
bb12:
  %t32 = load %"compiler/check:signMag", ptr %l1
  store %"compiler/check:signMag" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:signMag", ptr %rv
  ret %"compiler/check:signMag" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca %"compiler/check:signMag"
  %l4 = alloca i1
  %l5 = alloca i128
  %l6 = alloca %"compiler/check:signMag"
  %l7 = alloca i1
  %l8 = alloca i128
  %l9 = alloca i1
  %l10 = alloca i128
  %l12 = alloca %"compiler/check:signMag"
  %l16 = alloca %"compiler/check:signMag"
  %l21 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l36 = alloca i128
  %l42 = alloca i128
  %l52 = alloca %"compiler/check:litv"
  %l55 = alloca %"compiler/check:litv"
  %l58 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2etwos(%"compiler/check:litv" %a1)
  store %"compiler/check:signMag" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load %"compiler/check:signMag", ptr %l12
  store %"compiler/check:signMag" %t4, ptr %l3
  %t5 = getelementptr %"compiler/check:signMag", ptr %l3, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l4, !tbaa !21
  %t8 = getelementptr %"compiler/check:signMag", ptr %l3, i32 0, i32 1
  %t9 = load i128, ptr %t8
  store i128 %t9, ptr %l5
  %t13 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2etwos(%"compiler/check:litv" %a2)
  store %"compiler/check:signMag" %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load %"compiler/check:signMag", ptr %l16
  store %"compiler/check:signMag" %t14, ptr %l6
  %t15 = getelementptr %"compiler/check:signMag", ptr %l6, i32 0, i32 0
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l7, !tbaa !21
  %t18 = getelementptr %"compiler/check:signMag", ptr %l6, i32 0, i32 1
  %t19 = load i128, ptr %t18
  store i128 %t19, ptr %l8
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t23 = trunc i64 102 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i1, ptr %l4, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb4:
  %t28 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t30 = trunc i64 103 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb8, label %bb9
bb5:
  %t33 = load i1, ptr %l7, !tbaa !21
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l23, !tbaa !21
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb14
bb8:
  %t36 = load i1, ptr %l4, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb9:
  %t38 = load i1, ptr %l4, !tbaa !21
  %t39 = load i1, ptr %l7, !tbaa !21
  %t42 = icmp ne i1 %t38, %t39
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb13
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t44 = load i1, ptr %l7, !tbaa !21
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l27, !tbaa !21
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %l9, !tbaa !21
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t51 = trunc i64 102 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load i128, ptr %l5
  %t55 = load i128, ptr %l8
  %t58 = and i128 %t54, %t55
  store i128 %t58, ptr %l36
  br label %bb20
bb16:
  %t60 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t62 = trunc i64 103 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load i128, ptr %l5
  %t66 = load i128, ptr %l8
  %t69 = or i128 %t65, %t66
  store i128 %t69, ptr %l42
  br label %bb19
bb18:
  %t71 = load i128, ptr %l5
  %t72 = load i128, ptr %l8
  %t75 = xor i128 %t71, %t72
  store i128 %t75, ptr %l42
  br label %bb19
bb19:
  %t77 = load i128, ptr %l42
  store i128 %t77, ptr %l36
  br label %bb20
bb20:
  %t78 = load i128, ptr %l36
  store i128 %t78, ptr %l10
  %t79 = load i1, ptr %l9, !tbaa !21
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t83 = load i128, ptr %l10
  %t85 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 false, i128 %t83)
  store %"compiler/check:litv" %t85, ptr %l52
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t86 = load %"compiler/check:litv", ptr %l52
  store %"compiler/check:litv" %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load i128, ptr %l10
  %t89 = icmp eq i128 %t87, 0
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t91, ptr %l55
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t92 = load %"compiler/check:litv", ptr %l55
  store %"compiler/check:litv" %t92, ptr %rv
  br label %ret
bb28:
  %t93 = load i128, ptr %l10
  %t95 = sub i128 0, %t93
  %t97 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 true, i128 %t95)
  store %"compiler/check:litv" %t97, ptr %l58
  br label %bb29
bb29:
  %t98 = load %"compiler/check:litv", ptr %l58
  store %"compiler/check:litv" %t98, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fcheck_3aframe_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2ecompiler_2fgeneric_3aContext_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fgeneric_3aContext_2e3 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"comptime." }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d4 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d5 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d6 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"is of an owner that is no generic" }>, align 8
@.d7 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a.LanesLess(b)" }>, align 8
@.d8 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"b.LanesLess(a)" }>, align 8
@.d9 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"not b.LanesLess(a)" }>, align 8
@.d10 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"not a.LanesLess(b)" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d12 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'xor'" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"MatMul" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'@'" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2e0 = weak hidden constant i1 false
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Here" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3arawTable_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3arawTable_2e3 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"From" }>, align 8
@olang_2esole_2eArray_3cArray_3cU8_3e_26_3e_2e_2d1 = weak hidden constant i1 false
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cU8_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cU8_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d21 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"18446744073709551616" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Byte" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d24 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d26 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] [] }>, align 8
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2etraitHeader_2elocal_2e27 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"RefMut" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Ref" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
declare i64 @__olang_fmt_u128(ptr, i128)
declare i64 @__olang_fmt_u64(ptr, i64)
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3cU8_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t13
  %t17 = load i8, ptr %t16, !tbaa !32
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t18
  %t22 = load i8, ptr %t21, !tbaa !32
  %t25 = icmp eq i8 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/typed:Local" %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayLengthRange(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsLength(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3, i1 %a4)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsSynth(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_H19fded22be32a91ca4084130356a325d(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_fa3c94e3a612a0dd_4761343759351551 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i64 %a4, i32 %a5)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_26959ece93e3b5d7_ef6153c643f98adb = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyFieldRow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
@olang_loc_dcaa30bcf0ceb4b1_7307533feb398e7d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i1 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b = external constant [0 x i8]
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePackedByValueC(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExternType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExternResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H51b81a00fa8bf5fab3fd9fdb4d8e9d32(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIdentityOfValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
@olang_loc_652199a1d15cfac6_f2a0b86627c88902 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
@olang_loc_7509e56452997e5b_fb360af196d85db7 = external constant [0 x i8]
@olang_loc_ff81ff8210117a78_6f7a62fdc976c914 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ef037029164a29a_21fd292be875b5ee = external constant [0 x i8]
@olang_loc_bb01d10f777a4448_96828c8732d8ad84 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberInPlace(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberInPlaceKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ad750d80deeaf923_2ed747fea17822bf = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberOwnerArgs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @compiler_2fcheck_2elaneTok(i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneCompare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ebinaryOp(i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2eintOnly(i32 %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlaceMember(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceType(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eColumnAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2efreshValue(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2efieldNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadWordBare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_97f728d69fa9714_fb4d660b7b54b10 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedAt(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleRaised(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedSettled(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleBy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eRaisedFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_761ecce271a1def0_6ef2889dc9577e64 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaisedFieldsDiffer(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a7c6fed1dc036a32_295e341353c4274e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ff4549fd04ada907_b78a4102fd7994db = external constant [0 x i8]
declare %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i1 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_674ca34a4d5f8d72_a138681dd06a86e = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawWithoutType(ptr %v0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawType(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5479af00bceefeb1_f5b0eb753f441165 = external constant [0 x i8]
@olang_loc_4e17f4aa3948dea4_42025b20baf190f8 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0)
@olang_loc_15162faa0a6b8e7b_16d808b76471f267 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFromCaseName(ptr %v0)
@olang_loc_c9b25feecc9d128e_1218ffeebcd03452 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2etextBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_7a0bf9c228cd53f_3b674c8d006cd93 = external constant [0 x i8]
declare { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNotLiteral(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawRepeated(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
declare %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eaddMag(i1 %a0, i128 %a1, i1 %a2, i128 %a3)
@olang_loc_bdfafd86356a320_3271504b736459c4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %a0)
@olang_loc_cf3f79d848e44ed1_488edda033e9ba8d = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRawNoFit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
@olang_loc_fbd40b14c0771014_77084db5763620a0 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eLen_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eAt_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ejoinBytes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eSetAt_H0cacde38b1fa68c0147c90767fcd1b03(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
@olang_loc_3b34ae24d6eb5f50_7a213241b294babc = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTraitSig(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_21d2c8212e1ec20a_d97fbaae9e5bc606 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2eCtorOwner(i32 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
@olang_loc_86f2d648d7a819c5_fc1d6e84e063e4d9 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a50575fe0cbf16d0_d0ac681a5111f894 = external constant [0 x i8]
@olang_loc_60e1b0f1da45c3fd_13c1ffbfc1f1b5a1 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsCopy(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueFill(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ef99e54d7427d8e6_6c42201a9dddf792 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %a0, i128 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %a0)
@olang_loc_83df14ccfb59caa2_79e7c0956b45666e = external constant [0 x i8]
declare %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %v0, i1 %a0, i128 %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
