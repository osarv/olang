; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/prompt:cell" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/prompt:Reply" = type { i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/prompt:program" = type { %"std/prelude/text:StringBuilder", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/prompt:Session" = type { ptr, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/eval:Snapshot", { ptr, ptr }, i1, i1, %"compiler/cells:Worker", %"compiler/build:Config", { i64, ptr } }
%"compiler/eval:Snapshot" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/cells:Worker" = type { i1, i32, i32, i32, i32, i32, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/interp:Exec" = type { ptr, ptr, i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/eval:Machine" = type { ptr, i32, i64, { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/prompt:Value" = type { { i64, ptr }, { i64, ptr }, i1, i64, { i64, ptr }, { i64, ptr } }
%"compiler/prompt:Decl" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64 }
%"compiler/prompt:item" = type { i64, i64, i64, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
@G_2ecompiler_2fprompt_2eCellEntry = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\E9\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eCellEntry.k1 }>, align 8
@G_2ecompiler_2fprompt_2eCellEntry.k1 = internal constant <{ [233 x i8] }> <{ [233 x i8] c"\66\6E\20\6F\6C\61\6E\67\45\6E\74\72\79\3C\4F\6C\61\6E\67\45\6E\74\72\79\54\79\70\65\3E\28\29\20\7B\0A\20\20\20\20\74\72\79\20\6F\6C\61\6E\67\43\65\6C\6C\28\29\20\63\61\74\63\68\20\65\20\7B\0A\20\20\20\20\20\20\20\20\6F\6C\61\6E\67\46\61\69\6C\65\64\20\3A\3D\20\22\75\6E\68\61\6E\64\6C\65\64\20\65\72\72\6F\72\3A\20\22\20\2B\20\24\65\20\2B\20\22\5C\6E\22\0A\20\20\20\20\20\20\20\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\73\61\79\28\32\2C\20\6F\6C\61\6E\67\46\61\69\6C\65\64\2C\20\6F\6C\61\6E\67\46\61\69\6C\65\64\2E\4C\65\6E\28\29\29\0A\20\20\20\20\7D\0A\7D\0A\65\78\70\6F\72\74\20\66\6E\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\72\75\6E\28\29\20\7B\20\6F\6C\61\6E\67\45\6E\74\72\79\3C\49\36\34\3E\28\29\20\7D" }>, align 64
@G_2ecompiler_2fprompt_2eCellName = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eCellName.k1 }>, align 8
@G_2ecompiler_2fprompt_2eCellName.k1 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\6F\6C\61\6E\67\43\65\6C\6C" }>, align 8
@G_2ecompiler_2fprompt_2eHelpText = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\41\02\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eHelpText.k1 }>, align 8
@G_2ecompiler_2fprompt_2eHelpText.k1 = internal constant <{ [577 x i8] }> <{ [577 x i8] c"\45\61\63\68\20\65\6E\74\72\79\20\69\73\20\61\20\63\65\6C\6C\3A\20\64\65\63\6C\61\72\61\74\69\6F\6E\73\20\28\66\6E\2C\20\74\79\70\65\2C\20\69\6D\70\6F\72\74\2C\20\61\20\67\6C\6F\62\61\6C\29\20\6A\6F\69\6E\20\74\68\65\20\73\65\73\73\69\6F\6E\2C\20\61\6E\64\20\73\74\61\74\65\6D\65\6E\74\73\20\72\75\6E\20\2D\20\74\68\65\69\72\0A\74\6F\70\2D\6C\65\76\65\6C\20\6C\6F\63\61\6C\73\20\6B\65\70\74\20\66\6F\72\20\74\68\65\20\63\65\6C\6C\73\20\61\66\74\65\72\2E\20\41\20\63\65\6C\6C\20\77\68\6F\73\65\20\6C\61\73\74\20\73\74\61\74\65\6D\65\6E\74\20\69\73\20\61\6E\20\65\78\70\72\65\73\73\69\6F\6E\20\73\68\6F\77\73\20\69\74\73\20\76\61\6C\75\65\2E\20\41\6E\20\65\6E\74\72\79\0A\67\6F\65\73\20\6F\6E\20\6F\76\65\72\20\73\65\76\65\72\61\6C\20\6C\69\6E\65\73\20\77\68\69\6C\65\20\61\20\62\72\61\63\6B\65\74\20\69\73\20\6F\70\65\6E\2E\20\41\20\63\65\6C\6C\20\64\65\63\6C\61\72\69\6E\67\20\61\20\6E\61\6D\65\20\61\67\61\69\6E\20\72\65\70\6C\61\63\65\73\20\77\68\61\74\20\68\61\64\20\69\74\2E\0A\20\20\3A\74\79\70\65\20\45\58\50\52\20\20\20\74\68\65\20\74\79\70\65\20\6F\66\20\74\68\65\20\65\78\70\72\65\73\73\69\6F\6E\27\73\20\76\61\6C\75\65\0A\20\20\3A\6C\6F\61\64\20\46\49\4C\45\20\20\20\74\68\65\20\66\69\6C\65\27\73\20\74\65\78\74\20\61\73\20\61\20\63\65\6C\6C\0A\20\20\3A\73\65\74\20\76\69\20\20\20\20\20\20\76\69\27\73\20\6B\65\79\73\20\61\74\20\74\68\65\20\70\72\6F\6D\70\74\20\28\3A\73\65\74\20\65\6D\61\63\73\2C\20\65\6D\61\63\73\27\73\20\2D\20\74\68\65\20\64\65\66\61\75\6C\74\29\2C\20\72\65\6D\65\6D\62\65\72\65\64\0A\20\20\3A\68\65\6C\70\20\20\20\20\20\20\20\20\74\68\69\73\0A\20\20\3A\71\75\69\74\20\20\20\20\20\20\20\20\6C\65\61\76\65\73\20\28\73\6F\20\64\6F\65\73\20\74\68\65\20\65\6E\64\20\6F\66\20\74\68\65\20\69\6E\70\75\74\29" }>, align 64
@G_2ecompiler_2fprompt_2eKeepPrefix = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eKeepPrefix.k1 }>, align 8
@G_2ecompiler_2fprompt_2eKeepPrefix.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\6F\6C\61\6E\67\4B\65\65\70\5F" }>, align 8
@G_2ecompiler_2fprompt_2eRichDecls = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\37\01\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eRichDecls.k1 }>, align 8
@G_2ecompiler_2fprompt_2eRichDecls.k1 = internal constant <{ [311 x i8] }> <{ [311 x i8] c"\6F\6C\61\6E\67\53\68\6F\77\6E\4D\69\6D\65\20\6D\75\74\20\53\74\72\69\6E\67\20\3D\20\22\22\0A\6F\6C\61\6E\67\53\68\6F\77\6E\44\61\74\61\20\6D\75\74\20\53\74\72\69\6E\67\20\3D\20\22\22\0A\66\6E\20\6F\6C\61\6E\67\53\68\6F\77\6E\52\69\63\68\3C\4F\6C\61\6E\67\53\68\6F\77\6E\54\79\70\65\3E\28\76\20\4F\6C\61\6E\67\53\68\6F\77\6E\54\79\70\65\29\20\7B\0A\20\20\20\20\6D\61\74\63\68\20\4F\6C\61\6E\67\53\68\6F\77\6E\54\79\70\65\20\7B\0A\20\20\20\20\20\20\20\20\63\61\73\65\20\44\69\73\70\6C\61\79\61\62\6C\65\20\7B\0A\20\20\20\20\20\20\20\20\20\20\20\20\64\20\3A\3D\20\76\2E\44\69\73\70\6C\61\79\28\29\0A\20\20\20\20\20\20\20\20\20\20\20\20\6F\6C\61\6E\67\53\68\6F\77\6E\4D\69\6D\65\20\3D\20\64\2E\4D\69\6D\65\28\29\0A\20\20\20\20\20\20\20\20\20\20\20\20\6F\6C\61\6E\67\53\68\6F\77\6E\44\61\74\61\20\3D\20\64\2E\42\6F\64\79\28\29\0A\20\20\20\20\20\20\20\20\7D\0A\20\20\20\20\20\20\20\20\63\61\73\65\20\5F\20\7B\20\7D\0A\20\20\20\20\7D\0A\7D" }>, align 64
@G_2ecompiler_2fprompt_2eRichName = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eRichName.k1 }>, align 8
@G_2ecompiler_2fprompt_2eRichName.k1 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\6F\6C\61\6E\67\53\68\6F\77\6E\52\69\63\68" }>, align 8
@G_2ecompiler_2fprompt_2eSayDecl = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eSayDecl.k1 }>, align 8
@G_2ecompiler_2fprompt_2eSayDecl.k1 = internal constant <{ [62 x i8] }> <{ [62 x i8] c"\65\78\74\65\72\6E\20\7B\20\66\6E\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\73\61\79\28\6B\69\6E\64\20\49\36\34\2C\20\64\61\74\61\20\41\72\72\61\79\3C\55\38\3E\26\2C\20\6E\20\49\36\34\29\20\7D" }>, align 32
@G_2ecompiler_2fprompt_2eSayShown = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\C3\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eSayShown.k1 }>, align 8
@G_2ecompiler_2fprompt_2eSayShown.k1 = internal constant <{ [195 x i8] }> <{ [195 x i8] c"\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\73\61\79\28\31\2C\20\6F\6C\61\6E\67\53\68\6F\77\6E\2C\20\6F\6C\61\6E\67\53\68\6F\77\6E\2E\4C\65\6E\28\29\29\0A\69\66\20\6F\6C\61\6E\67\53\68\6F\77\6E\4D\69\6D\65\20\21\3D\20\22\22\20\7B\0A\20\20\20\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\73\61\79\28\33\2C\20\6F\6C\61\6E\67\53\68\6F\77\6E\4D\69\6D\65\2C\20\6F\6C\61\6E\67\53\68\6F\77\6E\4D\69\6D\65\2E\4C\65\6E\28\29\29\0A\20\20\20\20\6F\6C\61\6E\67\5F\63\65\6C\6C\5F\73\61\79\28\34\2C\20\6F\6C\61\6E\67\53\68\6F\77\6E\44\61\74\61\2C\20\6F\6C\61\6E\67\53\68\6F\77\6E\44\61\74\61\2E\4C\65\6E\28\29\29\0A\7D" }>, align 64
@G_2ecompiler_2fprompt_2eShownName = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eShownName.k1 }>, align 8
@G_2ecompiler_2fprompt_2eShownName.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\6F\6C\61\6E\67\53\68\6F\77\6E" }>, align 8
@G_2ecompiler_2fprompt_2eSynthetic = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fprompt_2eSynthetic.k1 }>, align 8
@G_2ecompiler_2fprompt_2eSynthetic.k1 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\65\73\73\69\6F\6E" }>, align 8
define dso_local i1 @compiler_2fprompt_2eOpen(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/scan:Tokens"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/scan:Diag"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/token:Token"
  %l12 = alloca %"compiler/scan:Tokens"
  %l16 = alloca i64
  %l19 = alloca i1
  %l24 = alloca { i64, ptr }
  %l29 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l52 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store %"compiler/scan:Tokens" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load %"compiler/scan:Tokens", ptr %l12
  store %"compiler/scan:Tokens" %t4, ptr %l1
  %t5 = getelementptr %"compiler/scan:Tokens", ptr %l1, i32 0, i32 3
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = sub i64 %t12, 1
  store i64 %t13, ptr %l16, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t14, 2147483648
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  %t20 = and i1 %t15, %t17
  store i1 %t20, ptr %l19, !tbaa !21
  br label %bb2
bb2:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l24, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr %"compiler/scan:Diag", ptr %t33, i64 %t30
  %t35 = load %"compiler/scan:Diag", ptr %t34
  store %"compiler/scan:Diag" %t35, ptr %l5
  %t37 = getelementptr %"compiler/scan:Diag", ptr %l5, i32 0, i32 0
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 31}
  %t40 = trunc i64 20 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  %t43 = getelementptr %"compiler/scan:Diag", ptr %l5, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 31}
  %t46 = trunc i64 7 to i32
  %t47 = icmp eq i32 %t44, %t46
  store i1 %t47, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t49 = load i1, ptr %l29, !tbaa !21
  br i1 %t49, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb2
bb13:
  store i64 0, ptr %l6, !tbaa !24
  %t56 = getelementptr %"compiler/scan:Tokens", ptr %l1, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  br label %bb27
bb16:
  br label %bb17
bb17:
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr %"compiler/token:Token", ptr %t75, i64 %t72
  %t77 = load %"compiler/token:Token", ptr %t76
  store %"compiler/token:Token" %t77, ptr %l10
  %t79 = getelementptr %"compiler/token:Token", ptr %l10, i32 0, i32 0
  %t80 = load i32, ptr %t79, !range !{i32 0, i32 116}
  %t82 = call i1 @compiler_2fprompt_2eopens(i32 %t80)
  store i1 %t82, ptr %l47
  br label %bb18
bb18:
  %t83 = load i1, ptr %l47, !tbaa !21
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l6, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t89 = getelementptr %"compiler/token:Token", ptr %l10, i32 0, i32 0
  %t90 = load i32, ptr %t89, !range !{i32 0, i32 116}
  %t92 = call i1 @compiler_2fprompt_2ecloses(i32 %t90)
  store i1 %t92, ptr %l52
  br label %bb22
bb22:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = sub i64 %t94, 1
  store i64 %t97, ptr %l6, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = add i64 %t99, 1
  store i64 %t102, ptr %l8, !tbaa !24
  br label %bb14
bb27:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fprompt_2ecellBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l12 = alloca ptr
  %l16 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i64
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l54 = alloca ptr
  %l63 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l12, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 12
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l16, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 3
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eCellName, !tbaa !27
  %t26 = load ptr, ptr @__olang_prog_scope
  %t29 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %t26, ptr %t24, { i64, ptr } %t25)
  store i32 %t29, ptr %l22
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l12, !tbaa !29
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i32, ptr %l22, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t30, i64 %t31, i32 %t32)
  store i64 %t33, ptr %l23
  br label %bb2
bb2:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 19
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l26
  br label %bb3
bb3:
  %t40 = load i64, ptr %l26, !tbaa !24
  store i64 %t40, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb4, label %bb5
bb4:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb9
bb6:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l2, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l33, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb8
bb8:
  %t67 = load i64, ptr %l33, !tbaa !24
  store i64 %t67, ptr %l30, !tbaa !24
  br label %bb9
bb9:
  %t68 = load i64, ptr %l30, !tbaa !24
  store i64 %t68, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb11, label %bb12
bb11:
  br label %bb29
bb12:
  br label %bb13
bb13:
  %t77 = load i64, ptr %l2, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l4, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l7, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 19
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l54
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l54, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 1
  %t98 = load { i64, [2 x i64] }, ptr %t97
  store { i64, [2 x i64] } %t98, ptr %l9
  %t100 = load { i64, [2 x i64] }, ptr %l9
  %t102 = extractvalue { i64, [2 x i64] } %t100, 0
  %t103 = icmp eq i64 %t102, 0
  br i1 %t103, label %bb15, label %bb16
bb15:
  %t105 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t106 = getelementptr { i64 }, ptr %t105, i32 0, i32 0
  %t107 = load i64, ptr %t106
  store i64 %t107, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l63
  br label %bb18
bb18:
  %t117 = load i64, ptr %l1, !tbaa !24
  %t118 = load i64, ptr %l63, !tbaa !24
  %t120 = icmp eq i64 %t118, %t117
  br i1 %t120, label %bb19, label %bb20
bb19:
  %t122 = load i64, ptr %l7, !tbaa !24
  store i64 %t122, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ff9ee7abf6d47f0b_7ec27dc509c45f6f)
  unreachable
bb27:
  br label %bb28
bb28:
  %t124 = load i64, ptr %l6, !tbaa !24
  %t127 = add i64 %t124, 1
  store i64 %t127, ptr %l6, !tbaa !24
  br label %bb10
bb29:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fprompt_2ecloses(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 111 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 113 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t14 = trunc i64 115 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eEnd(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/prompt:cell"
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/prompt:Reply"
  %l5 = alloca ptr
  %l6 = alloca { i64, [2 x i64] }
  %l13 = alloca i64
  %l15 = alloca %"compiler/prompt:cell"
  %l16 = alloca %"compiler/diag:Diagnostics"
  %l17 = alloca ptr
  %l24 = alloca %"compiler/prompt:program"
  %l27 = alloca ptr
  %l30 = alloca %"compiler/prompt:Reply"
  %l35 = alloca ptr
  %l39 = alloca i64
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca { i64, [5 x i64] }
  %s0 = alloca %olang.scope
  %t21 = alloca %"compiler/diag:Diagnostics", align 8
  %t47 = alloca %"compiler/prompt:Reply", align 8
  %t66 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:Session", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eendCompiled(ptr %v0, ptr %v1, ptr %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/prompt:Session", ptr %t10, i32 0, i32 5
  %t13 = getelementptr %"compiler/eval:Snapshot", ptr %t12, i32 0, i32 2
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l13
  br label %bb5
bb5:
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = icmp eq i64 %t16, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = call %"compiler/prompt:cell" @compiler_2fprompt_3acell_2ector(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store %"compiler/prompt:cell" %t19, ptr %l15
  br label %bb9
bb9:
  %t20 = load %"compiler/prompt:cell", ptr %l15
  store %"compiler/prompt:cell" %t20, ptr %l1
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t21, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t21, i64 704, i1 false)
  br label %bb10
bb10:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l16, i64 704, i1 false)
  %t22 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 25
  store i1 true, ptr %t22, !tbaa !21
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/prompt:Session", ptr %t25, i32 0, i32 3
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/prompt:Session", ptr %t28, i32 0, i32 4
  %t35 = call %"compiler/prompt:program" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ewrite(ptr %v0, ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t24, ptr %t27, ptr %t30, ptr %l1, i1 false)
  store %"compiler/prompt:program" %t35, ptr %l24
  br label %bb11
bb11:
  %t36 = load %"compiler/prompt:program", ptr %l24
  %t37 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 128, i64 8)
  store %"compiler/prompt:program" %t36, ptr %t37
  %t38 = load ptr, ptr %l17, !tbaa !29
  %t41 = call ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2echeck(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t38, ptr %t37, ptr %l2)
  store ptr %t41, ptr %l27
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l27, !tbaa !29
  store ptr %t42, ptr %l3, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @compiler_2fprompt_3aReply_2ector(ptr %t47, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t47, i64 144, i1 false)
  br label %bb16
bb16:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l30, i64 144, i1 false)
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t54 = call ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2emachine(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t48, ptr %t49, ptr %l2, ptr %l4)
  store ptr %t54, ptr %l35
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l35, !tbaa !29
  store ptr %t55, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = call i64 @compiler_2fprompt_2ecellBody(ptr %s0, ptr %t60)
  store i64 %t62, ptr %l39
  br label %bb21
bb21:
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = trunc i64 %t63 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t69 = insertvalue { i32 } undef, i32 %t64, 0
  %t70 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 1
  store { i32 } %t69, ptr %t70
  %t71 = load { i64, [2 x i64] }, ptr %t66
  store { i64, [2 x i64] } %t71, ptr %l6
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t74 = load { i64, [2 x i64] }, ptr %l6
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %s0, ptr %t73, { i64, [2 x i64] } %t74)
  br label %bb22
bb22:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/prompt:Session", ptr %t80, i32 0, i32 4
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erestore(ptr %v0, ptr %s0, ptr %s0, ptr %v0, ptr %s0, ptr %t77, ptr %t78, ptr %t79, ptr %t82)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l50
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/interp:Exec", ptr %t88, i32 0, i32 4
  %t91 = load { i64, [2 x i64] }, ptr %l6
  %t94 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEndProgram(ptr %s0, ptr %s0, ptr %t90, { i64, [2 x i64] } %t91)
  store { i64, [5 x i64] } %t94, ptr %l54
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ecellDir(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/prompt:Session", ptr %a0, i32 0, i32 10
  %t4 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  %t6 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = load i32, ptr %l3, !tbaa !23
  %t14 = sext i32 %t13 to i64
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t8, i64 %t9)
  %t18 = getelementptr i8, ptr %t17, i64 %t9
  call void @olang_textcopy(ptr %t18, ptr %t10, i64 %t11)
  %t19 = getelementptr i8, ptr %t18, i64 %t11
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t14)
  %t21 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t17, 1
  store { i64, ptr } %t22, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eglobalSym(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/prompt:Session", ptr %a0, i32 0, i32 11
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t9 = extractvalue { i64, ptr } %t4, 1
  %t10 = extractvalue { i64, ptr } %t4, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t6, i64 %t7)
  %t20 = getelementptr i8, ptr %t19, i64 %t7
  call void @olang_textcopy(ptr %t20, ptr %t9, i64 %t10)
  %t21 = getelementptr i8, ptr %t20, i64 %t10
  call void @olang_textcopy(ptr %t21, ptr %t12, i64 %t13)
  %t22 = getelementptr i8, ptr %t21, i64 %t13
  call void @olang_textcopy(ptr %t22, ptr %t16, i64 %t17)
  %t23 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t19, 1
  %t27 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s0, ptr %v2, { i64, ptr } %t24)
  store { i64, ptr } %t27, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erestore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/prompt:Value"
  %l11 = alloca { %"compiler/eval:Ptr", i32 }
  %l12 = alloca %"compiler/eval:Ptr"
  %l21 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca %"compiler/prompt:Value"
  %l32 = alloca { %"compiler/eval:Ptr", i32 }
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l41 = alloca i32
  %l42 = alloca { %"compiler/eval:Ptr", i32 }
  %l43 = alloca i32
  %l45 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l64 = alloca i32
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 12
  %t10 = load i64, ptr %t9, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 3
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aPtr_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t23, ptr %l21
  br label %bb1
bb1:
  %t24 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t24, ptr %l6
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l22
  br label %bb2
bb2:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l7
  store ptr %a3, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb3
bb3:
  %t29 = load i64, ptr %l9, !tbaa !24
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load ptr, ptr %l8, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t30)
  store i64 %t32, ptr %l26
  br label %bb4
bb4:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = load i64, ptr %l26, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb5, label %bb6
bb5:
  br label %bb30
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l8, !tbaa !29
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v3, ptr %t39, i64 %t40)
  store %"compiler/prompt:Value" %t43, ptr %l31
  br label %bb8
bb8:
  %t44 = load %"compiler/prompt:Value", ptr %l31
  store %"compiler/prompt:Value" %t44, ptr %l10
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/interp:Exec", ptr %t45, i32 0, i32 4
  store ptr %t47, ptr %l34, !tbaa !29
  %t48 = load i64, ptr %l4, !tbaa !24
  store i64 %t48, ptr %l35, !tbaa !24
  %t49 = load ptr, ptr %l5, !tbaa !29
  store ptr %t49, ptr %l36, !tbaa !29
  %t50 = call ptr @__olang_scope_hold(ptr %v1)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l37, !tbaa !24
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load ptr, ptr %l36, !tbaa !29
  %t55 = call ptr @__olang_region_or(ptr %t54, ptr %v1)
  %t56 = call ptr @__olang_scope_hold(ptr %t55)
  %t57 = ptrtoint ptr %t56 to i64
  store i64 %t57, ptr %l37, !tbaa !24
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l37
  %t62 = inttoptr i64 %t61 to ptr
  %t65 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t62, ptr %v3, ptr %t58, { i64, ptr } %t60)
  store i32 %t65, ptr %l41
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = load i64, ptr %l35, !tbaa !24
  %t68 = load i32, ptr %l41, !tbaa !23
  %t69 = call { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v2, ptr %t66, i64 %t67, i32 %t68)
  %t70 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t69, 1
  %t71 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t69, 0
  store i32 %t71, ptr %l43
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb13, label %ok.73, !prof !99
ok.73:
  store { %"compiler/eval:Ptr", i32 } %t70, ptr %l42
  br label %bb12
bb12:
  %t74 = load { %"compiler/eval:Ptr", i32 }, ptr %l42
  store { %"compiler/eval:Ptr", i32 } %t74, ptr %l32
  br label %bb15
bb13:
  %t75 = load i32, ptr %l43, !tbaa !23
  %t76 = ashr i32 %t75, 16
  %t78 = icmp eq i32 %t76, 1
  store i1 %t78, ptr %l45, !tbaa !21
  br label %bb14
bb14:
  br label %bb29
bb15:
  %t79 = load { %"compiler/eval:Ptr", i32 }, ptr %l32
  store { %"compiler/eval:Ptr", i32 } %t79, ptr %l11
  %t80 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l11, i32 0, i32 0
  %t81 = load %"compiler/eval:Ptr", ptr %t80
  store %"compiler/eval:Ptr" %t81, ptr %l12
  %t83 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 3
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb16, label %bb17
bb16:
  %t88 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 2
  %t89 = load i1, ptr %t88, !tbaa !21
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb18, label %bb19
bb17:
  br label %bb22
bb18:
  %t93 = load %"compiler/prompt:Value", ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v4, ptr %v3, ptr %l7, %"compiler/prompt:Value" %t93)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb29
bb22:
  %t96 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 3
  %t97 = load i64, ptr %t96, !tbaa !24
  %t98 = load %"compiler/eval:Ptr", ptr %l12
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aPtr_3e_2ePu_H449382aeee6306bad5d4fc1429daba25(ptr %s0, ptr %l6, i64 %t97, %"compiler/eval:Ptr" %t98)
  br label %bb23
bb23:
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/interp:Exec", ptr %t102, i32 0, i32 4
  store ptr %t104, ptr %l57, !tbaa !29
  %t105 = load i64, ptr %l4, !tbaa !24
  store i64 %t105, ptr %l58, !tbaa !24
  %t106 = load ptr, ptr %l5, !tbaa !29
  store ptr %t106, ptr %l59, !tbaa !29
  %t107 = call ptr @__olang_scope_hold(ptr %v1)
  %t108 = ptrtoint ptr %t107 to i64
  store i64 %t108, ptr %l60, !tbaa !24
  %t109 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t109, label %bb24, label %bb25
bb24:
  %t111 = load ptr, ptr %l59, !tbaa !29
  %t112 = call ptr @__olang_region_or(ptr %t111, ptr %v1)
  %t113 = call ptr @__olang_scope_hold(ptr %t112)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l60, !tbaa !24
  br label %bb25
bb25:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t116 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t118 = load i64, ptr %l60
  %t119 = inttoptr i64 %t118 to ptr
  %t122 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t119, ptr %v3, ptr %t115, { i64, ptr } %t117)
  store i32 %t122, ptr %l64
  br label %bb26
bb26:
  %t123 = load ptr, ptr %l57, !tbaa !29
  %t124 = load i64, ptr %l58, !tbaa !24
  %t125 = load i32, ptr %l64, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eMarkSet(ptr %v2, ptr %t123, i64 %t124, i32 %t125)
  br label %bb27
bb27:
  %t126 = load %"compiler/prompt:Value", ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v4, ptr %v3, ptr %l7, %"compiler/prompt:Value" %t126)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = add i64 %t129, 1
  store i64 %t132, ptr %l9, !tbaa !24
  br label %bb3
bb30:
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = getelementptr %"compiler/interp:Exec", ptr %t134, i32 0, i32 4
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/prompt:Session", ptr %t137, i32 0, i32 5
  store ptr %t139, ptr %l73, !tbaa !29
  store ptr %l6, ptr %l74, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  store ptr %t140, ptr %l75, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/prompt:Session", ptr %t141, i32 0, i32 5
  %t144 = getelementptr %"compiler/eval:Snapshot", ptr %t143, i32 0, i32 2
  %t146 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t144)
  store { i64, ptr } %t146, ptr %l78
  br label %bb31
bb31:
  %t147 = load ptr, ptr %l75, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t149 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2finterp_2ecompiler_2finterp_3aExec_2eDropTypes(ptr %v2, ptr %v0, ptr %s0, ptr %t147, { i64, ptr } %t148)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t149, ptr %l79
  br label %bb32
bb32:
  %t150 = load ptr, ptr %l71, !tbaa !29
  %t151 = load ptr, ptr %l73, !tbaa !29
  %t152 = load ptr, ptr %l74, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eRestore(ptr %v2, ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t150, ptr %t151, ptr %t152, ptr %l79)
  store { i64, ptr } %t154, ptr %l81
  br label %bb33
bb33:
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2estoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eglobalSym(ptr %v0, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t8, i64 %t9)
  %t17 = getelementptr i8, ptr %t16, i64 %t9
  call void @olang_textcopy(ptr %t17, ptr %t10, i64 %t11)
  %t18 = getelementptr i8, ptr %t17, i64 %t11
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %a2)
  %t20 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t16, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fprompt_2eendsAt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca %"compiler/token:Token"
  %l3 = alloca i32
  %l9 = alloca %"compiler/token:Token"
  %l10 = alloca { i64, ptr }
  %l15 = alloca %"compiler/token:Token"
  %l19 = alloca { i64, ptr }
  %l25 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l37 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = add i64 %t1, 1
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/token:Token", ptr %t17, i64 %t14
  %t19 = load %"compiler/token:Token", ptr %t18
  store %"compiler/token:Token" %t19, ptr %l9
  br label %bb4
bb2:
  %t22 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s0, i32 0, i8 0, i32 0, i32 0)
  store %"compiler/token:Token" %t22, ptr %l15
  br label %bb3
bb3:
  %t23 = load %"compiler/token:Token", ptr %l15
  store %"compiler/token:Token" %t23, ptr %l9
  br label %bb4
bb4:
  %t24 = load %"compiler/token:Token", ptr %l9
  store %"compiler/token:Token" %t24, ptr %l2
  %t25 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 0
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 116}
  %t28 = trunc i64 0 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr %"compiler/token:Token", ptr %t36, i64 %t33
  %t38 = getelementptr %"compiler/token:Token", ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38, !range !{i32 0, i32 116}
  store i32 %t39, ptr %l3
  %t41 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t43 = trunc i64 8 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t50 = trunc i64 115 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb14
bb10:
  %t53 = load %"compiler/token:Token", ptr %l2
  %t54 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t57 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t53, i8 %t54)
  store i1 %t57, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t58 = load i1, ptr %l31, !tbaa !21
  store i1 %t58, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l28, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t62 = load i1, ptr %l25, !tbaa !21
  br i1 %t62, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t64 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 0
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 116}
  %t67 = trunc i64 10 to i32
  %t68 = icmp eq i32 %t65, %t67
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t72 = getelementptr %"compiler/token:Token", ptr %l2, i32 0, i32 0
  %t73 = load i32, ptr %t72, !range !{i32 0, i32 116}
  %t75 = trunc i64 12 to i32
  %t76 = icmp eq i32 %t73, %t75
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l37, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i1, ptr %l37, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fprompt_2eisGlobal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:Decl", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/prompt:Decl", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v0, { i64, ptr } %t6, { i64, ptr } %t10)
  store i1 %t13, ptr %l7
  br label %bb1
bb1:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/prompt:Decl", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l12, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t22, 0
  store i64 %t25, ptr %l15, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l16, !tbaa !24
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb4, label %bb5
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb12
bb4:
  %t31 = load i64, ptr %l12, !tbaa !24
  %t32 = load i64, ptr %l15, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ab4beca8d06f686d_acb65cb479bd95a9)
  unreachable
bb6:
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = load i64, ptr %l16, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_ab4beca8d06f686d_acb65cb479bd95a9)
  unreachable
bb8:
  %t39 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l12, !tbaa !24
  %t42 = load i64, ptr %l15, !tbaa !24
  %t43 = getelementptr i8, ptr %t40, i64 %t41
  %t44 = sub i64 %t42, %t41
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t48 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %s0, { i64, ptr } %t46)
  store { i64, ptr } %t48, ptr %l21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ab4beca8d06f686d_acb65cb479bd95a9)
  unreachable
bb10:
  %t49 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t50, ptr %l22
  br label %bb11
bb11:
  %t51 = load i1, ptr %l22, !tbaa !21
  store i1 %t51, ptr %l8, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i1, ptr %l8, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/prompt:item" @compiler_2fprompt_2eitem_2eOf(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca %"compiler/prompt:item"
  %l29 = alloca { i64, ptr }
  %l31 = alloca i1
  %l34 = alloca { i64, ptr }
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca i1
  %l63 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/prompt:item"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l10, !tbaa !27
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr %"compiler/token:Token", ptr %t5, i64 %t2
  %t7 = getelementptr %"compiler/token:Token", ptr %t6, i32 0, i32 2
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = sext i32 %t8 to i64
  store i64 %t10, ptr %l13, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l14, !tbaa !27
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr %"compiler/token:Token", ptr %t15, i64 %t12
  %t17 = getelementptr %"compiler/token:Token", ptr %t16, i32 0, i32 3
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  store i64 %t20, ptr %l17, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l19, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr %"compiler/token:Token", ptr %t26, i64 %t23
  %t28 = getelementptr %"compiler/token:Token", ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  %t34 = call i64 @compiler_2fprompt_2elineOf(ptr %v0, { i64, ptr } %t21, i64 %t31)
  store i64 %t34, ptr %l23
  br label %bb1
bb1:
  %t35 = load i64, ptr %l13, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = call %"compiler/prompt:item" @compiler_2fprompt_3aitem_2ector(ptr %v2, i64 %t35, i64 %t36, i64 %t37)
  store %"compiler/prompt:item" %t38, ptr %l24
  br label %bb2
bb2:
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 88, i64 8)
  store ptr %t39, ptr %lp4
  %t40 = load %"compiler/prompt:item", ptr %l24
  %t41 = load ptr, ptr %lp4
  store %"compiler/prompt:item" %t40, ptr %t41
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t50 = call { i64, ptr } @compiler_2fprompt_2edeclKey(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %t42, { i64, ptr } %t43, i64 %t44, i64 %t45)
  store { i64, ptr } %t50, ptr %l29
  br label %bb3
bb3:
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t51, ptr %lp5
  %t52 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t53 = load ptr, ptr %lp5
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load ptr, ptr %lp5
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t57, ptr %l31
  br label %bb4
bb4:
  %t58 = load i1, ptr %l31, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb5, label %bb6
bb5:
  %t61 = load ptr, ptr %lp4
  %t62 = getelementptr %"compiler/prompt:item", ptr %t61, i32 0, i32 3
  store i1 true, ptr %t62, !tbaa !21
  %t63 = load ptr, ptr %lp5
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t65 = load ptr, ptr %lp4
  %t66 = getelementptr %"compiler/prompt:item", ptr %t65, i32 0, i32 4
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l34, !tbaa !27
  %t69 = load ptr, ptr %lp4
  %t70 = getelementptr %"compiler/prompt:item", ptr %t69, i32 0, i32 4
  store { i64, ptr } %t64, ptr %t70, !tbaa !27
  %t71 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aitem_2e4
  br i1 %t71, label %bb7, label %bb8
bb6:
  br label %bb9
bb7:
  %t73 = load { i64, ptr }, ptr %l34
  %t74 = extractvalue { i64, ptr } %t73, 1
  call void @__olang_region_release(ptr %t74)
  store { i64, ptr } zeroinitializer, ptr %l34
  br label %bb8
bb8:
  %t75 = load ptr, ptr %lp4
  %t76 = load %"compiler/prompt:item", ptr %t75
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/prompt:item" %t76, ptr %rv
  br label %ret
bb9:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t80 = load i64, ptr %l2, !tbaa !24
  %t81 = load i64, ptr %l3, !tbaa !24
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2elocalNames(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %t78, { i64, ptr } %t79, i64 %t80, i64 %t81)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l41
  br label %bb10
bb10:
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t87, ptr %lp6
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  %t89 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %t89
  %t90 = load ptr, ptr %lp6
  store ptr %t90, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t92 = load i64, ptr %l8, !tbaa !24
  store i64 %t92, ptr %l43, !tbaa !24
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t93)
  store i64 %t95, ptr %l45
  br label %bb12
bb12:
  %t96 = load i64, ptr %l43, !tbaa !24
  %t97 = load i64, ptr %l45, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l50
  br label %bb16
bb16:
  %t107 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t108 = load ptr, ptr %lp4
  %t109 = getelementptr %"compiler/prompt:item", ptr %t108, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t109, { i64, ptr } %t107)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %l8, !tbaa !24
  br label %bb11
bb19:
  %t118 = load ptr, ptr %lp6
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t118)
  store i64 %t120, ptr %l57
  br label %bb20
bb20:
  %t121 = load i64, ptr %l57, !tbaa !24
  %t122 = icmp eq i64 %t121, 0
  br i1 %t122, label %bb21, label %bb22
bb21:
  %t124 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t125 = load i64, ptr %l2, !tbaa !24
  %t126 = load i64, ptr %l3, !tbaa !24
  %t130 = call i1 @compiler_2fprompt_2eshows(ptr %v1, { i64, ptr } %t124, i64 %t125, i64 %t126)
  store i1 %t130, ptr %l63
  br label %bb23
bb22:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb24
bb23:
  %t131 = load i1, ptr %l63, !tbaa !21
  store i1 %t131, ptr %l59, !tbaa !21
  br label %bb24
bb24:
  %t132 = load i1, ptr %l59, !tbaa !21
  %t133 = load ptr, ptr %lp4
  %t134 = getelementptr %"compiler/prompt:item", ptr %t133, i32 0, i32 6
  store i1 %t132, ptr %t134, !tbaa !21
  %t135 = load ptr, ptr %lp4
  %t136 = load %"compiler/prompt:item", ptr %t135
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/prompt:item" %t136, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/prompt:item", ptr %rv
  ret %"compiler/prompt:item" %rr
}

define dso_local i64 @compiler_2fprompt_2elineOf(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %l38 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t33, 2147483648
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  %t39 = and i1 %t34, %t36
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store { i64, ptr } %a0, ptr %l38, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t56
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 10
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l2, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb7
bb15:
  %t78 = load i64, ptr %l2, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2elocalNames(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca i1
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca { i64, ptr }
  %l56 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store { i64, ptr } %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  store i64 %a2, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sle i64 %t5, %t6
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l13, !tbaa !27
  %t12 = load i64, ptr %l5, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr %"compiler/token:Token", ptr %t15, i64 %t12
  %t17 = getelementptr %"compiler/token:Token", ptr %t16, i32 0, i32 0
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 116}
  %t20 = trunc i64 1 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l12, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb20
bb7:
  br label %bb8
bb8:
  store ptr %l4, ptr %l18, !tbaa !29
  %t26 = call ptr @__olang_scope_hold(ptr %v2)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l19, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = call ptr @__olang_region_make(ptr %v2)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/token:Token", ptr %t37, i64 %t34
  %t39 = load %"compiler/token:Token", ptr %t38
  %t40 = load i64, ptr %l19
  %t41 = inttoptr i64 %t40 to ptr
  %t44 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %t41, { i64, ptr } %a0, %"compiler/token:Token" %t39)
  store { i64, ptr } %t44, ptr %l25
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t46 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t46, { i64, ptr } %t45)
  br label %bb12
bb12:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = add i64 %t48, 1
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb15
bb14:
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t56, ptr %l32, !tbaa !27
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  %t61 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr %"compiler/token:Token", ptr %t62, i64 %t59
  %t64 = getelementptr %"compiler/token:Token", ptr %t63, i32 0, i32 0
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 116}
  %t67 = trunc i64 75 to i32
  %t68 = icmp eq i32 %t65, %t67
  %t70 = xor i1 %t68, true
  store i1 %t70, ptr %l31, !tbaa !21
  br label %bb15
bb15:
  %t72 = load i1, ptr %l31, !tbaa !21
  br i1 %t72, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t73, 2
  store i64 %t76, ptr %l5, !tbaa !24
  br label %bb19
bb19:
  br label %bb2
bb20:
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %l4)
  store i64 %t79, ptr %l42
  br label %bb21
bb21:
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = icmp eq i64 %t80, 0
  br i1 %t81, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb24
bb23:
  %t83 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t83, 1
  %t86 = load i64, ptr %l3, !tbaa !24
  %t89 = icmp sgt i64 %t85, %t86
  store i1 %t89, ptr %l44, !tbaa !21
  br label %bb24
bb24:
  %t91 = load i1, ptr %l44, !tbaa !21
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l49
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %rv
  br label %ret
bb28:
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t94, ptr %l50, !tbaa !27
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t95, 1
  %t99 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr %"compiler/token:Token", ptr %t100, i64 %t97
  %t102 = getelementptr %"compiler/token:Token", ptr %t101, i32 0, i32 0
  %t103 = load i32, ptr %t102, !range !{i32 0, i32 116}
  store i32 %t103, ptr %l6
  %t105 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t107 = trunc i64 80 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb31
bb30:
  %t110 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t112 = trunc i64 1 to i32
  %t113 = icmp eq i32 %t110, %t112
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t115 = load i1, ptr %l56, !tbaa !21
  br i1 %t115, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb34
bb33:
  %t116 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t118 = trunc i64 37 to i32
  %t119 = icmp eq i32 %t116, %t118
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t121 = load i1, ptr %l59, !tbaa !21
  br i1 %t121, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb37
bb36:
  %t122 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t124 = trunc i64 52 to i32
  %t125 = icmp eq i32 %t122, %t124
  store i1 %t125, ptr %l62, !tbaa !21
  br label %bb37
bb37:
  %t127 = load i1, ptr %l62, !tbaa !21
  br i1 %t127, label %bb38, label %bb39
bb38:
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l66
  br label %bb41
bb41:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fprompt_2eopens(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 110 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 112 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t14 = trunc i64 114 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2epieces(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/scan:Tokens"
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l15 = alloca %"compiler/scan:Tokens"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l26 = alloca i64
  %l44 = alloca { i64, ptr }
  %l51 = alloca i1
  %l58 = alloca i1
  %l63 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i1
  %l77 = alloca i64
  %l81 = alloca ptr
  %l86 = alloca %"compiler/prompt:item"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %s0, { i64, ptr } %t1)
  store %"compiler/scan:Tokens" %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load %"compiler/scan:Tokens", ptr %l15
  store %"compiler/scan:Tokens" %t4, ptr %l1
  %t5 = getelementptr %"compiler/scan:Tokens", ptr %l1, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l17
  br label %bb2
bb2:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  store i64 -1, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l8, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l8, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l26, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l23, !tbaa !24
  store i64 %t41, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l10, !tbaa !24
  %t43 = load i64, ptr %l9, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  br label %bb46
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l10, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l11, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t60, ptr %l44, !tbaa !27
  %t61 = load i64, ptr %l11, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr %"compiler/token:Token", ptr %t64, i64 %t61
  %t66 = getelementptr %"compiler/token:Token", ptr %t65, i32 0, i32 0
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 116}
  store i32 %t67, ptr %l12
  %t69 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t71 = trunc i64 0 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb13, label %bb14
bb13:
  br label %bb46
bb14:
  br label %bb15
bb15:
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = icmp slt i64 %t74, 0
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t78 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t80 = trunc i64 8 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l51, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t83 = load i1, ptr %l51, !tbaa !21
  br i1 %t83, label %bb19, label %bb20
bb19:
  br label %bb45
bb20:
  br label %bb21
bb21:
  %t84 = load i64, ptr %l5, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb22, label %bb23
bb22:
  %t88 = load i64, ptr %l11, !tbaa !24
  store i64 %t88, ptr %l5, !tbaa !24
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t90 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t92 = call i1 @compiler_2fprompt_2eopens(i32 %t90)
  store i1 %t92, ptr %l58
  br label %bb25
bb25:
  %t93 = load i1, ptr %l58, !tbaa !21
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t97 = add i64 %t94, 1
  store i64 %t97, ptr %l4, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t99 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t101 = call i1 @compiler_2fprompt_2ecloses(i32 %t99)
  store i1 %t101, ptr %l63
  br label %bb29
bb29:
  %t102 = load i1, ptr %l63, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  %t103 = load i64, ptr %l4, !tbaa !24
  %t106 = sub i64 %t103, 1
  store i64 %t106, ptr %l4, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb36
bb34:
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = call i1 @compiler_2fprompt_2eendsAt(ptr %s0, { i64, ptr } %t112, i64 %t113)
  store i1 %t116, ptr %l72
  br label %bb35
bb35:
  %t117 = load i1, ptr %l72, !tbaa !21
  %t118 = xor i1 %t117, true
  store i1 %t118, ptr %l69, !tbaa !21
  br label %bb36
bb36:
  %t120 = load i1, ptr %l69, !tbaa !21
  br i1 %t120, label %bb37, label %bb38
bb37:
  br label %bb45
bb38:
  br label %bb39
bb39:
  %t121 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t123 = trunc i64 8 to i32
  %t124 = icmp eq i32 %t121, %t123
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb40, label %bb41
bb40:
  %t128 = load i64, ptr %l11, !tbaa !24
  store i64 %t128, ptr %l77, !tbaa !24
  br label %bb42
bb41:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = sub i64 %t130, 1
  store i64 %t132, ptr %l77, !tbaa !24
  br label %bb42
bb42:
  %t134 = load i64, ptr %l77, !tbaa !24
  store ptr %l3, ptr %l81, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = load i64, ptr %l5, !tbaa !24
  %t143 = call %"compiler/prompt:item" @compiler_2fprompt_2eitem_2eOf(ptr %v0, ptr %s0, ptr %v1, { i64, ptr } %t135, { i64, ptr } %t136, i64 %t137, i64 %t134)
  store %"compiler/prompt:item" %t143, ptr %l86
  br label %bb43
bb43:
  %t144 = load ptr, ptr %l81, !tbaa !29
  %t145 = load %"compiler/prompt:item", ptr %l86
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2ePush_3ccompiler_2fprompt_3aitem_3e(ptr %v1, ptr %v1, ptr %t144, %"compiler/prompt:item" %t145)
  br label %bb44
bb44:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb45
bb45:
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = add i64 %t146, 1
  store i64 %t149, ptr %l10, !tbaa !24
  br label %bb9
bb46:
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fprompt_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePut_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprompt_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %v1, { i64, ptr } %a0, %"compiler/token:Token" %a1) #0 {
entry:
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %rv = alloca { i64, ptr }
  store %"compiler/token:Token" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  %t2 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t3 = load i32, ptr %t2, !tbaa !23
  %t5 = sext i32 %t3 to i64
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l6, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sle i64 %t15, %t16
  br i1 %t17, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_62bbc83345dbe914_b70096db8abf8848)
  unreachable
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sle i64 %t19, %t20
  br i1 %t21, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_62bbc83345dbe914_b70096db8abf8848)
  unreachable
bb5:
  %t23 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = getelementptr i8, ptr %t24, i64 %t25
  %t28 = sub i64 %t26, %t25
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = extractvalue { i64, ptr } %t30, 0
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t32, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_62bbc83345dbe914_b70096db8abf8848)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprompt_3aReply_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"compiler/prompt:Reply"
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l0, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store i1 false, ptr %l2, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l9, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e8
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l9, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l9
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l11
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e8
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l9
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t22 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 0
  %t23 = load i1, ptr %l0, !tbaa !21
  store i1 %t23, ptr %t22, !tbaa !21
  %t24 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t25, ptr %t24, !tbaa !27
  %t26 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 2
  %t27 = load i1, ptr %l2, !tbaa !21
  store i1 %t27, ptr %t26, !tbaa !21
  %t28 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 3
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %t28, !tbaa !27
  %t30 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 4
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 5
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %t32, !tbaa !27
  %t34 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 6
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t35, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 7
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t37, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/prompt:Reply", ptr %l13, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %t38
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l13, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/prompt:Value" @compiler_2fprompt_3aValue_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %rv = alloca %"compiler/prompt:Value"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t8 = insertvalue %"compiler/prompt:Value" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/prompt:Value" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/prompt:Value" %t10, i1 %a2, 2
  %t14 = insertvalue %"compiler/prompt:Value" %t12, i64 -1, 3
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = insertvalue %"compiler/prompt:Value" %t14, { i64, ptr } %t15, 4
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t18 = insertvalue %"compiler/prompt:Value" %t16, { i64, ptr } %t17, 5
  store %"compiler/prompt:Value" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/prompt:Value", ptr %rv
  ret %"compiler/prompt:Value" %rr
}

define dso_local %"compiler/prompt:cell" @compiler_2fprompt_3acell_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/prompt:cell"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  %t5 = call ptr @__olang_scope_hold(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l9, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3acell_2e2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v2)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l9, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l9
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2ector(ptr %t12, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l11
  br label %bb3
bb3:
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3acell_2e2
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l9
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = call ptr @__olang_region_or(ptr %t20, ptr null)
  %t22 = call ptr @__olang_region_home(ptr %t21)
  %t23 = icmp ne ptr %t22, null
  %t24 = select i1 %t23, ptr %t22, ptr null
  call void @__olang_region_settle_in(ptr %t17, ptr %t24)
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l4
  %t26 = call ptr @__olang_scope_hold(ptr %v2)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l13, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3acell_2e3
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = call ptr @__olang_region_make(ptr %v2)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l13
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %t33, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb8
bb8:
  %t35 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3acell_2e3
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l13
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = call ptr @__olang_region_or(ptr %t41, ptr null)
  %t43 = call ptr @__olang_region_home(ptr %t42)
  %t44 = icmp ne ptr %t43, null
  %t45 = select i1 %t44, ptr %t43, ptr null
  call void @__olang_region_settle_in(ptr %t38, ptr %t45)
  br label %bb10
bb10:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = insertvalue %"compiler/prompt:cell" undef, { i64, ptr } %t47, 0
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = insertvalue %"compiler/prompt:cell" %t48, { i64, ptr } %t49, 1
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t52 = insertvalue %"compiler/prompt:cell" %t50, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, 2
  %t54 = insertvalue %"compiler/prompt:cell" %t52, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, 3
  %t56 = insertvalue %"compiler/prompt:cell" %t54, i1 false, 4
  store %"compiler/prompt:cell" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/prompt:cell", ptr %rv
  ret %"compiler/prompt:cell" %rr
}

define dso_local %"compiler/prompt:item" @compiler_2fprompt_3aitem_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/prompt:item"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 %a2, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t7 = call ptr @__olang_scope_hold(ptr %v0)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aitem_2e5
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = call ptr @__olang_region_make(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l13, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l13
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t14, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l15
  br label %bb3
bb3:
  %t16 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aitem_2e5
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l13
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = call ptr @__olang_region_or(ptr %t22, ptr null)
  %t24 = call ptr @__olang_region_home(ptr %t23)
  %t25 = icmp ne ptr %t24, null
  %t26 = select i1 %t25, ptr %t24, ptr null
  call void @__olang_region_settle_in(ptr %t19, ptr %t26)
  br label %bb5
bb5:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = insertvalue %"compiler/prompt:item" undef, i64 %t28, 0
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = insertvalue %"compiler/prompt:item" %t29, i64 %t30, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = insertvalue %"compiler/prompt:item" %t31, i64 %t32, 2
  %t34 = load i1, ptr %l6, !tbaa !21
  %t35 = insertvalue %"compiler/prompt:item" %t33, i1 %t34, 3
  %t36 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t37 = insertvalue %"compiler/prompt:item" %t35, { i64, ptr } %t36, 4
  %t39 = insertvalue %"compiler/prompt:item" %t37, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, 5
  %t41 = insertvalue %"compiler/prompt:item" %t39, i1 false, 6
  store %"compiler/prompt:item" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/prompt:item", ptr %rv
  ret %"compiler/prompt:item" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"end" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/s" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G." }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aPtr_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aPtr_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fload_3aLoader_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".cell" }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aitem_2e4 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @__olang_errpay_pop()
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aReply_2e8 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3acell_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3acell_2e3 = weak hidden constant i1 false
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aitem_2e5 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ff9ee7abf6d47f0b_7ec27dc509c45f6f = external constant [0 x i8]
declare void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eendCompiled(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare %"compiler/prompt:program" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4)
declare ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2echeck(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2emachine(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEndProgram(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2fbuild_2ePid()
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %a0)
declare %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/prompt:Value" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aPtr_3e_2ePu_H449382aeee6306bad5d4fc1429daba25(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eMarkSet(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2finterp_2ecompiler_2finterp_3aExec_2eDropTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eRestore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %v0, i32 %a0, i8 %a1, i32 %a2, i32 %a3)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ab4beca8d06f686d_acb65cb479bd95a9 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fprompt_2edeclKey(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fprompt_2eshows(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2ePush_3ccompiler_2fprompt_3aitem_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/prompt:item" %a1)
declare i32 @std_2fio_2ePut_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePutErr_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0)
@olang_loc_62bbc83345dbe914_b70096db8abf8848 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aPtr_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
