; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/lsp:Server" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/lsp:Worker", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1 }
%"compiler/lsp:Worker" = type { i32, i32, ptr, i64 }
%"compiler/session:Reader" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/lsp:Doc" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/lsp:worker" = type { ptr, ptr, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/session:Positions" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/session:Found" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/session:Analysis" = type { ptr, { i64, ptr }, ptr, ptr, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/session:Items" = type { %"std/prelude/text:StringBuilder", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"compiler/session:Use" = type { i64, i64, { i64, ptr } }
%"compiler/diag:Item" = type { i1, { i64, ptr }, i64, i64, i64, i64, { i64, ptr }, i1 }
define dso_local { i64, ptr } @compiler_2flsp_2ePathOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca i32
  %l59 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t9, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l13, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l14, !tbaa !24
  %t22 = icmp sge i64 7, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = icmp sle i64 7, %t24
  br i1 %t25, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6756d46c47226ab9_ec8477bb3ab165)
  unreachable
bb7:
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = icmp sle i64 %t27, %t28
  br i1 %t29, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6756d46c47226ab9_ec8477bb3ab165)
  unreachable
bb9:
  %t31 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = getelementptr i8, ptr %t32, i64 7
  %t35 = sub i64 %t33, 7
  %t36 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  store { i64, ptr } %t37, ptr %l1, !tbaa !27
  %t39 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t39, ptr %l19
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6756d46c47226ab9_ec8477bb3ab165)
  unreachable
bb11:
  %t40 = load %"std/prelude/text:StringBuilder", ptr %l19
  store %"std/prelude/text:StringBuilder" %t40, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  br label %bb12
bb12:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t47 = icmp slt i64 %t41, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb13, label %bb14
bb13:
  br label %bb40
bb14:
  br label %bb15
bb15:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp eq i8 %t57, 37
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 2
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t69 = icmp slt i64 %t63, %t66
  store i1 %t69, ptr %l29, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t71 = load i1, ptr %l29, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l36, !tbaa !27
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l38, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = add i64 %t76, 3
  store i64 %t78, ptr %l40, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l41, !tbaa !24
  %t81 = load i64, ptr %l38, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb21, label %bb22
bb20:
  br label %bb37
bb21:
  %t84 = load i64, ptr %l38, !tbaa !24
  %t85 = load i64, ptr %l40, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_78ef8a2f2ef3c68c_b23277b974982b08)
  unreachable
bb23:
  %t88 = load i64, ptr %l40, !tbaa !24
  %t89 = load i64, ptr %l41, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_78ef8a2f2ef3c68c_b23277b974982b08)
  unreachable
bb25:
  %t92 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l38, !tbaa !24
  %t95 = load i64, ptr %l40, !tbaa !24
  %t96 = getelementptr i8, ptr %t93, i64 %t94
  %t97 = sub i64 %t95, %t94
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  store { i64, ptr } %t99, ptr %l45, !tbaa !27
  %t100 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 16)
  %t101 = extractvalue { i32, i64 } %t100, 1
  %t102 = extractvalue { i32, i64 } %t100, 0
  store i32 %t102, ptr %l47
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb28, label %ok.104, !prof !99
ok.104:
  store i64 %t101, ptr %l46
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_78ef8a2f2ef3c68c_b23277b974982b08)
  unreachable
bb27:
  %t105 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t106 = load i64, ptr %l46, !tbaa !24
  %t107 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t105, i64 %t106)
  %t108 = extractvalue { i32, i64 } %t107, 1
  %t109 = extractvalue { i32, i64 } %t107, 0
  store i32 %t109, ptr %l49
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb31, label %ok.111, !prof !99
ok.111:
  store i64 %t108, ptr %l48
  br label %bb30
bb28:
  br label %bb29
bb29:
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb32
bb30:
  %t112 = load i64, ptr %l48, !tbaa !24
  store i64 %t112, ptr %l35, !tbaa !24
  br label %bb32
bb31:
  br label %bb29
bb32:
  %t113 = load i64, ptr %l35, !tbaa !24
  store i64 %t113, ptr %l4, !tbaa !24
  %t114 = load i64, ptr %l4, !tbaa !24
  %t116 = icmp sge i64 %t114, 0
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = trunc i64 %t118 to i8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 %t120)
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i64, ptr %l3, !tbaa !24
  %t126 = add i64 %t123, 3
  store i64 %t126, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb37:
  %t128 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t128, ptr %l59, !tbaa !27
  %t129 = load i64, ptr %l3, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i8, ptr %t132, i64 %t129
  %t134 = load i8, ptr %t133, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 %t134)
  br label %bb38
bb38:
  %t137 = load i64, ptr %l3, !tbaa !24
  %t140 = add i64 %t137, 1
  store i64 %t140, ptr %l3, !tbaa !24
  br label %bb39
bb39:
  br label %bb12
bb40:
  %t143 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t143, ptr %l66
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t144 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca [2 x i32]
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l10 = alloca %"compiler/lsp:Server"
  %l12 = alloca %"compiler/session:Reader"
  %l29 = alloca i64
  %l38 = alloca i64
  %l44 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i1
  %l52 = alloca i64
  %l54 = alloca i1
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca { i64, ptr }
  %l67 = alloca i1
  %l72 = alloca i1
  %l77 = alloca i32
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i32
  %l87 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i64
  %l102 = alloca i1
  %l106 = alloca i1
  %l107 = alloca i64
  %l113 = alloca i1
  %l116 = alloca i64
  %l118 = alloca i1
  %l121 = alloca i64
  %l127 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/lsp:Server", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fsession_2eIgnoreBrokenPipes()
  br label %bb1
bb1:
  call void @compiler_2flsp_3aServer_2ector(ptr %t2, ptr %v0, ptr %s0, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t2, i64 152, i1 false)
  br label %bb2
bb2:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 152, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t4, ptr %l10, i64 152, i1 false)
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %s0, i32 0)
  store %"compiler/session:Reader" %t6, ptr %l12
  br label %bb3
bb3:
  %t7 = load %"compiler/session:Reader", ptr %l12
  %t8 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 48, i64 8)
  store %"compiler/session:Reader" %t7, ptr %t8
  store ptr %t8, ptr %l2, !tbaa !29
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/lsp:Server", ptr %t10, i32 0, i32 8
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb97
bb6:
  br label %bb7
bb7:
  %t19 = insertvalue [2 x i32] undef, i32 -1, 0
  %t20 = insertvalue [2 x i32] %t19, i32 -1, 1
  store [2 x i32] %t20, ptr %l3
  %t22 = getelementptr [2 x i32], ptr %l3, i64 0, i64 0
  store i32 0, ptr %t22, !tbaa !33
  store i64 1, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/lsp:Server", ptr %t23, i32 0, i32 3
  %t26 = getelementptr %"compiler/lsp:Worker", ptr %t25, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp sgt i32 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/lsp:Server", ptr %t31, i32 0, i32 3
  %t34 = getelementptr %"compiler/lsp:Worker", ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_28490b3d64df97fe_1fa673a94cf24522)
  unreachable
bb11:
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/lsp:Server", ptr %t39, i32 0, i32 3
  %t42 = getelementptr %"compiler/lsp:Worker", ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t46 = getelementptr %"compiler/session:Reader", ptr %t43, i32 0, i32 0
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = getelementptr [2 x i32], ptr %l3, i64 0, i64 1
  store i32 %t47, ptr %t49, !tbaa !33
  store i64 2, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  store i32 -1, ptr %l5, !tbaa !23
  %t50 = call i64 @std_2ftime_2eNow()
  store i64 %t50, ptr %l29
  br label %bb14
bb14:
  %t51 = load i64, ptr %l29, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/lsp:Server", ptr %t52, i32 0, i32 6
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/lsp:Server", ptr %t59, i32 0, i32 6
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t68 = sdiv i64 %t66, 1000000
  %t70 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 0, i64 %t68)
  store i64 %t70, ptr %l38
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t71 = load i64, ptr %l38, !tbaa !24
  %t72 = add i64 %t71, 1
  %t74 = trunc i64 %t72 to i32
  store i32 %t74, ptr %l5, !tbaa !23
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/lsp:Server", ptr %t76, i32 0, i32 3
  %t79 = getelementptr %"compiler/lsp:Worker", ptr %t78, i32 0, i32 0
  %t80 = load i32, ptr %t79, !tbaa !23
  %t82 = icmp sgt i32 %t80, 0
  br i1 %t82, label %bb19, label %bb20
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/lsp:Server", ptr %t84, i32 0, i32 5
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t86)
  store i64 %t88, ptr %l47
  br label %bb21
bb20:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb26
bb21:
  %t89 = load i64, ptr %l47, !tbaa !24
  %t90 = icmp sgt i64 %t89, 0
  br i1 %t90, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb25
bb23:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/lsp:Server", ptr %t92, i32 0, i32 4
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t94)
  store i64 %t96, ptr %l52
  br label %bb24
bb24:
  %t97 = load i64, ptr %l52, !tbaa !24
  %t98 = icmp sgt i64 %t97, 0
  store i1 %t98, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t100 = load i1, ptr %l49, !tbaa !21
  store i1 %t100, ptr %l44, !tbaa !21
  br label %bb26
bb26:
  %t101 = load i1, ptr %l44, !tbaa !21
  br i1 %t101, label %bb27, label %bb28
bb27:
  %t102 = load i32, ptr %l5, !tbaa !23
  %t104 = icmp slt i32 %t102, 0
  store i1 %t104, ptr %l54, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l54, !tbaa !21
  br i1 %t106, label %bb30, label %bb31
bb30:
  store i32 1000, ptr %l5, !tbaa !23
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t107 = load i64, ptr %l4, !tbaa !24
  store i64 %t107, ptr %l57, !tbaa !24
  %t108 = load [2 x i32], ptr %l3
  store i64 2, ptr %l58, !tbaa !24
  %t109 = icmp sge i64 0, 0
  br i1 %t109, label %bb33, label %bb34
bb33:
  %t111 = load i64, ptr %l57, !tbaa !24
  %t112 = icmp sle i64 0, %t111
  br i1 %t112, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d1a2ced90ae1fed3_af42112fabe41f37)
  unreachable
bb35:
  %t114 = load i64, ptr %l57, !tbaa !24
  %t115 = load i64, ptr %l58, !tbaa !24
  %t116 = icmp sle i64 %t114, %t115
  br i1 %t116, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d1a2ced90ae1fed3_af42112fabe41f37)
  unreachable
bb37:
  %t118 = load i64, ptr %l57, !tbaa !24
  %t119 = getelementptr i32, ptr %l3, i64 0
  %t120 = sub i64 %t118, 0
  %t121 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t123 = load i32, ptr %l5, !tbaa !23
  %t126 = call { i64, ptr } @compiler_2fsession_2eReadable(ptr %s1, ptr %s1, { i64, ptr } %t122, i32 %t123)
  store { i64, ptr } %t126, ptr %l64
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d1a2ced90ae1fed3_af42112fabe41f37)
  unreachable
bb39:
  %t127 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t127, ptr %l7, !tbaa !27
  %t128 = load i64, ptr %l4, !tbaa !24
  %t130 = icmp eq i64 %t128, 2
  br i1 %t130, label %bb40, label %bb41
bb40:
  %t132 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i1, ptr %t133, i64 1
  %t135 = load i1, ptr %t134, !tbaa !31
  store i1 %t135, ptr %l67, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb42
bb42:
  %t137 = load i1, ptr %l67, !tbaa !21
  br i1 %t137, label %bb43, label %bb44
bb43:
  %t138 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2efromWorker(ptr %s0, ptr %t138)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t140 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i1, ptr %t141, i64 0
  %t143 = load i1, ptr %t142, !tbaa !31
  br i1 %t143, label %bb47, label %bb48
bb47:
  %t145 = load ptr, ptr %l2, !tbaa !29
  %t147 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %s0, ptr %t145)
  store i1 %t147, ptr %l72
  br label %bb49
bb48:
  br label %bb68
bb49:
  %t148 = load i1, ptr %l72, !tbaa !21
  %t149 = xor i1 %t148, true
  br i1 %t149, label %bb50, label %bb51
bb50:
  %t151 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2edrain(ptr %s0, ptr %v0, ptr %t151)
  br label %bb52
bb51:
  br label %bb56
bb52:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/lsp:Server", ptr %t153, i32 0, i32 7
  %t156 = load i1, ptr %t155, !tbaa !21
  br i1 %t156, label %bb53, label %bb54
bb53:
  store i32 0, ptr %l77, !tbaa !23
  br label %bb55
bb54:
  store i32 1, ptr %l77, !tbaa !23
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load i32, ptr %l77, !tbaa !23
  store i32 %t158, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/lsp:Server", ptr %t159, i32 0, i32 8
  %t162 = load i1, ptr %t161, !tbaa !21
  %t164 = xor i1 %t162, true
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb58, label %bb59
bb58:
  br label %bb67
bb59:
  br label %bb60
bb60:
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t170 = call { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %s0, ptr %s0, ptr %t168)
  %t171 = extractvalue { i32, { i64, ptr } } %t170, 1
  %t172 = extractvalue { i32, { i64, ptr } } %t170, 0
  store i32 %t172, ptr %l85
  %t173 = icmp ne i32 %t172, 0
  br i1 %t173, label %bb62, label %ok.174, !prof !99
ok.174:
  store { i64, ptr } %t171, ptr %l84
  br label %bb61
bb61:
  %t175 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t175, ptr %l82, !tbaa !27
  br label %bb64
bb62:
  %t176 = load i32, ptr %l85, !tbaa !23
  %t177 = ashr i32 %t176, 16
  %t179 = icmp eq i32 %t177, 1
  store i1 %t179, ptr %l87, !tbaa !21
  br label %bb63
bb63:
  br label %bb67
bb64:
  %t180 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t181 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ehandle(ptr %s0, ptr %s0, ptr %v0, ptr %t181, { i64, ptr } %t180)
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb57
bb67:
  br label %bb68
bb68:
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr %"compiler/lsp:Server", ptr %t185, i32 0, i32 6
  %t188 = load i64, ptr %t187, !tbaa !24
  %t190 = icmp sgt i64 %t188, 0
  br i1 %t190, label %bb69, label %bb70
bb69:
  %t192 = call i64 @std_2ftime_2eNow()
  store i64 %t192, ptr %l94
  br label %bb71
bb70:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb72
bb71:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/lsp:Server", ptr %t193, i32 0, i32 6
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = load i64, ptr %l94, !tbaa !24
  %t199 = icmp sge i64 %t197, %t196
  store i1 %t199, ptr %l93, !tbaa !21
  br label %bb72
bb72:
  %t201 = load i1, ptr %l93, !tbaa !21
  br i1 %t201, label %bb73, label %bb74
bb73:
  %t202 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estartWorker(ptr %s0, ptr %v0, ptr %t202)
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr %"compiler/lsp:Server", ptr %t204, i32 0, i32 3
  %t207 = getelementptr %"compiler/lsp:Worker", ptr %t206, i32 0, i32 0
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = icmp sgt i32 %t208, 0
  br i1 %t210, label %bb77, label %bb78
bb77:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/lsp:Server", ptr %t212, i32 0, i32 3
  %t215 = getelementptr %"compiler/lsp:Worker", ptr %t214, i32 0, i32 3
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = icmp sgt i64 %t216, 0
  store i1 %t218, ptr %l102, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb79
bb79:
  %t220 = load i1, ptr %l102, !tbaa !21
  br i1 %t220, label %bb80, label %bb81
bb80:
  %t221 = call i64 @std_2ftime_2eNow()
  store i64 %t221, ptr %l107
  br label %bb82
bb81:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb83
bb82:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr %"compiler/lsp:Server", ptr %t222, i32 0, i32 3
  %t225 = getelementptr %"compiler/lsp:Worker", ptr %t224, i32 0, i32 3
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = load i64, ptr %l107, !tbaa !24
  %t229 = sub i64 %t227, %t226
  %t230 = load i64, ptr @G_2ecompiler_2flsp_2eStuckNs, !tbaa !24
  %t233 = icmp sgt i64 %t229, %t230
  store i1 %t233, ptr %l106, !tbaa !21
  br label %bb83
bb83:
  %t235 = load i1, ptr %l106, !tbaa !21
  br i1 %t235, label %bb84, label %bb85
bb84:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr %"compiler/lsp:Server", ptr %t236, i32 0, i32 5
  %t240 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t238)
  store i64 %t240, ptr %l116
  br label %bb86
bb85:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb91
bb86:
  %t241 = load i64, ptr %l116, !tbaa !24
  %t242 = icmp sgt i64 %t241, 0
  br i1 %t242, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb90
bb88:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr %"compiler/lsp:Server", ptr %t244, i32 0, i32 4
  %t248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t246)
  store i64 %t248, ptr %l121
  br label %bb89
bb89:
  %t249 = load i64, ptr %l121, !tbaa !24
  %t250 = icmp sgt i64 %t249, 0
  store i1 %t250, ptr %l118, !tbaa !21
  br label %bb90
bb90:
  %t252 = load i1, ptr %l118, !tbaa !21
  store i1 %t252, ptr %l113, !tbaa !21
  br label %bb91
bb91:
  %t253 = load i1, ptr %l113, !tbaa !21
  br i1 %t253, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s11
  %t254 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eworkerLost(ptr %s0, ptr %s11, ptr %t254, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb94
bb93:
  br label %bb95
bb94:
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s1)
  br label %bb96
bb96:
  br label %bb4
bb97:
  %t256 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estopWorker(ptr %s0, ptr %t256)
  br label %bb98
bb98:
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr %"compiler/lsp:Server", ptr %t258, i32 0, i32 7
  %t261 = load i1, ptr %t260, !tbaa !21
  br i1 %t261, label %bb99, label %bb100
bb99:
  store i32 0, ptr %l127, !tbaa !23
  br label %bb101
bb100:
  store i32 1, ptr %l127, !tbaa !23
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s0)
  %t263 = load i32, ptr %l127, !tbaa !23
  store i32 %t263, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2ebuildSaid(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca [3 x { i64, ptr }]
  %l3 = alloca %"std/os:Output"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca %"std/os:Output"
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/os:Output"
  %l24 = alloca i32
  %l26 = alloca i1
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/text:LineIter"
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l52 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i32
  %l75 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fos_2eQuote(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = call { i64, ptr } @compiler_2flsp_2ecompilerUnderTest(ptr %s0)
  store { i64, ptr } %t4, ptr %l13
  br label %bb2
bb2:
  %t5 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t7 = call { i64, ptr } @std_2fos_2eQuote(ptr %s0, ptr %s0, { i64, ptr } %t5)
  store { i64, ptr } %t7, ptr %l15
  br label %bb3
bb3:
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t10 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t8, i64 %t9)
  %t25 = getelementptr i8, ptr %t24, i64 %t9
  call void @olang_textcopy(ptr %t25, ptr %t11, i64 %t12)
  %t26 = getelementptr i8, ptr %t25, i64 %t12
  call void @olang_textcopy(ptr %t26, ptr %t14, i64 %t15)
  %t27 = getelementptr i8, ptr %t26, i64 %t15
  call void @olang_textcopy(ptr %t27, ptr %t18, i64 %t19)
  %t28 = getelementptr i8, ptr %t27, i64 %t19
  call void @olang_textcopy(ptr %t28, ptr %t21, i64 %t22)
  %t29 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t24, 1
  %t33 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t34 = insertvalue [3 x { i64, ptr }] %t33, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t36 = insertvalue [3 x { i64, ptr }] %t34, { i64, ptr } %t30, 2
  store [3 x { i64, ptr }] %t36, ptr %l2
  %t39 = insertvalue { i64, ptr } undef, i64 3, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %l2, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t43 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t40, { i64, ptr } %t42, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  %t44 = extractvalue { i32, %"std/os:Output" } %t43, 1
  %t45 = extractvalue { i32, %"std/os:Output" } %t43, 0
  store i32 %t45, ptr %l24
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb5, label %ok.47, !prof !99
ok.47:
  store %"std/os:Output" %t44, ptr %l23
  br label %bb4
bb4:
  %t48 = load %"std/os:Output", ptr %l23
  store %"std/os:Output" %t48, ptr %l17
  br label %bb9
bb5:
  %t49 = load i32, ptr %l24, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  store i1 %t52, ptr %l26, !tbaa !21
  %t53 = load i32, ptr %l24, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  br i1 %t56, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t58 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t60 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t58, 1
  call void @__olang_check_failed_text(ptr @olang_loc_15a00d37002b4239_21fefac552c9525d, { i64, ptr } %t61)
  unreachable
bb9:
  %t62 = load %"std/os:Output", ptr %l17
  store %"std/os:Output" %t62, ptr %l3
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l29
  br label %bb10
bb10:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l4
  %t65 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t66)
  store %"std/prelude/text:LineIter" %t68, ptr %l31
  br label %bb11
bb11:
  %t69 = load %"std/prelude/text:LineIter", ptr %l31
  store %"std/prelude/text:LineIter" %t69, ptr %l5
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l5)
  %t72 = extractvalue { i32, { i64, ptr } } %t71, 1
  %t73 = extractvalue { i32, { i64, ptr } } %t71, 0
  store i32 %t73, ptr %l35
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb14, label %ok.75, !prof !99
ok.75:
  store { i64, ptr } %t72, ptr %l34
  br label %bb13
bb13:
  %t76 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t76, ptr %l32, !tbaa !27
  br label %bb16
bb14:
  %t77 = load i32, ptr %l35, !tbaa !23
  %t78 = ashr i32 %t77, 16
  %t80 = icmp eq i32 %t78, 1
  store i1 %t80, ptr %l37, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb16:
  %t81 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t84 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s4, { i64, ptr } %t82, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) })
  %t85 = extractvalue { i32, i64 } %t84, 1
  %t86 = extractvalue { i32, i64 } %t84, 0
  store i32 %t86, ptr %l41
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb18, label %ok.88, !prof !99
ok.88:
  store i64 %t85, ptr %l40
  br label %bb17
bb17:
  %t89 = load i64, ptr %l40, !tbaa !24
  store i64 %t89, ptr %l38, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb20:
  %t90 = load i64, ptr %l38, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t91, ptr %l42, !tbaa !27
  %t92 = load i64, ptr %l7, !tbaa !24
  store i64 %t92, ptr %l43, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l44, !tbaa !24
  %t95 = icmp sge i64 0, 0
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 0, %t97
  br i1 %t98, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_df0aeb6250e7481_26f5ec38bd691c8d)
  unreachable
bb23:
  %t100 = load i64, ptr %l43, !tbaa !24
  %t101 = load i64, ptr %l44, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_df0aeb6250e7481_26f5ec38bd691c8d)
  unreachable
bb25:
  %t104 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l43, !tbaa !24
  %t107 = getelementptr i8, ptr %t105, i64 0
  %t108 = sub i64 %t106, 0
  %t109 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  %t112 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s4, ptr %s4, { i64, ptr } %t110, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store { i64, ptr } %t112, ptr %l49
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_df0aeb6250e7481_26f5ec38bd691c8d)
  unreachable
bb27:
  %t113 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t114 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s4, ptr %s4, { i64, ptr } %t113)
  store ptr %t114, ptr %l50
  br label %bb28
bb28:
  %t115 = load ptr, ptr %l50, !tbaa !29
  store ptr %t115, ptr %l8, !tbaa !29
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s4, ptr %t116)
  store i64 %t118, ptr %l52
  br label %bb29
bb29:
  %t119 = load i64, ptr %l52, !tbaa !24
  %t120 = icmp slt i64 %t119, 3
  br i1 %t120, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb31:
  br label %bb32
bb32:
  %t122 = load ptr, ptr %l8, !tbaa !29
  %t124 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s4, ptr %s4, ptr %t122, i64 0)
  store { i64, ptr } %t124, ptr %l55
  br label %bb33
bb33:
  %t125 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t126 = call { i64, ptr } @compiler_2flsp_2ebaseName(ptr %s4, ptr %s4, { i64, ptr } %t125)
  store { i64, ptr } %t126, ptr %l56
  br label %bb34
bb34:
  %t127 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t127, ptr %l9, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t128, ptr %l57, !tbaa !27
  %t129 = load i64, ptr %l7, !tbaa !24
  %t131 = add i64 %t129, 8
  store i64 %t131, ptr %l59, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t132, 0
  store i64 %t135, ptr %l62, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l63, !tbaa !24
  %t138 = load i64, ptr %l59, !tbaa !24
  %t139 = icmp sge i64 %t138, 0
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t141 = load i64, ptr %l59, !tbaa !24
  %t142 = load i64, ptr %l62, !tbaa !24
  %t143 = icmp sle i64 %t141, %t142
  br i1 %t143, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_5f1d4675af139e82_e6710b64a8f7682e)
  unreachable
bb37:
  %t145 = load i64, ptr %l62, !tbaa !24
  %t146 = load i64, ptr %l63, !tbaa !24
  %t147 = icmp sle i64 %t145, %t146
  br i1 %t147, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5f1d4675af139e82_e6710b64a8f7682e)
  unreachable
bb39:
  %t149 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = load i64, ptr %l59, !tbaa !24
  %t152 = load i64, ptr %l62, !tbaa !24
  %t153 = getelementptr i8, ptr %t150, i64 %t151
  %t154 = sub i64 %t152, %t151
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  store { i64, ptr } %t156, ptr %l10, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t158, ptr %l68, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t161 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s4, { i64, ptr } %t159, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) })
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l72
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb42, label %ok.165, !prof !99
ok.165:
  store i64 %t162, ptr %l71
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_5f1d4675af139e82_e6710b64a8f7682e)
  unreachable
bb41:
  %t166 = load i64, ptr %l71, !tbaa !24
  store i64 %t166, ptr %l69, !tbaa !24
  br label %bb44
bb42:
  br label %bb43
bb43:
  %t167 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l69, !tbaa !24
  br label %bb44
bb44:
  %t171 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  store i64 %t172, ptr %l75, !tbaa !24
  %t173 = icmp sge i64 0, 0
  br i1 %t173, label %bb45, label %bb46
bb45:
  %t175 = load i64, ptr %l69, !tbaa !24
  %t176 = icmp sle i64 0, %t175
  br i1 %t176, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_ab8c4ea36668ab7f_3bb630bf34512b)
  unreachable
bb47:
  %t178 = load i64, ptr %l69, !tbaa !24
  %t179 = load i64, ptr %l75, !tbaa !24
  %t180 = icmp sle i64 %t178, %t179
  br i1 %t180, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_ab8c4ea36668ab7f_3bb630bf34512b)
  unreachable
bb49:
  %t182 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = load i64, ptr %l69, !tbaa !24
  %t185 = getelementptr i8, ptr %t183, i64 0
  %t186 = sub i64 %t184, 0
  %t187 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t185, 1
  store { i64, ptr } %t188, ptr %l10, !tbaa !27
  store ptr %l4, ptr %l80, !tbaa !29
  %t190 = call ptr @__olang_scope_hold(ptr %s0)
  %t191 = ptrtoint ptr %t190 to i64
  store i64 %t191, ptr %l81, !tbaa !24
  %t192 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t192, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_ab8c4ea36668ab7f_3bb630bf34512b)
  unreachable
bb51:
  %t194 = call ptr @__olang_region_make(ptr %s0)
  %t195 = ptrtoint ptr %t194 to i64
  store i64 %t195, ptr %l81, !tbaa !24
  br label %bb52
bb52:
  %t196 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t196, ptr %l83, !tbaa !27
  %t197 = load ptr, ptr %l8, !tbaa !29
  %t199 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s4, ptr %s4, ptr %t197, i64 1)
  store { i64, ptr } %t199, ptr %l85
  br label %bb53
bb53:
  %t200 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t206 = add i64 %t203, %t205
  %t207 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t215 = extractvalue { i64, ptr } %t200, 1
  %t216 = extractvalue { i64, ptr } %t200, 0
  %t217 = add i64 %t213, %t216
  %t218 = load i64, ptr %l81
  %t219 = inttoptr i64 %t218 to ptr
  %t220 = call ptr @__olang_held_alloc(ptr %t219, i64 %t217)
  call void @olang_textcopy(ptr %t220, ptr %t202, i64 %t203)
  %t221 = getelementptr i8, ptr %t220, i64 %t203
  call void @olang_textcopy(ptr %t221, ptr %t204, i64 %t205)
  %t222 = getelementptr i8, ptr %t221, i64 %t205
  call void @olang_textcopy(ptr %t222, ptr %t208, i64 %t209)
  %t223 = getelementptr i8, ptr %t222, i64 %t209
  call void @olang_textcopy(ptr %t223, ptr %t211, i64 %t212)
  %t224 = getelementptr i8, ptr %t223, i64 %t212
  call void @olang_textcopy(ptr %t224, ptr %t215, i64 %t216)
  %t225 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t220, 1
  %t228 = load ptr, ptr %l80, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t228, { i64, ptr } %t226)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb55:
  br label %bb12
bb56:
  %t230 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_14, 0
  %t231 = insertvalue { ptr, ptr } %t230, ptr null, 1
  %t234 = extractvalue { ptr, ptr } %t231, 0
  %t235 = extractvalue { ptr, ptr } %t231, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l4, ptr %t234, ptr %t235)
  br label %bb57
bb57:
  %t237 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %v1, ptr %l4, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store { i64, ptr } %t237, ptr %l92
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t238 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t238, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2ecodeActions(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { { i64, ptr }, i64 }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca i32
  %l30 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l36 = alloca i1
  %l42 = alloca %"std/prelude/text:StringBuilder"
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l58 = alloca { { i64, ptr }, i64 }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { { i64, ptr }, i64 }
  %l63 = alloca i32
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t6 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v0, ptr %a0, { i64, ptr } %t3)
  %t7 = extractvalue { i32, ptr } %t6, 1
  %t8 = extractvalue { i32, ptr } %t6, 0
  store i32 %t8, ptr %l19
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store ptr %t7, ptr %l18
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l18, !tbaa !29
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t15 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } %t12)
  %t16 = extractvalue { i32, ptr } %t15, 1
  %t17 = extractvalue { i32, ptr } %t15, 0
  store i32 %t17, ptr %l28
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb7, label %ok.19, !prof !99
ok.19:
  store ptr %t16, ptr %l27
  br label %bb6
bb2:
  %t20 = load i32, ptr %l19, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l21, !tbaa !21
  %t24 = load i32, ptr %l19, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t29 = icmp sge i64 0, 0
  br i1 %t29, label %bb14, label %bb15
bb6:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t32 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s0, ptr %s0, ptr %t31)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l34
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb11, label %ok.36, !prof !99
ok.36:
  store { i64, ptr } %t33, ptr %l33
  br label %bb10
bb7:
  %t37 = load i32, ptr %l28, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  store i1 %t40, ptr %l30, !tbaa !21
  %t41 = load i32, ptr %l28, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  br i1 %t44, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb5
bb10:
  %t46 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t46, ptr %l13, !tbaa !27
  br label %bb18
bb11:
  %t47 = load i32, ptr %l34, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  store i1 %t50, ptr %l36, !tbaa !21
  %t51 = load i32, ptr %l34, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb5
bb14:
  %t56 = icmp sle i64 0, 1152921504606846975
  br i1 %t56, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_ae05a22d05063faf_d2685d04a4fb9cc3)
  unreachable
bb16:
  %t58 = mul i64 0, 8
  %t59 = insertvalue { i64, ptr } undef, i64 0, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t60, ptr %l13, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_ae05a22d05063faf_d2685d04a4fb9cc3)
  unreachable
bb18:
  %t62 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t62, ptr %l4, !tbaa !27
  %t63 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t63, ptr %l42
  br label %bb19
bb19:
  %t64 = load %"std/prelude/text:StringBuilder", ptr %l42
  store %"std/prelude/text:StringBuilder" %t64, ptr %l5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 91)
  br label %bb20
bb20:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb23:
  br label %bb24
bb24:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t80, ptr %l51, !tbaa !27
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr ptr, ptr %t84, i64 %t81
  %t86 = load ptr, ptr %t85, !tbaa !39
  store ptr %t86, ptr %l9, !tbaa !29
  %t88 = load ptr, ptr %l9, !tbaa !29
  %t90 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s2, ptr %s0, ptr %t88, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store { i64, ptr } %t90, ptr %l55
  br label %bb25
bb25:
  %t91 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t91, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t92, ptr %l56
  br label %bb26
bb26:
  %t93 = load i1, ptr %l56, !tbaa !21
  %t94 = xor i1 %t93, true
  br i1 %t94, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb28:
  br label %bb29
bb29:
  store { i64, ptr } %a2, ptr %l59, !tbaa !27
  %t97 = load ptr, ptr %l9, !tbaa !29
  %t99 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s2, ptr %s0, ptr %t97, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store { i64, ptr } %t99, ptr %l61
  br label %bb30
bb30:
  %t100 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t102 = call { i32, { { i64, ptr }, i64 } } @compiler_2fsession_2eImportFix(ptr %v2, ptr %s0, ptr %s2, { i64, ptr } %t100, { i64, ptr } %t101)
  %t103 = extractvalue { i32, { { i64, ptr }, i64 } } %t102, 1
  %t104 = extractvalue { i32, { { i64, ptr }, i64 } } %t102, 0
  store i32 %t104, ptr %l63
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb32, label %ok.106, !prof !99
ok.106:
  store { { i64, ptr }, i64 } %t103, ptr %l62
  br label %bb31
bb31:
  %t107 = load { { i64, ptr }, i64 }, ptr %l62
  store { { i64, ptr }, i64 } %t107, ptr %l58
  br label %bb34
bb32:
  %t108 = load i32, ptr %l63, !tbaa !23
  %t109 = ashr i32 %t108, 16
  %t111 = icmp eq i32 %t109, 1
  store i1 %t111, ptr %l65, !tbaa !21
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb34:
  %t112 = load { { i64, ptr }, i64 }, ptr %l58
  store { { i64, ptr }, i64 } %t112, ptr %l10
  %t113 = getelementptr { { i64, ptr }, i64 }, ptr %l10, i32 0, i32 0
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l66, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l67, !tbaa !24
  %t117 = load i64, ptr %l67, !tbaa !24
  %t118 = mul i64 %t117, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t118)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l68, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l67, !tbaa !24
  %t127 = mul i64 %t126, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %t125, i64 %t127, i1 false)
  %t128 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t128, ptr %l11, !tbaa !27
  %t129 = getelementptr { { i64, ptr }, i64 }, ptr %l10, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  store i64 %t130, ptr %l12, !tbaa !24
  %t133 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l5)
  store i64 %t133, ptr %l71
  br label %bb35
bb35:
  %t134 = load i64, ptr %l71, !tbaa !24
  %t135 = icmp sgt i64 %t134, 1
  br i1 %t135, label %bb36, label %bb37
bb36:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 44)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb40
bb40:
  store ptr %l5, ptr %l75, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t141 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s2, ptr %s2, { i64, ptr } %t139)
  store { i64, ptr } %t141, ptr %l77
  br label %bb41
bb41:
  %t142 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t144 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t142, i64 %t143)
  %t149 = getelementptr i8, ptr %t148, i64 %t143
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  %t153 = load ptr, ptr %l75, !tbaa !29
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s2, ptr %t153, { i64, ptr } %t151)
  br label %bb42
bb42:
  store ptr %l5, ptr %l80, !tbaa !29
  %t155 = load ptr, ptr %l9, !tbaa !29
  %t158 = call { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %s0, ptr %s2, ptr %s2, ptr %t155, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, i32 0)
  store { i64, ptr } %t158, ptr %l83
  br label %bb43
bb43:
  %t159 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t161 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t159, i64 %t160)
  %t169 = getelementptr i8, ptr %t168, i64 %t160
  call void @olang_textcopy(ptr %t169, ptr %t162, i64 %t163)
  %t170 = getelementptr i8, ptr %t169, i64 %t163
  call void @olang_textcopy(ptr %t170, ptr %t165, i64 %t166)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t168, 1
  %t174 = load ptr, ptr %l80, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t174, { i64, ptr } %t172)
  br label %bb44
bb44:
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v1, ptr %l5, { i64, ptr } %a1)
  br label %bb45
bb45:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb46
bb46:
  %t181 = load i64, ptr %l12, !tbaa !24
  %t182 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v3, ptr %s0, ptr %a3, ptr %l5, i64 %t181, i64 %t182)
  br label %bb47
bb47:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb48
bb48:
  %t188 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t188)
  br label %bb49
bb49:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb51:
  %t192 = load i64, ptr %l7, !tbaa !24
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %l7, !tbaa !24
  br label %bb21
bb52:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l5, i8 93)
  br label %bb53
bb53:
  %t199 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %l5)
  store { i64, ptr } %t199, ptr %l102
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t200 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eask(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/lsp:Worker", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = icmp sle i32 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estartWorker(ptr %v0, ptr %v3, ptr %t9)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lsp:Server", ptr %t11, i32 0, i32 3
  %t14 = getelementptr %"compiler/lsp:Worker", ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = icmp sle i32 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %v2, ptr %s2, ptr %s2, { i64, ptr } %t20, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store { i64, ptr } %t22, ptr %l12
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s2, ptr %t24, { i64, ptr } %t23)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lsp:Server", ptr %t26, i32 0, i32 5
  store ptr %t28, ptr %l15, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l17, !tbaa !27
  %t30 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t31 = extractvalue { i32, i64 } %t30, 1
  %t32 = extractvalue { i32, i64 } %t30, 0
  store i32 %t32, ptr %l19
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb11, label %ok.34, !prof !99
ok.34:
  store i64 %t31, ptr %l18
  br label %bb10
bb10:
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t36 = load i64, ptr %l18, !tbaa !24
  %t37 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v2, { i64, ptr } %t35, i64 %t36)
  %t38 = extractvalue { i32, i64 } %t37, 1
  %t39 = extractvalue { i32, i64 } %t37, 0
  store i32 %t39, ptr %l21
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb14, label %ok.41, !prof !99
ok.41:
  store i64 %t38, ptr %l20
  br label %bb13
bb11:
  br label %bb12
bb12:
  store i64 -1, ptr %l16, !tbaa !24
  br label %bb15
bb13:
  %t42 = load i64, ptr %l20, !tbaa !24
  store i64 %t42, ptr %l16, !tbaa !24
  br label %bb15
bb14:
  br label %bb12
bb15:
  %t43 = load ptr, ptr %l15, !tbaa !29
  %t44 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t43, i64 %t44)
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lsp:Server", ptr %t45, i32 0, i32 3
  %t48 = getelementptr %"compiler/lsp:Worker", ptr %t47, i32 0, i32 1
  %t49 = load i32, ptr %t48, !tbaa !23
  call void @compiler_2fsession_2eWriteFramed(ptr %v1, i32 %t49, { i64, ptr } %a1)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2echanged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eopened(ptr %v0, ptr %v1, ptr %v2, ptr %t11, { i64, ptr } %t12, { i64, ptr } %t13)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esetText(ptr %v0, ptr %v2, ptr %t17, i64 %t18, { i64, ptr } %t19)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eclosed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l9 = alloca i64
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lsp:Server", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l15
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l15, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/lsp:Doc", ptr %t19, i32 0, i32 4
  store i1 false, ptr %t21, !tbaa !21
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = call ptr @__olang_scope_hold(ptr %v0)
  %t24 = ptrtoint ptr %t23 to i64
  store i64 %t24, ptr %l18, !tbaa !24
  %t25 = load i1, ptr @olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = call ptr @__olang_region_or(ptr %t27, ptr %v0)
  %t29 = call ptr @__olang_scope_hold(ptr %t28)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/lsp:Doc", ptr %t31, i32 0, i32 3
  %t34 = load i64, ptr %l18
  %t35 = inttoptr i64 %t34 to ptr
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %t35, ptr %t33)
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l22, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/lsp:Doc", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t41, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store { i64, ptr } %t43, ptr %l25
  br label %bb9
bb9:
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t45 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s0, ptr %t45, { i64, ptr } %t44)
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/lsp:Doc", ptr %t47, i32 0, i32 6
  store ptr %t49, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load i64, ptr %l5, !tbaa !24
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t52)
  store i64 %t54, ptr %l31
  br label %bb12
bb12:
  %t55 = load i64, ptr %l29, !tbaa !24
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = icmp slt i64 %t55, %t56
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb14:
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store { i64, ptr } %t65, ptr %l36
  br label %bb16
bb16:
  %t66 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  %t70 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v0, ptr %s3, ptr %s3, { i64, ptr } %t66, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t70, ptr %l39
  br label %bb17
bb17:
  %t71 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t72 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s3, ptr %t72, { i64, ptr } %t71)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l5, !tbaa !24
  br label %bb11
bb20:
  %t79 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estopWorker(ptr %v0, ptr %t79)
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lsp:Server", ptr %t81, i32 0, i32 4
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  store i1 %t87, ptr %l48
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l49, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/lsp:Server", ptr %t89, i32 0, i32 4
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l52
  br label %bb23
bb23:
  %t94 = load i64, ptr %l52, !tbaa !24
  %t95 = icmp sgt i64 %t94, 0
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t97 = call i64 @std_2ftime_2eNow()
  store i64 %t97, ptr %l55
  br label %bb26
bb25:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb27
bb26:
  %t98 = load i64, ptr @G_2ecompiler_2flsp_2eSettleNs, !tbaa !24
  %t99 = load i64, ptr %l55, !tbaa !24
  %t101 = add i64 %t99, %t98
  store i64 %t101, ptr %l54, !tbaa !24
  br label %bb27
bb27:
  %t103 = load i64, ptr %l54, !tbaa !24
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t105 = getelementptr %"compiler/lsp:Server", ptr %t104, i32 0, i32 6
  store i64 %t103, ptr %t105, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2efromWorker(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l11 = alloca i1
  %l15 = alloca i32
  %l19 = alloca i64
  %l21 = alloca i1
  %l24 = alloca i64
  %l27 = alloca { i64, ptr }
  %l31 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l53 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca i1
  %l68 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i32
  %l74 = alloca i64
  %l75 = alloca i32
  %l79 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/lsp:Worker", ptr %t3, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_824396f7e8872934_1f4412bc0bc5f5e0)
  unreachable
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lsp:Server", ptr %t9, i32 0, i32 3
  %t12 = getelementptr %"compiler/lsp:Worker", ptr %t11, i32 0, i32 2
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %t13)
  store i1 %t15, ptr %l11
  br label %bb4
bb4:
  %t16 = load i1, ptr %l11, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lsp:Server", ptr %t19, i32 0, i32 3
  %t22 = getelementptr %"compiler/lsp:Worker", ptr %t21, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = call i32 @compiler_2fsession_2eReap(i32 %t23)
  store i32 %t25, ptr %l15
  br label %bb7
bb6:
  br label %bb30
bb7:
  %t26 = load i32, ptr %l15, !tbaa !23
  store i32 %t26, ptr %l1, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ecloseWorker(ptr %v0, ptr %t27)
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lsp:Server", ptr %t29, i32 0, i32 4
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = icmp sgt i64 %t34, 0
  br i1 %t35, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb13
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lsp:Server", ptr %t37, i32 0, i32 5
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l24
  br label %bb12
bb12:
  %t42 = load i64, ptr %l24, !tbaa !24
  %t43 = icmp sgt i64 %t42, 0
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lsp:Server", ptr %t46, i32 0, i32 3
  %t49 = getelementptr %"compiler/lsp:Worker", ptr %t48, i32 0, i32 0
  store i32 -1, ptr %t49, !tbaa !23
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t50, ptr %l2, !tbaa !27
  %t52 = load i32, ptr %l1, !tbaa !23
  %t54 = icmp sgt i32 %t52, 128
  br i1 %t54, label %bb16, label %bb17
bb15:
  br label %bb29
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = call ptr @__olang_scope_hold(ptr %s2)
  %t57 = ptrtoint ptr %t56 to i64
  store i64 %t57, ptr %l31, !tbaa !24
  %t58 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aServer__2efromWorker_2elocal_2e2
  br i1 %t58, label %bb18, label %bb19
bb17:
  br label %bb27
bb18:
  %t60 = call ptr @__olang_region_make(ptr %s2)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l31, !tbaa !24
  br label %bb19
bb19:
  %t62 = load i32, ptr %l1, !tbaa !23
  %t64 = sub i32 %t62, 128
  %t66 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s3, i32 %t64)
  store { i64, ptr } %t66, ptr %l35
  br label %bb20
bb20:
  %t67 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = add i64 %t68, %t71
  %t73 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t76 = load i64, ptr %l31
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = call ptr @__olang_held_alloc(ptr %t77, i64 %t75)
  call void @olang_textcopy(ptr %t78, ptr %t67, i64 %t68)
  %t79 = getelementptr i8, ptr %t78, i64 %t68
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t80, ptr %t73, i64 %t74)
  %t81 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t78, 1
  store { i64, ptr } %t82, ptr %l36, !tbaa !27
  %t83 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aServer__2efromWorker_2elocal_2e2
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t85 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t88 = icmp eq i64 %t86, 0
  br i1 %t88, label %bb23, label %bb24
bb22:
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t90, ptr %l40, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t91, ptr %l2, !tbaa !27
  %t92 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aServer__2efromWorker_2elocal_2e2
  br i1 %t92, label %bb25, label %bb26
bb23:
  store { i64, ptr } zeroinitializer, ptr %l36, !tbaa !27
  br label %bb24
bb24:
  %t94 = load i64, ptr %l31
  %t95 = inttoptr i64 %t94 to ptr
  %t96 = load { i64, ptr }, ptr %l36
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = call ptr @__olang_region_or(ptr %t97, ptr null)
  %t99 = icmp ne ptr %t98, null
  %t100 = select i1 %t99, ptr %t98, ptr null
  call void @__olang_region_settle_in(ptr %t95, ptr %t100)
  br label %bb22
bb25:
  %t101 = load { i64, ptr }, ptr %l40
  %t102 = extractvalue { i64, ptr } %t101, 1
  call void @__olang_region_release(ptr %t102)
  store { i64, ptr } zeroinitializer, ptr %l40
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eworkerLost(ptr %v0, ptr %s2, ptr %t103, { i64, ptr } %t104)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  br label %ret
bb30:
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/lsp:Server", ptr %t107, i32 0, i32 3
  %t110 = getelementptr %"compiler/lsp:Worker", ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b5606d6e3fe22ec3_be86f13ccb1ff2ff)
  unreachable
bb33:
  br label %bb34
bb34:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lsp:Server", ptr %t115, i32 0, i32 3
  %t118 = getelementptr %"compiler/lsp:Worker", ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = call { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %v0, ptr %s5, ptr %t119)
  %t122 = extractvalue { i32, { i64, ptr } } %t121, 1
  %t123 = extractvalue { i32, { i64, ptr } } %t121, 0
  store i32 %t123, ptr %l51
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb36, label %ok.125, !prof !99
ok.125:
  store { i64, ptr } %t122, ptr %l50
  br label %bb35
bb35:
  %t126 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t126, ptr %l44, !tbaa !27
  br label %bb38
bb36:
  %t127 = load i32, ptr %l51, !tbaa !23
  %t128 = ashr i32 %t127, 16
  %t130 = icmp eq i32 %t128, 1
  store i1 %t130, ptr %l53, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb64
bb38:
  %t131 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t131, ptr %l3, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s5, ptr %s5, { i64, ptr } %t132, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t134, ptr %l55
  br label %bb39
bb39:
  %t135 = load i1, ptr %l55, !tbaa !21
  br i1 %t135, label %bb40, label %bb41
bb40:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2enote(ptr %v0, ptr %s5, ptr %t136, { i64, ptr } %t137)
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb43:
  %t140 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t142 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s5, ptr %s5, { i64, ptr } %t140, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t142, ptr %l59
  br label %bb44
bb44:
  %t143 = load i1, ptr %l59, !tbaa !21
  br i1 %t143, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t144 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t146 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %s5, ptr %s8, { i64, ptr } %t144)
  %t147 = extractvalue { i32, ptr } %t146, 1
  %t148 = extractvalue { i32, ptr } %t146, 0
  store i32 %t148, ptr %l63
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb48, label %ok.150, !prof !99
ok.150:
  store ptr %t147, ptr %l62
  br label %bb47
bb46:
  br label %bb61
bb47:
  %t151 = load ptr, ptr %l62, !tbaa !29
  store ptr %t151, ptr %l60, !tbaa !29
  br label %bb52
bb48:
  %t152 = load i32, ptr %l63, !tbaa !23
  %t153 = ashr i32 %t152, 16
  %t155 = icmp eq i32 %t153, 1
  store i1 %t155, ptr %l65, !tbaa !21
  %t156 = load i32, ptr %l63, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  br i1 %t159, label %bb49, label %bb50
bb49:
  call void @__olang_errpay_pop()
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb52:
  %t161 = load ptr, ptr %l60, !tbaa !29
  %t164 = call { i64, ptr } @compiler_2flsp_2eidOf(ptr %s8, ptr %s8, ptr %t161)
  store { i64, ptr } %t164, ptr %l70
  br label %bb53
bb53:
  %t165 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t165, ptr %l71, !tbaa !27
  %t166 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s8, i64 10)
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l73
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb55, label %ok.170, !prof !99
ok.170:
  store i64 %t167, ptr %l72
  br label %bb54
bb54:
  %t171 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t172 = load i64, ptr %l72, !tbaa !24
  %t173 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s8, { i64, ptr } %t171, i64 %t172)
  %t174 = extractvalue { i32, i64 } %t173, 1
  %t175 = extractvalue { i32, i64 } %t173, 0
  store i32 %t175, ptr %l75
  %t176 = icmp ne i32 %t175, 0
  br i1 %t176, label %bb58, label %ok.177, !prof !99
ok.177:
  store i64 %t174, ptr %l74
  br label %bb57
bb55:
  br label %bb56
bb56:
  store i64 -1, ptr %l68, !tbaa !24
  br label %bb59
bb57:
  %t178 = load i64, ptr %l74, !tbaa !24
  store i64 %t178, ptr %l68, !tbaa !24
  br label %bb59
bb58:
  br label %bb56
bb59:
  %t179 = load i64, ptr %l68, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/lsp:Server", ptr %t180, i32 0, i32 5
  %t186 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %t182, i64 %t179)
  store i1 %t186, ptr %l79
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s8)
  br label %bb61
bb61:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s5, ptr %t187, { i64, ptr } %t188)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb63:
  br label %bb31
bb64:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ehandle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca i32
  %l63 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca i1
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l97 = alloca i32
  %l99 = alloca i1
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca i32
  %l110 = alloca i1
  %l113 = alloca { i64, ptr }
  %l114 = alloca i32
  %l116 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l131 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i32
  %l140 = alloca i1
  %l144 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l147 = alloca i32
  %l149 = alloca i1
  %l152 = alloca ptr
  %l154 = alloca { i64, ptr }
  %l156 = alloca i1
  %l161 = alloca i1
  %l165 = alloca ptr
  %l170 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v1, ptr %v1, { i64, ptr } %t1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l14
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l11, !tbaa !29
  br label %bb8
bb2:
  %t9 = load i32, ptr %l14, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l16, !tbaa !21
  %t13 = load i32, ptr %l14, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l19, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2flsp_2eerrorReply(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) }, i64 -32700, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t19, ptr %l20
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t21 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t20)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t23 = load ptr, ptr %l11, !tbaa !29
  store ptr %t23, ptr %l2, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = call { i64, ptr } @compiler_2flsp_2estr(ptr %v1, ptr %s0, ptr %v1, ptr %t24, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store { i64, ptr } %t26, ptr %l23
  br label %bb9
bb9:
  %t27 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2flsp_2eidOf(ptr %v1, ptr %s0, ptr %t28)
  store { i64, ptr } %t30, ptr %l25
  br label %bb10
bb10:
  %t31 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t32, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t34, ptr %l27
  br label %bb11
bb11:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2einitialize(ptr %v0, ptr %v1, ptr %s0, ptr %t36, ptr %t37, { i64, ptr } %t38)
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t44, ptr %l32
  br label %bb16
bb16:
  %t45 = load i1, ptr %l32, !tbaa !21
  br i1 %t45, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb20
bb18:
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t48, ptr %l35
  br label %bb19
bb19:
  %t49 = load i1, ptr %l35, !tbaa !21
  store i1 %t49, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t50 = load i1, ptr %l33, !tbaa !21
  br i1 %t50, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb24
bb22:
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t51, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t53, ptr %l38
  br label %bb23
bb23:
  %t54 = load i1, ptr %l38, !tbaa !21
  store i1 %t54, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t55 = load i1, ptr %l36, !tbaa !21
  br i1 %t55, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb28
bb26:
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t58, ptr %l41
  br label %bb27
bb27:
  %t59 = load i1, ptr %l41, !tbaa !21
  store i1 %t59, ptr %l39, !tbaa !21
  br label %bb28
bb28:
  %t60 = load i1, ptr %l39, !tbaa !21
  br i1 %t60, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  br label %bb31
bb31:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t63, ptr %l43
  br label %bb32
bb32:
  %t64 = load i1, ptr %l43, !tbaa !21
  br i1 %t64, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2edrain(ptr %v0, ptr %v2, ptr %t65)
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lsp:Server", ptr %t67, i32 0, i32 7
  store i1 true, ptr %t69, !tbaa !21
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l46, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s4, ptr %s4, { i64, ptr } %t71, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store { i64, ptr } %t73, ptr %l48
  br label %bb36
bb36:
  %t74 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t75 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s4, ptr %t75, { i64, ptr } %t74)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb38:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t79, ptr %l51
  br label %bb39
bb39:
  %t80 = load i1, ptr %l51, !tbaa !21
  br i1 %t80, label %bb40, label %bb41
bb40:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lsp:Server", ptr %t81, i32 0, i32 8
  store i1 true, ptr %t83, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb41:
  br label %bb42
bb42:
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t84, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t86, ptr %l54
  br label %bb43
bb43:
  %t87 = load i1, ptr %l54, !tbaa !21
  br i1 %t87, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t88 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t93 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t88, { i64, ptr } %t90)
  %t94 = extractvalue { i32, ptr } %t93, 1
  %t95 = extractvalue { i32, ptr } %t93, 0
  store i32 %t95, ptr %l61
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb47, label %ok.97, !prof !99
ok.97:
  store ptr %t94, ptr %l60
  br label %bb46
bb45:
  br label %bb59
bb46:
  %t98 = load ptr, ptr %l60, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l67, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t102 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t98, { i64, ptr } %t99)
  %t103 = extractvalue { i32, ptr } %t102, 1
  %t104 = extractvalue { i32, ptr } %t102, 0
  store i32 %t104, ptr %l70
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb52, label %ok.106, !prof !99
ok.106:
  store ptr %t103, ptr %l69
  br label %bb51
bb47:
  %t107 = load i32, ptr %l61, !tbaa !23
  %t108 = ashr i32 %t107, 16
  %t110 = icmp eq i32 %t108, 1
  store i1 %t110, ptr %l63, !tbaa !21
  %t111 = load i32, ptr %l61, !tbaa !23
  %t112 = ashr i32 %t111, 16
  %t114 = icmp eq i32 %t112, 1
  br i1 %t114, label %bb48, label %bb49
bb48:
  call void @__olang_errpay_pop()
  br label %bb49
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb51:
  %t116 = load ptr, ptr %l69, !tbaa !29
  store ptr %t116, ptr %l55, !tbaa !29
  br label %bb55
bb52:
  %t117 = load i32, ptr %l70, !tbaa !23
  %t118 = ashr i32 %t117, 16
  %t120 = icmp eq i32 %t118, 1
  store i1 %t120, ptr %l72, !tbaa !21
  %t121 = load i32, ptr %l70, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  br i1 %t124, label %bb53, label %bb54
bb53:
  call void @__olang_errpay_pop()
  br label %bb54
bb54:
  br label %bb50
bb55:
  %t126 = load ptr, ptr %l55, !tbaa !29
  store ptr %t126, ptr %l5, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l75, !tbaa !29
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2flsp_2estr(ptr %v1, ptr %s6, ptr %v1, ptr %t128, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store { i64, ptr } %t130, ptr %l77
  br label %bb56
bb56:
  %t131 = load ptr, ptr %l5, !tbaa !29
  %t133 = call { i64, ptr } @compiler_2flsp_2estr(ptr %v1, ptr %s6, ptr %v1, ptr %t131, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store { i64, ptr } %t133, ptr %l79
  br label %bb57
bb57:
  %t134 = load ptr, ptr %l75, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l79, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eopened(ptr %v0, ptr %v1, ptr %v1, ptr %t134, { i64, ptr } %t135, { i64, ptr } %t136)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb59:
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t137, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t139, ptr %l81
  br label %bb60
bb60:
  %t140 = load i1, ptr %l81, !tbaa !21
  br i1 %t140, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t141 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l84, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t145 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t141, { i64, ptr } %t142)
  %t146 = extractvalue { i32, ptr } %t145, 1
  %t147 = extractvalue { i32, ptr } %t145, 0
  store i32 %t147, ptr %l87
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb64, label %ok.149, !prof !99
ok.149:
  store ptr %t146, ptr %l86
  br label %bb63
bb62:
  br label %bb91
bb63:
  %t150 = load ptr, ptr %l86, !tbaa !29
  store ptr %t150, ptr %l82, !tbaa !29
  br label %bb68
bb64:
  %t151 = load i32, ptr %l87, !tbaa !23
  %t152 = ashr i32 %t151, 16
  %t154 = icmp eq i32 %t152, 1
  store i1 %t154, ptr %l89, !tbaa !21
  %t155 = load i32, ptr %l87, !tbaa !23
  %t156 = ashr i32 %t155, 16
  %t158 = icmp eq i32 %t156, 1
  br i1 %t158, label %bb65, label %bb66
bb65:
  call void @__olang_errpay_pop()
  br label %bb66
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb68:
  %t160 = load ptr, ptr %l82, !tbaa !29
  store ptr %t160, ptr %l6, !tbaa !29
  %t161 = load ptr, ptr %l6, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t165 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t161, { i64, ptr } %t162)
  %t166 = extractvalue { i32, ptr } %t165, 1
  %t167 = extractvalue { i32, ptr } %t165, 0
  store i32 %t167, ptr %l97
  %t168 = icmp ne i32 %t167, 0
  br i1 %t168, label %bb70, label %ok.169, !prof !99
ok.169:
  store ptr %t166, ptr %l96
  br label %bb69
bb69:
  %t170 = load ptr, ptr %l96, !tbaa !29
  store ptr %t170, ptr %l92, !tbaa !29
  br label %bb74
bb70:
  %t171 = load i32, ptr %l97, !tbaa !23
  %t172 = ashr i32 %t171, 16
  %t174 = icmp eq i32 %t172, 1
  store i1 %t174, ptr %l99, !tbaa !21
  %t175 = load i32, ptr %l97, !tbaa !23
  %t176 = ashr i32 %t175, 16
  %t178 = icmp eq i32 %t176, 1
  br i1 %t178, label %bb71, label %bb72
bb71:
  call void @__olang_errpay_pop()
  br label %bb72
bb72:
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb74:
  %t180 = load ptr, ptr %l92, !tbaa !29
  %t181 = call { i64, ptr } @compiler_2flsp_2estr(ptr %v1, ptr %s8, ptr %v1, ptr %t180, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store { i64, ptr } %t181, ptr %l102
  br label %bb75
bb75:
  %t182 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t182, ptr %l7, !tbaa !27
  %t183 = load ptr, ptr %l6, !tbaa !29
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l105, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t187 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t183, { i64, ptr } %t184)
  %t188 = extractvalue { i32, ptr } %t187, 1
  %t189 = extractvalue { i32, ptr } %t187, 0
  store i32 %t189, ptr %l108
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb77, label %ok.191, !prof !99
ok.191:
  store ptr %t188, ptr %l107
  br label %bb76
bb76:
  %t192 = load ptr, ptr %l107, !tbaa !29
  %t193 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v1, ptr %v1, ptr %t192)
  %t194 = extractvalue { i32, { i64, ptr } } %t193, 1
  %t195 = extractvalue { i32, { i64, ptr } } %t193, 0
  store i32 %t195, ptr %l114
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb82, label %ok.197, !prof !99
ok.197:
  store { i64, ptr } %t194, ptr %l113
  br label %bb81
bb77:
  %t198 = load i32, ptr %l108, !tbaa !23
  %t199 = ashr i32 %t198, 16
  %t201 = icmp eq i32 %t199, 1
  store i1 %t201, ptr %l110, !tbaa !21
  %t202 = load i32, ptr %l108, !tbaa !23
  %t203 = ashr i32 %t202, 16
  %t205 = icmp eq i32 %t203, 1
  br i1 %t205, label %bb78, label %bb79
bb78:
  call void @__olang_errpay_pop()
  br label %bb79
bb79:
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  %t207 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t207, ptr %l103, !tbaa !27
  br label %bb85
bb82:
  %t208 = load i32, ptr %l114, !tbaa !23
  %t209 = ashr i32 %t208, 16
  %t211 = icmp eq i32 %t209, 1
  store i1 %t211, ptr %l116, !tbaa !21
  %t212 = load i32, ptr %l114, !tbaa !23
  %t213 = ashr i32 %t212, 16
  %t215 = icmp eq i32 %t213, 1
  br i1 %t215, label %bb83, label %bb84
bb83:
  call void @__olang_errpay_pop()
  br label %bb84
bb84:
  br label %bb80
bb85:
  %t217 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t217, ptr %l8, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t222 = icmp eq i64 %t220, 0
  br i1 %t222, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb87:
  br label %bb88
bb88:
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l122, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t225, ptr %l123, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t226, ptr %l124, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t231 = sub i64 %t229, 1
  %t233 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr ptr, ptr %t234, i64 %t231
  %t236 = load ptr, ptr %t235, !tbaa !39
  %t238 = call { i64, ptr } @compiler_2flsp_2estr(ptr %v1, ptr %s8, ptr %v1, ptr %t236, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store { i64, ptr } %t238, ptr %l129
  br label %bb89
bb89:
  %t239 = load ptr, ptr %l122, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l129, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2echanged(ptr %v0, ptr %v1, ptr %v1, ptr %t239, { i64, ptr } %t240, { i64, ptr } %t241)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb91:
  %t242 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t244 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t242, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t244, ptr %l131
  br label %bb92
bb92:
  %t245 = load i1, ptr %l131, !tbaa !21
  br i1 %t245, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s13
  %t246 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l135, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t251 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t246, { i64, ptr } %t248)
  %t252 = extractvalue { i32, ptr } %t251, 1
  %t253 = extractvalue { i32, ptr } %t251, 0
  store i32 %t253, ptr %l138
  %t254 = icmp ne i32 %t253, 0
  br i1 %t254, label %bb96, label %ok.255, !prof !99
ok.255:
  store ptr %t252, ptr %l137
  br label %bb95
bb94:
  br label %bb107
bb95:
  %t256 = load ptr, ptr %l137, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l144, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t260 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t256, { i64, ptr } %t257)
  %t261 = extractvalue { i32, ptr } %t260, 1
  %t262 = extractvalue { i32, ptr } %t260, 0
  store i32 %t262, ptr %l147
  %t263 = icmp ne i32 %t262, 0
  br i1 %t263, label %bb101, label %ok.264, !prof !99
ok.264:
  store ptr %t261, ptr %l146
  br label %bb100
bb96:
  %t265 = load i32, ptr %l138, !tbaa !23
  %t266 = ashr i32 %t265, 16
  %t268 = icmp eq i32 %t266, 1
  store i1 %t268, ptr %l140, !tbaa !21
  %t269 = load i32, ptr %l138, !tbaa !23
  %t270 = ashr i32 %t269, 16
  %t272 = icmp eq i32 %t270, 1
  br i1 %t272, label %bb97, label %bb98
bb97:
  call void @__olang_errpay_pop()
  br label %bb98
bb98:
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb100:
  %t274 = load ptr, ptr %l146, !tbaa !29
  store ptr %t274, ptr %l132, !tbaa !29
  br label %bb104
bb101:
  %t275 = load i32, ptr %l147, !tbaa !23
  %t276 = ashr i32 %t275, 16
  %t278 = icmp eq i32 %t276, 1
  store i1 %t278, ptr %l149, !tbaa !21
  %t279 = load i32, ptr %l147, !tbaa !23
  %t280 = ashr i32 %t279, 16
  %t282 = icmp eq i32 %t280, 1
  br i1 %t282, label %bb102, label %bb103
bb102:
  call void @__olang_errpay_pop()
  br label %bb103
bb103:
  br label %bb99
bb104:
  %t284 = load ptr, ptr %l132, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l152, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2flsp_2estr(ptr %v1, ptr %s13, ptr %v1, ptr %t284, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store { i64, ptr } %t288, ptr %l154
  br label %bb105
bb105:
  %t289 = load ptr, ptr %l152, !tbaa !29
  %t290 = load { i64, ptr }, ptr %l154, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eclosed(ptr %v0, ptr %v1, ptr %t289, { i64, ptr } %t290)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb107:
  %t291 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t293 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t291, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t293, ptr %l156
  br label %bb108
bb108:
  %t294 = load i1, ptr %l156, !tbaa !21
  br i1 %t294, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb110:
  br label %bb111
bb111:
  %t295 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t298 = insertvalue { i64, ptr } undef, i64 6, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr @G_2ecompiler_2flsp_2eRequests, 1
  %t301 = load ptr, ptr @__olang_prog_scope
  %t304 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t301, ptr %v1, { i64, ptr } %t299, { i64, ptr } %t295)
  store i1 %t304, ptr %l161
  br label %bb112
bb112:
  %t305 = load i1, ptr %l161, !tbaa !21
  br i1 %t305, label %bb113, label %bb114
bb113:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eask(ptr %v0, ptr %v1, ptr %s0, ptr %v2, ptr %t306, { i64, ptr } %t307, { i64, ptr } %t308)
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb116:
  %t312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t312, ptr %l165, !tbaa !29
  %t313 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t315 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t318 = extractvalue { i64, ptr } %t314, 1
  %t319 = extractvalue { i64, ptr } %t314, 0
  %t320 = add i64 %t316, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t315, i64 %t316)
  %t322 = getelementptr i8, ptr %t321, i64 %t316
  call void @olang_textcopy(ptr %t322, ptr %t318, i64 %t319)
  %t323 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t321, 1
  %t328 = call { i64, ptr } @compiler_2flsp_2eerrorReply(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t313, i64 -32601, { i64, ptr } %t324)
  store { i64, ptr } %t328, ptr %l170
  br label %bb117
bb117:
  %t329 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t330 = load ptr, ptr %l165, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s0, ptr %t330, { i64, ptr } %t329)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2einitialize(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i32
  %l27 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l52 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l76 = alloca i1
  %l79 = alloca i1
  %l86 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t6 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %a1, { i64, ptr } %t3)
  %t7 = extractvalue { i32, ptr } %t6, 1
  %t8 = extractvalue { i32, ptr } %t6, 0
  store i32 %t8, ptr %l15
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store ptr %t7, ptr %l14
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l14, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t16 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t11, { i64, ptr } %t13)
  %t17 = extractvalue { i32, ptr } %t16, 1
  %t18 = extractvalue { i32, ptr } %t16, 0
  store i32 %t18, ptr %l25
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb7, label %ok.20, !prof !99
ok.20:
  store ptr %t17, ptr %l24
  br label %bb6
bb2:
  %t21 = load i32, ptr %l15, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l17, !tbaa !21
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t30 = icmp sge i64 0, 0
  br i1 %t30, label %bb22, label %bb23
bb6:
  %t32 = load ptr, ptr %l24, !tbaa !29
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t37 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t32, { i64, ptr } %t34)
  %t38 = extractvalue { i32, ptr } %t37, 1
  %t39 = extractvalue { i32, ptr } %t37, 0
  store i32 %t39, ptr %l35
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb11, label %ok.41, !prof !99
ok.41:
  store ptr %t38, ptr %l34
  br label %bb10
bb7:
  %t42 = load i32, ptr %l25, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  store i1 %t45, ptr %l27, !tbaa !21
  %t46 = load i32, ptr %l25, !tbaa !23
  %t47 = ashr i32 %t46, 16
  %t49 = icmp eq i32 %t47, 1
  br i1 %t49, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb5
bb10:
  %t51 = load ptr, ptr %l34, !tbaa !29
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t55 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %s0, ptr %t51, { i64, ptr } %t52)
  %t56 = extractvalue { i32, ptr } %t55, 1
  %t57 = extractvalue { i32, ptr } %t55, 0
  store i32 %t57, ptr %l44
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb15, label %ok.59, !prof !99
ok.59:
  store ptr %t56, ptr %l43
  br label %bb14
bb11:
  %t60 = load i32, ptr %l35, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  store i1 %t63, ptr %l37, !tbaa !21
  %t64 = load i32, ptr %l35, !tbaa !23
  %t65 = ashr i32 %t64, 16
  %t67 = icmp eq i32 %t65, 1
  br i1 %t67, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb5
bb14:
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s0, ptr %s0, ptr %t69)
  %t71 = extractvalue { i32, { i64, ptr } } %t70, 1
  %t72 = extractvalue { i32, { i64, ptr } } %t70, 0
  store i32 %t72, ptr %l50
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb19, label %ok.74, !prof !99
ok.74:
  store { i64, ptr } %t71, ptr %l49
  br label %bb18
bb15:
  %t75 = load i32, ptr %l44, !tbaa !23
  %t76 = ashr i32 %t75, 16
  %t78 = icmp eq i32 %t76, 1
  store i1 %t78, ptr %l46, !tbaa !21
  %t79 = load i32, ptr %l44, !tbaa !23
  %t80 = ashr i32 %t79, 16
  %t82 = icmp eq i32 %t80, 1
  br i1 %t82, label %bb16, label %bb17
bb16:
  call void @__olang_errpay_pop()
  br label %bb17
bb17:
  br label %bb5
bb18:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t84, ptr %l9, !tbaa !27
  br label %bb26
bb19:
  %t85 = load i32, ptr %l50, !tbaa !23
  %t86 = ashr i32 %t85, 16
  %t88 = icmp eq i32 %t86, 1
  store i1 %t88, ptr %l52, !tbaa !21
  %t89 = load i32, ptr %l50, !tbaa !23
  %t90 = ashr i32 %t89, 16
  %t92 = icmp eq i32 %t90, 1
  br i1 %t92, label %bb20, label %bb21
bb20:
  call void @__olang_errpay_pop()
  br label %bb21
bb21:
  br label %bb5
bb22:
  %t94 = icmp sle i64 0, 1152921504606846975
  br i1 %t94, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9565c00a3cf79970_b45483162fef2b54)
  unreachable
bb24:
  %t96 = mul i64 0, 8
  %t97 = insertvalue { i64, ptr } undef, i64 0, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t98, ptr %l9, !tbaa !27
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_9565c00a3cf79970_b45483162fef2b54)
  unreachable
bb26:
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t100, ptr %l3, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t107, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l6, !tbaa !24
  br label %bb29
bb28:
  br label %bb45
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t113 = load i64, ptr %l5, !tbaa !24
  %t114 = load i64, ptr %l6, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb31:
  br label %bb32
bb32:
  %t121 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t121, ptr %l68, !tbaa !27
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t131 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s0, ptr %s0, ptr %t127)
  %t132 = extractvalue { i32, { i64, ptr } } %t131, 1
  %t133 = extractvalue { i32, { i64, ptr } } %t131, 0
  store i32 %t133, ptr %l74
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb34, label %ok.135, !prof !99
ok.135:
  store { i64, ptr } %t132, ptr %l73
  br label %bb33
bb33:
  %t136 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t136, ptr %l71, !tbaa !27
  br label %bb38
bb34:
  %t137 = load i32, ptr %l74, !tbaa !23
  %t138 = ashr i32 %t137, 16
  %t140 = icmp eq i32 %t138, 1
  store i1 %t140, ptr %l76, !tbaa !21
  %t141 = load i32, ptr %l74, !tbaa !23
  %t142 = ashr i32 %t141, 16
  %t144 = icmp eq i32 %t142, 1
  br i1 %t144, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l71, !tbaa !27
  br label %bb38
bb38:
  %t146 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s3, { i64, ptr } %t146, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t147, ptr %l79
  br label %bb39
bb39:
  %t148 = load i1, ptr %l79, !tbaa !21
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/lsp:Server", ptr %t149, i32 0, i32 2
  store i1 true, ptr %t151, !tbaa !21
  br label %bb42
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t152 = load i64, ptr %l5, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l5, !tbaa !24
  br label %bb29
bb44:
  br label %bb45
bb45:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/lsp:Server", ptr %t157, i32 0, i32 2
  %t160 = load i1, ptr %t159, !tbaa !21
  br i1 %t160, label %bb46, label %bb47
bb46:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb48
bb48:
  %t162 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t164 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t174 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t162, i64 %t163)
  %t181 = getelementptr i8, ptr %t180, i64 %t163
  call void @olang_textcopy(ptr %t181, ptr %t165, i64 %t166)
  %t182 = getelementptr i8, ptr %t181, i64 %t166
  call void @olang_textcopy(ptr %t182, ptr %t168, i64 %t169)
  %t183 = getelementptr i8, ptr %t182, i64 %t169
  call void @olang_textcopy(ptr %t183, ptr %t171, i64 %t172)
  %t184 = getelementptr i8, ptr %t183, i64 %t172
  call void @olang_textcopy(ptr %t184, ptr %t174, i64 %t175)
  %t185 = getelementptr i8, ptr %t184, i64 %t175
  call void @olang_textcopy(ptr %t185, ptr %t177, i64 %t178)
  %t186 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t180, 1
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l88, !tbaa !29
  %t192 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t195 = extractvalue { i64, ptr } %t187, 1
  %t196 = extractvalue { i64, ptr } %t187, 0
  %t197 = add i64 %t193, %t196
  %t198 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t200 = add i64 %t197, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t200)
  call void @olang_textcopy(ptr %t201, ptr %t192, i64 %t193)
  %t202 = getelementptr i8, ptr %t201, i64 %t193
  call void @olang_textcopy(ptr %t202, ptr %t195, i64 %t196)
  %t203 = getelementptr i8, ptr %t202, i64 %t196
  call void @olang_textcopy(ptr %t203, ptr %t198, i64 %t199)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t201, 1
  %t209 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %a2, { i64, ptr } %t205)
  store { i64, ptr } %t209, ptr %l93
  br label %bb49
bb49:
  %t210 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t211 = load ptr, ptr %l88, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s0, ptr %t211, { i64, ptr } %t210)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2enote(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca i32
  %l30 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i32
  %l36 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca i32
  %l67 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l73 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i32
  %l96 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i64
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca i32
  %l114 = alloca i1
  %l117 = alloca { i64, ptr }
  %l118 = alloca i32
  %l120 = alloca i1
  %l130 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca i64
  %l140 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i32
  %l145 = alloca i1
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v1, ptr %s0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l18
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l17
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l17, !tbaa !29
  store ptr %t8, ptr %l15, !tbaa !29
  br label %bb6
bb2:
  %t9 = load i32, ptr %l18, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l20, !tbaa !21
  %t13 = load i32, ptr %l18, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t18 = load ptr, ptr %l15, !tbaa !29
  store ptr %t18, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t23 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t19, { i64, ptr } %t20)
  %t24 = extractvalue { i32, ptr } %t23, 1
  %t25 = extractvalue { i32, ptr } %t23, 0
  store i32 %t25, ptr %l28
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb8, label %ok.27, !prof !99
ok.27:
  store ptr %t24, ptr %l27
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l27, !tbaa !29
  %t29 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t28)
  %t30 = extractvalue { i32, i64 } %t29, 1
  %t31 = extractvalue { i32, i64 } %t29, 0
  store i32 %t31, ptr %l34
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb13, label %ok.33, !prof !99
ok.33:
  store i64 %t30, ptr %l33
  br label %bb12
bb8:
  %t34 = load i32, ptr %l28, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  store i1 %t37, ptr %l30, !tbaa !21
  %t38 = load i32, ptr %l28, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb16
bb12:
  %t43 = load i64, ptr %l33, !tbaa !24
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb16
bb13:
  %t44 = load i32, ptr %l34, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  store i1 %t47, ptr %l36, !tbaa !21
  %t48 = load i32, ptr %l34, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  br i1 %t51, label %bb14, label %bb15
bb14:
  call void @__olang_errpay_pop()
  br label %bb15
bb15:
  br label %bb11
bb16:
  %t53 = load i64, ptr %l23, !tbaa !24
  store i64 %t53, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = icmp slt i64 %t54, 0
  br i1 %t56, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb20
bb18:
  %t58 = load i64, ptr %l3, !tbaa !24
  store i64 %t58, ptr %l42, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lsp:Server", ptr %t59, i32 0, i32 1
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eLen_Ha7d56d00f5631ac8d39ace71211767ab(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l45
  br label %bb19
bb19:
  %t64 = load i64, ptr %l42, !tbaa !24
  %t65 = load i64, ptr %l45, !tbaa !24
  %t66 = icmp sge i64 %t64, %t65
  store i1 %t66, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l41, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lsp:Server", ptr %t69, i32 0, i32 4
  %t72 = load i64, ptr %l3, !tbaa !24
  %t75 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l50
  br label %bb24
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lsp:Server", ptr %t76, i32 0, i32 1
  %t79 = load i64, ptr %l3, !tbaa !24
  %t82 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store ptr %t82, ptr %l54
  br label %bb25
bb25:
  %t83 = load ptr, ptr %l54, !tbaa !29
  store ptr %t83, ptr %l4, !tbaa !29
  %t84 = load ptr, ptr %l4, !tbaa !29
  store ptr %t84, ptr %l55, !tbaa !29
  %t85 = call ptr @__olang_scope_hold(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l56, !tbaa !24
  %t87 = load i1, ptr @olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l55, !tbaa !29
  %t90 = call ptr @__olang_region_or(ptr %t89, ptr %v0)
  %t91 = call ptr @__olang_scope_hold(ptr %t90)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l56, !tbaa !24
  br label %bb27
bb27:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/lsp:Doc", ptr %t93, i32 0, i32 5
  %t96 = load i64, ptr %l56
  %t97 = inttoptr i64 %t96 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %t97, ptr %t95)
  br label %bb28
bb28:
  %t99 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t103 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t99, { i64, ptr } %t100)
  %t104 = extractvalue { i32, ptr } %t103, 1
  %t105 = extractvalue { i32, ptr } %t103, 0
  store i32 %t105, ptr %l65
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb30, label %ok.107, !prof !99
ok.107:
  store ptr %t104, ptr %l64
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l64, !tbaa !29
  %t109 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s0, ptr %s0, ptr %t108)
  %t110 = extractvalue { i32, { i64, ptr } } %t109, 1
  %t111 = extractvalue { i32, { i64, ptr } } %t109, 0
  store i32 %t111, ptr %l71
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb35, label %ok.113, !prof !99
ok.113:
  store { i64, ptr } %t110, ptr %l70
  br label %bb34
bb30:
  %t114 = load i32, ptr %l65, !tbaa !23
  %t115 = ashr i32 %t114, 16
  %t117 = icmp eq i32 %t115, 1
  store i1 %t117, ptr %l67, !tbaa !21
  %t118 = load i32, ptr %l65, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 1
  br i1 %t121, label %bb31, label %bb32
bb31:
  call void @__olang_errpay_pop()
  br label %bb32
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  %t123 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t123, ptr %l60, !tbaa !27
  br label %bb38
bb35:
  %t124 = load i32, ptr %l71, !tbaa !23
  %t125 = ashr i32 %t124, 16
  %t127 = icmp eq i32 %t125, 1
  store i1 %t127, ptr %l73, !tbaa !21
  %t128 = load i32, ptr %l71, !tbaa !23
  %t129 = ashr i32 %t128, 16
  %t131 = icmp eq i32 %t129, 1
  br i1 %t131, label %bb36, label %bb37
bb36:
  call void @__olang_errpay_pop()
  br label %bb37
bb37:
  br label %bb33
bb38:
  %t133 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t133, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  store i64 %t138, ptr %l8, !tbaa !24
  br label %bb39
bb39:
  %t140 = load i64, ptr %l7, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb40, label %bb41
bb40:
  br label %bb53
bb41:
  br label %bb42
bb42:
  %t148 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t148, ptr %l83, !tbaa !27
  %t149 = load i64, ptr %l7, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr ptr, ptr %t152, i64 %t149
  %t154 = load ptr, ptr %t153, !tbaa !39
  store ptr %t154, ptr %l9, !tbaa !29
  %t156 = load ptr, ptr %l4, !tbaa !29
  store ptr %t156, ptr %l86, !tbaa !29
  %t157 = call ptr @__olang_scope_hold(ptr %v0)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l87, !tbaa !24
  %t159 = load i1, ptr @olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1
  br i1 %t159, label %bb43, label %bb44
bb43:
  %t161 = load ptr, ptr %l86, !tbaa !29
  %t162 = call ptr @__olang_region_or(ptr %t161, ptr %v0)
  %t163 = call ptr @__olang_scope_hold(ptr %t162)
  %t164 = ptrtoint ptr %t163 to i64
  store i64 %t164, ptr %l87, !tbaa !24
  br label %bb44
bb44:
  %t165 = load ptr, ptr %l4, !tbaa !29
  %t167 = getelementptr %"compiler/lsp:Doc", ptr %t165, i32 0, i32 5
  store ptr %t167, ptr %l90, !tbaa !29
  %t168 = load ptr, ptr %l9, !tbaa !29
  %t170 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t168)
  %t171 = extractvalue { i32, i64 } %t170, 1
  %t172 = extractvalue { i32, i64 } %t170, 0
  store i32 %t172, ptr %l94
  %t173 = icmp ne i32 %t172, 0
  br i1 %t173, label %bb46, label %ok.174, !prof !99
ok.174:
  store i64 %t171, ptr %l93
  br label %bb45
bb45:
  %t175 = load i64, ptr %l93, !tbaa !24
  store i64 %t175, ptr %l91, !tbaa !24
  br label %bb50
bb46:
  %t176 = load i32, ptr %l94, !tbaa !23
  %t177 = ashr i32 %t176, 16
  %t179 = icmp eq i32 %t177, 1
  store i1 %t179, ptr %l96, !tbaa !21
  %t180 = load i32, ptr %l94, !tbaa !23
  %t181 = ashr i32 %t180, 16
  %t183 = icmp eq i32 %t181, 1
  br i1 %t183, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  store i64 -1, ptr %l91, !tbaa !24
  br label %bb50
bb50:
  %t185 = load i64, ptr %l87
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = load ptr, ptr %l90, !tbaa !29
  %t188 = load i64, ptr %l91, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %t186, ptr %t187, i64 %t188)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t189 = load i64, ptr %l7, !tbaa !24
  %t192 = add i64 %t189, 1
  store i64 %t192, ptr %l7, !tbaa !24
  br label %bb39
bb53:
  %t194 = load ptr, ptr %l4, !tbaa !29
  store ptr %t194, ptr %l102, !tbaa !29
  %t195 = call ptr @__olang_scope_hold(ptr %v0)
  %t196 = ptrtoint ptr %t195 to i64
  store i64 %t196, ptr %l103, !tbaa !24
  %t197 = load i1, ptr @olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1
  br i1 %t197, label %bb54, label %bb55
bb54:
  %t199 = load ptr, ptr %l102, !tbaa !29
  %t200 = call ptr @__olang_region_or(ptr %t199, ptr %v0)
  %t201 = call ptr @__olang_scope_hold(ptr %t200)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l103, !tbaa !24
  br label %bb55
bb55:
  %t203 = load ptr, ptr %l4, !tbaa !29
  %t205 = getelementptr %"compiler/lsp:Doc", ptr %t203, i32 0, i32 6
  %t206 = load i64, ptr %l103
  %t207 = inttoptr i64 %t206 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %t207, ptr %t205)
  br label %bb56
bb56:
  %t209 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l109, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t213 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t209, { i64, ptr } %t210)
  %t214 = extractvalue { i32, ptr } %t213, 1
  %t215 = extractvalue { i32, ptr } %t213, 0
  store i32 %t215, ptr %l112
  %t216 = icmp ne i32 %t215, 0
  br i1 %t216, label %bb58, label %ok.217, !prof !99
ok.217:
  store ptr %t214, ptr %l111
  br label %bb57
bb57:
  %t218 = load ptr, ptr %l111, !tbaa !29
  %t219 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s0, ptr %s0, ptr %t218)
  %t220 = extractvalue { i32, { i64, ptr } } %t219, 1
  %t221 = extractvalue { i32, { i64, ptr } } %t219, 0
  store i32 %t221, ptr %l118
  %t222 = icmp ne i32 %t221, 0
  br i1 %t222, label %bb63, label %ok.223, !prof !99
ok.223:
  store { i64, ptr } %t220, ptr %l117
  br label %bb62
bb58:
  %t224 = load i32, ptr %l112, !tbaa !23
  %t225 = ashr i32 %t224, 16
  %t227 = icmp eq i32 %t225, 1
  store i1 %t227, ptr %l114, !tbaa !21
  %t228 = load i32, ptr %l112, !tbaa !23
  %t229 = ashr i32 %t228, 16
  %t231 = icmp eq i32 %t229, 1
  br i1 %t231, label %bb59, label %bb60
bb59:
  call void @__olang_errpay_pop()
  br label %bb60
bb60:
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb62:
  %t233 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t233, ptr %l107, !tbaa !27
  br label %bb66
bb63:
  %t234 = load i32, ptr %l118, !tbaa !23
  %t235 = ashr i32 %t234, 16
  %t237 = icmp eq i32 %t235, 1
  store i1 %t237, ptr %l120, !tbaa !21
  %t238 = load i32, ptr %l118, !tbaa !23
  %t239 = ashr i32 %t238, 16
  %t241 = icmp eq i32 %t239, 1
  br i1 %t241, label %bb64, label %bb65
bb64:
  call void @__olang_errpay_pop()
  br label %bb65
bb65:
  br label %bb61
bb66:
  %t243 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t243, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t246 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  store i64 %t248, ptr %l13, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s9
  %t250 = load i64, ptr %l12, !tbaa !24
  %t251 = load i64, ptr %l13, !tbaa !24
  %t254 = icmp slt i64 %t250, %t251
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s9)
  br label %bb83
bb69:
  br label %bb70
bb70:
  %t258 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t258, ptr %l130, !tbaa !27
  %t259 = load i64, ptr %l12, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr ptr, ptr %t262, i64 %t259
  %t264 = load ptr, ptr %t263, !tbaa !39
  store ptr %t264, ptr %l14, !tbaa !29
  %t266 = load ptr, ptr %l4, !tbaa !29
  store ptr %t266, ptr %l133, !tbaa !29
  %t267 = call ptr @__olang_scope_hold(ptr %v0)
  %t268 = ptrtoint ptr %t267 to i64
  store i64 %t268, ptr %l134, !tbaa !24
  %t269 = load i1, ptr @olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1
  br i1 %t269, label %bb71, label %bb72
bb71:
  %t271 = load ptr, ptr %l133, !tbaa !29
  %t272 = call ptr @__olang_region_or(ptr %t271, ptr %v0)
  %t273 = call ptr @__olang_scope_hold(ptr %t272)
  %t274 = ptrtoint ptr %t273 to i64
  store i64 %t274, ptr %l134, !tbaa !24
  br label %bb72
bb72:
  %t275 = load ptr, ptr %l4, !tbaa !29
  %t277 = getelementptr %"compiler/lsp:Doc", ptr %t275, i32 0, i32 6
  store ptr %t277, ptr %l137, !tbaa !29
  %t278 = load i64, ptr %l134
  %t279 = inttoptr i64 %t278 to ptr
  %t280 = call ptr @__olang_scope_hold(ptr %t279)
  %t281 = ptrtoint ptr %t280 to i64
  store i64 %t281, ptr %l138, !tbaa !24
  %t282 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t282, label %bb73, label %bb74
bb73:
  %t284 = load i64, ptr %l134
  %t285 = inttoptr i64 %t284 to ptr
  %t286 = call ptr @__olang_region_make(ptr %t285)
  %t287 = ptrtoint ptr %t286 to i64
  store i64 %t287, ptr %l138, !tbaa !24
  br label %bb74
bb74:
  %t288 = load ptr, ptr %l14, !tbaa !29
  %t290 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s0, ptr %s9, ptr %t288)
  %t291 = extractvalue { i32, { i64, ptr } } %t290, 1
  %t292 = extractvalue { i32, { i64, ptr } } %t290, 0
  store i32 %t292, ptr %l143
  %t293 = icmp ne i32 %t292, 0
  br i1 %t293, label %bb76, label %ok.294, !prof !99
ok.294:
  store { i64, ptr } %t291, ptr %l142
  br label %bb75
bb75:
  %t295 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t295, ptr %l140, !tbaa !27
  br label %bb80
bb76:
  %t296 = load i32, ptr %l143, !tbaa !23
  %t297 = ashr i32 %t296, 16
  %t299 = icmp eq i32 %t297, 1
  store i1 %t299, ptr %l145, !tbaa !21
  %t300 = load i32, ptr %l143, !tbaa !23
  %t301 = ashr i32 %t300, 16
  %t303 = icmp eq i32 %t301, 1
  br i1 %t303, label %bb77, label %bb78
bb77:
  call void @__olang_errpay_pop()
  br label %bb78
bb78:
  br label %bb79
bb79:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l140, !tbaa !27
  br label %bb80
bb80:
  %t305 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = load i64, ptr %l138
  %t309 = inttoptr i64 %t308 to ptr
  %t310 = call ptr @__olang_held_alloc(ptr %t309, i64 %t307)
  call void @olang_textcopy(ptr %t310, ptr %t306, i64 %t307)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  %t314 = load i64, ptr %l134
  %t315 = inttoptr i64 %t314 to ptr
  %t316 = load i64, ptr %l134
  %t317 = inttoptr i64 %t316 to ptr
  %t318 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %t315, ptr %t317, ptr %t318, { i64, ptr } %t312)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s9)
  br label %bb82
bb82:
  %t320 = load i64, ptr %l12, !tbaa !24
  %t323 = add i64 %t320, 1
  store i64 %t323, ptr %l12, !tbaa !24
  br label %bb67
bb83:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eopened(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/lsp:Doc"
  %l74 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca i64
  %l92 = alloca i64
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l101 = alloca i64
  %l105 = alloca ptr
  %l106 = alloca i64
  %t117 = alloca %"compiler/lsp:Doc", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = call { i64, ptr } @compiler_2flsp_2ePathOf(ptr %v1, ptr %v0, { i64, ptr } %t11)
  store { i64, ptr } %t13, ptr %l19
  br label %bb4
bb3:
  br label %bb49
bb4:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t14, ptr %lp4
  %t15 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t16 = load ptr, ptr %lp4
  store { i64, ptr } %t15, ptr %t16, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lsp:Server", ptr %t17, i32 0, i32 1
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eLen_Ha7d56d00f5631ac8d39ace71211767ab(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l22
  br label %bb5
bb5:
  %t22 = load i64, ptr %l22, !tbaa !24
  store i64 %t22, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l7, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb11
bb8:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l29, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l29, !tbaa !24
  store i64 %t49, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l26, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l9, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l10, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lsp:Server", ptr %t69, i32 0, i32 1
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l50
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l50, !tbaa !29
  %t78 = getelementptr %"compiler/lsp:Doc", ptr %t76, i32 0, i32 4
  %t79 = load i1, ptr %t78, !tbaa !21
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t83 = load i64, ptr %l10, !tbaa !24
  store i64 %t83, ptr %l3, !tbaa !24
  br label %bb21
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t94, ptr %l60, !tbaa !27
  %t95 = load ptr, ptr %lp4
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l61, !tbaa !27
  %t97 = call ptr @__olang_scope_hold(ptr %v0)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l62, !tbaa !24
  %t99 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e2
  br i1 %t99, label %bb24, label %bb25
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/lsp:Server", ptr %t101, i32 0, i32 1
  %t104 = load i64, ptr %l3, !tbaa !24
  %t107 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %v0, ptr %v0, ptr %t103, i64 %t104)
  store ptr %t107, ptr %l79
  br label %bb30
bb24:
  %t108 = call ptr @__olang_region_make(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l62, !tbaa !24
  br label %bb25
bb25:
  %t110 = load ptr, ptr %lp4
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l62
  %t113 = inttoptr i64 %t112 to ptr
  %t115 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %t113, { i64, ptr } %t111)
  store { i64, ptr } %t115, ptr %l65
  br label %bb26
bb26:
  %t116 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l61, !tbaa !27
  call void @compiler_2flsp_3aDoc_2ector(ptr %t117, ptr %v1, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t118, { i64, ptr } %t119, { i64, ptr } %t116)
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t117, i64 152, i1 false)
  br label %bb27
bb27:
  %t121 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 152, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %l67, i64 152, i1 false)
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/lsp:Server", ptr %t123, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2ePus_H951db0fb6558bf39f52145a6692a11d3(ptr %v0, ptr %v0, ptr %t125, ptr %t121)
  br label %bb28
bb28:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/lsp:Server", ptr %t129, i32 0, i32 1
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eLen_Ha7d56d00f5631ac8d39ace71211767ab(ptr %v0, ptr %t131)
  store i64 %t133, ptr %l74
  br label %bb29
bb29:
  %t134 = load i64, ptr %l74, !tbaa !24
  %t135 = sub i64 %t134, 1
  store i64 %t135, ptr %l3, !tbaa !24
  br label %bb48
bb30:
  %t137 = load ptr, ptr %l79, !tbaa !29
  store ptr %t137, ptr %l12, !tbaa !29
  %t138 = load ptr, ptr %l12, !tbaa !29
  store ptr %t138, ptr %l80, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t140 = load ptr, ptr %l80, !tbaa !29
  %t141 = getelementptr %"compiler/lsp:Doc", ptr %t140, i32 0, i32 0
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l82, !tbaa !27
  %t144 = load ptr, ptr %l80, !tbaa !29
  %t145 = getelementptr %"compiler/lsp:Doc", ptr %t144, i32 0, i32 0
  store { i64, ptr } %t139, ptr %t145, !tbaa !27
  %t146 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e0
  br i1 %t146, label %bb31, label %bb32
bb31:
  %t148 = load { i64, ptr }, ptr %l82
  %t149 = extractvalue { i64, ptr } %t148, 1
  call void @__olang_region_release(ptr %t149)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %bb32
bb32:
  %t150 = load ptr, ptr %l12, !tbaa !29
  store ptr %t150, ptr %l84, !tbaa !29
  %t151 = load ptr, ptr %lp4
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t153 = load ptr, ptr %l84, !tbaa !29
  %t154 = getelementptr %"compiler/lsp:Doc", ptr %t153, i32 0, i32 1
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l86, !tbaa !27
  %t157 = load ptr, ptr %l84, !tbaa !29
  %t158 = getelementptr %"compiler/lsp:Doc", ptr %t157, i32 0, i32 1
  store { i64, ptr } %t152, ptr %t158, !tbaa !27
  %t159 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e1
  br i1 %t159, label %bb33, label %bb34
bb33:
  %t161 = load { i64, ptr }, ptr %l86
  %t162 = extractvalue { i64, ptr } %t161, 1
  call void @__olang_region_release(ptr %t162)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %bb34
bb34:
  %t163 = load ptr, ptr %l12, !tbaa !29
  store ptr %t163, ptr %l88, !tbaa !29
  %t164 = load ptr, ptr %l12, !tbaa !29
  store ptr %t164, ptr %l89, !tbaa !29
  %t165 = call ptr @__olang_scope_hold(ptr %v0)
  %t166 = ptrtoint ptr %t165 to i64
  store i64 %t166, ptr %l90, !tbaa !24
  %t167 = load i1, ptr @olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1
  br i1 %t167, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l89, !tbaa !29
  %t170 = call ptr @__olang_region_or(ptr %t169, ptr %v0)
  %t171 = call ptr @__olang_scope_hold(ptr %t170)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l90, !tbaa !24
  br label %bb36
bb36:
  %t173 = load i64, ptr %l90
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = call ptr @__olang_scope_hold(ptr %t174)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l92, !tbaa !24
  %t177 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e2
  br i1 %t177, label %bb37, label %bb38
bb37:
  %t179 = load i64, ptr %l90
  %t180 = inttoptr i64 %t179 to ptr
  %t181 = call ptr @__olang_region_make(ptr %t180)
  %t182 = ptrtoint ptr %t181 to i64
  store i64 %t182, ptr %l92, !tbaa !24
  br label %bb38
bb38:
  %t183 = load ptr, ptr %lp4
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t185 = load i64, ptr %l92
  %t186 = inttoptr i64 %t185 to ptr
  %t188 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %t186, { i64, ptr } %t184)
  store { i64, ptr } %t188, ptr %l95
  br label %bb39
bb39:
  %t189 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t190 = load ptr, ptr %l88, !tbaa !29
  %t191 = getelementptr %"compiler/lsp:Doc", ptr %t190, i32 0, i32 2
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %l97, !tbaa !27
  %t194 = load ptr, ptr %l88, !tbaa !29
  %t195 = getelementptr %"compiler/lsp:Doc", ptr %t194, i32 0, i32 2
  store { i64, ptr } %t189, ptr %t195, !tbaa !27
  %t196 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e2
  br i1 %t196, label %bb40, label %bb41
bb40:
  %t198 = load { i64, ptr }, ptr %l97
  %t199 = extractvalue { i64, ptr } %t198, 1
  call void @__olang_region_release(ptr %t199)
  store { i64, ptr } zeroinitializer, ptr %l97
  br label %bb41
bb41:
  %t200 = load ptr, ptr %l12, !tbaa !29
  %t202 = getelementptr %"compiler/lsp:Doc", ptr %t200, i32 0, i32 4
  store i1 true, ptr %t202, !tbaa !21
  %t203 = load ptr, ptr %l12, !tbaa !29
  store ptr %t203, ptr %l100, !tbaa !29
  %t204 = call ptr @__olang_scope_hold(ptr %v0)
  %t205 = ptrtoint ptr %t204 to i64
  store i64 %t205, ptr %l101, !tbaa !24
  %t206 = load i1, ptr @olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1
  br i1 %t206, label %bb42, label %bb43
bb42:
  %t208 = load ptr, ptr %l100, !tbaa !29
  %t209 = call ptr @__olang_region_or(ptr %t208, ptr %v0)
  %t210 = call ptr @__olang_scope_hold(ptr %t209)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l101, !tbaa !24
  br label %bb43
bb43:
  %t212 = load ptr, ptr %l12, !tbaa !29
  %t214 = getelementptr %"compiler/lsp:Doc", ptr %t212, i32 0, i32 5
  %t215 = load i64, ptr %l101
  %t216 = inttoptr i64 %t215 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %t216, ptr %t214)
  br label %bb44
bb44:
  %t218 = load ptr, ptr %l12, !tbaa !29
  store ptr %t218, ptr %l105, !tbaa !29
  %t219 = call ptr @__olang_scope_hold(ptr %v0)
  %t220 = ptrtoint ptr %t219 to i64
  store i64 %t220, ptr %l106, !tbaa !24
  %t221 = load i1, ptr @olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1
  br i1 %t221, label %bb45, label %bb46
bb45:
  %t223 = load ptr, ptr %l105, !tbaa !29
  %t224 = call ptr @__olang_region_or(ptr %t223, ptr %v0)
  %t225 = call ptr @__olang_scope_hold(ptr %t224)
  %t226 = ptrtoint ptr %t225 to i64
  store i64 %t226, ptr %l106, !tbaa !24
  br label %bb46
bb46:
  %t227 = load ptr, ptr %l12, !tbaa !29
  %t229 = getelementptr %"compiler/lsp:Doc", ptr %t227, i32 0, i32 6
  %t230 = load i64, ptr %l106
  %t231 = inttoptr i64 %t230 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %t231, ptr %t229)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esetText(ptr %v0, ptr %v2, ptr %t233, i64 %t234, { i64, ptr } %a2)
  br label %bb50
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2eRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca %"compiler/session:Reader"
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca i64
  %l51 = alloca ptr
  %l54 = alloca i64
  %l62 = alloca %"compiler/session:Reader"
  %l64 = alloca i1
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:worker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 1
  store ptr %t6, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l12, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = call ptr @__olang_scope_or(ptr %v1, ptr %t10)
  %t12 = call ptr @__olang_scope_hold(ptr %t11)
  %t13 = ptrtoint ptr %t12 to i64
  %t15 = inttoptr i64 %t13 to ptr
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eLen_Ha7d56d00f5631ac8d39ace71211767ab(ptr %t15, ptr %t16)
  store i64 %t17, ptr %l15
  br label %bb2
bb2:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = call ptr @__olang_scope_or(ptr %v1, ptr %t26)
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lsp:worker", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = call ptr @__olang_scope_or(ptr %v1, ptr %t33)
  %t36 = call ptr @__olang_scope_hold(ptr %t35)
  %t37 = ptrtoint ptr %t36 to i64
  %t39 = inttoptr i64 %t29 to ptr
  %t41 = inttoptr i64 %t37 to ptr
  %t42 = load ptr, ptr %l18, !tbaa !29
  %t44 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %t39, ptr %t41, ptr %t42, i64 %t25)
  store ptr %t44, ptr %l24
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l24, !tbaa !29
  store ptr %t45, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/lsp:Doc", ptr %t46, i32 0, i32 4
  %t49 = load i1, ptr %t48, !tbaa !21
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lsp:worker", ptr %t51, i32 0, i32 4
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/lsp:Doc", ptr %t54, i32 0, i32 2
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = call ptr @__olang_scope_hold(ptr %v0)
  %t59 = ptrtoint ptr %t58 to i64
  store i64 %t59, ptr %l31, !tbaa !24
  %t60 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t60, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  %t62 = call ptr @__olang_region_make(ptr %v0)
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr %"compiler/lsp:Doc", ptr %t64, i32 0, i32 3
  store ptr %t66, ptr %l34, !tbaa !29
  %t67 = load ptr, ptr %l34, !tbaa !29
  %t68 = call ptr @__olang_scope_or(ptr %v1, ptr %t67)
  %t69 = call ptr @__olang_scope_hold(ptr %t68)
  %t70 = ptrtoint ptr %t69 to i64
  %t72 = inttoptr i64 %t70 to ptr
  %t73 = load i64, ptr %l31
  %t74 = inttoptr i64 %t73 to ptr
  %t75 = load ptr, ptr %l34, !tbaa !29
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %t72, ptr %t74, ptr %t75)
  store { i64, ptr } %t76, ptr %l36
  br label %bb11
bb11:
  %t77 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = call ptr @__olang_scope_or(ptr %v1, ptr %t79)
  %t81 = call ptr @__olang_scope_hold(ptr %t80)
  %t82 = ptrtoint ptr %t81 to i64
  %t84 = inttoptr i64 %t82 to ptr
  %t85 = load ptr, ptr %l28, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %t84, ptr %v0, ptr %t85, { i64, ptr } %t86, { i64, ptr } %t77)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l2, !tbaa !24
  br label %bb1
bb15:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lsp:worker", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/lsp:Server", ptr %t96, i32 0, i32 4
  store ptr %t98, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t100 = load i64, ptr %l5, !tbaa !24
  store i64 %t100, ptr %l45, !tbaa !24
  %t101 = load ptr, ptr %l4, !tbaa !29
  store ptr %t101, ptr %l46, !tbaa !29
  %t102 = load ptr, ptr %l46, !tbaa !29
  %t103 = call ptr @__olang_scope_or(ptr %v1, ptr %t102)
  %t104 = call ptr @__olang_scope_hold(ptr %t103)
  %t105 = ptrtoint ptr %t104 to i64
  %t107 = inttoptr i64 %t105 to ptr
  %t108 = load ptr, ptr %l46, !tbaa !29
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t107, ptr %t108)
  store i64 %t109, ptr %l48
  br label %bb17
bb17:
  %t110 = load i64, ptr %l45, !tbaa !24
  %t111 = load i64, ptr %l48, !tbaa !24
  %t112 = icmp slt i64 %t110, %t111
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t116 = load ptr, ptr %l4, !tbaa !29
  store ptr %t116, ptr %l51, !tbaa !29
  %t117 = load i64, ptr %l5, !tbaa !24
  %t118 = load ptr, ptr %l51, !tbaa !29
  %t119 = call ptr @__olang_scope_or(ptr %v1, ptr %t118)
  %t120 = call ptr @__olang_scope_hold(ptr %t119)
  %t121 = ptrtoint ptr %t120 to i64
  %t123 = inttoptr i64 %t121 to ptr
  %t124 = load ptr, ptr %l51, !tbaa !29
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t123, ptr %t124, i64 %t117)
  store i64 %t126, ptr %l54
  br label %bb21
bb21:
  %t127 = load i64, ptr %l54, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2echeck(ptr %v0, ptr %v1, ptr %v2, ptr %t128, i64 %t127)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t132 = load i64, ptr %l5, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l5, !tbaa !24
  br label %bb16
bb24:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lsp:worker", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %t139, !tbaa !23
  %t142 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %s0, i32 %t140)
  store %"compiler/session:Reader" %t142, ptr %l62
  br label %bb25
bb25:
  %t143 = load %"compiler/session:Reader", ptr %l62
  store %"compiler/session:Reader" %t143, ptr %l7
  br label %bb26
bb26:
  %t145 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %s0, ptr %l7)
  store i1 %t145, ptr %l64
  br label %bb27
bb27:
  %t146 = load i1, ptr %l64, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb28, label %bb29
bb28:
  br label %bb40
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t150 = call { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %s0, ptr %s9, ptr %l7)
  %t151 = extractvalue { i32, { i64, ptr } } %t150, 1
  %t152 = extractvalue { i32, { i64, ptr } } %t150, 0
  store i32 %t152, ptr %l69
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb33, label %ok.154, !prof !99
ok.154:
  store { i64, ptr } %t151, ptr %l68
  br label %bb32
bb32:
  %t155 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t155, ptr %l66, !tbaa !27
  br label %bb35
bb33:
  %t156 = load i32, ptr %l69, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  store i1 %t159, ptr %l71, !tbaa !21
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb35:
  %t160 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t161 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2eanswer(ptr %v0, ptr %s9, ptr %v1, ptr %v2, ptr %t161, { i64, ptr } %t160)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb37:
  br label %bb31
bb38:
  br label %bb39
bb39:
  br label %bb26
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flsp_2ecompiler_2flsp_3aworker_2eanalysis(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l8 = alloca i1
  %l20 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l36 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lsp:worker", ptr %t2, i32 0, i32 6
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = icmp eq i64 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lsp:worker", ptr %t10, i32 0, i32 5
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lsp:worker", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb6, label %bb7
bb5:
  br label %bb9
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cb6dbf061e2dce2f_dc463ae13d2c2fbb)
  unreachable
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lsp:worker", ptr %t27, i32 0, i32 5
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %rv
  br label %ret
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lsp:worker", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/lsp:Server", ptr %t35, i32 0, i32 1
  store ptr %t37, ptr %l20, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t40 = call ptr @__olang_scope_or(ptr %v3, ptr %t39)
  %t41 = call ptr @__olang_scope_hold(ptr %t40)
  %t42 = ptrtoint ptr %t41 to i64
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lsp:worker", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v3, ptr %t46)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t42 to ptr
  %t54 = inttoptr i64 %t50 to ptr
  %t55 = load ptr, ptr %l20, !tbaa !29
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %t52, ptr %t54, ptr %t55, i64 %t38)
  store ptr %t57, ptr %l26
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l26, !tbaa !29
  %t60 = getelementptr %"compiler/lsp:Doc", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l28, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lsp:worker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l30, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lsp:worker", ptr %t67, i32 0, i32 4
  %t70 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = call ptr @__olang_scope_or(ptr %v3, ptr %t71)
  %t73 = call ptr @__olang_scope_hold(ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  %t75 = load ptr, ptr %l30, !tbaa !29
  %t76 = call ptr @__olang_scope_or(ptr %v4, ptr %t75)
  %t77 = call ptr @__olang_scope_hold(ptr %t76)
  %t78 = ptrtoint ptr %t77 to i64
  %t80 = inttoptr i64 %t74 to ptr
  %t82 = inttoptr i64 %t78 to ptr
  %t83 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t84 = load ptr, ptr %l30, !tbaa !29
  %t87 = call ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %t80, ptr %t82, ptr %v1, ptr %v0, ptr %v2, { i64, ptr } %t83, ptr %t84, ptr %a2, ptr %t69, i1 true, i1 true)
  store ptr %t87, ptr %l36
  br label %bb11
bb11:
  %t88 = load ptr, ptr %l36, !tbaa !29
  store ptr %t88, ptr %l3, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t94 = getelementptr %"compiler/lsp:worker", ptr %t89, i32 0, i32 5
  store ptr %t90, ptr %t94, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = getelementptr %"compiler/lsp:worker", ptr %t95, i32 0, i32 6
  store i64 %t96, ptr %t99, !tbaa !24
  %t100 = load ptr, ptr %l3, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2eanswer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/session:Positions"
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca %"compiler/session:Found"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/session:Positions"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l32 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i32
  %l60 = alloca i1
  %l63 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l68 = alloca i64
  %l71 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l96 = alloca %"compiler/session:Positions"
  %l97 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca i32
  %l105 = alloca i1
  %l109 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca i32
  %l114 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i32
  %l120 = alloca i1
  %l123 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca i32
  %l131 = alloca i1
  %l135 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i32
  %l140 = alloca i1
  %l143 = alloca i64
  %l144 = alloca i32
  %l146 = alloca i1
  %l152 = alloca i64
  %l155 = alloca %"compiler/diag:Diagnostics"
  %l158 = alloca i1
  %l159 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l165 = alloca i32
  %l166 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l172 = alloca i1
  %l173 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l177 = alloca %"std/prelude/text:StringBuilder"
  %l187 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l195 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l207 = alloca i1
  %l210 = alloca ptr
  %l213 = alloca ptr
  %l220 = alloca ptr
  %l222 = alloca i1
  %l225 = alloca { i64, ptr }
  %l227 = alloca i64
  %l230 = alloca i1
  %l235 = alloca ptr
  %l240 = alloca ptr
  %l242 = alloca { i64, ptr }
  %l244 = alloca %"std/prelude/text:StringBuilder"
  %l245 = alloca ptr
  %l246 = alloca ptr
  %l251 = alloca ptr
  %l257 = alloca ptr
  %l258 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l264 = alloca %"compiler/session:Found"
  %l267 = alloca { i64, ptr }
  %l270 = alloca %"compiler/session:Found"
  %l271 = alloca i32
  %l273 = alloca i1
  %l274 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l279 = alloca i1
  %l280 = alloca %"std/prelude/text:StringBuilder"
  %l285 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l293 = alloca i1
  %l294 = alloca i1
  %l297 = alloca ptr
  %l299 = alloca { i64, ptr }
  %l304 = alloca { i64, ptr }
  %l309 = alloca %"compiler/session:Positions"
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca %"std/prelude/text:StringBuilder"
  %l315 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l328 = alloca ptr
  %l329 = alloca { i64, ptr }
  %l331 = alloca { i64, ptr }
  %l333 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t284 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v1, ptr %s0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l30
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l29
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l29, !tbaa !29
  store ptr %t8, ptr %l27, !tbaa !29
  br label %bb6
bb2:
  %t9 = load i32, ptr %l30, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l32, !tbaa !21
  %t13 = load i32, ptr %l30, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t18 = load ptr, ptr %l27, !tbaa !29
  store ptr %t18, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call { i64, ptr } @compiler_2flsp_2eidOf(ptr %s0, ptr %s0, ptr %t19)
  store { i64, ptr } %t21, ptr %l36
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s0, ptr %s0, ptr %t23, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l38
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t31 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t27, { i64, ptr } %t28)
  %t32 = extractvalue { i32, ptr } %t31, 1
  %t33 = extractvalue { i32, ptr } %t31, 0
  store i32 %t33, ptr %l44
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35, !prof !99
ok.35:
  store ptr %t32, ptr %l43
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l43, !tbaa !29
  store ptr %t36, ptr %l39, !tbaa !29
  br label %bb16
bb10:
  %t37 = load i32, ptr %l44, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  store i1 %t40, ptr %l46, !tbaa !21
  %t41 = load i32, ptr %l44, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  br i1 %t44, label %bb11, label %bb12
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l49, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t47, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store { i64, ptr } %t49, ptr %l51
  br label %bb14
bb14:
  %t50 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t51 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } %t50)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t53 = load ptr, ptr %l39, !tbaa !29
  store ptr %t53, ptr %l5, !tbaa !29
  %t54 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l55, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t58 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t54, { i64, ptr } %t55)
  %t59 = extractvalue { i32, ptr } %t58, 1
  %t60 = extractvalue { i32, ptr } %t58, 0
  store i32 %t60, ptr %l58
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb18, label %ok.62, !prof !99
ok.62:
  store ptr %t59, ptr %l57
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l57, !tbaa !29
  store ptr %t63, ptr %l53, !tbaa !29
  br label %bb22
bb18:
  %t64 = load i32, ptr %l58, !tbaa !23
  %t65 = ashr i32 %t64, 16
  %t67 = icmp eq i32 %t65, 1
  store i1 %t67, ptr %l60, !tbaa !21
  %t68 = load i32, ptr %l58, !tbaa !23
  %t69 = ashr i32 %t68, 16
  %t71 = icmp eq i32 %t69, 1
  br i1 %t71, label %bb19, label %bb20
bb19:
  call void @__olang_errpay_pop()
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t73 = load ptr, ptr %l53, !tbaa !29
  %t74 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s0, ptr %s0, ptr %t73, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store { i64, ptr } %t74, ptr %l63
  br label %bb23
bb23:
  %t75 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t75, ptr %l6, !tbaa !27
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lsp:worker", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  store ptr %t79, ptr %l65, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = load ptr, ptr %l65, !tbaa !29
  %t82 = call ptr @__olang_scope_or(ptr %v2, ptr %t81)
  %t83 = call ptr @__olang_scope_hold(ptr %t82)
  %t84 = ptrtoint ptr %t83 to i64
  %t86 = inttoptr i64 %t84 to ptr
  %t87 = load ptr, ptr %l65, !tbaa !29
  %t89 = call i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %t86, ptr %s0, ptr %t87, { i64, ptr } %t80)
  store i64 %t89, ptr %l68
  br label %bb24
bb24:
  %t90 = load i64, ptr %l68, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t93 = icmp slt i64 %t91, 0
  br i1 %t93, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l71, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t98 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s4, ptr %s4, { i64, ptr } %t96, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store { i64, ptr } %t98, ptr %l73
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t99 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t100 = load ptr, ptr %l71, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s4, ptr %t100, { i64, ptr } %t99)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lsp:worker", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/lsp:Server", ptr %t105, i32 0, i32 1
  store ptr %t107, ptr %l77, !tbaa !29
  %t108 = load i64, ptr %l7, !tbaa !24
  %t109 = load ptr, ptr %l77, !tbaa !29
  %t110 = call ptr @__olang_scope_or(ptr %v2, ptr %t109)
  %t111 = call ptr @__olang_scope_hold(ptr %t110)
  %t112 = ptrtoint ptr %t111 to i64
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/lsp:worker", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = call ptr @__olang_scope_or(ptr %v2, ptr %t116)
  %t119 = call ptr @__olang_scope_hold(ptr %t118)
  %t120 = ptrtoint ptr %t119 to i64
  %t122 = inttoptr i64 %t112 to ptr
  %t124 = inttoptr i64 %t120 to ptr
  %t125 = load ptr, ptr %l77, !tbaa !29
  %t127 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %t122, ptr %t124, ptr %t125, i64 %t108)
  store ptr %t127, ptr %l83
  br label %bb30
bb30:
  %t128 = load ptr, ptr %l83, !tbaa !29
  store ptr %t128, ptr %l8, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/lsp:worker", ptr %t129, i32 0, i32 4
  %t132 = load ptr, ptr %l8, !tbaa !29
  %t134 = getelementptr %"compiler/lsp:Doc", ptr %t132, i32 0, i32 2
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l88, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = call ptr @__olang_scope_or(ptr %v2, ptr %t137)
  %t139 = call ptr @__olang_scope_hold(ptr %t138)
  %t140 = ptrtoint ptr %t139 to i64
  %t142 = inttoptr i64 %t140 to ptr
  %t144 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t145 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %t142, ptr %v0, ptr %t131, { i64, ptr } %t144)
  %t146 = extractvalue { i32, { i64, ptr } } %t145, 1
  %t147 = extractvalue { i32, { i64, ptr } } %t145, 0
  store i32 %t147, ptr %l91
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb32, label %ok.149, !prof !99
ok.149:
  store { i64, ptr } %t146, ptr %l90
  br label %bb31
bb31:
  %t150 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t150, ptr %l84, !tbaa !27
  br label %bb34
bb32:
  br label %bb33
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l84, !tbaa !27
  br label %bb34
bb34:
  %t151 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/lsp:worker", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/lsp:Server", ptr %t156, i32 0, i32 2
  %t159 = load i1, ptr %t158, !tbaa !21
  %t162 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %s0, { i64, ptr } %t152, i1 %t159)
  store %"compiler/session:Positions" %t162, ptr %l96
  br label %bb35
bb35:
  %t163 = load %"compiler/session:Positions", ptr %l96
  store %"compiler/session:Positions" %t163, ptr %l10
  %t164 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t169 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t164, { i64, ptr } %t166)
  %t170 = extractvalue { i32, ptr } %t169, 1
  %t171 = extractvalue { i32, ptr } %t169, 0
  store i32 %t171, ptr %l103
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb37, label %ok.173, !prof !99
ok.173:
  store ptr %t170, ptr %l102
  br label %bb36
bb36:
  %t174 = load ptr, ptr %l102, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l109, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t178 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t174, { i64, ptr } %t175)
  %t179 = extractvalue { i32, ptr } %t178, 1
  %t180 = extractvalue { i32, ptr } %t178, 0
  store i32 %t180, ptr %l112
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb42, label %ok.182, !prof !99
ok.182:
  store ptr %t179, ptr %l111
  br label %bb41
bb37:
  %t183 = load i32, ptr %l103, !tbaa !23
  %t184 = ashr i32 %t183, 16
  %t186 = icmp eq i32 %t184, 1
  store i1 %t186, ptr %l105, !tbaa !21
  %t187 = load i32, ptr %l103, !tbaa !23
  %t188 = ashr i32 %t187, 16
  %t190 = icmp eq i32 %t188, 1
  br i1 %t190, label %bb38, label %bb39
bb38:
  call void @__olang_errpay_pop()
  br label %bb39
bb39:
  br label %bb40
bb40:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb49
bb41:
  %t192 = load ptr, ptr %l111, !tbaa !29
  %t193 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t192)
  %t194 = extractvalue { i32, i64 } %t193, 1
  %t195 = extractvalue { i32, i64 } %t193, 0
  store i32 %t195, ptr %l118
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb46, label %ok.197, !prof !99
ok.197:
  store i64 %t194, ptr %l117
  br label %bb45
bb42:
  %t198 = load i32, ptr %l112, !tbaa !23
  %t199 = ashr i32 %t198, 16
  %t201 = icmp eq i32 %t199, 1
  store i1 %t201, ptr %l114, !tbaa !21
  %t202 = load i32, ptr %l112, !tbaa !23
  %t203 = ashr i32 %t202, 16
  %t205 = icmp eq i32 %t203, 1
  br i1 %t205, label %bb43, label %bb44
bb43:
  call void @__olang_errpay_pop()
  br label %bb44
bb44:
  br label %bb40
bb45:
  %t207 = load i64, ptr %l117, !tbaa !24
  store i64 %t207, ptr %l97, !tbaa !24
  br label %bb49
bb46:
  %t208 = load i32, ptr %l118, !tbaa !23
  %t209 = ashr i32 %t208, 16
  %t211 = icmp eq i32 %t209, 1
  store i1 %t211, ptr %l120, !tbaa !21
  %t212 = load i32, ptr %l118, !tbaa !23
  %t213 = ashr i32 %t212, 16
  %t215 = icmp eq i32 %t213, 1
  br i1 %t215, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb40
bb49:
  %t217 = load i64, ptr %l97, !tbaa !24
  store i64 %t217, ptr %l11, !tbaa !24
  %t218 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %l126, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t223 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t218, { i64, ptr } %t220)
  %t224 = extractvalue { i32, ptr } %t223, 1
  %t225 = extractvalue { i32, ptr } %t223, 0
  store i32 %t225, ptr %l129
  %t226 = icmp ne i32 %t225, 0
  br i1 %t226, label %bb51, label %ok.227, !prof !99
ok.227:
  store ptr %t224, ptr %l128
  br label %bb50
bb50:
  %t228 = load ptr, ptr %l128, !tbaa !29
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l135, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t232 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t228, { i64, ptr } %t229)
  %t233 = extractvalue { i32, ptr } %t232, 1
  %t234 = extractvalue { i32, ptr } %t232, 0
  store i32 %t234, ptr %l138
  %t235 = icmp ne i32 %t234, 0
  br i1 %t235, label %bb56, label %ok.236, !prof !99
ok.236:
  store ptr %t233, ptr %l137
  br label %bb55
bb51:
  %t237 = load i32, ptr %l129, !tbaa !23
  %t238 = ashr i32 %t237, 16
  %t240 = icmp eq i32 %t238, 1
  store i1 %t240, ptr %l131, !tbaa !21
  %t241 = load i32, ptr %l129, !tbaa !23
  %t242 = ashr i32 %t241, 16
  %t244 = icmp eq i32 %t242, 1
  br i1 %t244, label %bb52, label %bb53
bb52:
  call void @__olang_errpay_pop()
  br label %bb53
bb53:
  br label %bb54
bb54:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb63
bb55:
  %t246 = load ptr, ptr %l137, !tbaa !29
  %t247 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t246)
  %t248 = extractvalue { i32, i64 } %t247, 1
  %t249 = extractvalue { i32, i64 } %t247, 0
  store i32 %t249, ptr %l144
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb60, label %ok.251, !prof !99
ok.251:
  store i64 %t248, ptr %l143
  br label %bb59
bb56:
  %t252 = load i32, ptr %l138, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  store i1 %t255, ptr %l140, !tbaa !21
  %t256 = load i32, ptr %l138, !tbaa !23
  %t257 = ashr i32 %t256, 16
  %t259 = icmp eq i32 %t257, 1
  br i1 %t259, label %bb57, label %bb58
bb57:
  call void @__olang_errpay_pop()
  br label %bb58
bb58:
  br label %bb54
bb59:
  %t261 = load i64, ptr %l143, !tbaa !24
  store i64 %t261, ptr %l123, !tbaa !24
  br label %bb63
bb60:
  %t262 = load i32, ptr %l144, !tbaa !23
  %t263 = ashr i32 %t262, 16
  %t265 = icmp eq i32 %t263, 1
  store i1 %t265, ptr %l146, !tbaa !21
  %t266 = load i32, ptr %l144, !tbaa !23
  %t267 = ashr i32 %t266, 16
  %t269 = icmp eq i32 %t267, 1
  br i1 %t269, label %bb61, label %bb62
bb61:
  call void @__olang_errpay_pop()
  br label %bb62
bb62:
  br label %bb54
bb63:
  %t271 = load i64, ptr %l123, !tbaa !24
  %t272 = load i64, ptr %l11, !tbaa !24
  %t277 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eOffset(ptr %s0, ptr %l10, i64 %t272, i64 %t271)
  store i64 %t277, ptr %l152
  br label %bb64
bb64:
  %t278 = load i64, ptr %l152, !tbaa !24
  store i64 %t278, ptr %l13, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/lsp:worker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  store ptr %t282, ptr %l14, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t284, ptr %v0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l155, ptr %t284, i64 704, i1 false)
  br label %bb65
bb65:
  %t285 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 704, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t285, ptr %l155, i64 704, i1 false)
  store ptr %t285, ptr %l15, !tbaa !29
  %t287 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t289 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t287, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t289, ptr %l158
  br label %bb66
bb66:
  %t290 = load i1, ptr %l158, !tbaa !21
  br i1 %t290, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s5
  %t291 = load ptr, ptr %l8, !tbaa !29
  %t293 = getelementptr %"compiler/lsp:Doc", ptr %t291, i32 0, i32 1
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  store { i64, ptr } %t294, ptr %l161, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 1
  %t298 = call ptr @__olang_scope_or(ptr %v2, ptr %t297)
  %t299 = call ptr @__olang_scope_hold(ptr %t298)
  %t300 = ptrtoint ptr %t299 to i64
  %t302 = inttoptr i64 %t300 to ptr
  %t303 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t305 = call { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %t302, ptr %v0, ptr %s5, { i64, ptr } %t303, { i64, ptr } %t295)
  %t306 = extractvalue { i32, { i64, ptr } } %t305, 1
  %t307 = extractvalue { i32, { i64, ptr } } %t305, 0
  store i32 %t307, ptr %l165
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb70, label %ok.309, !prof !99
ok.309:
  store { i64, ptr } %t306, ptr %l164
  br label %bb69
bb68:
  br label %bb90
bb69:
  %t310 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t310, ptr %l159, !tbaa !27
  br label %bb74
bb70:
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s6
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l166, !tbaa !29
  %t312 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t314 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s6, ptr %s6, { i64, ptr } %t312, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store { i64, ptr } %t314, ptr %l168
  br label %bb72
bb72:
  %t315 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t316 = load ptr, ptr %l166, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s6, ptr %t316, { i64, ptr } %t315)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb74:
  %t318 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t318, ptr %l16, !tbaa !27
  %t319 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t323 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %v0, { i64, ptr } %t319, { i64, ptr } %t320)
  store i1 %t323, ptr %l172
  br label %bb75
bb75:
  %t324 = load i1, ptr %l172, !tbaa !21
  br i1 %t324, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s7
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l173, !tbaa !29
  %t326 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t328 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s7, ptr %s7, { i64, ptr } %t326, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store { i64, ptr } %t328, ptr %l175
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t329 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t330 = load ptr, ptr %l173, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s7, ptr %t330, { i64, ptr } %t329)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb80:
  %t332 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s5)
  store %"std/prelude/text:StringBuilder" %t332, ptr %l177
  br label %bb81
bb81:
  %t333 = load %"std/prelude/text:StringBuilder", ptr %l177
  store %"std/prelude/text:StringBuilder" %t333, ptr %l17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %l17, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb82
bb82:
  %t335 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %s0, ptr %s5, ptr %l10, ptr %l17, i64 0, i64 %t337)
  br label %bb83
bb83:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %l17, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb84
bb84:
  %t342 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s5, ptr %s5, ptr %l17, { i64, ptr } %t342)
  br label %bb85
bb85:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %l17, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d100, i32 0, i32 1) })
  br label %bb86
bb86:
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l187, !tbaa !29
  %t347 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t347, ptr %l188, !tbaa !27
  %t349 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s5, ptr %s5, ptr %l17)
  store { i64, ptr } %t349, ptr %l190
  br label %bb87
bb87:
  %t350 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t353 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s5, ptr %s5, { i64, ptr } %t351, { i64, ptr } %t350)
  store { i64, ptr } %t353, ptr %l192
  br label %bb88
bb88:
  %t354 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t355 = load ptr, ptr %l187, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s5, ptr %t355, { i64, ptr } %t354)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb90:
  %t357 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t359 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t357, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t359, ptr %l195
  br label %bb91
bb91:
  %t360 = load i1, ptr %l195, !tbaa !21
  br i1 %t360, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s8
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l196, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t362, ptr %l197, !tbaa !27
  %t363 = load ptr, ptr %l5, !tbaa !29
  %t364 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t365 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t370 = call { i64, ptr } @compiler_2flsp_2ecodeActions(ptr %s0, ptr %s0, ptr %v0, ptr %s0, ptr %s8, ptr %t363, { i64, ptr } %t364, { i64, ptr } %t365, ptr %l10)
  store { i64, ptr } %t370, ptr %l202
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t371 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t374 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s8, ptr %s8, { i64, ptr } %t372, { i64, ptr } %t371)
  store { i64, ptr } %t374, ptr %l204
  br label %bb95
bb95:
  %t375 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t376 = load ptr, ptr %l196, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s8, ptr %t376, { i64, ptr } %t375)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb97:
  %t378 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t380 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t378, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t380, ptr %l207
  br label %bb98
bb98:
  %t381 = load i1, ptr %l207, !tbaa !21
  br i1 %t381, label %bb99, label %bb100
bb99:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t384 = load ptr, ptr %l8, !tbaa !29
  store ptr %t384, ptr %l210, !tbaa !29
  %t385 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t386 = load i64, ptr %l13, !tbaa !24
  %t387 = load ptr, ptr %l14, !tbaa !29
  store ptr %t387, ptr %l213, !tbaa !29
  %t388 = load ptr, ptr %l15, !tbaa !29
  %t389 = load ptr, ptr %l210, !tbaa !29
  %t390 = call ptr @__olang_scope_or(ptr %v2, ptr %t389)
  %t391 = call ptr @__olang_scope_hold(ptr %t390)
  %t392 = ptrtoint ptr %t391 to i64
  %t393 = load ptr, ptr %l213, !tbaa !29
  %t394 = call ptr @__olang_scope_or(ptr %v3, ptr %t393)
  %t395 = call ptr @__olang_scope_hold(ptr %t394)
  %t396 = ptrtoint ptr %t395 to i64
  %t398 = inttoptr i64 %t392 to ptr
  %t400 = inttoptr i64 %t396 to ptr
  %t403 = load ptr, ptr %l210, !tbaa !29
  %t406 = load ptr, ptr %l213, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2ecomplete(ptr %v0, ptr %s0, ptr %t398, ptr %v0, ptr %t400, ptr %v0, ptr %t382, { i64, ptr } %t383, ptr %t403, { i64, ptr } %t385, i64 %t386, ptr %t406, ptr %t388)
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb102:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load i64, ptr %l7, !tbaa !24
  %t410 = load ptr, ptr %l15, !tbaa !29
  %t414 = call ptr @compiler_2flsp_2ecompiler_2flsp_3aworker_2eanalysis(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t408, i64 %t409, ptr %t410)
  store ptr %t414, ptr %l220
  br label %bb103
bb103:
  %t415 = load ptr, ptr %l220, !tbaa !29
  store ptr %t415, ptr %l18, !tbaa !29
  %t416 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t418 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t416, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t418, ptr %l222
  br label %bb104
bb104:
  %t419 = load i1, ptr %l222, !tbaa !21
  br i1 %t419, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s10
  %t420 = load ptr, ptr %l18, !tbaa !29
  %t421 = load ptr, ptr %l8, !tbaa !29
  %t423 = getelementptr %"compiler/lsp:Doc", ptr %t421, i32 0, i32 2
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !27
  store { i64, ptr } %t424, ptr %l225, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t425, 1
  %t427 = call ptr @__olang_scope_or(ptr %v2, ptr %t426)
  %t428 = call ptr @__olang_scope_hold(ptr %t427)
  %t429 = ptrtoint ptr %t428 to i64
  %t431 = inttoptr i64 %t429 to ptr
  %t433 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t434 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %t431, ptr %t420, { i64, ptr } %t433)
  store i64 %t434, ptr %l227
  br label %bb107
bb106:
  br label %bb123
bb107:
  %t435 = load i64, ptr %l227, !tbaa !24
  store i64 %t435, ptr %l19, !tbaa !24
  %t436 = load i64, ptr %l19, !tbaa !24
  %t438 = icmp slt i64 %t436, 0
  br i1 %t438, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l230, !tbaa !21
  br label %bb111
bb109:
  %t440 = load ptr, ptr %l18, !tbaa !29
  %t442 = getelementptr %"compiler/session:Analysis", ptr %t440, i32 0, i32 0
  %t443 = load ptr, ptr %t442, !tbaa !29
  %t445 = getelementptr %"compiler/load:Loader", ptr %t443, i32 0, i32 10
  %t446 = load i64, ptr %l19, !tbaa !24
  %t449 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t445, i64 %t446)
  store ptr %t449, ptr %l235
  br label %bb110
bb110:
  %t450 = load ptr, ptr %l235, !tbaa !29
  %t452 = getelementptr %"compiler/load:Module", ptr %t450, i32 0, i32 8
  %t453 = load { i64, ptr }, ptr %t452, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t453, 0
  %t457 = icmp eq i64 %t455, 0
  store i1 %t457, ptr %l230, !tbaa !21
  br label %bb111
bb111:
  %t459 = load i1, ptr %l230, !tbaa !21
  br i1 %t459, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s11
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l240, !tbaa !29
  %t461 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t463 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s11, ptr %s11, { i64, ptr } %t461, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store { i64, ptr } %t463, ptr %l242
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t464 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t465 = load ptr, ptr %l240, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s11, ptr %t465, { i64, ptr } %t464)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb116:
  %t467 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s10)
  store %"std/prelude/text:StringBuilder" %t467, ptr %l244
  br label %bb117
bb117:
  %t468 = load %"std/prelude/text:StringBuilder", ptr %l244
  store %"std/prelude/text:StringBuilder" %t468, ptr %l20
  store ptr %l20, ptr %l245, !tbaa !29
  store ptr %l10, ptr %l246, !tbaa !29
  %t469 = load ptr, ptr %l18, !tbaa !29
  %t471 = getelementptr %"compiler/session:Analysis", ptr %t469, i32 0, i32 0
  %t472 = load ptr, ptr %t471, !tbaa !29
  %t474 = getelementptr %"compiler/load:Loader", ptr %t472, i32 0, i32 10
  %t475 = load i64, ptr %l19, !tbaa !24
  %t478 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t474, i64 %t475)
  store ptr %t478, ptr %l251
  br label %bb118
bb118:
  %t479 = load ptr, ptr %l251, !tbaa !29
  %t481 = getelementptr %"compiler/load:Module", ptr %t479, i32 0, i32 8
  %t482 = load { i64, ptr }, ptr %t481, !tbaa !27
  %t483 = load ptr, ptr %l18, !tbaa !29
  %t485 = getelementptr %"compiler/session:Analysis", ptr %t483, i32 0, i32 0
  %t486 = load ptr, ptr %t485, !tbaa !29
  %t488 = getelementptr %"compiler/load:Loader", ptr %t486, i32 0, i32 3
  %t489 = load ptr, ptr %t488, !tbaa !29
  %t490 = load ptr, ptr %l245, !tbaa !29
  %t491 = load ptr, ptr %l246, !tbaa !29
  call void @compiler_2fsession_2eSymbols(ptr %s10, ptr %s0, ptr %v0, ptr %v0, ptr %t490, ptr %t491, { i64, ptr } %t482, ptr %t489)
  br label %bb119
bb119:
  %t494 = load ptr, ptr %l0, !tbaa !29
  store ptr %t494, ptr %l257, !tbaa !29
  %t495 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t495, ptr %l258, !tbaa !27
  %t497 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s10, ptr %s10, ptr %l20)
  store { i64, ptr } %t497, ptr %l260
  br label %bb120
bb120:
  %t498 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t499 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t501 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s10, ptr %s10, { i64, ptr } %t499, { i64, ptr } %t498)
  store { i64, ptr } %t501, ptr %l262
  br label %bb121
bb121:
  %t502 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t503 = load ptr, ptr %l257, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s10, ptr %t503, { i64, ptr } %t502)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb123:
  %t505 = load ptr, ptr %l18, !tbaa !29
  %t506 = load ptr, ptr %l8, !tbaa !29
  %t508 = getelementptr %"compiler/lsp:Doc", ptr %t506, i32 0, i32 2
  %t509 = load { i64, ptr }, ptr %t508, !tbaa !27
  store { i64, ptr } %t509, ptr %l267, !tbaa !27
  %t510 = load i64, ptr %l13, !tbaa !24
  %t511 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t511, 1
  %t513 = call ptr @__olang_scope_or(ptr %v2, ptr %t512)
  %t514 = call ptr @__olang_scope_hold(ptr %t513)
  %t515 = ptrtoint ptr %t514 to i64
  %t517 = inttoptr i64 %t515 to ptr
  %t519 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t521 = call { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eLookup(ptr %v0, ptr %t517, ptr %s0, ptr %t505, { i64, ptr } %t519, i64 %t510)
  %t522 = extractvalue { i32, %"compiler/session:Found" } %t521, 1
  %t523 = extractvalue { i32, %"compiler/session:Found" } %t521, 0
  store i32 %t523, ptr %l271
  %t524 = icmp ne i32 %t523, 0
  br i1 %t524, label %bb125, label %ok.525, !prof !99
ok.525:
  store %"compiler/session:Found" %t522, ptr %l270
  br label %bb124
bb124:
  %t526 = load %"compiler/session:Found", ptr %l270
  store %"compiler/session:Found" %t526, ptr %l264
  br label %bb129
bb125:
  %t527 = load i32, ptr %l271, !tbaa !23
  %t528 = ashr i32 %t527, 16
  %t530 = icmp eq i32 %t528, 1
  store i1 %t530, ptr %l273, !tbaa !21
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s12
  %t531 = load ptr, ptr %l0, !tbaa !29
  store ptr %t531, ptr %l274, !tbaa !29
  %t532 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t534 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s12, ptr %s12, { i64, ptr } %t532, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store { i64, ptr } %t534, ptr %l276
  br label %bb127
bb127:
  %t535 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t536 = load ptr, ptr %l274, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s12, ptr %t536, { i64, ptr } %t535)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb129:
  %t538 = load %"compiler/session:Found", ptr %l264
  store %"compiler/session:Found" %t538, ptr %l21
  %t539 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t541 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t539, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d106, i32 0, i32 1) })
  store i1 %t541, ptr %l279
  br label %bb130
bb130:
  %t542 = load i1, ptr %l279, !tbaa !21
  br i1 %t542, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s13
  %t543 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s13)
  store %"std/prelude/text:StringBuilder" %t543, ptr %l280
  br label %bb133
bb132:
  br label %bb140
bb133:
  %t544 = load %"std/prelude/text:StringBuilder", ptr %l280
  store %"std/prelude/text:StringBuilder" %t544, ptr %l22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l22, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb134
bb134:
  %t546 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 0
  %t547 = load { i64, ptr }, ptr %t546, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s13, ptr %s0, ptr %l22, { i64, ptr } %t547)
  br label %bb135
bb135:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s13, ptr %s13, ptr %l22, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb136
bb136:
  %t551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t551, ptr %l285, !tbaa !29
  %t552 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t552, ptr %l286, !tbaa !27
  %t554 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s13, ptr %s13, ptr %l22)
  store { i64, ptr } %t554, ptr %l288
  br label %bb137
bb137:
  %t555 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t556 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t558 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s13, ptr %s13, { i64, ptr } %t556, { i64, ptr } %t555)
  store { i64, ptr } %t558, ptr %l290
  br label %bb138
bb138:
  %t559 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t560 = load ptr, ptr %l285, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s13, ptr %t560, { i64, ptr } %t559)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb140:
  %t562 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 1
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  %t565 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t563, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) })
  store i1 %t565, ptr %l293
  br label %bb141
bb141:
  %t566 = load i1, ptr %l293, !tbaa !21
  br i1 %t566, label %bb142, label %bb143
bb142:
  store i1 true, ptr %l294, !tbaa !21
  br label %bb144
bb143:
  %t567 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 2
  %t568 = load i64, ptr %t567, !tbaa !24
  %t570 = icmp slt i64 %t568, 0
  store i1 %t570, ptr %l294, !tbaa !21
  br label %bb144
bb144:
  %t572 = load i1, ptr %l294, !tbaa !21
  br i1 %t572, label %bb145, label %bb146
bb145:
  store %olang.scope zeroinitializer, ptr %s14
  %t573 = load ptr, ptr %l0, !tbaa !29
  store ptr %t573, ptr %l297, !tbaa !29
  %t574 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t576 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s14, ptr %s14, { i64, ptr } %t574, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store { i64, ptr } %t576, ptr %l299
  br label %bb147
bb146:
  br label %bb149
bb147:
  %t577 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t578 = load ptr, ptr %l297, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s14, ptr %t578, { i64, ptr } %t577)
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb149:
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t581 = load ptr, ptr %l18, !tbaa !29
  %t582 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 1
  %t583 = load { i64, ptr }, ptr %t582, !tbaa !27
  %t587 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t580, ptr %t581, { i64, ptr } %t583)
  store { i64, ptr } %t587, ptr %l304
  br label %bb150
bb150:
  %t588 = load { i64, ptr }, ptr %l304, !tbaa !27
  store { i64, ptr } %t588, ptr %l23, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/lsp:worker", ptr %t590, i32 0, i32 0
  %t593 = load ptr, ptr %t592, !tbaa !29
  %t595 = getelementptr %"compiler/lsp:Server", ptr %t593, i32 0, i32 2
  %t596 = load i1, ptr %t595, !tbaa !21
  %t599 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %s0, ptr %s0, { i64, ptr } %t589, i1 %t596)
  store %"compiler/session:Positions" %t599, ptr %l309
  br label %bb151
bb151:
  %t600 = load %"compiler/session:Positions", ptr %l309
  store %"compiler/session:Positions" %t600, ptr %l24
  %t601 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t602 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 2
  %t603 = load i64, ptr %t602, !tbaa !24
  %t606 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %s0, { i64, ptr } %t601, i64 %t603)
  store %"compiler/source:Span" %t606, ptr %l312
  br label %bb152
bb152:
  %t607 = load %"compiler/source:Span", ptr %l312
  store %"compiler/source:Span" %t607, ptr %l25
  %t608 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t608, ptr %l313
  br label %bb153
bb153:
  %t609 = load %"std/prelude/text:StringBuilder", ptr %l313
  store %"std/prelude/text:StringBuilder" %t609, ptr %l26
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb154
bb154:
  store ptr %l26, ptr %l315, !tbaa !29
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 1
  %t613 = load { i64, ptr }, ptr %t612, !tbaa !27
  %t616 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2euriOf(ptr %v0, ptr %s0, ptr %s0, ptr %v2, ptr %t611, { i64, ptr } %t613)
  store { i64, ptr } %t616, ptr %l318
  br label %bb155
bb155:
  %t617 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t618 = load ptr, ptr %l315, !tbaa !29
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s0, ptr %t618, { i64, ptr } %t617)
  br label %bb156
bb156:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb157
bb157:
  %t621 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t622 = load i32, ptr %t621, !tbaa !23
  %t624 = sext i32 %t622 to i64
  %t625 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 1
  %t626 = load i32, ptr %t625, !tbaa !23
  %t628 = sext i32 %t626 to i64
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %s0, ptr %s0, ptr %l24, ptr %l26, i64 %t624, i64 %t628)
  br label %bb158
bb158:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l26, i8 125)
  br label %bb159
bb159:
  %t634 = load ptr, ptr %l0, !tbaa !29
  store ptr %t634, ptr %l328, !tbaa !29
  %t635 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t635, ptr %l329, !tbaa !27
  %t637 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l26)
  store { i64, ptr } %t637, ptr %l331
  br label %bb160
bb160:
  %t638 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t639 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t641 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t639, { i64, ptr } %t638)
  store { i64, ptr } %t641, ptr %l333
  br label %bb161
bb161:
  %t642 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t643 = load ptr, ptr %l328, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s0, ptr %t643, { i64, ptr } %t642)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2echeck(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca %"compiler/diag:Diagnostics"
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l56 = alloca ptr
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca i64
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/text:StringBuilder"
  %l93 = alloca i64
  %l95 = alloca i64
  %l100 = alloca ptr
  %l103 = alloca ptr
  %l105 = alloca i64
  %l109 = alloca i64
  %l112 = alloca i64
  %l133 = alloca i1
  %l136 = alloca ptr
  %l142 = alloca ptr
  %l145 = alloca i1
  %l148 = alloca ptr
  %l154 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l160 = alloca i1
  %l176 = alloca i64
  %l180 = alloca i64
  %l183 = alloca i64
  %l204 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l212 = alloca ptr
  %l214 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t33 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:worker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 1
  store ptr %t6, ptr %l27, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = load ptr, ptr %l27, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lsp:worker", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v1, ptr %t15)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t11 to ptr
  %t23 = inttoptr i64 %t19 to ptr
  %t24 = load ptr, ptr %l27, !tbaa !29
  %t26 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %t21, ptr %t23, ptr %t24, i64 %t7)
  store ptr %t26, ptr %l33
  br label %bb1
bb1:
  %t27 = load ptr, ptr %l33, !tbaa !29
  store ptr %t27, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lsp:worker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l3, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t33, ptr %v0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t33, i64 704, i1 false)
  br label %bb2
bb2:
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 704, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %l36, i64 704, i1 false)
  store ptr %t34, ptr %l4, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/lsp:Doc", ptr %t36, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l39, !tbaa !27
  %t40 = load ptr, ptr %l3, !tbaa !29
  store ptr %t40, ptr %l40, !tbaa !29
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lsp:worker", ptr %t42, i32 0, i32 4
  %t45 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = call ptr @__olang_scope_or(ptr %v1, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t50 = load ptr, ptr %l40, !tbaa !29
  %t51 = call ptr @__olang_scope_or(ptr %v2, ptr %t50)
  %t52 = call ptr @__olang_scope_hold(ptr %t51)
  %t53 = ptrtoint ptr %t52 to i64
  %t55 = inttoptr i64 %t49 to ptr
  %t57 = inttoptr i64 %t53 to ptr
  %t58 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t59 = load ptr, ptr %l40, !tbaa !29
  %t62 = call ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %t55, ptr %t57, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t58, ptr %t59, ptr %t41, ptr %t44, i1 false, i1 true)
  store ptr %t62, ptr %l46
  br label %bb3
bb3:
  %t63 = load ptr, ptr %l46, !tbaa !29
  store ptr %t63, ptr %l5, !tbaa !29
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l48
  br label %bb4
bb4:
  %t67 = load i64, ptr %l48, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  %t68 = call ptr @__olang_scope_hold(ptr %s0)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l49, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2echeck_2elocal_2e7
  br i1 %t70, label %bb5, label %bb6
bb5:
  %t72 = call ptr @__olang_region_make(ptr %s0)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l49, !tbaa !24
  br label %bb6
bb6:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t76 = load ptr, ptr %l5, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = getelementptr %"compiler/lsp:Doc", ptr %t78, i32 0, i32 6
  store ptr %t80, ptr %l56, !tbaa !29
  %t81 = load ptr, ptr %l56, !tbaa !29
  %t82 = call ptr @__olang_scope_or(ptr %v1, ptr %t81)
  %t83 = call ptr @__olang_scope_hold(ptr %t82)
  %t84 = ptrtoint ptr %t83 to i64
  %t86 = inttoptr i64 %t84 to ptr
  %t87 = load i64, ptr %l49
  %t88 = inttoptr i64 %t87 to ptr
  %t93 = load ptr, ptr %l56, !tbaa !29
  %t94 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flsp_2ecompiler_2flsp_3aworker_2epublishAll(ptr %v0, ptr %v0, ptr %v0, ptr %t86, ptr %t88, ptr %v1, ptr %t74, i64 %t75, ptr %t76, ptr %t77, ptr %t93)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l58
  br label %bb7
bb7:
  %t95 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2echeck_2elocal_2e7
  br i1 %t95, label %bb8, label %bb9
bb8:
  %t97 = load i64, ptr %l49
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58, i32 0, i32 0
  %t100 = load { i64, ptr }, ptr %t99
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = call ptr @__olang_region_or(ptr %t101, ptr null)
  %t103 = call ptr @__olang_region_home(ptr %t102)
  %t104 = icmp ne ptr %t103, null
  %t105 = select i1 %t104, ptr %t103, ptr null
  call void @__olang_region_settle_in(ptr %t98, ptr %t105)
  br label %bb9
bb9:
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l7
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t108 = load ptr, ptr %l3, !tbaa !29
  store ptr %t108, ptr %l61, !tbaa !29
  %t109 = load ptr, ptr %l61, !tbaa !29
  %t110 = call ptr @__olang_scope_or(ptr %v2, ptr %t109)
  %t111 = call ptr @__olang_scope_hold(ptr %t110)
  %t112 = ptrtoint ptr %t111 to i64
  %t114 = inttoptr i64 %t112 to ptr
  %t116 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2fsession_2eHold(ptr %v0, ptr %t114, ptr %t107, ptr %t116)
  br label %bb10
bb10:
  %t117 = load ptr, ptr %l4, !tbaa !29
  %t119 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l64
  br label %bb11
bb11:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t121 = load i64, ptr %l64, !tbaa !24
  %t123 = icmp ne i64 %t121, %t120
  br i1 %t123, label %bb12, label %bb13
bb12:
  %t125 = call ptr @__olang_scope_hold(ptr %s0)
  %t126 = ptrtoint ptr %t125 to i64
  store i64 %t126, ptr %l67, !tbaa !24
  %t127 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2echeck_2elocal_2e7
  br i1 %t127, label %bb14, label %bb15
bb13:
  br label %bb23
bb14:
  %t129 = call ptr @__olang_region_make(ptr %s0)
  %t130 = ptrtoint ptr %t129 to i64
  store i64 %t130, ptr %l67, !tbaa !24
  br label %bb15
bb15:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l1, !tbaa !24
  %t133 = load ptr, ptr %l5, !tbaa !29
  %t134 = load ptr, ptr %l4, !tbaa !29
  %t135 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t137 = load i64, ptr %l67
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call ptr @__olang_scope_alloc_a(ptr %t138, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %t139
  %t140 = load i64, ptr %l67
  %t141 = inttoptr i64 %t140 to ptr
  %t142 = load i64, ptr %l67
  %t143 = inttoptr i64 %t142 to ptr
  %t149 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flsp_2ecompiler_2flsp_3aworker_2epublishAll(ptr %v0, ptr %v0, ptr %v0, ptr %t141, ptr %t143, ptr %v1, ptr %t131, i64 %t132, ptr %t133, ptr %t134, ptr %t139)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %l75
  br label %bb16
bb16:
  %t150 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2echeck_2elocal_2e7
  br i1 %t150, label %bb17, label %bb18
bb17:
  %t152 = load i64, ptr %l67
  %t153 = inttoptr i64 %t152 to ptr
  %t154 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = call ptr @__olang_region_or(ptr %t156, ptr null)
  %t158 = call ptr @__olang_region_home(ptr %t157)
  %t159 = icmp ne ptr %t158, null
  %t160 = select i1 %t159, ptr %t158, ptr null
  call void @__olang_region_settle_in(ptr %t153, ptr %t160)
  br label %bb18
bb18:
  %t161 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %l77
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l7
  %t163 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2echeck_2elocal_2e7
  br i1 %t163, label %bb19, label %bb20
bb19:
  %t165 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_region_or(ptr %t167, ptr null)
  %t169 = call ptr @__olang_region_home(ptr %t168)
  %t170 = icmp ne ptr %t169, null
  %t171 = select i1 %t170, ptr %t169, ptr null
  call void @__olang_region_drop(ptr %t171)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l77
  br label %bb20
bb20:
  %t172 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t172, label %bb21, label %bb22
bb21:
  %t174 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t177 = extractvalue { i64, ptr } %t175, 1
  call void @__olang_region_release_part(ptr %t177, i64 %t176)
  store { i64, ptr } zeroinitializer, ptr %t174
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l5, !tbaa !29
  %t183 = getelementptr %"compiler/lsp:worker", ptr %t178, i32 0, i32 5
  store ptr %t179, ptr %t183, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l1, !tbaa !24
  %t188 = getelementptr %"compiler/lsp:worker", ptr %t184, i32 0, i32 6
  store i64 %t185, ptr %t188, !tbaa !24
  %t189 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t189, ptr %l85
  br label %bb24
bb24:
  %t190 = load %"std/prelude/text:StringBuilder", ptr %l85
  store %"std/prelude/text:StringBuilder" %t190, ptr %l8
  %t191 = load i64, ptr %l1, !tbaa !24
  %t192 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t195 = call i64 @__olang_fmt_i64(ptr null, i64 %t191)
  %t196 = add i64 %t193, %t195
  %t197 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t192, i64 %t193)
  %t201 = getelementptr i8, ptr %t200, i64 %t193
  %t202 = call i64 @__olang_fmt_i64(ptr %t201, i64 %t191)
  %t203 = getelementptr i8, ptr %t201, i64 %t195
  call void @olang_textcopy(ptr %t203, ptr %t197, i64 %t198)
  %t204 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t200, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t205)
  br label %bb25
bb25:
  store i1 true, ptr %l9, !tbaa !21
  %t209 = load ptr, ptr %l5, !tbaa !29
  %t211 = getelementptr %"compiler/session:Analysis", ptr %t209, i32 0, i32 0
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/load:Loader", ptr %t212, i32 0, i32 10
  store ptr %t214, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  %t216 = load i64, ptr %l11, !tbaa !24
  store i64 %t216, ptr %l93, !tbaa !24
  %t217 = load ptr, ptr %l10, !tbaa !29
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t217)
  store i64 %t219, ptr %l95
  br label %bb27
bb27:
  %t220 = load i64, ptr %l93, !tbaa !24
  %t221 = load i64, ptr %l95, !tbaa !24
  %t222 = icmp slt i64 %t220, %t221
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb28, label %bb29
bb28:
  br label %bb63
bb29:
  br label %bb30
bb30:
  %t226 = load ptr, ptr %l10, !tbaa !29
  %t227 = load i64, ptr %l11, !tbaa !24
  %t230 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t226, i64 %t227)
  store ptr %t230, ptr %l100
  br label %bb31
bb31:
  %t231 = load ptr, ptr %l100, !tbaa !29
  store ptr %t231, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/lsp:worker", ptr %t232, i32 0, i32 0
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/lsp:Server", ptr %t235, i32 0, i32 1
  store ptr %t237, ptr %l103, !tbaa !29
  %t238 = load ptr, ptr %l103, !tbaa !29
  %t239 = call ptr @__olang_scope_or(ptr %v1, ptr %t238)
  %t240 = call ptr @__olang_scope_hold(ptr %t239)
  %t241 = ptrtoint ptr %t240 to i64
  %t243 = inttoptr i64 %t241 to ptr
  %t244 = load ptr, ptr %l103, !tbaa !29
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eLen_Ha7d56d00f5631ac8d39ace71211767ab(ptr %t243, ptr %t244)
  store i64 %t245, ptr %l105
  br label %bb32
bb32:
  %t246 = load i64, ptr %l105, !tbaa !24
  store i64 %t246, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t247 = load i64, ptr %l14, !tbaa !24
  %t248 = load i64, ptr %l13, !tbaa !24
  %t251 = icmp sgt i64 %t247, %t248
  br i1 %t251, label %bb33, label %bb34
bb33:
  %t253 = load i64, ptr %l15, !tbaa !24
  %t255 = icmp sgt i64 %t253, 0
  br i1 %t255, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb38
bb35:
  %t257 = load i64, ptr %l14, !tbaa !24
  %t258 = load i64, ptr %l13, !tbaa !24
  %t261 = sub i64 %t257, %t258
  %t262 = load i64, ptr %l15, !tbaa !24
  %t265 = add i64 %t261, %t262
  %t267 = sub i64 %t265, 1
  %t268 = load i64, ptr %l15, !tbaa !24
  %t271 = sdiv i64 %t267, %t268
  store i64 %t271, ptr %l112, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb37
bb37:
  %t273 = load i64, ptr %l112, !tbaa !24
  store i64 %t273, ptr %l109, !tbaa !24
  br label %bb38
bb38:
  %t274 = load i64, ptr %l109, !tbaa !24
  store i64 %t274, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t275 = load i64, ptr %l17, !tbaa !24
  %t276 = load i64, ptr %l16, !tbaa !24
  %t279 = icmp slt i64 %t275, %t276
  %t281 = xor i1 %t279, true
  br i1 %t281, label %bb40, label %bb41
bb40:
  br label %bb61
bb41:
  br label %bb42
bb42:
  %t283 = load i64, ptr %l13, !tbaa !24
  %t284 = load i64, ptr %l17, !tbaa !24
  %t285 = load i64, ptr %l15, !tbaa !24
  %t288 = mul i64 %t284, %t285
  %t291 = add i64 %t283, %t288
  store i64 %t291, ptr %l18, !tbaa !24
  %t293 = load i64, ptr %l18, !tbaa !24
  %t294 = load i64, ptr %l1, !tbaa !24
  %t297 = icmp ne i64 %t293, %t294
  br i1 %t297, label %bb43, label %bb44
bb43:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/lsp:worker", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/lsp:Server", ptr %t302, i32 0, i32 1
  store ptr %t304, ptr %l136, !tbaa !29
  %t305 = load i64, ptr %l18, !tbaa !24
  %t306 = load ptr, ptr %l136, !tbaa !29
  %t307 = call ptr @__olang_scope_or(ptr %v1, ptr %t306)
  %t308 = call ptr @__olang_scope_hold(ptr %t307)
  %t309 = ptrtoint ptr %t308 to i64
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/lsp:worker", ptr %t310, i32 0, i32 0
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t315 = call ptr @__olang_scope_or(ptr %v1, ptr %t313)
  %t316 = call ptr @__olang_scope_hold(ptr %t315)
  %t317 = ptrtoint ptr %t316 to i64
  %t319 = inttoptr i64 %t309 to ptr
  %t321 = inttoptr i64 %t317 to ptr
  %t322 = load ptr, ptr %l136, !tbaa !29
  %t324 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %t319, ptr %t321, ptr %t322, i64 %t305)
  store ptr %t324, ptr %l142
  br label %bb45
bb44:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb46
bb45:
  %t325 = load ptr, ptr %l142, !tbaa !29
  %t327 = getelementptr %"compiler/lsp:Doc", ptr %t325, i32 0, i32 4
  %t328 = load i1, ptr %t327, !tbaa !21
  store i1 %t328, ptr %l133, !tbaa !21
  br label %bb46
bb46:
  %t330 = load i1, ptr %l133, !tbaa !21
  br i1 %t330, label %bb47, label %bb48
bb47:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/lsp:worker", ptr %t331, i32 0, i32 0
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = getelementptr %"compiler/lsp:Server", ptr %t334, i32 0, i32 1
  store ptr %t336, ptr %l148, !tbaa !29
  %t337 = load i64, ptr %l18, !tbaa !24
  %t338 = load ptr, ptr %l148, !tbaa !29
  %t339 = call ptr @__olang_scope_or(ptr %v1, ptr %t338)
  %t340 = call ptr @__olang_scope_hold(ptr %t339)
  %t341 = ptrtoint ptr %t340 to i64
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/lsp:worker", ptr %t342, i32 0, i32 0
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t347 = call ptr @__olang_scope_or(ptr %v1, ptr %t345)
  %t348 = call ptr @__olang_scope_hold(ptr %t347)
  %t349 = ptrtoint ptr %t348 to i64
  %t351 = inttoptr i64 %t341 to ptr
  %t353 = inttoptr i64 %t349 to ptr
  %t354 = load ptr, ptr %l148, !tbaa !29
  %t356 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %t351, ptr %t353, ptr %t354, i64 %t337)
  store ptr %t356, ptr %l154
  br label %bb49
bb48:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb51
bb49:
  %t357 = load ptr, ptr %l154, !tbaa !29
  %t359 = getelementptr %"compiler/lsp:Doc", ptr %t357, i32 0, i32 2
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  store { i64, ptr } %t360, ptr %l156, !tbaa !27
  %t361 = load ptr, ptr %l12, !tbaa !29
  %t363 = getelementptr %"compiler/load:Module", ptr %t361, i32 0, i32 1
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !27
  %t365 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = call ptr @__olang_scope_or(ptr %v1, ptr %t366)
  %t368 = call ptr @__olang_scope_hold(ptr %t367)
  %t369 = ptrtoint ptr %t368 to i64
  %t371 = inttoptr i64 %t369 to ptr
  %t372 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t374 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t371, ptr %v0, { i64, ptr } %t372, { i64, ptr } %t364)
  store i1 %t374, ptr %l160
  br label %bb50
bb50:
  %t375 = load i1, ptr %l160, !tbaa !21
  store i1 %t375, ptr %l145, !tbaa !21
  br label %bb51
bb51:
  %t376 = load i1, ptr %l145, !tbaa !21
  br i1 %t376, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s7
  %t377 = load i1, ptr %l9, !tbaa !21
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb54, label %bb55
bb53:
  br label %bb59
bb54:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 44)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  store i1 false, ptr %l9, !tbaa !21
  %t382 = load i64, ptr %l18, !tbaa !24
  %t384 = call i64 @__olang_fmt_i64(ptr null, i64 %t382)
  %t385 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t384)
  %t386 = call i64 @__olang_fmt_i64(ptr %t385, i64 %t382)
  %t387 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t385, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l8, { i64, ptr } %t388)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t392 = load i64, ptr %l17, !tbaa !24
  %t395 = add i64 %t392, 1
  store i64 %t395, ptr %l17, !tbaa !24
  br label %bb39
bb61:
  br label %bb62
bb62:
  %t397 = load i64, ptr %l11, !tbaa !24
  %t400 = add i64 %t397, 1
  store i64 %t400, ptr %l11, !tbaa !24
  br label %bb26
bb63:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d115, i32 0, i32 1) })
  br label %bb64
bb64:
  store i64 0, ptr %l19, !tbaa !24
  %t404 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t404, ptr %l176
  br label %bb65
bb65:
  %t405 = load i64, ptr %l176, !tbaa !24
  store i64 %t405, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t406 = load i64, ptr %l20, !tbaa !24
  %t407 = load i64, ptr %l19, !tbaa !24
  %t410 = icmp sgt i64 %t406, %t407
  br i1 %t410, label %bb66, label %bb67
bb66:
  %t412 = load i64, ptr %l21, !tbaa !24
  %t414 = icmp sgt i64 %t412, 0
  br i1 %t414, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb71
bb68:
  %t416 = load i64, ptr %l20, !tbaa !24
  %t417 = load i64, ptr %l19, !tbaa !24
  %t420 = sub i64 %t416, %t417
  %t421 = load i64, ptr %l21, !tbaa !24
  %t424 = add i64 %t420, %t421
  %t426 = sub i64 %t424, 1
  %t427 = load i64, ptr %l21, !tbaa !24
  %t430 = sdiv i64 %t426, %t427
  store i64 %t430, ptr %l183, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb70
bb70:
  %t432 = load i64, ptr %l183, !tbaa !24
  store i64 %t432, ptr %l180, !tbaa !24
  br label %bb71
bb71:
  %t433 = load i64, ptr %l180, !tbaa !24
  store i64 %t433, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb72
bb72:
  %t434 = load i64, ptr %l23, !tbaa !24
  %t435 = load i64, ptr %l22, !tbaa !24
  %t438 = icmp slt i64 %t434, %t435
  %t440 = xor i1 %t438, true
  br i1 %t440, label %bb73, label %bb74
bb73:
  br label %bb83
bb74:
  br label %bb75
bb75:
  %t442 = load i64, ptr %l19, !tbaa !24
  %t443 = load i64, ptr %l23, !tbaa !24
  %t444 = load i64, ptr %l21, !tbaa !24
  %t447 = mul i64 %t443, %t444
  %t450 = add i64 %t442, %t447
  store i64 %t450, ptr %l24, !tbaa !24
  %t452 = load i64, ptr %l24, !tbaa !24
  %t454 = icmp sgt i64 %t452, 0
  br i1 %t454, label %bb76, label %bb77
bb76:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 44)
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb79
bb79:
  store ptr %l8, ptr %l204, !tbaa !29
  %t457 = load i64, ptr %l24, !tbaa !24
  %t460 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l7, i64 %t457)
  store { i64, ptr } %t460, ptr %l207
  br label %bb80
bb80:
  %t461 = load ptr, ptr %l204, !tbaa !29
  %t462 = load { i64, ptr }, ptr %l207, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s0, ptr %t461, { i64, ptr } %t462)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t463 = load i64, ptr %l23, !tbaa !24
  %t466 = add i64 %t463, 1
  store i64 %t466, ptr %l23, !tbaa !24
  br label %bb72
bb83:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb84
bb84:
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l212, !tbaa !29
  %t471 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t471, ptr %l214
  br label %bb85
bb85:
  %t472 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t473 = load ptr, ptr %l212, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s0, ptr %t473, { i64, ptr } %t472)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2ecomplete(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/session:Items"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %lp16 = alloca ptr
  %lp17 = alloca ptr
  %l18 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l19 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l22 = alloca %"compiler/session:Items"
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l58 = alloca i1
  %l65 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l101 = alloca i1
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca i64
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l124 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l127 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l128 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l130 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l131 = alloca i32
  %l133 = alloca i1
  %l146 = alloca ptr
  %l158 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/session:Items" @compiler_2fsession_3aItems_2ector(ptr %s0)
  store %"compiler/session:Items" %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = load %"compiler/session:Items", ptr %l22
  store %"compiler/session:Items" %t2, ptr %l7
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @compiler_2fsession_2eImportTyped(ptr %v3, ptr %s0, { i64, ptr } %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l27
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l26
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t12, ptr %l23, !tbaa !27
  br label %bb5
bb3:
  %t13 = load i32, ptr %l27, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  store i1 %t16, ptr %l29, !tbaa !21
  br label %bb4
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t17, ptr %l23, !tbaa !27
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l32, !tbaa !24
  %t21 = load i64, ptr %l32, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l33, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l32, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t32, ptr %l8, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store i1 %t35, ptr %l35
  br label %bb6
bb6:
  %t36 = load i1, ptr %l35, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l7, ptr %l37, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t39, ptr %l38, !tbaa !27
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr %"compiler/lsp:Doc", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v2, ptr %v2, { i64, ptr } %t43)
  store { i64, ptr } %t45, ptr %l41
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t46 = load ptr, ptr %l37, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l41, !tbaa !27
  call void @compiler_2fsession_2eImportPaths(ptr %s0, ptr %s0, ptr %v2, ptr %t46, { i64, ptr } %t47, { i64, ptr } %t48)
  br label %bb10
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l42, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l43, !tbaa !27
  %t51 = getelementptr %"compiler/session:Items", ptr %l7, i32 0, i32 0
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s1, ptr %t51)
  store { i64, ptr } %t53, ptr %l45
  br label %bb11
bb11:
  %t54 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t56 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t54, i64 %t55)
  %t64 = getelementptr i8, ptr %t63, i64 %t55
  call void @olang_textcopy(ptr %t64, ptr %t57, i64 %t58)
  %t65 = getelementptr i8, ptr %t64, i64 %t58
  call void @olang_textcopy(ptr %t65, ptr %t60, i64 %t61)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t71 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %v1, ptr %s1, ptr %s1, { i64, ptr } %t69, { i64, ptr } %t67)
  store { i64, ptr } %t71, ptr %l48
  br label %bb12
bb12:
  %t72 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t73 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s1, ptr %t73, { i64, ptr } %t72)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t75 = load i64, ptr %l4, !tbaa !24
  store i64 %t75, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb16, label %bb17
bb16:
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t81, ptr %l54, !tbaa !27
  %t82 = load i64, ptr %l9, !tbaa !24
  %t84 = sub i64 %t82, 1
  %t86 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t84
  %t89 = load i8, ptr %t88, !tbaa !32
  %t91 = call i1 @compiler_2fsession_2eWordChar(i8 %t89)
  store i1 %t91, ptr %l58
  br label %bb18
bb17:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb19
bb18:
  %t92 = load i1, ptr %l58, !tbaa !21
  store i1 %t92, ptr %l53, !tbaa !21
  br label %bb19
bb19:
  %t93 = load i1, ptr %l53, !tbaa !21
  %t94 = xor i1 %t93, true
  br i1 %t94, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = sub i64 %t96, 1
  store i64 %t99, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  br label %bb15
bb24:
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = call { i64, ptr } @compiler_2fsession_2ePromiseTargets(ptr %v3, ptr %s0, { i64, ptr } %t101, i64 %t102)
  store { i64, ptr } %t105, ptr %l65
  br label %bb25
bb25:
  %t106 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t106, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l12, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t120 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t120, ptr %l73, !tbaa !27
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %t124, i64 %t121
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !37
  %t129 = load i64, ptr @G_2ecompiler_2fsession_2eCompVariable, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %s0, ptr %s0, ptr %s5, ptr %l7, { i64, ptr } %t126, i64 %t129, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d121, i32 0, i32 1) })
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l11, !tbaa !24
  br label %bb26
bb32:
  %t138 = load i64, ptr %l9, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb33, label %bb34
bb33:
  %t142 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t142, ptr %l85, !tbaa !27
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = sub i64 %t143, 1
  %t147 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t145
  %t150 = load i8, ptr %t149, !tbaa !32
  %t152 = icmp eq i8 %t150, 46
  store i1 %t152, ptr %l84, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb35
bb35:
  %t154 = load i1, ptr %l84, !tbaa !21
  br i1 %t154, label %bb36, label %bb37
bb36:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t157 = sub i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  %t159 = load i64, ptr %l4, !tbaa !24
  store i64 %t159, ptr %l15, !tbaa !24
  br label %bb38
bb37:
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t163 = getelementptr %"compiler/lsp:Doc", ptr %t161, i32 0, i32 1
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t165 = load ptr, ptr %l5, !tbaa !29
  %t166 = load ptr, ptr %l6, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/lsp:worker", ptr %t167, i32 0, i32 4
  %t174 = call ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %v2, ptr %v4, ptr %v5, ptr %v0, ptr %v5, { i64, ptr } %t164, ptr %t165, ptr %t166, ptr %t169, i1 true, i1 true)
  store ptr %t174, ptr %l158
  br label %bb73
bb38:
  %t175 = load i64, ptr %l15, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t181 = icmp slt i64 %t175, %t178
  br i1 %t181, label %bb39, label %bb40
bb39:
  %t183 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t183, ptr %l98, !tbaa !27
  %t184 = load i64, ptr %l15, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr i8, ptr %t187, i64 %t184
  %t189 = load i8, ptr %t188, !tbaa !32
  %t191 = call i1 @compiler_2fsession_2eWordChar(i8 %t189)
  store i1 %t191, ptr %l101
  br label %bb41
bb40:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb42
bb41:
  %t192 = load i1, ptr %l101, !tbaa !21
  store i1 %t192, ptr %l97, !tbaa !21
  br label %bb42
bb42:
  %t193 = load i1, ptr %l97, !tbaa !21
  %t194 = xor i1 %t193, true
  br i1 %t194, label %bb43, label %bb44
bb43:
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t196 = load i64, ptr %l15, !tbaa !24
  %t199 = add i64 %t196, 1
  store i64 %t199, ptr %l15, !tbaa !24
  br label %bb46
bb46:
  br label %bb38
bb47:
  %t201 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t201, ptr %l106, !tbaa !27
  %t202 = load i64, ptr %l14, !tbaa !24
  store i64 %t202, ptr %l107, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  store i64 %t204, ptr %l108, !tbaa !24
  %t205 = icmp sge i64 0, 0
  br i1 %t205, label %bb48, label %bb49
bb48:
  %t207 = load i64, ptr %l107, !tbaa !24
  %t208 = icmp sle i64 0, %t207
  br i1 %t208, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb50:
  %t210 = load i64, ptr %l107, !tbaa !24
  %t211 = load i64, ptr %l108, !tbaa !24
  %t212 = icmp sle i64 %t210, %t211
  br i1 %t212, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb52:
  %t214 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = load i64, ptr %l107, !tbaa !24
  %t217 = getelementptr i8, ptr %t215, i64 0
  %t218 = sub i64 %t216, 0
  %t219 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t217, 1
  store { i64, ptr } %t220, ptr %l112, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t221, ptr %l113, !tbaa !27
  %t222 = load i64, ptr %l15, !tbaa !24
  store i64 %t222, ptr %l114, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t223, 0
  store i64 %t226, ptr %l117, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  store i64 %t228, ptr %l118, !tbaa !24
  %t229 = load i64, ptr %l114, !tbaa !24
  %t230 = icmp sge i64 %t229, 0
  br i1 %t230, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb54:
  %t232 = load i64, ptr %l114, !tbaa !24
  %t233 = load i64, ptr %l117, !tbaa !24
  %t234 = icmp sle i64 %t232, %t233
  br i1 %t234, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb56:
  %t236 = load i64, ptr %l117, !tbaa !24
  %t237 = load i64, ptr %l118, !tbaa !24
  %t238 = icmp sle i64 %t236, %t237
  br i1 %t238, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb58:
  %t240 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = load i64, ptr %l114, !tbaa !24
  %t243 = load i64, ptr %l117, !tbaa !24
  %t244 = getelementptr i8, ptr %t241, i64 %t242
  %t245 = sub i64 %t243, %t242
  %t246 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t244, 1
  %t248 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t252 = extractvalue { i64, ptr } %t247, 1
  %t253 = extractvalue { i64, ptr } %t247, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t249, i64 %t250)
  %t256 = getelementptr i8, ptr %t255, i64 %t250
  call void @olang_textcopy(ptr %t256, ptr %t252, i64 %t253)
  %t257 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t255, 1
  %t259 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 16, i64 8)
  store ptr %t259, ptr %lp16
  %t261 = load ptr, ptr %lp16
  store { i64, ptr } %t258, ptr %t261, !tbaa !27
  %t262 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v5)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t262, ptr %l124
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb60:
  %t263 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 72, i64 8)
  store ptr %t263, ptr %lp17
  %t264 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l124
  %t265 = load ptr, ptr %lp17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t264, ptr %t265
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/lsp:worker", ptr %t266, i32 0, i32 4
  %t270 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v0, ptr %v0, ptr %t268)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t270, ptr %l127
  br label %bb61
bb61:
  %t271 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l127
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t271, ptr %l18
  br label %bb62
bb62:
  %t273 = call { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v0, ptr %v0, ptr %l18)
  %t274 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t273, 1
  %t275 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t273, 0
  store i32 %t275, ptr %l131
  %t276 = icmp ne i32 %t275, 0
  br i1 %t276, label %bb64, label %ok.277, !prof !99
ok.277:
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t274, ptr %l130
  br label %bb63
bb63:
  %t278 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l130
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t278, ptr %l128
  br label %bb66
bb64:
  %t279 = load i32, ptr %l131, !tbaa !23
  %t280 = ashr i32 %t279, 16
  %t282 = icmp eq i32 %t280, 1
  store i1 %t282, ptr %l133, !tbaa !21
  br label %bb65
bb65:
  br label %bb69
bb66:
  %t283 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l128
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t283, ptr %l19
  %t284 = load ptr, ptr %lp17
  %t285 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l19, i32 0, i32 0
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  %t287 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l19, i32 0, i32 1
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v5, ptr %v0, ptr %v0, ptr %t284, { i64, ptr } %t286, { i64, ptr } %t288)
  br label %bb67
bb67:
  br label %bb68
bb68:
  br label %bb62
bb69:
  %t292 = load ptr, ptr %lp17
  %t293 = load ptr, ptr %l2, !tbaa !29
  %t295 = getelementptr %"compiler/lsp:Doc", ptr %t293, i32 0, i32 2
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  %t297 = load ptr, ptr %lp16
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v5, ptr %v2, ptr %v5, ptr %t292, { i64, ptr } %t296, { i64, ptr } %t298)
  br label %bb70
bb70:
  %t302 = load ptr, ptr %l2, !tbaa !29
  %t304 = getelementptr %"compiler/lsp:Doc", ptr %t302, i32 0, i32 1
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  %t306 = load ptr, ptr %l5, !tbaa !29
  %t307 = load ptr, ptr %l6, !tbaa !29
  %t308 = load ptr, ptr %lp17
  %t313 = call ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %v2, ptr %v4, ptr %v5, ptr %v5, ptr %v5, { i64, ptr } %t305, ptr %t306, ptr %t307, ptr %t308, i1 true, i1 false)
  store ptr %t313, ptr %l146
  br label %bb71
bb71:
  %t314 = load ptr, ptr %l146, !tbaa !29
  %t316 = load ptr, ptr %l2, !tbaa !29
  %t318 = getelementptr %"compiler/lsp:Doc", ptr %t316, i32 0, i32 2
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  %t320 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eMembers(ptr %v5, ptr %s0, ptr %v2, ptr %t314, ptr %l7, { i64, ptr } %t319, i64 %t320)
  br label %bb72
bb72:
  br label %bb75
bb73:
  %t325 = load ptr, ptr %l158, !tbaa !29
  %t327 = load ptr, ptr %l2, !tbaa !29
  %t329 = getelementptr %"compiler/lsp:Doc", ptr %t327, i32 0, i32 2
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  %t331 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eNames(ptr %v5, ptr %s0, ptr %v2, ptr %t325, ptr %l7, { i64, ptr } %t330, i64 %t331)
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l164, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t337, ptr %l165, !tbaa !27
  %t338 = getelementptr %"compiler/session:Items", ptr %l7, i32 0, i32 0
  %t340 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t338)
  store { i64, ptr } %t340, ptr %l167
  br label %bb76
bb76:
  %t341 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t343 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = add i64 %t342, %t345
  %t347 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t349 = add i64 %t346, %t348
  %t350 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t349)
  call void @olang_textcopy(ptr %t350, ptr %t341, i64 %t342)
  %t351 = getelementptr i8, ptr %t350, i64 %t342
  call void @olang_textcopy(ptr %t351, ptr %t344, i64 %t345)
  %t352 = getelementptr i8, ptr %t351, i64 %t345
  call void @olang_textcopy(ptr %t352, ptr %t347, i64 %t348)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t350, 1
  %t356 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t358 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t356, { i64, ptr } %t354)
  store { i64, ptr } %t358, ptr %l170
  br label %bb77
bb77:
  %t359 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t360 = load ptr, ptr %l164, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s0, ptr %t360, { i64, ptr } %t359)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2edeprecations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/session:Positions"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/session:Use"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/session:Use"
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l21 = alloca %"compiler/session:Positions"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca %"compiler/session:Use"
  %l35 = alloca i64
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/session:Use"
  %l63 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_hold(ptr %s0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l11, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aPositions_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %s0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l11, !tbaa !24
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = load i64, ptr %l11
  %t11 = inttoptr i64 %t10 to ptr
  %t15 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v2, ptr %v3, ptr %t11, ptr %t7, ptr %t8, { i64, ptr } %t9)
  store { i64, ptr } %t15, ptr %l16
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t17 = load i64, ptr %l11
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = extractvalue { i64, ptr } %t16, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_held_alloc(ptr %t18, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lsp:worker", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/lsp:Server", ptr %t28, i32 0, i32 2
  %t31 = load i1, ptr %t30, !tbaa !21
  %t34 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %s0, ptr %s0, { i64, ptr } %t24, i1 %t31)
  store %"compiler/session:Positions" %t34, ptr %l21
  br label %bb4
bb4:
  %t35 = load %"compiler/session:Positions", ptr %l21
  store %"compiler/session:Positions" %t35, ptr %l4
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eDeprecatedUses(ptr %v2, ptr %v3, ptr %s1, ptr %t36, { i64, ptr } %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l24
  br label %bb5
bb5:
  %t41 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  %t42 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %t42
  store ptr %t42, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l26, !tbaa !24
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2eLen_3ccompiler_2fsession_3aUse_3e(ptr %s1, ptr %t45)
  store i64 %t47, ptr %l28
  br label %bb7
bb7:
  %t48 = load i64, ptr %l26, !tbaa !24
  %t49 = load i64, ptr %l28, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb9:
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = call %"compiler/session:Use" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2eAt_3ccompiler_2fsession_3aUse_3e(ptr %s1, ptr %s1, ptr %t54, i64 %t55)
  store %"compiler/session:Use" %t58, ptr %l33
  br label %bb11
bb11:
  %t59 = load %"compiler/session:Use", ptr %l33
  store %"compiler/session:Use" %t59, ptr %l7
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v1, ptr %t60)
  store i64 %t62, ptr %l35
  br label %bb12
bb12:
  %t63 = load i64, ptr %l35, !tbaa !24
  %t64 = icmp sgt i64 %t63, 0
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t66 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t66, i8 44)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t68, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d124, i32 0, i32 1) })
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/session:Use", ptr %l7, i32 0, i32 0
  %t72 = load i64, ptr %t71, !tbaa !24
  %t73 = getelementptr %"compiler/session:Use", ptr %l7, i32 0, i32 1
  %t74 = load i64, ptr %t73, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %s0, ptr %v1, ptr %l4, ptr %t70, i64 %t72, i64 %t74)
  br label %bb18
bb18:
  %t79 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t79, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d125, i32 0, i32 1) })
  br label %bb19
bb19:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/session:Use", ptr %l7, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %s1, ptr %t81, { i64, ptr } %t83)
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t86, i8 125)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l6, !tbaa !24
  br label %bb6
bb23:
  call void @__olang_scope_close(ptr %s1)
  store %olang.scope zeroinitializer, ptr %s5
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t94 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2ePlaced(ptr %v2, ptr %v3, ptr %s5, ptr %t93, { i64, ptr } %t94)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l52
  br label %bb24
bb24:
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  %t99 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %t99
  store ptr %t99, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t101 = load i64, ptr %l9, !tbaa !24
  store i64 %t101, ptr %l54, !tbaa !24
  %t102 = load ptr, ptr %l8, !tbaa !29
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2eLen_3ccompiler_2fsession_3aUse_3e(ptr %s5, ptr %t102)
  store i64 %t104, ptr %l56
  br label %bb26
bb26:
  %t105 = load i64, ptr %l54, !tbaa !24
  %t106 = load i64, ptr %l56, !tbaa !24
  %t107 = icmp slt i64 %t105, %t106
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb28:
  br label %bb29
bb29:
  %t111 = load ptr, ptr %l8, !tbaa !29
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = call %"compiler/session:Use" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2eAt_3ccompiler_2fsession_3aUse_3e(ptr %s5, ptr %s5, ptr %t111, i64 %t112)
  store %"compiler/session:Use" %t115, ptr %l61
  br label %bb30
bb30:
  %t116 = load %"compiler/session:Use", ptr %l61
  store %"compiler/session:Use" %t116, ptr %l10
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v1, ptr %t117)
  store i64 %t119, ptr %l63
  br label %bb31
bb31:
  %t120 = load i64, ptr %l63, !tbaa !24
  %t121 = icmp sgt i64 %t120, 0
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t123, i8 44)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  %t125 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s6, ptr %t125, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d126, i32 0, i32 1) })
  br label %bb36
bb36:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/session:Use", ptr %l10, i32 0, i32 0
  %t129 = load i64, ptr %t128, !tbaa !24
  %t130 = getelementptr %"compiler/session:Use", ptr %l10, i32 0, i32 1
  %t131 = load i64, ptr %t130, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %s0, ptr %v1, ptr %l4, ptr %t127, i64 %t129, i64 %t131)
  br label %bb37
bb37:
  %t136 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s6, ptr %t136, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d127, i32 0, i32 1) })
  br label %bb38
bb38:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr %"compiler/session:Use", ptr %l10, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %s5, ptr %t138, { i64, ptr } %t140)
  br label %bb39
bb39:
  %t143 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t143, i8 125)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l9, !tbaa !24
  br label %bb25
bb42:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2ediagnostic(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/diag:Item"
  %l8 = alloca %"compiler/session:Positions"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca %"compiler/diag:Item"
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/session:Positions"
  %l21 = alloca %"compiler/diag:Item"
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l32 = alloca %"compiler/session:Positions"
  %l38 = alloca ptr
  %l40 = alloca i64
  %l44 = alloca i1
  %l52 = alloca %"std/prelude/text:StringBuilder"
  %l56 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l83 = alloca %"compiler/diag:Item"
  %l86 = alloca i64
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l97 = alloca i64
  %l102 = alloca { i64, ptr }
  %l107 = alloca %"compiler/session:Positions"
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l120 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l132 = alloca i64
  %l134 = alloca ptr
  %l136 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t2 = load i64, ptr %l5, !tbaa !24
  %t5 = call %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v4, ptr %v4, ptr %t1, i64 %t2)
  store %"compiler/diag:Item" %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load %"compiler/diag:Item", ptr %l21
  store %"compiler/diag:Item" %t6, ptr %l7
  %t7 = call ptr @__olang_scope_hold(ptr %s0)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l22, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aPositions_2e0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = call ptr @__olang_region_make(ptr %s0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l22, !tbaa !24
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t16 = load i64, ptr %l22
  %t17 = inttoptr i64 %t16 to ptr
  %t21 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v2, ptr %v5, ptr %t17, ptr %t13, ptr %t14, { i64, ptr } %t15)
  store { i64, ptr } %t21, ptr %l27
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t23 = load i64, ptr %l22
  %t24 = inttoptr i64 %t23 to ptr
  %t25 = extractvalue { i64, ptr } %t22, 0
  %t26 = extractvalue { i64, ptr } %t22, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_held_alloc(ptr %t24, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lsp:worker", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/lsp:Server", ptr %t34, i32 0, i32 2
  %t37 = load i1, ptr %t36, !tbaa !21
  %t40 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %s0, ptr %s0, { i64, ptr } %t30, i1 %t37)
  store %"compiler/session:Positions" %t40, ptr %l32
  br label %bb5
bb5:
  %t41 = load %"compiler/session:Positions", ptr %l32
  store %"compiler/session:Positions" %t41, ptr %l8
  %t42 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t42, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d128, i32 0, i32 1) })
  br label %bb6
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2erangeOf(ptr %v0, ptr %v1, ptr %s0, ptr %v4, ptr %t44, ptr %t45, ptr %l8, ptr %l7)
  br label %bb7
bb7:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l38, !tbaa !29
  %t51 = getelementptr %"compiler/diag:Item", ptr %l7, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = call i64 @compiler_2flsp_2eseverityOf(ptr %v4, { i64, ptr } %t52)
  store i64 %t54, ptr %l40
  br label %bb8
bb8:
  %t55 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t57 = load i64, ptr %l40, !tbaa !24
  %t58 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t59 = add i64 %t56, %t58
  %t60 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = getelementptr i8, ptr %t63, i64 %t56
  %t65 = call i64 @__olang_fmt_i64(ptr %t64, i64 %t57)
  %t66 = getelementptr i8, ptr %t64, i64 %t58
  call void @olang_textcopy(ptr %t66, ptr %t60, i64 %t61)
  %t67 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t63, 1
  %t70 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t70, { i64, ptr } %t68)
  br label %bb9
bb9:
  %t72 = getelementptr %"compiler/diag:Item", ptr %l7, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store i1 %t75, ptr %l44
  br label %bb10
bb10:
  %t76 = load i1, ptr %l44, !tbaa !21
  %t77 = xor i1 %t76, true
  br i1 %t77, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t79, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d132, i32 0, i32 1) })
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/diag:Item", ptr %l7, i32 0, i32 1
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %v4, ptr %t81, { i64, ptr } %t83)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t86 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t86, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d133, i32 0, i32 1) })
  br label %bb16
bb16:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/diag:Item", ptr %l7, i32 0, i32 6
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %v4, ptr %t88, { i64, ptr } %t90)
  br label %bb17
bb17:
  %t93 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t93, ptr %l52
  br label %bb18
bb18:
  %t94 = load %"std/prelude/text:StringBuilder", ptr %l52
  store %"std/prelude/text:StringBuilder" %t94, ptr %l9
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l10, !tbaa !24
  %t99 = load ptr, ptr %l4, !tbaa !29
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %v4, ptr %t99)
  store i64 %t101, ptr %l56
  br label %bb19
bb19:
  %t102 = load i64, ptr %l56, !tbaa !24
  store i64 %t102, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t107 = icmp sgt i64 %t103, %t104
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load i64, ptr %l12, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  br i1 %t111, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb25
bb22:
  %t113 = load i64, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t117 = sub i64 %t113, %t114
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = add i64 %t117, %t118
  %t123 = sub i64 %t121, 1
  %t124 = load i64, ptr %l12, !tbaa !24
  %t127 = sdiv i64 %t123, %t124
  store i64 %t127, ptr %l63, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb24
bb24:
  %t129 = load i64, ptr %l63, !tbaa !24
  store i64 %t129, ptr %l60, !tbaa !24
  br label %bb25
bb25:
  %t130 = load i64, ptr %l60, !tbaa !24
  store i64 %t130, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t131 = load i64, ptr %l14, !tbaa !24
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb28:
  br label %bb29
bb29:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t141 = load i64, ptr %l12, !tbaa !24
  %t144 = mul i64 %t140, %t141
  %t147 = add i64 %t139, %t144
  %t149 = load ptr, ptr %l4, !tbaa !29
  %t153 = call %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v4, ptr %v4, ptr %t149, i64 %t147)
  store %"compiler/diag:Item" %t153, ptr %l83
  br label %bb30
bb30:
  %t154 = load %"compiler/diag:Item", ptr %l83
  store %"compiler/diag:Item" %t154, ptr %l16
  %t155 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 0
  %t156 = load i1, ptr %t155, !tbaa !21
  br i1 %t156, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb32:
  br label %bb33
bb33:
  %t159 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l9)
  store i64 %t159, ptr %l86
  br label %bb34
bb34:
  %t160 = load i64, ptr %l86, !tbaa !24
  %t161 = icmp sgt i64 %t160, 0
  br i1 %t161, label %bb35, label %bb36
bb35:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 44)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t164 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 2
  %t165 = load i64, ptr %t164, !tbaa !24
  %t167 = icmp sge i64 %t165, 0
  br i1 %t167, label %bb39, label %bb40
bb39:
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t170 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 2
  %t171 = load i64, ptr %t170, !tbaa !24
  %t174 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eRealOfFile(ptr %v2, ptr %s4, ptr %t169, i64 %t171)
  store { i64, ptr } %t174, ptr %l94
  br label %bb41
bb40:
  %t175 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 1
  %t178 = extractvalue { i64, ptr } %t175, 0
  %t179 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t177, i64 %t178)
  %t180 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  store { i64, ptr } %t181, ptr %l91, !tbaa !27
  br label %bb42
bb41:
  %t183 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t183, ptr %l91, !tbaa !27
  br label %bb42
bb42:
  %t184 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t184, ptr %l17, !tbaa !27
  %t185 = call ptr @__olang_scope_hold(ptr %s4)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l97, !tbaa !24
  %t187 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aPositions_2e0
  br i1 %t187, label %bb43, label %bb44
bb43:
  %t189 = call ptr @__olang_region_make(ptr %s4)
  %t190 = ptrtoint ptr %t189 to i64
  store i64 %t190, ptr %l97, !tbaa !24
  br label %bb44
bb44:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t194 = load i64, ptr %l97
  %t195 = inttoptr i64 %t194 to ptr
  %t199 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v2, ptr %s4, ptr %t195, ptr %t191, ptr %t192, { i64, ptr } %t193)
  store { i64, ptr } %t199, ptr %l102
  br label %bb45
bb45:
  %t200 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t201 = load i64, ptr %l97
  %t202 = inttoptr i64 %t201 to ptr
  %t203 = extractvalue { i64, ptr } %t200, 0
  %t204 = extractvalue { i64, ptr } %t200, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_held_alloc(ptr %t202, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/lsp:worker", ptr %t209, i32 0, i32 0
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/lsp:Server", ptr %t212, i32 0, i32 2
  %t215 = load i1, ptr %t214, !tbaa !21
  %t218 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %s4, ptr %s4, { i64, ptr } %t208, i1 %t215)
  store %"compiler/session:Positions" %t218, ptr %l107
  br label %bb46
bb46:
  %t219 = load %"compiler/session:Positions", ptr %l107
  store %"compiler/session:Positions" %t219, ptr %l18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l9, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d134, i32 0, i32 1) })
  br label %bb47
bb47:
  store ptr %l9, ptr %l109, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t225 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2euriOf(ptr %v0, ptr %s4, ptr %s4, ptr %v6, ptr %t221, { i64, ptr } %t222)
  store { i64, ptr } %t225, ptr %l112
  br label %bb48
bb48:
  %t226 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t227 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s4, ptr %t227, { i64, ptr } %t226)
  br label %bb49
bb49:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l9, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d135, i32 0, i32 1) })
  br label %bb50
bb50:
  %t230 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2erangeOf(ptr %v0, ptr %s0, ptr %s4, ptr %v4, ptr %t230, ptr %l9, ptr %l18, ptr %l16)
  br label %bb51
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l9, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d136, i32 0, i32 1) })
  br label %bb52
bb52:
  store ptr %l9, ptr %l120, !tbaa !29
  %t236 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 7
  %t237 = load i1, ptr %t236, !tbaa !21
  br i1 %t237, label %bb53, label %bb54
bb53:
  %t239 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 6
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t241 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t244 = extractvalue { i64, ptr } %t240, 1
  %t245 = extractvalue { i64, ptr } %t240, 0
  %t246 = add i64 %t242, %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t246)
  call void @olang_textcopy(ptr %t247, ptr %t241, i64 %t242)
  %t248 = getelementptr i8, ptr %t247, i64 %t242
  call void @olang_textcopy(ptr %t248, ptr %t244, i64 %t245)
  %t249 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t247, 1
  store { i64, ptr } %t250, ptr %l122, !tbaa !27
  br label %bb55
bb54:
  %t253 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 6
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l122, !tbaa !27
  br label %bb55
bb55:
  %t256 = load ptr, ptr %l120, !tbaa !29
  %t257 = load { i64, ptr }, ptr %l122, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v4, ptr %t256, { i64, ptr } %t257)
  br label %bb56
bb56:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 125)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s4)
  br label %bb58
bb58:
  %t259 = load i64, ptr %l14, !tbaa !24
  %t262 = add i64 %t259, 1
  store i64 %t262, ptr %l14, !tbaa !24
  br label %bb26
bb59:
  %t265 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l9)
  store i64 %t265, ptr %l132
  br label %bb60
bb60:
  %t266 = load i64, ptr %l132, !tbaa !24
  %t267 = icmp sgt i64 %t266, 0
  br i1 %t267, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  %t269 = load ptr, ptr %l1, !tbaa !29
  store ptr %t269, ptr %l134, !tbaa !29
  %t271 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s10, ptr %l9)
  store { i64, ptr } %t271, ptr %l136
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t272 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t274 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 1
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t277 = add i64 %t273, %t276
  %t278 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t280 = add i64 %t277, %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t280)
  call void @olang_textcopy(ptr %t281, ptr %t272, i64 %t273)
  %t282 = getelementptr i8, ptr %t281, i64 %t273
  call void @olang_textcopy(ptr %t282, ptr %t275, i64 %t276)
  %t283 = getelementptr i8, ptr %t282, i64 %t276
  call void @olang_textcopy(ptr %t283, ptr %t278, i64 %t279)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t281, 1
  %t287 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s10, ptr %t287, { i64, ptr } %t285)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb65:
  %t289 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t289, i8 125)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2flsp_2ecompiler_2flsp_3aworker_2epublishAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/diag:Item"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %lp39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l85 = alloca %"compiler/diag:Item"
  %l90 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l98 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca i64
  %l108 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l115 = alloca i64
  %l119 = alloca i64
  %l122 = alloca i64
  %l142 = alloca { i64, ptr }
  %l144 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca %"std/prelude/text:StringBuilder"
  %l156 = alloca i64
  %l160 = alloca ptr
  %l162 = alloca i64
  %l175 = alloca i64
  %l177 = alloca %"std/prelude/text:StringBuilder"
  %l179 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l181 = alloca i64
  %l185 = alloca i64
  %l188 = alloca i64
  %l208 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l212 = alloca i1
  %l215 = alloca %"std/prelude/text:StringBuilder"
  %l217 = alloca %"std/prelude/text:StringBuilder"
  %l218 = alloca %"std/prelude/text:StringBuilder"
  %l229 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l242 = alloca i64
  %l246 = alloca i64
  %l249 = alloca i64
  %l269 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l273 = alloca i1
  %l274 = alloca i1
  %l275 = alloca ptr
  %l278 = alloca { i64, ptr }
  %l279 = alloca i1
  %l280 = alloca ptr
  %l283 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l285 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l289 = alloca %"std/prelude/text:StringBuilder"
  %l291 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l302 = alloca i64
  %l304 = alloca i64
  %l309 = alloca { i64, ptr }
  %l313 = alloca i1
  %l315 = alloca ptr
  %l317 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:worker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 1
  store ptr %t6, ptr %l46, !tbaa !29
  %t8 = load ptr, ptr %l46, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v5, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lsp:worker", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v5, ptr %t15)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t11 to ptr
  %t23 = inttoptr i64 %t19 to ptr
  %t24 = load ptr, ptr %l46, !tbaa !29
  %t26 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %t21, ptr %t23, ptr %t24, i64 %a1)
  store ptr %t26, ptr %l52
  br label %bb1
bb1:
  %t27 = load ptr, ptr %l52, !tbaa !29
  store ptr %t27, ptr %l5, !tbaa !29
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l53
  br label %bb2
bb2:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l6
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l54
  br label %bb3
bb3:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l7
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v2, ptr %s0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l56
  br label %bb4
bb4:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %l8)
  store i64 %t37, ptr %l58
  br label %bb5
bb5:
  %t38 = load i64, ptr %l58, !tbaa !24
  store i64 %t38, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t39 = load i64, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t45 = load i64, ptr %l11, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb11
bb8:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l65, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb10
bb10:
  %t65 = load i64, ptr %l65, !tbaa !24
  store i64 %t65, ptr %l62, !tbaa !24
  br label %bb11
bb11:
  %t66 = load i64, ptr %l62, !tbaa !24
  store i64 %t66, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t67 = load i64, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l12, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb14:
  br label %bb15
bb15:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l14, !tbaa !24
  %t85 = load i64, ptr %l14, !tbaa !24
  %t88 = call %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %s0, ptr %l8, i64 %t85)
  store %"compiler/diag:Item" %t88, ptr %l85
  br label %bb16
bb16:
  %t89 = load %"compiler/diag:Item", ptr %l85
  store %"compiler/diag:Item" %t89, ptr %l15
  %t90 = getelementptr %"compiler/diag:Item", ptr %l15, i32 0, i32 0
  %t91 = load i1, ptr %t90, !tbaa !21
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb18:
  br label %bb19
bb19:
  %t95 = getelementptr %"compiler/diag:Item", ptr %l15, i32 0, i32 2
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = icmp sge i64 %t96, 0
  br i1 %t98, label %bb20, label %bb21
bb20:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/diag:Item", ptr %l15, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  %t105 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eRealOfFile(ptr %v1, ptr %s0, ptr %t100, i64 %t102)
  store { i64, ptr } %t105, ptr %l93
  br label %bb22
bb21:
  %t106 = call ptr @__olang_scope_hold(ptr %s0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l94, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e16
  br i1 %t108, label %bb23, label %bb24
bb22:
  %t110 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t110, ptr %l90, !tbaa !27
  br label %bb29
bb23:
  %t111 = call ptr @__olang_region_make(ptr %s0)
  %t112 = ptrtoint ptr %t111 to i64
  store i64 %t112, ptr %l94, !tbaa !24
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr %"compiler/lsp:Doc", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = extractvalue { i64, ptr } %t116, 0
  %t120 = load i64, ptr %l94
  %t121 = inttoptr i64 %t120 to ptr
  %t122 = call ptr @__olang_held_alloc(ptr %t121, i64 %t119)
  call void @olang_textcopy(ptr %t122, ptr %t118, i64 %t119)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l98, !tbaa !27
  %t125 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e16
  br i1 %t125, label %bb25, label %bb26
bb25:
  %t127 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t130 = icmp eq i64 %t128, 0
  br i1 %t130, label %bb27, label %bb28
bb26:
  %t132 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t132, ptr %l90, !tbaa !27
  br label %bb29
bb27:
  store { i64, ptr } zeroinitializer, ptr %l98, !tbaa !27
  br label %bb28
bb28:
  %t133 = load i64, ptr %l94
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = load { i64, ptr }, ptr %l98
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = call ptr @__olang_region_or(ptr %t136, ptr null)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr null
  call void @__olang_region_settle_in(ptr %t134, ptr %t139)
  br label %bb26
bb29:
  %t140 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t140, ptr %l16, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t141, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d140, i32 0, i32 1) })
  store i1 %t143, ptr %l103
  br label %bb30
bb30:
  %t144 = load i1, ptr %l103, !tbaa !21
  br i1 %t144, label %bb31, label %bb32
bb31:
  %t145 = call ptr @__olang_scope_hold(ptr %s0)
  %t146 = ptrtoint ptr %t145 to i64
  store i64 %t146, ptr %l104, !tbaa !24
  %t147 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e16
  br i1 %t147, label %bb33, label %bb34
bb32:
  br label %bb41
bb33:
  %t149 = call ptr @__olang_region_make(ptr %s0)
  %t150 = ptrtoint ptr %t149 to i64
  store i64 %t150, ptr %l104, !tbaa !24
  br label %bb34
bb34:
  %t151 = load ptr, ptr %l5, !tbaa !29
  %t153 = getelementptr %"compiler/lsp:Doc", ptr %t151, i32 0, i32 2
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = extractvalue { i64, ptr } %t154, 0
  %t158 = load i64, ptr %l104
  %t159 = inttoptr i64 %t158 to ptr
  %t160 = call ptr @__olang_held_alloc(ptr %t159, i64 %t157)
  call void @olang_textcopy(ptr %t160, ptr %t156, i64 %t157)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l108, !tbaa !27
  %t163 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e16
  br i1 %t163, label %bb35, label %bb36
bb35:
  %t165 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t168 = icmp eq i64 %t166, 0
  br i1 %t168, label %bb37, label %bb38
bb36:
  %t170 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t170, ptr %l112, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t171, ptr %l16, !tbaa !27
  %t172 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e16
  br i1 %t172, label %bb39, label %bb40
bb37:
  store { i64, ptr } zeroinitializer, ptr %l108, !tbaa !27
  br label %bb38
bb38:
  %t174 = load i64, ptr %l104
  %t175 = inttoptr i64 %t174 to ptr
  %t176 = load { i64, ptr }, ptr %l108
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = call ptr @__olang_region_or(ptr %t177, ptr null)
  %t179 = icmp ne ptr %t178, null
  %t180 = select i1 %t179, ptr %t178, ptr null
  call void @__olang_region_settle_in(ptr %t175, ptr %t180)
  br label %bb36
bb39:
  %t181 = load { i64, ptr }, ptr %l112
  %t182 = extractvalue { i64, ptr } %t181, 1
  call void @__olang_region_release(ptr %t182)
  store { i64, ptr } zeroinitializer, ptr %l112
  br label %bb40
bb40:
  br label %bb41
bb41:
  store i64 -1, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t184, ptr %l115
  br label %bb42
bb42:
  %t185 = load i64, ptr %l115, !tbaa !24
  store i64 %t185, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t186 = load i64, ptr %l19, !tbaa !24
  %t187 = load i64, ptr %l18, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb43, label %bb44
bb43:
  %t192 = load i64, ptr %l20, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb48
bb45:
  %t196 = load i64, ptr %l19, !tbaa !24
  %t197 = load i64, ptr %l18, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l20, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l20, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l122, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb47
bb47:
  %t212 = load i64, ptr %l122, !tbaa !24
  store i64 %t212, ptr %l119, !tbaa !24
  br label %bb48
bb48:
  %t213 = load i64, ptr %l119, !tbaa !24
  store i64 %t213, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb49
bb49:
  %t214 = load i64, ptr %l22, !tbaa !24
  %t215 = load i64, ptr %l21, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb50, label %bb51
bb50:
  br label %bb59
bb51:
  br label %bb52
bb52:
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load i64, ptr %l22, !tbaa !24
  %t224 = load i64, ptr %l20, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  store i64 %t230, ptr %l23, !tbaa !24
  %t232 = load i64, ptr %l23, !tbaa !24
  %t235 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l6, i64 %t232)
  store { i64, ptr } %t235, ptr %l142
  br label %bb53
bb53:
  %t236 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t237, { i64, ptr } %t236)
  store i1 %t239, ptr %l144
  br label %bb54
bb54:
  %t240 = load i1, ptr %l144, !tbaa !21
  br i1 %t240, label %bb55, label %bb56
bb55:
  %t241 = load i64, ptr %l23, !tbaa !24
  store i64 %t241, ptr %l17, !tbaa !24
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t243 = load i64, ptr %l22, !tbaa !24
  %t246 = add i64 %t243, 1
  store i64 %t246, ptr %l22, !tbaa !24
  br label %bb49
bb59:
  %t248 = load i64, ptr %l17, !tbaa !24
  %t250 = icmp slt i64 %t248, 0
  br i1 %t250, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t252 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t252)
  br label %bb62
bb61:
  br label %bb66
bb62:
  store ptr %l7, ptr %l153, !tbaa !29
  %t255 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s11)
  store %"std/prelude/text:StringBuilder" %t255, ptr %l154
  br label %bb63
bb63:
  %t256 = load ptr, ptr %l153, !tbaa !29
  %t257 = load %"std/prelude/text:StringBuilder", ptr %l154
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3_H619e677aa004466b5bd5bdbfda9f24c5(ptr %s0, ptr %s11, ptr %t256, %"std/prelude/text:StringBuilder" %t257)
  br label %bb64
bb64:
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t259, ptr %l156
  br label %bb65
bb65:
  %t260 = load i64, ptr %l156, !tbaa !24
  %t261 = sub i64 %t260, 1
  store i64 %t261, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb66:
  %t263 = load i64, ptr %l17, !tbaa !24
  %t266 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3_Hf1ae1a5ebbb395c2e928aa8f7e1c7e01(ptr %s0, ptr %s0, ptr %l7, i64 %t263)
  store ptr %t266, ptr %l160
  br label %bb67
bb67:
  %t267 = load ptr, ptr %l160, !tbaa !29
  store ptr %t267, ptr %l24, !tbaa !29
  %t268 = load ptr, ptr %l24, !tbaa !29
  %t270 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %t268)
  store i64 %t270, ptr %l162
  br label %bb68
bb68:
  %t271 = load i64, ptr %l162, !tbaa !24
  %t272 = icmp sgt i64 %t271, 0
  br i1 %t272, label %bb69, label %bb70
bb69:
  %t274 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t274, i8 44)
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb72
bb72:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l24, !tbaa !29
  %t278 = load ptr, ptr %l2, !tbaa !29
  %t279 = load ptr, ptr %l3, !tbaa !29
  %t280 = load i64, ptr %l14, !tbaa !24
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2ediagnostic(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %s0, ptr %s0, ptr %v5, ptr %t276, ptr %t277, ptr %t278, ptr %t279, ptr %l8, i64 %t280, { i64, ptr } %t281)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb74:
  %t289 = load i64, ptr %l13, !tbaa !24
  %t292 = add i64 %t289, 1
  store i64 %t292, ptr %l13, !tbaa !24
  br label %bb12
bb75:
  %t294 = call ptr @__olang_scope_hold(ptr %s0)
  %t295 = ptrtoint ptr %t294 to i64
  store i64 %t295, ptr %l175, !tbaa !24
  %t296 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e25
  br i1 %t296, label %bb76, label %bb77
bb76:
  %t298 = call ptr @__olang_region_make(ptr %s0)
  %t299 = ptrtoint ptr %t298 to i64
  store i64 %t299, ptr %l175, !tbaa !24
  br label %bb77
bb77:
  %t300 = load i64, ptr %l175
  %t301 = inttoptr i64 %t300 to ptr
  %t302 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t301)
  store %"std/prelude/text:StringBuilder" %t302, ptr %l177
  br label %bb78
bb78:
  %t303 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e25
  br i1 %t303, label %bb79, label %bb80
bb79:
  %t305 = load i64, ptr %l175
  %t306 = inttoptr i64 %t305 to ptr
  %t307 = getelementptr %"std/prelude/text:StringBuilder", ptr %l177, i32 0, i32 0
  %t308 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t307, i32 0, i32 0
  %t309 = load { i64, ptr }, ptr %t308
  %t310 = extractvalue { i64, ptr } %t309, 1
  %t311 = call ptr @__olang_region_or(ptr %t310, ptr null)
  %t312 = call ptr @__olang_region_home(ptr %t311)
  %t313 = icmp ne ptr %t312, null
  %t314 = select i1 %t313, ptr %t312, ptr null
  call void @__olang_region_settle_in(ptr %t306, ptr %t314)
  br label %bb80
bb80:
  %t315 = load %"std/prelude/text:StringBuilder", ptr %l177
  store %"std/prelude/text:StringBuilder" %t315, ptr %l25
  %t316 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t316, ptr %l179
  br label %bb81
bb81:
  %t317 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l179
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t317, ptr %l26
  store i64 0, ptr %l27, !tbaa !24
  %t319 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t319, ptr %l181
  br label %bb82
bb82:
  %t320 = load i64, ptr %l181, !tbaa !24
  store i64 %t320, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t321 = load i64, ptr %l28, !tbaa !24
  %t322 = load i64, ptr %l27, !tbaa !24
  %t325 = icmp sgt i64 %t321, %t322
  br i1 %t325, label %bb83, label %bb84
bb83:
  %t327 = load i64, ptr %l29, !tbaa !24
  %t329 = icmp sgt i64 %t327, 0
  br i1 %t329, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb88
bb85:
  %t331 = load i64, ptr %l28, !tbaa !24
  %t332 = load i64, ptr %l27, !tbaa !24
  %t335 = sub i64 %t331, %t332
  %t336 = load i64, ptr %l29, !tbaa !24
  %t339 = add i64 %t335, %t336
  %t341 = sub i64 %t339, 1
  %t342 = load i64, ptr %l29, !tbaa !24
  %t345 = sdiv i64 %t341, %t342
  store i64 %t345, ptr %l188, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l188, !tbaa !24
  br label %bb87
bb87:
  %t347 = load i64, ptr %l188, !tbaa !24
  store i64 %t347, ptr %l185, !tbaa !24
  br label %bb88
bb88:
  %t348 = load i64, ptr %l185, !tbaa !24
  store i64 %t348, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb89
bb89:
  %t349 = load i64, ptr %l31, !tbaa !24
  %t350 = load i64, ptr %l30, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb90, label %bb91
bb90:
  br label %bb107
bb91:
  br label %bb92
bb92:
  %t357 = load i64, ptr %l27, !tbaa !24
  %t358 = load i64, ptr %l31, !tbaa !24
  %t359 = load i64, ptr %l29, !tbaa !24
  %t362 = mul i64 %t358, %t359
  %t365 = add i64 %t357, %t362
  store i64 %t365, ptr %l32, !tbaa !24
  %t367 = load i64, ptr %l32, !tbaa !24
  %t370 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l6, i64 %t367)
  store { i64, ptr } %t370, ptr %l208
  br label %bb93
bb93:
  %t371 = load ptr, ptr %l5, !tbaa !29
  %t373 = getelementptr %"compiler/lsp:Doc", ptr %t371, i32 0, i32 2
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  store { i64, ptr } %t374, ptr %l210, !tbaa !27
  %t375 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 1
  %t377 = call ptr @__olang_scope_or(ptr %v5, ptr %t376)
  %t378 = call ptr @__olang_scope_hold(ptr %t377)
  %t379 = ptrtoint ptr %t378 to i64
  %t381 = inttoptr i64 %t379 to ptr
  %t382 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t383 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t384 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %t381, { i64, ptr } %t382, { i64, ptr } %t383)
  store i1 %t384, ptr %l212
  br label %bb94
bb94:
  %t385 = load i1, ptr %l212, !tbaa !21
  br i1 %t385, label %bb95, label %bb96
bb95:
  %t386 = load i64, ptr %l32, !tbaa !24
  %t389 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3_H3391400cd512141e3398528b8c477a4f(ptr %s0, ptr %s0, ptr %l7, i64 %t386)
  store %"std/prelude/text:StringBuilder" %t389, ptr %l215
  br label %bb97
bb96:
  br label %bb105
bb97:
  %t391 = call %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s0, ptr %l215)
  store %"std/prelude/text:StringBuilder" %t391, ptr %l217
  br label %bb98
bb98:
  %t392 = load %"std/prelude/text:StringBuilder", ptr %l25
  store %"std/prelude/text:StringBuilder" %t392, ptr %l218
  %t393 = load %"std/prelude/text:StringBuilder", ptr %l217
  store %"std/prelude/text:StringBuilder" %t393, ptr %l25
  %t394 = load i1, ptr @olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e25
  br i1 %t394, label %bb99, label %bb100
bb99:
  %t396 = getelementptr %"std/prelude/text:StringBuilder", ptr %l218, i32 0, i32 0
  %t397 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t396, i32 0, i32 0
  %t398 = load { i64, ptr }, ptr %t397
  %t399 = extractvalue { i64, ptr } %t398, 1
  %t400 = call ptr @__olang_region_or(ptr %t399, ptr null)
  %t401 = call ptr @__olang_region_home(ptr %t400)
  %t402 = icmp ne ptr %t401, null
  %t403 = select i1 %t402, ptr %t401, ptr null
  call void @__olang_region_drop(ptr %t403)
  store %"std/prelude/text:StringBuilder" zeroinitializer, ptr %l218
  br label %bb100
bb100:
  %t404 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aStringBuilder_2e0
  br i1 %t404, label %bb101, label %bb102
bb101:
  %t406 = getelementptr %"std/prelude/text:StringBuilder", ptr %l218, i32 0, i32 0
  %t407 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t406, i32 0, i32 0
  %t408 = load { i64, ptr }, ptr %t407
  %t409 = extractvalue { i64, ptr } %t408, 1
  %t410 = call ptr @__olang_region_or(ptr %t409, ptr null)
  %t411 = call ptr @__olang_region_home(ptr %t410)
  %t412 = icmp ne ptr %t411, null
  %t413 = select i1 %t412, ptr %t411, ptr null
  call void @__olang_region_drop(ptr %t413)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t406
  br label %bb102
bb102:
  %t414 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2e0
  br i1 %t414, label %bb103, label %bb104
bb103:
  %t416 = getelementptr %"std/prelude/text:StringBuilder", ptr %l218, i32 0, i32 0
  %t417 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t416, i32 0, i32 0
  %t418 = load { i64, ptr }, ptr %t417
  %t419 = extractvalue { i64, ptr } %t418, 0
  %t420 = extractvalue { i64, ptr } %t418, 1
  call void @__olang_region_release_part(ptr %t420, i64 %t419)
  store { i64, ptr } zeroinitializer, ptr %t417
  br label %bb104
bb104:
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t421 = load i64, ptr %l31, !tbaa !24
  %t424 = add i64 %t421, 1
  store i64 %t424, ptr %l31, !tbaa !24
  br label %bb89
bb107:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l2, !tbaa !29
  %t428 = load ptr, ptr %l5, !tbaa !29
  %t430 = getelementptr %"compiler/lsp:Doc", ptr %t428, i32 0, i32 2
  %t431 = load { i64, ptr }, ptr %t430, !tbaa !27
  store { i64, ptr } %t431, ptr %l229, !tbaa !27
  %t432 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t432, 1
  %t434 = call ptr @__olang_scope_or(ptr %v5, ptr %t433)
  %t435 = call ptr @__olang_scope_hold(ptr %t434)
  %t436 = ptrtoint ptr %t435 to i64
  %t438 = inttoptr i64 %t436 to ptr
  %t442 = load { i64, ptr }, ptr %l229, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2edeprecations(ptr %v0, ptr %s0, ptr %v1, ptr %t438, ptr %t426, ptr %l25, ptr %t427, { i64, ptr } %t442)
  br label %bb108
bb108:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l231, !tbaa !29
  %t444 = load ptr, ptr %l5, !tbaa !29
  %t446 = getelementptr %"compiler/lsp:Doc", ptr %t444, i32 0, i32 0
  %t447 = load { i64, ptr }, ptr %t446, !tbaa !27
  store { i64, ptr } %t447, ptr %l233, !tbaa !27
  %t449 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l25)
  store { i64, ptr } %t449, ptr %l235
  br label %bb109
bb109:
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t452 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 1
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = add i64 %t451, %t454
  %t456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t457 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t458 = add i64 %t455, %t457
  %t459 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t458)
  call void @olang_textcopy(ptr %t459, ptr %t450, i64 %t451)
  %t460 = getelementptr i8, ptr %t459, i64 %t451
  call void @olang_textcopy(ptr %t460, ptr %t453, i64 %t454)
  %t461 = getelementptr i8, ptr %t460, i64 %t454
  call void @olang_textcopy(ptr %t461, ptr %t456, i64 %t457)
  %t462 = insertvalue { i64, ptr } undef, i64 %t458, 0
  %t463 = insertvalue { i64, ptr } %t462, ptr %t459, 1
  %t465 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 1
  %t467 = call ptr @__olang_scope_or(ptr %v5, ptr %t466)
  %t468 = call ptr @__olang_scope_hold(ptr %t467)
  %t469 = ptrtoint ptr %t468 to i64
  %t471 = inttoptr i64 %t469 to ptr
  %t472 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t474 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %t471, ptr %s0, ptr %s0, { i64, ptr } %t472, { i64, ptr } %t463)
  store { i64, ptr } %t474, ptr %l239
  br label %bb110
bb110:
  %t475 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t476 = load ptr, ptr %l231, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s0, ptr %t476, { i64, ptr } %t475)
  br label %bb111
bb111:
  store i64 0, ptr %l33, !tbaa !24
  %t479 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t479, ptr %l242
  br label %bb112
bb112:
  %t480 = load i64, ptr %l242, !tbaa !24
  store i64 %t480, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t481 = load i64, ptr %l34, !tbaa !24
  %t482 = load i64, ptr %l33, !tbaa !24
  %t485 = icmp sgt i64 %t481, %t482
  br i1 %t485, label %bb113, label %bb114
bb113:
  %t487 = load i64, ptr %l35, !tbaa !24
  %t489 = icmp sgt i64 %t487, 0
  br i1 %t489, label %bb115, label %bb116
bb114:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb118
bb115:
  %t491 = load i64, ptr %l34, !tbaa !24
  %t492 = load i64, ptr %l33, !tbaa !24
  %t495 = sub i64 %t491, %t492
  %t496 = load i64, ptr %l35, !tbaa !24
  %t499 = add i64 %t495, %t496
  %t501 = sub i64 %t499, 1
  %t502 = load i64, ptr %l35, !tbaa !24
  %t505 = sdiv i64 %t501, %t502
  store i64 %t505, ptr %l249, !tbaa !24
  br label %bb117
bb116:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb117
bb117:
  %t507 = load i64, ptr %l249, !tbaa !24
  store i64 %t507, ptr %l246, !tbaa !24
  br label %bb118
bb118:
  %t508 = load i64, ptr %l246, !tbaa !24
  store i64 %t508, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s20
  %t509 = load i64, ptr %l37, !tbaa !24
  %t510 = load i64, ptr %l36, !tbaa !24
  %t513 = icmp slt i64 %t509, %t510
  %t515 = xor i1 %t513, true
  br i1 %t515, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s20)
  br label %bb141
bb121:
  br label %bb122
bb122:
  %t517 = load i64, ptr %l33, !tbaa !24
  %t518 = load i64, ptr %l37, !tbaa !24
  %t519 = load i64, ptr %l35, !tbaa !24
  %t522 = mul i64 %t518, %t519
  %t525 = add i64 %t517, %t522
  store i64 %t525, ptr %l38, !tbaa !24
  %t527 = load i64, ptr %l38, !tbaa !24
  %t530 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l6, i64 %t527)
  store { i64, ptr } %t530, ptr %l269
  br label %bb123
bb123:
  %t531 = load ptr, ptr %l5, !tbaa !29
  %t533 = getelementptr %"compiler/lsp:Doc", ptr %t531, i32 0, i32 2
  %t534 = load { i64, ptr }, ptr %t533, !tbaa !27
  store { i64, ptr } %t534, ptr %l271, !tbaa !27
  %t535 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 1
  %t537 = call ptr @__olang_scope_or(ptr %v5, ptr %t536)
  %t538 = call ptr @__olang_scope_hold(ptr %t537)
  %t539 = ptrtoint ptr %t538 to i64
  %t541 = inttoptr i64 %t539 to ptr
  %t542 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t543 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t544 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %t541, { i64, ptr } %t542, { i64, ptr } %t543)
  store i1 %t544, ptr %l273
  br label %bb124
bb124:
  %t545 = load i1, ptr %l273, !tbaa !21
  br i1 %t545, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l274, !tbaa !21
  br label %bb129
bb126:
  %t546 = load ptr, ptr %l0, !tbaa !29
  store ptr %t546, ptr %l275, !tbaa !29
  %t547 = load i64, ptr %l38, !tbaa !24
  %t550 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l6, i64 %t547)
  store { i64, ptr } %t550, ptr %l278
  br label %bb127
bb127:
  %t551 = load ptr, ptr %l275, !tbaa !29
  %t552 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t553 = call i1 @compiler_2flsp_2ecompiler_2flsp_3aworker_2eslotPending(ptr %v0, ptr %s0, ptr %v5, ptr %t551, { i64, ptr } %t552)
  store i1 %t553, ptr %l279
  br label %bb128
bb128:
  %t554 = load i1, ptr %l279, !tbaa !21
  store i1 %t554, ptr %l274, !tbaa !21
  br label %bb129
bb129:
  %t555 = load i1, ptr %l274, !tbaa !21
  br i1 %t555, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s20)
  br label %bb140
bb131:
  br label %bb132
bb132:
  %t556 = load ptr, ptr %l0, !tbaa !29
  store ptr %t556, ptr %l280, !tbaa !29
  %t557 = load i64, ptr %l38, !tbaa !24
  %t560 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l6, i64 %t557)
  store { i64, ptr } %t560, ptr %l283
  br label %bb133
bb133:
  %t561 = load ptr, ptr %l280, !tbaa !29
  %t562 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t563 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2euriOf(ptr %v0, ptr %s0, ptr %v4, ptr %v5, ptr %t561, { i64, ptr } %t562)
  store { i64, ptr } %t563, ptr %l284
  br label %bb134
bb134:
  %t564 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t564, ptr %lp39
  %t565 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t566 = load ptr, ptr %lp39
  store { i64, ptr } %t565, ptr %t566, !tbaa !27
  %t567 = load ptr, ptr %l0, !tbaa !29
  store ptr %t567, ptr %l285, !tbaa !29
  %t568 = load ptr, ptr %lp39
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !27
  store { i64, ptr } %t569, ptr %l286, !tbaa !27
  %t570 = load i64, ptr %l38, !tbaa !24
  %t573 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3_H3391400cd512141e3398528b8c477a4f(ptr %s0, ptr %s0, ptr %l7, i64 %t570)
  store %"std/prelude/text:StringBuilder" %t573, ptr %l289
  br label %bb135
bb135:
  %t575 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s20, ptr %l289)
  store { i64, ptr } %t575, ptr %l291
  br label %bb136
bb136:
  %t576 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t577 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t578 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 1
  %t580 = extractvalue { i64, ptr } %t578, 0
  %t581 = add i64 %t577, %t580
  %t582 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t583 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t584 = add i64 %t581, %t583
  %t585 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t584)
  call void @olang_textcopy(ptr %t585, ptr %t576, i64 %t577)
  %t586 = getelementptr i8, ptr %t585, i64 %t577
  call void @olang_textcopy(ptr %t586, ptr %t579, i64 %t580)
  %t587 = getelementptr i8, ptr %t586, i64 %t580
  call void @olang_textcopy(ptr %t587, ptr %t582, i64 %t583)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t585, 1
  %t591 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t593 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v4, ptr %s20, ptr %s20, { i64, ptr } %t591, { i64, ptr } %t589)
  store { i64, ptr } %t593, ptr %l294
  br label %bb137
bb137:
  %t594 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t595 = load ptr, ptr %l285, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s20, ptr %t595, { i64, ptr } %t594)
  br label %bb138
bb138:
  %t597 = load ptr, ptr %lp39
  %t598 = load { i64, ptr }, ptr %t597, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %l26, { i64, ptr } %t598)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s20)
  br label %bb140
bb140:
  %t601 = load i64, ptr %l37, !tbaa !24
  %t604 = add i64 %t601, 1
  store i64 %t604, ptr %l37, !tbaa !24
  br label %bb119
bb141:
  store ptr %a4, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb142
bb142:
  %t608 = load i64, ptr %l41, !tbaa !24
  store i64 %t608, ptr %l302, !tbaa !24
  %t609 = load ptr, ptr %l40, !tbaa !29
  %t611 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t609)
  store i64 %t611, ptr %l304
  br label %bb143
bb143:
  %t612 = load i64, ptr %l302, !tbaa !24
  %t613 = load i64, ptr %l304, !tbaa !24
  %t614 = icmp slt i64 %t612, %t613
  %t616 = xor i1 %t614, true
  br i1 %t616, label %bb144, label %bb145
bb144:
  br label %bb155
bb145:
  br label %bb146
bb146:
  %t618 = load ptr, ptr %l40, !tbaa !29
  %t619 = load i64, ptr %l41, !tbaa !24
  %t622 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t618, i64 %t619)
  store { i64, ptr } %t622, ptr %l309
  br label %bb147
bb147:
  %t623 = load { i64, ptr }, ptr %l309, !tbaa !27
  store { i64, ptr } %t623, ptr %l42, !tbaa !27
  %t624 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t629 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v4, ptr %v3, ptr %l26, { i64, ptr } %t624)
  store i1 %t629, ptr %l313
  br label %bb148
bb148:
  %t630 = load i1, ptr %l313, !tbaa !21
  %t631 = xor i1 %t630, true
  br i1 %t631, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s26
  %t633 = load ptr, ptr %l0, !tbaa !29
  store ptr %t633, ptr %l315, !tbaa !29
  %t634 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t636 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v3, ptr %s26, ptr %s26, { i64, ptr } %t634, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d145, i32 0, i32 1) })
  store { i64, ptr } %t636, ptr %l317
  br label %bb151
bb150:
  br label %bb153
bb151:
  %t637 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t638 = load ptr, ptr %l315, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s26, ptr %t638, { i64, ptr } %t637)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s26)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t640 = load i64, ptr %l41, !tbaa !24
  %t643 = add i64 %t640, 1
  store i64 %t643, ptr %l41, !tbaa !24
  br label %bb142
bb155:
  %t645 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t645, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2erangeOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca i64
  %l17 = alloca i64
  %l25 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Item", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store ptr %a2, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/diag:Item", ptr %t10, i32 0, i32 3
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/diag:Item", ptr %t14, i32 0, i32 4
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/diag:Item", ptr %t18, i32 0, i32 3
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = icmp sgt i64 %t17, %t21
  br i1 %t24, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/diag:Item", ptr %t26, i32 0, i32 4
  %t29 = load i64, ptr %t28, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/diag:Item", ptr %t31, i32 0, i32 3
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l8, !tbaa !29
  %t37 = load ptr, ptr %l9, !tbaa !29
  %t38 = load i64, ptr %l11, !tbaa !24
  %t39 = load i64, ptr %l17, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v2, ptr %v1, ptr %t36, ptr %t37, i64 %t38, i64 %t39)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/diag:Item", ptr %t40, i32 0, i32 5
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/diag:Item", ptr %t47, i32 0, i32 5
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = sub i64 %t50, 1
  store i64 %t52, ptr %l25, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l25, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t61 = call i64 @__olang_fmt_i64(ptr null, i64 %t56)
  %t62 = add i64 %t59, %t61
  %t63 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t67 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t68 = add i64 %t65, %t67
  %t69 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t58, i64 %t59)
  %t73 = getelementptr i8, ptr %t72, i64 %t59
  %t74 = call i64 @__olang_fmt_i64(ptr %t73, i64 %t56)
  %t75 = getelementptr i8, ptr %t73, i64 %t61
  call void @olang_textcopy(ptr %t75, ptr %t63, i64 %t64)
  %t76 = getelementptr i8, ptr %t75, i64 %t64
  %t77 = call i64 @__olang_fmt_i64(ptr %t76, i64 %t57)
  %t78 = getelementptr i8, ptr %t76, i64 %t67
  call void @olang_textcopy(ptr %t78, ptr %t69, i64 %t70)
  %t79 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t72, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t55, { i64, ptr } %t80)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flsp_2ecompiler_2flsp_3aworker_2eslotPending(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:worker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 4
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_scope_or(ptr %v2, ptr %t10)
  %t12 = call ptr @__olang_scope_hold(ptr %t11)
  %t13 = ptrtoint ptr %t12 to i64
  %t15 = inttoptr i64 %t13 to ptr
  %t16 = load ptr, ptr %l9, !tbaa !29
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t15, ptr %t16)
  store i64 %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = load i64, ptr %l8, !tbaa !24
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = call ptr @__olang_scope_or(ptr %v2, ptr %t26)
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t29 to ptr
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t31, ptr %t32, i64 %t25)
  store i64 %t34, ptr %l17
  br label %bb6
bb6:
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lsp:worker", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/lsp:Server", ptr %t39, i32 0, i32 1
  store ptr %t41, ptr %l20, !tbaa !29
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = call ptr @__olang_scope_or(ptr %v2, ptr %t43)
  %t45 = call ptr @__olang_scope_hold(ptr %t44)
  %t46 = ptrtoint ptr %t45 to i64
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lsp:worker", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = call ptr @__olang_scope_or(ptr %v2, ptr %t50)
  %t53 = call ptr @__olang_scope_hold(ptr %t52)
  %t54 = ptrtoint ptr %t53 to i64
  %t56 = inttoptr i64 %t46 to ptr
  %t58 = inttoptr i64 %t54 to ptr
  %t59 = load ptr, ptr %l20, !tbaa !29
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %t56, ptr %t58, ptr %t59, i64 %t35)
  store ptr %t61, ptr %l26
  br label %bb7
bb7:
  %t62 = load ptr, ptr %l26, !tbaa !29
  %t64 = getelementptr %"compiler/lsp:Doc", ptr %t62, i32 0, i32 2
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l28, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = call ptr @__olang_scope_or(ptr %v2, ptr %t68)
  %t70 = call ptr @__olang_scope_hold(ptr %t69)
  %t71 = ptrtoint ptr %t70 to i64
  %t73 = inttoptr i64 %t71 to ptr
  %t74 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t73, ptr %v1, { i64, ptr } %t74, { i64, ptr } %a1)
  store i1 %t76, ptr %l31
  br label %bb8
bb8:
  %t77 = load i1, ptr %l31, !tbaa !21
  br i1 %t77, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t79 = load i64, ptr %l3, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2eframed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t8 = call i64 @__olang_fmt_i64(ptr null, i64 %t3)
  %t9 = add i64 %t6, %t8
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t4, 1
  %t15 = extractvalue { i64, ptr } %t4, 0
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t5, i64 %t6)
  %t18 = getelementptr i8, ptr %t17, i64 %t6
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t3)
  %t20 = getelementptr i8, ptr %t18, i64 %t8
  call void @olang_textcopy(ptr %t20, ptr %t10, i64 %t11)
  %t21 = getelementptr i8, ptr %t20, i64 %t11
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t17, 1
  store { i64, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2flsp_2eframes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l1, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l9, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t6, 0
  store i64 %t9, ptr %l12, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l13, !tbaa !24
  %t12 = icmp sge i64 0, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = icmp sle i64 0, %t14
  br i1 %t15, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_f3afb7cdea72bea9_2e903794abb886a5)
  unreachable
bb4:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = icmp sle i64 %t17, %t18
  br i1 %t19, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f3afb7cdea72bea9_2e903794abb886a5)
  unreachable
bb6:
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l12, !tbaa !24
  %t24 = getelementptr i8, ptr %t22, i64 0
  %t25 = sub i64 %t23, 0
  %t26 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f3afb7cdea72bea9_2e903794abb886a5)
  unreachable
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s1, { i64, ptr } %t29, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d151, i32 0, i32 1) })
  %t32 = extractvalue { i32, i64 } %t31, 1
  %t33 = extractvalue { i32, i64 } %t31, 0
  store i32 %t33, ptr %l21
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35, !prof !99
ok.35:
  store i64 %t32, ptr %l20
  br label %bb9
bb9:
  %t36 = load i64, ptr %l20, !tbaa !24
  store i64 %t36, ptr %l18, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb12:
  %t37 = load i64, ptr %l18, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  %t41 = add i64 %t37, 16
  store i64 %t41, ptr %l24, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t42, 0
  store i64 %t45, ptr %l27, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l24, !tbaa !24
  %t52 = load i64, ptr %l27, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8c5172bb8ea5e6bc_75de6e53c7815648)
  unreachable
bb15:
  %t55 = load i64, ptr %l27, !tbaa !24
  %t56 = load i64, ptr %l28, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8c5172bb8ea5e6bc_75de6e53c7815648)
  unreachable
bb17:
  %t59 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = load i64, ptr %l27, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s1, { i64, ptr } %t68, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d152, i32 0, i32 1) })
  %t71 = extractvalue { i32, i64 } %t70, 1
  %t72 = extractvalue { i32, i64 } %t70, 0
  store i32 %t72, ptr %l36
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb20, label %ok.74, !prof !99
ok.74:
  store i64 %t71, ptr %l35
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8c5172bb8ea5e6bc_75de6e53c7815648)
  unreachable
bb19:
  %t75 = load i64, ptr %l35, !tbaa !24
  store i64 %t75, ptr %l33, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb22:
  %t76 = load i64, ptr %l33, !tbaa !24
  store i64 %t76, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t77, ptr %l38, !tbaa !27
  %t78 = load i64, ptr %l5, !tbaa !24
  store i64 %t78, ptr %l39, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l40, !tbaa !24
  %t81 = icmp sge i64 0, 0
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t83 = load i64, ptr %l39, !tbaa !24
  %t84 = icmp sle i64 0, %t83
  br i1 %t84, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_6f843a9f898efe67_8723688731f48c63)
  unreachable
bb25:
  %t86 = load i64, ptr %l39, !tbaa !24
  %t87 = load i64, ptr %l40, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_6f843a9f898efe67_8723688731f48c63)
  unreachable
bb27:
  %t90 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l39, !tbaa !24
  %t93 = getelementptr i8, ptr %t91, i64 0
  %t94 = sub i64 %t92, 0
  %t95 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t98 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s1, { i64, ptr } %t96)
  store { i64, ptr } %t98, ptr %l45
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_6f843a9f898efe67_8723688731f48c63)
  unreachable
bb29:
  %t99 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 10)
  %t100 = extractvalue { i32, i64 } %t99, 1
  %t101 = extractvalue { i32, i64 } %t99, 0
  store i32 %t101, ptr %l47
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb31, label %ok.103, !prof !99
ok.103:
  store i64 %t100, ptr %l46
  br label %bb30
bb30:
  %t104 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t105 = load i64, ptr %l46, !tbaa !24
  %t106 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s1, { i64, ptr } %t104, i64 %t105)
  %t107 = extractvalue { i32, i64 } %t106, 1
  %t108 = extractvalue { i32, i64 } %t106, 0
  store i32 %t108, ptr %l49
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb34, label %ok.110, !prof !99
ok.110:
  store i64 %t107, ptr %l48
  br label %bb33
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb33:
  %t111 = load i64, ptr %l48, !tbaa !24
  store i64 %t111, ptr %l37, !tbaa !24
  br label %bb35
bb34:
  br label %bb32
bb35:
  %t112 = load i64, ptr %l37, !tbaa !24
  store i64 %t112, ptr %l6, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = add i64 %t116, 4
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t125 = icmp slt i64 %t115, %t122
  br i1 %t125, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb37:
  br label %bb38
bb38:
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l57, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l58, !tbaa !27
  %t129 = load i64, ptr %l5, !tbaa !24
  %t131 = add i64 %t129, 4
  store i64 %t131, ptr %l60, !tbaa !24
  %t132 = load i64, ptr %l5, !tbaa !24
  %t134 = add i64 %t132, 4
  %t135 = load i64, ptr %l6, !tbaa !24
  %t138 = add i64 %t134, %t135
  store i64 %t138, ptr %l64, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l65, !tbaa !24
  %t141 = load i64, ptr %l60, !tbaa !24
  %t142 = icmp sge i64 %t141, 0
  br i1 %t142, label %bb39, label %bb40
bb39:
  %t144 = load i64, ptr %l60, !tbaa !24
  %t145 = load i64, ptr %l64, !tbaa !24
  %t146 = icmp sle i64 %t144, %t145
  br i1 %t146, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8f54b2067e6b6b8a_86cbf1b666cce186)
  unreachable
bb41:
  %t148 = load i64, ptr %l64, !tbaa !24
  %t149 = load i64, ptr %l65, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8f54b2067e6b6b8a_86cbf1b666cce186)
  unreachable
bb43:
  %t152 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l60, !tbaa !24
  %t155 = load i64, ptr %l64, !tbaa !24
  %t156 = getelementptr i8, ptr %t153, i64 %t154
  %t157 = sub i64 %t155, %t154
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t160 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %t160, { i64, ptr } %t159)
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_8f54b2067e6b6b8a_86cbf1b666cce186)
  unreachable
bb45:
  %t162 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t162, ptr %l70, !tbaa !27
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = add i64 %t163, 4
  %t166 = load i64, ptr %l6, !tbaa !24
  %t169 = add i64 %t165, %t166
  store i64 %t169, ptr %l74, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t170, 0
  store i64 %t173, ptr %l77, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 0
  store i64 %t175, ptr %l78, !tbaa !24
  %t176 = load i64, ptr %l74, !tbaa !24
  %t177 = icmp sge i64 %t176, 0
  br i1 %t177, label %bb46, label %bb47
bb46:
  %t179 = load i64, ptr %l74, !tbaa !24
  %t180 = load i64, ptr %l77, !tbaa !24
  %t181 = icmp sle i64 %t179, %t180
  br i1 %t181, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_c8d49224b0a3e505_8d1f0d35a00e1b49)
  unreachable
bb48:
  %t183 = load i64, ptr %l77, !tbaa !24
  %t184 = load i64, ptr %l78, !tbaa !24
  %t185 = icmp sle i64 %t183, %t184
  br i1 %t185, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_c8d49224b0a3e505_8d1f0d35a00e1b49)
  unreachable
bb50:
  %t187 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = load i64, ptr %l74, !tbaa !24
  %t190 = load i64, ptr %l77, !tbaa !24
  %t191 = getelementptr i8, ptr %t188, i64 %t189
  %t192 = sub i64 %t190, %t189
  %t193 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  store { i64, ptr } %t194, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_c8d49224b0a3e505_8d1f0d35a00e1b49)
  unreachable
bb52:
  br label %bb8
bb53:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2flsp_2elspSaid(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca [3 x { i64, ptr }]
  %l7 = alloca %"std/os:Output"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"std/os:Output"
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca %"std/os:Output"
  %l60 = alloca i32
  %l62 = alloca i1
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca ptr
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i32
  %l84 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca i32
  %l101 = alloca i1
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca i32
  %l122 = alloca i1
  %l132 = alloca { i64, ptr }
  %l135 = alloca i64
  %l138 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca i32
  %l143 = alloca i1
  %l148 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca i32
  %l153 = alloca i1
  %l157 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l160 = alloca i32
  %l162 = alloca i1
  %l165 = alloca i64
  %l166 = alloca i32
  %l168 = alloca i1
  %l171 = alloca i64
  %l173 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca i32
  %l178 = alloca i1
  %l181 = alloca i64
  %l182 = alloca i32
  %l184 = alloca i1
  %l188 = alloca ptr
  %l189 = alloca i64
  %l191 = alloca { i64, ptr }
  %l193 = alloca i64
  %l195 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l210 = alloca { { i64, ptr }, { i64, ptr } }
  %l211 = alloca { i64, ptr }
  %l212 = alloca i64
  %l213 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2flsp_2eUriOf(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l23
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t6, ptr %l3
  %t7 = load { i64, ptr }, ptr @G_2ecompiler_2flsp_2eStepMain, !tbaa !27
  %t8 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %t8, ptr %l3, { i64, ptr } %t7)
  br label %bb3
bb3:
  %t11 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t11, ptr %l26
  br label %bb4
bb4:
  %t12 = load %"std/prelude/text:StringBuilder", ptr %l26
  store %"std/prelude/text:StringBuilder" %t12, ptr %l4
  store ptr %l4, ptr %l27, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2flsp_2eframed(ptr %s0, ptr %s0, { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store { i64, ptr } %t13, ptr %l28
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t15 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t15, { i64, ptr } %t14)
  br label %bb6
bb6:
  store ptr %l4, ptr %l30, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l31, !tbaa !27
  %t19 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t19, ptr %l33
  br label %bb7
bb7:
  %t20 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t22 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t20, i64 %t21)
  %t37 = getelementptr i8, ptr %t36, i64 %t21
  call void @olang_textcopy(ptr %t37, ptr %t23, i64 %t24)
  %t38 = getelementptr i8, ptr %t37, i64 %t24
  call void @olang_textcopy(ptr %t38, ptr %t26, i64 %t27)
  %t39 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t30, i64 %t31)
  %t40 = getelementptr i8, ptr %t39, i64 %t31
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t36, 1
  %t45 = call { i64, ptr } @compiler_2flsp_2eframed(ptr %s0, ptr %s0, { i64, ptr } %t42)
  store { i64, ptr } %t45, ptr %l36
  br label %bb8
bb8:
  %t46 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t47 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t47, { i64, ptr } %t46)
  br label %bb9
bb9:
  store ptr %l4, ptr %l38, !tbaa !29
  %t49 = call { i64, ptr } @compiler_2flsp_2eframed(ptr %s0, ptr %s0, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d157, i32 0, i32 1) })
  store { i64, ptr } %t49, ptr %l39
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t51 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t51, { i64, ptr } %t50)
  br label %bb11
bb11:
  store ptr %l4, ptr %l41, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2flsp_2eframed(ptr %s0, ptr %s0, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d158, i32 0, i32 1) })
  store { i64, ptr } %t53, ptr %l42
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t55 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t55, { i64, ptr } %t54)
  br label %bb13
bb13:
  %t59 = call { i64, ptr } @std_2fos_2eQuote(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t59, ptr %l45
  br label %bb14
bb14:
  %t60 = call { i64, ptr } @compiler_2flsp_2ecompilerUnderTest(ptr %s0)
  store { i64, ptr } %t60, ptr %l46
  br label %bb15
bb15:
  %t61 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t63 = call { i64, ptr } @std_2fos_2eQuote(ptr %s0, ptr %s0, { i64, ptr } %t61)
  store { i64, ptr } %t63, ptr %l48
  br label %bb16
bb16:
  %t64 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t66 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t64, i64 %t65)
  %t81 = getelementptr i8, ptr %t80, i64 %t65
  call void @olang_textcopy(ptr %t81, ptr %t67, i64 %t68)
  %t82 = getelementptr i8, ptr %t81, i64 %t68
  call void @olang_textcopy(ptr %t82, ptr %t70, i64 %t71)
  %t83 = getelementptr i8, ptr %t82, i64 %t71
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t80, 1
  %t89 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t90 = insertvalue [3 x { i64, ptr }] %t89, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t92 = insertvalue [3 x { i64, ptr }] %t90, { i64, ptr } %t86, 2
  store [3 x { i64, ptr }] %t92, ptr %l6
  %t95 = insertvalue { i64, ptr } undef, i64 3, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %l6, 1
  store { i64, ptr } %t96, ptr %l54, !tbaa !27
  %t98 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t98, ptr %l56
  br label %bb17
bb17:
  %t99 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t109 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t107, { i64, ptr } %t106, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  %t110 = extractvalue { i32, %"std/os:Output" } %t109, 1
  %t111 = extractvalue { i32, %"std/os:Output" } %t109, 0
  store i32 %t111, ptr %l60
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb19, label %ok.113, !prof !99
ok.113:
  store %"std/os:Output" %t110, ptr %l59
  br label %bb18
bb18:
  %t114 = load %"std/os:Output", ptr %l59
  store %"std/os:Output" %t114, ptr %l50
  br label %bb23
bb19:
  %t115 = load i32, ptr %l60, !tbaa !23
  %t116 = ashr i32 %t115, 16
  %t118 = icmp eq i32 %t116, 1
  store i1 %t118, ptr %l62, !tbaa !21
  %t119 = load i32, ptr %l60, !tbaa !23
  %t120 = ashr i32 %t119, 16
  %t122 = icmp eq i32 %t120, 1
  br i1 %t122, label %bb20, label %bb21
bb20:
  call void @__olang_errpay_pop()
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t124 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t126 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t124, 1
  call void @__olang_check_failed_text(ptr @olang_loc_e95ee7c974268826_dbe3ca405aac726a, { i64, ptr } %t127)
  unreachable
bb23:
  %t128 = load %"std/os:Output", ptr %l50
  store %"std/os:Output" %t128, ptr %l7
  %t129 = getelementptr %"std/os:Output", ptr %l7, i32 0, i32 0
  %t130 = load i32, ptr %t129, !tbaa !23
  %t132 = icmp eq i32 %t130, 0
  br i1 %t132, label %bb24, label %bb25
bb24:
  %t134 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l68
  br label %bb26
bb25:
  %t135 = getelementptr %"std/os:Output", ptr %l7, i32 0, i32 2
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = extractvalue { i64, ptr } %t136, 0
  %t140 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  call void @__olang_check_failed_text(ptr @olang_loc_e0c8a6c727c459ae_6ecdb6d914c5403a, { i64, ptr } %t141)
  unreachable
bb26:
  %t142 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %l8
  store %olang.scope zeroinitializer, ptr %s4
  %t143 = getelementptr %"std/os:Output", ptr %l7, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t146 = call ptr @compiler_2flsp_2eframes(ptr %s0, ptr %s4, { i64, ptr } %t144)
  store ptr %t146, ptr %l70
  br label %bb27
bb27:
  %t147 = load ptr, ptr %l70, !tbaa !29
  store ptr %t147, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load i64, ptr %l10, !tbaa !24
  store i64 %t148, ptr %l71, !tbaa !24
  %t149 = load ptr, ptr %l9, !tbaa !29
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s4, ptr %t149)
  store i64 %t151, ptr %l73
  br label %bb29
bb29:
  %t152 = load i64, ptr %l71, !tbaa !24
  %t153 = load i64, ptr %l73, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb106
bb31:
  br label %bb32
bb32:
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t159 = load i64, ptr %l10, !tbaa !24
  %t162 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s4, ptr %s4, ptr %t158, i64 %t159)
  store { i64, ptr } %t162, ptr %l78
  br label %bb33
bb33:
  %t163 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t163, ptr %l11, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t166 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %s4, ptr %s5, { i64, ptr } %t164)
  %t167 = extractvalue { i32, ptr } %t166, 1
  %t168 = extractvalue { i32, ptr } %t166, 0
  store i32 %t168, ptr %l82
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb35, label %ok.170, !prof !99
ok.170:
  store ptr %t167, ptr %l81
  br label %bb34
bb34:
  %t171 = load ptr, ptr %l81, !tbaa !29
  store ptr %t171, ptr %l79, !tbaa !29
  br label %bb39
bb35:
  %t172 = load i32, ptr %l82, !tbaa !23
  %t173 = ashr i32 %t172, 16
  %t175 = icmp eq i32 %t173, 1
  store i1 %t175, ptr %l84, !tbaa !21
  %t176 = load i32, ptr %l82, !tbaa !23
  %t177 = ashr i32 %t176, 16
  %t179 = icmp eq i32 %t177, 1
  br i1 %t179, label %bb36, label %bb37
bb36:
  call void @__olang_errpay_pop()
  br label %bb37
bb37:
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t181 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t182 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t185 = extractvalue { i64, ptr } %t181, 1
  %t186 = extractvalue { i64, ptr } %t181, 0
  %t187 = add i64 %t183, %t186
  %t188 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t187)
  call void @olang_textcopy(ptr %t188, ptr %t182, i64 %t183)
  %t189 = getelementptr i8, ptr %t188, i64 %t183
  call void @olang_textcopy(ptr %t189, ptr %t185, i64 %t186)
  %t190 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t188, 1
  %t194 = extractvalue { i64, ptr } %t191, 1
  %t195 = extractvalue { i64, ptr } %t191, 0
  %t196 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t194, 1
  call void @__olang_check_failed_text(ptr @olang_loc_6196fce1a841dab8_1c2f84dff31e5f9c, { i64, ptr } %t197)
  unreachable
bb39:
  %t198 = load ptr, ptr %l79, !tbaa !29
  store ptr %t198, ptr %l12, !tbaa !29
  %t199 = load ptr, ptr %l12, !tbaa !29
  %t201 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s5, ptr %s5, ptr %s5, ptr %t199, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) })
  store { i64, ptr } %t201, ptr %l91
  br label %bb40
bb40:
  %t202 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t202, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d167, i32 0, i32 1) })
  store i1 %t203, ptr %l92
  br label %bb41
bb41:
  %t204 = load i1, ptr %l92, !tbaa !21
  %t205 = xor i1 %t204, true
  br i1 %t205, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb105
bb43:
  br label %bb44
bb44:
  %t207 = load ptr, ptr %l12, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d168, i32 0, i32 1) }, ptr %l96, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t211 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s5, ptr %s5, ptr %t207, { i64, ptr } %t208)
  %t212 = extractvalue { i32, ptr } %t211, 1
  %t213 = extractvalue { i32, ptr } %t211, 0
  store i32 %t213, ptr %l99
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb46, label %ok.215, !prof !99
ok.215:
  store ptr %t212, ptr %l98
  br label %bb45
bb45:
  %t216 = load ptr, ptr %l98, !tbaa !29
  store ptr %t216, ptr %l94, !tbaa !29
  br label %bb50
bb46:
  %t217 = load i32, ptr %l99, !tbaa !23
  %t218 = ashr i32 %t217, 16
  %t220 = icmp eq i32 %t218, 1
  store i1 %t220, ptr %l101, !tbaa !21
  %t221 = load i32, ptr %l99, !tbaa !23
  %t222 = ashr i32 %t221, 16
  %t224 = icmp eq i32 %t222, 1
  br i1 %t224, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb105
bb50:
  %t226 = load ptr, ptr %l94, !tbaa !29
  store ptr %t226, ptr %l13, !tbaa !29
  %t227 = load ptr, ptr %l13, !tbaa !29
  %t229 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s5, ptr %s5, ptr %s5, ptr %t227, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d169, i32 0, i32 1) })
  store { i64, ptr } %t229, ptr %l105
  br label %bb51
bb51:
  %t230 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t231 = call { i64, ptr } @compiler_2flsp_2ePathOf(ptr %s5, ptr %s5, { i64, ptr } %t230)
  store { i64, ptr } %t231, ptr %l106
  br label %bb52
bb52:
  %t232 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t234 = call { i64, ptr } @compiler_2flsp_2ebaseName(ptr %s5, ptr %s5, { i64, ptr } %t232)
  store { i64, ptr } %t234, ptr %l108
  br label %bb53
bb53:
  %t235 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t235, ptr %l14, !tbaa !27
  %t236 = load ptr, ptr %l13, !tbaa !29
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d170, i32 0, i32 1) }, ptr %l111, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t240 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s5, ptr %s5, ptr %t236, { i64, ptr } %t237)
  %t241 = extractvalue { i32, ptr } %t240, 1
  %t242 = extractvalue { i32, ptr } %t240, 0
  store i32 %t242, ptr %l114
  %t243 = icmp ne i32 %t242, 0
  br i1 %t243, label %bb55, label %ok.244, !prof !99
ok.244:
  store ptr %t241, ptr %l113
  br label %bb54
bb54:
  %t245 = load ptr, ptr %l113, !tbaa !29
  %t246 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s5, ptr %s5, ptr %t245)
  %t247 = extractvalue { i32, { i64, ptr } } %t246, 1
  %t248 = extractvalue { i32, { i64, ptr } } %t246, 0
  store i32 %t248, ptr %l120
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb60, label %ok.250, !prof !99
ok.250:
  store { i64, ptr } %t247, ptr %l119
  br label %bb59
bb55:
  %t251 = load i32, ptr %l114, !tbaa !23
  %t252 = ashr i32 %t251, 16
  %t254 = icmp eq i32 %t252, 1
  store i1 %t254, ptr %l116, !tbaa !21
  %t255 = load i32, ptr %l114, !tbaa !23
  %t256 = ashr i32 %t255, 16
  %t258 = icmp eq i32 %t256, 1
  br i1 %t258, label %bb56, label %bb57
bb56:
  call void @__olang_errpay_pop()
  br label %bb57
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s5)
  br label %bb105
bb59:
  %t260 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t260, ptr %l109, !tbaa !27
  br label %bb63
bb60:
  %t261 = load i32, ptr %l120, !tbaa !23
  %t262 = ashr i32 %t261, 16
  %t264 = icmp eq i32 %t262, 1
  store i1 %t264, ptr %l122, !tbaa !21
  %t265 = load i32, ptr %l120, !tbaa !23
  %t266 = ashr i32 %t265, 16
  %t268 = icmp eq i32 %t266, 1
  br i1 %t268, label %bb61, label %bb62
bb61:
  call void @__olang_errpay_pop()
  br label %bb62
bb62:
  br label %bb58
bb63:
  %t270 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t270, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t273 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t273, 0
  store i64 %t275, ptr %l18, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t277 = load i64, ptr %l17, !tbaa !24
  %t278 = load i64, ptr %l18, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s12)
  br label %bb104
bb66:
  br label %bb67
bb67:
  %t285 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t285, ptr %l132, !tbaa !27
  %t286 = load i64, ptr %l17, !tbaa !24
  %t288 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr ptr, ptr %t289, i64 %t286
  %t291 = load ptr, ptr %t290, !tbaa !39
  store ptr %t291, ptr %l19, !tbaa !29
  %t293 = load ptr, ptr %l19, !tbaa !29
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d171, i32 0, i32 1) }, ptr %l138, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t298 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s5, ptr %s5, ptr %t293, { i64, ptr } %t295)
  %t299 = extractvalue { i32, ptr } %t298, 1
  %t300 = extractvalue { i32, ptr } %t298, 0
  store i32 %t300, ptr %l141
  %t301 = icmp ne i32 %t300, 0
  br i1 %t301, label %bb69, label %ok.302, !prof !99
ok.302:
  store ptr %t299, ptr %l140
  br label %bb68
bb68:
  %t303 = load ptr, ptr %l140, !tbaa !29
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d172, i32 0, i32 1) }, ptr %l148, !tbaa !27
  %t305 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t308 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s5, ptr %s5, ptr %t303, { i64, ptr } %t305)
  %t309 = extractvalue { i32, ptr } %t308, 1
  %t310 = extractvalue { i32, ptr } %t308, 0
  store i32 %t310, ptr %l151
  %t311 = icmp ne i32 %t310, 0
  br i1 %t311, label %bb74, label %ok.312, !prof !99
ok.312:
  store ptr %t309, ptr %l150
  br label %bb73
bb69:
  %t313 = load i32, ptr %l141, !tbaa !23
  %t314 = ashr i32 %t313, 16
  %t316 = icmp eq i32 %t314, 1
  store i1 %t316, ptr %l143, !tbaa !21
  %t317 = load i32, ptr %l141, !tbaa !23
  %t318 = ashr i32 %t317, 16
  %t320 = icmp eq i32 %t318, 1
  br i1 %t320, label %bb70, label %bb71
bb70:
  call void @__olang_errpay_pop()
  br label %bb71
bb71:
  br label %bb72
bb72:
  store i64 -1, ptr %l135, !tbaa !24
  br label %bb85
bb73:
  %t322 = load ptr, ptr %l150, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d173, i32 0, i32 1) }, ptr %l157, !tbaa !27
  %t323 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t326 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s5, ptr %s12, ptr %t322, { i64, ptr } %t323)
  %t327 = extractvalue { i32, ptr } %t326, 1
  %t328 = extractvalue { i32, ptr } %t326, 0
  store i32 %t328, ptr %l160
  %t329 = icmp ne i32 %t328, 0
  br i1 %t329, label %bb78, label %ok.330, !prof !99
ok.330:
  store ptr %t327, ptr %l159
  br label %bb77
bb74:
  %t331 = load i32, ptr %l151, !tbaa !23
  %t332 = ashr i32 %t331, 16
  %t334 = icmp eq i32 %t332, 1
  store i1 %t334, ptr %l153, !tbaa !21
  %t335 = load i32, ptr %l151, !tbaa !23
  %t336 = ashr i32 %t335, 16
  %t338 = icmp eq i32 %t336, 1
  br i1 %t338, label %bb75, label %bb76
bb75:
  call void @__olang_errpay_pop()
  br label %bb76
bb76:
  br label %bb72
bb77:
  %t340 = load ptr, ptr %l159, !tbaa !29
  %t341 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s12, ptr %t340)
  %t342 = extractvalue { i32, i64 } %t341, 1
  %t343 = extractvalue { i32, i64 } %t341, 0
  store i32 %t343, ptr %l166
  %t344 = icmp ne i32 %t343, 0
  br i1 %t344, label %bb82, label %ok.345, !prof !99
ok.345:
  store i64 %t342, ptr %l165
  br label %bb81
bb78:
  %t346 = load i32, ptr %l160, !tbaa !23
  %t347 = ashr i32 %t346, 16
  %t349 = icmp eq i32 %t347, 1
  store i1 %t349, ptr %l162, !tbaa !21
  %t350 = load i32, ptr %l160, !tbaa !23
  %t351 = ashr i32 %t350, 16
  %t353 = icmp eq i32 %t351, 1
  br i1 %t353, label %bb79, label %bb80
bb79:
  call void @__olang_errpay_pop()
  br label %bb80
bb80:
  br label %bb72
bb81:
  %t355 = load i64, ptr %l165, !tbaa !24
  store i64 %t355, ptr %l135, !tbaa !24
  br label %bb85
bb82:
  %t356 = load i32, ptr %l166, !tbaa !23
  %t357 = ashr i32 %t356, 16
  %t359 = icmp eq i32 %t357, 1
  store i1 %t359, ptr %l168, !tbaa !21
  %t360 = load i32, ptr %l166, !tbaa !23
  %t361 = ashr i32 %t360, 16
  %t363 = icmp eq i32 %t361, 1
  br i1 %t363, label %bb83, label %bb84
bb83:
  call void @__olang_errpay_pop()
  br label %bb84
bb84:
  br label %bb72
bb85:
  %t365 = load i64, ptr %l135, !tbaa !24
  store i64 %t365, ptr %l20, !tbaa !24
  %t366 = load ptr, ptr %l19, !tbaa !29
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l173, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t370 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s5, ptr %s5, ptr %t366, { i64, ptr } %t367)
  %t371 = extractvalue { i32, ptr } %t370, 1
  %t372 = extractvalue { i32, ptr } %t370, 0
  store i32 %t372, ptr %l176
  %t373 = icmp ne i32 %t372, 0
  br i1 %t373, label %bb87, label %ok.374, !prof !99
ok.374:
  store ptr %t371, ptr %l175
  br label %bb86
bb86:
  %t375 = load ptr, ptr %l175, !tbaa !29
  %t376 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s5, ptr %t375)
  %t377 = extractvalue { i32, i64 } %t376, 1
  %t378 = extractvalue { i32, i64 } %t376, 0
  store i32 %t378, ptr %l182
  %t379 = icmp ne i32 %t378, 0
  br i1 %t379, label %bb92, label %ok.380, !prof !99
ok.380:
  store i64 %t377, ptr %l181
  br label %bb91
bb87:
  %t381 = load i32, ptr %l176, !tbaa !23
  %t382 = ashr i32 %t381, 16
  %t384 = icmp eq i32 %t382, 1
  store i1 %t384, ptr %l178, !tbaa !21
  %t385 = load i32, ptr %l176, !tbaa !23
  %t386 = ashr i32 %t385, 16
  %t388 = icmp eq i32 %t386, 1
  br i1 %t388, label %bb88, label %bb89
bb88:
  call void @__olang_errpay_pop()
  br label %bb89
bb89:
  br label %bb90
bb90:
  store i64 1, ptr %l171, !tbaa !24
  br label %bb95
bb91:
  %t390 = load i64, ptr %l181, !tbaa !24
  store i64 %t390, ptr %l171, !tbaa !24
  br label %bb95
bb92:
  %t391 = load i32, ptr %l182, !tbaa !23
  %t392 = ashr i32 %t391, 16
  %t394 = icmp eq i32 %t392, 1
  store i1 %t394, ptr %l184, !tbaa !21
  %t395 = load i32, ptr %l182, !tbaa !23
  %t396 = ashr i32 %t395, 16
  %t398 = icmp eq i32 %t396, 1
  br i1 %t398, label %bb93, label %bb94
bb93:
  call void @__olang_errpay_pop()
  br label %bb94
bb94:
  br label %bb90
bb95:
  %t400 = load i64, ptr %l171, !tbaa !24
  %t401 = icmp sle i64 %t400, 2
  br i1 %t401, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l8, ptr %l188, !tbaa !29
  %t403 = call ptr @__olang_scope_hold(ptr %s0)
  %t404 = ptrtoint ptr %t403 to i64
  store i64 %t404, ptr %l189, !tbaa !24
  %t405 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t405, label %bb98, label %bb99
bb97:
  br label %bb102
bb98:
  %t407 = call ptr @__olang_region_make(ptr %s0)
  %t408 = ptrtoint ptr %t407 to i64
  store i64 %t408, ptr %l189, !tbaa !24
  br label %bb99
bb99:
  %t409 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t409, ptr %l191, !tbaa !27
  %t410 = load i64, ptr %l20, !tbaa !24
  %t412 = add i64 %t410, 1
  store i64 %t412, ptr %l193, !tbaa !24
  %t413 = load ptr, ptr %l19, !tbaa !29
  %t415 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s5, ptr %s13, ptr %s13, ptr %t413, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d175, i32 0, i32 1) })
  store { i64, ptr } %t415, ptr %l195
  br label %bb100
bb100:
  %t416 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t416, 1
  %t418 = extractvalue { i64, ptr } %t416, 0
  %t419 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t420 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t421 = add i64 %t418, %t420
  %t422 = load i64, ptr %l193, !tbaa !24
  %t423 = call i64 @__olang_fmt_i64(ptr null, i64 %t422)
  %t424 = add i64 %t421, %t423
  %t425 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t426 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t427 = add i64 %t424, %t426
  %t428 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t428, 1
  %t430 = extractvalue { i64, ptr } %t428, 0
  %t431 = add i64 %t427, %t430
  %t432 = load i64, ptr %l189
  %t433 = inttoptr i64 %t432 to ptr
  %t434 = call ptr @__olang_held_alloc(ptr %t433, i64 %t431)
  call void @olang_textcopy(ptr %t434, ptr %t417, i64 %t418)
  %t435 = getelementptr i8, ptr %t434, i64 %t418
  call void @olang_textcopy(ptr %t435, ptr %t419, i64 %t420)
  %t436 = getelementptr i8, ptr %t435, i64 %t420
  %t437 = call i64 @__olang_fmt_i64(ptr %t436, i64 %t422)
  %t438 = getelementptr i8, ptr %t436, i64 %t423
  call void @olang_textcopy(ptr %t438, ptr %t425, i64 %t426)
  %t439 = getelementptr i8, ptr %t438, i64 %t426
  call void @olang_textcopy(ptr %t439, ptr %t429, i64 %t430)
  %t440 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t434, 1
  %t443 = load ptr, ptr %l188, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t443, { i64, ptr } %t441)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s13)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s12)
  br label %bb103
bb103:
  %t445 = load i64, ptr %l17, !tbaa !24
  %t448 = add i64 %t445, 1
  store i64 %t448, ptr %l17, !tbaa !24
  br label %bb64
bb104:
  call void @__olang_scope_close(ptr %s5)
  br label %bb105
bb105:
  %t450 = load i64, ptr %l10, !tbaa !24
  %t453 = add i64 %t450, 1
  store i64 %t453, ptr %l10, !tbaa !24
  br label %bb28
bb106:
  call void @__olang_scope_close(ptr %s4)
  %t455 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_177, 0
  %t456 = insertvalue { ptr, ptr } %t455, ptr null, 1
  %t459 = extractvalue { ptr, ptr } %t456, 0
  %t460 = extractvalue { ptr, ptr } %t456, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l8, ptr %t459, ptr %t460)
  br label %bb107
bb107:
  %t462 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %v2, ptr %l8, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d178, i32 0, i32 1) })
  store { i64, ptr } %t462, ptr %l207
  br label %bb108
bb108:
  %t463 = getelementptr %"std/os:Output", ptr %l7, i32 0, i32 2
  %t464 = load { i64, ptr }, ptr %t463, !tbaa !27
  %t466 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t467 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t466, 0
  %t469 = insertvalue { { i64, ptr }, { i64, ptr } } %t467, { i64, ptr } %t464, 1
  store { { i64, ptr }, { i64, ptr } } %t469, ptr %l210
  %t470 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l210, i32 0, i32 1
  %t471 = load { i64, ptr }, ptr %t470, !tbaa !27
  store { i64, ptr } %t471, ptr %l211, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t472, 0
  store i64 %t473, ptr %l212, !tbaa !24
  %t474 = load i64, ptr %l212, !tbaa !24
  %t475 = mul i64 %t474, 1
  %t476 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t475)
  %t477 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t476, 1
  store { i64, ptr } %t478, ptr %l213, !tbaa !27
  %t479 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !27
  %t481 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = load i64, ptr %l212, !tbaa !24
  %t484 = mul i64 %t483, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t480, ptr %t482, i64 %t484, i1 false)
  %t485 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t486 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l210, i32 0, i32 1
  store { i64, ptr } %t485, ptr %t486, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t487 = load { { i64, ptr }, { i64, ptr } }, ptr %l210
  store { { i64, ptr }, { i64, ptr } } %t487, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2flsp_2eseverityOf(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fdiag_2eUntidy(ptr %v0, { i64, ptr } %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i64 2, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flsp_3aDoc_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"compiler/lsp:Doc"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  %t7 = call ptr @__olang_scope_hold(ptr %v3)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e3
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = call ptr @__olang_region_make(ptr %v3)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l13, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l13
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t14)
  store %"std/prelude/text:StringBuilder" %t15, ptr %l15
  br label %bb3
bb3:
  %t16 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e3
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l13
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = getelementptr %"std/prelude/text:StringBuilder", ptr %l15, i32 0, i32 0
  %t21 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t20, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = call ptr @__olang_region_home(ptr %t24)
  %t26 = icmp ne ptr %t25, null
  %t27 = select i1 %t26, ptr %t25, ptr null
  call void @__olang_region_settle_in(ptr %t19, ptr %t27)
  br label %bb5
bb5:
  %t28 = load %"std/prelude/text:StringBuilder", ptr %l15
  store %"std/prelude/text:StringBuilder" %t28, ptr %l6
  store i1 true, ptr %l7, !tbaa !21
  %t29 = call ptr @__olang_scope_hold(ptr %v3)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l17, !tbaa !24
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e5
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = call ptr @__olang_region_make(ptr %v3)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l17
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t36, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l19
  br label %bb8
bb8:
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e5
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load i64, ptr %l17
  %t41 = inttoptr i64 %t40 to ptr
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19, i32 0, i32 0
  %t43 = load { i64, ptr }, ptr %t42
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = call ptr @__olang_region_or(ptr %t44, ptr null)
  %t46 = call ptr @__olang_region_home(ptr %t45)
  %t47 = icmp ne ptr %t46, null
  %t48 = select i1 %t47, ptr %t46, ptr null
  call void @__olang_region_settle_in(ptr %t41, ptr %t48)
  br label %bb10
bb10:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l8
  %t50 = call ptr @__olang_scope_hold(ptr %v3)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l21, !tbaa !24
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e6
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = call ptr @__olang_region_make(ptr %v3)
  %t55 = ptrtoint ptr %t54 to i64
  store i64 %t55, ptr %l21, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l21
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t57, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l23
  br label %bb13
bb13:
  %t59 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aDoc_2e6
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t61 = load i64, ptr %l21
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr null
  call void @__olang_region_settle_in(ptr %t62, ptr %t69)
  br label %bb15
bb15:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t71 = getelementptr %"compiler/lsp:Doc", ptr %l25, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %t71, !tbaa !27
  %t73 = getelementptr %"compiler/lsp:Doc", ptr %l25, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %t73, !tbaa !27
  %t75 = getelementptr %"compiler/lsp:Doc", ptr %l25, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t76, ptr %t75, !tbaa !27
  %t77 = getelementptr %"compiler/lsp:Doc", ptr %l25, i32 0, i32 3
  %t78 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t78, ptr %t77
  %t79 = getelementptr %"compiler/lsp:Doc", ptr %l25, i32 0, i32 4
  %t80 = load i1, ptr %l7, !tbaa !21
  store i1 %t80, ptr %t79, !tbaa !21
  %t81 = getelementptr %"compiler/lsp:Doc", ptr %l25, i32 0, i32 5
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %t81
  %t83 = getelementptr %"compiler/lsp:Doc", ptr %l25, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t83
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l25, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_3aServer_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i1
  %l4 = alloca %"compiler/lsp:Worker"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"compiler/lsp:Worker"
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"compiler/lsp:Server"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call ptr @__olang_scope_hold(ptr %v1)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l11, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aServer_2e1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l11, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l11
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2ector(ptr %t10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l13
  br label %bb3
bb3:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aServer_2e1
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l11
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  call void @__olang_region_settle_in(ptr %t15, ptr %t22)
  br label %bb5
bb5:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t24 = call %"compiler/lsp:Worker" @compiler_2flsp_3aWorker_2ector(ptr %v1)
  store %"compiler/lsp:Worker" %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load %"compiler/lsp:Worker", ptr %l15
  store %"compiler/lsp:Worker" %t25, ptr %l4
  %t26 = call ptr @__olang_scope_hold(ptr %v1)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l16, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aServer_2e4
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = call ptr @__olang_region_make(ptr %v1)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t32 = load i64, ptr %l16
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t33, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l18
  br label %bb9
bb9:
  %t35 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aServer_2e4
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load i64, ptr %l16
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = call ptr @__olang_region_or(ptr %t41, ptr null)
  %t43 = call ptr @__olang_region_home(ptr %t42)
  %t44 = icmp ne ptr %t43, null
  %t45 = select i1 %t44, ptr %t43, ptr null
  call void @__olang_region_settle_in(ptr %t38, ptr %t45)
  br label %bb11
bb11:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l5
  %t47 = call ptr @__olang_scope_hold(ptr %v1)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l20, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aServer_2e5
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = call ptr @__olang_region_make(ptr %v1)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l20, !tbaa !24
  br label %bb13
bb13:
  %t53 = load i64, ptr %l20
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t54, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l22
  br label %bb14
bb14:
  %t56 = load i1, ptr @olang_2esole_2ecompiler_2flsp_3aServer_2e5
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t58 = load i64, ptr %l20
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = call ptr @__olang_region_or(ptr %t62, ptr null)
  %t64 = call ptr @__olang_region_home(ptr %t63)
  %t65 = icmp ne ptr %t64, null
  %t66 = select i1 %t65, ptr %t64, ptr null
  call void @__olang_region_settle_in(ptr %t59, ptr %t66)
  br label %bb16
bb16:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  %t68 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 0
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %t68, !tbaa !29
  %t70 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 1
  %t71 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %t70
  %t72 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 2
  %t73 = load i1, ptr %l3, !tbaa !21
  store i1 %t73, ptr %t72, !tbaa !21
  %t74 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 3
  %t75 = load %"compiler/lsp:Worker", ptr %l4
  store %"compiler/lsp:Worker" %t75, ptr %t74
  %t76 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 4
  %t77 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %t76
  %t78 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %t78
  %t80 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 6
  store i64 0, ptr %t80, !tbaa !24
  %t82 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 7
  store i1 false, ptr %t82, !tbaa !21
  %t84 = getelementptr %"compiler/lsp:Server", ptr %l24, i32 0, i32 8
  store i1 false, ptr %t84, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l24, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lsp:Worker" @compiler_2flsp_3aWorker_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/lsp:Worker"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/lsp:Worker" undef, i32 -1, 0
  %t4 = insertvalue %"compiler/lsp:Worker" %t2, i32 -1, 1
  %t6 = insertvalue %"compiler/lsp:Worker" %t4, ptr null, 2
  %t8 = insertvalue %"compiler/lsp:Worker" %t6, i64 0, 3
  store %"compiler/lsp:Worker" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lsp:Worker", ptr %rv
  ret %"compiler/lsp:Worker" %rr
}

@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"file://" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"checking took more than a minute - it was stopped" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"cd " }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" && " }>, align 8
@.d4 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" build main.olang 2>&1" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"sh" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
@.d9 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang build did not run" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
@.d10 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c": error[" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define internal i1 @olang_lambda_14(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"context" }>, align 8
@.d17 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"diagnostics" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M10" }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"message" }>, align 8
@.d21 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22title\22:" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Add " }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c",\22kind\22:\22quickfix\22,\22diagnostics\22:[" }>, align 8
@.d25 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"],\22edit\22:{\22changes\22:{" }>, align 8
@.d26 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c":[{\22range\22:" }>, align 8
@.d27 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22newText\22:" }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"}]}}}" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@olang_2esole_2eArray_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d32 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"the compiler ended while checking this file" }>, align 8
@olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aServer__2efromWorker_2elocal_2e2 = weak hidden constant i1 false
@.d33 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"the compiler ended (" }>, align 8
@.d34 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c") while checking this file" }>, align 8
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_release(ptr) noinline
@.d35 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22olang\22:" }>, align 8
@.d36 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d38 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"the message is not JSON" }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d40 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"initialize" }>, align 8
@.d41 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"initialized" }>, align 8
@.d42 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"$/cancelRequest" }>, align 8
@.d43 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"$/setTrace" }>, align 8
@.d44 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"textDocument/didSave" }>, align 8
@.d45 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shutdown" }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"exit" }>, align 8
@.d48 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"textDocument/didOpen" }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d50 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"textDocument" }>, align 8
@.d51 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d52 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d53 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"textDocument/didChange" }>, align 8
@.d54 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d55 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"textDocument" }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d57 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"contentChanges" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d59 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"textDocument/didClose" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d61 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"textDocument" }>, align 8
@.d62 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d64 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"olang serve lsp has no " }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d66 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"capabilities" }>, align 8
@.d67 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"general" }>, align 8
@.d68 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"positionEncodings" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"utf-8" }>, align 8
@.d71 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"utf-8" }>, align 8
@.d72 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"utf-16" }>, align 8
@.d73 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"{\22positionEncoding\22:\22" }>, align 8
@.d74 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"\22,\22textDocumentSync\22:{\22openClose\22:true," }>, align 8
@.d75 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"\22change\22:1},\22hoverProvider\22:true,\22definitionProvider\22:true,\22documentSymbolProvider\22:true," }>, align 8
@.d76 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"\22completionProvider\22:{\22triggerCharacters\22:[\22.\22,\22/\22,\22\5C\22\22]},\22documentFormattingProvider\22:true," }>, align 8
@.d77 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"\22codeActionProvider\22:true}" }>, align 8
@.d78 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"{\22capabilities\22:" }>, align 8
@.d79 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c",\22serverInfo\22:{\22name\22:\22olang\22}}" }>, align 8
@.d80 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"slot" }>, align 8
@.d81 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"deps" }>, align 8
@.d82 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"foreign" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flsp_3aDoc_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2flsp_3aDoc_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2flsp_3aDoc_2e1 = weak hidden constant i1 false
declare ptr @__olang_scope_or(ptr, ptr)
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03 = weak hidden constant i1 false
@.d84 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d85 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d86 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d87 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"textDocument" }>, align 8
@.d88 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d89 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"position" }>, align 8
@.d92 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"line" }>, align 8
@.d93 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"position" }>, align 8
@.d94 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"character" }>, align 8
@.d95 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"textDocument/formatting" }>, align 8
@.d96 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d98 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"[{\22range\22:" }>, align 8
@.d99 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22newText\22:" }>, align 8
@.d100 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}]" }>, align 8
@.d101 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"textDocument/codeAction" }>, align 8
@.d102 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"textDocument/completion" }>, align 8
@.d103 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"textDocument/documentSymbol" }>, align 8
@.d104 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d105 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d106 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"textDocument/hover" }>, align 8
@.d107 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"{\22contents\22:{\22kind\22:\22markdown\22,\22value\22:" }>, align 8
@.d108 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}}" }>, align 8
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d111 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"{\22uri\22:" }>, align 8
@.d112 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c",\22range\22:" }>, align 8
@olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2echeck_2elocal_2e7 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@.d113 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"{\22olang\22:\22checked\22,\22slot\22:" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d114 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c",\22deps\22:[" }>, align 8
@.d115 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"],\22foreign\22:[" }>, align 8
@.d116 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d119 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"{\22isIncomplete\22:false,\22items\22:[" }>, align 8
@.d120 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d121 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a parameter a promise word names (T21c)" }>, align 8
@.d122 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"{\22isIncomplete\22:false,\22items\22:[" }>, align 8
@.d123 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@olang_2esole_2ecompiler_2fsession_3aPositions_2e0 = weak hidden constant i1 false
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d124 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22range\22:" }>, align 8
@.d125 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c",\22severity\22:4,\22source\22:\22olang\22,\22tags\22:[2],\22message\22:" }>, align 8
@.d126 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22range\22:" }>, align 8
@.d127 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c",\22severity\22:4,\22source\22:\22olang\22,\22code\22:\22O27\22,\22message\22:" }>, align 8
@.d128 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22range\22:" }>, align 8
@.d129 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c",\22severity\22:" }>, align 8
@.d130 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c",\22source\22:\22olang\22" }>, align 8
@.d131 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d132 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22code\22:" }>, align 8
@.d133 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22message\22:" }>, align 8
@.d134 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"{\22location\22:{\22uri\22:" }>, align 8
@.d135 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c",\22range\22:" }>, align 8
@.d136 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"},\22message\22:" }>, align 8
@.d137 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"help: " }>, align 8
@.d138 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c",\22relatedInformation\22:[" }>, align 8
@.d139 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e16 = weak hidden constant i1 false
@.d140 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2flsp__2ecompiler__2flsp__3aworker__2epublishAll_2elocal_2e25 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %a0
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/text:StringBuilder", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"std/prelude/text:StringBuilder", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l1
  store %"std/prelude/text:StringBuilder" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@olang_2esole_2estd_2fprelude_2ftext_3aStringBuilder_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2e0 = weak hidden constant i1 false
@.d141 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d143 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d145 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d146 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"{\22start\22:{\22line\22:" }>, align 8
@.d147 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c",\22character\22:0},\22end\22:{\22line\22:" }>, align 8
@.d148 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c",\22character\22:0}}" }>, align 8
@.d149 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"Content-Length: " }>, align 8
@.d150 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0D\0A\0D\0A" }>, align 8
@.d151 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"Content-Length: " }>, align 8
@.d152 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0D\0A\0D\0A" }>, align 8
@.d153 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:1,\22method\22:\22initialize\22,\22params\22:{\22capabilities\22:{}}}" }>, align 8
@.d154 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"{\22jsonrpc\22:\222.0\22,\22method\22:\22textDocument/didOpen\22,\22params\22:{\22textDocument\22:{\22uri\22:\22" }>, align 8
@.d155 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"\22,\22languageId\22:\22olang\22,\22version\22:1,\22text\22:" }>, align 8
@.d156 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"}}}" }>, align 8
@.d157 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:2,\22method\22:\22shutdown\22}" }>, align 8
@.d158 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"{\22jsonrpc\22:\222.0\22,\22method\22:\22exit\22}" }>, align 8
@.d159 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"cd " }>, align 8
@.d160 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" && OLANG_TOOL_LOG=1 " }>, align 8
@.d161 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" serve lsp" }>, align 8
@.d162 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"sh" }>, align 8
@.d163 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d164 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"olang serve lsp did not run" }>, align 8
@.d165 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a message that is no JSON: " }>, align 8
@.d166 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d167 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"textDocument/publishDiagnostics" }>, align 8
@.d168 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d169 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d170 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"diagnostics" }>, align 8
@.d171 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"range" }>, align 8
@.d172 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"start" }>, align 8
@.d173 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"line" }>, align 8
@.d174 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"severity" }>, align 8
@.d175 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define internal i1 @olang_lambda_177(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d178 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@olang_2esole_2ecompiler_2flsp_3aDoc_2e3 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@olang_2esole_2ecompiler_2flsp_3aDoc_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2flsp_3aDoc_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2flsp_3aServer_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2flsp_3aServer_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2flsp_3aServer_2e5 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_6756d46c47226ab9_ec8477bb3ab165 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
@olang_loc_78ef8a2f2ef3c68c_b23277b974982b08 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fsession_2eIgnoreBrokenPipes()
declare %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 %a0)
@olang_loc_28490b3d64df97fe_1fa673a94cf24522 = external constant [0 x i8]
declare i64 @std_2ftime_2eNow()
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_d1a2ced90ae1fed3_af42112fabe41f37 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsession_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %a0)
declare void @compiler_2flsp_2ecompiler_2flsp_3aServer_2edrain(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estartWorker(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2flsp_2eStuckNs = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\58\47\F8\0D\00\00\00" }>, align 8
declare void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eworkerLost(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estopWorker(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fos_2eQuote(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2flsp_2ecompilerUnderTest(ptr %v0)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_15a00d37002b4239_21fefac552c9525d = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_df0aeb6250e7481_26f5ec38bd691c8d = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2flsp_2ebaseName(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5f1d4675af139e82_e6710b64a8f7682e = external constant [0 x i8]
@olang_loc_ab8c4ea36668ab7f_3bb630bf34512b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ae05a22d05063faf_d2685d04a4fb9cc3 = external constant [0 x i8]
declare { i64, ptr } @compiler_2flsp_2estr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { { i64, ptr }, i64 } } @compiler_2fsession_2eImportFix(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare { i64, ptr } @compiler_2flsp_2ereply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fsession_2eWriteFramed(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esetText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eAt__Ha6317692879988aa8c889b506af3dc4d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2flsp_2epublish(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2flsp_2eSettleNs = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\5A\62\02\00\00\00\00" }>, align 8
@olang_loc_824396f7e8872934_1f4412bc0bc5f5e0 = external constant [0 x i8]
declare i32 @compiler_2fsession_2eReap(i32 %a0)
declare void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ecloseWorker(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
@olang_loc_b5606d6e3fe22ec3_be86f13ccb1ff2ff = external constant [0 x i8]
declare { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2flsp_2eidOf(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2flsp_2eerrorReply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
@G_2ecompiler_2flsp_2eRequests = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9565c00a3cf79970_b45483162fef2b54 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2eLen_Ha7d56d00f5631ac8d39ace71211767ab(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2ePus_H951db0fb6558bf39f52145a6692a11d3(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cb6dbf061e2dce2f_dc463ae13d2c2fbb = external constant [0 x i8]
declare ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4, i1 %a5)
declare void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare i64 @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eOffset(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fsession_2eSymbols(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3)
declare { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eLookup(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2euriOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare void @compiler_2fsession_2eHold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare %"compiler/session:Items" @compiler_2fsession_3aItems_2ector(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2fsession_2eImportTyped(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fsession_2eImportPaths(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fsession_2eWordChar(i8 %a0)
declare { i64, ptr } @compiler_2fsession_2ePromiseTargets(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
@G_2ecompiler_2fsession_2eCompVariable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eMembers(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
declare void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eDeprecatedUses(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2eLen_3ccompiler_2fsession_3aUse_3e(ptr %v0, ptr %a0)
declare %"compiler/session:Use" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2eAt_3ccompiler_2fsession_3aUse_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2ePlaced(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eRealOfFile(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3_H619e677aa004466b5bd5bdbfda9f24c5(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/text:StringBuilder" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3_Hf1ae1a5ebbb395c2e928aa8f7e1c7e01(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3_H3391400cd512141e3398528b8c477a4f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_f3afb7cdea72bea9_2e903794abb886a5 = external constant [0 x i8]
@olang_loc_8c5172bb8ea5e6bc_75de6e53c7815648 = external constant [0 x i8]
@olang_loc_6f843a9f898efe67_8723688731f48c63 = external constant [0 x i8]
@olang_loc_8f54b2067e6b6b8a_86cbf1b666cce186 = external constant [0 x i8]
@olang_loc_c8d49224b0a3e505_8d1f0d35a00e1b49 = external constant [0 x i8]
declare { i64, ptr } @compiler_2flsp_2eUriOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2flsp_2eStepMain = external constant <{ [8 x i8], ptr }>
@olang_loc_e95ee7c974268826_dbe3ca405aac726a = external constant [0 x i8]
@olang_loc_e0c8a6c727c459ae_6ecdb6d914c5403a = external constant [0 x i8]
@olang_loc_6196fce1a841dab8_1c2f84dff31e5f9c = external constant [0 x i8]
declare i1 @compiler_2fdiag_2eUntidy(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2flsp_3aDoc_26_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
