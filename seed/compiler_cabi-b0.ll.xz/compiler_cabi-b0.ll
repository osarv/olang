; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/cabi:Scalar" = type { i64, i64, { i64, ptr }, i1 }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cabi:Regs" = type { i64, i64 }
define dso_local { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l19 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l27 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l37 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l8
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t11 = load i32, ptr %l8, !tbaa !23
  %t13 = icmp eq i32 %t11, %t10
  br i1 %t13, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  br label %bb7
bb7:
  %t19 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l16, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l16, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t32, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb8:
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t36, ptr %l19
  br label %bb9
bb9:
  %t37 = load i1, ptr %l19, !tbaa !21
  %t38 = xor i1 %t37, true
  br i1 %t38, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t40, ptr %l22, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l23, !tbaa !24
  %t43 = load i64, ptr %l23, !tbaa !24
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l23, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  %t54 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t54, ptr %l22, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t55 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t55, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l27
  br label %bb13
bb13:
  %t61 = load i32, ptr %l27, !tbaa !23
  store i32 %t61, ptr %l3, !tbaa !23
  %t62 = load i32, ptr %l3, !tbaa !23
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t66 = icmp eq i32 %t62, %t63
  br i1 %t66, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t68, ptr %l32, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l33, !tbaa !24
  %t71 = load i64, ptr %l33, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l34, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t82, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l37
  br label %bb17
bb17:
  %t89 = load i1, ptr %l37, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb21
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t92, i32 %t93)
  store i64 %t96, ptr %l42
  br label %bb20
bb20:
  %t97 = load i64, ptr %l42, !tbaa !24
  %t98 = icmp sge i64 %t97, 32
  store i1 %t98, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t100 = load i1, ptr %l39, !tbaa !21
  br i1 %t100, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t101, ptr %l45, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l46, !tbaa !24
  %t104 = load i64, ptr %l46, !tbaa !24
  %t105 = mul i64 %t104, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l47, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = mul i64 %t113, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t115, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t116 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l3, !tbaa !23
  %t121 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t121, ptr %l50
  br label %bb25
bb25:
  %t122 = load i1, ptr %l50, !tbaa !21
  br i1 %t122, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t123, ptr %l51, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t125, ptr %l51, !tbaa !27
  br label %bb28
bb28:
  %t127 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  store i64 %t128, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l56, !tbaa !24
  %t130 = mul i64 %t129, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l57, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = load i64, ptr %l56, !tbaa !24
  %t139 = mul i64 %t138, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t135, ptr %t137, i64 %t139, i1 false)
  %t140 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t140, ptr %l51, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t141 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t141, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i32
  %l34 = alloca i32
  %l37 = alloca ptr
  %l39 = alloca %"compiler/cabi:Scalar"
  %l42 = alloca i32
  %l47 = alloca i32
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i32
  %l55 = alloca i64
  %l56 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i64
  %l101 = alloca i1
  %l104 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l129 = alloca ptr
  %l133 = alloca %"compiler/cabi:Scalar"
  %l139 = alloca i32
  %l142 = alloca i1
  %l143 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca i32
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l163 = alloca i64
  %l166 = alloca i64
  %l185 = alloca { i64, ptr }
  %l198 = alloca i64
  %l202 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l208 = alloca ptr
  %l209 = alloca i64
  %l210 = alloca i64
  %l211 = alloca { i64, ptr }
  %l214 = alloca i1
  %l215 = alloca %"compiler/cabi:Scalar"
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i32, ptr %l31, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l34
  br label %bb2
bb2:
  %t12 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l3, !tbaa !29
  store ptr %t17, ptr %l37, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t18, i64 8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, i1 false)
  store %"compiler/cabi:Scalar" %t20, ptr %l39
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l37, !tbaa !29
  %t22 = load %"compiler/cabi:Scalar", ptr %l39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t21, %"compiler/cabi:Scalar" %t22)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l42
  br label %bb8
bb8:
  %t28 = load i32, ptr %l42, !range !{i32 0, i32 33}
  %t30 = trunc i64 19 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l47
  br label %bb11
bb10:
  br label %bb33
bb11:
  %t38 = load i32, ptr %l47, !tbaa !23
  store i32 %t38, ptr %l5, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l48, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l51
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l48, !tbaa !29
  %t46 = load i32, ptr %l51, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l52
  br label %bb13
bb13:
  %t48 = load i32, ptr %l52, !range !{i32 0, i32 33}
  %t50 = trunc i64 26 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l56, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l59
  br label %bb16
bb15:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb18
bb16:
  %t59 = load ptr, ptr %l56, !tbaa !29
  %t60 = load i32, ptr %l59, !tbaa !23
  %t61 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t61, ptr %l60
  br label %bb17
bb17:
  %t62 = load i64, ptr %l60, !tbaa !24
  store i64 %t62, ptr %l55, !tbaa !24
  br label %bb18
bb18:
  %t63 = load i64, ptr %l55, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb24
bb21:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l68, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l68, !tbaa !24
  store i64 %t92, ptr %l65, !tbaa !24
  br label %bb24
bb24:
  %t93 = load i64, ptr %l65, !tbaa !24
  store i64 %t93, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l86, !tbaa !29
  %t113 = load i32, ptr %l5, !tbaa !23
  store i32 %t113, ptr %l87, !tbaa !23
  %t114 = load i64, ptr %l2, !tbaa !24
  store i64 %t114, ptr %l88, !tbaa !24
  store i64 %t110, ptr %l89, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t116, i32 %t117)
  store i64 %t120, ptr %l92
  br label %bb29
bb29:
  %t121 = load i64, ptr %l89, !tbaa !24
  %t122 = load i64, ptr %l92, !tbaa !24
  %t123 = mul i64 %t121, %t122
  %t124 = load i64, ptr %l88, !tbaa !24
  %t126 = add i64 %t124, %t123
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load ptr, ptr %l86, !tbaa !29
  %t129 = load i32, ptr %l87, !tbaa !23
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %v2, ptr %t128, i32 %t129, i64 %t126, ptr %t127)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l11, !tbaa !24
  br label %bb25
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l4, !tbaa !23
  %t141 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t141, ptr %l101
  br label %bb34
bb34:
  %t142 = load i1, ptr %l101, !tbaa !21
  br i1 %t142, label %bb35, label %bb36
bb35:
  store i64 0, ptr %l13, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l4, !tbaa !23
  %t147 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l104
  br label %bb37
bb36:
  br label %bb52
bb37:
  %t148 = load i64, ptr %l104, !tbaa !24
  store i64 %t148, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l13, !tbaa !24
  %t153 = icmp sgt i64 %t149, %t150
  br i1 %t153, label %bb38, label %bb39
bb38:
  %t155 = load i64, ptr %l15, !tbaa !24
  %t157 = icmp sgt i64 %t155, 0
  br i1 %t157, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb43
bb40:
  %t159 = load i64, ptr %l14, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = sub i64 %t159, %t160
  %t164 = load i64, ptr %l15, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t169 = sub i64 %t167, 1
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = sdiv i64 %t169, %t170
  store i64 %t173, ptr %l111, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb42
bb42:
  %t175 = load i64, ptr %l111, !tbaa !24
  store i64 %t175, ptr %l108, !tbaa !24
  br label %bb43
bb43:
  %t176 = load i64, ptr %l108, !tbaa !24
  store i64 %t176, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb44
bb44:
  %t177 = load i64, ptr %l17, !tbaa !24
  %t178 = load i64, ptr %l16, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb45, label %bb46
bb45:
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t185 = load i64, ptr %l13, !tbaa !24
  %t186 = load i64, ptr %l17, !tbaa !24
  %t187 = load i64, ptr %l15, !tbaa !24
  %t190 = mul i64 %t186, %t187
  %t193 = add i64 %t185, %t190
  %t195 = load ptr, ptr %l3, !tbaa !29
  store ptr %t195, ptr %l129, !tbaa !29
  %t196 = load i64, ptr %l2, !tbaa !24
  %t200 = add i64 %t196, %t193
  %t202 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t200, i64 1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, i1 false)
  store %"compiler/cabi:Scalar" %t202, ptr %l133
  br label %bb48
bb48:
  %t203 = load ptr, ptr %l129, !tbaa !29
  %t204 = load %"compiler/cabi:Scalar", ptr %l133
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t203, %"compiler/cabi:Scalar" %t204)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t205 = load i64, ptr %l17, !tbaa !24
  %t208 = add i64 %t205, 1
  store i64 %t208, ptr %l17, !tbaa !24
  br label %bb44
bb51:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb52:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l4, !tbaa !23
  %t214 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t210, i32 %t211)
  store i32 %t214, ptr %l139
  br label %bb53
bb53:
  %t215 = load i32, ptr %l139, !range !{i32 0, i32 33}
  %t217 = trunc i64 18 to i32
  %t218 = icmp eq i32 %t215, %t217
  br i1 %t218, label %bb54, label %bb55
bb54:
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l143, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l4, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l146
  br label %bb56
bb55:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb58
bb56:
  %t226 = load ptr, ptr %l143, !tbaa !29
  %t227 = load i32, ptr %l146, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l147
  br label %bb57
bb57:
  %t229 = load i32, ptr %l147, !range !{i32 0, i32 6}
  %t231 = trunc i64 0 to i32
  %t232 = icmp eq i32 %t229, %t231
  store i1 %t232, ptr %l142, !tbaa !21
  br label %bb58
bb58:
  %t234 = load i1, ptr %l142, !tbaa !21
  br i1 %t234, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l150, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l4, !tbaa !23
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t236, i32 %t237)
  store i32 %t240, ptr %l153
  br label %bb61
bb60:
  br label %bb77
bb61:
  %t241 = load ptr, ptr %l150, !tbaa !29
  %t242 = load i32, ptr %l153, !tbaa !23
  %t243 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t241, i32 %t242)
  store { i64, ptr } %t243, ptr %l154
  br label %bb62
bb62:
  %t244 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t244, ptr %l19, !tbaa !27
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l4, !tbaa !23
  %t249 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s10, ptr %t245, i32 %t246)
  store { i64, ptr } %t249, ptr %l157
  br label %bb63
bb63:
  %t250 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t250, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t255 = load i64, ptr %l22, !tbaa !24
  %t256 = load i64, ptr %l21, !tbaa !24
  %t259 = icmp sgt i64 %t255, %t256
  br i1 %t259, label %bb64, label %bb65
bb64:
  %t261 = load i64, ptr %l23, !tbaa !24
  %t263 = icmp sgt i64 %t261, 0
  br i1 %t263, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb69
bb66:
  %t265 = load i64, ptr %l22, !tbaa !24
  %t266 = load i64, ptr %l21, !tbaa !24
  %t269 = sub i64 %t265, %t266
  %t270 = load i64, ptr %l23, !tbaa !24
  %t273 = add i64 %t269, %t270
  %t275 = sub i64 %t273, 1
  %t276 = load i64, ptr %l23, !tbaa !24
  %t279 = sdiv i64 %t275, %t276
  store i64 %t279, ptr %l166, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb68
bb68:
  %t281 = load i64, ptr %l166, !tbaa !24
  store i64 %t281, ptr %l163, !tbaa !24
  br label %bb69
bb69:
  %t282 = load i64, ptr %l163, !tbaa !24
  store i64 %t282, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb70
bb70:
  %t283 = load i64, ptr %l25, !tbaa !24
  %t284 = load i64, ptr %l24, !tbaa !24
  %t287 = icmp slt i64 %t283, %t284
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb71, label %bb72
bb71:
  br label %bb76
bb72:
  br label %bb73
bb73:
  %t291 = load i64, ptr %l21, !tbaa !24
  %t292 = load i64, ptr %l25, !tbaa !24
  %t293 = load i64, ptr %l23, !tbaa !24
  %t296 = mul i64 %t292, %t293
  %t299 = add i64 %t291, %t296
  store i64 %t299, ptr %l26, !tbaa !24
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t302, ptr %l185, !tbaa !27
  %t303 = load i64, ptr %l26, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i32, ptr %t306, i64 %t303
  %t308 = load i32, ptr %t307, !tbaa !33
  %t309 = load i64, ptr %l2, !tbaa !24
  %t310 = load i64, ptr %l26, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr i64, ptr %t313, i64 %t310
  %t315 = load i64, ptr %t314, !tbaa !34
  %t318 = add i64 %t309, %t315
  %t319 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %v2, ptr %t301, i32 %t308, i64 %t318, ptr %t319)
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t324 = load i64, ptr %l25, !tbaa !24
  %t327 = add i64 %t324, 1
  store i64 %t327, ptr %l25, !tbaa !24
  br label %bb70
bb76:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb77:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l4, !tbaa !23
  %t333 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t329, i32 %t330)
  store i64 %t333, ptr %l198
  br label %bb78
bb78:
  %t334 = load i64, ptr %l198, !tbaa !24
  store i64 %t334, ptr %l27, !tbaa !24
  %t335 = load i32, ptr %l4, !tbaa !23
  %t336 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t339 = icmp eq i32 %t335, %t336
  br i1 %t339, label %bb79, label %bb80
bb79:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l202, !tbaa !27
  br label %bb82
bb80:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load i32, ptr %l4, !tbaa !23
  %t345 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s0, ptr %v2, ptr %t341, i32 %t342)
  store { i64, ptr } %t345, ptr %l205
  br label %bb81
bb81:
  %t346 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 1
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t349 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t348)
  call void @olang_textcopy(ptr %t349, ptr %t347, i64 %t348)
  %t350 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t349, 1
  store { i64, ptr } %t351, ptr %l202, !tbaa !27
  br label %bb82
bb82:
  %t354 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t355 = load ptr, ptr %l3, !tbaa !29
  store ptr %t355, ptr %l208, !tbaa !29
  %t356 = load i64, ptr %l2, !tbaa !24
  store i64 %t356, ptr %l209, !tbaa !24
  %t357 = load i64, ptr %l27, !tbaa !24
  store i64 %t357, ptr %l210, !tbaa !24
  store { i64, ptr } %t354, ptr %l211, !tbaa !27
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l4, !tbaa !23
  %t363 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t359, i32 %t360)
  store i1 %t363, ptr %l214
  br label %bb83
bb83:
  %t364 = load i64, ptr %l209, !tbaa !24
  %t365 = load i64, ptr %l210, !tbaa !24
  %t366 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t367 = load i1, ptr %l214, !tbaa !21
  %t368 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t364, i64 %t365, { i64, ptr } %t366, i1 %t367)
  store %"compiler/cabi:Scalar" %t368, ptr %l215
  br label %bb84
bb84:
  %t369 = load ptr, ptr %l208, !tbaa !29
  %t370 = load %"compiler/cabi:Scalar", ptr %l215
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t369, %"compiler/cabi:Scalar" %t370)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eClassify(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp6 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/cabi:Scalar"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/cabi:Scalar"
  %l34 = alloca { { i64, ptr }, i64 }
  %lp35 = alloca ptr
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i32
  %l64 = alloca i64
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca %"compiler/cabi:Way"
  %l85 = alloca %"compiler/cabi:Way"
  %l86 = alloca ptr
  %l87 = alloca i64
  %l96 = alloca i32
  %l97 = alloca i64
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca %"compiler/cabi:Way"
  %l118 = alloca %"compiler/cabi:Way"
  %l120 = alloca i1
  %l122 = alloca i64
  %l124 = alloca i1
  %l126 = alloca i64
  %l129 = alloca i64
  %l131 = alloca i64
  %l136 = alloca %"compiler/cabi:Scalar"
  %l139 = alloca i1
  %l140 = alloca i64
  %l142 = alloca %"compiler/cabi:Scalar"
  %l150 = alloca %"compiler/cabi:Scalar"
  %l153 = alloca %"std/prelude/text:StringBuilder"
  %l156 = alloca i64
  %l160 = alloca i64
  %l163 = alloca i64
  %l190 = alloca ptr
  %l191 = alloca i64
  %l194 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l197 = alloca i64
  %l200 = alloca i64
  %l205 = alloca ptr
  %l207 = alloca i64
  %l209 = alloca %"compiler/cabi:Scalar"
  %l212 = alloca i32
  %l213 = alloca i64
  %l216 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l217 = alloca i64
  %l219 = alloca { i64, ptr }
  %l220 = alloca i64
  %l221 = alloca { i64, ptr }
  %l226 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l228 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l229 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l231 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l232 = alloca %"compiler/cabi:Way"
  %l234 = alloca %"compiler/cabi:Way"
  %l238 = alloca i32
  %l241 = alloca i64
  %l244 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l245 = alloca i64
  %l247 = alloca { i64, ptr }
  %l248 = alloca i64
  %l249 = alloca { i64, ptr }
  %l254 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l256 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l257 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l259 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l260 = alloca %"compiler/cabi:Way"
  %l262 = alloca %"compiler/cabi:Way"
  %l265 = alloca ptr
  %l266 = alloca i64
  %l269 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l277 = alloca ptr
  %l279 = alloca i64
  %l284 = alloca i32
  %l285 = alloca i64
  %l288 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l289 = alloca i64
  %l291 = alloca { i64, ptr }
  %l292 = alloca i64
  %l293 = alloca { i64, ptr }
  %l298 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l300 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l301 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l303 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l304 = alloca %"compiler/cabi:Way"
  %l306 = alloca %"compiler/cabi:Way"
  %l309 = alloca i1
  %l313 = alloca i32
  %l316 = alloca i64
  %l319 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l320 = alloca i64
  %l322 = alloca { i64, ptr }
  %l323 = alloca i64
  %l324 = alloca { i64, ptr }
  %l329 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l331 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l332 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l334 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l335 = alloca %"compiler/cabi:Way"
  %l337 = alloca %"compiler/cabi:Way"
  %l344 = alloca i64
  %l347 = alloca i64
  %l370 = alloca i64
  %l372 = alloca i64
  %l377 = alloca %"compiler/cabi:Scalar"
  %l381 = alloca i1
  %l393 = alloca { { i64, ptr }, i64 }
  %l396 = alloca { { i64, ptr }, i64 }
  %l400 = alloca { { i64, ptr }, i64 }
  %l401 = alloca { i64, ptr }
  %l402 = alloca i64
  %l403 = alloca { i64, ptr }
  %l414 = alloca i32
  %l415 = alloca i64
  %l418 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l419 = alloca i64
  %l421 = alloca { i64, ptr }
  %l422 = alloca i64
  %l423 = alloca { i64, ptr }
  %l428 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l430 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l431 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l433 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l434 = alloca %"compiler/cabi:Way"
  %l436 = alloca %"compiler/cabi:Way"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l39
  br label %bb1
bb1:
  %t6 = load i64, ptr %l39, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l40
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %s0, ptr %v3, ptr %t9, i32 %t10, i64 0, ptr %l5)
  br label %bb3
bb3:
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l44
  br label %bb4
bb4:
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t15, ptr %lp6
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t17 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l45
  br label %bb5
bb5:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l7
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l46
  br label %bb6
bb6:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l8
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t24, ptr %l48
  br label %bb7
bb7:
  %t25 = load i1, ptr %l48, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp ne i64 %t26, 1
  br i1 %t28, label %bb10, label %bb11
bb9:
  br label %bb58
bb10:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp ne i64 %t30, 2
  store i1 %t32, ptr %l51, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb12
bb12:
  %t34 = load i1, ptr %l51, !tbaa !21
  br i1 %t34, label %bb13, label %bb14
bb13:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp ne i64 %t35, 4
  store i1 %t37, ptr %l54, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb15
bb15:
  %t39 = load i1, ptr %l54, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = icmp ne i64 %t40, 8
  store i1 %t42, ptr %l57, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb18
bb18:
  %t44 = load i1, ptr %l57, !tbaa !21
  br i1 %t44, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i1, ptr %l3, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb20:
  br label %bb38
bb21:
  store i32 4, ptr %l61
  br label %bb23
bb22:
  store i32 3, ptr %l61
  br label %bb23
bb23:
  %t49 = call ptr @__olang_scope_hold(ptr %v2)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l64, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t51, label %bb24, label %bb25
bb24:
  %t53 = call ptr @__olang_region_make(ptr %v2)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l64, !tbaa !24
  br label %bb25
bb25:
  %t55 = load ptr, ptr %lp6
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l67
  %t58 = load i64, ptr %l64
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_scope_hold(ptr %t59)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l68, !tbaa !24
  %t62 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t62, label %bb26, label %bb27
bb26:
  %t64 = load i64, ptr %l64
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = call ptr @__olang_region_make_part(ptr %t65)
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l68, !tbaa !24
  br label %bb27
bb27:
  %t68 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l70, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l71, !tbaa !24
  %t72 = load i64, ptr %l71, !tbaa !24
  %t73 = mul i64 %t72, 16
  %t74 = load i64, ptr %l68
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = call ptr @__olang_held_alloc(ptr %t75, i64 %t73)
  %t77 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l72, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l71, !tbaa !24
  %t84 = mul i64 %t83, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t80, ptr %t82, i64 %t84, i1 false)
  %t85 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t86 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67, i32 0, i32 0
  store { i64, ptr } %t85, ptr %t86, !tbaa !27
  %t87 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t89 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb30, label %bb31
bb29:
  %t95 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t95, label %bb32, label %bb33
bb30:
  %t97 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t97, !tbaa !27
  br label %bb31
bb31:
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67, i32 0, i32 0
  %t99 = load i64, ptr %l68
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = load { i64, ptr }, ptr %t98
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = icmp ne ptr %t103, null
  %t105 = select i1 %t104, ptr %t103, ptr null
  call void @__olang_region_settle_in(ptr %t100, ptr %t105)
  br label %bb29
bb32:
  %t106 = load i64, ptr %l64
  %t107 = inttoptr i64 %t106 to ptr
  %t108 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = call ptr @__olang_region_or(ptr %t110, ptr null)
  %t112 = call ptr @__olang_region_home(ptr %t111)
  %t113 = icmp ne ptr %t112, null
  %t114 = select i1 %t113, ptr %t112, ptr null
  call void @__olang_region_settle_in(ptr %t107, ptr %t114)
  br label %bb33
bb33:
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %l77
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l79
  br label %bb34
bb34:
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l80
  %t120 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l80)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l82
  br label %bb35
bb35:
  %t121 = load i32, ptr %l61, !range !{i32 0, i32 5}
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  %t123 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  %t124 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  %t125 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t121, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t125, ptr %l83
  br label %bb36
bb36:
  %t127 = call %"compiler/cabi:Way" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l83)
  store %"compiler/cabi:Way" %t127, ptr %l85
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t128 = load %"compiler/cabi:Way", ptr %l85
  store %"compiler/cabi:Way" %t128, ptr %rv
  br label %ret
bb38:
  %t129 = load ptr, ptr %lp6
  store ptr %t129, ptr %l86, !tbaa !29
  %t130 = call ptr @__olang_scope_hold(ptr %v2)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l87, !tbaa !24
  %t132 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t132, label %bb39, label %bb40
bb39:
  %t134 = call ptr @__olang_region_make(ptr %v2)
  %t135 = ptrtoint ptr %t134 to i64
  store i64 %t135, ptr %l87, !tbaa !24
  br label %bb40
bb40:
  %t136 = load i64, ptr %l4, !tbaa !24
  %t138 = mul i64 %t136, 8
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t142 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t143 = add i64 %t140, %t142
  %t144 = load i64, ptr %l87
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = call ptr @__olang_held_alloc(ptr %t145, i64 %t143)
  call void @olang_textcopy(ptr %t146, ptr %t139, i64 %t140)
  %t147 = getelementptr i8, ptr %t146, i64 %t140
  %t148 = call i64 @__olang_fmt_i64(ptr %t147, i64 %t138)
  %t149 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t146, 1
  %t152 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t152, { i64, ptr } %t150)
  br label %bb41
bb41:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 0)
  br label %bb42
bb42:
  %t155 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t155)
  br label %bb43
bb43:
  store i32 1, ptr %l96
  %t158 = call ptr @__olang_scope_hold(ptr %v2)
  %t159 = ptrtoint ptr %t158 to i64
  store i64 %t159, ptr %l97, !tbaa !24
  %t160 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t160, label %bb44, label %bb45
bb44:
  %t162 = call ptr @__olang_region_make(ptr %v2)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l97, !tbaa !24
  br label %bb45
bb45:
  %t164 = load ptr, ptr %lp6
  %t165 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t164
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, ptr %l100
  %t167 = load i64, ptr %l97
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_scope_hold(ptr %t168)
  %t170 = ptrtoint ptr %t169 to i64
  store i64 %t170, ptr %l101, !tbaa !24
  %t171 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t171, label %bb46, label %bb47
bb46:
  %t173 = load i64, ptr %l97
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = call ptr @__olang_region_make_part(ptr %t174)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l101, !tbaa !24
  br label %bb47
bb47:
  %t177 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l103, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l104, !tbaa !24
  %t181 = load i64, ptr %l104, !tbaa !24
  %t182 = mul i64 %t181, 16
  %t183 = load i64, ptr %l101
  %t184 = inttoptr i64 %t183 to ptr
  %t185 = call ptr @__olang_held_alloc(ptr %t184, i64 %t182)
  %t186 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l105, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = load i64, ptr %l104, !tbaa !24
  %t193 = mul i64 %t192, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t189, ptr %t191, i64 %t193, i1 false)
  %t194 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t195 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100, i32 0, i32 0
  store { i64, ptr } %t194, ptr %t195, !tbaa !27
  %t196 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t196, label %bb48, label %bb49
bb48:
  %t198 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100, i32 0, i32 0
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t202 = icmp eq i64 %t200, 0
  br i1 %t202, label %bb50, label %bb51
bb49:
  %t204 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t204, label %bb52, label %bb53
bb50:
  %t206 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t206, !tbaa !27
  br label %bb51
bb51:
  %t207 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100, i32 0, i32 0
  %t208 = load i64, ptr %l101
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = load { i64, ptr }, ptr %t207
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = call ptr @__olang_region_or(ptr %t211, ptr null)
  %t213 = icmp ne ptr %t212, null
  %t214 = select i1 %t213, ptr %t212, ptr null
  call void @__olang_region_settle_in(ptr %t209, ptr %t214)
  br label %bb49
bb52:
  %t215 = load i64, ptr %l97
  %t216 = inttoptr i64 %t215 to ptr
  %t217 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100, i32 0, i32 0
  %t218 = load { i64, ptr }, ptr %t217
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = call ptr @__olang_region_or(ptr %t219, ptr null)
  %t221 = call ptr @__olang_region_home(ptr %t220)
  %t222 = icmp ne ptr %t221, null
  %t223 = select i1 %t222, ptr %t221, ptr null
  call void @__olang_region_settle_in(ptr %t216, ptr %t223)
  br label %bb53
bb53:
  %t224 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %l110
  %t226 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s1, ptr %l110)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %l112
  br label %bb54
bb54:
  %t227 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l113
  %t229 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s1, ptr %l113)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %l115
  br label %bb55
bb55:
  %t230 = load i32, ptr %l96, !range !{i32 0, i32 5}
  %t231 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  %t233 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  %t234 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t230, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t234, ptr %l116
  br label %bb56
bb56:
  %t236 = call %"compiler/cabi:Way" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l116)
  store %"compiler/cabi:Way" %t236, ptr %l118
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t237 = load %"compiler/cabi:Way", ptr %l118
  store %"compiler/cabi:Way" %t237, ptr %rv
  br label %ret
bb58:
  %t238 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t240 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t238, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t240, ptr %l120
  br label %bb59
bb59:
  %t241 = load i1, ptr %l120, !tbaa !21
  br i1 %t241, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s4
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t243, ptr %l122
  br label %bb62
bb61:
  br label %bb186
bb62:
  %t244 = load i64, ptr %l122, !tbaa !24
  %t245 = icmp sge i64 %t244, 1
  br i1 %t245, label %bb63, label %bb64
bb63:
  %t248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t248, ptr %l126
  br label %bb65
bb64:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb66
bb65:
  %t249 = load i64, ptr %l126, !tbaa !24
  %t250 = icmp sle i64 %t249, 4
  store i1 %t250, ptr %l124, !tbaa !21
  br label %bb66
bb66:
  %t252 = load i1, ptr %l124, !tbaa !21
  store i1 %t252, ptr %l9, !tbaa !21
  store ptr %l5, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s6
  %t254 = load i64, ptr %l11, !tbaa !24
  store i64 %t254, ptr %l129, !tbaa !24
  %t255 = load ptr, ptr %l10, !tbaa !29
  %t257 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %t255)
  store i64 %t257, ptr %l131
  br label %bb68
bb68:
  %t258 = load i64, ptr %l129, !tbaa !24
  %t259 = load i64, ptr %l131, !tbaa !24
  %t260 = icmp slt i64 %t258, %t259
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s6)
  br label %bb81
bb70:
  br label %bb71
bb71:
  %t264 = load ptr, ptr %l10, !tbaa !29
  %t265 = load i64, ptr %l11, !tbaa !24
  %t268 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %t264, i64 %t265)
  store %"compiler/cabi:Scalar" %t268, ptr %l136
  br label %bb72
bb72:
  %t269 = load %"compiler/cabi:Scalar", ptr %l136
  store %"compiler/cabi:Scalar" %t269, ptr %l12
  %t270 = getelementptr %"compiler/cabi:Scalar", ptr %l12, i32 0, i32 3
  %t271 = load i1, ptr %t270, !tbaa !21
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l139, !tbaa !21
  br label %bb76
bb74:
  %t275 = getelementptr %"compiler/cabi:Scalar", ptr %l12, i32 0, i32 1
  %t276 = load i64, ptr %t275, !tbaa !24
  store i64 %t276, ptr %l140, !tbaa !24
  %t278 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s6, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t278, ptr %l142
  br label %bb75
bb75:
  %t279 = getelementptr %"compiler/cabi:Scalar", ptr %l142, i32 0, i32 1
  %t280 = load i64, ptr %t279, !tbaa !24
  %t281 = load i64, ptr %l140, !tbaa !24
  %t283 = icmp ne i64 %t281, %t280
  store i1 %t283, ptr %l139, !tbaa !21
  br label %bb76
bb76:
  %t285 = load i1, ptr %l139, !tbaa !21
  br i1 %t285, label %bb77, label %bb78
bb77:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb79
bb78:
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s6)
  br label %bb80
bb80:
  %t286 = load i64, ptr %l11, !tbaa !24
  %t289 = add i64 %t286, 1
  store i64 %t289, ptr %l11, !tbaa !24
  br label %bb67
bb81:
  %t291 = load i1, ptr %l9, !tbaa !21
  br i1 %t291, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s9
  %t294 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t294, ptr %l150
  br label %bb84
bb83:
  br label %bb135
bb84:
  %t295 = getelementptr %"compiler/cabi:Scalar", ptr %l150, i32 0, i32 2
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  store { i64, ptr } %t296, ptr %l13, !tbaa !27
  %t298 = load i1, ptr %l3, !tbaa !21
  br i1 %t298, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s10
  %t300 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s10)
  store %"std/prelude/text:StringBuilder" %t300, ptr %l153
  br label %bb87
bb86:
  %t301 = load ptr, ptr %lp6
  store ptr %t301, ptr %l196, !tbaa !29
  %t302 = call ptr @__olang_scope_hold(ptr %v2)
  %t303 = ptrtoint ptr %t302 to i64
  store i64 %t303, ptr %l197, !tbaa !24
  %t304 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t304, label %bb112, label %bb113
bb87:
  %t306 = load %"std/prelude/text:StringBuilder", ptr %l153
  store %"std/prelude/text:StringBuilder" %t306, ptr %l14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s10, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb88
bb88:
  store i64 0, ptr %l15, !tbaa !24
  %t309 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t309, ptr %l156
  br label %bb89
bb89:
  %t310 = load i64, ptr %l156, !tbaa !24
  store i64 %t310, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t311 = load i64, ptr %l16, !tbaa !24
  %t312 = load i64, ptr %l15, !tbaa !24
  %t315 = icmp sgt i64 %t311, %t312
  br i1 %t315, label %bb90, label %bb91
bb90:
  %t317 = load i64, ptr %l17, !tbaa !24
  %t319 = icmp sgt i64 %t317, 0
  br i1 %t319, label %bb92, label %bb93
bb91:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb95
bb92:
  %t321 = load i64, ptr %l16, !tbaa !24
  %t322 = load i64, ptr %l15, !tbaa !24
  %t325 = sub i64 %t321, %t322
  %t326 = load i64, ptr %l17, !tbaa !24
  %t329 = add i64 %t325, %t326
  %t331 = sub i64 %t329, 1
  %t332 = load i64, ptr %l17, !tbaa !24
  %t335 = sdiv i64 %t331, %t332
  store i64 %t335, ptr %l163, !tbaa !24
  br label %bb94
bb93:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb94
bb94:
  %t337 = load i64, ptr %l163, !tbaa !24
  store i64 %t337, ptr %l160, !tbaa !24
  br label %bb95
bb95:
  %t338 = load i64, ptr %l160, !tbaa !24
  store i64 %t338, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb96
bb96:
  %t339 = load i64, ptr %l19, !tbaa !24
  %t340 = load i64, ptr %l18, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb97, label %bb98
bb97:
  br label %bb106
bb98:
  br label %bb99
bb99:
  %t347 = load i64, ptr %l15, !tbaa !24
  %t348 = load i64, ptr %l19, !tbaa !24
  %t349 = load i64, ptr %l17, !tbaa !24
  %t352 = mul i64 %t348, %t349
  %t355 = add i64 %t347, %t352
  %t359 = icmp sgt i64 %t355, 0
  br i1 %t359, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s13
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s13, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_scope_close(ptr %s13)
  br label %bb103
bb103:
  %t362 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s0, ptr %l14, { i64, ptr } %t362)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t365 = load i64, ptr %l19, !tbaa !24
  %t368 = add i64 %t365, 1
  store i64 %t368, ptr %l19, !tbaa !24
  br label %bb96
bb106:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s10, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb107
bb107:
  %t371 = load ptr, ptr %lp6
  store ptr %t371, ptr %l190, !tbaa !29
  %t372 = call ptr @__olang_scope_hold(ptr %v2)
  %t373 = ptrtoint ptr %t372 to i64
  store i64 %t373, ptr %l191, !tbaa !24
  %t374 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t374, label %bb108, label %bb109
bb108:
  %t376 = call ptr @__olang_region_make(ptr %v2)
  %t377 = ptrtoint ptr %t376 to i64
  store i64 %t377, ptr %l191, !tbaa !24
  br label %bb109
bb109:
  %t378 = load i64, ptr %l191
  %t379 = inttoptr i64 %t378 to ptr
  %t381 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s10, ptr %t379, ptr %l14)
  store { i64, ptr } %t381, ptr %l194
  br label %bb110
bb110:
  %t382 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t383 = load ptr, ptr %l190, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t383, { i64, ptr } %t382)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb112:
  %t385 = call ptr @__olang_region_make(ptr %v2)
  %t386 = ptrtoint ptr %t385 to i64
  store i64 %t386, ptr %l197, !tbaa !24
  br label %bb113
bb113:
  %t388 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t388, ptr %l200
  br label %bb114
bb114:
  %t389 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t392 = load i64, ptr %l200, !tbaa !24
  %t393 = call i64 @__olang_fmt_i64(ptr null, i64 %t392)
  %t394 = add i64 %t391, %t393
  %t395 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t396 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t397 = add i64 %t394, %t396
  %t399 = extractvalue { i64, ptr } %t389, 1
  %t400 = extractvalue { i64, ptr } %t389, 0
  %t401 = add i64 %t397, %t400
  %t402 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t403 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t404 = add i64 %t401, %t403
  %t405 = load i64, ptr %l197
  %t406 = inttoptr i64 %t405 to ptr
  %t407 = call ptr @__olang_held_alloc(ptr %t406, i64 %t404)
  call void @olang_textcopy(ptr %t407, ptr %t390, i64 %t391)
  %t408 = getelementptr i8, ptr %t407, i64 %t391
  %t409 = call i64 @__olang_fmt_i64(ptr %t408, i64 %t392)
  %t410 = getelementptr i8, ptr %t408, i64 %t393
  call void @olang_textcopy(ptr %t410, ptr %t395, i64 %t396)
  %t411 = getelementptr i8, ptr %t410, i64 %t396
  call void @olang_textcopy(ptr %t411, ptr %t399, i64 %t400)
  %t412 = getelementptr i8, ptr %t411, i64 %t400
  call void @olang_textcopy(ptr %t412, ptr %t402, i64 %t403)
  %t413 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t407, 1
  %t416 = load ptr, ptr %l196, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t416, { i64, ptr } %t414)
  br label %bb115
bb115:
  br label %bb116
bb116:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 0)
  br label %bb117
bb117:
  store ptr %l8, ptr %l205, !tbaa !29
  %t420 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t420, ptr %l207
  br label %bb118
bb118:
  %t422 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s9, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t422, ptr %l209
  br label %bb119
bb119:
  %t423 = getelementptr %"compiler/cabi:Scalar", ptr %l209, i32 0, i32 1
  %t424 = load i64, ptr %t423, !tbaa !24
  %t425 = load i64, ptr %l207, !tbaa !24
  %t427 = mul i64 %t425, %t424
  %t428 = load ptr, ptr %l205, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t428, i64 %t427)
  br label %bb120
bb120:
  store i32 1, ptr %l212
  %t430 = call ptr @__olang_scope_hold(ptr %v2)
  %t431 = ptrtoint ptr %t430 to i64
  store i64 %t431, ptr %l213, !tbaa !24
  %t432 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t432, label %bb121, label %bb122
bb121:
  %t434 = call ptr @__olang_region_make(ptr %v2)
  %t435 = ptrtoint ptr %t434 to i64
  store i64 %t435, ptr %l213, !tbaa !24
  br label %bb122
bb122:
  %t436 = load ptr, ptr %lp6
  %t437 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t436
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t437, ptr %l216
  %t439 = load i64, ptr %l213
  %t440 = inttoptr i64 %t439 to ptr
  %t441 = call ptr @__olang_scope_hold(ptr %t440)
  %t442 = ptrtoint ptr %t441 to i64
  store i64 %t442, ptr %l217, !tbaa !24
  %t443 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t443, label %bb123, label %bb124
bb123:
  %t445 = load i64, ptr %l213
  %t446 = inttoptr i64 %t445 to ptr
  %t447 = call ptr @__olang_region_make_part(ptr %t446)
  %t448 = ptrtoint ptr %t447 to i64
  store i64 %t448, ptr %l217, !tbaa !24
  br label %bb124
bb124:
  %t449 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l216, i32 0, i32 0
  %t450 = load { i64, ptr }, ptr %t449, !tbaa !27
  store { i64, ptr } %t450, ptr %l219, !tbaa !27
  %t451 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 0
  store i64 %t452, ptr %l220, !tbaa !24
  %t453 = load i64, ptr %l220, !tbaa !24
  %t454 = mul i64 %t453, 16
  %t455 = load i64, ptr %l217
  %t456 = inttoptr i64 %t455 to ptr
  %t457 = call ptr @__olang_held_alloc(ptr %t456, i64 %t454)
  %t458 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t457, 1
  store { i64, ptr } %t459, ptr %l221, !tbaa !27
  %t460 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = load i64, ptr %l220, !tbaa !24
  %t465 = mul i64 %t464, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t461, ptr %t463, i64 %t465, i1 false)
  %t466 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t467 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l216, i32 0, i32 0
  store { i64, ptr } %t466, ptr %t467, !tbaa !27
  %t468 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t468, label %bb125, label %bb126
bb125:
  %t470 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l216, i32 0, i32 0
  %t471 = load { i64, ptr }, ptr %t470, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 0
  %t474 = icmp eq i64 %t472, 0
  br i1 %t474, label %bb127, label %bb128
bb126:
  %t476 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t476, label %bb129, label %bb130
bb127:
  %t478 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l216, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t478, !tbaa !27
  br label %bb128
bb128:
  %t479 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l216, i32 0, i32 0
  %t480 = load i64, ptr %l217
  %t481 = inttoptr i64 %t480 to ptr
  %t482 = load { i64, ptr }, ptr %t479
  %t483 = extractvalue { i64, ptr } %t482, 1
  %t484 = call ptr @__olang_region_or(ptr %t483, ptr null)
  %t485 = icmp ne ptr %t484, null
  %t486 = select i1 %t485, ptr %t484, ptr null
  call void @__olang_region_settle_in(ptr %t481, ptr %t486)
  br label %bb126
bb129:
  %t487 = load i64, ptr %l213
  %t488 = inttoptr i64 %t487 to ptr
  %t489 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l216, i32 0, i32 0
  %t490 = load { i64, ptr }, ptr %t489
  %t491 = extractvalue { i64, ptr } %t490, 1
  %t492 = call ptr @__olang_region_or(ptr %t491, ptr null)
  %t493 = call ptr @__olang_region_home(ptr %t492)
  %t494 = icmp ne ptr %t493, null
  %t495 = select i1 %t494, ptr %t493, ptr null
  call void @__olang_region_settle_in(ptr %t488, ptr %t495)
  br label %bb130
bb130:
  %t496 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t496, ptr %l226
  %t498 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s9, ptr %l226)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t498, ptr %l228
  br label %bb131
bb131:
  %t499 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t499, ptr %l229
  %t501 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s9, ptr %l229)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t501, ptr %l231
  br label %bb132
bb132:
  %t502 = load i32, ptr %l212, !range !{i32 0, i32 5}
  %t503 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l216
  %t504 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l228
  %t505 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l231
  %t506 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t502, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t503, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t504, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t505, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t506, ptr %l232
  br label %bb133
bb133:
  %t508 = call %"compiler/cabi:Way" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l232)
  store %"compiler/cabi:Way" %t508, ptr %l234
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t509 = load %"compiler/cabi:Way", ptr %l234
  store %"compiler/cabi:Way" %t509, ptr %rv
  br label %ret
bb135:
  %t510 = load i64, ptr %l4, !tbaa !24
  %t512 = icmp sgt i64 %t510, 16
  br i1 %t512, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s17
  %t514 = load i1, ptr %l3, !tbaa !21
  br i1 %t514, label %bb138, label %bb139
bb137:
  br label %bb155
bb138:
  store i32 4, ptr %l238
  br label %bb140
bb139:
  store i32 3, ptr %l238
  br label %bb140
bb140:
  %t518 = call ptr @__olang_scope_hold(ptr %v2)
  %t519 = ptrtoint ptr %t518 to i64
  store i64 %t519, ptr %l241, !tbaa !24
  %t520 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t520, label %bb141, label %bb142
bb141:
  %t522 = call ptr @__olang_region_make(ptr %v2)
  %t523 = ptrtoint ptr %t522 to i64
  store i64 %t523, ptr %l241, !tbaa !24
  br label %bb142
bb142:
  %t524 = load ptr, ptr %lp6
  %t525 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t524
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t525, ptr %l244
  %t527 = load i64, ptr %l241
  %t528 = inttoptr i64 %t527 to ptr
  %t529 = call ptr @__olang_scope_hold(ptr %t528)
  %t530 = ptrtoint ptr %t529 to i64
  store i64 %t530, ptr %l245, !tbaa !24
  %t531 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t531, label %bb143, label %bb144
bb143:
  %t533 = load i64, ptr %l241
  %t534 = inttoptr i64 %t533 to ptr
  %t535 = call ptr @__olang_region_make_part(ptr %t534)
  %t536 = ptrtoint ptr %t535 to i64
  store i64 %t536, ptr %l245, !tbaa !24
  br label %bb144
bb144:
  %t537 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244, i32 0, i32 0
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l247, !tbaa !27
  %t539 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 0
  store i64 %t540, ptr %l248, !tbaa !24
  %t541 = load i64, ptr %l248, !tbaa !24
  %t542 = mul i64 %t541, 16
  %t543 = load i64, ptr %l245
  %t544 = inttoptr i64 %t543 to ptr
  %t545 = call ptr @__olang_held_alloc(ptr %t544, i64 %t542)
  %t546 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t547 = insertvalue { i64, ptr } %t546, ptr %t545, 1
  store { i64, ptr } %t547, ptr %l249, !tbaa !27
  %t548 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = load i64, ptr %l248, !tbaa !24
  %t553 = mul i64 %t552, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t549, ptr %t551, i64 %t553, i1 false)
  %t554 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t555 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244, i32 0, i32 0
  store { i64, ptr } %t554, ptr %t555, !tbaa !27
  %t556 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t556, label %bb145, label %bb146
bb145:
  %t558 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244, i32 0, i32 0
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  %t560 = extractvalue { i64, ptr } %t559, 0
  %t562 = icmp eq i64 %t560, 0
  br i1 %t562, label %bb147, label %bb148
bb146:
  %t564 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t564, label %bb149, label %bb150
bb147:
  %t566 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t566, !tbaa !27
  br label %bb148
bb148:
  %t567 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244, i32 0, i32 0
  %t568 = load i64, ptr %l245
  %t569 = inttoptr i64 %t568 to ptr
  %t570 = load { i64, ptr }, ptr %t567
  %t571 = extractvalue { i64, ptr } %t570, 1
  %t572 = call ptr @__olang_region_or(ptr %t571, ptr null)
  %t573 = icmp ne ptr %t572, null
  %t574 = select i1 %t573, ptr %t572, ptr null
  call void @__olang_region_settle_in(ptr %t569, ptr %t574)
  br label %bb146
bb149:
  %t575 = load i64, ptr %l241
  %t576 = inttoptr i64 %t575 to ptr
  %t577 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244, i32 0, i32 0
  %t578 = load { i64, ptr }, ptr %t577
  %t579 = extractvalue { i64, ptr } %t578, 1
  %t580 = call ptr @__olang_region_or(ptr %t579, ptr null)
  %t581 = call ptr @__olang_region_home(ptr %t580)
  %t582 = icmp ne ptr %t581, null
  %t583 = select i1 %t582, ptr %t581, ptr null
  call void @__olang_region_settle_in(ptr %t576, ptr %t583)
  br label %bb150
bb150:
  %t584 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t584, ptr %l254
  %t586 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s17, ptr %l254)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t586, ptr %l256
  br label %bb151
bb151:
  %t587 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t587, ptr %l257
  %t589 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s17, ptr %l257)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t589, ptr %l259
  br label %bb152
bb152:
  %t590 = load i32, ptr %l238, !range !{i32 0, i32 5}
  %t591 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244
  %t592 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l256
  %t593 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l259
  %t594 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t590, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t591, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t592, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t593, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t594, ptr %l260
  br label %bb153
bb153:
  %t596 = call %"compiler/cabi:Way" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l260)
  store %"compiler/cabi:Way" %t596, ptr %l262
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t597 = load %"compiler/cabi:Way", ptr %l262
  store %"compiler/cabi:Way" %t597, ptr %rv
  br label %ret
bb155:
  %t598 = load i64, ptr %l4, !tbaa !24
  %t600 = icmp sle i64 %t598, 8
  br i1 %t600, label %bb156, label %bb157
bb156:
  %t602 = load ptr, ptr %lp6
  store ptr %t602, ptr %l265, !tbaa !29
  %t603 = call ptr @__olang_scope_hold(ptr %v2)
  %t604 = ptrtoint ptr %t603 to i64
  store i64 %t604, ptr %l266, !tbaa !24
  %t605 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t605, label %bb158, label %bb159
bb157:
  %t607 = load ptr, ptr %lp6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t607, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb168
bb158:
  %t609 = call ptr @__olang_region_make(ptr %v2)
  %t610 = ptrtoint ptr %t609 to i64
  store i64 %t610, ptr %l266, !tbaa !24
  br label %bb159
bb159:
  %t611 = load i1, ptr %l3, !tbaa !21
  br i1 %t611, label %bb160, label %bb161
bb160:
  %t613 = load i64, ptr %l4, !tbaa !24
  %t615 = mul i64 %t613, 8
  %t616 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t617 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t619 = call i64 @__olang_fmt_i64(ptr null, i64 %t615)
  %t620 = add i64 %t617, %t619
  %t621 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t620)
  call void @olang_textcopy(ptr %t621, ptr %t616, i64 %t617)
  %t622 = getelementptr i8, ptr %t621, i64 %t617
  %t623 = call i64 @__olang_fmt_i64(ptr %t622, i64 %t615)
  %t624 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t621, 1
  %t627 = load i64, ptr %l266
  %t628 = inttoptr i64 %t627 to ptr
  %t629 = extractvalue { i64, ptr } %t625, 0
  %t630 = extractvalue { i64, ptr } %t625, 1
  %t631 = mul i64 %t629, 1
  %t632 = call ptr @__olang_held_alloc(ptr %t628, i64 %t631)
  call void @llvm.memcpy.p0.p0.i64(ptr %t632, ptr %t630, i64 %t631, i1 false)
  %t633 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t634 = insertvalue { i64, ptr } %t633, ptr %t632, 1
  store { i64, ptr } %t634, ptr %l269, !tbaa !27
  br label %bb162
bb161:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l274, !tbaa !27
  %t636 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t638 = load i64, ptr %l266
  %t639 = inttoptr i64 %t638 to ptr
  %t640 = extractvalue { i64, ptr } %t636, 0
  %t641 = extractvalue { i64, ptr } %t636, 1
  %t642 = mul i64 %t640, 1
  %t643 = call ptr @__olang_held_alloc(ptr %t639, i64 %t642)
  call void @llvm.memcpy.p0.p0.i64(ptr %t643, ptr %t641, i64 %t642, i1 false)
  %t644 = insertvalue { i64, ptr } undef, i64 %t640, 0
  %t645 = insertvalue { i64, ptr } %t644, ptr %t643, 1
  store { i64, ptr } %t645, ptr %l269, !tbaa !27
  br label %bb162
bb162:
  %t647 = load ptr, ptr %l265, !tbaa !29
  %t648 = load { i64, ptr }, ptr %l269, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t647, { i64, ptr } %t648)
  br label %bb163
bb163:
  store ptr %l8, ptr %l277, !tbaa !29
  %t649 = load i1, ptr %l3, !tbaa !21
  br i1 %t649, label %bb164, label %bb165
bb164:
  %t651 = load i64, ptr %l4, !tbaa !24
  store i64 %t651, ptr %l279, !tbaa !24
  br label %bb166
bb165:
  store i64 8, ptr %l279, !tbaa !24
  br label %bb166
bb166:
  %t653 = load ptr, ptr %l277, !tbaa !29
  %t654 = load i64, ptr %l279, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t653, i64 %t654)
  br label %bb167
bb167:
  br label %bb170
bb168:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 16)
  br label %bb169
bb169:
  br label %bb170
bb170:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 0)
  br label %bb171
bb171:
  store i32 1, ptr %l284
  %t657 = call ptr @__olang_scope_hold(ptr %v2)
  %t658 = ptrtoint ptr %t657 to i64
  store i64 %t658, ptr %l285, !tbaa !24
  %t659 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t659, label %bb172, label %bb173
bb172:
  %t661 = call ptr @__olang_region_make(ptr %v2)
  %t662 = ptrtoint ptr %t661 to i64
  store i64 %t662, ptr %l285, !tbaa !24
  br label %bb173
bb173:
  %t663 = load ptr, ptr %lp6
  %t664 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t663
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t664, ptr %l288
  %t666 = load i64, ptr %l285
  %t667 = inttoptr i64 %t666 to ptr
  %t668 = call ptr @__olang_scope_hold(ptr %t667)
  %t669 = ptrtoint ptr %t668 to i64
  store i64 %t669, ptr %l289, !tbaa !24
  %t670 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t670, label %bb174, label %bb175
bb174:
  %t672 = load i64, ptr %l285
  %t673 = inttoptr i64 %t672 to ptr
  %t674 = call ptr @__olang_region_make_part(ptr %t673)
  %t675 = ptrtoint ptr %t674 to i64
  store i64 %t675, ptr %l289, !tbaa !24
  br label %bb175
bb175:
  %t676 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l288, i32 0, i32 0
  %t677 = load { i64, ptr }, ptr %t676, !tbaa !27
  store { i64, ptr } %t677, ptr %l291, !tbaa !27
  %t678 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t678, 0
  store i64 %t679, ptr %l292, !tbaa !24
  %t680 = load i64, ptr %l292, !tbaa !24
  %t681 = mul i64 %t680, 16
  %t682 = load i64, ptr %l289
  %t683 = inttoptr i64 %t682 to ptr
  %t684 = call ptr @__olang_held_alloc(ptr %t683, i64 %t681)
  %t685 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t684, 1
  store { i64, ptr } %t686, ptr %l293, !tbaa !27
  %t687 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t688 = load ptr, ptr %t687, !tbaa !27
  %t689 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t690 = load ptr, ptr %t689, !tbaa !27
  %t691 = load i64, ptr %l292, !tbaa !24
  %t692 = mul i64 %t691, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t688, ptr %t690, i64 %t692, i1 false)
  %t693 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t694 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l288, i32 0, i32 0
  store { i64, ptr } %t693, ptr %t694, !tbaa !27
  %t695 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t695, label %bb176, label %bb177
bb176:
  %t697 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l288, i32 0, i32 0
  %t698 = load { i64, ptr }, ptr %t697, !tbaa !27
  %t699 = extractvalue { i64, ptr } %t698, 0
  %t701 = icmp eq i64 %t699, 0
  br i1 %t701, label %bb178, label %bb179
bb177:
  %t703 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t703, label %bb180, label %bb181
bb178:
  %t705 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l288, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t705, !tbaa !27
  br label %bb179
bb179:
  %t706 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l288, i32 0, i32 0
  %t707 = load i64, ptr %l289
  %t708 = inttoptr i64 %t707 to ptr
  %t709 = load { i64, ptr }, ptr %t706
  %t710 = extractvalue { i64, ptr } %t709, 1
  %t711 = call ptr @__olang_region_or(ptr %t710, ptr null)
  %t712 = icmp ne ptr %t711, null
  %t713 = select i1 %t712, ptr %t711, ptr null
  call void @__olang_region_settle_in(ptr %t708, ptr %t713)
  br label %bb177
bb180:
  %t714 = load i64, ptr %l285
  %t715 = inttoptr i64 %t714 to ptr
  %t716 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l288, i32 0, i32 0
  %t717 = load { i64, ptr }, ptr %t716
  %t718 = extractvalue { i64, ptr } %t717, 1
  %t719 = call ptr @__olang_region_or(ptr %t718, ptr null)
  %t720 = call ptr @__olang_region_home(ptr %t719)
  %t721 = icmp ne ptr %t720, null
  %t722 = select i1 %t721, ptr %t720, ptr null
  call void @__olang_region_settle_in(ptr %t715, ptr %t722)
  br label %bb181
bb181:
  %t723 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t723, ptr %l298
  %t725 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s4, ptr %l298)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t725, ptr %l300
  br label %bb182
bb182:
  %t726 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t726, ptr %l301
  %t728 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s4, ptr %l301)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t728, ptr %l303
  br label %bb183
bb183:
  %t729 = load i32, ptr %l284, !range !{i32 0, i32 5}
  %t730 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l288
  %t731 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l300
  %t732 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l303
  %t733 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t729, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t730, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t731, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t732, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t733, ptr %l304
  br label %bb184
bb184:
  %t735 = call %"compiler/cabi:Way" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l304)
  store %"compiler/cabi:Way" %t735, ptr %l306
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t736 = load %"compiler/cabi:Way", ptr %l306
  store %"compiler/cabi:Way" %t736, ptr %rv
  br label %ret
bb186:
  %t737 = load i64, ptr %l4, !tbaa !24
  %t739 = icmp sgt i64 %t737, 16
  br i1 %t739, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l309, !tbaa !21
  br label %bb189
bb188:
  %t741 = load i64, ptr %l4, !tbaa !24
  %t743 = icmp eq i64 %t741, 0
  store i1 %t743, ptr %l309, !tbaa !21
  br label %bb189
bb189:
  %t745 = load i1, ptr %l309, !tbaa !21
  br i1 %t745, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s21
  %t746 = load i1, ptr %l3, !tbaa !21
  br i1 %t746, label %bb192, label %bb193
bb191:
  br label %bb209
bb192:
  store i32 4, ptr %l313
  br label %bb194
bb193:
  store i32 2, ptr %l313
  br label %bb194
bb194:
  %t750 = call ptr @__olang_scope_hold(ptr %v2)
  %t751 = ptrtoint ptr %t750 to i64
  store i64 %t751, ptr %l316, !tbaa !24
  %t752 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t752, label %bb195, label %bb196
bb195:
  %t754 = call ptr @__olang_region_make(ptr %v2)
  %t755 = ptrtoint ptr %t754 to i64
  store i64 %t755, ptr %l316, !tbaa !24
  br label %bb196
bb196:
  %t756 = load ptr, ptr %lp6
  %t757 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t756
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t757, ptr %l319
  %t759 = load i64, ptr %l316
  %t760 = inttoptr i64 %t759 to ptr
  %t761 = call ptr @__olang_scope_hold(ptr %t760)
  %t762 = ptrtoint ptr %t761 to i64
  store i64 %t762, ptr %l320, !tbaa !24
  %t763 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t763, label %bb197, label %bb198
bb197:
  %t765 = load i64, ptr %l316
  %t766 = inttoptr i64 %t765 to ptr
  %t767 = call ptr @__olang_region_make_part(ptr %t766)
  %t768 = ptrtoint ptr %t767 to i64
  store i64 %t768, ptr %l320, !tbaa !24
  br label %bb198
bb198:
  %t769 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l319, i32 0, i32 0
  %t770 = load { i64, ptr }, ptr %t769, !tbaa !27
  store { i64, ptr } %t770, ptr %l322, !tbaa !27
  %t771 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t772 = extractvalue { i64, ptr } %t771, 0
  store i64 %t772, ptr %l323, !tbaa !24
  %t773 = load i64, ptr %l323, !tbaa !24
  %t774 = mul i64 %t773, 16
  %t775 = load i64, ptr %l320
  %t776 = inttoptr i64 %t775 to ptr
  %t777 = call ptr @__olang_held_alloc(ptr %t776, i64 %t774)
  %t778 = insertvalue { i64, ptr } undef, i64 %t773, 0
  %t779 = insertvalue { i64, ptr } %t778, ptr %t777, 1
  store { i64, ptr } %t779, ptr %l324, !tbaa !27
  %t780 = getelementptr { i64, ptr }, ptr %l324, i32 0, i32 1
  %t781 = load ptr, ptr %t780, !tbaa !27
  %t782 = getelementptr { i64, ptr }, ptr %l322, i32 0, i32 1
  %t783 = load ptr, ptr %t782, !tbaa !27
  %t784 = load i64, ptr %l323, !tbaa !24
  %t785 = mul i64 %t784, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t781, ptr %t783, i64 %t785, i1 false)
  %t786 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t787 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l319, i32 0, i32 0
  store { i64, ptr } %t786, ptr %t787, !tbaa !27
  %t788 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t788, label %bb199, label %bb200
bb199:
  %t790 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l319, i32 0, i32 0
  %t791 = load { i64, ptr }, ptr %t790, !tbaa !27
  %t792 = extractvalue { i64, ptr } %t791, 0
  %t794 = icmp eq i64 %t792, 0
  br i1 %t794, label %bb201, label %bb202
bb200:
  %t796 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t796, label %bb203, label %bb204
bb201:
  %t798 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l319, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t798, !tbaa !27
  br label %bb202
bb202:
  %t799 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l319, i32 0, i32 0
  %t800 = load i64, ptr %l320
  %t801 = inttoptr i64 %t800 to ptr
  %t802 = load { i64, ptr }, ptr %t799
  %t803 = extractvalue { i64, ptr } %t802, 1
  %t804 = call ptr @__olang_region_or(ptr %t803, ptr null)
  %t805 = icmp ne ptr %t804, null
  %t806 = select i1 %t805, ptr %t804, ptr null
  call void @__olang_region_settle_in(ptr %t801, ptr %t806)
  br label %bb200
bb203:
  %t807 = load i64, ptr %l316
  %t808 = inttoptr i64 %t807 to ptr
  %t809 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l319, i32 0, i32 0
  %t810 = load { i64, ptr }, ptr %t809
  %t811 = extractvalue { i64, ptr } %t810, 1
  %t812 = call ptr @__olang_region_or(ptr %t811, ptr null)
  %t813 = call ptr @__olang_region_home(ptr %t812)
  %t814 = icmp ne ptr %t813, null
  %t815 = select i1 %t814, ptr %t813, ptr null
  call void @__olang_region_settle_in(ptr %t808, ptr %t815)
  br label %bb204
bb204:
  %t816 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t816, ptr %l329
  %t818 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s21, ptr %l329)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t818, ptr %l331
  br label %bb205
bb205:
  %t819 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t819, ptr %l332
  %t821 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s21, ptr %l332)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t821, ptr %l334
  br label %bb206
bb206:
  %t822 = load i32, ptr %l313, !range !{i32 0, i32 5}
  %t823 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l319
  %t824 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l331
  %t825 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l334
  %t826 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t822, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t823, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t824, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t825, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t826, ptr %l335
  br label %bb207
bb207:
  %t828 = call %"compiler/cabi:Way" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l335)
  store %"compiler/cabi:Way" %t828, ptr %l337
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t829 = load %"compiler/cabi:Way", ptr %l337
  store %"compiler/cabi:Way" %t829, ptr %rv
  br label %ret
bb209:
  store i64 0, ptr %l21, !tbaa !24
  %t830 = load i64, ptr %l4, !tbaa !24
  %t832 = add i64 %t830, 7
  %t834 = sdiv i64 %t832, 8
  store i64 %t834, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t836 = load i64, ptr %l22, !tbaa !24
  %t837 = load i64, ptr %l21, !tbaa !24
  %t840 = icmp sgt i64 %t836, %t837
  br i1 %t840, label %bb210, label %bb211
bb210:
  %t842 = load i64, ptr %l23, !tbaa !24
  %t844 = icmp sgt i64 %t842, 0
  br i1 %t844, label %bb212, label %bb213
bb211:
  store i64 0, ptr %l344, !tbaa !24
  br label %bb215
bb212:
  %t846 = load i64, ptr %l22, !tbaa !24
  %t847 = load i64, ptr %l21, !tbaa !24
  %t850 = sub i64 %t846, %t847
  %t851 = load i64, ptr %l23, !tbaa !24
  %t854 = add i64 %t850, %t851
  %t856 = sub i64 %t854, 1
  %t857 = load i64, ptr %l23, !tbaa !24
  %t860 = sdiv i64 %t856, %t857
  store i64 %t860, ptr %l347, !tbaa !24
  br label %bb214
bb213:
  store i64 0, ptr %l347, !tbaa !24
  br label %bb214
bb214:
  %t862 = load i64, ptr %l347, !tbaa !24
  store i64 %t862, ptr %l344, !tbaa !24
  br label %bb215
bb215:
  %t863 = load i64, ptr %l344, !tbaa !24
  store i64 %t863, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb216
bb216:
  store %olang.scope zeroinitializer, ptr %s23
  %t864 = load i64, ptr %l25, !tbaa !24
  %t865 = load i64, ptr %l24, !tbaa !24
  %t868 = icmp slt i64 %t864, %t865
  %t870 = xor i1 %t868, true
  br i1 %t870, label %bb217, label %bb218
bb217:
  call void @__olang_scope_close(ptr %s23)
  br label %bb249
bb218:
  br label %bb219
bb219:
  %t872 = load i64, ptr %l21, !tbaa !24
  %t873 = load i64, ptr %l25, !tbaa !24
  %t874 = load i64, ptr %l23, !tbaa !24
  %t877 = mul i64 %t873, %t874
  %t880 = add i64 %t872, %t877
  %t884 = mul i64 %t880, 8
  store i64 %t884, ptr %l27, !tbaa !24
  %t886 = load i64, ptr %l27, !tbaa !24
  %t888 = add i64 %t886, 8
  store i64 %t888, ptr %l28, !tbaa !24
  store i1 true, ptr %l29, !tbaa !21
  store i1 false, ptr %l30, !tbaa !21
  store ptr %l5, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb220
bb220:
  %t891 = load i64, ptr %l32, !tbaa !24
  store i64 %t891, ptr %l370, !tbaa !24
  %t892 = load ptr, ptr %l31, !tbaa !29
  %t894 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %t892)
  store i64 %t894, ptr %l372
  br label %bb221
bb221:
  %t895 = load i64, ptr %l370, !tbaa !24
  %t896 = load i64, ptr %l372, !tbaa !24
  %t897 = icmp slt i64 %t895, %t896
  %t899 = xor i1 %t897, true
  br i1 %t899, label %bb222, label %bb223
bb222:
  br label %bb236
bb223:
  br label %bb224
bb224:
  %t901 = load ptr, ptr %l31, !tbaa !29
  %t902 = load i64, ptr %l32, !tbaa !24
  %t905 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %t901, i64 %t902)
  store %"compiler/cabi:Scalar" %t905, ptr %l377
  br label %bb225
bb225:
  %t906 = load %"compiler/cabi:Scalar", ptr %l377
  store %"compiler/cabi:Scalar" %t906, ptr %l33
  %t907 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 0
  %t908 = load i64, ptr %t907, !tbaa !24
  %t909 = load i64, ptr %l27, !tbaa !24
  %t912 = icmp sge i64 %t908, %t909
  br i1 %t912, label %bb226, label %bb227
bb226:
  %t914 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 0
  %t915 = load i64, ptr %t914, !tbaa !24
  %t916 = load i64, ptr %l28, !tbaa !24
  %t919 = icmp slt i64 %t915, %t916
  store i1 %t919, ptr %l381, !tbaa !21
  br label %bb228
bb227:
  store i1 false, ptr %l381, !tbaa !21
  br label %bb228
bb228:
  %t921 = load i1, ptr %l381, !tbaa !21
  br i1 %t921, label %bb229, label %bb230
bb229:
  store i1 true, ptr %l30, !tbaa !21
  %t922 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 3
  %t923 = load i1, ptr %t922, !tbaa !21
  %t925 = xor i1 %t923, true
  br i1 %t925, label %bb231, label %bb232
bb230:
  br label %bb234
bb231:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb233
bb232:
  br label %bb233
bb233:
  br label %bb234
bb234:
  br label %bb235
bb235:
  %t927 = load i64, ptr %l32, !tbaa !24
  %t930 = add i64 %t927, 1
  store i64 %t930, ptr %l32, !tbaa !24
  br label %bb220
bb236:
  %t932 = load i1, ptr %l30, !tbaa !21
  %t934 = xor i1 %t932, true
  br i1 %t934, label %bb237, label %bb238
bb237:
  call void @__olang_scope_close(ptr %s23)
  br label %bb248
bb238:
  br label %bb239
bb239:
  %t936 = load i1, ptr %l29, !tbaa !21
  br i1 %t936, label %bb240, label %bb241
bb240:
  %t938 = load i64, ptr %l27, !tbaa !24
  %t941 = call { { i64, ptr }, i64 } @compiler_2fcabi_2esseAt(ptr %s0, ptr %s23, ptr %l5, i64 %t938)
  store { { i64, ptr }, i64 } %t941, ptr %l396
  br label %bb242
bb241:
  %t942 = load i64, ptr %l27, !tbaa !24
  %t943 = load i64, ptr %l4, !tbaa !24
  %t947 = call { { i64, ptr }, i64 } @compiler_2fcabi_2eintAt(ptr %s0, ptr %s23, ptr %l5, i64 %t942, i64 %t943)
  store { { i64, ptr }, i64 } %t947, ptr %l400
  br label %bb243
bb242:
  %t948 = load { { i64, ptr }, i64 }, ptr %l396
  store { { i64, ptr }, i64 } %t948, ptr %l393
  br label %bb244
bb243:
  %t949 = load { { i64, ptr }, i64 }, ptr %l400
  store { { i64, ptr }, i64 } %t949, ptr %l393
  br label %bb244
bb244:
  %t950 = load { { i64, ptr }, i64 }, ptr %l393
  store { { i64, ptr }, i64 } %t950, ptr %l34
  %t951 = getelementptr { { i64, ptr }, i64 }, ptr %l34, i32 0, i32 0
  %t952 = load { i64, ptr }, ptr %t951, !tbaa !27
  store { i64, ptr } %t952, ptr %l401, !tbaa !27
  %t953 = load { i64, ptr }, ptr %l401, !tbaa !27
  %t954 = extractvalue { i64, ptr } %t953, 0
  store i64 %t954, ptr %l402, !tbaa !24
  %t955 = load i64, ptr %l402, !tbaa !24
  %t956 = mul i64 %t955, 1
  %t957 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t956)
  %t958 = insertvalue { i64, ptr } undef, i64 %t955, 0
  %t959 = insertvalue { i64, ptr } %t958, ptr %t957, 1
  store { i64, ptr } %t959, ptr %l403, !tbaa !27
  %t960 = getelementptr { i64, ptr }, ptr %l403, i32 0, i32 1
  %t961 = load ptr, ptr %t960, !tbaa !27
  %t962 = getelementptr { i64, ptr }, ptr %l401, i32 0, i32 1
  %t963 = load ptr, ptr %t962, !tbaa !27
  %t964 = load i64, ptr %l402, !tbaa !24
  %t965 = mul i64 %t964, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t961, ptr %t963, i64 %t965, i1 false)
  %t966 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t966, ptr %lp35
  %t967 = load { i64, ptr }, ptr %l403, !tbaa !27
  %t968 = load ptr, ptr %lp35
  store { i64, ptr } %t967, ptr %t968, !tbaa !27
  %t969 = getelementptr { { i64, ptr }, i64 }, ptr %l34, i32 0, i32 1
  %t970 = load i64, ptr %t969, !tbaa !24
  store i64 %t970, ptr %l36, !tbaa !24
  %t972 = load ptr, ptr %lp6
  %t973 = load ptr, ptr %lp35
  %t974 = load { i64, ptr }, ptr %t973, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t972, { i64, ptr } %t974)
  br label %bb245
bb245:
  %t977 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 %t977)
  br label %bb246
bb246:
  %t980 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t980)
  br label %bb247
bb247:
  call void @__olang_scope_close(ptr %s23)
  br label %bb248
bb248:
  %t983 = load i64, ptr %l25, !tbaa !24
  %t986 = add i64 %t983, 1
  store i64 %t986, ptr %l25, !tbaa !24
  br label %bb216
bb249:
  store i32 1, ptr %l414
  %t988 = call ptr @__olang_scope_hold(ptr %v2)
  %t989 = ptrtoint ptr %t988 to i64
  store i64 %t989, ptr %l415, !tbaa !24
  %t990 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t990, label %bb250, label %bb251
bb250:
  %t992 = call ptr @__olang_region_make(ptr %v2)
  %t993 = ptrtoint ptr %t992 to i64
  store i64 %t993, ptr %l415, !tbaa !24
  br label %bb251
bb251:
  %t994 = load ptr, ptr %lp6
  %t995 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t994
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t995, ptr %l418
  %t997 = load i64, ptr %l415
  %t998 = inttoptr i64 %t997 to ptr
  %t999 = call ptr @__olang_scope_hold(ptr %t998)
  %t1000 = ptrtoint ptr %t999 to i64
  store i64 %t1000, ptr %l419, !tbaa !24
  %t1001 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t1001, label %bb252, label %bb253
bb252:
  %t1003 = load i64, ptr %l415
  %t1004 = inttoptr i64 %t1003 to ptr
  %t1005 = call ptr @__olang_region_make_part(ptr %t1004)
  %t1006 = ptrtoint ptr %t1005 to i64
  store i64 %t1006, ptr %l419, !tbaa !24
  br label %bb253
bb253:
  %t1007 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l418, i32 0, i32 0
  %t1008 = load { i64, ptr }, ptr %t1007, !tbaa !27
  store { i64, ptr } %t1008, ptr %l421, !tbaa !27
  %t1009 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t1010 = extractvalue { i64, ptr } %t1009, 0
  store i64 %t1010, ptr %l422, !tbaa !24
  %t1011 = load i64, ptr %l422, !tbaa !24
  %t1012 = mul i64 %t1011, 16
  %t1013 = load i64, ptr %l419
  %t1014 = inttoptr i64 %t1013 to ptr
  %t1015 = call ptr @__olang_held_alloc(ptr %t1014, i64 %t1012)
  %t1016 = insertvalue { i64, ptr } undef, i64 %t1011, 0
  %t1017 = insertvalue { i64, ptr } %t1016, ptr %t1015, 1
  store { i64, ptr } %t1017, ptr %l423, !tbaa !27
  %t1018 = getelementptr { i64, ptr }, ptr %l423, i32 0, i32 1
  %t1019 = load ptr, ptr %t1018, !tbaa !27
  %t1020 = getelementptr { i64, ptr }, ptr %l421, i32 0, i32 1
  %t1021 = load ptr, ptr %t1020, !tbaa !27
  %t1022 = load i64, ptr %l422, !tbaa !24
  %t1023 = mul i64 %t1022, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t1019, ptr %t1021, i64 %t1023, i1 false)
  %t1024 = load { i64, ptr }, ptr %l423, !tbaa !27
  %t1025 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l418, i32 0, i32 0
  store { i64, ptr } %t1024, ptr %t1025, !tbaa !27
  %t1026 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t1026, label %bb254, label %bb255
bb254:
  %t1028 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l418, i32 0, i32 0
  %t1029 = load { i64, ptr }, ptr %t1028, !tbaa !27
  %t1030 = extractvalue { i64, ptr } %t1029, 0
  %t1032 = icmp eq i64 %t1030, 0
  br i1 %t1032, label %bb256, label %bb257
bb255:
  %t1034 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t1034, label %bb258, label %bb259
bb256:
  %t1036 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l418, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1036, !tbaa !27
  br label %bb257
bb257:
  %t1037 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l418, i32 0, i32 0
  %t1038 = load i64, ptr %l419
  %t1039 = inttoptr i64 %t1038 to ptr
  %t1040 = load { i64, ptr }, ptr %t1037
  %t1041 = extractvalue { i64, ptr } %t1040, 1
  %t1042 = call ptr @__olang_region_or(ptr %t1041, ptr null)
  %t1043 = icmp ne ptr %t1042, null
  %t1044 = select i1 %t1043, ptr %t1042, ptr null
  call void @__olang_region_settle_in(ptr %t1039, ptr %t1044)
  br label %bb255
bb258:
  %t1045 = load i64, ptr %l415
  %t1046 = inttoptr i64 %t1045 to ptr
  %t1047 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l418, i32 0, i32 0
  %t1048 = load { i64, ptr }, ptr %t1047
  %t1049 = extractvalue { i64, ptr } %t1048, 1
  %t1050 = call ptr @__olang_region_or(ptr %t1049, ptr null)
  %t1051 = call ptr @__olang_region_home(ptr %t1050)
  %t1052 = icmp ne ptr %t1051, null
  %t1053 = select i1 %t1052, ptr %t1051, ptr null
  call void @__olang_region_settle_in(ptr %t1046, ptr %t1053)
  br label %bb259
bb259:
  %t1054 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1054, ptr %l428
  %t1056 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l428)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1056, ptr %l430
  br label %bb260
bb260:
  %t1057 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1057, ptr %l431
  %t1059 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l431)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1059, ptr %l433
  br label %bb261
bb261:
  %t1060 = load i32, ptr %l414, !range !{i32 0, i32 5}
  %t1061 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l418
  %t1062 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l430
  %t1063 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l433
  %t1064 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t1060, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1061, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1062, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1063, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t1064, ptr %l434
  br label %bb262
bb262:
  %t1066 = call %"compiler/cabi:Way" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l434)
  store %"compiler/cabi:Way" %t1066, ptr %l436
  br label %bb263
bb263:
  call void @__olang_scope_close(ptr %s0)
  %t1067 = load %"compiler/cabi:Way", ptr %l436
  store %"compiler/cabi:Way" %t1067, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca %"compiler/cabi:Way"
  %l53 = alloca %"compiler/cabi:Way"
  %l55 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i64
  %l62 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca i1
  %l83 = alloca i1
  %l88 = alloca i32
  %l89 = alloca i64
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i64
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca i64
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca %"compiler/cabi:Way"
  %l102 = alloca ptr
  %l107 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l17
  br label %bb4
bb3:
  br label %bb28
bb4:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t15, i32 %t14)
  store i1 %t19, ptr %l20
  br label %bb5
bb5:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = getelementptr %"compiler/cabi:Regs", ptr %t22, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = sub i64 %t24, 1
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t30 = getelementptr %"compiler/cabi:Regs", ptr %t29, i32 0, i32 1
  store i64 %t27, ptr %t30, !tbaa !24
  br label %bb8
bb7:
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = getelementptr %"compiler/cabi:Regs", ptr %t32, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = sub i64 %t34, 1
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = getelementptr %"compiler/cabi:Regs", ptr %t39, i32 0, i32 0
  store i64 %t37, ptr %t40, !tbaa !24
  br label %bb8
bb8:
  store i32 0, ptr %l29
  %t41 = call ptr @__olang_scope_hold(ptr %v3)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l30, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = call ptr @__olang_region_make(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l30, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l30
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t48, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l32
  br label %bb11
bb11:
  %t50 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l30
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = call ptr @__olang_region_or(ptr %t56, ptr null)
  %t58 = call ptr @__olang_region_home(ptr %t57)
  %t59 = icmp ne ptr %t58, null
  %t60 = select i1 %t59, ptr %t58, ptr null
  call void @__olang_region_settle_in(ptr %t53, ptr %t60)
  br label %bb13
bb13:
  %t61 = call ptr @__olang_scope_hold(ptr %v3)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l34, !tbaa !24
  %t63 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = call ptr @__olang_region_make(ptr %v3)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l34, !tbaa !24
  br label %bb15
bb15:
  %t67 = load i64, ptr %l34
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t68, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l36
  br label %bb16
bb16:
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t72 = load i64, ptr %l34
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t75 = load { i64, ptr }, ptr %t74
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = call ptr @__olang_region_or(ptr %t76, ptr null)
  %t78 = call ptr @__olang_region_home(ptr %t77)
  %t79 = icmp ne ptr %t78, null
  %t80 = select i1 %t79, ptr %t78, ptr null
  call void @__olang_region_settle_in(ptr %t73, ptr %t80)
  br label %bb18
bb18:
  %t81 = call ptr @__olang_scope_hold(ptr %v3)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l38, !tbaa !24
  %t83 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t85 = call ptr @__olang_region_make(ptr %v3)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l38, !tbaa !24
  br label %bb20
bb20:
  %t87 = load i64, ptr %l38
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t88, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l40
  br label %bb21
bb21:
  %t90 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t90, label %bb22, label %bb23
bb22:
  %t92 = load i64, ptr %l38
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40, i32 0, i32 0
  %t95 = load { i64, ptr }, ptr %t94
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = call ptr @__olang_region_or(ptr %t96, ptr null)
  %t98 = call ptr @__olang_region_home(ptr %t97)
  %t99 = icmp ne ptr %t98, null
  %t100 = select i1 %t99, ptr %t98, ptr null
  call void @__olang_region_settle_in(ptr %t93, ptr %t100)
  br label %bb23
bb23:
  %t101 = call ptr @__olang_scope_hold(ptr %v3)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l42, !tbaa !24
  %t103 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e4
  br i1 %t103, label %bb24, label %bb25
bb24:
  %t105 = call ptr @__olang_region_make(ptr %v3)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l42, !tbaa !24
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t109 = load i32, ptr %l2, !tbaa !23
  %t110 = load i64, ptr %l42
  %t111 = inttoptr i64 %t110 to ptr
  %t115 = call { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %t111, ptr %t107, { i64, ptr } %t108, i32 %t109)
  store { i64, ptr } %t115, ptr %l47
  br label %bb26
bb26:
  %t116 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t117 = load i64, ptr %l42
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = extractvalue { i64, ptr } %t116, 0
  %t120 = extractvalue { i64, ptr } %t116, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_held_alloc(ptr %t118, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t125 = load i32, ptr %l29, !range !{i32 0, i32 5}
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  %t130 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t125, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, { i64, ptr } %t124)
  store %"compiler/cabi:Way" %t130, ptr %l49
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t131 = load %"compiler/cabi:Way", ptr %l49
  store %"compiler/cabi:Way" %t131, ptr %rv
  br label %ret
bb28:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t134 = load i32, ptr %l2, !tbaa !23
  %t138 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eClassify(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t132, { i64, ptr } %t133, i32 %t134, i1 false)
  store %"compiler/cabi:Way" %t138, ptr %l53
  br label %bb29
bb29:
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 120, i64 8)
  store ptr %t139, ptr %lp5
  %t140 = load %"compiler/cabi:Way", ptr %l53
  %t141 = load ptr, ptr %lp5
  store %"compiler/cabi:Way" %t140, ptr %t141
  %t142 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t144 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t142, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t144, ptr %l55
  br label %bb30
bb30:
  %t145 = load i1, ptr %l55, !tbaa !21
  br i1 %t145, label %bb31, label %bb32
bb31:
  %t146 = load ptr, ptr %lp5
  %t147 = getelementptr %"compiler/cabi:Way", ptr %t146, i32 0, i32 0
  %t148 = load i32, ptr %t147, !range !{i32 0, i32 5}
  %t150 = trunc i64 1 to i32
  %t151 = icmp eq i32 %t148, %t150
  store i1 %t151, ptr %l56, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb33
bb33:
  %t153 = load i1, ptr %l56, !tbaa !21
  br i1 %t153, label %bb34, label %bb35
bb34:
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t154 = load ptr, ptr %lp5
  %t155 = getelementptr %"compiler/cabi:Way", ptr %t154, i32 0, i32 1
  store ptr %t155, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb36
bb35:
  br label %bb70
bb36:
  %t157 = load i64, ptr %l9, !tbaa !24
  store i64 %t157, ptr %l60, !tbaa !24
  %t158 = load ptr, ptr %l8, !tbaa !29
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t158)
  store i64 %t160, ptr %l62
  br label %bb37
bb37:
  %t161 = load i64, ptr %l60, !tbaa !24
  %t162 = load i64, ptr %l62, !tbaa !24
  %t163 = icmp slt i64 %t161, %t162
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb38, label %bb39
bb38:
  br label %bb47
bb39:
  br label %bb40
bb40:
  %t167 = load ptr, ptr %l8, !tbaa !29
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t167, i64 %t168)
  store { i64, ptr } %t171, ptr %l67
  br label %bb41
bb41:
  %t172 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t175 = call i1 @compiler_2fcabi_2einSse(ptr %v3, { i64, ptr } %t172)
  store i1 %t175, ptr %l69
  br label %bb42
bb42:
  %t176 = load i1, ptr %l69, !tbaa !21
  br i1 %t176, label %bb43, label %bb44
bb43:
  %t177 = load i64, ptr %l7, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l7, !tbaa !24
  br label %bb45
bb44:
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l6, !tbaa !24
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t187 = load i64, ptr %l9, !tbaa !24
  %t190 = add i64 %t187, 1
  store i64 %t190, ptr %l9, !tbaa !24
  br label %bb36
bb47:
  %t192 = load i64, ptr %l6, !tbaa !24
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t195 = getelementptr %"compiler/cabi:Regs", ptr %t193, i32 0, i32 0
  %t196 = load i64, ptr %t195, !tbaa !24
  %t199 = icmp sgt i64 %t192, %t196
  br i1 %t199, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb50
bb49:
  %t201 = load i64, ptr %l7, !tbaa !24
  %t202 = load ptr, ptr %l3, !tbaa !29
  %t204 = getelementptr %"compiler/cabi:Regs", ptr %t202, i32 0, i32 1
  %t205 = load i64, ptr %t204, !tbaa !24
  %t208 = icmp sgt i64 %t201, %t205
  store i1 %t208, ptr %l83, !tbaa !21
  br label %bb50
bb50:
  %t210 = load i1, ptr %l83, !tbaa !21
  br i1 %t210, label %bb51, label %bb52
bb51:
  store i32 2, ptr %l88
  %t211 = call ptr @__olang_scope_hold(ptr %v3)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l89, !tbaa !24
  %t213 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t213, label %bb53, label %bb54
bb52:
  br label %bb69
bb53:
  %t215 = call ptr @__olang_region_make(ptr %v3)
  %t216 = ptrtoint ptr %t215 to i64
  store i64 %t216, ptr %l89, !tbaa !24
  br label %bb54
bb54:
  %t217 = load i64, ptr %l89
  %t218 = inttoptr i64 %t217 to ptr
  %t219 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t218, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t219, ptr %l91
  br label %bb55
bb55:
  %t220 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t220, label %bb56, label %bb57
bb56:
  %t222 = load i64, ptr %l89
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = call ptr @__olang_region_or(ptr %t226, ptr null)
  %t228 = call ptr @__olang_region_home(ptr %t227)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t223, ptr %t230)
  br label %bb57
bb57:
  %t231 = call ptr @__olang_scope_hold(ptr %v3)
  %t232 = ptrtoint ptr %t231 to i64
  store i64 %t232, ptr %l93, !tbaa !24
  %t233 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t233, label %bb58, label %bb59
bb58:
  %t235 = call ptr @__olang_region_make(ptr %v3)
  %t236 = ptrtoint ptr %t235 to i64
  store i64 %t236, ptr %l93, !tbaa !24
  br label %bb59
bb59:
  %t237 = load i64, ptr %l93
  %t238 = inttoptr i64 %t237 to ptr
  %t239 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t238, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l95
  br label %bb60
bb60:
  %t240 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t240, label %bb61, label %bb62
bb61:
  %t242 = load i64, ptr %l93
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95, i32 0, i32 0
  %t245 = load { i64, ptr }, ptr %t244
  %t246 = extractvalue { i64, ptr } %t245, 1
  %t247 = call ptr @__olang_region_or(ptr %t246, ptr null)
  %t248 = call ptr @__olang_region_home(ptr %t247)
  %t249 = icmp ne ptr %t248, null
  %t250 = select i1 %t249, ptr %t248, ptr null
  call void @__olang_region_settle_in(ptr %t243, ptr %t250)
  br label %bb62
bb62:
  %t251 = call ptr @__olang_scope_hold(ptr %v3)
  %t252 = ptrtoint ptr %t251 to i64
  store i64 %t252, ptr %l97, !tbaa !24
  %t253 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t253, label %bb63, label %bb64
bb63:
  %t255 = call ptr @__olang_region_make(ptr %v3)
  %t256 = ptrtoint ptr %t255 to i64
  store i64 %t256, ptr %l97, !tbaa !24
  br label %bb64
bb64:
  %t257 = load i64, ptr %l97
  %t258 = inttoptr i64 %t257 to ptr
  %t259 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t258, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t259, ptr %l99
  br label %bb65
bb65:
  %t260 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t260, label %bb66, label %bb67
bb66:
  %t262 = load i64, ptr %l97
  %t263 = inttoptr i64 %t262 to ptr
  %t264 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99, i32 0, i32 0
  %t265 = load { i64, ptr }, ptr %t264
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = call ptr @__olang_region_or(ptr %t266, ptr null)
  %t268 = call ptr @__olang_region_home(ptr %t267)
  %t269 = icmp ne ptr %t268, null
  %t270 = select i1 %t269, ptr %t268, ptr null
  call void @__olang_region_settle_in(ptr %t263, ptr %t270)
  br label %bb67
bb67:
  %t271 = load i32, ptr %l88, !range !{i32 0, i32 5}
  %t272 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  %t273 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  %t274 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99
  %t275 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t271, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t272, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t275, ptr %l101
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t276 = load %"compiler/cabi:Way", ptr %l101
  store %"compiler/cabi:Way" %t276, ptr %rv
  br label %ret
bb69:
  %t277 = load ptr, ptr %l3, !tbaa !29
  store ptr %t277, ptr %l102, !tbaa !29
  %t278 = load ptr, ptr %l102, !tbaa !29
  %t279 = getelementptr %"compiler/cabi:Regs", ptr %t278, i32 0, i32 0
  %t280 = load i64, ptr %t279, !tbaa !24
  %t282 = load i64, ptr %l6, !tbaa !24
  %t285 = sub i64 %t280, %t282
  %t287 = load ptr, ptr %l102, !tbaa !29
  %t288 = getelementptr %"compiler/cabi:Regs", ptr %t287, i32 0, i32 0
  store i64 %t285, ptr %t288, !tbaa !24
  %t289 = load ptr, ptr %l3, !tbaa !29
  store ptr %t289, ptr %l107, !tbaa !29
  %t290 = load ptr, ptr %l107, !tbaa !29
  %t291 = getelementptr %"compiler/cabi:Regs", ptr %t290, i32 0, i32 1
  %t292 = load i64, ptr %t291, !tbaa !24
  %t294 = load i64, ptr %l7, !tbaa !24
  %t297 = sub i64 %t292, %t294
  %t299 = load ptr, ptr %l107, !tbaa !29
  %t300 = getelementptr %"compiler/cabi:Regs", ptr %t299, i32 0, i32 1
  store i64 %t297, ptr %t300, !tbaa !24
  br label %bb70
bb70:
  %t301 = load ptr, ptr %lp5
  %t302 = load %"compiler/cabi:Way", ptr %t301
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cabi:Way" %t302, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i32
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca %"compiler/cabi:Way"
  %l31 = alloca %"compiler/cabi:Way"
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %l7
  %t9 = call ptr @__olang_scope_hold(ptr %v2)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb23
bb4:
  %t13 = call ptr @__olang_region_make(ptr %v2)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l8
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t16, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l10
  br label %bb6
bb6:
  %t18 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e1
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t20 = load i64, ptr %l8
  %t21 = inttoptr i64 %t20 to ptr
  %t22 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = call ptr @__olang_region_or(ptr %t24, ptr null)
  %t26 = call ptr @__olang_region_home(ptr %t25)
  %t27 = icmp ne ptr %t26, null
  %t28 = select i1 %t27, ptr %t26, ptr null
  call void @__olang_region_settle_in(ptr %t21, ptr %t28)
  br label %bb8
bb8:
  %t29 = call ptr @__olang_scope_hold(ptr %v2)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l12, !tbaa !24
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = call ptr @__olang_region_make(ptr %v2)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l12, !tbaa !24
  br label %bb10
bb10:
  %t35 = load i64, ptr %l12
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t36, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l14
  br label %bb11
bb11:
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e2
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load i64, ptr %l12
  %t41 = inttoptr i64 %t40 to ptr
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14, i32 0, i32 0
  %t43 = load { i64, ptr }, ptr %t42
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = call ptr @__olang_region_or(ptr %t44, ptr null)
  %t46 = call ptr @__olang_region_home(ptr %t45)
  %t47 = icmp ne ptr %t46, null
  %t48 = select i1 %t47, ptr %t46, ptr null
  call void @__olang_region_settle_in(ptr %t41, ptr %t48)
  br label %bb13
bb13:
  %t49 = call ptr @__olang_scope_hold(ptr %v2)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l16, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = call ptr @__olang_region_make(ptr %v2)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l16, !tbaa !24
  br label %bb15
bb15:
  %t55 = load i64, ptr %l16
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t56, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l18
  br label %bb16
bb16:
  %t58 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e3
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load i64, ptr %l16
  %t61 = inttoptr i64 %t60 to ptr
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = call ptr @__olang_region_or(ptr %t64, ptr null)
  %t66 = call ptr @__olang_region_home(ptr %t65)
  %t67 = icmp ne ptr %t66, null
  %t68 = select i1 %t67, ptr %t66, ptr null
  call void @__olang_region_settle_in(ptr %t61, ptr %t68)
  br label %bb18
bb18:
  %t69 = call ptr @__olang_scope_hold(ptr %v2)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l20, !tbaa !24
  %t71 = load i1, ptr @olang_2esole_2ecompiler_2fcabi_3aWay_2e4
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t73 = call ptr @__olang_region_make(ptr %v2)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l20, !tbaa !24
  br label %bb20
bb20:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t77 = load i32, ptr %l2, !tbaa !23
  %t78 = load i64, ptr %l20
  %t79 = inttoptr i64 %t78 to ptr
  %t83 = call { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %t79, ptr %t75, { i64, ptr } %t76, i32 %t77)
  store { i64, ptr } %t83, ptr %l25
  br label %bb21
bb21:
  %t84 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t85 = load i64, ptr %l20
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = extractvalue { i64, ptr } %t84, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_held_alloc(ptr %t86, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load i32, ptr %l7, !range !{i32 0, i32 5}
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t98 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t93, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, { i64, ptr } %t92)
  store %"compiler/cabi:Way" %t98, ptr %l27
  br label %bb22
bb22:
  %t99 = load %"compiler/cabi:Way", ptr %l27
  store %"compiler/cabi:Way" %t99, ptr %rv
  br label %ret
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = load i32, ptr %l2, !tbaa !23
  %t106 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eClassify(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t100, { i64, ptr } %t101, i32 %t102, i1 true)
  store %"compiler/cabi:Way" %t106, ptr %l31
  br label %bb24
bb24:
  %t107 = load %"compiler/cabi:Way", ptr %l31
  store %"compiler/cabi:Way" %t107, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local i1 @compiler_2fcabi_2einSse(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l12, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fcabi_2eintAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/cabi:Scalar"
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca %"compiler/cabi:Scalar"
  %l20 = alloca %"compiler/cabi:Scalar"
  %l22 = alloca i1
  %l23 = alloca i1
  %l28 = alloca { { i64, ptr }, i64 }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l38 = alloca i1
  %l48 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %s0, ptr %t11, i64 %t13)
  store %"compiler/cabi:Scalar" %t16, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t17 = getelementptr %"compiler/cabi:Scalar", ptr %l15, i32 0, i32 3
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store %"compiler/cabi:Scalar" %t27, ptr %l20
  br label %bb8
bb7:
  br label %bb20
bb8:
  %t28 = load %"compiler/cabi:Scalar", ptr %l20
  store %"compiler/cabi:Scalar" %t28, ptr %l4
  %t29 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t32, ptr %l22
  br label %bb9
bb9:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t34 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp eq i64 %t35, 8
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t44 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t41, 0
  %t45 = insertvalue { { i64, ptr }, i64 } %t44, i64 8, 1
  store { { i64, ptr }, i64 } %t45, ptr %l28
  %t46 = getelementptr { { i64, ptr }, i64 }, ptr %l28, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l30, !tbaa !24
  %t50 = load i64, ptr %l30, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l30, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t62 = getelementptr { { i64, ptr }, i64 }, ptr %l28, i32 0, i32 0
  store { i64, ptr } %t61, ptr %t62, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { { i64, ptr }, i64 }, ptr %l28
  store { { i64, ptr }, i64 } %t63, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l1, !tbaa !24
  %t66 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = add i64 %t65, %t67
  %t71 = load i64, ptr %l1, !tbaa !24
  %t73 = add i64 %t71, 8
  %t77 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t64, i64 %t70, i64 %t73)
  store i1 %t77, ptr %l38
  br label %bb16
bb16:
  %t78 = load i1, ptr %l38, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = mul i64 %t82, 8
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t88 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t89 = add i64 %t86, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t85, i64 %t86)
  %t91 = getelementptr i8, ptr %t90, i64 %t86
  %t92 = call i64 @__olang_fmt_i64(ptr %t91, i64 %t84)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t90, 1
  %t95 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t94, 0
  %t100 = insertvalue { { i64, ptr }, i64 } %t98, i64 %t96, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t100, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = sub i64 %a2, %t103
  %t108 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t106, i64 8)
  store i64 %t108, ptr %l48
  br label %bb21
bb21:
  %t109 = load i64, ptr %l48, !tbaa !24
  store i64 %t109, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l5, !tbaa !24
  %t112 = mul i64 %t110, 8
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t117 = add i64 %t114, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t113, i64 %t114)
  %t119 = getelementptr i8, ptr %t118, i64 %t114
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t112)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t118, 1
  %t123 = load i64, ptr %l5, !tbaa !24
  %t125 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t122, 0
  %t127 = insertvalue { { i64, ptr }, i64 } %t125, i64 %t123, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fcabi_2esseAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/cabi:Scalar"
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca %"compiler/cabi:Scalar"
  %l20 = alloca { i64, ptr }
  %l23 = alloca i64
  %l25 = alloca i64
  %l30 = alloca %"compiler/cabi:Scalar"
  %l34 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l62 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l74 = alloca i1
  %l78 = alloca { { i64, ptr }, i64 }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l87 = alloca { { i64, ptr }, i64 }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca { i64, ptr }
  %l92 = alloca i1
  %l100 = alloca i64
  %l102 = alloca i1
  %l103 = alloca i1
  %l106 = alloca i1
  %l110 = alloca %"compiler/cabi:Scalar"
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l115 = alloca { { i64, ptr }, i64 }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca { i64, ptr }
  %l121 = alloca { { i64, ptr }, i64 }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t13)
  store %"compiler/cabi:Scalar" %t16, ptr %l18
  br label %bb4
bb3:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb5
bb4:
  %t17 = getelementptr %"compiler/cabi:Scalar", ptr %l18, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t21, ptr %l4, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l6, !tbaa !24
  store i64 %t25, ptr %l23, !tbaa !24
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l25
  br label %bb7
bb7:
  %t29 = load i64, ptr %l23, !tbaa !24
  %t30 = load i64, ptr %l25, !tbaa !24
  %t31 = icmp slt i64 %t29, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb9:
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store %"compiler/cabi:Scalar" %t39, ptr %l30
  br label %bb11
bb11:
  %t40 = load %"compiler/cabi:Scalar", ptr %l30
  store %"compiler/cabi:Scalar" %t40, ptr %l7
  %t41 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = icmp sge i64 %t42, %t43
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = add i64 %t50, 8
  %t55 = icmp slt i64 %t49, %t52
  store i1 %t55, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l34, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = icmp eq i64 %t59, 2
  store i1 %t61, ptr %l39, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb17
bb17:
  %t63 = load i1, ptr %l39, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t64 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t64, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t66, ptr %l44
  br label %bb20
bb19:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb21
bb20:
  %t67 = load i1, ptr %l44, !tbaa !21
  store i1 %t67, ptr %l42, !tbaa !21
  br label %bb21
bb21:
  %t68 = load i1, ptr %l42, !tbaa !21
  br i1 %t68, label %bb22, label %bb23
bb22:
  %t69 = call ptr @__olang_scope_hold(ptr %s0)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l45, !tbaa !24
  %t71 = load i1, ptr @olang_2esole_2ecompiler__2fcabi__2esseAt_2elocal_2e4
  br i1 %t71, label %bb24, label %bb25
bb23:
  br label %bb32
bb24:
  %t73 = call ptr @__olang_region_make(ptr %s0)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l45, !tbaa !24
  br label %bb25
bb25:
  %t75 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 1
  %t79 = extractvalue { i64, ptr } %t76, 0
  %t80 = load i64, ptr %l45
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = call ptr @__olang_held_alloc(ptr %t81, i64 %t79)
  call void @olang_textcopy(ptr %t82, ptr %t78, i64 %t79)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l48, !tbaa !27
  %t85 = load i1, ptr @olang_2esole_2ecompiler__2fcabi__2esseAt_2elocal_2e4
  br i1 %t85, label %bb26, label %bb27
bb26:
  %t87 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t90 = icmp eq i64 %t88, 0
  br i1 %t90, label %bb28, label %bb29
bb27:
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t92, ptr %l52, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t93, ptr %l4, !tbaa !27
  %t94 = load i1, ptr @olang_2esole_2ecompiler__2fcabi__2esseAt_2elocal_2e4
  br i1 %t94, label %bb30, label %bb31
bb28:
  store { i64, ptr } zeroinitializer, ptr %l48, !tbaa !27
  br label %bb29
bb29:
  %t96 = load i64, ptr %l45
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l48
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  br label %bb27
bb30:
  %t103 = load { i64, ptr }, ptr %l52
  %t104 = extractvalue { i64, ptr } %t103, 1
  call void @__olang_region_release(ptr %t104)
  store { i64, ptr } zeroinitializer, ptr %l52
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l6, !tbaa !24
  br label %bb6
bb34:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l1, !tbaa !24
  %t113 = add i64 %t111, 4
  %t114 = load i64, ptr %l1, !tbaa !24
  %t116 = add i64 %t114, 8
  %t120 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t110, i64 %t113, i64 %t116)
  store i1 %t120, ptr %l62
  br label %bb35
bb35:
  %t121 = load i1, ptr %l62, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t124, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t126, ptr %l65
  br label %bb38
bb37:
  br label %bb50
bb38:
  %t127 = load i1, ptr %l65, !tbaa !21
  br i1 %t127, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb42
bb40:
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t128, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t130, ptr %l68
  br label %bb41
bb41:
  %t131 = load i1, ptr %l68, !tbaa !21
  store i1 %t131, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t132 = load i1, ptr %l66, !tbaa !21
  br i1 %t132, label %bb43, label %bb44
bb43:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  %t136 = add i64 %t134, 2
  %t137 = load i64, ptr %l1, !tbaa !24
  %t139 = add i64 %t137, 4
  %t143 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t133, i64 %t136, i64 %t139)
  store i1 %t143, ptr %l74
  br label %bb45
bb44:
  br label %bb49
bb45:
  %t144 = load i1, ptr %l74, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb46, label %bb47
bb46:
  %t147 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t150 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t147, 0
  %t151 = insertvalue { { i64, ptr }, i64 } %t150, i64 2, 1
  store { { i64, ptr }, i64 } %t151, ptr %l78
  %t152 = getelementptr { { i64, ptr }, i64 }, ptr %l78, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l79, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l80, !tbaa !24
  %t156 = load i64, ptr %l80, !tbaa !24
  %t157 = mul i64 %t156, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l81, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l80, !tbaa !24
  %t166 = mul i64 %t165, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t162, ptr %t164, i64 %t166, i1 false)
  %t167 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t168 = getelementptr { { i64, ptr }, i64 }, ptr %l78, i32 0, i32 0
  store { i64, ptr } %t167, ptr %t168, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t169 = load { { i64, ptr }, i64 }, ptr %l78
  store { { i64, ptr }, i64 } %t169, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t170 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t171 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t174 = extractvalue { i64, ptr } %t170, 1
  %t175 = extractvalue { i64, ptr } %t170, 0
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t171, i64 %t172)
  %t181 = getelementptr i8, ptr %t180, i64 %t172
  call void @olang_textcopy(ptr %t181, ptr %t174, i64 %t175)
  %t182 = getelementptr i8, ptr %t181, i64 %t175
  call void @olang_textcopy(ptr %t182, ptr %t177, i64 %t178)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t180, 1
  %t186 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t184, 0
  %t187 = insertvalue { { i64, ptr }, i64 } %t186, i64 4, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t187, ptr %rv
  br label %ret
bb49:
  %t189 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t192 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t189, 0
  %t193 = insertvalue { { i64, ptr }, i64 } %t192, i64 4, 1
  store { { i64, ptr }, i64 } %t193, ptr %l87
  %t194 = getelementptr { { i64, ptr }, i64 }, ptr %l87, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l88, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  store i64 %t197, ptr %l89, !tbaa !24
  %t198 = load i64, ptr %l89, !tbaa !24
  %t199 = mul i64 %t198, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l90, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l89, !tbaa !24
  %t208 = mul i64 %t207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %t206, i64 %t208, i1 false)
  %t209 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t210 = getelementptr { { i64, ptr }, i64 }, ptr %l87, i32 0, i32 0
  store { i64, ptr } %t209, ptr %t210, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t211 = load { { i64, ptr }, i64 }, ptr %l87
  store { { i64, ptr }, i64 } %t211, ptr %rv
  br label %ret
bb50:
  %t212 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t214 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t212, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t214, ptr %l92
  br label %bb51
bb51:
  %t215 = load i1, ptr %l92, !tbaa !21
  %t216 = xor i1 %t215, true
  br i1 %t216, label %bb52, label %bb53
bb52:
  %t218 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t219 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t222 = extractvalue { i64, ptr } %t218, 1
  %t223 = extractvalue { i64, ptr } %t218, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t219, i64 %t220)
  %t229 = getelementptr i8, ptr %t228, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t222, i64 %t223)
  %t230 = getelementptr i8, ptr %t229, i64 %t223
  call void @olang_textcopy(ptr %t230, ptr %t225, i64 %t226)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t228, 1
  %t234 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t232, 0
  %t235 = insertvalue { { i64, ptr }, i64 } %t234, i64 8, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t235, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i64, ptr %l1, !tbaa !24
  %t240 = add i64 %t238, 4
  %t243 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t237, i64 %t240)
  store i64 %t243, ptr %l100
  br label %bb55
bb55:
  %t244 = load i64, ptr %l100, !tbaa !24
  store i64 %t244, ptr %l8, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t247 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t245, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t247, ptr %l102
  br label %bb56
bb56:
  %t248 = load i1, ptr %l102, !tbaa !21
  br i1 %t248, label %bb57, label %bb58
bb57:
  %t249 = load i64, ptr %l8, !tbaa !24
  %t251 = icmp sge i64 %t249, 0
  store i1 %t251, ptr %l103, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb59
bb59:
  %t253 = load i1, ptr %l103, !tbaa !21
  br i1 %t253, label %bb60, label %bb61
bb60:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l8, !tbaa !24
  %t259 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t254, i64 %t256)
  store %"compiler/cabi:Scalar" %t259, ptr %l110
  br label %bb62
bb61:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb64
bb62:
  %t260 = getelementptr %"compiler/cabi:Scalar", ptr %l110, i32 0, i32 2
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t263 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t261, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t263, ptr %l112
  br label %bb63
bb63:
  %t264 = load i1, ptr %l112, !tbaa !21
  store i1 %t264, ptr %l106, !tbaa !21
  br label %bb64
bb64:
  %t265 = load i1, ptr %l106, !tbaa !21
  br i1 %t265, label %bb65, label %bb66
bb65:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l113, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t268 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t266, 0
  %t269 = insertvalue { { i64, ptr }, i64 } %t268, i64 8, 1
  store { { i64, ptr }, i64 } %t269, ptr %l115
  %t270 = getelementptr { { i64, ptr }, i64 }, ptr %l115, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  store { i64, ptr } %t271, ptr %l116, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l117, !tbaa !24
  %t274 = load i64, ptr %l117, !tbaa !24
  %t275 = mul i64 %t274, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t275)
  %t277 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l118, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = load i64, ptr %l117, !tbaa !24
  %t284 = mul i64 %t283, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t280, ptr %t282, i64 %t284, i1 false)
  %t285 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t286 = getelementptr { { i64, ptr }, i64 }, ptr %l115, i32 0, i32 0
  store { i64, ptr } %t285, ptr %t286, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t287 = load { { i64, ptr }, i64 }, ptr %l115
  store { { i64, ptr }, i64 } %t287, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t288 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t291 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t288, 0
  %t292 = insertvalue { { i64, ptr }, i64 } %t291, i64 8, 1
  store { { i64, ptr }, i64 } %t292, ptr %l121
  %t293 = getelementptr { { i64, ptr }, i64 }, ptr %l121, i32 0, i32 0
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  store { i64, ptr } %t294, ptr %l122, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 0
  store i64 %t296, ptr %l123, !tbaa !24
  %t297 = load i64, ptr %l123, !tbaa !24
  %t298 = mul i64 %t297, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t298)
  %t300 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  store { i64, ptr } %t301, ptr %l124, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = load i64, ptr %l123, !tbaa !24
  %t307 = mul i64 %t306, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t303, ptr %t305, i64 %t307, i1 false)
  %t308 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t309 = getelementptr { { i64, ptr }, i64 }, ptr %l121, i32 0, i32 0
  store { i64, ptr } %t308, ptr %t309, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t310 = load { { i64, ptr }, i64 }, ptr %l121
  store { { i64, ptr }, i64 } %t310, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2etestDecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca %"compiler/cabi:Way"
  %l4 = alloca %"compiler/cabi:Regs"
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"compiler/cabi:Way"
  %l9 = alloca i32
  %l13 = alloca %"compiler/cabi:Way"
  %l14 = alloca %"compiler/cabi:Regs"
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca %"compiler/cabi:Way"
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v1, ptr %s0, ptr %v3, ptr %t1, { i64, ptr } %t2, i32 %t3)
  store %"compiler/cabi:Way" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"compiler/cabi:Way", ptr %l13
  store %"compiler/cabi:Way" %t8, ptr %l3
  %t9 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load %"compiler/cabi:Regs", ptr %l14
  store %"compiler/cabi:Regs" %t10, ptr %l4
  %t11 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t12 = load i32, ptr %t11, !range !{i32 0, i32 5}
  store i32 %t12, ptr %l5
  %t14 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s1, ptr %v3, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l21
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb7:
  %t31 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t33 = trunc i64 1 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t37 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t37, ptr %l26
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t38, ptr %l16, !tbaa !27
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9727aebca4df1374_94c7225b64063378)
  unreachable
bb17:
  %t41 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l29, !tbaa !24
  %t43 = load i64, ptr %l29, !tbaa !24
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l30, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l29, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  %t54 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t54, ptr %l6, !tbaa !27
  %t55 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t55, ptr %l31
  br label %bb18
bb18:
  %t56 = load %"std/prelude/text:StringBuilder", ptr %l31
  store %"std/prelude/text:StringBuilder" %t56, ptr %l7
  %t57 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 5}
  %t60 = trunc i64 4 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l7, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d55, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t64 = getelementptr %"compiler/cabi:Regs", ptr %l4, i32 0, i32 0
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = sub i64 %t65, 1
  %t70 = getelementptr %"compiler/cabi:Regs", ptr %l4, i32 0, i32 0
  store i64 %t68, ptr %t70, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t73 = load i32, ptr %l2, !tbaa !23
  %t78 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eParam(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %v3, ptr %t71, { i64, ptr } %t72, i32 %t73, ptr %l4)
  store %"compiler/cabi:Way" %t78, ptr %l42
  br label %bb23
bb23:
  %t79 = load %"compiler/cabi:Way", ptr %l42
  store %"compiler/cabi:Way" %t79, ptr %l8
  store ptr %l7, ptr %l43, !tbaa !29
  %t80 = getelementptr %"compiler/cabi:Way", ptr %l8, i32 0, i32 0
  %t81 = load i32, ptr %t80, !range !{i32 0, i32 5}
  store i32 %t81, ptr %l9
  %t83 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t85 = trunc i64 0 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l2, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s6, ptr %v3, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l50
  br label %bb27
bb27:
  %t93 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t94, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb28:
  %t101 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t103 = trunc i64 1 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t107 = call { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t107, ptr %l56
  br label %bb32
bb32:
  %t108 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t108, ptr %l45, !tbaa !27
  br label %bb46
bb33:
  %t110 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t112 = trunc i64 2 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb46
bb37:
  %t115 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t117 = trunc i64 3 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb46
bb41:
  %t120 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t122 = trunc i64 4 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_8f84916f6bbe2da5_8f456227b094de49)
  unreachable
bb46:
  %t125 = load ptr, ptr %l43, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t125, { i64, ptr } %t126)
  br label %bb47
bb47:
  %t127 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t127, ptr %l64, !tbaa !27
  %t129 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t129, ptr %l66
  br label %bb48
bb48:
  %t130 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t131, i64 %t132)
  %t144 = getelementptr i8, ptr %t143, i64 %t132
  call void @olang_textcopy(ptr %t144, ptr %t133, i64 %t134)
  %t145 = getelementptr i8, ptr %t144, i64 %t134
  call void @olang_textcopy(ptr %t145, ptr %t137, i64 %t138)
  %t146 = getelementptr i8, ptr %t145, i64 %t138
  call void @olang_textcopy(ptr %t146, ptr %t140, i64 %t141)
  %t147 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t143, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t148, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/cabi:Scalar"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/cabi:Scalar" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/cabi:Scalar" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/cabi:Scalar" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/cabi:Scalar" %t14, i1 %a3, 3
  store %"compiler/cabi:Scalar" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Scalar", ptr %rv
  ret %"compiler/cabi:Scalar" %rr
}

@.d0 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"x86_64-windows" }>, align 8
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"zeroext" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"zeroext" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"zeroext" }>, align 8
@.d8 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"signext" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d12 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"x86_64-windows" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fcabi_3aWay_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare ptr @__olang_region_home(ptr)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"compiler/cabi:Way" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/cabi:Way"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/cabi:Way"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/cabi:Way", ptr %a0
  store %"compiler/cabi:Way" %t2, ptr %l1
  %t3 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 2
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 3
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l7
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t17 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = load %"compiler/cabi:Way", ptr %l1
  store %"compiler/cabi:Way" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" x " }>, align 8
@.d22 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"] alignstack(8)" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"[2 x i64]" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fcabi_3aWay_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcabi_3aWay_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcabi_3aWay_2e4 = weak hidden constant i1 false
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d34 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d36 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d41 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fcabi__2esseAt_2elocal_2e4 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d46 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<2 x " }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<4 x " }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d52 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d53 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"<2 x float>" }>, align 8
@.d54 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d55 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"sret, " }>, align 8
@.d56 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"byval" }>, align 8
@.d57 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/cabi:Scalar" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3, { i64, ptr } %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %a0)
declare %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcabi_2eat(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcabi_2edata(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_9727aebca4df1374_94c7225b64063378 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_8f84916f6bbe2da5_8f456227b094de49 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
