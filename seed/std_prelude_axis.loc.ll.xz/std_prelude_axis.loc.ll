; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_4faaa7f9de26fcf4_7f72e248c84ee068 = weak_odr constant [48 x i8] c"std/prelude/axis.olang:14: unreachable reached\0A\00"
