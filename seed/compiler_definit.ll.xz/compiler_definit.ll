; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/definit:heldWalker" = type { i32, i32, i64, i1, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/definit:Walker" = type { ptr, i32, i1, %"compiler/source:Span", i32, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/definit:State" = type { i1, i1, i32, %"compiler/source:Span" }
%"compiler/definit:Verdict" = type { i1, %"compiler/source:Span", i32, %"compiler/source:Span" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
define dso_local i64 @compiler_2fdefinit_2eHeldWalk(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/definit:heldWalker"
  %l10 = alloca %"compiler/definit:heldWalker"
  %l11 = alloca ptr
  %l20 = alloca i1
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = call %"compiler/definit:heldWalker" @compiler_2fdefinit_3aheldWalker_2ector(ptr %s0, i32 %a1, i32 %a2)
  store %"compiler/definit:heldWalker" %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load %"compiler/definit:heldWalker", ptr %l10
  store %"compiler/definit:heldWalker" %t14, ptr %l3
  store ptr %l3, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 11
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_98f0ccb4874a0151_2f8f084c984a7dad)
  unreachable
bb6:
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 11
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %s0, ptr %v0, ptr %t27, ptr %t25, i1 false)
  br label %bb8
bb8:
  %t29 = getelementptr %"compiler/definit:heldWalker", ptr %l3, i32 0, i32 2
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = icmp eq i64 %t30, 1
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr %"compiler/definit:heldWalker", ptr %l3, i32 0, i32 3
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = getelementptr %"compiler/definit:heldWalker", ptr %l3, i32 0, i32 4
  %t39 = load i64, ptr %t38, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb14
bb13:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i64, ptr %l22, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fdefinit_2eReadIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/definit:Walker"
  %l5 = alloca %"compiler/definit:State"
  %l8 = alloca %"compiler/definit:Walker"
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/definit:State"
  %l14 = alloca %"compiler/definit:State"
  %l20 = alloca %"compiler/definit:State"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call %"compiler/definit:Walker" @compiler_2fdefinit_3aWalker_2ector(ptr %v0, ptr %s0, ptr %a0, i32 %a1)
  store %"compiler/definit:Walker" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"compiler/definit:Walker", ptr %l8
  store %"compiler/definit:Walker" %t6, ptr %l4
  store ptr %l4, ptr %l9, !tbaa !29
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  store i32 0, ptr %l11
  %t8 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = load i32, ptr %l11, !range !{i32 0, i32 6}
  %t10 = load %"compiler/source:Span", ptr %l12
  %t11 = call %"compiler/definit:State" @compiler_2fdefinit_3aState_2ector(ptr %s0, i1 true, i1 false, i32 %t9, %"compiler/source:Span" %t10)
  store %"compiler/definit:State" %t11, ptr %l13
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t14 = load %"compiler/definit:State", ptr %l13
  %t15 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmts(ptr %s0, ptr %v1, ptr %t12, { i64, ptr } %t13, %"compiler/definit:State" %t14)
  store %"compiler/definit:State" %t15, ptr %l14
  br label %bb4
bb4:
  %t16 = load %"compiler/definit:State", ptr %l14
  store %"compiler/definit:State" %t16, ptr %l5
  %t17 = getelementptr %"compiler/definit:Walker", ptr %l4, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t17, i1 true)
  br label %bb5
bb5:
  %t21 = load %"compiler/definit:State", ptr %l5
  %t25 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %s0, ptr %v2, ptr %l4, ptr %a3, %"compiler/definit:State" %t21)
  store %"compiler/definit:State" %t25, ptr %l20
  br label %bb6
bb6:
  %t26 = getelementptr %"compiler/definit:Walker", ptr %l4, i32 0, i32 2
  %t27 = load i1, ptr %t26, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead() #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/definit:State"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/definit:State"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr %l0
  %t1 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !range !{i32 0, i32 6}
  %t3 = load %"compiler/source:Span", ptr %l1
  %t4 = call %"compiler/definit:State" @compiler_2fdefinit_3aState_2ector(ptr %s0, i1 false, i1 false, i32 %t2, %"compiler/source:Span" %t3)
  store %"compiler/definit:State" %t4, ptr %l2
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t5 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t5, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:Verdict" @compiler_2fdefinit_2eVerdict_2eJudge(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/definit:Walker"
  %l4 = alloca %"compiler/definit:State"
  %l7 = alloca %"compiler/definit:Walker"
  %l9 = alloca %"compiler/definit:State"
  %l11 = alloca i1
  %l13 = alloca i1
  %l24 = alloca %"compiler/definit:Verdict"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/definit:Verdict"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/definit:Walker" @compiler_2fdefinit_3aWalker_2ector(ptr %v0, ptr %s0, ptr %t1, i32 %a1)
  store %"compiler/definit:Walker" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"compiler/definit:Walker", ptr %l7
  store %"compiler/definit:Walker" %t6, ptr %l3
  %t8 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eRun(ptr %s0, ptr %l3)
  store %"compiler/definit:State" %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load %"compiler/definit:State", ptr %l9
  store %"compiler/definit:State" %t9, ptr %l4
  br i1 %a2, label %bb3, label %bb4
bb3:
  %t12 = getelementptr %"compiler/definit:State", ptr %l4, i32 0, i32 0
  %t13 = load i1, ptr %t12, !tbaa !21
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = getelementptr %"compiler/definit:State", ptr %l4, i32 0, i32 1
  %t17 = load i1, ptr %t16, !tbaa !21
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t22 = load %"compiler/definit:State", ptr %l4
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 4
  %t26 = load %"compiler/source:Span", ptr %t25
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eread(ptr %s0, ptr %l3, %"compiler/definit:State" %t22, %"compiler/source:Span" %t26)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t30 = getelementptr %"compiler/definit:Walker", ptr %l3, i32 0, i32 2
  %t31 = load i1, ptr %t30, !tbaa !21
  %t32 = getelementptr %"compiler/definit:Walker", ptr %l3, i32 0, i32 3
  %t33 = load %"compiler/source:Span", ptr %t32
  %t34 = getelementptr %"compiler/definit:Walker", ptr %l3, i32 0, i32 4
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 6}
  %t36 = getelementptr %"compiler/definit:Walker", ptr %l3, i32 0, i32 5
  %t37 = load %"compiler/source:Span", ptr %t36
  %t42 = call %"compiler/definit:Verdict" @compiler_2fdefinit_3aVerdict_2ector(ptr %s0, i1 %t31, %"compiler/source:Span" %t33, i32 %t35, %"compiler/source:Span" %t37)
  store %"compiler/definit:Verdict" %t42, ptr %l24
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/definit:Verdict", ptr %l24
  store %"compiler/definit:Verdict" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:Verdict", ptr %rv
  ret %"compiler/definit:Verdict" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eRun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/definit:State"
  %l7 = alloca %"compiler/definit:State"
  %rv = alloca %"compiler/definit:State"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/definit:Walker", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Body", ptr %t5, i32 0, i32 11
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load %"compiler/definit:State", ptr %l6
  %t13 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v0, ptr %t10, ptr %t11, %"compiler/definit:State" %t12)
  store %"compiler/definit:State" %t13, ptr %l7
  br label %bb2
bb2:
  %t14 = load %"compiler/definit:State", ptr %l7
  store %"compiler/definit:State" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/definit:State"
  %l10 = alloca %"compiler/definit:State"
  %rv = alloca %"compiler/definit:State"
  store ptr %a1, ptr %l1
  store %"compiler/definit:State" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Block", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t12 = load %"compiler/definit:State", ptr %l2
  %t16 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t11, %"compiler/definit:State" %t12)
  store %"compiler/definit:State" %t16, ptr %l10
  br label %bb4
bb4:
  %t17 = load %"compiler/definit:State", ptr %l10
  store %"compiler/definit:State" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/definit:State" %a2, %"compiler/definit:State" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/definit:State"
  %l4 = alloca %"compiler/definit:State"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/definit:State"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l26 = alloca { i64, ptr }
  %l33 = alloca %"compiler/definit:State"
  %l42 = alloca { i64, ptr }
  %l49 = alloca %"compiler/definit:State"
  %l53 = alloca %"compiler/definit:State"
  %l60 = alloca %"compiler/definit:State"
  %l61 = alloca %"compiler/definit:State"
  %rv = alloca %"compiler/definit:State"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store %"compiler/definit:State" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/definit:State" %a3, ptr %l4
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load %"compiler/definit:State", ptr %l4
  store %"compiler/definit:State" %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb19
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t25, ptr %l26, !tbaa !27
  %t26 = load i64, ptr %l6, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l8, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l8, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Clause", ptr %t34, i32 0, i32 3
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load %"compiler/definit:State", ptr %l2
  %t42 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t33, ptr %t37, %"compiler/definit:State" %t38)
  store %"compiler/definit:State" %t42, ptr %l33
  br label %bb8
bb8:
  %t43 = load %"compiler/definit:State", ptr %l33
  store %"compiler/definit:State" %t43, ptr %l9
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Clause", ptr %t44, i32 0, i32 4
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l11, !tbaa !24
  %t54 = load i64, ptr %l12, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t61 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t61, ptr %l42, !tbaa !27
  %t62 = load i64, ptr %l11, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/definit:State", ptr %l9
  %t76 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t69, ptr %t67, %"compiler/definit:State" %t72)
  store %"compiler/definit:State" %t76, ptr %l49
  br label %bb13
bb13:
  %t77 = load %"compiler/definit:State", ptr %l49
  store %"compiler/definit:State" %t77, ptr %l9
  br label %bb14
bb14:
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l11, !tbaa !24
  br label %bb9
bb15:
  %t83 = load %"compiler/definit:State", ptr %l4
  store %"compiler/definit:State" %t83, ptr %l53
  %t84 = load %"compiler/definit:State", ptr %l9
  %t85 = load %"compiler/definit:State", ptr %l2
  %t86 = load %"compiler/definit:State", ptr %l4
  %t87 = load ptr, ptr %l8, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Clause", ptr %t87, i32 0, i32 0
  %t90 = load %"compiler/source:Span", ptr %t89
  %t96 = call %"compiler/definit:State" @compiler_2fdefinit_2eretag(%"compiler/definit:State" %t84, %"compiler/definit:State" %t85, %"compiler/definit:State" %t86, i32 5, %"compiler/source:Span" %t90)
  store %"compiler/definit:State" %t96, ptr %l60
  br label %bb16
bb16:
  %t97 = load %"compiler/definit:State", ptr %l53
  %t98 = load %"compiler/definit:State", ptr %l60
  %t99 = call %"compiler/definit:State" @compiler_2fdefinit_2emeet(%"compiler/definit:State" %t97, %"compiler/definit:State" %t98)
  store %"compiler/definit:State" %t99, ptr %l61
  br label %bb17
bb17:
  %t100 = load %"compiler/definit:State", ptr %l61
  store %"compiler/definit:State" %t100, ptr %l4
  br label %bb18
bb18:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l6, !tbaa !24
  br label %bb4
bb19:
  %t106 = load %"compiler/definit:State", ptr %l4
  store %"compiler/definit:State" %t106, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/definit:State"
  %l3 = alloca %"compiler/definit:State"
  %l10 = alloca %"compiler/definit:State"
  %l12 = alloca i32
  %l15 = alloca %"compiler/definit:State"
  %rv = alloca %"compiler/definit:State"
  store ptr %a1, ptr %l1
  store %"compiler/definit:State" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load %"compiler/definit:State", ptr %l2
  %t13 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr1(ptr %v0, ptr %v1, ptr %a0, ptr %t8, %"compiler/definit:State" %t9)
  store %"compiler/definit:State" %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load %"compiler/definit:State", ptr %l10
  store %"compiler/definit:State" %t14, ptr %l3
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t15)
  store i32 %t17, ptr %l12
  br label %bb5
bb5:
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t19 = load i32, ptr %l12, !tbaa !23
  %t21 = icmp eq i32 %t19, %t18
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t23, ptr %l15
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t24 = load %"compiler/definit:State", ptr %l15
  store %"compiler/definit:State" %t24, ptr %rv
  br label %ret
bb9:
  %t25 = load %"compiler/definit:State", ptr %l3
  store %"compiler/definit:State" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/definit:State"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca %"compiler/definit:State"
  %l43 = alloca ptr
  %l44 = alloca i1
  %l52 = alloca %"compiler/definit:State"
  %l53 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l67 = alloca %"compiler/definit:State"
  %l68 = alloca %"compiler/definit:State"
  %l69 = alloca ptr
  %l70 = alloca i1
  %l79 = alloca %"compiler/definit:State"
  %l80 = alloca ptr
  %l81 = alloca i1
  %l90 = alloca %"compiler/definit:State"
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca i64
  %l101 = alloca i1
  %l103 = alloca ptr
  %l106 = alloca i64
  %l108 = alloca i1
  %rv = alloca %"compiler/definit:State"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/definit:State" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load i32, ptr %l4, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/definit:Walker", ptr %t23, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  %t29 = icmp eq i32 %t22, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/definit:State", ptr %l2
  %t33 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eread(ptr %v0, ptr %t31, %"compiler/definit:State" %t32, %"compiler/source:Span" %t33)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t37 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t37, ptr %rv
  br label %ret
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l27, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 1
  store i1 %t46, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t48 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t48, ptr %rv
  br label %ret
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t51 = load ptr, ptr %l32, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 2
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = load %"compiler/definit:State", ptr %l2
  %t72 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t66, %"compiler/definit:State" %t68)
  store %"compiler/definit:State" %t72, ptr %l42
  br label %bb22
bb22:
  %t73 = load %"compiler/definit:State", ptr %l42
  store %"compiler/definit:State" %t73, ptr %rv
  br label %ret
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t75 = load ptr, ptr %l43, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 8}
  %t81 = icmp eq i64 %t79, 3
  store i1 %t81, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l44, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t91 = load %"compiler/definit:State", ptr %l2
  %t95 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %t89, ptr %t90, %"compiler/definit:State" %t91)
  store %"compiler/definit:State" %t95, ptr %l52
  br label %bb29
bb29:
  %t96 = load %"compiler/definit:State", ptr %l52
  store %"compiler/definit:State" %t96, ptr %rv
  br label %ret
bb30:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t98 = load ptr, ptr %l53, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l53, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 8}
  %t104 = icmp eq i64 %t102, 4
  store i1 %t104, ptr %l54, !tbaa !21
  br label %bb32
bb32:
  %t105 = load i1, ptr %l54, !tbaa !21
  br i1 %t105, label %bb33, label %bb34
bb33:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l7, !tbaa !29
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l59, !tbaa !29
  %t113 = load ptr, ptr %l7, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Elem", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l62, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l7, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Elem", ptr %t119, i32 0, i32 0
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = load %"compiler/definit:State", ptr %l2
  %t127 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %t118, ptr %t122, %"compiler/definit:State" %t123)
  store %"compiler/definit:State" %t127, ptr %l67
  br label %bb36
bb36:
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = load ptr, ptr %l62, !tbaa !29
  %t130 = load %"compiler/definit:State", ptr %l67
  %t131 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t128, ptr %t129, %"compiler/definit:State" %t130)
  store %"compiler/definit:State" %t131, ptr %l68
  br label %bb37
bb37:
  %t132 = load %"compiler/definit:State", ptr %l68
  store %"compiler/definit:State" %t132, ptr %rv
  br label %ret
bb38:
  %t133 = load ptr, ptr %l1, !tbaa !29
  store ptr %t133, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb39, label %bb40
bb39:
  %t137 = load ptr, ptr %l69, !tbaa !29
  %t138 = load i64, ptr %t137, !range !{i64 0, i64 8}
  %t140 = icmp eq i64 %t138, 5
  store i1 %t140, ptr %l70, !tbaa !21
  br label %bb40
bb40:
  %t141 = load i1, ptr %l70, !tbaa !21
  br i1 %t141, label %bb41, label %bb42
bb41:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t144, i32 0, i32 2
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l8, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l8, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Payload", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t153 = load %"compiler/definit:State", ptr %l2
  %t157 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %t148, ptr %t152, %"compiler/definit:State" %t153)
  store %"compiler/definit:State" %t157, ptr %l79
  br label %bb44
bb44:
  %t158 = load %"compiler/definit:State", ptr %l79
  store %"compiler/definit:State" %t158, ptr %rv
  br label %ret
bb45:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t160 = load ptr, ptr %l80, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t163 = load ptr, ptr %l80, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 8}
  %t166 = icmp eq i64 %t164, 6
  store i1 %t166, ptr %l81, !tbaa !21
  br label %bb47
bb47:
  %t167 = load i1, ptr %l81, !tbaa !21
  br i1 %t167, label %bb48, label %bb49
bb48:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [4 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l9, !tbaa !29
  %t177 = load %"compiler/definit:State", ptr %l2
  %t181 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t174, ptr %t175, %"compiler/definit:State" %t177)
  store %"compiler/definit:State" %t181, ptr %l90
  br label %bb51
bb51:
  %t182 = load %"compiler/definit:State", ptr %l90
  store %"compiler/definit:State" %t182, ptr %rv
  br label %ret
bb52:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t184 = load ptr, ptr %l91, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb53, label %bb54
bb53:
  %t187 = load ptr, ptr %l91, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 8}
  %t190 = icmp eq i64 %t188, 7
  store i1 %t190, ptr %l92, !tbaa !21
  br label %bb54
bb54:
  %t191 = load i1, ptr %l92, !tbaa !21
  br i1 %t191, label %bb55, label %bb56
bb55:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", i32 }, ptr %t194, i32 0, i32 0
  %t196 = load %"compiler/source:Span", ptr %t195
  store %"compiler/source:Span" %t196, ptr %l10
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/definit:Walker", ptr %t198, i32 0, i32 6
  %t202 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t200)
  store i64 %t202, ptr %l99
  br label %bb58
bb58:
  %t203 = load i64, ptr %l99, !tbaa !24
  %t204 = icmp sgt i64 %t203, 0
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/definit:Walker", ptr %t206, i32 0, i32 6
  store ptr %t208, ptr %l103, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/definit:Walker", ptr %t209, i32 0, i32 6
  %t213 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t211)
  store i64 %t213, ptr %l106
  br label %bb61
bb60:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb63
bb61:
  %t214 = load i64, ptr %l106, !tbaa !24
  %t215 = sub i64 %t214, 1
  %t216 = load ptr, ptr %l103, !tbaa !29
  %t218 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t216, i64 %t215)
  store i1 %t218, ptr %l108
  br label %bb62
bb62:
  %t219 = load i1, ptr %l108, !tbaa !21
  store i1 %t219, ptr %l101, !tbaa !21
  br label %bb63
bb63:
  %t220 = load i1, ptr %l101, !tbaa !21
  br i1 %t220, label %bb64, label %bb65
bb64:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load %"compiler/definit:State", ptr %l2
  %t223 = load %"compiler/source:Span", ptr %l10
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eread(ptr %v0, ptr %t221, %"compiler/definit:State" %t222, %"compiler/source:Span" %t223)
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb67
bb67:
  %t227 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t227, ptr %rv
  br label %ret
bb68:
  call void @__olang_check_failed(ptr @olang_loc_2c3786087cdb93b5_d0365e9ed2e87ce9)
  unreachable
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eread(ptr %v0, ptr %a0, %"compiler/definit:State" %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/definit:State"
  %l5 = alloca i1
  %l8 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/definit:State" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/definit:Walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t6 = getelementptr %"compiler/definit:State", ptr %l1, i32 0, i32 0
  %t7 = load i1, ptr %t6, !tbaa !21
  %t9 = xor i1 %t7, true
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t12 = getelementptr %"compiler/definit:State", ptr %l1, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/definit:Walker", ptr %t16, i32 0, i32 2
  store i1 true, ptr %t18, !tbaa !21
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/definit:Walker", ptr %t19, i32 0, i32 3
  store %"compiler/source:Span" %a2, ptr %t23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/definit:State", ptr %l1, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 6}
  %t29 = getelementptr %"compiler/definit:Walker", ptr %t24, i32 0, i32 4
  store i32 %t26, ptr %t29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/definit:State", ptr %l1, i32 0, i32 3
  %t32 = load %"compiler/source:Span", ptr %t31
  %t35 = getelementptr %"compiler/definit:Walker", ptr %t30, i32 0, i32 5
  store %"compiler/source:Span" %t32, ptr %t35
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/definit:State" %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"compiler/definit:State"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l20 = alloca { i64, ptr }
  %l26 = alloca %"compiler/definit:State"
  %rv = alloca %"compiler/definit:State"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/definit:State" %a2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load %"compiler/definit:State", ptr %l3
  store %"compiler/definit:State" %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t25, ptr %l20, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t35 = load %"compiler/definit:State", ptr %l3
  %t39 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t31, %"compiler/definit:State" %t35)
  store %"compiler/definit:State" %t39, ptr %l26
  br label %bb8
bb8:
  %t40 = load %"compiler/definit:State", ptr %l26
  store %"compiler/definit:State" %t40, ptr %l3
  br label %bb9
bb9:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  %t46 = load %"compiler/definit:State", ptr %l3
  store %"compiler/definit:State" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l38 = alloca i64
  %l47 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 %a2, ptr %l3, !tbaa !21
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb38
bb6:
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l22, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l7, !tbaa !29
  %t32 = load ptr, ptr %l7, !tbaa !29
  store ptr %t32, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l25, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 17}
  %t39 = icmp eq i64 %t37, 0
  store i1 %t39, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l26, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t43 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 1
  %t45 = load i32, ptr %t44
  store i32 %t45, ptr %l8, !tbaa !23
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l9, !tbaa !29
  br label %bb12
bb11:
  br label %bb30
bb12:
  %t53 = load i32, ptr %l8, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/definit:heldWalker", ptr %t54, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = icmp eq i32 %t53, %t57
  br i1 %t60, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l3, !tbaa !21
  %t62 = load ptr, ptr %l9, !tbaa !29
  %t64 = call i64 @compiler_2ftyped_2eCalledBody(ptr %v1, ptr %t62)
  store i64 %t64, ptr %l38
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t65 = load i64, ptr %l38, !tbaa !24
  store i64 %t65, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp sge i64 %t66, 0
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = getelementptr %"compiler/definit:heldWalker", ptr %t70, i32 0, i32 4
  store i64 %t71, ptr %t74, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t75 = load i32, ptr %l8, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/definit:heldWalker", ptr %t76, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t82 = icmp eq i32 %t75, %t79
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load i1, ptr %l3, !tbaa !21
  store i1 %t84, ptr %l47, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l47, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l9, !tbaa !29
  %t91 = call i1 @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2ereadsG(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store i1 %t91, ptr %l52
  br label %bb25
bb24:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb26
bb25:
  %t92 = load i1, ptr %l52, !tbaa !21
  store i1 %t92, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t93 = load i1, ptr %l49, !tbaa !21
  br i1 %t93, label %bb27, label %bb28
bb27:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/definit:heldWalker", ptr %t94, i32 0, i32 3
  store i1 true, ptr %t96, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d952dfd7a131b942_4ab1800a85b68e5e)
  unreachable
bb35:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t99 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2estmt(ptr %v0, ptr %v1, ptr %t97, ptr %t98, i1 %t99)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t106 = add i64 %t103, 1
  store i64 %t106, ptr %l5, !tbaa !24
  br label %bb4
bb38:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l17 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l6, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l6, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t29, ptr %t33, i1 %t34)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Clause", ptr %t39, i32 0, i32 4
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexprs(ptr %v0, ptr %v1, ptr %t38, { i64, ptr } %t42, i1 %t43)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb4
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t27, i1 %a2)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eisG(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = getelementptr %"compiler/definit:heldWalker", ptr %a0, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t23 = icmp eq i32 %t16, %t20
  store i1 %t23, ptr %l3, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d9e86c57eee4683e_b043e463d27920c2)
  unreachable
bb11:
  %t25 = load i1, ptr %l3, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/definit:heldWalker", ptr %t17, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t23 = icmp eq i32 %t16, %t20
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l19, !tbaa !29
  %t26 = load ptr, ptr %l19, !tbaa !29
  %t27 = getelementptr %"compiler/definit:heldWalker", ptr %t26, i32 0, i32 2
  %t28 = load i64, ptr %t27, !tbaa !24
  %t31 = add i64 %t28, 1
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = getelementptr %"compiler/definit:heldWalker", ptr %t33, i32 0, i32 2
  store i64 %t31, ptr %t34, !tbaa !24
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb56
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 8}
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t45 = load ptr, ptr %l27, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 8}
  %t51 = icmp eq i64 %t49, 7
  store i1 %t51, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb56
bb19:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t68, ptr %t69, i1 %t71)
  br label %bb25
bb25:
  br label %bb56
bb26:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t76 = load ptr, ptr %l41, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb27, label %bb28
bb27:
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 8}
  %t82 = icmp eq i64 %t80, 3
  store i1 %t82, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t83 = load i1, ptr %l42, !tbaa !21
  br i1 %t83, label %bb29, label %bb30
bb29:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t92 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %t90, ptr %t91, i1 %t92)
  br label %bb32
bb32:
  br label %bb56
bb33:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t97 = load ptr, ptr %l50, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb34, label %bb35
bb34:
  %t100 = load ptr, ptr %l50, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 8}
  %t103 = icmp eq i64 %t101, 4
  store i1 %t103, ptr %l51, !tbaa !21
  br label %bb35
bb35:
  %t104 = load i1, ptr %l51, !tbaa !21
  br i1 %t104, label %bb36, label %bb37
bb36:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [4 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Elem", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t116 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %t111, ptr %t115, i1 %t116)
  br label %bb39
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Elem", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t120, ptr %t124, i1 %t126)
  br label %bb40
bb40:
  br label %bb56
bb41:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb42, label %bb43
bb42:
  %t134 = load ptr, ptr %l65, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 5
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb43
bb43:
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb44, label %bb45
bb44:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l7, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l7, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Payload", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %t145, ptr %t149, i1 %t150)
  br label %bb47
bb47:
  br label %bb56
bb48:
  %t154 = load ptr, ptr %l1, !tbaa !29
  store ptr %t154, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t155 = load ptr, ptr %l75, !tbaa !29
  %t156 = icmp ne ptr %t155, null
  br i1 %t156, label %bb49, label %bb50
bb49:
  %t158 = load ptr, ptr %l75, !tbaa !29
  %t159 = load i64, ptr %t158, !range !{i64 0, i64 8}
  %t161 = icmp eq i64 %t159, 6
  store i1 %t161, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t162 = load i1, ptr %l76, !tbaa !21
  br i1 %t162, label %bb51, label %bb52
bb51:
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t163, i32 0, i32 1
  %t166 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t165, i32 0, i32 2
  %t167 = load ptr, ptr %t166
  store ptr %t167, ptr %l8, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l8, !tbaa !29
  %t172 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t169, ptr %t170, i1 %t172)
  br label %bb54
bb54:
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_828a4528b8c70060_f45c4a72375fc35c)
  unreachable
bb56:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2ereadsG(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eisG(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  store i1 %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load i1, ptr %l12, !tbaa !21
  store i1 %t21, ptr %l3, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_9a6d4bf984d4b4b9_118b76f3baa09ee5)
  unreachable
bb12:
  %t22 = load i1, ptr %l3, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2emeet(%"compiler/definit:State" %a0, %"compiler/definit:State" %a1) #0 {
entry:
  %l0 = alloca %"compiler/definit:State"
  %l1 = alloca %"compiler/definit:State"
  %l9 = alloca i1
  %rv = alloca %"compiler/definit:State"
  store %"compiler/definit:State" %a0, ptr %l0
  store %"compiler/definit:State" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/definit:State", ptr %l0, i32 0, i32 0
  %t2 = load i1, ptr %t1, !tbaa !21
  %t4 = xor i1 %t2, true
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load %"compiler/definit:State", ptr %l1
  store %"compiler/definit:State" %t6, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = getelementptr %"compiler/definit:State", ptr %l1, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load %"compiler/definit:State", ptr %l0
  store %"compiler/definit:State" %t13, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = getelementptr %"compiler/definit:State", ptr %l0, i32 0, i32 1
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t18 = getelementptr %"compiler/definit:State", ptr %l1, i32 0, i32 1
  %t19 = load i1, ptr %t18, !tbaa !21
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load %"compiler/definit:State", ptr %l0
  store %"compiler/definit:State" %t22, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t24 = getelementptr %"compiler/definit:State", ptr %l0, i32 0, i32 1
  %t25 = load i1, ptr %t24, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t29 = load %"compiler/definit:State", ptr %l0
  store %"compiler/definit:State" %t29, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t31 = load %"compiler/definit:State", ptr %l1
  store %"compiler/definit:State" %t31, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2eretag(%"compiler/definit:State" %a0, %"compiler/definit:State" %a1, %"compiler/definit:State" %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca %"compiler/definit:State"
  %l1 = alloca %"compiler/definit:State"
  %l2 = alloca %"compiler/definit:State"
  %l7 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i32
  %l17 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca i1
  %l28 = alloca %"compiler/definit:State"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/definit:State"
  store %"compiler/definit:State" %a0, ptr %l0
  store %"compiler/definit:State" %a1, ptr %l1
  store %"compiler/definit:State" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/definit:State", ptr %l0, i32 0, i32 0
  %t2 = load i1, ptr %t1, !tbaa !21
  %t4 = xor i1 %t2, true
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t6 = getelementptr %"compiler/definit:State", ptr %l0, i32 0, i32 1
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load %"compiler/definit:State", ptr %l0
  store %"compiler/definit:State" %t10, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = getelementptr %"compiler/definit:State", ptr %l2, i32 0, i32 0
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = getelementptr %"compiler/definit:State", ptr %l2, i32 0, i32 1
  %t16 = load i1, ptr %t15, !tbaa !21
  %t18 = xor i1 %t16, true
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t21 = load %"compiler/definit:State", ptr %l0
  store %"compiler/definit:State" %t21, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t23 = getelementptr %"compiler/definit:State", ptr %l0, i32 0, i32 2
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 6}
  store i32 %t24, ptr %l15
  %t25 = getelementptr %"compiler/definit:State", ptr %l1, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 6}
  store i32 %t26, ptr %l17
  %t29 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fdefinit_3aCause(ptr %l15, ptr %l17)
  store i1 %t29, ptr %l19
  br label %bb13
bb13:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb14, label %bb15
bb14:
  %t31 = getelementptr %"compiler/definit:State", ptr %l0, i32 0, i32 3
  %t32 = load %"compiler/source:Span", ptr %t31
  store %"compiler/source:Span" %t32, ptr %l21
  %t33 = getelementptr %"compiler/definit:State", ptr %l1, i32 0, i32 3
  %t34 = load %"compiler/source:Span", ptr %t33
  store %"compiler/source:Span" %t34, ptr %l23
  %t37 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l21, ptr %l23)
  store i1 %t37, ptr %l25
  br label %bb16
bb15:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb17
bb16:
  %t38 = load i1, ptr %l25, !tbaa !21
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = call %"compiler/definit:State" @compiler_2fdefinit_3aState_2ector(ptr %s3, i1 true, i1 false, i32 %a3, %"compiler/source:Span" %a4)
  store %"compiler/definit:State" %t44, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  %t45 = load %"compiler/definit:State", ptr %l28
  store %"compiler/definit:State" %t45, ptr %rv
  br label %ret
bb21:
  %t46 = load %"compiler/definit:State", ptr %l0
  store %"compiler/definit:State" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_3aState_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %rv = alloca %"compiler/definit:State"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/definit:State" undef, i1 %a0, 0
  %t12 = insertvalue %"compiler/definit:State" %t10, i1 %a1, 1
  %t14 = insertvalue %"compiler/definit:State" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/definit:State" %t14, %"compiler/source:Span" %a3, 3
  store %"compiler/definit:State" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:Verdict" @compiler_2fdefinit_3aVerdict_2ector(ptr %v0, i1 %a0, %"compiler/source:Span" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %rv = alloca %"compiler/definit:Verdict"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/definit:Verdict" undef, i1 %a0, 0
  %t12 = insertvalue %"compiler/definit:Verdict" %t10, %"compiler/source:Span" %a1, 1
  %t14 = insertvalue %"compiler/definit:Verdict" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/definit:Verdict" %t14, %"compiler/source:Span" %a3, 3
  store %"compiler/definit:Verdict" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:Verdict", ptr %rv
  ret %"compiler/definit:Verdict" %rr
}

define dso_local %"compiler/definit:Walker" @compiler_2fdefinit_3aWalker_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/definit:Walker"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i32 %a1, ptr %l3, !tbaa !23
  store i1 false, ptr %l4, !tbaa !21
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t6, ptr %l5
  store i32 0, ptr %l6
  %t8 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 0, i32 0)
  store %"compiler/source:Span" %t8, ptr %l13
  br label %bb2
bb2:
  %t9 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t9, ptr %l7
  %t10 = call ptr @__olang_scope_hold(ptr %v1)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l14, !tbaa !24
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fdefinit_3aWalker_2e6
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = call ptr @__olang_region_make(ptr %v1)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l14, !tbaa !24
  br label %bb4
bb4:
  %t16 = load i64, ptr %l14
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t17, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l16
  br label %bb5
bb5:
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fdefinit_3aWalker_2e6
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load i64, ptr %l14
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = call ptr @__olang_region_or(ptr %t25, ptr null)
  %t27 = call ptr @__olang_region_home(ptr %t26)
  %t28 = icmp ne ptr %t27, null
  %t29 = select i1 %t28, ptr %t27, ptr null
  call void @__olang_region_settle_in(ptr %t22, ptr %t29)
  br label %bb7
bb7:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = insertvalue %"compiler/definit:Walker" undef, ptr %t31, 0
  %t33 = load i32, ptr %l3, !tbaa !23
  %t34 = insertvalue %"compiler/definit:Walker" %t32, i32 %t33, 1
  %t35 = load i1, ptr %l4, !tbaa !21
  %t36 = insertvalue %"compiler/definit:Walker" %t34, i1 %t35, 2
  %t37 = load %"compiler/source:Span", ptr %l5
  %t38 = insertvalue %"compiler/definit:Walker" %t36, %"compiler/source:Span" %t37, 3
  %t39 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t40 = insertvalue %"compiler/definit:Walker" %t38, i32 %t39, 4
  %t41 = load %"compiler/source:Span", ptr %l7
  %t42 = insertvalue %"compiler/definit:Walker" %t40, %"compiler/source:Span" %t41, 5
  %t44 = insertvalue %"compiler/definit:Walker" %t42, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, 6
  store %"compiler/definit:Walker" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:Walker", ptr %rv
  ret %"compiler/definit:Walker" %rr
}

define dso_local %"compiler/definit:heldWalker" @compiler_2fdefinit_3aheldWalker_2ector(ptr %v0, i32 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/definit:heldWalker"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/definit:heldWalker" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/definit:heldWalker" %t6, i32 %a1, 1
  %t10 = insertvalue %"compiler/definit:heldWalker" %t8, i64 0, 2
  %t12 = insertvalue %"compiler/definit:heldWalker" %t10, i1 false, 3
  %t14 = insertvalue %"compiler/definit:heldWalker" %t12, i64 -1, 4
  store %"compiler/definit:heldWalker" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:heldWalker", ptr %rv
  ret %"compiler/definit:heldWalker" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fdefinit_3aCause(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 6}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 6}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fdefinit_3aWalker_2e6 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
@olang_loc_98f0ccb4874a0151_2f8f084c984a7dad = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr1(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2c3786087cdb93b5_d0365e9ed2e87ce9 = external constant [0 x i8]
declare %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2)
declare i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %a0)
@olang_loc_d952dfd7a131b942_4ab1800a85b68e5e = external constant [0 x i8]
declare void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_d9e86c57eee4683e_b043e463d27920c2 = external constant [0 x i8]
@olang_loc_828a4528b8c70060_f45c4a72375fc35c = external constant [0 x i8]
@olang_loc_9a6d4bf984d4b4b9_118b76f3baa09ee5 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
