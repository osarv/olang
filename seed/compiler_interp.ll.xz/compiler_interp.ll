; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/interp:CondErr" = type { { i64, [3 x i64] }, %"compiler/msgs:Msg" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/generic:ConstAsk" = type { i64, ptr, i32, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/views:Viewer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
define dso_local { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 3 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb4:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 4 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb8:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 5 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb12:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 6 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb16:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 7 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb20:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 9 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb24:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 10 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb28:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 8 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb32:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 11 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb36:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 12 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb40:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 13 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb44:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb45
bb45:
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %lp8 = alloca ptr
  %lp9 = alloca ptr
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/interp:CondErr"
  %l14 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca i64
  %l23 = alloca %"compiler/names:Resolver"
  %l27 = alloca %"compiler/generic:Program"
  %l32 = alloca %"compiler/check:Checker"
  %l43 = alloca i1
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca %"compiler/interp:CondErr"
  %l58 = alloca i64
  %l63 = alloca i64
  %l67 = alloca %"compiler/check:Checker"
  %s0 = alloca %olang.scope
  %t36 = alloca %"compiler/generic:Program", align 8
  %t53 = alloca %"compiler/check:Checker", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t8 = load ptr, ptr %lp3
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %t8
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l16
  br label %bb3
bb3:
  %t10 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t10, ptr %lp4
  %t11 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t12 = load ptr, ptr %lp4
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %t12
  %t13 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hfa18c4028fc14c940207bea2352eb53b(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l17
  br label %bb4
bb4:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t14, ptr %lp5
  %t15 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t16 = load ptr, ptr %lp5
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %t16
  %t17 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l18
  br label %bb5
bb5:
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l6
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 4
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l21
  br label %bb7
bb7:
  %t25 = load i64, ptr %l21, !tbaa !24
  store i64 %t25, ptr %l7, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %v0, ptr %v1, ptr %t26)
  store %"compiler/names:Resolver" %t28, ptr %l23
  br label %bb8
bb8:
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 128, i64 8)
  store ptr %t29, ptr %lp8
  %t30 = load %"compiler/names:Resolver", ptr %l23
  %t31 = load ptr, ptr %lp8
  store %"compiler/names:Resolver" %t30, ptr %t31
  %t32 = load ptr, ptr %lp8
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v1, ptr %t32)
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %lp8
  call void @compiler_2fgeneric_3aProgram_2ector(ptr %t36, ptr %v0, ptr %v1, ptr %v1, ptr %t34, ptr %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t36, i64 640, i1 false)
  br label %bb10
bb10:
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 640, i64 8)
  store ptr %t39, ptr %lp9
  %t40 = load ptr, ptr %lp9
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %l27, i64 640, i1 false)
  %t41 = load ptr, ptr %lp4
  %t42 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t41
  %t44 = load ptr, ptr %lp9
  %t45 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 38
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %t45
  %t46 = load ptr, ptr %lp5
  %t47 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t46
  %t49 = load ptr, ptr %lp9
  %t50 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 40
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %t50
  %t51 = load ptr, ptr %lp9
  call void @compiler_2fcheck_3aChecker_2ector(ptr %t53, ptr %v1, ptr %v1, ptr %t51, i1 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t53, i64 768, i1 false)
  br label %bb11
bb11:
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 768, i64 8)
  store ptr %t56, ptr %lp10
  %t57 = load ptr, ptr %lp10
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %l32, i64 768, i1 false)
  %t58 = load ptr, ptr %lp2
  %t59 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t58
  %t61 = load ptr, ptr %lp10
  %t62 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 75
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %t62
  %t63 = load ptr, ptr %lp3
  %t64 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t63
  %t66 = load ptr, ptr %lp10
  %t67 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 94
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %t67
  %t68 = load ptr, ptr %lp10
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v1, ptr %t68)
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %lp10
  %t72 = load ptr, ptr %lp2
  %t73 = load ptr, ptr %lp3
  %t74 = load ptr, ptr %lp4
  %t75 = load ptr, ptr %lp5
  %t83 = call i1 @compiler_2finterp_2edecide(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %s0, ptr %t70, ptr %t71, ptr %t72, ptr %t73, ptr %t74, ptr %t75, ptr %l6)
  store i1 %t83, ptr %l43
  br label %bb13
bb13:
  %t84 = load i1, ptr %l43, !tbaa !21
  %t85 = xor i1 %t84, true
  br i1 %t85, label %bb14, label %bb15
bb14:
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb16
bb15:
  br label %bb30
bb16:
  %t88 = load i64, ptr %l12, !tbaa !24
  store i64 %t88, ptr %l46, !tbaa !24
  %t89 = load ptr, ptr %l11, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2eLen_3ccompiler_2finterp_3aCondErr_3e(ptr %s0, ptr %t89)
  store i64 %t91, ptr %l48
  br label %bb17
bb17:
  %t92 = load i64, ptr %l46, !tbaa !24
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l11, !tbaa !29
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = call %"compiler/interp:CondErr" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2eAt_3ccompiler_2finterp_3aCondErr_3e(ptr %s0, ptr %s0, ptr %t98, i64 %t99)
  store %"compiler/interp:CondErr" %t102, ptr %l53
  br label %bb21
bb21:
  %t103 = load %"compiler/interp:CondErr", ptr %l53
  store %"compiler/interp:CondErr" %t103, ptr %l13
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/load:Loader", ptr %t104, i32 0, i32 4
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = getelementptr %"compiler/interp:CondErr", ptr %l13, i32 0, i32 0
  %t109 = load { i64, [3 x i64] }, ptr %t108
  %t110 = getelementptr %"compiler/interp:CondErr", ptr %l13, i32 0, i32 1
  %t111 = load %"compiler/msgs:Msg", ptr %t110
  %t115 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t107, { i64, [3 x i64] } %t109, %"compiler/msgs:Msg" %t111)
  store i64 %t115, ptr %l58
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t116 = load i64, ptr %l12, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l12, !tbaa !24
  br label %bb16
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/load:Loader", ptr %t120, i32 0, i32 4
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l63
  br label %bb25
bb25:
  %t126 = load i64, ptr %l7, !tbaa !24
  %t127 = load i64, ptr %l63, !tbaa !24
  %t129 = icmp eq i64 %t127, %t126
  br i1 %t129, label %bb26, label %bb27
bb26:
  %t131 = load ptr, ptr %lp10
  call void @compiler_2finterp_2ejudgeViews(ptr %v1, ptr %t131)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t133 = load ptr, ptr %lp10
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t133, i64 768, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l67, i64 768, i1 false)
  br label %ret
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/load:Loader", ptr %t134, i32 0, i32 4
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t137, i64 %t138)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb6
ret:
  ret void
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, [5 x i64] }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l16 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca ptr
  %l24 = alloca i64
  %lp25 = alloca ptr
  %l26 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %lp30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca %"compiler/eval:Blob"
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %lp50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %lp57 = alloca ptr
  %lp58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l67 = alloca { i64, i32 }
  %l68 = alloca i64
  %l69 = alloca i32
  %l70 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"compiler/interp:Exec"
  %l86 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca i64
  %l100 = alloca ptr
  %l107 = alloca %"compiler/eval:Image"
  %l112 = alloca %"compiler/eval:Image"
  %l113 = alloca i32
  %l125 = alloca i1
  %l130 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l133 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l149 = alloca { i64, [3 x i64] }
  %l151 = alloca %"compiler/msgs:Msg"
  %l152 = alloca i64
  %l165 = alloca i1
  %l171 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l174 = alloca i1
  %l180 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca { i64, [3 x i64] }
  %l193 = alloca { i64, ptr }
  %l194 = alloca %"compiler/msgs:Msg"
  %l195 = alloca i64
  %l200 = alloca i1
  %l205 = alloca i64
  %l212 = alloca i64
  %l214 = alloca ptr
  %l215 = alloca i64
  %l221 = alloca { i64, [3 x i64] }
  %l222 = alloca %"compiler/msgs:Msg"
  %l228 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l231 = alloca i64
  %l233 = alloca i64
  %l238 = alloca i64
  %l239 = alloca %"compiler/eval:Image"
  %l242 = alloca %"compiler/eval:Image"
  %l243 = alloca i32
  %l247 = alloca ptr
  %l248 = alloca i64
  %l250 = alloca i64
  %l255 = alloca i64
  %l259 = alloca i64
  %l262 = alloca i64
  %l282 = alloca i64
  %l285 = alloca i1
  %l288 = alloca i1
  %l289 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l292 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l293 = alloca i32
  %l294 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l298 = alloca ptr
  %l299 = alloca i64
  %l309 = alloca i64
  %l311 = alloca i64
  %l316 = alloca %"compiler/eval:Blob"
  %l318 = alloca i64
  %l320 = alloca i64
  %l325 = alloca i64
  %l328 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l331 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l332 = alloca i32
  %l333 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l336 = alloca i1
  %l340 = alloca ptr
  %l341 = alloca i64
  %l352 = alloca i1
  %l353 = alloca %"compiler/eval:Image"
  %l355 = alloca i64
  %l359 = alloca i64
  %l362 = alloca i64
  %l385 = alloca %"compiler/eval:Blob"
  %l386 = alloca %"compiler/eval:Blob"
  %l391 = alloca i64
  %l395 = alloca i64
  %l398 = alloca i64
  %l416 = alloca ptr
  %l419 = alloca i64
  %l420 = alloca ptr
  %l423 = alloca i64
  %l426 = alloca i64
  %l428 = alloca i64
  %l431 = alloca i64
  %l432 = alloca ptr
  %l435 = alloca i64
  %l436 = alloca i64
  %l439 = alloca i64
  %l441 = alloca i1
  %l444 = alloca i64
  %l447 = alloca ptr
  %l450 = alloca i64
  %l453 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l456 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l457 = alloca i32
  %l458 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l462 = alloca ptr
  %l463 = alloca { i64, i32 }
  %l479 = alloca ptr
  %l482 = alloca i64
  %l483 = alloca ptr
  %l486 = alloca i64
  %l490 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %t13 = alloca %"compiler/interp:Exec", align 8
  %t182 = alloca { i64, [3 x i64] }, align 8
  %t281 = alloca { i64, [3 x i64] }, align 8
  %t355 = alloca { i64, [3 x i64] }, align 8
  %t442 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l70
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 11
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t11
  call void @compiler_2finterp_3aExec_2ector(ptr %t13, ptr %v0, ptr %v0, ptr %v0, ptr %t8, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t13, i64 976, i1 false)
  br label %bb2
bb2:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 976, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %l76, i64 976, i1 false)
  store ptr %t17, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 89
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t22
  %t26 = getelementptr %"compiler/interp:Exec", ptr %t19, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %t26
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t27)
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/load:Loader", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l86
  br label %bb4
bb4:
  %t41 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l4
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/interp:Exec", ptr %t42, i32 0, i32 9
  store ptr %t44, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t46 = load i64, ptr %l6, !tbaa !24
  store i64 %t46, ptr %l89, !tbaa !24
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l91
  br label %bb6
bb6:
  %t50 = load i64, ptr %l89, !tbaa !24
  %t51 = load i64, ptr %l91, !tbaa !24
  %t52 = icmp slt i64 %t50, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb7, label %bb8
bb7:
  br label %bb82
bb8:
  br label %bb9
bb9:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t56, i64 %t57)
  store i64 %t60, ptr %l96
  br label %bb10
bb10:
  %t61 = load i64, ptr %l96, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/interp:Exec", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t64, i64 %t65)
  store ptr %t68, ptr %l100
  br label %bb11
bb11:
  %t69 = load ptr, ptr %l100, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 1
  %t72 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t72, ptr %l8
  %t74 = load { i64, [2 x i64] }, ptr %l8
  %t76 = extractvalue { i64, [2 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 6
  br i1 %t77, label %bb12, label %bb13
bb12:
  %t79 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t80 = getelementptr { i64, i32 }, ptr %t79, i32 0, i32 0
  %t81 = load i64, ptr %t80
  store i64 %t81, ptr %l9, !tbaa !24
  %t83 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t84 = getelementptr { i64, i32 }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l10, !tbaa !23
  br label %bb14
bb13:
  br label %bb75
bb14:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/interp:Exec", ptr %t87, i32 0, i32 4
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i32, ptr %l10, !tbaa !23
  %t95 = call { i32, %"compiler/eval:Image" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eImage(ptr %v0, ptr %v1, ptr %t89, i64 %t90, i32 %t91)
  %t96 = extractvalue { i32, %"compiler/eval:Image" } %t95, 1
  %t97 = extractvalue { i32, %"compiler/eval:Image" } %t95, 0
  store i32 %t97, ptr %l113
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb16, label %ok.99
ok.99:
  store %"compiler/eval:Image" %t96, ptr %l112
  br label %bb15
bb15:
  %t100 = load %"compiler/eval:Image", ptr %l112
  store %"compiler/eval:Image" %t100, ptr %l107
  br label %bb73
bb16:
  %t101 = load i32, ptr %l113, !tbaa !23
  %t102 = ashr i32 %t101, 16
  %t104 = icmp eq i32 %t102, 1
  br i1 %t104, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_23ba8871310952f4_ff8b68d1da902468)
  unreachable
bb19:
  call void @__olang_ert_req_clear()
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr %"compiler/interp:Exec", ptr %t106, i32 0, i32 4
  %t109 = getelementptr %"compiler/eval:Machine", ptr %t108, i32 0, i32 12
  %t110 = load { i64, [5 x i64] }, ptr %t109
  store { i64, [5 x i64] } %t110, ptr %l11
  %t112 = load { i64, [5 x i64] }, ptr %l11
  %t114 = extractvalue { i64, [5 x i64] } %t112, 0
  %t115 = icmp eq i64 %t114, 3
  br i1 %t115, label %bb20, label %bb21
bb20:
  %t117 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t118 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t117, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118
  store { i64, ptr } %t119, ptr %l12, !tbaa !27
  %t121 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t122 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t121, i32 0, i32 1
  %t123 = load i64, ptr %t122
  store i64 %t123, ptr %l13, !tbaa !24
  %t125 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t126 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t125, i32 0, i32 2
  %t127 = load %"compiler/source:Span", ptr %t126
  store %"compiler/source:Span" %t127, ptr %l14
  br label %bb22
bb21:
  br label %bb37
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t130 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t131 = load ptr, ptr @__olang_prog_scope
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t131, { i64, ptr } %t129, { i64, ptr } %t130)
  store i1 %t134, ptr %l125
  br label %bb23
bb23:
  %t135 = load i1, ptr %l125, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb25:
  br label %bb26
bb26:
  %t138 = load i64, ptr %l13, !tbaa !24
  %t139 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t140 = load i32, ptr %t139, !tbaa !23
  %t142 = sext i32 %t140 to i64
  %t145 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t138, i64 %t142)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t145, ptr %l130
  br label %bb27
bb27:
  %t146 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l130
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t146, ptr %l15
  %t147 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l15
  %t150 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t147)
  store i1 %t150, ptr %l133
  br label %bb28
bb28:
  %t151 = load i1, ptr %l133, !tbaa !21
  br i1 %t151, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb30:
  br label %bb31
bb31:
  %t152 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l15
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t152, i1 true)
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t157 = getelementptr %"compiler/interp:Exec", ptr %t155, i32 0, i32 1
  %t158 = load i64, ptr %l7, !tbaa !24
  %t161 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t157, i64 %t158)
  store ptr %t161, ptr %l139
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l139, !tbaa !29
  store ptr %t162, ptr %l16, !tbaa !29
  %t163 = load ptr, ptr %l3, !tbaa !29
  store ptr %t163, ptr %l140, !tbaa !29
  %t164 = load ptr, ptr %l16, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Body", ptr %t164, i32 0, i32 3
  %t167 = load i64, ptr %t166, !tbaa !24
  %t168 = load ptr, ptr %l16, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Body", ptr %t168, i32 0, i32 4
  %t171 = getelementptr %"compiler/source:Span", ptr %t170, i32 0, i32 0
  %t172 = load i32, ptr %t171, !tbaa !23
  %t174 = sext i32 %t172 to i64
  %t175 = load ptr, ptr %l16, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Body", ptr %t175, i32 0, i32 4
  %t178 = getelementptr %"compiler/source:Span", ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178, !tbaa !23
  %t181 = sext i32 %t179 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 0
  store i64 3, ptr %t183
  %t185 = insertvalue { i64, i64, i64 } undef, i64 %t167, 0
  %t187 = insertvalue { i64, i64, i64 } %t185, i64 %t174, 1
  %t189 = insertvalue { i64, i64, i64 } %t187, i64 %t181, 2
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  store { i64, i64, i64 } %t189, ptr %t190
  %t191 = load { i64, [3 x i64] }, ptr %t182
  store { i64, [3 x i64] } %t191, ptr %l149
  %t192 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t194 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalStale(ptr %v0, ptr %s5, { i64, ptr } %t192)
  store %"compiler/msgs:Msg" %t194, ptr %l151
  br label %bb34
bb34:
  %t195 = load ptr, ptr %l140, !tbaa !29
  %t196 = load { i64, [3 x i64] }, ptr %l149
  %t197 = load %"compiler/msgs:Msg", ptr %l151
  %t198 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t195, { i64, [3 x i64] } %t196, %"compiler/msgs:Msg" %t197)
  store i64 %t198, ptr %l152
  br label %bb35
bb35:
  %t199 = load i64, ptr %l152, !tbaa !24
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t201 = load ptr, ptr %l3, !tbaa !29
  %t203 = load i64, ptr %l13, !tbaa !24
  %t204 = load %"compiler/source:Span", ptr %l14
  call void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v0, ptr %t200, ptr %t201, i64 %t199, i64 %t203, %"compiler/source:Span" %t204)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb72
bb37:
  %t210 = load { i64, [5 x i64] }, ptr %l11
  %t212 = extractvalue { i64, [5 x i64] } %t210, 0
  %t213 = icmp eq i64 %t212, 2
  br i1 %t213, label %bb38, label %bb39
bb38:
  %t215 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t216 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t215, i32 0, i32 0
  %t217 = load i32, ptr %t216
  store i32 %t217, ptr %l18
  %t219 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t220 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t219, i32 0, i32 1
  %t221 = load i64, ptr %t220
  store i64 %t221, ptr %l19, !tbaa !24
  %t223 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t224 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t223, i32 0, i32 2
  %t225 = load %"compiler/source:Span", ptr %t224
  store %"compiler/source:Span" %t225, ptr %l20
  br label %bb40
bb39:
  br label %bb67
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t227 = load i32, ptr %l18
  %t229 = trunc i64 0 to i32
  %t230 = icmp eq i32 %t227, %t229
  br i1 %t230, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l165, !tbaa !21
  br label %bb43
bb42:
  %t232 = load i32, ptr %l18
  %t234 = trunc i64 1 to i32
  %t235 = icmp eq i32 %t232, %t234
  store i1 %t235, ptr %l165, !tbaa !21
  br label %bb43
bb43:
  %t237 = load i1, ptr %l165, !tbaa !21
  br i1 %t237, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb45:
  br label %bb46
bb46:
  %t238 = load i64, ptr %l19, !tbaa !24
  %t239 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t240 = load i32, ptr %t239, !tbaa !23
  %t242 = sext i32 %t240 to i64
  %t245 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s8, i64 %t238, i64 %t242)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t245, ptr %l171
  br label %bb47
bb47:
  %t246 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l171
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t246, ptr %l21
  %t247 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t250 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t247)
  store i1 %t250, ptr %l174
  br label %bb48
bb48:
  %t251 = load i1, ptr %l174, !tbaa !21
  br i1 %t251, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb50:
  br label %bb51
bb51:
  %t252 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t252, i1 true)
  br label %bb52
bb52:
  %t255 = load ptr, ptr %l2, !tbaa !29
  %t257 = getelementptr %"compiler/interp:Exec", ptr %t255, i32 0, i32 1
  %t258 = load i64, ptr %l7, !tbaa !24
  %t261 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t257, i64 %t258)
  store ptr %t261, ptr %l180
  br label %bb53
bb53:
  %t262 = load ptr, ptr %l180, !tbaa !29
  store ptr %t262, ptr %l22, !tbaa !29
  %t263 = load ptr, ptr %l22, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 3
  %t266 = load i64, ptr %t265, !tbaa !24
  %t267 = load ptr, ptr %l22, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t267, i32 0, i32 4
  %t270 = getelementptr %"compiler/source:Span", ptr %t269, i32 0, i32 0
  %t271 = load i32, ptr %t270, !tbaa !23
  %t273 = sext i32 %t271 to i64
  %t274 = load ptr, ptr %l22, !tbaa !29
  %t276 = getelementptr %"compiler/typed:Body", ptr %t274, i32 0, i32 4
  %t277 = getelementptr %"compiler/source:Span", ptr %t276, i32 0, i32 1
  %t278 = load i32, ptr %t277, !tbaa !23
  %t280 = sext i32 %t278 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t281
  %t282 = getelementptr { i64, [3 x i64] }, ptr %t281, i32 0, i32 0
  store i64 3, ptr %t282
  %t284 = insertvalue { i64, i64, i64 } undef, i64 %t266, 0
  %t286 = insertvalue { i64, i64, i64 } %t284, i64 %t273, 1
  %t288 = insertvalue { i64, i64, i64 } %t286, i64 %t280, 2
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t281, i32 0, i32 1
  store { i64, i64, i64 } %t288, ptr %t289
  %t290 = load { i64, [3 x i64] }, ptr %t281
  %t292 = load ptr, ptr %l3, !tbaa !29
  store ptr %t292, ptr %l190, !tbaa !29
  store { i64, [3 x i64] } %t290, ptr %l191
  %t294 = load i32, ptr %l18
  %t296 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s8, i32 %t294)
  store { i64, ptr } %t296, ptr %l193
  br label %bb54
bb54:
  %t297 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t298 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalAborts(ptr %s8, ptr %s8, { i64, ptr } %t297)
  store %"compiler/msgs:Msg" %t298, ptr %l194
  br label %bb55
bb55:
  %t299 = load ptr, ptr %l190, !tbaa !29
  %t300 = load { i64, [3 x i64] }, ptr %l191
  %t301 = load %"compiler/msgs:Msg", ptr %l194
  %t302 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t299, { i64, [3 x i64] } %t300, %"compiler/msgs:Msg" %t301)
  store i64 %t302, ptr %l195
  br label %bb56
bb56:
  %t303 = load i64, ptr %l195, !tbaa !24
  store i64 %t303, ptr %l24, !tbaa !24
  %t304 = load i64, ptr %l19, !tbaa !24
  %t305 = load ptr, ptr %l22, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Body", ptr %t305, i32 0, i32 3
  %t308 = load i64, ptr %t307, !tbaa !24
  %t311 = icmp ne i64 %t304, %t308
  br i1 %t311, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb61
bb58:
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t314 = load i64, ptr %l19, !tbaa !24
  %t315 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t316 = load i32, ptr %t315, !tbaa !23
  %t318 = sext i32 %t316 to i64
  %t322 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t313, i64 %t314, i64 %t318)
  store i64 %t322, ptr %l205
  br label %bb59
bb59:
  %t323 = load ptr, ptr %l3, !tbaa !29
  %t324 = load ptr, ptr %l22, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Body", ptr %t324, i32 0, i32 3
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = load ptr, ptr %l22, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Body", ptr %t328, i32 0, i32 4
  %t331 = getelementptr %"compiler/source:Span", ptr %t330, i32 0, i32 0
  %t332 = load i32, ptr %t331, !tbaa !23
  %t334 = sext i32 %t332 to i64
  %t338 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t323, i64 %t327, i64 %t334)
  store i64 %t338, ptr %l212
  br label %bb60
bb60:
  %t339 = load i64, ptr %l205, !tbaa !24
  %t340 = load i64, ptr %l212, !tbaa !24
  %t341 = icmp ne i64 %t339, %t340
  store i1 %t341, ptr %l200, !tbaa !21
  br label %bb61
bb61:
  %t343 = load i1, ptr %l200, !tbaa !21
  br i1 %t343, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s11
  %t344 = load ptr, ptr %l3, !tbaa !29
  store ptr %t344, ptr %l214, !tbaa !29
  %t345 = load i64, ptr %l24, !tbaa !24
  store i64 %t345, ptr %l215, !tbaa !24
  %t346 = load i64, ptr %l19, !tbaa !24
  %t347 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t348 = load i32, ptr %t347, !tbaa !23
  %t350 = sext i32 %t348 to i64
  %t351 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 1
  %t352 = load i32, ptr %t351, !tbaa !23
  %t354 = sext i32 %t352 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [3 x i64] }, ptr %t355, i32 0, i32 0
  store i64 3, ptr %t356
  %t358 = insertvalue { i64, i64, i64 } undef, i64 %t346, 0
  %t360 = insertvalue { i64, i64, i64 } %t358, i64 %t350, 1
  %t362 = insertvalue { i64, i64, i64 } %t360, i64 %t354, 2
  %t363 = getelementptr { i64, [3 x i64] }, ptr %t355, i32 0, i32 1
  store { i64, i64, i64 } %t362, ptr %t363
  %t364 = load { i64, [3 x i64] }, ptr %t355
  store { i64, [3 x i64] } %t364, ptr %l221
  %t365 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s11)
  store %"compiler/msgs:Msg" %t365, ptr %l222
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t366 = load ptr, ptr %l214, !tbaa !29
  %t367 = load i64, ptr %l215, !tbaa !24
  %t368 = load { i64, [3 x i64] }, ptr %l221
  %t369 = load %"compiler/msgs:Msg", ptr %l222
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s11, ptr %t366, i64 %t367, { i64, [3 x i64] } %t368, %"compiler/msgs:Msg" %t369)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_1c176b23f7e86d25_2ef9862bd1101439)
  unreachable
bb72:
  br label %bb81
bb73:
  %t370 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t370, ptr %lp25
  %t371 = load %"compiler/eval:Image", ptr %l107
  %t372 = load ptr, ptr %lp25
  store %"compiler/eval:Image" %t371, ptr %t372
  %t373 = load ptr, ptr %lp1
  %t374 = load i64, ptr %l7, !tbaa !24
  %t375 = load ptr, ptr %lp25
  %t376 = load %"compiler/eval:Image", ptr %t375
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v1, ptr %v1, ptr %t373, i64 %t374, %"compiler/eval:Image" %t376)
  br label %bb74
bb74:
  br label %bb80
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_e5af19e5316a916e_83bce7741a9ff3c2)
  unreachable
bb80:
  br label %bb81
bb81:
  %t380 = load i64, ptr %l6, !tbaa !24
  %t382 = add i64 %t380, 1
  store i64 %t382, ptr %l6, !tbaa !24
  br label %bb5
bb82:
  %t384 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t384, ptr %l228
  br label %bb83
bb83:
  %t385 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l228
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t385, ptr %l26
  %t386 = load ptr, ptr %l2, !tbaa !29
  %t388 = getelementptr %"compiler/interp:Exec", ptr %t386, i32 0, i32 9
  store ptr %t388, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s16
  %t390 = load i64, ptr %l28, !tbaa !24
  store i64 %t390, ptr %l231, !tbaa !24
  %t391 = load ptr, ptr %l27, !tbaa !29
  %t393 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t391)
  store i64 %t393, ptr %l233
  br label %bb85
bb85:
  %t394 = load i64, ptr %l231, !tbaa !24
  %t395 = load i64, ptr %l233, !tbaa !24
  %t396 = icmp slt i64 %t394, %t395
  %t398 = xor i1 %t396, true
  br i1 %t398, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s16)
  br label %bb242
bb87:
  br label %bb88
bb88:
  %t400 = load ptr, ptr %l27, !tbaa !29
  %t401 = load i64, ptr %l28, !tbaa !24
  %t404 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t400, i64 %t401)
  store i64 %t404, ptr %l238
  br label %bb89
bb89:
  %t405 = load i64, ptr %l238, !tbaa !24
  store i64 %t405, ptr %l29, !tbaa !24
  %t406 = load ptr, ptr %lp1
  %t407 = load i64, ptr %l29, !tbaa !24
  %t410 = call { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v1, ptr %v1, ptr %t406, i64 %t407)
  %t411 = extractvalue { i32, %"compiler/eval:Image" } %t410, 1
  %t412 = extractvalue { i32, %"compiler/eval:Image" } %t410, 0
  store i32 %t412, ptr %l243
  %t413 = icmp ne i32 %t412, 0
  br i1 %t413, label %bb91, label %ok.414
ok.414:
  store %"compiler/eval:Image" %t411, ptr %l242
  br label %bb90
bb90:
  %t415 = load %"compiler/eval:Image", ptr %l242
  store %"compiler/eval:Image" %t415, ptr %l239
  br label %bb93
bb91:
  br label %bb92
bb92:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s16)
  br label %bb241
bb93:
  %t416 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t416, ptr %lp30
  %t417 = load %"compiler/eval:Image", ptr %l239
  %t418 = load ptr, ptr %lp30
  store %"compiler/eval:Image" %t417, ptr %t418
  %t419 = load ptr, ptr %l2, !tbaa !29
  %t421 = getelementptr %"compiler/interp:Exec", ptr %t419, i32 0, i32 1
  %t422 = load i64, ptr %l29, !tbaa !24
  %t425 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t421, i64 %t422)
  store ptr %t425, ptr %l247
  br label %bb94
bb94:
  %t426 = load ptr, ptr %l247, !tbaa !29
  %t427 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t426)
  store i64 %t427, ptr %l248
  br label %bb95
bb95:
  %t428 = load i64, ptr %l248, !tbaa !24
  store i64 %t428, ptr %l31, !tbaa !24
  store i1 true, ptr %l32, !tbaa !21
  %t429 = load ptr, ptr %lp30
  %t430 = getelementptr %"compiler/eval:Image", ptr %t429, i32 0, i32 0
  %t432 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t430)
  store i64 %t432, ptr %l250
  br label %bb96
bb96:
  %t433 = load i64, ptr %l250, !tbaa !24
  %t434 = icmp sge i64 %t433, 0
  br i1 %t434, label %bb97, label %bb98
bb97:
  %t436 = load i64, ptr %l250, !tbaa !24
  %t437 = icmp sle i64 %t436, 1152921504606846975
  br i1 %t437, label %bb99, label %bb100
bb98:
  call void @__olang_check_failed(ptr @olang_loc_3773d5026fcce970_1368cc7afcdc192c)
  unreachable
bb99:
  %t439 = load i64, ptr %l250, !tbaa !24
  %t440 = mul i64 %t439, 8
  %t441 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t440)
  store i64 0, ptr %t442
  br label %fill.443
fill.443:
  %t446 = load i64, ptr %t442
  %t447 = icmp slt i64 %t446, %t439
  br i1 %t447, label %fillb.444, label %filld.445
fillb.444:
  %t448 = getelementptr i64, ptr %t441, i64 %t446
  store i64 -1, ptr %t448
  %t449 = add i64 %t446, 1
  store i64 %t449, ptr %t442
  br label %fill.443
filld.445:
  %t450 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t441, 1
  store { i64, ptr } %t451, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  %t453 = load ptr, ptr %lp30
  %t454 = getelementptr %"compiler/eval:Image", ptr %t453, i32 0, i32 0
  %t456 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t454)
  store i64 %t456, ptr %l255
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_3773d5026fcce970_1368cc7afcdc192c)
  unreachable
bb101:
  %t457 = load i64, ptr %l255, !tbaa !24
  store i64 %t457, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t458 = load i64, ptr %l36, !tbaa !24
  %t459 = load i64, ptr %l35, !tbaa !24
  %t462 = icmp sgt i64 %t458, %t459
  br i1 %t462, label %bb102, label %bb103
bb102:
  %t464 = load i64, ptr %l37, !tbaa !24
  %t466 = icmp sgt i64 %t464, 0
  br i1 %t466, label %bb104, label %bb105
bb103:
  store i64 0, ptr %l259, !tbaa !24
  br label %bb107
bb104:
  %t468 = load i64, ptr %l36, !tbaa !24
  %t469 = load i64, ptr %l35, !tbaa !24
  %t472 = sub i64 %t468, %t469
  %t473 = load i64, ptr %l37, !tbaa !24
  %t476 = add i64 %t472, %t473
  %t478 = sub i64 %t476, 1
  %t479 = load i64, ptr %l37, !tbaa !24
  %t482 = sdiv i64 %t478, %t479
  store i64 %t482, ptr %l262, !tbaa !24
  br label %bb106
bb105:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb106
bb106:
  %t484 = load i64, ptr %l262, !tbaa !24
  store i64 %t484, ptr %l259, !tbaa !24
  br label %bb107
bb107:
  %t485 = load i64, ptr %l259, !tbaa !24
  store i64 %t485, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb108
bb108:
  %t486 = load i64, ptr %l39, !tbaa !24
  %t487 = load i64, ptr %l38, !tbaa !24
  %t490 = icmp slt i64 %t486, %t487
  %t492 = xor i1 %t490, true
  br i1 %t492, label %bb109, label %bb110
bb109:
  br label %bb131
bb110:
  br label %bb111
bb111:
  %t494 = load i64, ptr %l35, !tbaa !24
  %t495 = load i64, ptr %l39, !tbaa !24
  %t496 = load i64, ptr %l37, !tbaa !24
  %t499 = mul i64 %t495, %t496
  %t502 = add i64 %t494, %t499
  store i64 %t502, ptr %l40, !tbaa !24
  %t504 = load ptr, ptr %lp30
  %t505 = getelementptr %"compiler/eval:Image", ptr %t504, i32 0, i32 1
  %t506 = load i64, ptr %l40, !tbaa !24
  %t509 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t505, i64 %t506)
  store i64 %t509, ptr %l282
  br label %bb112
bb112:
  %t510 = load i64, ptr %l282, !tbaa !24
  store i64 %t510, ptr %l41, !tbaa !24
  %t511 = load i64, ptr %l40, !tbaa !24
  %t513 = icmp sgt i64 %t511, 0
  br i1 %t513, label %bb113, label %bb114
bb113:
  %t515 = load i64, ptr %l41, !tbaa !24
  %t518 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H3ccda5e77fabf86fda89ecfc77eff03d(ptr %s0, ptr %l26, i64 %t515)
  store i1 %t518, ptr %l288
  br label %bb115
bb114:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb116
bb115:
  %t519 = load i1, ptr %l288, !tbaa !21
  store i1 %t519, ptr %l285, !tbaa !21
  br label %bb116
bb116:
  %t520 = load i1, ptr %l285, !tbaa !21
  br i1 %t520, label %bb117, label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s20
  %t521 = load i64, ptr %l41, !tbaa !24
  %t524 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l26, i64 %t521)
  %t525 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t524, 1
  %t526 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t524, 0
  store i32 %t526, ptr %l293
  %t527 = icmp ne i32 %t526, 0
  br i1 %t527, label %bb120, label %ok.528
ok.528:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t525, ptr %l292
  br label %bb119
bb118:
  br label %bb129
bb119:
  %t529 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l292
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t529, ptr %l289
  br label %bb123
bb120:
  br label %bb121
bb121:
  call void @__olang_ert_req_clear()
  %t530 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s20, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t530, ptr %l294
  br label %bb122
bb122:
  %t531 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l294
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t531, ptr %l289
  br label %bb123
bb123:
  %t532 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l289
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t532, ptr %l42
  %t533 = load ptr, ptr %l2, !tbaa !29
  %t535 = getelementptr %"compiler/interp:Exec", ptr %t533, i32 0, i32 1
  %t536 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l42, i32 0, i32 0
  %t537 = load i64, ptr %t536, !tbaa !24
  %t540 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t535, i64 %t537)
  store ptr %t540, ptr %l298
  br label %bb124
bb124:
  %t541 = load ptr, ptr %l298, !tbaa !29
  %t542 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t541)
  store i64 %t542, ptr %l299
  br label %bb125
bb125:
  %t543 = load i64, ptr %l31, !tbaa !24
  %t544 = load i64, ptr %l299, !tbaa !24
  %t546 = icmp ne i64 %t544, %t543
  br i1 %t546, label %bb126, label %bb127
bb126:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb128
bb127:
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s20)
  br label %bb130
bb129:
  %t548 = load i64, ptr %l40, !tbaa !24
  %t549 = load i64, ptr %l34, !tbaa !24
  %t552 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !27
  %t554 = getelementptr i64, ptr %t553, i64 %t548
  store i64 %t549, ptr %t554, !tbaa !34
  %t555 = load i64, ptr %l34, !tbaa !24
  %t557 = add i64 %t555, 1
  store i64 %t557, ptr %l34, !tbaa !24
  br label %bb130
bb130:
  %t559 = load i64, ptr %l39, !tbaa !24
  %t561 = add i64 %t559, 1
  store i64 %t561, ptr %l39, !tbaa !24
  br label %bb108
bb131:
  %t563 = load ptr, ptr %lp30
  %t564 = getelementptr %"compiler/eval:Image", ptr %t563, i32 0, i32 0
  store ptr %t564, ptr %l43, !tbaa !29
  store i64 0, ptr %l44, !tbaa !24
  br label %bb132
bb132:
  %t566 = load i64, ptr %l44, !tbaa !24
  store i64 %t566, ptr %l309, !tbaa !24
  %t567 = load ptr, ptr %l43, !tbaa !29
  %t569 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t567)
  store i64 %t569, ptr %l311
  br label %bb133
bb133:
  %t570 = load i64, ptr %l309, !tbaa !24
  %t571 = load i64, ptr %l311, !tbaa !24
  %t572 = icmp slt i64 %t570, %t571
  %t574 = xor i1 %t572, true
  br i1 %t574, label %bb134, label %bb135
bb134:
  br label %bb163
bb135:
  br label %bb136
bb136:
  %t576 = load ptr, ptr %l43, !tbaa !29
  %t577 = load i64, ptr %l44, !tbaa !24
  %t580 = call %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t576, i64 %t577)
  store %"compiler/eval:Blob" %t580, ptr %l316
  br label %bb137
bb137:
  %t581 = load %"compiler/eval:Blob", ptr %l316
  store %"compiler/eval:Blob" %t581, ptr %l45
  %t582 = getelementptr %"compiler/eval:Blob", ptr %l45, i32 0, i32 6
  store ptr %t582, ptr %l46, !tbaa !29
  store i64 0, ptr %l47, !tbaa !24
  br label %bb138
bb138:
  store %olang.scope zeroinitializer, ptr %s26
  %t584 = load i64, ptr %l47, !tbaa !24
  store i64 %t584, ptr %l318, !tbaa !24
  %t585 = load ptr, ptr %l46, !tbaa !29
  %t587 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t585)
  store i64 %t587, ptr %l320
  br label %bb139
bb139:
  %t588 = load i64, ptr %l318, !tbaa !24
  %t589 = load i64, ptr %l320, !tbaa !24
  %t590 = icmp slt i64 %t588, %t589
  %t592 = xor i1 %t590, true
  br i1 %t592, label %bb140, label %bb141
bb140:
  call void @__olang_scope_close(ptr %s26)
  br label %bb161
bb141:
  br label %bb142
bb142:
  %t594 = load ptr, ptr %l46, !tbaa !29
  %t595 = load i64, ptr %l47, !tbaa !24
  %t598 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t594, i64 %t595)
  store i64 %t598, ptr %l325
  br label %bb143
bb143:
  %t599 = load i64, ptr %l325, !tbaa !24
  store i64 %t599, ptr %l48, !tbaa !24
  %t600 = load i64, ptr %l48, !tbaa !24
  %t602 = icmp slt i64 %t600, 0
  br i1 %t602, label %bb144, label %bb145
bb144:
  call void @__olang_scope_close(ptr %s26)
  br label %bb160
bb145:
  br label %bb146
bb146:
  %t604 = load i64, ptr %l48, !tbaa !24
  %t607 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l26, i64 %t604)
  %t608 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t607, 1
  %t609 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t607, 0
  store i32 %t609, ptr %l332
  %t610 = icmp ne i32 %t609, 0
  br i1 %t610, label %bb148, label %ok.611
ok.611:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t608, ptr %l331
  br label %bb147
bb147:
  %t612 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l331
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t612, ptr %l328
  br label %bb151
bb148:
  br label %bb149
bb149:
  call void @__olang_ert_req_clear()
  %t613 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s26, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t613, ptr %l333
  br label %bb150
bb150:
  %t614 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l333
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t614, ptr %l328
  br label %bb151
bb151:
  %t615 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l328
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t615, ptr %l49
  %t616 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l49, i32 0, i32 0
  %t617 = load i64, ptr %t616, !tbaa !24
  %t619 = icmp slt i64 %t617, 0
  br i1 %t619, label %bb152, label %bb153
bb152:
  store i1 true, ptr %l336, !tbaa !21
  br label %bb156
bb153:
  %t621 = load ptr, ptr %l2, !tbaa !29
  %t623 = getelementptr %"compiler/interp:Exec", ptr %t621, i32 0, i32 1
  %t624 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l49, i32 0, i32 0
  %t625 = load i64, ptr %t624, !tbaa !24
  %t628 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t623, i64 %t625)
  store ptr %t628, ptr %l340
  br label %bb154
bb154:
  %t629 = load ptr, ptr %l340, !tbaa !29
  %t630 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t629)
  store i64 %t630, ptr %l341
  br label %bb155
bb155:
  %t631 = load i64, ptr %l31, !tbaa !24
  %t632 = load i64, ptr %l341, !tbaa !24
  %t634 = icmp ne i64 %t632, %t631
  store i1 %t634, ptr %l336, !tbaa !21
  br label %bb156
bb156:
  %t636 = load i1, ptr %l336, !tbaa !21
  br i1 %t636, label %bb157, label %bb158
bb157:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb159
bb158:
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s26)
  br label %bb160
bb160:
  %t637 = load i64, ptr %l47, !tbaa !24
  %t639 = add i64 %t637, 1
  store i64 %t639, ptr %l47, !tbaa !24
  br label %bb138
bb161:
  br label %bb162
bb162:
  %t641 = load i64, ptr %l44, !tbaa !24
  %t643 = add i64 %t641, 1
  store i64 %t643, ptr %l44, !tbaa !24
  br label %bb132
bb163:
  %t645 = load i1, ptr %l32, !tbaa !21
  %t647 = xor i1 %t645, true
  br i1 %t647, label %bb164, label %bb165
bb164:
  %t649 = load ptr, ptr %lp1
  %t650 = load i64, ptr %l29, !tbaa !24
  %t653 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H8e3ab02101333f4dae95aad48f2e722e(ptr %v1, ptr %t649, i64 %t650)
  store i1 %t653, ptr %l352
  br label %bb166
bb165:
  br label %bb167
bb166:
  call void @__olang_scope_close(ptr %s16)
  br label %bb241
bb167:
  %t654 = call %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v1)
  store %"compiler/eval:Image" %t654, ptr %l353
  br label %bb168
bb168:
  %t655 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t655, ptr %lp50
  %t656 = load %"compiler/eval:Image", ptr %l353
  %t657 = load ptr, ptr %lp50
  store %"compiler/eval:Image" %t656, ptr %t657
  store i64 0, ptr %l51, !tbaa !24
  %t658 = load ptr, ptr %lp30
  %t659 = getelementptr %"compiler/eval:Image", ptr %t658, i32 0, i32 0
  %t661 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t659)
  store i64 %t661, ptr %l355
  br label %bb169
bb169:
  %t662 = load i64, ptr %l355, !tbaa !24
  store i64 %t662, ptr %l52, !tbaa !24
  store i64 1, ptr %l53, !tbaa !24
  %t663 = load i64, ptr %l52, !tbaa !24
  %t664 = load i64, ptr %l51, !tbaa !24
  %t667 = icmp sgt i64 %t663, %t664
  br i1 %t667, label %bb170, label %bb171
bb170:
  %t669 = load i64, ptr %l53, !tbaa !24
  %t671 = icmp sgt i64 %t669, 0
  br i1 %t671, label %bb172, label %bb173
bb171:
  store i64 0, ptr %l359, !tbaa !24
  br label %bb175
bb172:
  %t673 = load i64, ptr %l52, !tbaa !24
  %t674 = load i64, ptr %l51, !tbaa !24
  %t677 = sub i64 %t673, %t674
  %t678 = load i64, ptr %l53, !tbaa !24
  %t681 = add i64 %t677, %t678
  %t683 = sub i64 %t681, 1
  %t684 = load i64, ptr %l53, !tbaa !24
  %t687 = sdiv i64 %t683, %t684
  store i64 %t687, ptr %l362, !tbaa !24
  br label %bb174
bb173:
  store i64 0, ptr %l362, !tbaa !24
  br label %bb174
bb174:
  %t689 = load i64, ptr %l362, !tbaa !24
  store i64 %t689, ptr %l359, !tbaa !24
  br label %bb175
bb175:
  %t690 = load i64, ptr %l359, !tbaa !24
  store i64 %t690, ptr %l54, !tbaa !24
  store i64 0, ptr %l55, !tbaa !24
  br label %bb176
bb176:
  store %olang.scope zeroinitializer, ptr %s33
  %t691 = load i64, ptr %l55, !tbaa !24
  %t692 = load i64, ptr %l54, !tbaa !24
  %t695 = icmp slt i64 %t691, %t692
  %t697 = xor i1 %t695, true
  br i1 %t697, label %bb177, label %bb178
bb177:
  call void @__olang_scope_close(ptr %s33)
  br label %bb239
bb178:
  br label %bb179
bb179:
  %t699 = load i64, ptr %l51, !tbaa !24
  %t700 = load i64, ptr %l55, !tbaa !24
  %t701 = load i64, ptr %l53, !tbaa !24
  %t704 = mul i64 %t700, %t701
  %t707 = add i64 %t699, %t704
  store i64 %t707, ptr %l56, !tbaa !24
  %t709 = load i64, ptr %l56, !tbaa !24
  %t711 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t712 = load ptr, ptr %t711, !tbaa !27
  %t713 = getelementptr i64, ptr %t712, i64 %t709
  %t714 = load i64, ptr %t713, !tbaa !34
  %t716 = icmp slt i64 %t714, 0
  br i1 %t716, label %bb180, label %bb181
bb180:
  call void @__olang_scope_close(ptr %s33)
  br label %bb238
bb181:
  br label %bb182
bb182:
  %t718 = load ptr, ptr %lp30
  %t719 = getelementptr %"compiler/eval:Image", ptr %t718, i32 0, i32 0
  %t720 = load i64, ptr %l56, !tbaa !24
  %t723 = call %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t719, i64 %t720)
  store %"compiler/eval:Blob" %t723, ptr %l385
  br label %bb183
bb183:
  %t724 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store ptr %t724, ptr %lp57
  %t725 = load %"compiler/eval:Blob", ptr %l385
  %t726 = load ptr, ptr %lp57
  store %"compiler/eval:Blob" %t725, ptr %t726
  %t727 = call %"compiler/eval:Blob" @compiler_2feval_3aBlob_2ector(ptr %v1)
  store %"compiler/eval:Blob" %t727, ptr %l386
  br label %bb184
bb184:
  %t728 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store ptr %t728, ptr %lp58
  %t729 = load %"compiler/eval:Blob", ptr %l386
  %t730 = load ptr, ptr %lp58
  store %"compiler/eval:Blob" %t729, ptr %t730
  %t731 = load ptr, ptr %lp57
  %t732 = getelementptr %"compiler/eval:Blob", ptr %t731, i32 0, i32 0
  %t733 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t732
  %t735 = load ptr, ptr %lp58
  %t736 = getelementptr %"compiler/eval:Blob", ptr %t735, i32 0, i32 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t733, ptr %t736
  %t737 = load ptr, ptr %lp57
  %t738 = getelementptr %"compiler/eval:Blob", ptr %t737, i32 0, i32 1
  %t739 = load i64, ptr %t738, !tbaa !24
  %t741 = load ptr, ptr %lp58
  %t742 = getelementptr %"compiler/eval:Blob", ptr %t741, i32 0, i32 1
  store i64 %t739, ptr %t742, !tbaa !24
  %t743 = load ptr, ptr %lp57
  %t744 = getelementptr %"compiler/eval:Blob", ptr %t743, i32 0, i32 2
  %t745 = load i1, ptr %t744, !tbaa !21
  %t747 = load ptr, ptr %lp58
  %t748 = getelementptr %"compiler/eval:Blob", ptr %t747, i32 0, i32 2
  store i1 %t745, ptr %t748, !tbaa !21
  store i64 0, ptr %l59, !tbaa !24
  %t749 = load ptr, ptr %lp57
  %t750 = getelementptr %"compiler/eval:Blob", ptr %t749, i32 0, i32 3
  %t752 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t750)
  store i64 %t752, ptr %l391
  br label %bb185
bb185:
  %t753 = load i64, ptr %l391, !tbaa !24
  store i64 %t753, ptr %l60, !tbaa !24
  store i64 1, ptr %l61, !tbaa !24
  %t754 = load i64, ptr %l60, !tbaa !24
  %t755 = load i64, ptr %l59, !tbaa !24
  %t758 = icmp sgt i64 %t754, %t755
  br i1 %t758, label %bb186, label %bb187
bb186:
  %t760 = load i64, ptr %l61, !tbaa !24
  %t762 = icmp sgt i64 %t760, 0
  br i1 %t762, label %bb188, label %bb189
bb187:
  store i64 0, ptr %l395, !tbaa !24
  br label %bb191
bb188:
  %t764 = load i64, ptr %l60, !tbaa !24
  %t765 = load i64, ptr %l59, !tbaa !24
  %t768 = sub i64 %t764, %t765
  %t769 = load i64, ptr %l61, !tbaa !24
  %t772 = add i64 %t768, %t769
  %t774 = sub i64 %t772, 1
  %t775 = load i64, ptr %l61, !tbaa !24
  %t778 = sdiv i64 %t774, %t775
  store i64 %t778, ptr %l398, !tbaa !24
  br label %bb190
bb189:
  store i64 0, ptr %l398, !tbaa !24
  br label %bb190
bb190:
  %t780 = load i64, ptr %l398, !tbaa !24
  store i64 %t780, ptr %l395, !tbaa !24
  br label %bb191
bb191:
  %t781 = load i64, ptr %l395, !tbaa !24
  store i64 %t781, ptr %l62, !tbaa !24
  store i64 0, ptr %l63, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s36
  %t782 = load i64, ptr %l63, !tbaa !24
  %t783 = load i64, ptr %l62, !tbaa !24
  %t786 = icmp slt i64 %t782, %t783
  %t788 = xor i1 %t786, true
  br i1 %t788, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s36)
  br label %bb231
bb194:
  br label %bb195
bb195:
  %t790 = load i64, ptr %l59, !tbaa !24
  %t791 = load i64, ptr %l63, !tbaa !24
  %t792 = load i64, ptr %l61, !tbaa !24
  %t795 = mul i64 %t791, %t792
  %t798 = add i64 %t790, %t795
  store i64 %t798, ptr %l64, !tbaa !24
  %t800 = load ptr, ptr %lp58
  %t801 = getelementptr %"compiler/eval:Blob", ptr %t800, i32 0, i32 3
  store ptr %t801, ptr %l416, !tbaa !29
  %t802 = load ptr, ptr %lp57
  %t803 = getelementptr %"compiler/eval:Blob", ptr %t802, i32 0, i32 3
  %t804 = load i64, ptr %l64, !tbaa !24
  %t807 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t803, i64 %t804)
  store i64 %t807, ptr %l419
  br label %bb196
bb196:
  %t808 = load ptr, ptr %l416, !tbaa !29
  %t809 = load i64, ptr %l419, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t808, i64 %t809)
  br label %bb197
bb197:
  %t810 = load ptr, ptr %lp58
  %t811 = getelementptr %"compiler/eval:Blob", ptr %t810, i32 0, i32 5
  store ptr %t811, ptr %l420, !tbaa !29
  %t812 = load ptr, ptr %lp57
  %t813 = getelementptr %"compiler/eval:Blob", ptr %t812, i32 0, i32 5
  %t814 = load i64, ptr %l64, !tbaa !24
  %t817 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t813, i64 %t814)
  store i64 %t817, ptr %l423
  br label %bb198
bb198:
  %t818 = load ptr, ptr %l420, !tbaa !29
  %t819 = load i64, ptr %l423, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t818, i64 %t819)
  br label %bb199
bb199:
  %t820 = load ptr, ptr %lp57
  %t821 = getelementptr %"compiler/eval:Blob", ptr %t820, i32 0, i32 4
  %t822 = load i64, ptr %l64, !tbaa !24
  %t825 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t821, i64 %t822)
  store i64 %t825, ptr %l426
  br label %bb200
bb200:
  %t826 = load i64, ptr %l426, !tbaa !24
  %t827 = icmp slt i64 %t826, 0
  br i1 %t827, label %bb201, label %bb202
bb201:
  %t829 = load ptr, ptr %lp57
  %t830 = getelementptr %"compiler/eval:Blob", ptr %t829, i32 0, i32 6
  %t831 = load i64, ptr %l64, !tbaa !24
  %t834 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t830, i64 %t831)
  store i64 %t834, ptr %l431
  br label %bb203
bb202:
  %t835 = load ptr, ptr %lp30
  %t836 = getelementptr %"compiler/eval:Image", ptr %t835, i32 0, i32 1
  store ptr %t836, ptr %l432, !tbaa !29
  %t837 = load ptr, ptr %lp57
  %t838 = getelementptr %"compiler/eval:Blob", ptr %t837, i32 0, i32 4
  %t839 = load i64, ptr %l64, !tbaa !24
  %t842 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t838, i64 %t839)
  store i64 %t842, ptr %l435
  br label %bb204
bb203:
  %t843 = load i64, ptr %l431, !tbaa !24
  store i64 %t843, ptr %l428, !tbaa !24
  br label %bb206
bb204:
  %t844 = load ptr, ptr %l432, !tbaa !29
  %t845 = load i64, ptr %l435, !tbaa !24
  %t846 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t844, i64 %t845)
  store i64 %t846, ptr %l436
  br label %bb205
bb205:
  %t847 = load i64, ptr %l436, !tbaa !24
  store i64 %t847, ptr %l428, !tbaa !24
  br label %bb206
bb206:
  %t848 = load i64, ptr %l428, !tbaa !24
  store i64 %t848, ptr %l65, !tbaa !24
  %t849 = load ptr, ptr %lp57
  %t850 = getelementptr %"compiler/eval:Blob", ptr %t849, i32 0, i32 4
  %t851 = load i64, ptr %l64, !tbaa !24
  %t854 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t850, i64 %t851)
  store i64 %t854, ptr %l439
  br label %bb207
bb207:
  %t855 = load i64, ptr %l439, !tbaa !24
  %t856 = icmp sge i64 %t855, 0
  br i1 %t856, label %bb208, label %bb209
bb208:
  %t858 = load ptr, ptr %lp57
  %t859 = getelementptr %"compiler/eval:Blob", ptr %t858, i32 0, i32 4
  %t860 = load i64, ptr %l64, !tbaa !24
  %t863 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t859, i64 %t860)
  store i64 %t863, ptr %l444
  br label %bb210
bb209:
  store i1 false, ptr %l441, !tbaa !21
  br label %bb211
bb210:
  %t864 = load i64, ptr %l444, !tbaa !24
  %t865 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t866 = load ptr, ptr %t865, !tbaa !27
  %t867 = getelementptr i64, ptr %t866, i64 %t864
  %t868 = load i64, ptr %t867, !tbaa !34
  %t870 = icmp sge i64 %t868, 0
  store i1 %t870, ptr %l441, !tbaa !21
  br label %bb211
bb211:
  %t872 = load i1, ptr %l441, !tbaa !21
  br i1 %t872, label %bb212, label %bb213
bb212:
  %t873 = load ptr, ptr %lp58
  %t874 = getelementptr %"compiler/eval:Blob", ptr %t873, i32 0, i32 4
  store ptr %t874, ptr %l447, !tbaa !29
  %t875 = load ptr, ptr %lp57
  %t876 = getelementptr %"compiler/eval:Blob", ptr %t875, i32 0, i32 4
  %t877 = load i64, ptr %l64, !tbaa !24
  %t880 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t876, i64 %t877)
  store i64 %t880, ptr %l450
  br label %bb214
bb213:
  br label %bb217
bb214:
  %t881 = load i64, ptr %l450, !tbaa !24
  %t882 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t883 = load ptr, ptr %t882, !tbaa !27
  %t884 = getelementptr i64, ptr %t883, i64 %t881
  %t885 = load i64, ptr %t884, !tbaa !34
  %t886 = load ptr, ptr %l447, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t886, i64 %t885)
  br label %bb215
bb215:
  %t888 = load ptr, ptr %lp58
  %t889 = getelementptr %"compiler/eval:Blob", ptr %t888, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t889, i64 -1)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s36)
  br label %bb230
bb217:
  %t891 = load i64, ptr %l65, !tbaa !24
  %t894 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l26, i64 %t891)
  %t895 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t894, 1
  %t896 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t894, 0
  store i32 %t896, ptr %l457
  %t897 = icmp ne i32 %t896, 0
  br i1 %t897, label %bb219, label %ok.898
ok.898:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t895, ptr %l456
  br label %bb218
bb218:
  %t899 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l456
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t899, ptr %l453
  br label %bb222
bb219:
  br label %bb220
bb220:
  call void @__olang_ert_req_clear()
  %t900 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s36, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t900, ptr %l458
  br label %bb221
bb221:
  %t901 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l458
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t901, ptr %l453
  br label %bb222
bb222:
  %t902 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l453
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t902, ptr %l66
  %t903 = load ptr, ptr %l2, !tbaa !29
  %t905 = getelementptr %"compiler/interp:Exec", ptr %t903, i32 0, i32 1
  %t906 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l66, i32 0, i32 0
  %t907 = load i64, ptr %t906, !tbaa !24
  %t910 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t905, i64 %t907)
  store ptr %t910, ptr %l462
  br label %bb223
bb223:
  %t911 = load ptr, ptr %l462, !tbaa !29
  %t912 = call { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %t911)
  store { i64, i32 } %t912, ptr %l463
  br label %bb224
bb224:
  %t913 = load { i64, i32 }, ptr %l463
  store { i64, i32 } %t913, ptr %l67
  %t914 = getelementptr { i64, i32 }, ptr %l67, i32 0, i32 0
  %t915 = load i64, ptr %t914, !tbaa !24
  store i64 %t915, ptr %l68, !tbaa !24
  %t917 = getelementptr { i64, i32 }, ptr %l67, i32 0, i32 1
  %t918 = load i32, ptr %t917, !tbaa !23
  store i32 %t918, ptr %l69, !tbaa !23
  %t920 = load ptr, ptr %lp58
  %t921 = getelementptr %"compiler/eval:Blob", ptr %t920, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t921, i64 -1)
  br label %bb225
bb225:
  %t923 = load ptr, ptr %lp58
  %t924 = getelementptr %"compiler/eval:Blob", ptr %t923, i32 0, i32 6
  %t925 = load i64, ptr %l65, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t924, i64 %t925)
  br label %bb226
bb226:
  %t928 = load ptr, ptr %lp58
  %t929 = getelementptr %"compiler/eval:Blob", ptr %t928, i32 0, i32 7
  %t930 = load i64, ptr %l68, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t929, i64 %t930)
  br label %bb227
bb227:
  %t933 = load ptr, ptr %lp58
  %t934 = getelementptr %"compiler/eval:Blob", ptr %t933, i32 0, i32 8
  %t935 = load i32, ptr %l69, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t934, i32 %t935)
  br label %bb228
bb228:
  %t938 = load ptr, ptr %lp58
  %t939 = getelementptr %"compiler/eval:Blob", ptr %t938, i32 0, i32 9
  %t940 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l66, i32 0, i32 1
  %t941 = load i64, ptr %t940, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t939, i64 %t941)
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s36)
  br label %bb230
bb230:
  %t944 = load i64, ptr %l63, !tbaa !24
  %t946 = add i64 %t944, 1
  store i64 %t946, ptr %l63, !tbaa !24
  br label %bb192
bb231:
  %t948 = load ptr, ptr %lp50
  %t949 = getelementptr %"compiler/eval:Image", ptr %t948, i32 0, i32 0
  %t950 = load ptr, ptr %lp58
  %t951 = load %"compiler/eval:Blob", ptr %t950
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t949, %"compiler/eval:Blob" %t951)
  br label %bb232
bb232:
  %t954 = load ptr, ptr %lp50
  %t955 = getelementptr %"compiler/eval:Image", ptr %t954, i32 0, i32 1
  store ptr %t955, ptr %l479, !tbaa !29
  %t956 = load ptr, ptr %lp30
  %t957 = getelementptr %"compiler/eval:Image", ptr %t956, i32 0, i32 1
  %t958 = load i64, ptr %l56, !tbaa !24
  %t961 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t957, i64 %t958)
  store i64 %t961, ptr %l482
  br label %bb233
bb233:
  %t962 = load ptr, ptr %l479, !tbaa !29
  %t963 = load i64, ptr %l482, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t962, i64 %t963)
  br label %bb234
bb234:
  store ptr %l26, ptr %l483, !tbaa !29
  %t964 = load ptr, ptr %lp30
  %t965 = getelementptr %"compiler/eval:Image", ptr %t964, i32 0, i32 1
  %t966 = load i64, ptr %l56, !tbaa !24
  %t969 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t965, i64 %t966)
  store i64 %t969, ptr %l486
  br label %bb235
bb235:
  %t970 = load i64, ptr %l29, !tbaa !24
  %t971 = load i64, ptr %l56, !tbaa !24
  %t973 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t974 = load ptr, ptr %t973, !tbaa !27
  %t975 = getelementptr i64, ptr %t974, i64 %t971
  %t976 = load i64, ptr %t975, !tbaa !34
  %t979 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s33, i64 %t970, i64 %t976)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t979, ptr %l490
  br label %bb236
bb236:
  %t980 = load ptr, ptr %l483, !tbaa !29
  %t981 = load i64, ptr %l486, !tbaa !24
  %t982 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l490
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_Hd47ddefe3838698aaa5711f2f63b01ed(ptr %s0, ptr %t980, i64 %t981, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t982)
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s33)
  br label %bb238
bb238:
  %t983 = load i64, ptr %l55, !tbaa !24
  %t985 = add i64 %t983, 1
  store i64 %t985, ptr %l55, !tbaa !24
  br label %bb176
bb239:
  %t987 = load ptr, ptr %lp1
  %t988 = load i64, ptr %l29, !tbaa !24
  %t989 = load ptr, ptr %lp50
  %t990 = load %"compiler/eval:Image", ptr %t989
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v1, ptr %v1, ptr %t987, i64 %t988, %"compiler/eval:Image" %t990)
  br label %bb240
bb240:
  call void @__olang_scope_close(ptr %s16)
  br label %bb241
bb241:
  %t994 = load i64, ptr %l28, !tbaa !24
  %t996 = add i64 %t994, 1
  store i64 %t996, ptr %l28, !tbaa !24
  br label %bb84
bb242:
  %t998 = load ptr, ptr %lp1
  %t999 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t998
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t999, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:AssertAsk"
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [5 x i64] }
  %l11 = alloca { i64, [3 x i64] }
  %l12 = alloca { { i64, ptr }, i1 }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l28 = alloca i1
  %l31 = alloca i64
  %l43 = alloca %"compiler/interp:Exec"
  %l50 = alloca i64
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca %"compiler/check:AssertAsk"
  %l64 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l67 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca { i64, [2 x i64] }
  %l80 = alloca { i64, [5 x i64] }
  %l96 = alloca i64
  %l102 = alloca { { i64, ptr }, i1 }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca { i64, [3 x i64] }
  %l110 = alloca %"compiler/msgs:Msg"
  %l112 = alloca %"compiler/msgs:Msg"
  %l113 = alloca %"compiler/msgs:Msg"
  %l114 = alloca i64
  %l116 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i64
  %l120 = alloca { i64, [3 x i64] }
  %l121 = alloca %"compiler/msgs:Msg"
  %l124 = alloca %"compiler/msgs:Msg"
  %l132 = alloca ptr
  %l133 = alloca { i64, [3 x i64] }
  %l135 = alloca { i64, ptr }
  %l136 = alloca %"compiler/msgs:Msg"
  %l137 = alloca i64
  %l138 = alloca ptr
  %l139 = alloca i64
  %l145 = alloca { i64, [3 x i64] }
  %l146 = alloca %"compiler/msgs:Msg"
  %l154 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca { i64, [3 x i64] }
  %l160 = alloca %"compiler/msgs:Msg"
  %l161 = alloca i64
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i64
  %t38 = alloca %"compiler/interp:Exec", align 8
  %t100 = alloca { i64, [2 x i64] }, align 8
  %t140 = alloca { i64, [3 x i64] }, align 8
  %t288 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 78
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i64, ptr %l26, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 82
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l31
  br label %bb4
bb3:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb5
bb4:
  %t14 = load i64, ptr %l31, !tbaa !24
  %t15 = icmp eq i64 %t14, 0
  store i1 %t15, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l28, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i64 0, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l2, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 11
  %t37 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t36
  call void @compiler_2finterp_3aExec_2ector(ptr %t38, ptr %v0, ptr %v0, ptr %v0, ptr %t33, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t38, i64 976, i1 false)
  br label %bb9
bb9:
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 976, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %l43, i64 976, i1 false)
  store ptr %t42, ptr %l3, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 89
  %t48 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t47
  %t51 = getelementptr %"compiler/interp:Exec", ptr %t44, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %t51
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t56 = call i64 @compiler_2finterp_2edecideContracts(ptr %v0, ptr %v0, ptr %t52, ptr %t53)
  store i64 %t56, ptr %l50
  br label %bb10
bb10:
  %t57 = load i64, ptr %l50, !tbaa !24
  store i64 %t57, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 78
  store ptr %t60, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l53, !tbaa !24
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l55
  br label %bb12
bb12:
  %t66 = load i64, ptr %l53, !tbaa !24
  %t67 = load i64, ptr %l55, !tbaa !24
  %t68 = icmp slt i64 %t66, %t67
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb77
bb14:
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = call %"compiler/check:AssertAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eAt_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %v0, ptr %v0, ptr %t72, i64 %t73)
  store %"compiler/check:AssertAsk" %t76, ptr %l60
  br label %bb16
bb16:
  %t77 = load %"compiler/check:AssertAsk", ptr %l60
  store %"compiler/check:AssertAsk" %t77, ptr %l7
  %t78 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 2
  %t81 = getelementptr %"compiler/source:Span", ptr %t80, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = sext i32 %t82 to i64
  %t87 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t79, i64 %t84)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t87, ptr %l64
  br label %bb17
bb17:
  %t88 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l64
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t88, ptr %l8
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t90 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t93 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v1, ptr %t89, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t90)
  store i1 %t93, ptr %l67
  br label %bb18
bb18:
  %t94 = load i1, ptr %l67, !tbaa !21
  br i1 %t94, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb76
bb20:
  br label %bb21
bb21:
  %t95 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 4
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = trunc i64 %t96 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [2 x i64] }, ptr %t100, i32 0, i32 0
  store i64 0, ptr %t101
  %t103 = insertvalue { i32 } undef, i32 %t98, 0
  %t104 = getelementptr { i64, [2 x i64] }, ptr %t100, i32 0, i32 1
  store { i32 } %t103, ptr %t104
  %t105 = load { i64, [2 x i64] }, ptr %t100
  store { i64, [2 x i64] } %t105, ptr %l9
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t108 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t107, { i64, [2 x i64] } %t108)
  br label %bb22
bb22:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/interp:Exec", ptr %t111, i32 0, i32 4
  store ptr %t113, ptr %l75, !tbaa !29
  %t114 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t114, ptr %l76
  %t115 = icmp sge i64 0, 0
  br i1 %t115, label %bb23, label %bb24
bb23:
  %t117 = icmp sle i64 0, 1152921504606846975
  br i1 %t117, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7edf3cf7ccf8e57f_276bde685bbe381b)
  unreachable
bb25:
  %t119 = mul i64 0, 8
  %t120 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 0, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t123 = load ptr, ptr %l75, !tbaa !29
  %t124 = load { i64, [2 x i64] }, ptr %l76
  %t126 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t123, { i64, [2 x i64] } %t124, { i64, ptr } %t122)
  store { i64, [5 x i64] } %t126, ptr %l80
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7edf3cf7ccf8e57f_276bde685bbe381b)
  unreachable
bb27:
  %t127 = load { i64, [5 x i64] }, ptr %l80
  store { i64, [5 x i64] } %t127, ptr %l10
  %t128 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 1
  %t129 = load i64, ptr %t128, !tbaa !24
  %t130 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 3
  %t131 = getelementptr %"compiler/source:Span", ptr %t130, i32 0, i32 0
  %t132 = load i32, ptr %t131, !tbaa !23
  %t134 = sext i32 %t132 to i64
  %t135 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 3
  %t136 = getelementptr %"compiler/source:Span", ptr %t135, i32 0, i32 1
  %t137 = load i32, ptr %t136, !tbaa !23
  %t139 = sext i32 %t137 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [3 x i64] }, ptr %t140, i32 0, i32 0
  store i64 3, ptr %t141
  %t143 = insertvalue { i64, i64, i64 } undef, i64 %t129, 0
  %t145 = insertvalue { i64, i64, i64 } %t143, i64 %t134, 1
  %t147 = insertvalue { i64, i64, i64 } %t145, i64 %t139, 2
  %t148 = getelementptr { i64, [3 x i64] }, ptr %t140, i32 0, i32 1
  store { i64, i64, i64 } %t147, ptr %t148
  %t149 = load { i64, [3 x i64] }, ptr %t140
  store { i64, [3 x i64] } %t149, ptr %l11
  %t151 = load { i64, [5 x i64] }, ptr %l10
  %t153 = extractvalue { i64, [5 x i64] } %t151, 0
  %t154 = icmp eq i64 %t153, 0
  br i1 %t154, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb50
bb30:
  %t156 = load i64, ptr %l4, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l4, !tbaa !24
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr %"compiler/interp:Exec", ptr %t160, i32 0, i32 4
  %t163 = load ptr, ptr %l3, !tbaa !29
  %t165 = getelementptr %"compiler/interp:Exec", ptr %t163, i32 0, i32 4
  %t166 = getelementptr %"compiler/eval:Machine", ptr %t165, i32 0, i32 10
  %t167 = load %"compiler/eval:Ptr", ptr %t166
  %t168 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t172 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t162, %"compiler/eval:Ptr" %t167, i32 %t168)
  store i64 %t172, ptr %l96
  br label %bb31
bb31:
  %t173 = load i64, ptr %l96, !tbaa !24
  %t174 = icmp ne i64 %t173, 0
  br i1 %t174, label %bb32, label %bb33
bb32:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t177 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v1, ptr %t176, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t177, i1 true)
  br label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t180 = load ptr, ptr %l3, !tbaa !29
  %t181 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 5
  %t182 = load i64, ptr %t181, !tbaa !24
  %t185 = call { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %s7, ptr %t180, i64 %t182)
  store { { i64, ptr }, i1 } %t185, ptr %l102
  br label %bb35
bb34:
  br label %bb49
bb35:
  %t186 = load { { i64, ptr }, i1 }, ptr %l102
  store { { i64, ptr }, i1 } %t186, ptr %l12
  %t187 = getelementptr { { i64, ptr }, i1 }, ptr %l12, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l103, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l104, !tbaa !24
  %t191 = load i64, ptr %l104, !tbaa !24
  %t192 = mul i64 %t191, 1
  %t193 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l105, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l104, !tbaa !24
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  %t202 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t202, ptr %l13, !tbaa !27
  %t203 = getelementptr { { i64, ptr }, i1 }, ptr %l12, i32 0, i32 1
  %t204 = load i1, ptr %t203, !tbaa !21
  %t206 = load ptr, ptr %l2, !tbaa !29
  store ptr %t206, ptr %l107, !tbaa !29
  %t207 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t207, ptr %l108
  br i1 %t204, label %bb36, label %bb37
bb36:
  %t210 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t212 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %s7, ptr %s7, { i64, ptr } %t210)
  store %"compiler/msgs:Msg" %t212, ptr %l112
  br label %bb38
bb37:
  %t213 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %s7)
  store %"compiler/msgs:Msg" %t213, ptr %l113
  br label %bb39
bb38:
  %t214 = load %"compiler/msgs:Msg", ptr %l112
  store %"compiler/msgs:Msg" %t214, ptr %l110
  br label %bb40
bb39:
  %t215 = load %"compiler/msgs:Msg", ptr %l113
  store %"compiler/msgs:Msg" %t215, ptr %l110
  br label %bb40
bb40:
  %t216 = load ptr, ptr %l107, !tbaa !29
  %t217 = load { i64, [3 x i64] }, ptr %l108
  %t218 = load %"compiler/msgs:Msg", ptr %l110
  %t219 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t216, { i64, [3 x i64] } %t217, %"compiler/msgs:Msg" %t218)
  store i64 %t219, ptr %l114
  br label %bb41
bb41:
  %t220 = load i64, ptr %l114, !tbaa !24
  store i64 %t220, ptr %l15, !tbaa !24
  %t221 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 8
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t222, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t224, ptr %l116
  br label %bb42
bb42:
  %t225 = load i1, ptr %l116, !tbaa !21
  %t226 = xor i1 %t225, true
  br i1 %t226, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t228 = load ptr, ptr %l2, !tbaa !29
  store ptr %t228, ptr %l118, !tbaa !29
  %t229 = load i64, ptr %l15, !tbaa !24
  store i64 %t229, ptr %l119, !tbaa !24
  %t230 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 7
  %t231 = load { i64, [3 x i64] }, ptr %t230
  store { i64, [3 x i64] } %t231, ptr %l120
  %t232 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s8)
  store %"compiler/msgs:Msg" %t232, ptr %l121
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t233 = getelementptr %"compiler/msgs:Msg", ptr %l121, i32 0, i32 0
  %t234 = load i32, ptr %t233
  %t235 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 8
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t239 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s8, ptr %v0, ptr %s8, i32 %t234, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, { i64, ptr } %t236)
  store %"compiler/msgs:Msg" %t239, ptr %l124
  br label %bb46
bb46:
  %t240 = load ptr, ptr %l118, !tbaa !29
  %t241 = load i64, ptr %l119, !tbaa !24
  %t242 = load { i64, [3 x i64] }, ptr %l120
  %t243 = load %"compiler/msgs:Msg", ptr %l124
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t240, i64 %t241, { i64, [3 x i64] } %t242, %"compiler/msgs:Msg" %t243)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb49:
  br label %bb75
bb50:
  %t244 = load { i64, [5 x i64] }, ptr %l10
  %t246 = extractvalue { i64, [5 x i64] } %t244, 0
  %t247 = icmp eq i64 %t246, 2
  br i1 %t247, label %bb51, label %bb52
bb51:
  %t249 = getelementptr { i64, [5 x i64] }, ptr %l10, i32 0, i32 1
  %t250 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t249, i32 0, i32 0
  %t251 = load i32, ptr %t250
  store i32 %t251, ptr %l16
  %t253 = getelementptr { i64, [5 x i64] }, ptr %l10, i32 0, i32 1
  %t254 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t253, i32 0, i32 1
  %t255 = load i64, ptr %t254
  store i64 %t255, ptr %l17, !tbaa !24
  %t257 = getelementptr { i64, [5 x i64] }, ptr %l10, i32 0, i32 1
  %t258 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t257, i32 0, i32 2
  %t259 = load %"compiler/source:Span", ptr %t258
  store %"compiler/source:Span" %t259, ptr %l18
  br label %bb53
bb52:
  br label %bb59
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t261 = load i64, ptr %l4, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l4, !tbaa !24
  %t265 = load ptr, ptr %l2, !tbaa !29
  store ptr %t265, ptr %l132, !tbaa !29
  %t266 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t266, ptr %l133
  %t267 = load i32, ptr %l16
  %t269 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s9, i32 %t267)
  store { i64, ptr } %t269, ptr %l135
  br label %bb54
bb54:
  %t270 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t271 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %s9, ptr %s9, { i64, ptr } %t270)
  store %"compiler/msgs:Msg" %t271, ptr %l136
  br label %bb55
bb55:
  %t272 = load ptr, ptr %l132, !tbaa !29
  %t273 = load { i64, [3 x i64] }, ptr %l133
  %t274 = load %"compiler/msgs:Msg", ptr %l136
  %t275 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t272, { i64, [3 x i64] } %t273, %"compiler/msgs:Msg" %t274)
  store i64 %t275, ptr %l137
  br label %bb56
bb56:
  %t276 = load i64, ptr %l137, !tbaa !24
  %t277 = load ptr, ptr %l2, !tbaa !29
  store ptr %t277, ptr %l138, !tbaa !29
  store i64 %t276, ptr %l139, !tbaa !24
  %t279 = load i64, ptr %l17, !tbaa !24
  %t280 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t281 = load i32, ptr %t280, !tbaa !23
  %t283 = sext i32 %t281 to i64
  %t284 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t285 = load i32, ptr %t284, !tbaa !23
  %t287 = sext i32 %t285 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t288, i32 0, i32 0
  store i64 3, ptr %t289
  %t291 = insertvalue { i64, i64, i64 } undef, i64 %t279, 0
  %t293 = insertvalue { i64, i64, i64 } %t291, i64 %t283, 1
  %t295 = insertvalue { i64, i64, i64 } %t293, i64 %t287, 2
  %t296 = getelementptr { i64, [3 x i64] }, ptr %t288, i32 0, i32 1
  store { i64, i64, i64 } %t295, ptr %t296
  %t297 = load { i64, [3 x i64] }, ptr %t288
  store { i64, [3 x i64] } %t297, ptr %l145
  %t298 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s9)
  store %"compiler/msgs:Msg" %t298, ptr %l146
  br label %bb57
bb57:
  %t299 = load ptr, ptr %l138, !tbaa !29
  %t300 = load i64, ptr %l139, !tbaa !24
  %t301 = load { i64, [3 x i64] }, ptr %l145
  %t302 = load %"compiler/msgs:Msg", ptr %l146
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s9, ptr %t299, i64 %t300, { i64, [3 x i64] } %t301, %"compiler/msgs:Msg" %t302)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb75
bb59:
  %t303 = load { i64, [5 x i64] }, ptr %l10
  %t305 = extractvalue { i64, [5 x i64] } %t303, 0
  %t306 = icmp eq i64 %t305, 3
  br i1 %t306, label %bb60, label %bb61
bb60:
  %t308 = getelementptr { i64, [5 x i64] }, ptr %l10, i32 0, i32 1
  %t309 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t308, i32 0, i32 0
  %t310 = load { i64, ptr }, ptr %t309
  store { i64, ptr } %t310, ptr %l20, !tbaa !27
  %t312 = getelementptr { i64, [5 x i64] }, ptr %l10, i32 0, i32 1
  %t313 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t312, i32 0, i32 1
  %t314 = load i64, ptr %t313
  store i64 %t314, ptr %l21, !tbaa !24
  %t316 = getelementptr { i64, [5 x i64] }, ptr %l10, i32 0, i32 1
  %t317 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t316, i32 0, i32 2
  %t318 = load %"compiler/source:Span", ptr %t317
  store %"compiler/source:Span" %t318, ptr %l22
  br label %bb62
bb61:
  br label %bb70
bb62:
  %t320 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t321 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t322 = load ptr, ptr @__olang_prog_scope
  %t325 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t322, { i64, ptr } %t320, { i64, ptr } %t321)
  store i1 %t325, ptr %l154
  br label %bb63
bb63:
  %t326 = load i1, ptr %l154, !tbaa !21
  br i1 %t326, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s11
  %t327 = load i64, ptr %l4, !tbaa !24
  %t329 = add i64 %t327, 1
  store i64 %t329, ptr %l4, !tbaa !24
  %t331 = load ptr, ptr %l2, !tbaa !29
  store ptr %t331, ptr %l157, !tbaa !29
  %t332 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t332, ptr %l158
  %t333 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t335 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %v0, ptr %s11, { i64, ptr } %t333)
  store %"compiler/msgs:Msg" %t335, ptr %l160
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t336 = load ptr, ptr %l157, !tbaa !29
  %t337 = load { i64, [3 x i64] }, ptr %l158
  %t338 = load %"compiler/msgs:Msg", ptr %l160
  %t339 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t336, { i64, [3 x i64] } %t337, %"compiler/msgs:Msg" %t338)
  store i64 %t339, ptr %l161
  br label %bb67
bb67:
  %t340 = load i64, ptr %l161, !tbaa !24
  %t341 = load ptr, ptr %l3, !tbaa !29
  %t342 = load ptr, ptr %l2, !tbaa !29
  %t344 = load i64, ptr %l21, !tbaa !24
  %t345 = load %"compiler/source:Span", ptr %l22
  call void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v0, ptr %t341, ptr %t342, i64 %t340, i64 %t344, %"compiler/source:Span" %t345)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s11)
  br label %bb69
bb69:
  br label %bb75
bb70:
  br i1 true, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_d8df33bf7c2af1a9_d617709f0680343d)
  unreachable
bb75:
  call void @__olang_scope_close(ptr %s3)
  br label %bb76
bb76:
  %t351 = load i64, ptr %l6, !tbaa !24
  %t353 = add i64 %t351, 1
  store i64 %t353, ptr %l6, !tbaa !24
  br label %bb11
bb77:
  %t355 = load i64, ptr %l4, !tbaa !24
  store i64 %t355, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:ValueAsk"
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca { i64, [2 x i64] }
  %l11 = alloca { i64, [3 x i64] }
  %l12 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca i1
  %l18 = alloca { i64, [3 x i64] }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l21 = alloca i64
  %l24 = alloca i64
  %l36 = alloca %"compiler/interp:Exec"
  %l41 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca %"compiler/check:ValueAsk"
  %l55 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l58 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca { i64, [2 x i64] }
  %l71 = alloca { i64, [5 x i64] }
  %l80 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l87 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca { i64, [3 x i64] }
  %l102 = alloca { i64, ptr }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca { i64, [3 x i64] }
  %l114 = alloca { i64, ptr }
  %l117 = alloca %"compiler/msgs:Msg"
  %l118 = alloca i64
  %l125 = alloca { i64, [3 x i64] }
  %l127 = alloca { i64, [3 x i64] }
  %l129 = alloca i1
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l134 = alloca i64
  %l135 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca { i64, [3 x i64] }
  %l141 = alloca { i64, ptr }
  %l143 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l145 = alloca { i64, ptr }
  %l147 = alloca i64
  %l149 = alloca i64
  %l150 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca { i64, [3 x i64] }
  %l155 = alloca { i64, ptr }
  %l158 = alloca %"compiler/msgs:Msg"
  %l159 = alloca i64
  %l161 = alloca ptr
  %l162 = alloca i64
  %l163 = alloca { i64, [3 x i64] }
  %l164 = alloca %"compiler/msgs:Msg"
  %l172 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca i64
  %l176 = alloca { i64, [3 x i64] }
  %l178 = alloca %"compiler/msgs:Msg"
  %l180 = alloca ptr
  %l181 = alloca i64
  %l182 = alloca { i64, [3 x i64] }
  %l185 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l191 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i64
  %t29 = alloca %"compiler/interp:Exec", align 8
  %t86 = alloca { i64, [2 x i64] }, align 8
  %t126 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 79
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 4
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 11
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27
  call void @compiler_2finterp_3aExec_2ector(ptr %t29, ptr %v0, ptr %v0, ptr %v0, ptr %t24, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t29, i64 976, i1 false)
  br label %bb5
bb5:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 976, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l36, i64 976, i1 false)
  store ptr %t33, ptr %l2, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 89
  %t39 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t38
  %t42 = getelementptr %"compiler/interp:Exec", ptr %t35, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %t42
  %t43 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l41
  br label %bb6
bb6:
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 79
  store ptr %t47, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l44, !tbaa !24
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l46
  br label %bb8
bb8:
  %t53 = load i64, ptr %l44, !tbaa !24
  %t54 = load i64, ptr %l46, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb10:
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = call %"compiler/check:ValueAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eAt_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t59, i64 %t60)
  store %"compiler/check:ValueAsk" %t63, ptr %l51
  br label %bb12
bb12:
  %t64 = load %"compiler/check:ValueAsk", ptr %l51
  store %"compiler/check:ValueAsk" %t64, ptr %l7
  %t65 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t68 = getelementptr %"compiler/source:Span", ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = sext i32 %t69 to i64
  %t74 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t66, i64 %t71)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t74, ptr %l55
  br label %bb13
bb13:
  %t75 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l55
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t75, ptr %l8
  %t76 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t79 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t76)
  store i1 %t79, ptr %l58
  br label %bb14
bb14:
  %t80 = load i1, ptr %l58, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb16:
  br label %bb17
bb17:
  %t81 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 4
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = trunc i64 %t82 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 0
  store i64 0, ptr %t87
  %t89 = insertvalue { i32 } undef, i32 %t84, 0
  %t90 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 1
  store { i32 } %t89, ptr %t90
  %t91 = load { i64, [2 x i64] }, ptr %t86
  store { i64, [2 x i64] } %t91, ptr %l9
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t94 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t93, { i64, [2 x i64] } %t94)
  br label %bb18
bb18:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/interp:Exec", ptr %t97, i32 0, i32 4
  store ptr %t99, ptr %l66, !tbaa !29
  %t100 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t100, ptr %l67
  %t101 = icmp sge i64 0, 0
  br i1 %t101, label %bb19, label %bb20
bb19:
  %t103 = icmp sle i64 0, 1152921504606846975
  br i1 %t103, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e1183b54591591ba_6784d54d52bb291e)
  unreachable
bb21:
  %t105 = mul i64 0, 8
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 0, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l66, !tbaa !29
  %t110 = load { i64, [2 x i64] }, ptr %l67
  %t112 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t109, { i64, [2 x i64] } %t110, { i64, ptr } %t108)
  store { i64, [5 x i64] } %t112, ptr %l71
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e1183b54591591ba_6784d54d52bb291e)
  unreachable
bb23:
  %t113 = load { i64, [5 x i64] }, ptr %l71
  %t114 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 1
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t117 = getelementptr %"compiler/source:Span", ptr %t116, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t120 = sext i32 %t118 to i64
  %t121 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t122 = getelementptr %"compiler/source:Span", ptr %t121, i32 0, i32 1
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [3 x i64] }, ptr %t126, i32 0, i32 0
  store i64 3, ptr %t127
  %t129 = insertvalue { i64, i64, i64 } undef, i64 %t115, 0
  %t131 = insertvalue { i64, i64, i64 } %t129, i64 %t120, 1
  %t133 = insertvalue { i64, i64, i64 } %t131, i64 %t125, 2
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t126, i32 0, i32 1
  store { i64, i64, i64 } %t133, ptr %t134
  %t135 = load { i64, [3 x i64] }, ptr %t126
  store { i64, [3 x i64] } %t135, ptr %l11
  %t138 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t139 = load %"compiler/source:Span", ptr %t138
  %t142 = call { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %s3, { i64, [5 x i64] } %t113, %"compiler/source:Span" %t139)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t142, ptr %l80
  br label %bb24
bb24:
  %t143 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l80
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t143, ptr %l12
  %t144 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l12, i32 0, i32 0
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l81, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l82, !tbaa !24
  %t148 = load i64, ptr %l82, !tbaa !24
  %t149 = mul i64 %t148, 1
  %t150 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  store { i64, ptr } %t152, ptr %l83, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l82, !tbaa !24
  %t158 = mul i64 %t157, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t154, ptr %t156, i64 %t158, i1 false)
  %t159 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t159, ptr %l13, !tbaa !27
  %t160 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l12, i32 0, i32 1
  %t161 = load i64, ptr %t160, !tbaa !24
  store i64 %t161, ptr %l14, !tbaa !24
  %t163 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l12, i32 0, i32 2
  %t164 = load %"compiler/source:Span", ptr %t163
  store %"compiler/source:Span" %t164, ptr %l15
  %t166 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t166, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t168, ptr %l87
  br label %bb25
bb25:
  %t169 = load i1, ptr %l87, !tbaa !21
  br i1 %t169, label %bb26, label %bb27
bb26:
  %t170 = load i64, ptr %l4, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l4, !tbaa !24
  %t174 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 0
  %t175 = load i32, ptr %t174
  %t177 = trunc i64 2 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb28, label %bb29
bb27:
  br label %bb39
bb28:
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t182 = getelementptr %"compiler/interp:Exec", ptr %t180, i32 0, i32 4
  %t184 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eResultHoldsAddress(ptr %v0, ptr %t182)
  store i1 %t184, ptr %l95
  br label %bb30
bb29:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb31
bb30:
  %t185 = load i1, ptr %l95, !tbaa !21
  store i1 %t185, ptr %l92, !tbaa !21
  br label %bb31
bb31:
  %t186 = load i1, ptr %l92, !tbaa !21
  br i1 %t186, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t187 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t187, i1 true)
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t190 = load ptr, ptr %l1, !tbaa !29
  store ptr %t190, ptr %l98, !tbaa !29
  %t191 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t191, ptr %l99
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t194 = load i32, ptr %t193, !tbaa !23
  %t197 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s6, ptr %t192, i32 %t194)
  store { i64, ptr } %t197, ptr %l102
  br label %bb35
bb35:
  %t198 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t206 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eZeroValueShared(ptr %s6, ptr %s6, { i64, ptr } %t204)
  store %"compiler/msgs:Msg" %t206, ptr %l104
  br label %bb36
bb36:
  %t207 = load ptr, ptr %l98, !tbaa !29
  %t208 = load { i64, [3 x i64] }, ptr %l99
  %t209 = load %"compiler/msgs:Msg", ptr %l104
  %t210 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t207, { i64, [3 x i64] } %t208, %"compiler/msgs:Msg" %t209)
  store i64 %t210, ptr %l105
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb39:
  %t211 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t211, i1 true)
  br label %bb40
bb40:
  %t214 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 0
  %t215 = load i32, ptr %t214
  %t217 = trunc i64 0 to i32
  %t218 = icmp eq i32 %t215, %t217
  br i1 %t218, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l110, !tbaa !29
  %t221 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t221, ptr %l111
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t224 = load i32, ptr %t223, !tbaa !23
  %t227 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t222, i32 %t224)
  store { i64, ptr } %t227, ptr %l114
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t228 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  %t230 = extractvalue { i64, ptr } %t228, 1
  %t231 = mul i64 %t229, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  %t235 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t238 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralCtorFails(ptr %s7, ptr %s3, ptr %s7, { i64, ptr } %t234, { i64, ptr } %t235)
  store %"compiler/msgs:Msg" %t238, ptr %l117
  br label %bb44
bb44:
  %t239 = load ptr, ptr %l110, !tbaa !29
  %t240 = load { i64, [3 x i64] }, ptr %l111
  %t241 = load %"compiler/msgs:Msg", ptr %l117
  %t242 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t239, { i64, [3 x i64] } %t240, %"compiler/msgs:Msg" %t241)
  store i64 %t242, ptr %l118
  br label %bb45
bb45:
  %t243 = load i64, ptr %l118, !tbaa !24
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 1
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t249 = load %"compiler/source:Span", ptr %t248
  %t250 = load i64, ptr %l14, !tbaa !24
  %t251 = load %"compiler/source:Span", ptr %l15
  call void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %t244, i64 %t243, i64 %t247, %"compiler/source:Span" %t249, i64 %t250, %"compiler/source:Span" %t251)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb47:
  %t258 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 5
  %t259 = load { i64, [3 x i64] }, ptr %t258
  store { i64, [3 x i64] } %t259, ptr %l125
  %t260 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t260, ptr %l127
  %t263 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %l125, ptr %l127)
  store i1 %t263, ptr %l129
  br label %bb48
bb48:
  %t264 = load i1, ptr %l129, !tbaa !21
  %t265 = xor i1 %t264, true
  store i1 %t265, ptr %l17, !tbaa !21
  %t267 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 5
  %t268 = load { i64, [3 x i64] }, ptr %t267
  store { i64, [3 x i64] } %t268, ptr %l18
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l132, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t270, ptr %l133, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l134, !tbaa !24
  %t273 = load i64, ptr %l134, !tbaa !24
  %t274 = mul i64 %t273, 1
  %t275 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  store { i64, ptr } %t277, ptr %l135, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = load i64, ptr %l134, !tbaa !24
  %t283 = mul i64 %t282, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t279, ptr %t281, i64 %t283, i1 false)
  %t284 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t284, ptr %l19, !tbaa !27
  %t285 = load i1, ptr %l17, !tbaa !21
  br i1 %t285, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t287 = load ptr, ptr %l1, !tbaa !29
  store ptr %t287, ptr %l137, !tbaa !29
  %t288 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 5
  %t289 = load { i64, [3 x i64] }, ptr %t288
  store { i64, [3 x i64] } %t289, ptr %l138
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t292 = load i32, ptr %t291, !tbaa !23
  %t295 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s8, ptr %t290, i32 %t292)
  store { i64, ptr } %t295, ptr %l141
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t296 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 0
  %t298 = extractvalue { i64, ptr } %t296, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  %t303 = load ptr, ptr %l137, !tbaa !29
  %t304 = load { i64, [3 x i64] }, ptr %l138
  %t306 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2finterp_2ezeroUseArg(ptr %v0, ptr %s8, ptr %s8, ptr %t303, { i64, [3 x i64] } %t304, { i64, ptr } %t302)
  store { { i64, [3 x i64] }, { i64, ptr } } %t306, ptr %l143
  br label %bb52
bb52:
  %t307 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l143
  store { { i64, [3 x i64] }, { i64, ptr } } %t307, ptr %l20
  %t308 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l20, i32 0, i32 0
  %t309 = load { i64, [3 x i64] }, ptr %t308
  store { i64, [3 x i64] } %t309, ptr %l18
  %t311 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l20, i32 0, i32 1
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !27
  store { i64, ptr } %t312, ptr %l145, !tbaa !27
  %t313 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 0
  %t315 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  store i64 %t316, ptr %l147, !tbaa !24
  %t318 = load i64, ptr %l147, !tbaa !24
  %t319 = icmp eq i64 %t314, %t318
  br i1 %t319, label %bb53, label %bb54
bb53:
  %t321 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = load i64, ptr %l147, !tbaa !24
  %t326 = mul i64 %t325, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t322, ptr %t324, i64 %t326, i1 false)
  br label %bb55
bb54:
  %t327 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t327, 0
  store i64 %t328, ptr %l149, !tbaa !24
  %t329 = load i64, ptr %l149, !tbaa !24
  %t330 = mul i64 %t329, 1
  %t331 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t330)
  %t332 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  store { i64, ptr } %t333, ptr %l150, !tbaa !27
  %t334 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = load i64, ptr %l149, !tbaa !24
  %t339 = mul i64 %t338, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t335, ptr %t337, i64 %t339, i1 false)
  %t340 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t340, ptr %l19, !tbaa !27
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  %t341 = load ptr, ptr %l1, !tbaa !29
  store ptr %t341, ptr %l151, !tbaa !29
  %t342 = load { i64, [3 x i64] }, ptr %l18
  store { i64, [3 x i64] } %t342, ptr %l152
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t345 = load i32, ptr %t344, !tbaa !23
  %t348 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s3, ptr %t343, i32 %t345)
  store { i64, ptr } %t348, ptr %l155
  br label %bb57
bb57:
  %t349 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  %t351 = extractvalue { i64, ptr } %t349, 1
  %t352 = mul i64 %t350, 1
  %t353 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t352)
  call void @llvm.memcpy.p0.p0.i64(ptr %t353, ptr %t351, i64 %t352, i1 false)
  %t354 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  %t356 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t359 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t355, { i64, ptr } %t356)
  store %"compiler/msgs:Msg" %t359, ptr %l158
  br label %bb58
bb58:
  %t360 = load ptr, ptr %l151, !tbaa !29
  %t361 = load { i64, [3 x i64] }, ptr %l152
  %t362 = load %"compiler/msgs:Msg", ptr %l158
  %t363 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t360, { i64, [3 x i64] } %t361, %"compiler/msgs:Msg" %t362)
  store i64 %t363, ptr %l159
  br label %bb59
bb59:
  %t364 = load i64, ptr %l159, !tbaa !24
  store i64 %t364, ptr %l21, !tbaa !24
  %t365 = load i1, ptr %l17, !tbaa !21
  br i1 %t365, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t367 = load ptr, ptr %l1, !tbaa !29
  store ptr %t367, ptr %l161, !tbaa !29
  %t368 = load i64, ptr %l21, !tbaa !24
  store i64 %t368, ptr %l162, !tbaa !24
  %t369 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t369, ptr %l163
  %t370 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %s9)
  store %"compiler/msgs:Msg" %t370, ptr %l164
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t371 = load ptr, ptr %l161, !tbaa !29
  %t372 = load i64, ptr %l162, !tbaa !24
  %t373 = load { i64, [3 x i64] }, ptr %l163
  %t374 = load %"compiler/msgs:Msg", ptr %l164
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s9, ptr %t371, i64 %t372, { i64, [3 x i64] } %t373, %"compiler/msgs:Msg" %t374)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb64:
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t376 = load i64, ptr %l21, !tbaa !24
  %t377 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 1
  %t378 = load i64, ptr %t377, !tbaa !24
  %t379 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t380 = load %"compiler/source:Span", ptr %t379
  %t381 = load i64, ptr %l14, !tbaa !24
  %t382 = load %"compiler/source:Span", ptr %l15
  call void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %t375, i64 %t376, i64 %t378, %"compiler/source:Span" %t380, i64 %t381, %"compiler/source:Span" %t382)
  br label %bb65
bb65:
  %t389 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t391 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t389, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t391, ptr %l172
  br label %bb66
bb66:
  %t392 = load i1, ptr %l172, !tbaa !21
  %t393 = xor i1 %t392, true
  br i1 %t393, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t395 = load ptr, ptr %l1, !tbaa !29
  store ptr %t395, ptr %l174, !tbaa !29
  %t396 = load i64, ptr %l21, !tbaa !24
  store i64 %t396, ptr %l175, !tbaa !24
  %t397 = load { i64, [3 x i64] }, ptr %l18
  store { i64, [3 x i64] } %t397, ptr %l176
  %t398 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t400 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroByReference(ptr %s3, ptr %s10, { i64, ptr } %t398)
  store %"compiler/msgs:Msg" %t400, ptr %l178
  br label %bb69
bb68:
  %t401 = load i1, ptr %l17, !tbaa !21
  br i1 %t401, label %bb71, label %bb72
bb69:
  %t403 = load ptr, ptr %l174, !tbaa !29
  %t404 = load i64, ptr %l175, !tbaa !24
  %t405 = load { i64, [3 x i64] }, ptr %l176
  %t406 = load %"compiler/msgs:Msg", ptr %l178
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s10, ptr %t403, i64 %t404, { i64, [3 x i64] } %t405, %"compiler/msgs:Msg" %t406)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb78
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t407 = load ptr, ptr %l1, !tbaa !29
  store ptr %t407, ptr %l180, !tbaa !29
  %t408 = load i64, ptr %l21, !tbaa !24
  store i64 %t408, ptr %l181, !tbaa !24
  %t409 = load { i64, [3 x i64] }, ptr %l18
  store { i64, [3 x i64] } %t409, ptr %l182
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t412 = load i32, ptr %t411, !tbaa !23
  %t415 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s12, ptr %t410, i32 %t412)
  store { i64, ptr } %t415, ptr %l185
  br label %bb73
bb72:
  br label %bb77
bb73:
  %t416 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t416, 0
  %t418 = extractvalue { i64, ptr } %t416, 1
  %t419 = mul i64 %t417, 1
  %t420 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t419)
  call void @llvm.memcpy.p0.p0.i64(ptr %t420, ptr %t418, i64 %t419, i1 false)
  %t421 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  store { i64, ptr } %t422, ptr %l186, !tbaa !27
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t425 = load i32, ptr %t424, !tbaa !23
  %t428 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s12, ptr %t423, i32 %t425)
  store { i64, ptr } %t428, ptr %l189
  br label %bb74
bb74:
  %t429 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t429, 0
  %t431 = extractvalue { i64, ptr } %t429, 1
  %t432 = mul i64 %t430, 1
  %t433 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t432)
  call void @llvm.memcpy.p0.p0.i64(ptr %t433, ptr %t431, i64 %t432, i1 false)
  %t434 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t433, 1
  %t436 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t438 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroReferenceHasOne(ptr %s12, ptr %s12, ptr %s12, { i64, ptr } %t436, { i64, ptr } %t435)
  store %"compiler/msgs:Msg" %t438, ptr %l191
  br label %bb75
bb75:
  %t439 = load ptr, ptr %l180, !tbaa !29
  %t440 = load i64, ptr %l181, !tbaa !24
  %t441 = load { i64, [3 x i64] }, ptr %l182
  %t442 = load %"compiler/msgs:Msg", ptr %l191
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s12, ptr %t439, i64 %t440, { i64, [3 x i64] } %t441, %"compiler/msgs:Msg" %t442)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s12)
  br label %bb77
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb79:
  %t443 = load i64, ptr %l6, !tbaa !24
  %t445 = add i64 %t443, 1
  store i64 %t445, ptr %l6, !tbaa !24
  br label %bb7
bb80:
  %t447 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t447, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t6, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = icmp sge i64 2, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  br label %bb10
bb4:
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 2, %t22
  br i1 %t23, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_31552f310cf75527_9d9c34da119f96fb)
  unreachable
bb6:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_31552f310cf75527_9d9c34da119f96fb)
  unreachable
bb8:
  %t29 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 2
  %t33 = sub i64 %t31, 2
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t39 = extractvalue { i64, ptr } %t35, 1
  %t40 = extractvalue { i64, ptr } %t35, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t36, i64 %t37)
  %t46 = getelementptr i8, ptr %t45, i64 %t37
  call void @olang_textcopy(ptr %t46, ptr %t39, i64 %t40)
  %t47 = getelementptr i8, ptr %t46, i64 %t40
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t45, 1
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t51, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l5, !tbaa !27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_31552f310cf75527_9d9c34da119f96fb)
  unreachable
bb10:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t60, ptr %l20
  br label %bb11
bb11:
  %t61 = load i1, ptr %l20, !tbaa !21
  br i1 %t61, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb15
bb13:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t64, ptr %l23
  br label %bb14
bb14:
  %t65 = load i1, ptr %l23, !tbaa !21
  store i1 %t65, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t66 = load i1, ptr %l21, !tbaa !21
  br i1 %t66, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t67, ptr %l25, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l26, !tbaa !24
  %t70 = load i64, ptr %l26, !tbaa !24
  %t71 = mul i64 %t70, 1
  %t72 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l27, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l26, !tbaa !24
  %t80 = mul i64 %t79, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %t78, i64 %t80, i1 false)
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t82 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t82, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t85 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToC(ptr %s0, ptr %s0, { i64, ptr } %t83)
  store { i64, ptr } %t85, ptr %l29
  br label %bb19
bb19:
  %t86 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = call ptr @dlopen(ptr %t87, i32 258)
  store ptr %t89, ptr %l30
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l30, !tbaa !29
  %t91 = icmp eq ptr %t90, null
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t95, ptr %l34, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l35, !tbaa !24
  %t98 = load i64, ptr %l35, !tbaa !24
  %t99 = mul i64 %t98, 1
  %t100 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l36, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l35, !tbaa !24
  %t108 = mul i64 %t107, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t109, ptr %l34, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t110 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t111 = call ptr @dlerror()
  store ptr %t111, ptr %l37
  br label %bb24
bb24:
  %t112 = load ptr, ptr %l37, !tbaa !29
  store ptr %t112, ptr %l2, !tbaa !29
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb25, label %bb26
bb25:
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t122 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aCStr_2eStringFromC(ptr %v1, ptr %t119, i64 400)
  store { i64, ptr } %t122, ptr %l44
  br label %bb27
bb26:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t123, ptr %l41, !tbaa !27
  br label %bb28
bb27:
  %t125 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t125, ptr %l41, !tbaa !27
  br label %bb28
bb28:
  %t126 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l47, !tbaa !24
  %t128 = load i64, ptr %l47, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l48, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l47, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t139, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t140 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t140, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2eStopText(ptr %v0, ptr %v1, ptr %v2, { i64, [5 x i64] } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, [5 x i64] }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l43 = alloca i1
  %l47 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, [5 x i64] } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l14, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb4:
  %t22 = load { i64, [5 x i64] }, ptr %l0
  %t24 = extractvalue { i64, [5 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 1
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t31)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb8:
  %t43 = load { i64, [5 x i64] }, ptr %l0
  %t45 = extractvalue { i64, [5 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 2
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t49 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t48, i32 0, i32 0
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l3
  %t52 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t53 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t52, i32 0, i32 1
  %t54 = load i64, ptr %t53
  store i64 %t54, ptr %l4, !tbaa !24
  %t56 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t57 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t56, i32 0, i32 2
  %t58 = load %"compiler/source:Span", ptr %t57
  store %"compiler/source:Span" %t58, ptr %l5
  %t60 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t61 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t60, i32 0, i32 3
  %t62 = load { i64, ptr }, ptr %t61
  store { i64, ptr } %t62, ptr %l6, !tbaa !27
  br label %bb11
bb10:
  br label %bb27
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i32, ptr %l3
  %t66 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s4, i32 %t64)
  store { i64, ptr } %t66, ptr %l29
  br label %bb12
bb12:
  %t67 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t67, ptr %l7, !tbaa !27
  %t68 = load i32, ptr %l3
  %t70 = trunc i64 12 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  %t75 = load %"compiler/source:Span", ptr %l5
  %t79 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s5, ptr %t73, i64 %t74, %"compiler/source:Span" %t75)
  store { i64, ptr } %t79, ptr %l35
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t88 = extractvalue { i64, ptr } %t80, 1
  %t89 = extractvalue { i64, ptr } %t80, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t84, i64 %t85)
  %t93 = getelementptr i8, ptr %t92, i64 %t85
  call void @olang_textcopy(ptr %t93, ptr %t88, i64 %t89)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t91, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
bb16:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t97, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t99, ptr %l39
  br label %bb17
bb17:
  %t100 = load i1, ptr %l39, !tbaa !21
  br i1 %t100, label %bb18, label %bb19
bb18:
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = extractvalue { i64, ptr } %t101, 0
  %t105 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t103, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t109, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t111, ptr %l43
  br label %bb21
bb21:
  %t112 = load i1, ptr %l43, !tbaa !21
  br i1 %t112, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s9
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load %"compiler/source:Span", ptr %l5
  %t119 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s9, ptr %t113, i64 %t114, %"compiler/source:Span" %t115)
  store { i64, ptr } %t119, ptr %l47
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = extractvalue { i64, ptr } %t120, 1
  %t129 = extractvalue { i64, ptr } %t120, 0
  %t130 = add i64 %t126, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = getelementptr i8, ptr %t131, i64 %t123
  call void @olang_textcopy(ptr %t132, ptr %t124, i64 %t125)
  %t133 = getelementptr i8, ptr %t132, i64 %t125
  call void @olang_textcopy(ptr %t133, ptr %t128, i64 %t129)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t131, 1
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t135, ptr %rv
  br label %ret
bb25:
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t138 = load i64, ptr %l4, !tbaa !24
  %t139 = load %"compiler/source:Span", ptr %l5
  %t143 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t137, i64 %t138, %"compiler/source:Span" %t139)
  store { i64, ptr } %t143, ptr %l53
  br label %bb26
bb26:
  %t144 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = extractvalue { i64, ptr } %t144, 1
  %t154 = extractvalue { i64, ptr } %t144, 0
  %t155 = add i64 %t151, %t154
  %t156 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t160 = extractvalue { i64, ptr } %t145, 1
  %t161 = extractvalue { i64, ptr } %t145, 0
  %t162 = add i64 %t158, %t161
  %t163 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t147, i64 %t148)
  %t164 = getelementptr i8, ptr %t163, i64 %t148
  call void @olang_textcopy(ptr %t164, ptr %t149, i64 %t150)
  %t165 = getelementptr i8, ptr %t164, i64 %t150
  call void @olang_textcopy(ptr %t165, ptr %t153, i64 %t154)
  %t166 = getelementptr i8, ptr %t165, i64 %t154
  call void @olang_textcopy(ptr %t166, ptr %t156, i64 %t157)
  %t167 = getelementptr i8, ptr %t166, i64 %t157
  call void @olang_textcopy(ptr %t167, ptr %t160, i64 %t161)
  %t168 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t163, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t169, ptr %rv
  br label %ret
bb27:
  %t171 = load { i64, [5 x i64] }, ptr %l0
  %t173 = extractvalue { i64, [5 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 3
  br i1 %t174, label %bb28, label %bb29
bb28:
  %t176 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t177 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t176, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177
  store { i64, ptr } %t178, ptr %l8, !tbaa !27
  %t180 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t180, i32 0, i32 1
  %t182 = load i64, ptr %t181
  store i64 %t182, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t185 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t184, i32 0, i32 2
  %t186 = load %"compiler/source:Span", ptr %t185
  store %"compiler/source:Span" %t186, ptr %l10
  br label %bb30
bb29:
  br label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s12
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t189 = load i64, ptr %l9, !tbaa !24
  %t190 = load %"compiler/source:Span", ptr %l10
  %t194 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s12, ptr %t188, i64 %t189, %"compiler/source:Span" %t190)
  store { i64, ptr } %t194, ptr %l65
  br label %bb31
bb31:
  %t195 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %t195, 1
  %t204 = extractvalue { i64, ptr } %t195, 0
  %t205 = add i64 %t201, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t197, i64 %t198)
  %t207 = getelementptr i8, ptr %t206, i64 %t198
  call void @olang_textcopy(ptr %t207, ptr %t199, i64 %t200)
  %t208 = getelementptr i8, ptr %t207, i64 %t200
  call void @olang_textcopy(ptr %t208, ptr %t203, i64 %t204)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t206, 1
  call void @__olang_scope_close(ptr %s12)
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5ef8759083cc657e_8312724bf589cc02)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, i1, { i64, ptr }, { i64, [3 x i64] } } @compiler_2finterp_2echain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca i64
  %l11 = alloca { i1, { i64, [5 x i64] } }
  %l12 = alloca i1
  %l13 = alloca { i64, [5 x i64] }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l50 = alloca ptr
  %l51 = alloca i64
  %l57 = alloca i64
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i1, { i64, [5 x i64] } }
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca { i64, ptr }
  %l128 = alloca i64
  %l131 = alloca { i64, ptr }
  %l134 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l145 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %t64 = alloca { i64, [3 x i64] }, align 8
  %t366 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 5
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l29
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l29, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store ptr %a3, ptr %l7, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  %t37 = xor i1 %t35, true
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb48
bb4:
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopIf", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_97cc5832d0a5683f_9bb5deb899ee2c5b)
  unreachable
bb7:
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopIf", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t51)
  store %"compiler/source:Span" %t53, ptr %l43
  br label %bb9
bb9:
  %t54 = load %"compiler/source:Span", ptr %l43
  store %"compiler/source:Span" %t54, ptr %l8
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t60 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t63 = sext i32 %t61 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 0
  store i64 3, ptr %t65
  %t67 = insertvalue { i64, i64, i64 } undef, i64 %t55, 0
  %t69 = insertvalue { i64, i64, i64 } %t67, i64 %t59, 1
  %t71 = insertvalue { i64, i64, i64 } %t69, i64 %t63, 2
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  store { i64, i64, i64 } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t64
  store { i64, [3 x i64] } %t73, ptr %l9
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l50, !tbaa !29
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %l51, !tbaa !24
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t79 = getelementptr %"compiler/ast:TopIf", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9c0b486f116f3620_d1f759da60f3616c)
  unreachable
bb11:
  br label %bb12
bb12:
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t86 = getelementptr %"compiler/ast:TopIf", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load ptr, ptr %l50, !tbaa !29
  %t89 = load i64, ptr %l51, !tbaa !24
  %t91 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v1, ptr %v2, ptr %t88, i64 %t89, ptr %t87)
  store i64 %t91, ptr %l57
  br label %bb13
bb13:
  %t92 = load i64, ptr %l57, !tbaa !24
  store i64 %t92, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = icmp slt i64 %t93, 0
  br i1 %t95, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t98 = load { i64, [3 x i64] }, ptr %l9
  %t99 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 0, 0
  %t100 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t99, i1 false, 1
  %t102 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t100, { i64, ptr } %t97, 2
  %t104 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t102, { i64, [3 x i64] } %t98, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t104, ptr %l63
  %t105 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l63, i32 0, i32 2
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l64, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l65, !tbaa !24
  %t109 = load i64, ptr %l65, !tbaa !24
  %t110 = mul i64 %t109, 1
  %t111 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l66, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = load i64, ptr %l65, !tbaa !24
  %t119 = mul i64 %t118, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t115, ptr %t117, i64 %t119, i1 false)
  %t120 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t121 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l63, i32 0, i32 2
  store { i64, ptr } %t120, ptr %t121, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t122 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l63
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t122, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t127 = call { i1, { i64, [5 x i64] } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCondStop(ptr %v0, ptr %s1, ptr %a0, i64 %t124)
  store { i1, { i64, [5 x i64] } } %t127, ptr %l69
  br label %bb17
bb17:
  %t128 = load { i1, { i64, [5 x i64] } }, ptr %l69
  store { i1, { i64, [5 x i64] } } %t128, ptr %l11
  %t129 = getelementptr { i1, { i64, [5 x i64] } }, ptr %l11, i32 0, i32 0
  %t130 = load i1, ptr %t129, !tbaa !21
  store i1 %t130, ptr %l12, !tbaa !21
  %t132 = getelementptr { i1, { i64, [5 x i64] } }, ptr %l11, i32 0, i32 1
  %t133 = load { i64, [5 x i64] }, ptr %t132
  store { i64, [5 x i64] } %t133, ptr %l13
  %t135 = load { i64, [5 x i64] }, ptr %l13
  %t137 = extractvalue { i64, [5 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 0
  br i1 %t138, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb37
bb21:
  %t140 = load { i64, [5 x i64] }, ptr %l13
  %t142 = extractvalue { i64, [5 x i64] } %t140, 0
  %t143 = icmp eq i64 %t142, 3
  br i1 %t143, label %bb22, label %bb23
bb22:
  %t145 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t146 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t145, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146
  store { i64, ptr } %t147, ptr %l14, !tbaa !27
  %t149 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t150 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t149, i32 0, i32 1
  %t151 = load i64, ptr %t150
  store i64 %t151, ptr %l15, !tbaa !24
  %t153 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t154 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t153, i32 0, i32 2
  %t155 = load %"compiler/source:Span", ptr %t154
  store %"compiler/source:Span" %t155, ptr %l16
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t157 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t157, ptr %l79, !tbaa !27
  %t158 = load ptr, ptr %l4, !tbaa !29
  %t159 = load i64, ptr %l15, !tbaa !24
  %t160 = load %"compiler/source:Span", ptr %l16
  %t164 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t158, i64 %t159, %"compiler/source:Span" %t160)
  store { i64, ptr } %t164, ptr %l83
  br label %bb25
bb25:
  %t165 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = add i64 %t170, %t173
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t177 = add i64 %t174, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t166, i64 %t167)
  %t179 = getelementptr i8, ptr %t178, i64 %t167
  call void @olang_textcopy(ptr %t179, ptr %t168, i64 %t169)
  %t180 = getelementptr i8, ptr %t179, i64 %t169
  call void @olang_textcopy(ptr %t180, ptr %t172, i64 %t173)
  %t181 = getelementptr i8, ptr %t180, i64 %t173
  call void @olang_textcopy(ptr %t181, ptr %t175, i64 %t176)
  %t182 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t178, 1
  %t184 = load { i64, [3 x i64] }, ptr %l9
  %t185 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 0, 0
  %t186 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t185, i1 false, 1
  %t188 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t186, { i64, ptr } %t183, 2
  %t190 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t188, { i64, [3 x i64] } %t184, 3
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t190, ptr %rv
  br label %ret
bb26:
  %t192 = load { i64, [5 x i64] }, ptr %l13
  %t194 = extractvalue { i64, [5 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 2
  br i1 %t195, label %bb27, label %bb28
bb27:
  %t197 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t198 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t197, i32 0, i32 0
  %t199 = load i32, ptr %t198
  store i32 %t199, ptr %l17
  %t201 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t202 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t201, i32 0, i32 1
  %t203 = load i64, ptr %t202
  store i64 %t203, ptr %l18, !tbaa !24
  %t205 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t206 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t205, i32 0, i32 2
  %t207 = load %"compiler/source:Span", ptr %t206
  store %"compiler/source:Span" %t207, ptr %l19
  br label %bb29
bb28:
  br label %bb32
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t209 = load i32, ptr %l17
  %t211 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s6, i32 %t209)
  store { i64, ptr } %t211, ptr %l93
  br label %bb30
bb30:
  %t212 = load ptr, ptr %l4, !tbaa !29
  %t213 = load i64, ptr %l18, !tbaa !24
  %t214 = load %"compiler/source:Span", ptr %l19
  %t218 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s6, ptr %t212, i64 %t213, %"compiler/source:Span" %t214)
  store { i64, ptr } %t218, ptr %l97
  br label %bb31
bb31:
  %t219 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t220, i64 %t221)
  %t233 = getelementptr i8, ptr %t232, i64 %t221
  call void @olang_textcopy(ptr %t233, ptr %t222, i64 %t223)
  %t234 = getelementptr i8, ptr %t233, i64 %t223
  call void @olang_textcopy(ptr %t234, ptr %t226, i64 %t227)
  %t235 = getelementptr i8, ptr %t234, i64 %t227
  call void @olang_textcopy(ptr %t235, ptr %t229, i64 %t230)
  %t236 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t232, 1
  %t238 = load { i64, [3 x i64] }, ptr %l9
  %t239 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 0, 0
  %t240 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t239, i1 false, 1
  %t242 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t240, { i64, ptr } %t237, 2
  %t244 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t242, { i64, [3 x i64] } %t238, 3
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t244, ptr %rv
  br label %ret
bb32:
  %t246 = load { i64, [5 x i64] }, ptr %l13
  %t248 = extractvalue { i64, [5 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 1
  br i1 %t249, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t252 = load { i64, [3 x i64] }, ptr %l9
  %t253 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 0, 0
  %t254 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t253, i1 false, 1
  %t256 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t254, { i64, ptr } %t251, 2
  %t258 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t256, { i64, [3 x i64] } %t252, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t258, ptr %l106
  %t259 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l106, i32 0, i32 2
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  store { i64, ptr } %t260, ptr %l107, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  store i64 %t262, ptr %l108, !tbaa !24
  %t263 = load i64, ptr %l108, !tbaa !24
  %t264 = mul i64 %t263, 1
  %t265 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t264)
  %t266 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  store { i64, ptr } %t267, ptr %l109, !tbaa !27
  %t268 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = load i64, ptr %l108, !tbaa !24
  %t273 = mul i64 %t272, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t269, ptr %t271, i64 %t273, i1 false)
  %t274 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t275 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l106, i32 0, i32 2
  store { i64, ptr } %t274, ptr %t275, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t276 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l106
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t276, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_b7cf027bc3b091ec_6e850e1bd8f0ff28)
  unreachable
bb37:
  %t277 = load i1, ptr %l12, !tbaa !21
  br i1 %t277, label %bb38, label %bb39
bb38:
  %t279 = load i64, ptr %l6, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l112, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t281 = load { i64, [3 x i64] }, ptr %l9
  %t283 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 %t279, 0
  %t284 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t283, i1 true, 1
  %t286 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t284, { i64, ptr } %t280, 2
  %t288 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t286, { i64, [3 x i64] } %t281, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t288, ptr %l115
  %t289 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l115, i32 0, i32 2
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, ptr } %t290, ptr %l116, !tbaa !27
  %t291 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 0
  store i64 %t292, ptr %l117, !tbaa !24
  %t293 = load i64, ptr %l117, !tbaa !24
  %t294 = mul i64 %t293, 1
  %t295 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t294)
  %t296 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  store { i64, ptr } %t297, ptr %l118, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = load i64, ptr %l117, !tbaa !24
  %t303 = mul i64 %t302, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t299, ptr %t301, i64 %t303, i1 false)
  %t304 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t305 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l115, i32 0, i32 2
  store { i64, ptr } %t304, ptr %t305, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t306 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l115
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t306, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t307 = load i64, ptr %l6, !tbaa !24
  %t309 = add i64 %t307, 1
  store i64 %t309, ptr %l6, !tbaa !24
  %t311 = load ptr, ptr %l7, !tbaa !29
  %t313 = getelementptr %"compiler/ast:TopIf", ptr %t311, i32 0, i32 2
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = icmp eq ptr %t314, null
  br i1 %t316, label %bb41, label %bb42
bb41:
  %t318 = load ptr, ptr %l7, !tbaa !29
  %t320 = getelementptr %"compiler/ast:TopIf", ptr %t318, i32 0, i32 3
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = icmp eq ptr %t321, null
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb43, label %bb44
bb42:
  br label %bb46
bb43:
  %t327 = load i64, ptr %l6, !tbaa !24
  store i64 %t327, ptr %l128, !tbaa !24
  br label %bb45
bb44:
  %t329 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store i64 %t329, ptr %l128, !tbaa !24
  br label %bb45
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l131, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t332 = load { i64, [3 x i64] }, ptr %l9
  %t333 = load i64, ptr %l128, !tbaa !24
  %t334 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 %t333, 0
  %t335 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t334, i1 true, 1
  %t337 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t335, { i64, ptr } %t331, 2
  %t339 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t337, { i64, [3 x i64] } %t332, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t339, ptr %l134
  %t340 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l134, i32 0, i32 2
  %t341 = load { i64, ptr }, ptr %t340, !tbaa !27
  store { i64, ptr } %t341, ptr %l135, !tbaa !27
  %t342 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 0
  store i64 %t343, ptr %l136, !tbaa !24
  %t344 = load i64, ptr %l136, !tbaa !24
  %t345 = mul i64 %t344, 1
  %t346 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t345)
  %t347 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  store { i64, ptr } %t348, ptr %l137, !tbaa !27
  %t349 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = load i64, ptr %l136, !tbaa !24
  %t354 = mul i64 %t353, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t350, ptr %t352, i64 %t354, i1 false)
  %t355 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t356 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l134, i32 0, i32 2
  store { i64, ptr } %t355, ptr %t356, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t357 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l134
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t357, ptr %rv
  br label %ret
bb46:
  %t358 = load ptr, ptr %l7, !tbaa !29
  %t360 = getelementptr %"compiler/ast:TopIf", ptr %t358, i32 0, i32 2
  %t361 = load ptr, ptr %t360, !tbaa !29
  store ptr %t361, ptr %l7, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  br label %bb47
bb47:
  br label %bb2
bb48:
  %t363 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l141, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t365 = load i64, ptr %l5, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t366
  %t367 = getelementptr { i64, [3 x i64] }, ptr %t366, i32 0, i32 0
  store i64 3, ptr %t367
  %t369 = insertvalue { i64, i64, i64 } undef, i64 %t365, 0
  %t370 = insertvalue { i64, i64, i64 } %t369, i64 0, 1
  %t371 = insertvalue { i64, i64, i64 } %t370, i64 0, 2
  %t372 = getelementptr { i64, [3 x i64] }, ptr %t366, i32 0, i32 1
  store { i64, i64, i64 } %t371, ptr %t372
  %t373 = load { i64, [3 x i64] }, ptr %t366
  %t375 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 %t363, 0
  %t376 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t375, i1 true, 1
  %t378 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t376, { i64, ptr } %t364, 2
  %t380 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t378, { i64, [3 x i64] } %t373, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t380, ptr %l145
  %t381 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l145, i32 0, i32 2
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  store { i64, ptr } %t382, ptr %l146, !tbaa !27
  %t383 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 0
  store i64 %t384, ptr %l147, !tbaa !24
  %t385 = load i64, ptr %l147, !tbaa !24
  %t386 = mul i64 %t385, 1
  %t387 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t386)
  %t388 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  store { i64, ptr } %t389, ptr %l148, !tbaa !27
  %t390 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = load i64, ptr %l147, !tbaa !24
  %t395 = mul i64 %t394, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t391, ptr %t393, i64 %t395, i1 false)
  %t396 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t397 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l145, i32 0, i32 2
  store { i64, ptr } %t396, ptr %t397, !tbaa !27
  %t398 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l145
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t398, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %rv
  ret { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %rr
}

define dso_local { i1, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l11 = alloca ptr
  %l12 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [5 x i64] }
  %l26 = alloca i64
  %rv = alloca { i1, i1 }
  %t5 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a1 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t10, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 4
  store ptr %t18, ptr %l11, !tbaa !29
  %t19 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t19, ptr %l12
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_d3dcaf488556181a_337076a643e912ae)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = load ptr, ptr %l11, !tbaa !29
  %t29 = load { i64, [2 x i64] }, ptr %l12
  %t31 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t28, { i64, [2 x i64] } %t29, { i64, ptr } %t27)
  store { i64, [5 x i64] } %t31, ptr %l16
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d3dcaf488556181a_337076a643e912ae)
  unreachable
bb6:
  %t32 = load { i64, [5 x i64] }, ptr %l16
  %t35 = extractvalue { i64, [5 x i64] } %t32, 0
  %t36 = icmp eq i64 %t35, 0
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = insertvalue { i1, i1 } undef, i1 false, 0
  %t41 = insertvalue { i1, i1 } %t40, i1 false, 1
  store { i1, i1 } %t41, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/interp:Exec", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/interp:Exec", ptr %t46, i32 0, i32 4
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 10
  %t50 = load %"compiler/eval:Ptr", ptr %t49
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t55 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t45, %"compiler/eval:Ptr" %t50, i32 %t51)
  store i64 %t55, ptr %l26
  br label %bb10
bb10:
  %t56 = load i64, ptr %l26, !tbaa !24
  %t57 = icmp ne i64 %t56, 0
  %t59 = insertvalue { i1, i1 } undef, i1 %t57, 0
  %t60 = insertvalue { i1, i1 } %t59, i1 true, 1
  store { i1, i1 } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i1, i1 }, ptr %rv
  ret { i1, i1 } %rr
}

define dso_local { i1, { i64, [5 x i64] } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCondStop(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %lp3 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [5 x i64] }
  %l27 = alloca i64
  %rv = alloca { i1, { i64, [5 x i64] } }
  %t5 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a1 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t10, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 4
  store ptr %t18, ptr %l11, !tbaa !29
  %t19 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t19, ptr %l12
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_e80992fd1d33d452_12ec5773a31f7726)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = load ptr, ptr %l11, !tbaa !29
  %t29 = load { i64, [2 x i64] }, ptr %l12
  %t31 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v1, ptr %t28, { i64, [2 x i64] } %t29, { i64, ptr } %t27)
  store { i64, [5 x i64] } %t31, ptr %l16
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_e80992fd1d33d452_12ec5773a31f7726)
  unreachable
bb6:
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t32, ptr %lp3
  %t33 = load { i64, [5 x i64] }, ptr %l16
  %t34 = load ptr, ptr %lp3
  store { i64, [5 x i64] } %t33, ptr %t34
  %t35 = load ptr, ptr %lp3
  %t36 = load { i64, [5 x i64] }, ptr %t35
  %t38 = extractvalue { i64, [5 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 0
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load ptr, ptr %lp3
  %t44 = load { i64, [5 x i64] }, ptr %t43
  %t45 = insertvalue { i1, { i64, [5 x i64] } } undef, i1 false, 0
  %t47 = insertvalue { i1, { i64, [5 x i64] } } %t45, { i64, [5 x i64] } %t44, 1
  store { i1, { i64, [5 x i64] } } %t47, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/interp:Exec", ptr %t49, i32 0, i32 4
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/interp:Exec", ptr %t52, i32 0, i32 4
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 10
  %t56 = load %"compiler/eval:Ptr", ptr %t55
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t61 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t51, %"compiler/eval:Ptr" %t56, i32 %t57)
  store i64 %t61, ptr %l27
  br label %bb10
bb10:
  %t62 = load i64, ptr %l27, !tbaa !24
  %t63 = icmp ne i64 %t62, 0
  %t64 = load ptr, ptr %lp3
  %t65 = load { i64, [5 x i64] }, ptr %t64
  %t67 = insertvalue { i1, { i64, [5 x i64] } } undef, i1 %t63, 0
  %t69 = insertvalue { i1, { i64, [5 x i64] } } %t67, { i64, [5 x i64] } %t65, 1
  store { i1, { i64, [5 x i64] } } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i1, { i64, [5 x i64] } }, ptr %rv
  ret { i1, { i64, [5 x i64] } } %rr
}

define dso_local { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca ptr
  %l54 = alloca ptr
  %l66 = alloca i64
  %l69 = alloca i64
  %l74 = alloca i1
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l83 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store i64 -1, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/interp:Exec", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/interp:Exec", ptr %t10, i32 0, i32 1
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l18
  br label %bb2
bb2:
  %t15 = load i64, ptr %l18, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l22, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb44
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/interp:Exec", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %l9, !tbaa !24
  %t68 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t64, i64 %t65)
  store ptr %t68, ptr %l46
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l46, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 1
  %t72 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t72, ptr %l10
  %t74 = load { i64, [2 x i64] }, ptr %l10
  %t76 = extractvalue { i64, [2 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 5
  br i1 %t77, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/interp:Exec", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l54
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l54, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Body", ptr %t86, i32 0, i32 11
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t95 = load ptr, ptr %lp1
  %t96 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t95, i64 %t96)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb42
bb22:
  %t99 = load { i64, [2 x i64] }, ptr %l10
  %t101 = extractvalue { i64, [2 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 0
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t104 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t105 = getelementptr { i64 }, ptr %t104, i32 0, i32 0
  %t106 = load i64, ptr %t105
  store i64 %t106, ptr %l11, !tbaa !24
  br label %bb25
bb24:
  br label %bb37
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t108, i64 %t109)
  store i64 %t112, ptr %l66
  br label %bb26
bb26:
  %t113 = load i64, ptr %l66, !tbaa !24
  store i64 %t113, ptr %l12, !tbaa !24
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t114, i64 %t115)
  store i64 %t118, ptr %l69
  br label %bb27
bb27:
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 0
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/load:Loader", ptr %t122, i32 0, i32 7
  %t125 = load i64, ptr %t124, !tbaa !24
  %t126 = load i64, ptr %l69, !tbaa !24
  %t128 = icmp eq i64 %t126, %t125
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = getelementptr %"compiler/types:Table", ptr %t132, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l76, !tbaa !29
  %t135 = load ptr, ptr %l3, !tbaa !29
  %t136 = load i64, ptr %l12, !tbaa !24
  %t139 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t135, i64 %t136)
  store ptr %t139, ptr %l79
  br label %bb30
bb29:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb33
bb30:
  %t140 = load ptr, ptr %l79, !tbaa !29
  %t142 = getelementptr %"compiler/ast:Func", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %t142, !tbaa !23
  %t144 = load ptr, ptr %l76, !tbaa !29
  %t146 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t144, i32 %t143)
  store { i64, ptr } %t146, ptr %l82
  br label %bb31
bb31:
  %t147 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t147, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t148, ptr %l83
  br label %bb32
bb32:
  %t149 = load i1, ptr %l83, !tbaa !21
  store i1 %t149, ptr %l74, !tbaa !21
  br label %bb33
bb33:
  %t150 = load i1, ptr %l74, !tbaa !21
  br i1 %t150, label %bb34, label %bb35
bb34:
  %t151 = load i64, ptr %l9, !tbaa !24
  store i64 %t151, ptr %l2, !tbaa !24
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_5b75817b97c7703f_a9caa4d803bddbab)
  unreachable
bb42:
  br label %bb43
bb43:
  %t153 = load i64, ptr %l8, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l8, !tbaa !24
  br label %bb9
bb44:
  %t157 = load ptr, ptr %lp1
  %t158 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t157
  %t159 = load i64, ptr %l2, !tbaa !24
  %t161 = insertvalue { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } undef, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, 0
  %t163 = insertvalue { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t161, i64 %t159, 1
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t163, ptr %rv
  br label %ret
ret:
  %rr = load { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %rv
  ret { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %rr
}

define dso_local { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, [5 x i64] }
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l35 = alloca { i64, [5 x i64] }
  %l39 = alloca i1
  %rv = alloca { i64, [5 x i64] }
  %t3 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store { i64, [5 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load { i64, [5 x i64] }, ptr %t3
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t6, ptr %lp1
  %t8 = load ptr, ptr %lp1
  store { i64, [5 x i64] } %t5, ptr %t8
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/interp:Exec", ptr %t9, i32 0, i32 9
  store ptr %t11, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l13, !tbaa !24
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l15
  br label %bb3
bb3:
  %t17 = load i64, ptr %l13, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb26
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l20
  br label %bb7
bb7:
  %t28 = load i64, ptr %l20, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/interp:Exec", ptr %t29, i32 0, i32 1
  %t35 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t31, i64 %t28)
  store ptr %t35, ptr %l24
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 1
  %t39 = load { i64, [2 x i64] }, ptr %t38
  store { i64, [2 x i64] } %t39, ptr %l5
  %t41 = load { i64, [2 x i64] }, ptr %l5
  %t43 = extractvalue { i64, [2 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 6
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t47 = getelementptr { i64, i32 }, ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47
  store i64 %t48, ptr %l6, !tbaa !24
  %t50 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t51 = getelementptr { i64, i32 }, ptr %t50, i32 0, i32 1
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l7, !tbaa !23
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 4
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load i32, ptr %l7, !tbaa !23
  %t62 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v0, ptr %t56, i64 %t57, i32 %t58)
  store { i64, [5 x i64] } %t62, ptr %l35
  br label %bb12
bb12:
  %t63 = load { i64, [5 x i64] }, ptr %l35
  store { i64, [5 x i64] } %t63, ptr %l8
  %t64 = load { i64, [5 x i64] }, ptr %l8
  %t66 = extractvalue { i64, [5 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 0
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load ptr, ptr %lp1
  %t72 = load { i64, [5 x i64] }, ptr %t71
  %t74 = extractvalue { i64, [5 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 0
  store i1 %t75, ptr %l39, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l39, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t78 = load { i64, [5 x i64] }, ptr %l8
  %t80 = load ptr, ptr %lp1
  store { i64, [5 x i64] } %t78, ptr %t80
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fce8d31b7e62f371_71870e12b086bddd)
  unreachable
bb24:
  br label %bb25
bb25:
  %t81 = load i64, ptr %l3, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l3, !tbaa !24
  br label %bb2
bb26:
  %t85 = load ptr, ptr %lp1
  %t86 = load { i64, [5 x i64] }, ptr %t85
  store { i64, [5 x i64] } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { i64, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInt(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l12 = alloca ptr
  %l13 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, [5 x i64] }
  %l27 = alloca i64
  %rv = alloca { i64, i1 }
  %t5 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a1 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t10, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 4
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t19, ptr %l13
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6d054a657ae82b6f_99a66fec87b1ac03)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = load ptr, ptr %l12, !tbaa !29
  %t29 = load { i64, [2 x i64] }, ptr %l13
  %t31 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t28, { i64, [2 x i64] } %t29, { i64, ptr } %t27)
  store { i64, [5 x i64] } %t31, ptr %l17
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6d054a657ae82b6f_99a66fec87b1ac03)
  unreachable
bb6:
  %t32 = load { i64, [5 x i64] }, ptr %l17
  %t35 = extractvalue { i64, [5 x i64] } %t32, 0
  %t36 = icmp eq i64 %t35, 0
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = insertvalue { i64, i1 } undef, i64 0, 0
  %t41 = insertvalue { i64, i1 } %t40, i1 false, 1
  store { i64, i1 } %t41, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/interp:Exec", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/interp:Exec", ptr %t46, i32 0, i32 4
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 10
  %t50 = load %"compiler/eval:Ptr", ptr %t49
  %t55 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t45, %"compiler/eval:Ptr" %t50, i32 %a2)
  store i64 %t55, ptr %l27
  br label %bb10
bb10:
  %t56 = load i64, ptr %l27, !tbaa !24
  %t57 = insertvalue { i64, i1 } undef, i64 %t56, 0
  %t58 = insertvalue { i64, i1 } %t57, i1 true, 1
  store { i64, i1 } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i1 }, ptr %rv
  ret { i64, i1 } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca %"compiler/mir:Fn"
  %l6 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, [2 x i64] }
  %l18 = alloca i32
  %l22 = alloca i1
  %l36 = alloca i1
  %l43 = alloca %"compiler/mir:Fn"
  %l56 = alloca i1
  %s0 = alloca %olang.scope
  %t74 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l8
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2, { i64, [2 x i64] } %a1)
  br label %bb3
bb3:
  br label %bb4
bb4:
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2)
  store i64 %t9, ptr %l12
  br label %bb5
bb5:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb57
bb7:
  br label %bb8
bb8:
  %t16 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePop_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2)
  %t17 = extractvalue { i32, { i64, [2 x i64] } } %t16, 1
  %t18 = extractvalue { i32, { i64, [2 x i64] } } %t16, 0
  store i32 %t18, ptr %l18
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb10, label %ok.20
ok.20:
  store { i64, [2 x i64] } %t17, ptr %l17
  br label %bb9
bb9:
  %t21 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t21, ptr %l15
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  br label %bb57
bb12:
  %t22 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t22, ptr %l3
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/interp:Exec", ptr %t23, i32 0, i32 6
  %t26 = load { i64, [2 x i64] }, ptr %l3
  %t29 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t25, { i64, [2 x i64] } %t26)
  store i1 %t29, ptr %l22
  br label %bb13
bb13:
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb14, label %bb15
bb14:
  br label %bb56
bb15:
  br label %bb16
bb16:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/interp:Exec", ptr %t31, i32 0, i32 6
  %t34 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t33, { i64, [2 x i64] } %t34, i1 true)
  br label %bb17
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/interp:Exec", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %t39
  %t42 = trunc i64 0 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb18, label %bb19
bb18:
  %t45 = load { i64, [2 x i64] }, ptr %l3
  %t47 = extractvalue { i64, [2 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 0
  br i1 %t48, label %bb20, label %bb21
bb19:
  br label %bb34
bb20:
  %t50 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t51 = getelementptr { i32 }, ptr %t50, i32 0, i32 0
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l4, !tbaa !23
  br label %bb22
bb21:
  br label %bb28
bb22:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 10
  %t57 = load i32, ptr %l4, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t62 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t56, i64 %t59)
  store i1 %t62, ptr %l36
  br label %bb23
bb23:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb24, label %bb25
bb24:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/interp:Exec", ptr %t64, i32 0, i32 5
  %t67 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t66, { i64, [2 x i64] } %t67)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb56
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_26fab0deca850fb9_a904bdf0227cd14d)
  unreachable
bb33:
  br label %bb34
bb34:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/interp:Exec", ptr %t70, i32 0, i32 3
  %t73 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t74, ptr %v0, ptr %v0, ptr %t72, { i64, [2 x i64] } %t73)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t74, i64 232, i1 false)
  br label %bb35
bb35:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l43, i64 232, i1 false)
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/interp:Exec", ptr %t77, i32 0, i32 3
  %t80 = getelementptr %"compiler/lower:Lowerer", ptr %t79, i32 0, i32 5
  %t81 = load i1, ptr %t80, !tbaa !21
  br i1 %t81, label %bb36, label %bb37
bb36:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/interp:Exec", ptr %t83, i32 0, i32 5
  %t86 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t85, { i64, [2 x i64] } %t86)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb56
bb39:
  %t89 = load { i64, [2 x i64] }, ptr %l3
  %t91 = extractvalue { i64, [2 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 0
  br i1 %t92, label %bb40, label %bb41
bb40:
  %t94 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t95 = getelementptr { i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l6, !tbaa !23
  br label %bb42
bb41:
  br label %bb48
bb42:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/interp:Exec", ptr %t98, i32 0, i32 11
  %t101 = load i32, ptr %l6, !tbaa !23
  %t103 = sext i32 %t101 to i64
  %t106 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t100, i64 %t103)
  store i1 %t106, ptr %l56
  br label %bb43
bb43:
  %t107 = load i1, ptr %l56, !tbaa !21
  br i1 %t107, label %bb44, label %bb45
bb44:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/interp:Exec", ptr %t108, i32 0, i32 4
  %t111 = getelementptr %"compiler/eval:Machine", ptr %t110, i32 0, i32 15
  %t112 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t111, { i64, [2 x i64] } %t112, i1 true)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_f78c9384d4051fe8_f87279dcad65e91c)
  unreachable
bb53:
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ereach(ptr %v0, ptr %v0, ptr %s0, ptr %t115, ptr %l5, ptr %l2)
  br label %bb54
bb54:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/interp:Exec", ptr %t119, i32 0, i32 4
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v0, ptr %t121, ptr %l5)
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb4
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca { i64, [5 x i64] }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, %"compiler/source:Span" }
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l24 = alloca { i64, [5 x i64] }
  %l28 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %l33 = alloca { i64, [5 x i64] }
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l63 = alloca i1
  %l66 = alloca { i64, %"compiler/source:Span" }
  %l74 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  %t17 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %s0, ptr %t1)
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l12
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t4, ptr %l2
  %t5 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l2, i32 0, i32 1
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @compiler_2finterp_2esayErr(ptr %s1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb5:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = trunc i64 %t13 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [2 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t20 = insertvalue { i32 } undef, i32 %t15, 0
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t17, i32 0, i32 1
  store { i32 } %t20, ptr %t21
  %t22 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t22, ptr %l4
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, [2 x i64] }, ptr %l4
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t24, { i64, [2 x i64] } %t25)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %s0, ptr %t28)
  store { i64, [5 x i64] } %t30, ptr %l24
  br label %bb7
bb7:
  %t31 = load { i64, [5 x i64] }, ptr %l24
  store { i64, [5 x i64] } %t31, ptr %l5
  %t32 = load { i64, [5 x i64] }, ptr %l5
  %t34 = extractvalue { i64, [5 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/interp:Exec", ptr %t37, i32 0, i32 4
  store ptr %t39, ptr %l28, !tbaa !29
  %t40 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t40, ptr %l29
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb10, label %bb11
bb9:
  br label %bb15
bb10:
  %t43 = icmp sle i64 0, 1152921504606846975
  br i1 %t43, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c21b7649f9083df0_c859438e5e055394)
  unreachable
bb12:
  %t45 = mul i64 0, 8
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 0, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load { i64, [2 x i64] }, ptr %l29
  %t52 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %s0, ptr %t49, { i64, [2 x i64] } %t50, { i64, ptr } %t48)
  store { i64, [5 x i64] } %t52, ptr %l33
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c21b7649f9083df0_c859438e5e055394)
  unreachable
bb14:
  %t53 = load { i64, [5 x i64] }, ptr %l33
  store { i64, [5 x i64] } %t53, ptr %l5
  br label %bb15
bb15:
  %t54 = load { i64, [5 x i64] }, ptr %l5
  %t56 = extractvalue { i64, [5 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 0
  br i1 %t57, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb19:
  %t60 = load { i64, [5 x i64] }, ptr %l5
  %t62 = extractvalue { i64, [5 x i64] } %t60, 0
  %t63 = icmp eq i64 %t62, 1
  br i1 %t63, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb27
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, [5 x i64] }, ptr %l5
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t73 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s4, ptr %t65, { i64, [5 x i64] } %t66, i64 %t67, ptr %t68)
  store { i64, ptr } %t73, ptr %l43
  br label %bb23
bb23:
  %t74 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t75, i64 %t76)
  %t81 = getelementptr i8, ptr %t80, i64 %t76
  call void @olang_textcopy(ptr %t81, ptr %t77, i64 %t78)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  call void @compiler_2finterp_2esayErr(ptr %s4, { i64, ptr } %t90)
  br label %bb24
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t96 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %s4, ptr %t92, ptr %t93)
  store { i64, ptr } %t96, ptr %l48
  br label %bb25
bb25:
  %t97 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  call void @compiler_2finterp_2esayErr(ptr %s4, { i64, ptr } %t103)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb27:
  %t106 = load { i64, [5 x i64] }, ptr %l5
  %t108 = extractvalue { i64, [5 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 3
  br i1 %t109, label %bb28, label %bb29
bb28:
  %t111 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t112 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t111, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112
  store { i64, ptr } %t113, ptr %l6, !tbaa !27
  br label %bb30
bb29:
  br label %bb43
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load { i64, [5 x i64] }, ptr %l5
  %t117 = load i64, ptr %l3, !tbaa !24
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t123 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s6, ptr %t115, { i64, [5 x i64] } %t116, i64 %t117, ptr %t118)
  store { i64, ptr } %t123, ptr %l58
  br label %bb31
bb31:
  %t124 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t126 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = add i64 %t125, %t128
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t124, i64 %t125)
  %t134 = getelementptr i8, ptr %t133, i64 %t125
  call void @olang_textcopy(ptr %t134, ptr %t127, i64 %t128)
  %t135 = getelementptr i8, ptr %t134, i64 %t128
  call void @olang_textcopy(ptr %t135, ptr %t130, i64 %t131)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t133, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = extractvalue { i64, ptr } %t137, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  call void @compiler_2finterp_2esayErr(ptr %s6, { i64, ptr } %t144)
  br label %bb32
bb32:
  %t146 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t147 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t148 = load ptr, ptr @__olang_prog_scope
  %t151 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %t148, { i64, ptr } %t146, { i64, ptr } %t147)
  store i1 %t151, ptr %l63
  br label %bb33
bb33:
  %t152 = load i1, ptr %l63, !tbaa !21
  br i1 %t152, label %bb34, label %bb35
bb34:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/interp:Exec", ptr %t153, i32 0, i32 4
  %t157 = call { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %t155)
  store { i64, %"compiler/source:Span" } %t157, ptr %l66
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t158 = load { i64, %"compiler/source:Span" }, ptr %l66
  store { i64, %"compiler/source:Span" } %t158, ptr %l7
  %t159 = getelementptr { i64, %"compiler/source:Span" }, ptr %l7, i32 0, i32 0
  %t160 = load i64, ptr %t159, !tbaa !24
  store i64 %t160, ptr %l8, !tbaa !24
  %t162 = getelementptr { i64, %"compiler/source:Span" }, ptr %l7, i32 0, i32 1
  %t163 = load %"compiler/source:Span", ptr %t162
  store %"compiler/source:Span" %t163, ptr %l9
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = icmp sge i64 %t165, 0
  br i1 %t167, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t170 = load i64, ptr %l8, !tbaa !24
  %t171 = load %"compiler/source:Span", ptr %l9
  %t175 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s9, ptr %t169, i64 %t170, %"compiler/source:Span" %t171)
  store { i64, ptr } %t175, ptr %l74
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t176 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t178 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = add i64 %t177, %t180
  %t182 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t184 = add i64 %t181, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t176, i64 %t177)
  %t186 = getelementptr i8, ptr %t185, i64 %t177
  call void @olang_textcopy(ptr %t186, ptr %t179, i64 %t180)
  %t187 = getelementptr i8, ptr %t186, i64 %t180
  call void @olang_textcopy(ptr %t187, ptr %t182, i64 %t183)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t185, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } %t189, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  call void @compiler_2finterp_2esayErr(ptr %s9, { i64, ptr } %t196)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb43:
  %t199 = load { i64, [5 x i64] }, ptr %l5
  %t201 = extractvalue { i64, [5 x i64] } %t199, 0
  %t202 = icmp eq i64 %t201, 2
  br i1 %t202, label %bb44, label %bb45
bb44:
  %t204 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t205 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t204, i32 0, i32 0
  %t206 = load i32, ptr %t205
  store i32 %t206, ptr %l10
  br label %bb46
bb45:
  br label %bb54
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load { i64, [5 x i64] }, ptr %l5
  %t210 = load i64, ptr %l3, !tbaa !24
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t216 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s11, ptr %t208, { i64, [5 x i64] } %t209, i64 %t210, ptr %t211)
  store { i64, ptr } %t216, ptr %l85
  br label %bb47
bb47:
  %t217 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t222 = add i64 %t219, %t221
  %t223 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t222)
  call void @olang_textcopy(ptr %t223, ptr %t218, i64 %t219)
  %t224 = getelementptr i8, ptr %t223, i64 %t219
  call void @olang_textcopy(ptr %t224, ptr %t220, i64 %t221)
  %t225 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t223, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  call void @compiler_2finterp_2esayErr(ptr %s11, { i64, ptr } %t233)
  br label %bb48
bb48:
  %t235 = load i32, ptr %l10
  %t237 = trunc i64 12 to i32
  %t238 = icmp eq i32 %t235, %t237
  br i1 %t238, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s13
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t244 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %s13, ptr %t240, ptr %t241)
  store { i64, ptr } %t244, ptr %l92
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t245 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  call void @compiler_2finterp_2esayErr(ptr %s13, { i64, ptr } %t251)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s13)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 134, ptr %rv
  br label %ret
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb60
bb57:
  store %olang.scope zeroinitializer, ptr %s14
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load { i64, [5 x i64] }, ptr %l5
  %t256 = load i64, ptr %l3, !tbaa !24
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t262 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s14, ptr %t254, { i64, [5 x i64] } %t255, i64 %t256, ptr %t257)
  store { i64, ptr } %t262, ptr %l99
  br label %bb58
bb58:
  %t263 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t268 = add i64 %t265, %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t264, i64 %t265)
  %t270 = getelementptr i8, ptr %t269, i64 %t265
  call void @olang_textcopy(ptr %t270, ptr %t266, i64 %t267)
  %t271 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t269, 1
  %t274 = extractvalue { i64, ptr } %t272, 0
  %t275 = extractvalue { i64, ptr } %t272, 1
  %t276 = mul i64 %t274, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  call void @compiler_2finterp_2esayErr(ptr %s14, { i64, ptr } %t279)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  store i32 134, ptr %rv
  br label %ret
bb60:
  call void @__olang_check_failed(ptr @olang_loc_736b533d144489ee_c645810c81b1a7fa)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunTests(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca [0 x i64]
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, [5 x i64] }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l36 = alloca { i64, [5 x i64] }
  %l39 = alloca i64
  %l41 = alloca i64
  %l46 = alloca i64
  %l49 = alloca { i64, ptr }
  %l58 = alloca { i64, [5 x i64] }
  %l72 = alloca { i64, ptr }
  %l74 = alloca i1
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  %t30 = alloca { i64, [2 x i64] }, align 8
  %t76 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %s0, ptr %t1)
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l17
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t4, ptr %l2
  %t5 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l2, i32 0, i32 0
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t5
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %l20, !tbaa !24
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t10)
  store i64 %t12, ptr %l22
  br label %bb3
bb3:
  %t13 = load i64, ptr %l20, !tbaa !24
  %t14 = load i64, ptr %l22, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l27
  br label %bb7
bb7:
  %t24 = load i64, ptr %l27, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = trunc i64 %t24 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 0
  store i64 0, ptr %t31
  %t33 = insertvalue { i32 } undef, i32 %t28, 0
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 1
  store { i32 } %t33, ptr %t34
  %t35 = load { i64, [2 x i64] }, ptr %t30
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t25, { i64, [2 x i64] } %t35)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l5, !tbaa !24
  br label %bb2
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %s0, ptr %t42)
  store { i64, [5 x i64] } %t44, ptr %l36
  br label %bb11
bb11:
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  store [0 x i64] zeroinitializer, ptr %l9
  store ptr %l3, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l11, !tbaa !24
  store i64 %t47, ptr %l39, !tbaa !24
  %t48 = load ptr, ptr %l10, !tbaa !29
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t48)
  store i64 %t50, ptr %l41
  br label %bb13
bb13:
  %t51 = load i64, ptr %l39, !tbaa !24
  %t52 = load i64, ptr %l41, !tbaa !24
  %t53 = icmp slt i64 %t51, %t52
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l10, !tbaa !29
  %t58 = load i64, ptr %l11, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l46
  br label %bb17
bb17:
  %t62 = load i64, ptr %l46, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i64, ptr %l12, !tbaa !24
  %t67 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTestName(ptr %v0, ptr %s5, ptr %t63, i64 %t64)
  store { i64, ptr } %t67, ptr %l49
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t68, ptr %l13, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t69, i32 0, i32 4
  %t72 = load i64, ptr %l12, !tbaa !24
  %t74 = trunc i64 %t72 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t76, i32 0, i32 0
  store i64 0, ptr %t77
  %t79 = insertvalue { i32 } undef, i32 %t74, 0
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t76, i32 0, i32 1
  store { i32 } %t79, ptr %t80
  %t81 = load { i64, [2 x i64] }, ptr %t76
  %t83 = insertvalue { i64, ptr } undef, i64 0, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %l9, 1
  %t88 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %v0, ptr %t71, { i64, [2 x i64] } %t81, { i64, ptr } %t84)
  store { i64, [5 x i64] } %t88, ptr %l58
  br label %bb19
bb19:
  %t89 = load { i64, [5 x i64] }, ptr %l58
  store { i64, [5 x i64] } %t89, ptr %l14
  %t90 = load { i64, [5 x i64] }, ptr %l14
  %t92 = extractvalue { i64, [5 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t100 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t103 = extractvalue { i64, ptr } %t99, 1
  %t104 = extractvalue { i64, ptr } %t99, 0
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t100, i64 %t101)
  %t110 = getelementptr i8, ptr %t109, i64 %t101
  call void @olang_textcopy(ptr %t110, ptr %t103, i64 %t104)
  %t111 = getelementptr i8, ptr %t110, i64 %t104
  call void @olang_textcopy(ptr %t111, ptr %t106, i64 %t107)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t109, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } %t113, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  call void @compiler_2finterp_2esay(ptr %s6, { i64, ptr } %t120)
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l8, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, [5 x i64] }, ptr %l14
  %t128 = load i64, ptr %l12, !tbaa !24
  %t134 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %v0, ptr %v1, ptr %s8, ptr %t126, { i64, [5 x i64] } %t127, i64 %t128, ptr %a1)
  store { i64, ptr } %t134, ptr %l72
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb23:
  %t135 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t135, ptr %l15, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s8, { i64, ptr } %t136, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t138, ptr %l74
  br label %bb24
bb24:
  %t139 = load i1, ptr %l74, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t142 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t144, i64 %t145)
  %t150 = getelementptr i8, ptr %t149, i64 %t145
  call void @olang_textcopy(ptr %t150, ptr %t146, i64 %t147)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t149, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  call void @compiler_2finterp_2esay(ptr %s9, { i64, ptr } %t159)
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  %t161 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t162 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t165 = extractvalue { i64, ptr } %t161, 1
  %t166 = extractvalue { i64, ptr } %t161, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t162, i64 %t163)
  %t172 = getelementptr i8, ptr %t171, i64 %t163
  call void @olang_textcopy(ptr %t172, ptr %t165, i64 %t166)
  %t173 = getelementptr i8, ptr %t172, i64 %t166
  call void @olang_textcopy(ptr %t173, ptr %t168, i64 %t169)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t171, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @compiler_2finterp_2esay(ptr %s8, { i64, ptr } %t182)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t184 = load i64, ptr %l11, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l11, !tbaa !24
  br label %bb12
bb32:
  %t188 = load i64, ptr %l7, !tbaa !24
  %t189 = load i64, ptr %l8, !tbaa !24
  %t191 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t192 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t196 = call i64 @__olang_fmt_i64(ptr null, i64 %t189)
  %t197 = add i64 %t194, %t196
  %t198 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t200 = add i64 %t197, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t200)
  %t202 = call i64 @__olang_fmt_i64(ptr %t201, i64 %t188)
  %t203 = getelementptr i8, ptr %t201, i64 %t191
  call void @olang_textcopy(ptr %t203, ptr %t192, i64 %t193)
  %t204 = getelementptr i8, ptr %t203, i64 %t193
  %t205 = call i64 @__olang_fmt_i64(ptr %t204, i64 %t189)
  %t206 = getelementptr i8, ptr %t204, i64 %t196
  call void @olang_textcopy(ptr %t206, ptr %t198, i64 %t199)
  %t207 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t201, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = extractvalue { i64, ptr } %t208, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  call void @compiler_2finterp_2esay(ptr %s0, { i64, ptr } %t215)
  br label %bb33
bb33:
  %t217 = load i64, ptr %l8, !tbaa !24
  %t219 = icmp sgt i64 %t217, 0
  br i1 %t219, label %bb34, label %bb35
bb34:
  store i32 1, ptr %l90, !tbaa !23
  br label %bb36
bb35:
  store i32 0, ptr %l90, !tbaa !23
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t221 = load i32, ptr %l90, !tbaa !23
  store i32 %t221, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [5 x i64] } %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [5 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l31 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [5 x i64] } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb6
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/interp:Exec", ptr %t12, i32 0, i32 1
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t14, i64 %a2)
  store ptr %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t23 = load ptr, ptr %l9, !tbaa !29
  %t24 = load i64, ptr %l10, !tbaa !24
  %t26 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eerrorName(ptr %v0, ptr %s1, ptr %t23, i64 %t24, i32 %t22)
  store { i64, ptr } %t26, ptr %l17
  br label %bb5
bb5:
  %t27 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t27, i64 %t28)
  %t34 = getelementptr i8, ptr %t33, i64 %t28
  call void @olang_textcopy(ptr %t34, ptr %t30, i64 %t31)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb6:
  %t38 = load { i64, [5 x i64] }, ptr %l1
  %t40 = extractvalue { i64, [5 x i64] } %t38, 0
  %t41 = icmp eq i64 %t40, 3
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t44 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t43, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  br label %bb9
bb8:
  br label %bb20
bb9:
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWaits, !tbaa !27
  %t49 = load ptr, ptr @__olang_prog_scope
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %t49, { i64, ptr } %t47, { i64, ptr } %t48)
  store i1 %t52, ptr %l24
  br label %bb10
bb10:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 4
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 77
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = icmp sge i64 %t58, 0
  store i1 %t60, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l25, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load { i64, [5 x i64] }, ptr %l1
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %s4, { i64, [5 x i64] } %t63, ptr %t64)
  store { i64, ptr } %t67, ptr %l31
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t69, i32 0, i32 4
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 77
  %t73 = load i64, ptr %t72, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/interp:Exec", ptr %t74, i32 0, i32 4
  %t77 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 78
  %t78 = load %"compiler/source:Span", ptr %t77
  %t82 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v2, ptr %s4, ptr %t68, i64 %t73, %"compiler/source:Span" %t78)
  store { i64, ptr } %t82, ptr %l37
  br label %bb17
bb17:
  %t83 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t84, i64 %t85)
  %t94 = getelementptr i8, ptr %t93, i64 %t85
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = getelementptr i8, ptr %t94, i64 %t87
  call void @olang_textcopy(ptr %t95, ptr %t90, i64 %t91)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb18:
  %t99 = load { i64, [5 x i64] }, ptr %l1
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t103 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %v3, { i64, [5 x i64] } %t99, ptr %t100)
  store { i64, ptr } %t103, ptr %l41
  br label %bb19
bb19:
  %t104 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t105 = load { i64, [5 x i64] }, ptr %l1
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t109 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %v3, { i64, [5 x i64] } %t105, ptr %t106)
  store { i64, ptr } %t109, ptr %l44
  br label %bb24
bb24:
  %t110 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_177aae49e1a91f38_175ec48f508568b4)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTestName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/interp:Exec", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t19)
  store ptr %t22, ptr %l13
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l13, !tbaa !29
  store ptr %t23, ptr %l2, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 8
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/interp:Exec", ptr %t28, i32 0, i32 1
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %a1)
  store ptr %t34, ptr %l19
  br label %bb2
bb2:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 4
  %t38 = load %"compiler/source:Span", ptr %t37
  %t39 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t41 = call %"compiler/source:Span" @compiler_2finterp_2efindTest(ptr %v0, { i64, ptr } %t39, %"compiler/source:Span" %t38)
  store %"compiler/source:Span" %t41, ptr %l22
  br label %bb3
bb3:
  %t42 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t42, ptr %l3
  %t43 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp eq i32 %t44, 0
  br i1 %t46, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l27, !tbaa !24
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l28, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l27, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t62, ptr %l26, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 6
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_eb59e3d17e209b69_67e25fc5a7a9951d)
  unreachable
bb8:
  br label %bb9
bb9:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 6
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l3
  %t78 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %t74, %"compiler/source:Span" %t75)
  store { i64, ptr } %t78, ptr %l35
  br label %bb10
bb10:
  %t79 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t79, ptr %l4, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = icmp sge i64 %t82, 2
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t86, ptr %l40, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i8, ptr %t88, i64 0
  %t90 = load i8, ptr %t89, !tbaa !32
  %t92 = icmp eq i8 %t90, 34
  store i1 %t92, ptr %l39, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t94 = load i1, ptr %l39, !tbaa !21
  br i1 %t94, label %bb14, label %bb15
bb14:
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l43, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t100 = sub i64 %t98, 1
  store i64 %t100, ptr %l46, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l47, !tbaa !24
  %t103 = icmp sge i64 1, 0
  br i1 %t103, label %bb16, label %bb17
bb15:
  br label %bb22
bb16:
  %t105 = load i64, ptr %l46, !tbaa !24
  %t106 = icmp sle i64 1, %t105
  br i1 %t106, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_475297ef6b70163a_9a972925e80d4cae)
  unreachable
bb18:
  %t108 = load i64, ptr %l46, !tbaa !24
  %t109 = load i64, ptr %l47, !tbaa !24
  %t110 = icmp sle i64 %t108, %t109
  br i1 %t110, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_475297ef6b70163a_9a972925e80d4cae)
  unreachable
bb20:
  %t112 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l46, !tbaa !24
  %t115 = getelementptr i8, ptr %t113, i64 1
  %t116 = sub i64 %t114, 1
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t120, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_475297ef6b70163a_9a972925e80d4cae)
  unreachable
bb22:
  %t126 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 1
  %t129 = extractvalue { i64, ptr } %t126, 0
  %t130 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t128, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { { i64, ptr }, i1 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca { i64, [2 x i64] }
  %l24 = alloca { i64, [5 x i64] }
  %l28 = alloca { i64, ptr }
  %l30 = alloca { { i64, ptr }, i1 }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %rv = alloca { { i64, ptr }, i1 }
  %t31 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t5, 0
  %t8 = insertvalue { { i64, ptr }, i1 } %t7, i1 false, 1
  store { { i64, ptr }, i1 } %t8, ptr %l8
  %t9 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t25 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 0
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = load { { i64, ptr }, i1 }, ptr %l8
  store { { i64, ptr }, i1 } %t26, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t27 = load i64, ptr %l1, !tbaa !24
  %t29 = trunc i64 %t27 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t34 = insertvalue { i32 } undef, i32 %t29, 0
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 1
  store { i32 } %t34, ptr %t35
  %t36 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t36, ptr %l2
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t38, { i64, [2 x i64] } %t39)
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/interp:Exec", ptr %t42, i32 0, i32 4
  store ptr %t44, ptr %l19, !tbaa !29
  %t45 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t45, ptr %l20
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = icmp sle i64 0, 1152921504606846975
  br i1 %t48, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d8a47822f9024607_7785834784e2e59b)
  unreachable
bb7:
  %t50 = mul i64 0, 8
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 0, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t54 = load ptr, ptr %l19, !tbaa !29
  %t55 = load { i64, [2 x i64] }, ptr %l20
  %t57 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t54, { i64, [2 x i64] } %t55, { i64, ptr } %t53)
  store { i64, [5 x i64] } %t57, ptr %l24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d8a47822f9024607_7785834784e2e59b)
  unreachable
bb9:
  %t58 = load { i64, [5 x i64] }, ptr %l24
  %t61 = extractvalue { i64, [5 x i64] } %t58, 0
  %t62 = icmp eq i64 %t61, 0
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t68 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t66, 0
  %t69 = insertvalue { { i64, ptr }, i1 } %t68, i1 false, 1
  store { { i64, ptr }, i1 } %t69, ptr %l30
  %t70 = getelementptr { { i64, ptr }, i1 }, ptr %l30, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l31, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l32, !tbaa !24
  %t74 = load i64, ptr %l32, !tbaa !24
  %t75 = mul i64 %t74, 1
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l33, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l32, !tbaa !24
  %t84 = mul i64 %t83, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t80, ptr %t82, i64 %t84, i1 false)
  %t85 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t86 = getelementptr { { i64, ptr }, i1 }, ptr %l30, i32 0, i32 0
  store { i64, ptr } %t85, ptr %t86, !tbaa !27
  %t87 = load { { i64, ptr }, i1 }, ptr %l30
  store { { i64, ptr }, i1 } %t87, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/interp:Exec", ptr %t88, i32 0, i32 4
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/interp:Exec", ptr %t91, i32 0, i32 4
  %t94 = getelementptr %"compiler/eval:Machine", ptr %t93, i32 0, i32 10
  %t95 = load %"compiler/eval:Ptr", ptr %t94
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/interp:Exec", ptr %t96, i32 0, i32 4
  %t99 = getelementptr %"compiler/eval:Machine", ptr %t98, i32 0, i32 11
  %t100 = load i32, ptr %t99, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %t90, %"compiler/eval:Ptr" %t95, i32 %t100)
  store { i64, ptr } %t104, ptr %l40
  br label %bb13
bb13:
  %t105 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t106 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t105, 0
  %t107 = insertvalue { { i64, ptr }, i1 } %t106, i1 true, 1
  store { { i64, ptr }, i1 } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i1 }, ptr %rv
  ret { { i64, ptr }, i1 } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i64
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/interp:Exec", ptr %t3, i32 0, i32 4
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 75
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/interp:Exec", ptr %t11, i32 0, i32 4
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 75
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %t15)
  %t20 = add i64 %t17, %t19
  %t21 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t16, i64 %t17)
  %t25 = getelementptr i8, ptr %t24, i64 %t17
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %t15)
  %t27 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } %t36)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  store i64 0, ptr %l3, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/interp:Exec", ptr %t39, i32 0, i32 4
  %t43 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l25
  br label %bb6
bb6:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb12
bb9:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l32, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t71 = load i64, ptr %l32, !tbaa !24
  store i64 %t71, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t72 = load i64, ptr %l29, !tbaa !24
  store i64 %t72, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb15:
  br label %bb16
bb16:
  %t81 = load i64, ptr %l3, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l8, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/interp:Exec", ptr %t91, i32 0, i32 4
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = call { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %t93, i64 %t94)
  store { i64, i64, i64 } %t97, ptr %l53
  br label %bb17
bb17:
  %t98 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t98, ptr %l9
  %t99 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 0
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l10, !tbaa !24
  %t102 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l11, !tbaa !24
  %t105 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 2
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp eq i64 %t108, 0
  br i1 %t110, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb23
bb19:
  %t112 = load i64, ptr %l12, !tbaa !24
  %t114 = icmp eq i64 %t112, 1
  br i1 %t114, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb22
bb22:
  %t116 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t116, ptr %l59, !tbaa !27
  br label %bb23
bb23:
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t117, ptr %l13, !tbaa !27
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/interp:Exec", ptr %t118, i32 0, i32 4
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceWhat(ptr %v0, ptr %t120, i64 %t121)
  store { i64, ptr } %t124, ptr %l66
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb25, label %bb26
bb25:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/interp:Exec", ptr %t130, i32 0, i32 4
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceWhat(ptr %v0, ptr %t132, i64 %t133)
  store { i64, ptr } %t136, ptr %l72
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t137 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = load ptr, ptr @__olang_prog_scope
  %t141 = call ptr @__olang_scope_alloc(ptr %t140, i64 %t139)
  call void @olang_textcopy(ptr %t141, ptr %t138, i64 %t139)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = load ptr, ptr @__olang_prog_scope
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = extractvalue { i64, ptr } %t143, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %t145, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l13, !tbaa !27
  br label %bb28
bb28:
  store ptr %l2, ptr %l75, !tbaa !29
  store ptr %a1, ptr %l76, !tbaa !29
  %t154 = load i64, ptr %l10, !tbaa !24
  store i64 %t154, ptr %l77, !tbaa !24
  %t155 = load i64, ptr %l11, !tbaa !24
  %t157 = trunc i64 %t155 to i32
  %t158 = load i64, ptr %l11, !tbaa !24
  %t160 = trunc i64 %t158 to i32
  %t163 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t157, i32 %t160)
  store %"compiler/source:Span" %t163, ptr %l82
  br label %bb29
bb29:
  %t164 = load ptr, ptr %l76, !tbaa !29
  %t165 = load i64, ptr %l77, !tbaa !24
  %t166 = load %"compiler/source:Span", ptr %l82
  %t167 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t164, i64 %t165, %"compiler/source:Span" %t166)
  store { i64, ptr } %t167, ptr %l83
  br label %bb30
bb30:
  %t168 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t176 = extractvalue { i64, ptr } %t168, 1
  %t177 = extractvalue { i64, ptr } %t168, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t170, i64 %t171)
  %t183 = getelementptr i8, ptr %t182, i64 %t171
  call void @olang_textcopy(ptr %t183, ptr %t172, i64 %t173)
  %t184 = getelementptr i8, ptr %t183, i64 %t173
  call void @olang_textcopy(ptr %t184, ptr %t176, i64 %t177)
  %t185 = getelementptr i8, ptr %t184, i64 %t177
  call void @olang_textcopy(ptr %t185, ptr %t179, i64 %t180)
  %t186 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t182, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = extractvalue { i64, ptr } %t187, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t195 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t195, { i64, ptr } %t194)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t197 = load i64, ptr %l7, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l7, !tbaa !24
  br label %bb13
bb33:
  %t202 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t202, ptr %l90
  br label %bb34
bb34:
  %t203 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t203, ptr %l91, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  store i64 %t205, ptr %l92, !tbaa !24
  %t206 = load i64, ptr %l92, !tbaa !24
  %t207 = mul i64 %t206, 1
  %t208 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  store { i64, ptr } %t210, ptr %l93, !tbaa !27
  %t211 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = load i64, ptr %l92, !tbaa !24
  %t216 = mul i64 %t215, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t212, ptr %t214, i64 %t216, i1 false)
  %t217 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t217, ptr %l91, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t218 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t218, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2finterp_2ecompiler_2finterp_3aExec_2ebuildDefault(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca i1
  %l35 = alloca i32
  %l40 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/interp:Exec", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 5
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t12, i64 %a1)
  store ptr %t16, ptr %l16
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = getelementptr %"compiler/load:Module", ptr %t18, i32 0, i32 3
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t28, ptr %l22
  br label %bb7
bb7:
  %t29 = load i1, ptr %l22, !tbaa !21
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t33 = insertvalue [5 x { i64, ptr }] %t32, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t34 = insertvalue [5 x { i64, ptr }] %t33, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d74, i32 0, i32 1) }, 2
  %t35 = insertvalue [5 x { i64, ptr }] %t34, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d75, i32 0, i32 1) }, 3
  %t36 = insertvalue [5 x { i64, ptr }] %t35, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, 4
  %t38 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 80, i64 8)
  store [5 x { i64, ptr }] %t36, ptr %t38
  store ptr %t38, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t40 = load ptr, ptr %l5
  store i64 5, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l5
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr [5 x { i64, ptr }], ptr %t51, i64 0, i64 %t52
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !37
  %t58 = load i32, ptr %l2, !tbaa !23
  store i32 %t58, ptr %l35, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/interp:Exec", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t66 = load ptr, ptr @__olang_prog_scope
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %t66, ptr %t64, { i64, ptr } %t56)
  store i32 %t69, ptr %l40
  br label %bb16
bb16:
  %t70 = load i32, ptr %l35, !tbaa !23
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = icmp eq i32 %t70, %t71
  br i1 %t72, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb12
bb21:
  call void @__olang_scope_close(ptr %s3)
  %t79 = load i32, ptr %l2, !tbaa !23
  store i32 %t79, ptr %l45, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/interp:Exec", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t83, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d77, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i32 %t85, ptr %l48
  br label %bb22
bb22:
  %t86 = load i32, ptr %l45, !tbaa !23
  %t87 = load i32, ptr %l48, !tbaa !23
  %t88 = icmp eq i32 %t86, %t87
  call void @__olang_scope_close(ptr %s0)
  store i1 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l16 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  store { i64, [2 x i64] } %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v1, ptr %a2, { i64, [2 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb24
bb5:
  %t14 = load { i64, [7 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [7 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i64, i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/interp:Exec", ptr %t23, i32 0, i32 8
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t25, i64 %t26)
  store i1 %t29, ptr %l16
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/interp:Exec", ptr %t33, i32 0, i32 8
  %t36 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t35, i64 %t36, i1 true)
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/interp:Exec", ptr %t39, i32 0, i32 4
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  store i64 %t42, ptr %l23, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/interp:Exec", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = getelementptr %"compiler/types:Table", ptr %t48, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/interp:Exec", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t54, i64 %t55)
  store ptr %t58, ptr %l30
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l26, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t63, i32 %t62)
  store { i64, ptr } %t65, ptr %l33
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l22, !tbaa !29
  %t67 = load i64, ptr %l23, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v0, ptr %t66, i64 %t67, { i64, ptr } %t68)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb24
bb17:
  %t69 = load { i64, [7 x i64] }, ptr %l1
  %t71 = extractvalue { i64, [7 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 2
  br i1 %t72, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t74 = load { i64, [7 x i64] }, ptr %l1
  %t76 = extractvalue { i64, [7 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 3
  br i1 %t77, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6b327bc23f54125b_df118949941dcc1f)
  unreachable
bb24:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eerrorName(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l26 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i32
  %l44 = alloca i32
  %l48 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l94 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l14, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/interp:Exec", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t12, i32 %a2)
  store i32 %t16, ptr %l19
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = load i32, ptr %l19, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l20
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = ashr i64 %t21, 16
  %t25 = sub i64 %t23, 1
  store i64 %t25, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb4:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp sge i64 %t31, %t34
  store i1 %t37, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t39 = load i1, ptr %l26, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t40)
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = getelementptr i8, ptr %t46, i64 %t42
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t40)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/interp:Exec", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %l36, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t57, i32 %t64)
  store i32 %t67, ptr %l39
  br label %bb9
bb9:
  %t68 = load i32, ptr %l39, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t74, i32 %t68)
  store i32 %t78, ptr %l44
  br label %bb10
bb10:
  %t79 = load i32, ptr %l44, !tbaa !23
  store i32 %t79, ptr %l6, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/interp:Exec", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i32, ptr %l6, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t83, i32 %t84)
  store { i64, ptr } %t87, ptr %l48
  br label %bb11
bb11:
  %t88 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  %t89 = load i64, ptr %l1, !tbaa !24
  %t91 = and i64 %t89, 65535
  store i64 %t91, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t99 = icmp slt i64 %t93, %t96
  br i1 %t99, label %bb12, label %bb13
bb12:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/interp:Exec", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = getelementptr %"compiler/types:Table", ptr %t106, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t109, ptr %l59, !tbaa !27
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  %t118 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t108, i32 %t115)
  store { i64, ptr } %t118, ptr %l62
  br label %bb14
bb13:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = call i64 @__olang_fmt_i64(ptr null, i64 %t119)
  %t122 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t121)
  %t123 = call i64 @__olang_fmt_i64(ptr %t122, i64 %t119)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t122, 1
  store { i64, ptr } %t125, ptr %l55, !tbaa !27
  br label %bb15
bb14:
  %t127 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t128, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l55, !tbaa !27
  br label %bb15
bb15:
  %t134 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t134, ptr %l9, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/interp:Exec", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l6, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t140, i32 %t141)
  store i64 %t144, ptr %l70
  br label %bb16
bb16:
  %t145 = load i64, ptr %l70, !tbaa !24
  store i64 %t145, ptr %l10, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/interp:Exec", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t152 = getelementptr %"compiler/types:Table", ptr %t151, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  store ptr %t153, ptr %l73, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/interp:Exec", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l6, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l78
  br label %bb17
bb17:
  %t164 = load ptr, ptr %l73, !tbaa !29
  %t165 = load i32, ptr %l78, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t164, i32 %t165)
  store { i64, ptr } %t166, ptr %l79
  br label %bb18
bb18:
  %t167 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t167, ptr %l11, !tbaa !27
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/interp:Exec", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 0
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/load:Loader", ptr %t174, i32 0, i32 5
  %t177 = load i64, ptr %l10, !tbaa !24
  %t180 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t176, i64 %t177)
  store ptr %t180, ptr %l85
  br label %bb19
bb19:
  %t181 = load ptr, ptr %l85, !tbaa !29
  %t183 = getelementptr %"compiler/load:Module", ptr %t181, i32 0, i32 2
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t185 = load i64, ptr %l10, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/interp:Exec", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/generic:Program", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/load:Loader", ptr %t192, i32 0, i32 7
  %t195 = load i64, ptr %t194, !tbaa !24
  %t198 = icmp eq i64 %t185, %t195
  %t201 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s0, { i64, ptr } %t184, i1 %t198)
  store { i64, ptr } %t201, ptr %l94
  br label %bb20
bb20:
  %t202 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t208 = extractvalue { i64, ptr } %t202, 1
  %t209 = extractvalue { i64, ptr } %t202, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t215 = extractvalue { i64, ptr } %t203, 1
  %t216 = extractvalue { i64, ptr } %t203, 0
  %t217 = add i64 %t213, %t216
  %t218 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t205, i64 %t206)
  %t219 = getelementptr i8, ptr %t218, i64 %t206
  call void @olang_textcopy(ptr %t219, ptr %t208, i64 %t209)
  %t220 = getelementptr i8, ptr %t219, i64 %t209
  call void @olang_textcopy(ptr %t220, ptr %t211, i64 %t212)
  %t221 = getelementptr i8, ptr %t220, i64 %t212
  call void @olang_textcopy(ptr %t221, ptr %t215, i64 %t216)
  %t222 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t218, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t223, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:Call"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/mir:Task"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/mir:BasicBlock"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, [21 x i64] }
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca { i64, [2 x i64] }
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca %"compiler/mir:Call"
  %l39 = alloca i64
  %l41 = alloca i64
  %l46 = alloca %"compiler/mir:Task"
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/mir:BasicBlock"
  %l63 = alloca i64
  %l65 = alloca i64
  %l70 = alloca { i64, [21 x i64] }
  %l71 = alloca { i64, [21 x i64] }
  %l73 = alloca i1
  %l79 = alloca { i64, [21 x i64] }
  %l81 = alloca i1
  %l84 = alloca i1
  %l93 = alloca { i64, [4 x i64] }
  %l100 = alloca { i64, [21 x i64] }
  %l103 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %t207 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 14
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l24, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l26
  br label %bb2
bb2:
  %t9 = load i64, ptr %l24, !tbaa !24
  %t10 = load i64, ptr %l26, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/mir:Call" %t19, ptr %l31
  br label %bb6
bb6:
  %t20 = load %"compiler/mir:Call", ptr %l31
  store %"compiler/mir:Call" %t20, ptr %l5
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/mir:Call", ptr %l5, i32 0, i32 0
  %t23 = load { i64, [7 x i64] }, ptr %t22
  %t24 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v2, ptr %t21, { i64, [7 x i64] } %t23, ptr %t24)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb1
bb9:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/mir:Fn", ptr %t32, i32 0, i32 16
  store ptr %t34, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l7, !tbaa !24
  store i64 %t36, ptr %l39, !tbaa !24
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v1, ptr %t37)
  store i64 %t39, ptr %l41
  br label %bb11
bb11:
  %t40 = load i64, ptr %l39, !tbaa !24
  %t41 = load i64, ptr %l41, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v1, ptr %t46, i64 %t47)
  store %"compiler/mir:Task" %t50, ptr %l46
  br label %bb15
bb15:
  %t51 = load %"compiler/mir:Task", ptr %l46
  store %"compiler/mir:Task" %t51, ptr %l8
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/mir:Task", ptr %l8, i32 0, i32 0
  %t54 = load { i64, [7 x i64] }, ptr %t53
  %t55 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v2, ptr %t52, { i64, [7 x i64] } %t54, ptr %t55)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l7, !tbaa !24
  br label %bb10
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/mir:Fn", ptr %t63, i32 0, i32 9
  store ptr %t65, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t67 = load i64, ptr %l10, !tbaa !24
  store i64 %t67, ptr %l54, !tbaa !24
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v1, ptr %t68)
  store i64 %t70, ptr %l56
  br label %bb20
bb20:
  %t71 = load i64, ptr %l54, !tbaa !24
  %t72 = load i64, ptr %l56, !tbaa !24
  %t73 = icmp slt i64 %t71, %t72
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb21, label %bb22
bb21:
  br label %bb81
bb22:
  br label %bb23
bb23:
  %t77 = load ptr, ptr %l9, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v1, ptr %v1, ptr %t77, i64 %t78)
  store %"compiler/mir:BasicBlock" %t81, ptr %l61
  br label %bb24
bb24:
  %t82 = load %"compiler/mir:BasicBlock", ptr %l61
  store %"compiler/mir:BasicBlock" %t82, ptr %l11
  %t83 = getelementptr %"compiler/mir:BasicBlock", ptr %l11, i32 0, i32 0
  store ptr %t83, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t85 = load i64, ptr %l13, !tbaa !24
  store i64 %t85, ptr %l63, !tbaa !24
  %t86 = load ptr, ptr %l12, !tbaa !29
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t86)
  store i64 %t88, ptr %l65
  br label %bb26
bb26:
  %t89 = load i64, ptr %l63, !tbaa !24
  %t90 = load i64, ptr %l65, !tbaa !24
  %t91 = icmp slt i64 %t89, %t90
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb27, label %bb28
bb27:
  br label %bb79
bb28:
  br label %bb29
bb29:
  %t95 = load ptr, ptr %l12, !tbaa !29
  %t96 = load i64, ptr %l13, !tbaa !24
  %t99 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t95, i64 %t96)
  store { i64, [21 x i64] } %t99, ptr %l70
  br label %bb30
bb30:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l70, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %l14, i64 176, i1 false)
  %t100 = load { i64, [21 x i64] }, ptr %l71
  %t101 = extractvalue { i64, [21 x i64] } %t100, 0
  %t102 = icmp eq i64 %t101, 0
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t104, i32 0, i32 2
  %t106 = load { i64, [15 x i64] }, ptr %t105
  %t108 = extractvalue { i64, [15 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 10
  store i1 %t109, ptr %l73, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t111 = load i1, ptr %l73, !tbaa !21
  br i1 %t111, label %bb34, label %bb35
bb34:
  %t112 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t112, i32 0, i32 2
  %t114 = getelementptr { i64, [15 x i64] }, ptr %t113, i32 0, i32 1
  %t115 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t114, i32 0, i32 0
  %t116 = load { i64, [2 x i64] }, ptr %t115
  store { i64, [2 x i64] } %t116, ptr %l15
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t119 = load { i64, [2 x i64] }, ptr %l15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v2, ptr %t118, { i64, [2 x i64] } %t119)
  br label %bb37
bb37:
  br label %bb77
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %l14, i64 176, i1 false)
  %t122 = load { i64, [21 x i64] }, ptr %l79
  %t123 = extractvalue { i64, [21 x i64] } %t122, 0
  %t124 = icmp eq i64 %t123, 0
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t126 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t126, i32 0, i32 2
  %t128 = load { i64, [15 x i64] }, ptr %t127
  %t130 = extractvalue { i64, [15 x i64] } %t128, 0
  %t131 = icmp eq i64 %t130, 3
  br i1 %t131, label %bb41, label %bb42
bb40:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb44
bb41:
  %t133 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t133, i32 0, i32 2
  %t135 = getelementptr { i64, [15 x i64] }, ptr %t134, i32 0, i32 1
  %t136 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t135, i32 0, i32 0
  %t137 = load i32, ptr %t136
  %t139 = trunc i64 40 to i32
  %t140 = icmp eq i32 %t137, %t139
  store i1 %t140, ptr %l84, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb43
bb43:
  %t142 = load i1, ptr %l84, !tbaa !21
  store i1 %t142, ptr %l81, !tbaa !21
  br label %bb44
bb44:
  %t143 = load i1, ptr %l81, !tbaa !21
  br i1 %t143, label %bb45, label %bb46
bb45:
  %t144 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t144, i32 0, i32 2
  %t146 = getelementptr { i64, [15 x i64] }, ptr %t145, i32 0, i32 1
  %t147 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t146, i32 0, i32 2
  %t148 = load %"compiler/mir:Range", ptr %t147
  store %"compiler/mir:Range" %t148, ptr %l16
  br label %bb47
bb46:
  br label %bb59
bb47:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/mir:Fn", ptr %t150, i32 0, i32 11
  %t153 = getelementptr %"compiler/mir:Range", ptr %l16, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sext i32 %t154 to i64
  %t158 = add i64 %t156, 1
  %t161 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %t152, i64 %t158)
  store { i64, [4 x i64] } %t161, ptr %l93
  br label %bb48
bb48:
  %t162 = load { i64, [4 x i64] }, ptr %l93
  store { i64, [4 x i64] } %t162, ptr %l17
  %t163 = load { i64, [4 x i64] }, ptr %l17
  %t165 = extractvalue { i64, [4 x i64] } %t163, 0
  %t166 = icmp eq i64 %t165, 2
  br i1 %t166, label %bb49, label %bb50
bb49:
  %t168 = getelementptr { i64, [4 x i64] }, ptr %l17, i32 0, i32 1
  %t169 = getelementptr { i32, i64 }, ptr %t168, i32 0, i32 1
  %t170 = load i64, ptr %t169
  store i64 %t170, ptr %l18, !tbaa !24
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i64, ptr %l18, !tbaa !24
  %t174 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2etable(ptr %v0, ptr %v2, ptr %t172, i64 %t173, ptr %t174)
  br label %bb52
bb52:
  br label %bb58
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_cc02f93ad90a889a_227f669eebce755e)
  unreachable
bb58:
  br label %bb77
bb59:
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %l14, i64 176, i1 false)
  %t178 = load { i64, [21 x i64] }, ptr %l100
  %t179 = extractvalue { i64, [21 x i64] } %t178, 0
  %t180 = icmp eq i64 %t179, 6
  br i1 %t180, label %bb60, label %bb61
bb60:
  %t182 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t182, i32 0, i32 2
  %t184 = load i32, ptr %t183
  store i32 %t184, ptr %l19, !tbaa !23
  br label %bb62
bb61:
  br label %bb72
bb62:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/interp:Exec", ptr %t186, i32 0, i32 7
  %t189 = load i32, ptr %l19, !tbaa !23
  %t192 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t188, i32 %t189)
  %t193 = extractvalue { i32, i64 } %t192, 1
  %t194 = extractvalue { i32, i64 } %t192, 0
  store i32 %t194, ptr %l108
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb64, label %ok.196
ok.196:
  store i64 %t193, ptr %l107
  br label %bb63
bb63:
  %t197 = load i64, ptr %l107, !tbaa !24
  store i64 %t197, ptr %l103, !tbaa !24
  br label %bb66
bb64:
  br label %bb65
bb65:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l103, !tbaa !24
  br label %bb66
bb66:
  %t198 = load i64, ptr %l103, !tbaa !24
  store i64 %t198, ptr %l20, !tbaa !24
  %t199 = load i64, ptr %l20, !tbaa !24
  %t201 = icmp sge i64 %t199, 0
  br i1 %t201, label %bb67, label %bb68
bb67:
  %t203 = load i64, ptr %l20, !tbaa !24
  %t205 = trunc i64 %t203 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [2 x i64] }, ptr %t207, i32 0, i32 0
  store i64 0, ptr %t208
  %t210 = insertvalue { i32 } undef, i32 %t205, 0
  %t211 = getelementptr { i64, [2 x i64] }, ptr %t207, i32 0, i32 1
  store { i32 } %t210, ptr %t211
  %t212 = load { i64, [2 x i64] }, ptr %t207
  store { i64, [2 x i64] } %t212, ptr %l21
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/interp:Exec", ptr %t214, i32 0, i32 4
  %t217 = load i32, ptr %l19, !tbaa !23
  %t218 = load { i64, [2 x i64] }, ptr %l21
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %t216, i32 %t217, { i64, [2 x i64] } %t218)
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t222 = load ptr, ptr %l2, !tbaa !29
  %t223 = load { i64, [2 x i64] }, ptr %l21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v2, ptr %t222, { i64, [2 x i64] } %t223)
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_8861c203007a29b_3eff7fe7d80c41df)
  unreachable
bb77:
  br label %bb78
bb78:
  %t226 = load i64, ptr %l13, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l13, !tbaa !24
  br label %bb25
bb79:
  br label %bb80
bb80:
  %t230 = load i64, ptr %l10, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l10, !tbaa !24
  br label %bb19
bb81:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca i1
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca ptr
  %l106 = alloca i32
  %l115 = alloca ptr
  %l116 = alloca i64
  %l117 = alloca i32
  %l118 = alloca i32
  %l123 = alloca ptr
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i64
  %l128 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca i1
  %l135 = alloca i1
  %l145 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l149 = alloca i64
  %l151 = alloca i64
  %l156 = alloca i64
  %l161 = alloca i1
  %l168 = alloca i64
  %l170 = alloca i64
  %l175 = alloca i64
  %l179 = alloca i1
  %l188 = alloca i64
  %l190 = alloca i64
  %l195 = alloca i64
  %l203 = alloca i64
  %l205 = alloca i64
  %l210 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t176 = alloca { i64, [2 x i64] }, align 8
  %t381 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/interp:Exec", ptr %t6, i32 0, i32 12
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/interp:Exec", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 5
  store ptr %t17, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l39, !tbaa !24
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l41
  br label %bb5
bb5:
  %t23 = load i64, ptr %l39, !tbaa !24
  %t24 = load i64, ptr %l41, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t29, i64 %t30)
  store ptr %t33, ptr %l46
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l46, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/load:Module", ptr %t35, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t38, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t40, ptr %l49
  br label %bb10
bb10:
  %t41 = load i1, ptr %l49, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/interp:Exec", ptr %t42, i32 0, i32 4
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 71
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/load:Module", ptr %t46, i32 0, i32 4
  %t49 = load i64, ptr %t48, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t45, i64 %t49, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l2, !tbaa !24
  br label %bb4
bb16:
  store i64 0, ptr %l4, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/interp:Exec", ptr %t56, i32 0, i32 1
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l58
  br label %bb17
bb17:
  %t61 = load i64, ptr %l58, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb23
bb20:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l4, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l65, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb22
bb22:
  %t88 = load i64, ptr %l65, !tbaa !24
  store i64 %t88, ptr %l62, !tbaa !24
  br label %bb23
bb23:
  %t89 = load i64, ptr %l62, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb25, label %bb26
bb25:
  br label %bb62
bb26:
  br label %bb27
bb27:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l9, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/interp:Exec", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t110, i64 %t111)
  store ptr %t114, ptr %l86
  br label %bb28
bb28:
  %t115 = load ptr, ptr %l86, !tbaa !29
  store ptr %t115, ptr %l10, !tbaa !29
  %t116 = load ptr, ptr %l10, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Body", ptr %t116, i32 0, i32 1
  %t119 = load { i64, [2 x i64] }, ptr %t118
  store { i64, [2 x i64] } %t119, ptr %l11
  %t121 = load { i64, [2 x i64] }, ptr %l11
  %t123 = extractvalue { i64, [2 x i64] } %t121, 0
  %t124 = icmp eq i64 %t123, 3
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t126 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t127 = getelementptr { i32 }, ptr %t126, i32 0, i32 0
  %t128 = load i32, ptr %t127
  store i32 %t128, ptr %l12, !tbaa !23
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/interp:Exec", ptr %t130, i32 0, i32 7
  %t133 = load i32, ptr %l12, !tbaa !23
  %t134 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t132, i32 %t133, i64 %t134)
  br label %bb32
bb32:
  br label %bb60
bb33:
  %t138 = load { i64, [2 x i64] }, ptr %l11
  %t140 = extractvalue { i64, [2 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 6
  br i1 %t141, label %bb34, label %bb35
bb34:
  %t143 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t144 = getelementptr { i64, i32 }, ptr %t143, i32 0, i32 0
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l13, !tbaa !24
  %t147 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t148 = getelementptr { i64, i32 }, ptr %t147, i32 0, i32 1
  %t149 = load i32, ptr %t148
  store i32 %t149, ptr %l14, !tbaa !23
  br label %bb36
bb35:
  br label %bb55
bb36:
  %t151 = load ptr, ptr %l10, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Body", ptr %t151, i32 0, i32 11
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb37, label %bb38
bb37:
  br label %bb61
bb38:
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t159 = load i64, ptr %l13, !tbaa !24
  %t160 = load i32, ptr %l14, !tbaa !23
  %t164 = call i32 @compiler_2finterp_2eglobalType(ptr %v0, ptr %t158, i64 %t159, i32 %t160)
  store i32 %t164, ptr %l106
  br label %bb40
bb40:
  %t165 = load i32, ptr %l106, !tbaa !23
  store i32 %t165, ptr %l15, !tbaa !23
  %t166 = load i32, ptr %l15, !tbaa !23
  %t167 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t170 = icmp eq i32 %t166, %t167
  br i1 %t170, label %bb41, label %bb42
bb41:
  br label %bb61
bb42:
  br label %bb43
bb43:
  %t172 = load i64, ptr %l9, !tbaa !24
  %t174 = trunc i64 %t172 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t179 = insertvalue { i32 } undef, i32 %t174, 0
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 1
  store { i32 } %t179, ptr %t180
  %t181 = load { i64, [2 x i64] }, ptr %t176
  store { i64, [2 x i64] } %t181, ptr %l16
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/interp:Exec", ptr %t183, i32 0, i32 4
  store ptr %t185, ptr %l115, !tbaa !29
  %t186 = load i64, ptr %l13, !tbaa !24
  store i64 %t186, ptr %l116, !tbaa !24
  %t187 = load i32, ptr %l14, !tbaa !23
  store i32 %t187, ptr %l117, !tbaa !23
  %t188 = load i32, ptr %l15, !tbaa !23
  store i32 %t188, ptr %l118, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/interp:Exec", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t193 = load i64, ptr %l13, !tbaa !24
  %t194 = load i32, ptr %l14, !tbaa !23
  %t198 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t192, i64 %t193, i32 %t194)
  store ptr %t198, ptr %l123
  br label %bb44
bb44:
  %t199 = load ptr, ptr %l123, !tbaa !29
  %t200 = call i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %t199)
  store i1 %t200, ptr %l124
  br label %bb45
bb45:
  %t201 = load { i64, [2 x i64] }, ptr %l16
  %t202 = load ptr, ptr %l115, !tbaa !29
  %t203 = load i64, ptr %l116, !tbaa !24
  %t204 = load i32, ptr %l117, !tbaa !23
  %t205 = load i32, ptr %l118, !tbaa !23
  %t206 = load i1, ptr %l124, !tbaa !21
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %t202, i64 %t203, i32 %t204, i32 %t205, i1 %t206, { i64, [2 x i64] } %t201)
  br label %bb46
bb46:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l126, !tbaa !29
  %t209 = load i64, ptr %l13, !tbaa !24
  store i64 %t209, ptr %l127, !tbaa !24
  %t210 = load i32, ptr %l15, !tbaa !23
  store i32 %t210, ptr %l128, !tbaa !23
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/interp:Exec", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load i64, ptr %l13, !tbaa !24
  %t216 = load i32, ptr %l14, !tbaa !23
  %t220 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t214, i64 %t215, i32 %t216)
  store ptr %t220, ptr %l133
  br label %bb47
bb47:
  %t221 = load ptr, ptr %l133, !tbaa !29
  %t222 = call i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %t221)
  store i1 %t222, ptr %l134
  br label %bb48
bb48:
  %t223 = load ptr, ptr %l126, !tbaa !29
  %t224 = load i64, ptr %l127, !tbaa !24
  %t225 = load i32, ptr %l128, !tbaa !23
  %t226 = load i1, ptr %l134, !tbaa !21
  %t227 = call i1 @compiler_2finterp_2ecompiler_2finterp_3aExec_2ebuildDefault(ptr %v0, ptr %t223, i64 %t224, i32 %t225, i1 %t226)
  store i1 %t227, ptr %l135
  br label %bb49
bb49:
  %t228 = load i1, ptr %l135, !tbaa !21
  br i1 %t228, label %bb50, label %bb51
bb50:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/interp:Exec", ptr %t229, i32 0, i32 4
  %t232 = load i64, ptr %l13, !tbaa !24
  %t233 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eBuildGlobal(ptr %v0, ptr %t231, i64 %t232, i32 %t233)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/interp:Exec", ptr %t237, i32 0, i32 9
  %t240 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t239, i64 %t240)
  br label %bb54
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_5218513f7b2d35ff_8134a4fdf2d394bb)
  unreachable
bb60:
  br label %bb61
bb61:
  %t243 = load i64, ptr %l8, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l8, !tbaa !24
  br label %bb24
bb62:
  %t247 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t247, ptr %l145
  br label %bb63
bb63:
  %t248 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l145
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %l17
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/interp:Exec", ptr %t249, i32 0, i32 0
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/generic:Program", ptr %t252, i32 0, i32 41
  store ptr %t254, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb64
bb64:
  %t256 = load i64, ptr %l19, !tbaa !24
  store i64 %t256, ptr %l149, !tbaa !24
  %t257 = load ptr, ptr %l18, !tbaa !29
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t257)
  store i64 %t259, ptr %l151
  br label %bb65
bb65:
  %t260 = load i64, ptr %l149, !tbaa !24
  %t261 = load i64, ptr %l151, !tbaa !24
  %t262 = icmp slt i64 %t260, %t261
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb66, label %bb67
bb66:
  br label %bb76
bb67:
  br label %bb68
bb68:
  %t266 = load ptr, ptr %l18, !tbaa !29
  %t267 = load i64, ptr %l19, !tbaa !24
  %t270 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t266, i64 %t267)
  store i64 %t270, ptr %l156
  br label %bb69
bb69:
  %t271 = load i64, ptr %l156, !tbaa !24
  store i64 %t271, ptr %l20, !tbaa !24
  %t272 = load i64, ptr %l20, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/interp:Exec", ptr %t274, i32 0, i32 9
  %t280 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t276, i64 %t272)
  store i1 %t280, ptr %l161
  br label %bb70
bb70:
  %t281 = load i1, ptr %l161, !tbaa !21
  br i1 %t281, label %bb71, label %bb72
bb71:
  %t282 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l17, i64 %t282)
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t285 = load i64, ptr %l19, !tbaa !24
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l19, !tbaa !24
  br label %bb64
bb76:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/interp:Exec", ptr %t289, i32 0, i32 9
  store ptr %t291, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb77
bb77:
  %t293 = load i64, ptr %l23, !tbaa !24
  store i64 %t293, ptr %l168, !tbaa !24
  %t294 = load ptr, ptr %l22, !tbaa !29
  %t296 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t294)
  store i64 %t296, ptr %l170
  br label %bb78
bb78:
  %t297 = load i64, ptr %l168, !tbaa !24
  %t298 = load i64, ptr %l170, !tbaa !24
  %t299 = icmp slt i64 %t297, %t298
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb79, label %bb80
bb79:
  br label %bb89
bb80:
  br label %bb81
bb81:
  %t303 = load ptr, ptr %l22, !tbaa !29
  %t304 = load i64, ptr %l23, !tbaa !24
  %t307 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t303, i64 %t304)
  store i64 %t307, ptr %l175
  br label %bb82
bb82:
  %t308 = load i64, ptr %l175, !tbaa !24
  store i64 %t308, ptr %l24, !tbaa !24
  %t309 = load i64, ptr %l24, !tbaa !24
  %t314 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l17, i64 %t309)
  store i1 %t314, ptr %l179
  br label %bb83
bb83:
  %t315 = load i1, ptr %l179, !tbaa !21
  %t316 = xor i1 %t315, true
  br i1 %t316, label %bb84, label %bb85
bb84:
  %t318 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l17, i64 %t318)
  br label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t321 = load i64, ptr %l23, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l23, !tbaa !24
  br label %bb77
bb89:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/interp:Exec", ptr %t325, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t327)
  br label %bb90
bb90:
  store ptr %l17, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb91
bb91:
  %t330 = load i64, ptr %l27, !tbaa !24
  store i64 %t330, ptr %l188, !tbaa !24
  %t331 = load ptr, ptr %l26, !tbaa !29
  %t333 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t331)
  store i64 %t333, ptr %l190
  br label %bb92
bb92:
  %t334 = load i64, ptr %l188, !tbaa !24
  %t335 = load i64, ptr %l190, !tbaa !24
  %t336 = icmp slt i64 %t334, %t335
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb93, label %bb94
bb93:
  br label %bb99
bb94:
  br label %bb95
bb95:
  %t340 = load ptr, ptr %l26, !tbaa !29
  %t341 = load i64, ptr %l27, !tbaa !24
  %t344 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t340, i64 %t341)
  store i64 %t344, ptr %l195
  br label %bb96
bb96:
  %t345 = load i64, ptr %l195, !tbaa !24
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/interp:Exec", ptr %t346, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t348, i64 %t345)
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t352 = load i64, ptr %l27, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l27, !tbaa !24
  br label %bb91
bb99:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/interp:Exec", ptr %t356, i32 0, i32 9
  store ptr %t358, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb100
bb100:
  %t360 = load i64, ptr %l30, !tbaa !24
  store i64 %t360, ptr %l203, !tbaa !24
  %t361 = load ptr, ptr %l29, !tbaa !29
  %t363 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t361)
  store i64 %t363, ptr %l205
  br label %bb101
bb101:
  %t364 = load i64, ptr %l203, !tbaa !24
  %t365 = load i64, ptr %l205, !tbaa !24
  %t366 = icmp slt i64 %t364, %t365
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb102, label %bb103
bb102:
  br label %bb108
bb103:
  br label %bb104
bb104:
  %t370 = load ptr, ptr %l29, !tbaa !29
  %t371 = load i64, ptr %l30, !tbaa !24
  %t374 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t370, i64 %t371)
  store i64 %t374, ptr %l210
  br label %bb105
bb105:
  %t375 = load i64, ptr %l210, !tbaa !24
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t379 = trunc i64 %t375 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t381
  %t382 = getelementptr { i64, [2 x i64] }, ptr %t381, i32 0, i32 0
  store i64 0, ptr %t382
  %t384 = insertvalue { i32 } undef, i32 %t379, 0
  %t385 = getelementptr { i64, [2 x i64] }, ptr %t381, i32 0, i32 1
  store { i32 } %t384, ptr %t385
  %t386 = load { i64, [2 x i64] }, ptr %t381
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t376, { i64, [2 x i64] } %t386)
  br label %bb106
bb106:
  br label %bb107
bb107:
  %t389 = load i64, ptr %l30, !tbaa !24
  %t391 = add i64 %t389, 1
  store i64 %t391, ptr %l30, !tbaa !24
  br label %bb100
bb108:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2etable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/generic:AnyTable"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l19 = alloca %"compiler/generic:AnyTable"
  %l21 = alloca i64
  %l24 = alloca i64
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l78 = alloca { i64, ptr }
  %t35 = alloca { i64, [2 x i64] }, align 8
  %t48 = alloca { i64, [2 x i64] }, align 8
  %t121 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 42
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/generic:AnyTable" %t10, ptr %l19
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:AnyTable", ptr %l19
  store %"compiler/generic:AnyTable" %t11, ptr %l3
  %t12 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l21
  br label %bb2
bb2:
  %t15 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t16 = load i64, ptr %l21, !tbaa !24
  %t18 = add i64 %t16, %t15
  %t20 = sub i64 %t18, 1
  store i64 %t20, ptr %l24, !tbaa !24
  %t21 = load i64, ptr %l24, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load i64, ptr %l24, !tbaa !24
  %t25 = icmp sle i64 %t24, 384307168202282325
  br i1 %t25, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6661ff5fcd5a0e74_cadc672e97162150)
  unreachable
bb5:
  %t27 = load i64, ptr %l24, !tbaa !24
  %t28 = mul i64 %t27, 24
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l28, !tbaa !27
  %t34 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 0
  store i64 4, ptr %t36
  %t38 = insertvalue { i64, i1 } undef, i64 %t34, 0
  %t39 = insertvalue { i64, i1 } %t38, i1 false, 1
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  store { i64, i1 } %t39, ptr %t40
  %t41 = load { i64, [2 x i64] }, ptr %t35
  %t43 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t44, i64 0
  store { i64, [2 x i64] } %t41, ptr %t45
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l31, !tbaa !27
  %t47 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 0
  store i64 4, ptr %t49
  %t51 = insertvalue { i64, i1 } undef, i64 %t47, 0
  %t52 = insertvalue { i64, i1 } %t51, i1 true, 1
  %t53 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  store { i64, i1 } %t52, ptr %t53
  %t54 = load { i64, [2 x i64] }, ptr %t48
  %t56 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i64 1
  store { i64, [2 x i64] } %t54, ptr %t58
  store i64 0, ptr %l5, !tbaa !24
  %t59 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l35
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6661ff5fcd5a0e74_cadc672e97162150)
  unreachable
bb7:
  %t62 = load i64, ptr %l35, !tbaa !24
  store i64 %t62, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb8, label %bb9
bb8:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb13
bb10:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l42, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb12
bb12:
  %t89 = load i64, ptr %l42, !tbaa !24
  store i64 %t89, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t90 = load i64, ptr %l39, !tbaa !24
  store i64 %t90, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t99 = load i64, ptr %l5, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l10, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t109, ptr %l60, !tbaa !27
  %t110 = load i64, ptr %l10, !tbaa !24
  %t112 = add i64 %t110, 2
  store i64 %t112, ptr %l62, !tbaa !24
  %t113 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t114 = load i64, ptr %l10, !tbaa !24
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t113, i64 %t114)
  store i64 %t117, ptr %l65
  br label %bb18
bb18:
  %t118 = load i64, ptr %l65, !tbaa !24
  %t119 = trunc i64 %t118 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [2 x i64] }, ptr %t121, i32 0, i32 0
  store i64 0, ptr %t122
  %t124 = insertvalue { i32 } undef, i32 %t119, 0
  %t125 = getelementptr { i64, [2 x i64] }, ptr %t121, i32 0, i32 1
  store { i32 } %t124, ptr %t125
  %t126 = load { i64, [2 x i64] }, ptr %t121
  %t128 = load i64, ptr %l62, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, [2 x i64] }, ptr %t130, i64 %t128
  store { i64, [2 x i64] } %t126, ptr %t131
  br label %bb19
bb19:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l9, !tbaa !24
  br label %bb14
bb20:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t136, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t150 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t150, ptr %l78, !tbaa !27
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr { i64, [2 x i64] }, ptr %t154, i64 %t151
  %t156 = load { i64, [2 x i64] }, ptr %t155
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v1, ptr %a2, { i64, [2 x i64] } %t156)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t162 = load i64, ptr %l12, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l12, !tbaa !24
  br label %bb21
bb27:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/interp:Exec", ptr %t166, i32 0, i32 4
  %t169 = load i64, ptr %l1, !tbaa !24
  %t170 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t171 = load i32, ptr %t170, !tbaa !23
  %t172 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineTable(ptr %v0, ptr %v0, ptr %t168, i64 %t169, i32 %t171, { i64, ptr } %t172)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2finterp_2econdSaid(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [3 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [3 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l3, !tbaa !24
  %t14 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t15 = getelementptr { i64, i64, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l15
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l10, !tbaa !29
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = load i64, ptr %l15, !tbaa !24
  %t30 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %t25, i64 %t26, i64 %t27, i64 %t28, i64 %t29)
  store i1 %t30, ptr %l16
  br label %bb5
bb5:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2finterp_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/check:EmbedAsk"
  %l13 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca { { i64, ptr }, i1 }
  %l15 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/check:Ask"
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca { i1, i1 }
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca %"compiler/generic:ConstAsk"
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, [2 x i64] }
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l35 = alloca ptr
  %l36 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, [3 x i64] }
  %l41 = alloca ptr
  %l42 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca i64
  %l49 = alloca i1
  %l52 = alloca i64
  %l54 = alloca i1
  %l58 = alloca i64
  %l60 = alloca i1
  %l63 = alloca i64
  %l71 = alloca %"compiler/interp:Exec"
  %l81 = alloca i64
  %l83 = alloca i64
  %l88 = alloca %"compiler/check:EmbedAsk"
  %l92 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l95 = alloca i1
  %l98 = alloca { { i64, ptr }, i1 }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l104 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l106 = alloca { i64, ptr }
  %l114 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l117 = alloca i64
  %l119 = alloca i64
  %l124 = alloca %"compiler/check:Ask"
  %l128 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l131 = alloca i1
  %l132 = alloca i1
  %l135 = alloca i1
  %l138 = alloca { i1, i1 }
  %l142 = alloca i1
  %l159 = alloca i64
  %l161 = alloca i64
  %l166 = alloca %"compiler/generic:ConstAsk"
  %l170 = alloca i1
  %l178 = alloca i64
  %l193 = alloca ptr
  %l194 = alloca { i64, [2 x i64] }
  %l198 = alloca { i64, [5 x i64] }
  %l201 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l210 = alloca i64
  %l219 = alloca i64
  %l221 = alloca i64
  %l226 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l230 = alloca ptr
  %l234 = alloca ptr
  %l241 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l244 = alloca { i64, ptr }
  %l245 = alloca i64
  %l246 = alloca { i64, ptr }
  %l250 = alloca i1
  %l252 = alloca i1
  %l253 = alloca i1
  %l257 = alloca i1
  %l260 = alloca i1
  %l262 = alloca i1
  %l263 = alloca i1
  %l268 = alloca ptr
  %l269 = alloca { i64, [3 x i64] }
  %l271 = alloca i1
  %l272 = alloca %"compiler/msgs:Msg"
  %l273 = alloca %"compiler/msgs:Msg"
  %l275 = alloca %"compiler/msgs:Msg"
  %l276 = alloca %"compiler/interp:CondErr"
  %l287 = alloca i64
  %l289 = alloca i64
  %l294 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca i1
  %t49 = alloca %"compiler/interp:Exec", align 8
  %t332 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %s0, ptr %t1)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l45
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l7
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H8bd9ddbe6d7efc10dd35c4d42ad9dacf(ptr %s0, ptr %l7)
  store i64 %t6, ptr %l47
  br label %bb2
bb2:
  %t7 = load i64, ptr %l47, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 76
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l52
  br label %bb5
bb4:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb6
bb5:
  %t15 = load i64, ptr %l52, !tbaa !24
  %t16 = icmp eq i64 %t15, 0
  store i1 %t16, ptr %l49, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l49, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 39
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v1, ptr %t24)
  store i64 %t26, ptr %l58
  br label %bb9
bb8:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb10
bb9:
  %t27 = load i64, ptr %l58, !tbaa !24
  %t28 = icmp eq i64 %t27, 0
  store i1 %t28, ptr %l54, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l54, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 77
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eLen_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v1, ptr %t33)
  store i64 %t35, ptr %l63
  br label %bb13
bb12:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb14
bb13:
  %t36 = load i64, ptr %l63, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l60, !tbaa !21
  br label %bb14
bb14:
  %t39 = load i1, ptr %l60, !tbaa !21
  br i1 %t39, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 11
  %t48 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t47
  call void @compiler_2finterp_3aExec_2ector(ptr %t49, ptr %v1, ptr %v1, ptr %v1, ptr %t44, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t49, i64 976, i1 false)
  br label %bb18
bb18:
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 976, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %l71, i64 976, i1 false)
  store ptr %t53, ptr %l8, !tbaa !29
  %t55 = load ptr, ptr %l8, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 89
  %t59 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t58
  %t62 = getelementptr %"compiler/interp:Exec", ptr %t55, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %t62
  %t63 = load ptr, ptr %l8, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 93
  %t67 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t66
  %t70 = getelementptr %"compiler/interp:Exec", ptr %t63, i32 0, i32 11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %t70
  store i1 false, ptr %l9, !tbaa !21
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 77
  store ptr %t73, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load i64, ptr %l11, !tbaa !24
  store i64 %t75, ptr %l81, !tbaa !24
  %t76 = load ptr, ptr %l10, !tbaa !29
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eLen_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v1, ptr %t76)
  store i64 %t78, ptr %l83
  br label %bb20
bb20:
  %t79 = load i64, ptr %l81, !tbaa !24
  %t80 = load i64, ptr %l83, !tbaa !24
  %t81 = icmp slt i64 %t79, %t80
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t85 = load ptr, ptr %l10, !tbaa !29
  %t86 = load i64, ptr %l11, !tbaa !24
  %t89 = call %"compiler/check:EmbedAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eAt_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v1, ptr %t85, i64 %t86)
  store %"compiler/check:EmbedAsk" %t89, ptr %l88
  br label %bb24
bb24:
  %t90 = load %"compiler/check:EmbedAsk", ptr %l88
  store %"compiler/check:EmbedAsk" %t90, ptr %l12
  %t91 = getelementptr %"compiler/check:EmbedAsk", ptr %l12, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = getelementptr %"compiler/check:EmbedAsk", ptr %l12, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = sext i32 %t94 to i64
  %t99 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t92, i64 %t96)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t99, ptr %l92
  br label %bb25
bb25:
  %t100 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l92
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t100, ptr %l13
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t102 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  %t105 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4b90e82c7a9c5937397e46eef988cfe3(ptr %v5, ptr %t101, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t102)
  store i1 %t105, ptr %l95
  br label %bb26
bb26:
  %t106 = load i1, ptr %l95, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb28:
  br label %bb29
bb29:
  store i1 true, ptr %l9, !tbaa !21
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/check:EmbedAsk", ptr %l12, i32 0, i32 0
  %t109 = load i64, ptr %t108, !tbaa !24
  %t112 = call { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s3, ptr %t107, i64 %t109)
  store { { i64, ptr }, i1 } %t112, ptr %l98
  br label %bb30
bb30:
  %t113 = load { { i64, ptr }, i1 }, ptr %l98
  store { { i64, ptr }, i1 } %t113, ptr %l14
  %t114 = getelementptr { { i64, ptr }, i1 }, ptr %l14, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l99, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l100, !tbaa !24
  %t118 = load i64, ptr %l100, !tbaa !24
  %t119 = mul i64 %t118, 1
  %t120 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l101, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l100, !tbaa !24
  %t128 = mul i64 %t127, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t124, ptr %t126, i64 %t128, i1 false)
  %t129 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t129, ptr %l15, !tbaa !27
  %t130 = getelementptr { { i64, ptr }, i1 }, ptr %l14, i32 0, i32 1
  %t131 = load i1, ptr %t130, !tbaa !21
  %t133 = load ptr, ptr %l5, !tbaa !29
  store ptr %t133, ptr %l103, !tbaa !29
  %t134 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t134, ptr %l104
  br i1 %t131, label %bb31, label %bb32
bb31:
  %t137 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t137, ptr %l106, !tbaa !27
  br label %bb33
bb32:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l106, !tbaa !27
  br label %bb33
bb33:
  %t139 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t141)
  call void @olang_textcopy(ptr %t142, ptr %t140, i64 %t141)
  %t143 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t152 = load ptr, ptr %l103, !tbaa !29
  %t153 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l104
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94076cc109da9d789864820ff05c3ac1(ptr %v5, ptr %v5, ptr %t152, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t153, { i64, ptr } %t151)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l11, !tbaa !24
  br label %bb19
bb36:
  %t159 = load i1, ptr %l9, !tbaa !21
  br i1 %t159, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t162 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %l114
  br label %bb40
bb40:
  %t163 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t163, ptr %l17
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 76
  store ptr %t166, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t168 = load i64, ptr %l19, !tbaa !24
  store i64 %t168, ptr %l117, !tbaa !24
  %t169 = load ptr, ptr %l18, !tbaa !29
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %t169)
  store i64 %t171, ptr %l119
  br label %bb42
bb42:
  %t172 = load i64, ptr %l117, !tbaa !24
  %t173 = load i64, ptr %l119, !tbaa !24
  %t174 = icmp slt i64 %t172, %t173
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s9)
  br label %bb70
bb44:
  br label %bb45
bb45:
  %t178 = load ptr, ptr %l18, !tbaa !29
  %t179 = load i64, ptr %l19, !tbaa !24
  %t182 = call %"compiler/check:Ask" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %v1, ptr %t178, i64 %t179)
  store %"compiler/check:Ask" %t182, ptr %l124
  br label %bb46
bb46:
  %t183 = load %"compiler/check:Ask", ptr %l124
  store %"compiler/check:Ask" %t183, ptr %l20
  %t184 = getelementptr %"compiler/check:Ask", ptr %l20, i32 0, i32 1
  %t185 = load i64, ptr %t184, !tbaa !24
  %t186 = getelementptr %"compiler/check:Ask", ptr %l20, i32 0, i32 2
  %t187 = load i32, ptr %t186, !tbaa !23
  %t189 = sext i32 %t187 to i64
  %t192 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s9, i64 %t185, i64 %t189)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t192, ptr %l128
  br label %bb47
bb47:
  %t193 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l128
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t193, ptr %l21
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t195 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t198 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v2, ptr %t194, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t195)
  store i1 %t198, ptr %l131
  br label %bb48
bb48:
  %t199 = load i1, ptr %l131, !tbaa !21
  br i1 %t199, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb52
bb50:
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t201 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t204 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v3, ptr %t200, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t201)
  store i1 %t204, ptr %l135
  br label %bb51
bb51:
  %t205 = load i1, ptr %l135, !tbaa !21
  store i1 %t205, ptr %l132, !tbaa !21
  br label %bb52
bb52:
  %t206 = load i1, ptr %l132, !tbaa !21
  br i1 %t206, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb69
bb54:
  br label %bb55
bb55:
  %t207 = load ptr, ptr %l8, !tbaa !29
  %t208 = getelementptr %"compiler/check:Ask", ptr %l20, i32 0, i32 0
  %t209 = load i64, ptr %t208, !tbaa !24
  %t212 = call { i1, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v1, ptr %t207, i64 %t209)
  store { i1, i1 } %t212, ptr %l138
  br label %bb56
bb56:
  %t213 = load { i1, i1 }, ptr %l138
  store { i1, i1 } %t213, ptr %l22
  %t214 = getelementptr { i1, i1 }, ptr %l22, i32 0, i32 0
  %t215 = load i1, ptr %t214, !tbaa !21
  store i1 %t215, ptr %l23, !tbaa !21
  %t217 = getelementptr { i1, i1 }, ptr %l22, i32 0, i32 1
  %t218 = load i1, ptr %t217, !tbaa !21
  store i1 %t218, ptr %l24, !tbaa !21
  %t220 = load i1, ptr %l24, !tbaa !21
  br i1 %t220, label %bb57, label %bb58
bb57:
  %t222 = load ptr, ptr %l8, !tbaa !29
  %t224 = getelementptr %"compiler/interp:Exec", ptr %t222, i32 0, i32 4
  %t225 = getelementptr %"compiler/eval:Machine", ptr %t224, i32 0, i32 14
  %t226 = load i1, ptr %t225, !tbaa !21
  %t228 = xor i1 %t226, true
  store i1 %t228, ptr %l142, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb59
bb59:
  %t230 = load i1, ptr %l142, !tbaa !21
  br i1 %t230, label %bb60, label %bb61
bb60:
  %t231 = load ptr, ptr %l3, !tbaa !29
  %t232 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v3, ptr %t231, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t232, i1 true)
  br label %bb62
bb61:
  %t235 = load i1, ptr %l24, !tbaa !21
  br i1 %t235, label %bb63, label %bb64
bb62:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb68
bb63:
  %t237 = load ptr, ptr %l2, !tbaa !29
  %t238 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t239 = load i1, ptr %l23, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v2, ptr %t237, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t238, i1 %t239)
  br label %bb65
bb64:
  %t243 = getelementptr %"compiler/check:Ask", ptr %l20, i32 0, i32 3
  %t244 = load ptr, ptr %t243, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2ePush_3ccompiler_2fast_3aIf_26_3e(ptr %s0, ptr %v1, ptr %l17, ptr %t244)
  br label %bb66
bb65:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb67
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s9)
  br label %bb69
bb69:
  %t247 = load i64, ptr %l19, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l19, !tbaa !24
  br label %bb41
bb70:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr %"compiler/check:Checker", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/generic:Program", ptr %t254, i32 0, i32 39
  store ptr %t256, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s17
  %t258 = load i64, ptr %l26, !tbaa !24
  store i64 %t258, ptr %l159, !tbaa !24
  %t259 = load ptr, ptr %l25, !tbaa !29
  %t261 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v1, ptr %t259)
  store i64 %t261, ptr %l161
  br label %bb72
bb72:
  %t262 = load i64, ptr %l159, !tbaa !24
  %t263 = load i64, ptr %l161, !tbaa !24
  %t264 = icmp slt i64 %t262, %t263
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s17)
  br label %bb105
bb74:
  br label %bb75
bb75:
  %t268 = load ptr, ptr %l25, !tbaa !29
  %t269 = load i64, ptr %l26, !tbaa !24
  %t272 = call %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v1, ptr %v1, ptr %t268, i64 %t269)
  store %"compiler/generic:ConstAsk" %t272, ptr %l166
  br label %bb76
bb76:
  %t273 = load %"compiler/generic:ConstAsk", ptr %l166
  store %"compiler/generic:ConstAsk" %t273, ptr %l27
  %t274 = getelementptr %"compiler/generic:ConstAsk", ptr %l27, i32 0, i32 6
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  store { i64, ptr } %t275, ptr %l28, !tbaa !27
  %t277 = load ptr, ptr %l4, !tbaa !29
  %t278 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t281 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v4, ptr %v1, ptr %t277, { i64, ptr } %t278)
  store i1 %t281, ptr %l170
  br label %bb77
bb77:
  %t282 = load i1, ptr %l170, !tbaa !21
  br i1 %t282, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb79:
  br label %bb80
bb80:
  store i1 true, ptr %l9, !tbaa !21
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t284 = getelementptr %"compiler/generic:ConstAsk", ptr %l27, i32 0, i32 0
  %t285 = load i64, ptr %t284, !tbaa !24
  %t286 = getelementptr %"compiler/generic:ConstAsk", ptr %l27, i32 0, i32 3
  %t287 = load i64, ptr %t286, !tbaa !24
  %t288 = getelementptr %"compiler/generic:ConstAsk", ptr %l27, i32 0, i32 4
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !27
  %t290 = getelementptr %"compiler/generic:ConstAsk", ptr %l27, i32 0, i32 5
  %t291 = load { i64, ptr }, ptr %t290, !tbaa !27
  %t292 = getelementptr %"compiler/generic:ConstAsk", ptr %l27, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t294 = getelementptr %"compiler/generic:ConstAsk", ptr %l27, i32 0, i32 2
  %t295 = load i32, ptr %t294, !tbaa !23
  %t303 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t283, i64 %t285, i64 %t287, { i64, ptr } %t289, { i64, ptr } %t291, ptr %t293, i32 %t295)
  store i64 %t303, ptr %l178
  br label %bb81
bb81:
  %t304 = load i64, ptr %l178, !tbaa !24
  store i64 %t304, ptr %l29, !tbaa !24
  %t305 = load i64, ptr %l29, !tbaa !24
  %t307 = icmp slt i64 %t305, 0
  br i1 %t307, label %bb82, label %bb83
bb82:
  %t309 = load ptr, ptr %l4, !tbaa !29
  %t310 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 1
  %t313 = extractvalue { i64, ptr } %t310, 0
  %t314 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t313)
  call void @olang_textcopy(ptr %t314, ptr %t312, i64 %t313)
  %t315 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } %t316, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  %t324 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t309, { i64, ptr } %t323, i64 %t324)
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb85:
  %t328 = load i64, ptr %l29, !tbaa !24
  %t330 = trunc i64 %t328 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t332
  %t333 = getelementptr { i64, [2 x i64] }, ptr %t332, i32 0, i32 0
  store i64 0, ptr %t333
  %t335 = insertvalue { i32 } undef, i32 %t330, 0
  %t336 = getelementptr { i64, [2 x i64] }, ptr %t332, i32 0, i32 1
  store { i32 } %t335, ptr %t336
  %t337 = load { i64, [2 x i64] }, ptr %t332
  store { i64, [2 x i64] } %t337, ptr %l30
  %t339 = load ptr, ptr %l8, !tbaa !29
  %t340 = load { i64, [2 x i64] }, ptr %l30
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v1, ptr %t339, { i64, [2 x i64] } %t340)
  br label %bb86
bb86:
  %t343 = load ptr, ptr %l8, !tbaa !29
  %t345 = getelementptr %"compiler/interp:Exec", ptr %t343, i32 0, i32 4
  store ptr %t345, ptr %l193, !tbaa !29
  %t346 = load { i64, [2 x i64] }, ptr %l30
  store { i64, [2 x i64] } %t346, ptr %l194
  %t347 = icmp sge i64 0, 0
  br i1 %t347, label %bb87, label %bb88
bb87:
  %t349 = icmp sle i64 0, 1152921504606846975
  br i1 %t349, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_4d4f35a1b1719400_5211f6c42998ad34)
  unreachable
bb89:
  %t351 = mul i64 0, 8
  %t352 = call ptr @__olang_scope_alloc_zeroed(ptr %s17, i64 %t351)
  %t353 = insertvalue { i64, ptr } undef, i64 0, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t355 = load ptr, ptr %l193, !tbaa !29
  %t356 = load { i64, [2 x i64] }, ptr %l194
  %t358 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v1, ptr %s17, ptr %s17, ptr %t355, { i64, [2 x i64] } %t356, { i64, ptr } %t354)
  store { i64, [5 x i64] } %t358, ptr %l198
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_4d4f35a1b1719400_5211f6c42998ad34)
  unreachable
bb91:
  %t359 = load { i64, [5 x i64] }, ptr %l198
  %t362 = extractvalue { i64, [5 x i64] } %t359, 0
  %t363 = icmp eq i64 %t362, 0
  br i1 %t363, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t365 = load ptr, ptr %l4, !tbaa !29
  store ptr %t365, ptr %l201, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t366, 1
  %t369 = extractvalue { i64, ptr } %t366, 0
  %t370 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t369)
  call void @olang_textcopy(ptr %t370, ptr %t368, i64 %t369)
  %t371 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = extractvalue { i64, ptr } %t372, 1
  %t376 = mul i64 %t374, 1
  %t377 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t376)
  call void @llvm.memcpy.p0.p0.i64(ptr %t377, ptr %t375, i64 %t376, i1 false)
  %t378 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  store { i64, ptr } %t379, ptr %l204, !tbaa !27
  %t380 = load ptr, ptr %l8, !tbaa !29
  %t382 = getelementptr %"compiler/interp:Exec", ptr %t380, i32 0, i32 4
  %t383 = load ptr, ptr %l8, !tbaa !29
  %t385 = getelementptr %"compiler/interp:Exec", ptr %t383, i32 0, i32 4
  %t386 = getelementptr %"compiler/eval:Machine", ptr %t385, i32 0, i32 10
  %t387 = load %"compiler/eval:Ptr", ptr %t386
  %t388 = getelementptr %"compiler/generic:ConstAsk", ptr %l27, i32 0, i32 2
  %t389 = load i32, ptr %t388, !tbaa !23
  %t393 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v1, ptr %t382, %"compiler/eval:Ptr" %t387, i32 %t389)
  store i64 %t393, ptr %l210
  br label %bb95
bb95:
  %t394 = load ptr, ptr %l201, !tbaa !29
  %t395 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t396 = load i64, ptr %l210, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t394, { i64, ptr } %t395, i64 %t396)
  br label %bb96
bb96:
  br label %bb103
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t397 = load ptr, ptr %l4, !tbaa !29
  %t398 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t398, 1
  %t401 = extractvalue { i64, ptr } %t398, 0
  %t402 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t401)
  call void @olang_textcopy(ptr %t402, ptr %t400, i64 %t401)
  %t403 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t402, 1
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t407 = extractvalue { i64, ptr } %t404, 1
  %t408 = mul i64 %t406, 1
  %t409 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t408)
  call void @llvm.memcpy.p0.p0.i64(ptr %t409, ptr %t407, i64 %t408, i1 false)
  %t410 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t411 = insertvalue { i64, ptr } %t410, ptr %t409, 1
  %t412 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t397, { i64, ptr } %t411, i64 %t412)
  br label %bb101
bb101:
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_ba0df268265cfa7e_806ddae02611f59a)
  unreachable
bb103:
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb104:
  %t416 = load i64, ptr %l26, !tbaa !24
  %t418 = add i64 %t416, 1
  store i64 %t418, ptr %l26, !tbaa !24
  br label %bb71
bb105:
  store ptr %l7, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb106
bb106:
  store %olang.scope zeroinitializer, ptr %s27
  %t421 = load i64, ptr %l33, !tbaa !24
  store i64 %t421, ptr %l219, !tbaa !24
  %t422 = load ptr, ptr %l32, !tbaa !29
  %t424 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H8bd9ddbe6d7efc10dd35c4d42ad9dacf(ptr %s0, ptr %t422)
  store i64 %t424, ptr %l221
  br label %bb107
bb107:
  %t425 = load i64, ptr %l219, !tbaa !24
  %t426 = load i64, ptr %l221, !tbaa !24
  %t427 = icmp slt i64 %t425, %t426
  %t429 = xor i1 %t427, true
  br i1 %t429, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s27)
  br label %bb152
bb109:
  br label %bb110
bb110:
  %t431 = load ptr, ptr %l32, !tbaa !29
  %t432 = load i64, ptr %l33, !tbaa !24
  %t435 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H7486c711b8ab0d124cd9b327dc5d14f9(ptr %s0, ptr %t431, i64 %t432)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t435, ptr %l226
  br label %bb111
bb111:
  %t436 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l226
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t436, ptr %l34
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/load:Loader", ptr %t437, i32 0, i32 5
  %t440 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l34, i32 0, i32 0
  %t441 = load i64, ptr %t440, !tbaa !24
  %t444 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t439, i64 %t441)
  store ptr %t444, ptr %l230
  br label %bb112
bb112:
  %t445 = load ptr, ptr %l230, !tbaa !29
  %t447 = getelementptr %"compiler/load:Module", ptr %t445, i32 0, i32 8
  %t448 = load { i64, ptr }, ptr %t447, !tbaa !27
  %t449 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l34, i32 0, i32 1
  %t450 = load i32, ptr %t449, !tbaa !23
  %t453 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t448, i32 %t450)
  store ptr %t453, ptr %l234
  br label %bb113
bb113:
  %t454 = load ptr, ptr %l234, !tbaa !29
  store ptr %t454, ptr %l35, !tbaa !29
  %t455 = load ptr, ptr %l35, !tbaa !29
  %t457 = icmp eq ptr %t455, null
  br i1 %t457, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s27)
  br label %bb151
bb115:
  br label %bb116
bb116:
  %t459 = load ptr, ptr %l8, !tbaa !29
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t461 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l34, i32 0, i32 0
  %t462 = load i64, ptr %t461, !tbaa !24
  %t463 = load ptr, ptr %l35, !tbaa !29
  %t468 = call { i64, i1, { i64, ptr }, { i64, [3 x i64] } } @compiler_2finterp_2echain(ptr %v1, ptr %v1, ptr %v0, ptr %s27, ptr %t459, ptr %t460, i64 %t462, ptr %t463)
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t468, ptr %l241
  br label %bb117
bb117:
  %t469 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l241
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t469, ptr %l36
  %t470 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l36, i32 0, i32 0
  %t471 = load i64, ptr %t470, !tbaa !24
  store i64 %t471, ptr %l37, !tbaa !24
  %t473 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l36, i32 0, i32 1
  %t474 = load i1, ptr %t473, !tbaa !21
  store i1 %t474, ptr %l38, !tbaa !21
  %t476 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l36, i32 0, i32 2
  %t477 = load { i64, ptr }, ptr %t476, !tbaa !27
  store { i64, ptr } %t477, ptr %l244, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 0
  store i64 %t479, ptr %l245, !tbaa !24
  %t480 = load i64, ptr %l245, !tbaa !24
  %t481 = mul i64 %t480, 1
  %t482 = call ptr @__olang_scope_alloc_zeroed(ptr %s27, i64 %t481)
  %t483 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t484 = insertvalue { i64, ptr } %t483, ptr %t482, 1
  store { i64, ptr } %t484, ptr %l246, !tbaa !27
  %t485 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = load i64, ptr %l245, !tbaa !24
  %t490 = mul i64 %t489, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t486, ptr %t488, i64 %t490, i1 false)
  %t491 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t491, ptr %l39, !tbaa !27
  %t492 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l36, i32 0, i32 3
  %t493 = load { i64, [3 x i64] }, ptr %t492
  store { i64, [3 x i64] } %t493, ptr %l40
  %t495 = load i1, ptr %l38, !tbaa !21
  %t497 = xor i1 %t495, true
  br i1 %t497, label %bb118, label %bb119
bb118:
  %t499 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t501 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s27, ptr %s27, { i64, ptr } %t499, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t501, ptr %l252
  br label %bb120
bb119:
  store i1 false, ptr %l250, !tbaa !21
  br label %bb121
bb120:
  %t502 = load i1, ptr %l252, !tbaa !21
  store i1 %t502, ptr %l250, !tbaa !21
  br label %bb121
bb121:
  %t503 = load i1, ptr %l250, !tbaa !21
  br i1 %t503, label %bb122, label %bb123
bb122:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/load:Loader", ptr %t504, i32 0, i32 4
  %t507 = load ptr, ptr %t506, !tbaa !29
  %t508 = load { i64, [3 x i64] }, ptr %l40
  %t511 = call i1 @compiler_2finterp_2econdSaid(ptr %v0, ptr %t507, { i64, [3 x i64] } %t508)
  store i1 %t511, ptr %l257
  br label %bb124
bb123:
  store i1 false, ptr %l253, !tbaa !21
  br label %bb125
bb124:
  %t512 = load i1, ptr %l257, !tbaa !21
  store i1 %t512, ptr %l253, !tbaa !21
  br label %bb125
bb125:
  %t513 = load i1, ptr %l253, !tbaa !21
  br i1 %t513, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s27)
  br label %bb151
bb127:
  br label %bb128
bb128:
  %t514 = load i1, ptr %l38, !tbaa !21
  %t516 = xor i1 %t514, true
  br i1 %t516, label %bb129, label %bb130
bb129:
  %t518 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t520 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s27, ptr %s27, { i64, ptr } %t518, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t520, ptr %l262
  br label %bb131
bb130:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb132
bb131:
  %t521 = load i1, ptr %l262, !tbaa !21
  store i1 %t521, ptr %l260, !tbaa !21
  br label %bb132
bb132:
  %t522 = load i1, ptr %l260, !tbaa !21
  br i1 %t522, label %bb133, label %bb134
bb133:
  %t523 = load ptr, ptr %l1, !tbaa !29
  %t525 = getelementptr %"compiler/check:Checker", ptr %t523, i32 0, i32 88
  %t526 = load i1, ptr %t525, !tbaa !21
  store i1 %t526, ptr %l263, !tbaa !21
  br label %bb135
bb134:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb135
bb135:
  %t528 = load i1, ptr %l263, !tbaa !21
  br i1 %t528, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s27)
  br label %bb151
bb137:
  br label %bb138
bb138:
  %t529 = load i1, ptr %l38, !tbaa !21
  %t531 = xor i1 %t529, true
  br i1 %t531, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s31
  store ptr %a6, ptr %l268, !tbaa !29
  %t534 = load { i64, [3 x i64] }, ptr %l40
  store { i64, [3 x i64] } %t534, ptr %l269
  %t535 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t537 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s27, ptr %s31, { i64, ptr } %t535, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store i1 %t537, ptr %l271
  br label %bb141
bb140:
  br label %bb149
bb141:
  %t538 = load i1, ptr %l271, !tbaa !21
  br i1 %t538, label %bb142, label %bb143
bb142:
  %t539 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnseen(ptr %v6)
  store %"compiler/msgs:Msg" %t539, ptr %l273
  br label %bb144
bb143:
  %t540 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t542 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUndecidable(ptr %s27, ptr %v6, { i64, ptr } %t540)
  store %"compiler/msgs:Msg" %t542, ptr %l275
  br label %bb145
bb144:
  %t543 = load %"compiler/msgs:Msg", ptr %l273
  store %"compiler/msgs:Msg" %t543, ptr %l272
  br label %bb146
bb145:
  %t544 = load %"compiler/msgs:Msg", ptr %l275
  store %"compiler/msgs:Msg" %t544, ptr %l272
  br label %bb146
bb146:
  %t545 = load { i64, [3 x i64] }, ptr %l269
  %t546 = load %"compiler/msgs:Msg", ptr %l272
  %t547 = call %"compiler/interp:CondErr" @compiler_2finterp_3aCondErr_2ector(ptr %v6, ptr %v6, { i64, [3 x i64] } %t545, %"compiler/msgs:Msg" %t546)
  store %"compiler/interp:CondErr" %t547, ptr %l276
  br label %bb147
bb147:
  %t548 = load ptr, ptr %l268, !tbaa !29
  %t549 = load %"compiler/interp:CondErr", ptr %l276
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2ePush_3ccompiler_2finterp_3aCondErr_3e(ptr %v6, ptr %v6, ptr %t548, %"compiler/interp:CondErr" %t549)
  br label %bb148
bb148:
  %t550 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store i64 %t550, ptr %l37, !tbaa !24
  call void @__olang_scope_close(ptr %s31)
  br label %bb149
bb149:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l34, i32 0, i32 0
  %t554 = load i64, ptr %t553, !tbaa !24
  %t555 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l34, i32 0, i32 1
  %t556 = load i32, ptr %t555, !tbaa !23
  %t557 = load i64, ptr %l37, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %t552, i64 %t554, i32 %t556, i64 %t557)
  br label %bb150
bb150:
  store i1 true, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s27)
  br label %bb151
bb151:
  %t562 = load i64, ptr %l33, !tbaa !24
  %t564 = add i64 %t562, 1
  store i64 %t564, ptr %l33, !tbaa !24
  br label %bb106
bb152:
  %t566 = load i1, ptr %l9, !tbaa !21
  %t568 = xor i1 %t566, true
  br i1 %t568, label %bb153, label %bb154
bb153:
  store ptr %l17, ptr %l41, !tbaa !29
  store i64 0, ptr %l42, !tbaa !24
  br label %bb155
bb154:
  br label %bb164
bb155:
  %t571 = load i64, ptr %l42, !tbaa !24
  store i64 %t571, ptr %l287, !tbaa !24
  %t572 = load ptr, ptr %l41, !tbaa !29
  %t574 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2eLen_3ccompiler_2fast_3aIf_26_3e(ptr %s0, ptr %t572)
  store i64 %t574, ptr %l289
  br label %bb156
bb156:
  %t575 = load i64, ptr %l287, !tbaa !24
  %t576 = load i64, ptr %l289, !tbaa !24
  %t577 = icmp slt i64 %t575, %t576
  %t579 = xor i1 %t577, true
  br i1 %t579, label %bb157, label %bb158
bb157:
  br label %bb163
bb158:
  br label %bb159
bb159:
  %t581 = load ptr, ptr %l41, !tbaa !29
  %t582 = load i64, ptr %l42, !tbaa !24
  %t585 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2eAt_3ccompiler_2fast_3aIf_26_3e(ptr %s0, ptr %s0, ptr %t581, i64 %t582)
  store ptr %t585, ptr %l294
  br label %bb160
bb160:
  %t586 = load ptr, ptr %l294, !tbaa !29
  %t587 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v1, ptr %s0, ptr %t587, ptr %t586)
  br label %bb161
bb161:
  br label %bb162
bb162:
  %t591 = load i64, ptr %l42, !tbaa !24
  %t593 = add i64 %t591, 1
  store i64 %t593, ptr %l42, !tbaa !24
  br label %bb155
bb163:
  br label %bb164
bb164:
  %t595 = load i1, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t595, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2finterp_2edecideContracts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/check:ContractAsk"
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l13 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [3 x i64] }
  %l17 = alloca i64
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca %"compiler/check:ContractAsk"
  %l57 = alloca i1
  %l65 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l70 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l73 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca { i64, [2 x i64] }
  %l94 = alloca { i64, [5 x i64] }
  %l104 = alloca i64
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca { i64, [3 x i64] }
  %l120 = alloca %"compiler/msgs:Msg"
  %l121 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca { i64, [3 x i64] }
  %l128 = alloca %"compiler/msgs:Msg"
  %l129 = alloca i64
  %l130 = alloca ptr
  %l131 = alloca i64
  %l137 = alloca { i64, [3 x i64] }
  %l138 = alloca %"compiler/msgs:Msg"
  %l140 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i64
  %l144 = alloca { i64, [3 x i64] }
  %l145 = alloca %"compiler/msgs:Msg"
  %l148 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  %t70 = alloca %"compiler/check:ContractAsk", align 8
  %t139 = alloca { i64, [2 x i64] }, align 8
  %t207 = alloca { i64, [3 x i64] }, align 8
  %t267 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l22
  br label %bb1
bb1:
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 82
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l25
  br label %bb2
bb2:
  %t19 = load i64, ptr %l25, !tbaa !24
  store i64 %t19, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb5:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l32, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l32, !tbaa !24
  store i64 %t46, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l29, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 82
  %t69 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eAt_H56c1cddaee4bc4aa5c09605de1331e44(ptr %t70, ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  call void @llvm.memmove.p0.p0.i64(ptr %l53, ptr %t70, i64 136, i1 false)
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l53, i64 136, i1 false)
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 84
  %t76 = load i64, ptr %l10, !tbaa !24
  %t79 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t75, i64 %t76)
  store i1 %t79, ptr %l57
  br label %bb14
bb14:
  %t80 = load i1, ptr %l57, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb16:
  br label %bb17
bb17:
  %t81 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 2
  %t84 = getelementptr %"compiler/source:Span", ptr %t83, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t89 = shl i64 %t87, 32
  %t90 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 4
  %t91 = getelementptr %"compiler/source:Span", ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = sext i32 %t92 to i64
  %t97 = or i64 %t89, %t94
  %t100 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t82, i64 %t97)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t100, ptr %l65
  br label %bb18
bb18:
  %t101 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l65
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t101, ptr %l12
  %t102 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 2
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t110 = shl i64 %t108, 32
  %t113 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t103, i64 %t110)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t113, ptr %l70
  br label %bb19
bb19:
  %t114 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l70
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l13
  %t115 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  %t118 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t115)
  store i1 %t118, ptr %l73
  br label %bb20
bb20:
  %t119 = load i1, ptr %l73, !tbaa !21
  br i1 %t119, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb28
bb22:
  %t120 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 5
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t121, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store i1 %t123, ptr %l76
  br label %bb23
bb23:
  %t124 = load i1, ptr %l76, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  %t127 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  %t130 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t127)
  store i1 %t130, ptr %l81
  br label %bb26
bb25:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb27
bb26:
  %t131 = load i1, ptr %l81, !tbaa !21
  store i1 %t131, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t132 = load i1, ptr %l78, !tbaa !21
  store i1 %t132, ptr %l74, !tbaa !21
  br label %bb28
bb28:
  %t133 = load i1, ptr %l74, !tbaa !21
  br i1 %t133, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb30:
  br label %bb31
bb31:
  %t134 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 0
  %t135 = load i64, ptr %t134, !tbaa !24
  %t137 = trunc i64 %t135 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [2 x i64] }, ptr %t139, i32 0, i32 0
  store i64 0, ptr %t140
  %t142 = insertvalue { i32 } undef, i32 %t137, 0
  %t143 = getelementptr { i64, [2 x i64] }, ptr %t139, i32 0, i32 1
  store { i32 } %t142, ptr %t143
  %t144 = load { i64, [2 x i64] }, ptr %t139
  store { i64, [2 x i64] } %t144, ptr %l14
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t147 = load { i64, [2 x i64] }, ptr %l14
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v1, ptr %t146, { i64, [2 x i64] } %t147)
  br label %bb32
bb32:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/interp:Exec", ptr %t150, i32 0, i32 4
  store ptr %t152, ptr %l89, !tbaa !29
  %t153 = load { i64, [2 x i64] }, ptr %l14
  store { i64, [2 x i64] } %t153, ptr %l90
  %t154 = icmp sge i64 0, 0
  br i1 %t154, label %bb33, label %bb34
bb33:
  %t156 = icmp sle i64 0, 1152921504606846975
  br i1 %t156, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d213ae2acd73c837_819e6544d8b9fb33)
  unreachable
bb35:
  %t158 = mul i64 0, 8
  %t159 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 0, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load ptr, ptr %l89, !tbaa !29
  %t163 = load { i64, [2 x i64] }, ptr %l90
  %t165 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v1, ptr %v1, ptr %v1, ptr %t162, { i64, [2 x i64] } %t163, { i64, ptr } %t161)
  store { i64, [5 x i64] } %t165, ptr %l94
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d213ae2acd73c837_819e6544d8b9fb33)
  unreachable
bb37:
  %t166 = load { i64, [5 x i64] }, ptr %l94
  %t169 = extractvalue { i64, [5 x i64] } %t166, 0
  %t170 = icmp eq i64 %t169, 0
  br i1 %t170, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb64
bb40:
  store %olang.scope zeroinitializer, ptr %s5
  %t172 = load i64, ptr %l4, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l4, !tbaa !24
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/interp:Exec", ptr %t176, i32 0, i32 4
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/interp:Exec", ptr %t179, i32 0, i32 4
  %t182 = getelementptr %"compiler/eval:Machine", ptr %t181, i32 0, i32 10
  %t183 = load %"compiler/eval:Ptr", ptr %t182
  %t184 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t188 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v1, ptr %t178, %"compiler/eval:Ptr" %t183, i32 %t184)
  store i64 %t188, ptr %l104
  br label %bb41
bb41:
  %t189 = load i64, ptr %l104, !tbaa !24
  %t190 = icmp ne i64 %t189, 0
  br i1 %t190, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb43:
  br label %bb44
bb44:
  %t192 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t192, i1 true)
  br label %bb45
bb45:
  %t195 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 1
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 2
  %t198 = getelementptr %"compiler/source:Span", ptr %t197, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = sext i32 %t199 to i64
  %t202 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 2
  %t203 = getelementptr %"compiler/source:Span", ptr %t202, i32 0, i32 1
  %t204 = load i32, ptr %t203, !tbaa !23
  %t206 = sext i32 %t204 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 0
  store i64 3, ptr %t208
  %t210 = insertvalue { i64, i64, i64 } undef, i64 %t196, 0
  %t212 = insertvalue { i64, i64, i64 } %t210, i64 %t201, 1
  %t214 = insertvalue { i64, i64, i64 } %t212, i64 %t206, 2
  %t215 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 1
  store { i64, i64, i64 } %t214, ptr %t215
  %t216 = load { i64, [3 x i64] }, ptr %t207
  store { i64, [3 x i64] } %t216, ptr %l16
  %t218 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 5
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t219, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t221, ptr %l115
  br label %bb46
bb46:
  %t222 = load i1, ptr %l115, !tbaa !21
  br i1 %t222, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t223 = load ptr, ptr %l2, !tbaa !29
  store ptr %t223, ptr %l116, !tbaa !29
  %t224 = load { i64, [3 x i64] }, ptr %l16
  store { i64, [3 x i64] } %t224, ptr %l117
  %t225 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 6
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t227 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 9
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  %t231 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConversionDoesNotFit(ptr %v0, ptr %v0, ptr %s7, { i64, ptr } %t226, { i64, ptr } %t228)
  store %"compiler/msgs:Msg" %t231, ptr %l120
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t232 = load ptr, ptr %l116, !tbaa !29
  %t233 = load { i64, [3 x i64] }, ptr %l117
  %t234 = load %"compiler/msgs:Msg", ptr %l120
  %t235 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t232, { i64, [3 x i64] } %t233, %"compiler/msgs:Msg" %t234)
  store i64 %t235, ptr %l121
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb51:
  %t236 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t236, i1 true)
  br label %bb52
bb52:
  %t239 = load ptr, ptr %l2, !tbaa !29
  store ptr %t239, ptr %l124, !tbaa !29
  %t240 = load { i64, [3 x i64] }, ptr %l16
  store { i64, [3 x i64] } %t240, ptr %l125
  %t241 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 6
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  %t243 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 5
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  %t247 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractFalse(ptr %v0, ptr %v0, ptr %s5, { i64, ptr } %t242, { i64, ptr } %t244)
  store %"compiler/msgs:Msg" %t247, ptr %l128
  br label %bb53
bb53:
  %t248 = load ptr, ptr %l124, !tbaa !29
  %t249 = load { i64, [3 x i64] }, ptr %l125
  %t250 = load %"compiler/msgs:Msg", ptr %l128
  %t251 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t248, { i64, [3 x i64] } %t249, %"compiler/msgs:Msg" %t250)
  store i64 %t251, ptr %l129
  br label %bb54
bb54:
  %t252 = load i64, ptr %l129, !tbaa !24
  store i64 %t252, ptr %l17, !tbaa !24
  %t253 = load ptr, ptr %l2, !tbaa !29
  store ptr %t253, ptr %l130, !tbaa !29
  %t254 = load i64, ptr %l17, !tbaa !24
  store i64 %t254, ptr %l131, !tbaa !24
  %t255 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 3
  %t256 = load i64, ptr %t255, !tbaa !24
  %t257 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 4
  %t258 = getelementptr %"compiler/source:Span", ptr %t257, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = sext i32 %t259 to i64
  %t262 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 4
  %t263 = getelementptr %"compiler/source:Span", ptr %t262, i32 0, i32 1
  %t264 = load i32, ptr %t263, !tbaa !23
  %t266 = sext i32 %t264 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t267
  %t268 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 0
  store i64 3, ptr %t268
  %t270 = insertvalue { i64, i64, i64 } undef, i64 %t256, 0
  %t272 = insertvalue { i64, i64, i64 } %t270, i64 %t261, 1
  %t274 = insertvalue { i64, i64, i64 } %t272, i64 %t266, 2
  %t275 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 1
  store { i64, i64, i64 } %t274, ptr %t275
  %t276 = load { i64, [3 x i64] }, ptr %t267
  store { i64, [3 x i64] } %t276, ptr %l137
  %t277 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteContractCondition(ptr %s5)
  store %"compiler/msgs:Msg" %t277, ptr %l138
  br label %bb55
bb55:
  %t278 = load ptr, ptr %l130, !tbaa !29
  %t279 = load i64, ptr %l131, !tbaa !24
  %t280 = load { i64, [3 x i64] }, ptr %l137
  %t281 = load %"compiler/msgs:Msg", ptr %l138
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s5, ptr %t278, i64 %t279, { i64, [3 x i64] } %t280, %"compiler/msgs:Msg" %t281)
  br label %bb56
bb56:
  %t282 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 8
  %t283 = load { i64, ptr }, ptr %t282, !tbaa !27
  %t285 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t283, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t285, ptr %l140
  br label %bb57
bb57:
  %t286 = load i1, ptr %l140, !tbaa !21
  %t287 = xor i1 %t286, true
  br i1 %t287, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t289 = load ptr, ptr %l2, !tbaa !29
  store ptr %t289, ptr %l142, !tbaa !29
  %t290 = load i64, ptr %l17, !tbaa !24
  store i64 %t290, ptr %l143, !tbaa !24
  %t291 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 7
  %t292 = load { i64, [3 x i64] }, ptr %t291
  store { i64, [3 x i64] } %t292, ptr %l144
  %t293 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s8)
  store %"compiler/msgs:Msg" %t293, ptr %l145
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t294 = getelementptr %"compiler/msgs:Msg", ptr %l145, i32 0, i32 0
  %t295 = load i32, ptr %t294
  %t296 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 8
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  %t300 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s8, ptr %v0, ptr %s8, i32 %t295, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) }, { i64, ptr } %t297)
  store %"compiler/msgs:Msg" %t300, ptr %l148
  br label %bb61
bb61:
  %t301 = load ptr, ptr %l142, !tbaa !29
  %t302 = load i64, ptr %l143, !tbaa !24
  %t303 = load { i64, [3 x i64] }, ptr %l144
  %t304 = load %"compiler/msgs:Msg", ptr %l148
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t301, i64 %t302, { i64, [3 x i64] } %t303, %"compiler/msgs:Msg" %t304)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s8)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s5)
  br label %bb69
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_3238838aabc16991_ed85858096edfcc5)
  unreachable
bb69:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb70:
  %t305 = load i64, ptr %l9, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l9, !tbaa !24
  br label %bb9
bb71:
  %t309 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t309, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i1
  %l38 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb34
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l19, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 7
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [6 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb27
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TopIf", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TopIf", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_ef1298413c90a2dc_ba44d1693e670768)
  unreachable
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l6, !tbaa !29
  %t63 = getelementptr %"compiler/ast:TopIf", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t64)
  store %"compiler/source:Span" %t66, ptr %l38
  br label %bb18
bb18:
  %t67 = getelementptr %"compiler/source:Span", ptr %l38, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = icmp eq i32 %t68, %t69
  store i1 %t72, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t74 = load i1, ptr %l32, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t75 = load ptr, ptr %l6, !tbaa !29
  store ptr %t75, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t78 = load ptr, ptr %l6, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %t78, i32 %t80)
  store ptr %t83, ptr %l47
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l47, !tbaa !29
  store ptr %t84, ptr %l7, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l7, !tbaa !29
  store ptr %t91, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2f4ce1a9e181e1f2_bd4ae6421df971e)
  unreachable
bb32:
  br label %bb33
bb33:
  %t94 = load i64, ptr %l3, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l3, !tbaa !24
  br label %bb4
bb34:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l19 = alloca ptr
  %l37 = alloca ptr
  %l46 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/ast:TopIf", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/ast:TopIf", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb6, label %bb7
bb5:
  br label %bb13
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6beaad51a5cbbd4f_ba25a08250cd8123)
  unreachable
bb7:
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/ast:TopIf", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/ast:TopBranch", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t29, i32 %t30)
  store ptr %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l19, !tbaa !29
  store ptr %t34, ptr %l2, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TopIf", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/ast:TopIf", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb16, label %bb17
bb15:
  br label %bb23
bb16:
  call void @__olang_check_failed(ptr @olang_loc_337e2febbb969070_fe2fc98a6d253614)
  unreachable
bb17:
  br label %bb18
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t66 = getelementptr %"compiler/ast:TopBranch", ptr %t63, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t67, i32 %t68)
  store ptr %t71, ptr %l37
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l37, !tbaa !29
  store ptr %t72, ptr %l3, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l3, !tbaa !29
  store ptr %t79, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/ast:TopIf", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %t85, i32 %t86)
  store ptr %t89, ptr %l46
  br label %bb24
bb24:
  %t90 = load ptr, ptr %l46, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2finterp_2efindTest(ptr %v0, { i64, ptr } %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/source:Span"
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca %"compiler/source:Span"
  %l36 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca %"compiler/source:Span"
  %l53 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t8 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb35
bb7:
  br label %bb8
bb8:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l21, !tbaa !27
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l5, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  store ptr %t31, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t32 = load ptr, ptr %l24, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 6
  store i1 %t38, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l25, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr { i64, [6 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l6
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t48 = getelementptr { i64, [6 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t48, i32 0, i32 1
  %t50 = load %"compiler/source:Span", ptr %t49
  store %"compiler/source:Span" %t50, ptr %l7
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t52 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t52, ptr %l32
  %t53 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t53, ptr %l34
  %t56 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l32, ptr %l34)
  store i1 %t56, ptr %l36
  br label %bb14
bb14:
  %t57 = load i1, ptr %l36, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load %"compiler/source:Span", ptr %l7
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t58, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb33
bb18:
  %t60 = load ptr, ptr %l5, !tbaa !29
  store ptr %t60, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 7
  store i1 %t67, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l39, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr { i64, [6 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr }, ptr %t71, i32 0, i32 1
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l8, !tbaa !29
  br label %bb23
bb22:
  br label %bb28
bb23:
  %t75 = load ptr, ptr %l8, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  %t80 = call %"compiler/source:Span" @compiler_2finterp_2efindTestIf(ptr %v0, ptr %t75, %"compiler/source:Span" %t77)
  store %"compiler/source:Span" %t80, ptr %l47
  br label %bb24
bb24:
  %t81 = load %"compiler/source:Span", ptr %l47
  store %"compiler/source:Span" %t81, ptr %l9
  %t82 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 1
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = icmp sgt i32 %t83, 0
  br i1 %t85, label %bb25, label %bb26
bb25:
  %t87 = load %"compiler/source:Span", ptr %l9
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t87, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_972a61363a9ec592_fd7ddbe7b61f56ae)
  unreachable
bb33:
  br label %bb34
bb34:
  %t89 = load i64, ptr %l3, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l3, !tbaa !24
  br label %bb5
bb35:
  %t93 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t93, ptr %l53
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t94, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2finterp_2efindTestIf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l19 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l6
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  %t6 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/ast:TopIf", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb7, label %bb8
bb6:
  br label %bb14
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2a2178e5d5b03d3c_5603e1310e4875e0)
  unreachable
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopIf", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TopBranch", ptr %t26, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t31 = load %"compiler/source:Span", ptr %l1
  %t34 = call %"compiler/source:Span" @compiler_2finterp_2efindTest(ptr %v0, { i64, ptr } %t30, %"compiler/source:Span" %t31)
  store %"compiler/source:Span" %t34, ptr %l19
  br label %bb10
bb10:
  %t35 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t35, ptr %l2
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t37 = load i32, ptr %t36, !tbaa !23
  %t39 = icmp sgt i32 %t37, 0
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t41 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t41, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TopIf", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/ast:TopIf", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb17, label %bb18
bb16:
  br label %bb24
bb17:
  call void @__olang_check_failed(ptr @olang_loc_17914f4f6ca28ab_f546bfb1cda272ff)
  unreachable
bb18:
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = getelementptr %"compiler/ast:TopBranch", ptr %t62, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t67 = load %"compiler/source:Span", ptr %l1
  %t70 = call %"compiler/source:Span" @compiler_2finterp_2efindTest(ptr %v0, { i64, ptr } %t66, %"compiler/source:Span" %t67)
  store %"compiler/source:Span" %t70, ptr %l35
  br label %bb20
bb20:
  %t71 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t71, ptr %l3
  %t72 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t73 = load i32, ptr %t72, !tbaa !23
  %t75 = icmp sgt i32 %t73, 0
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t77, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l1
  %t86 = call %"compiler/source:Span" @compiler_2finterp_2efindTestIf(ptr %v0, ptr %t82, %"compiler/source:Span" %t83)
  store %"compiler/source:Span" %t86, ptr %l42
  br label %bb25
bb25:
  %t87 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t87, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, i32 }
  %l4 = alloca { i64, i32 }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %a0)
  store { i64, i32 } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, i32 }, ptr %l4
  store { i64, i32 } %t4, ptr %l1
  %t5 = getelementptr { i64, i32 }, ptr %l1, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i32
  %rv = alloca { i64, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l1
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64, i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l2, !tbaa !24
  %t15 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i32, ptr %l3, !tbaa !23
  %t22 = insertvalue { i64, i32 } undef, i64 %t19, 0
  %t24 = insertvalue { i64, i32 } %t22, i32 %t20, 1
  store { i64, i32 } %t24, ptr %rv
  br label %ret
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t26 = insertvalue { i64, i32 } undef, i64 -1, 0
  %t27 = insertvalue { i64, i32 } %t26, i32 0, 1
  store { i64, i32 } %t27, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c5607a0551bceea3_a83aa459e58f2847)
  unreachable
ret:
  %rr = load { i64, i32 }, ptr %rv
  ret { i64, i32 } %rr
}

define dso_local i32 @compiler_2finterp_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l23 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l48 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_4efe4c4a78894057_5e75e4c074554d53)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 11
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Block", ptr %t11, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 %t30
  %t35 = load ptr, ptr %t34, !tbaa !39
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 1
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t48, i32 0, i32 1
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t51 = load ptr, ptr %l32, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb12:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i64, ptr %t54
  %t57 = icmp eq i64 %t55, 1
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l30, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t66, i32 0, i32 1
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l7, !tbaa !23
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i64, ptr %t77
  store i64 %t78, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l6, !tbaa !29
  %t82 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t82, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t86, i32 0, i32 3
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l9, !tbaa !23
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp eq i64 %t90, %a1
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load i32, ptr %l9, !tbaa !23
  %t100 = icmp eq i32 %t96, %a2
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t102 = load i1, ptr %l48, !tbaa !21
  br i1 %t102, label %bb21, label %bb22
bb21:
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_1ec4d19c7606c42f_38a78c76cd6682ab)
  unreachable
bb29:
  br label %bb30
bb30:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l4, !tbaa !24
  br label %bb4
bb31:
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2finterp_2ejudgeViews(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca %"compiler/views:Viewer"
  %t9 = alloca %"compiler/views:Viewer", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 11
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7
  call void @compiler_2fviews_3aViewer_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v0, ptr %t4, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t9, i64 216, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 216, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l6, i64 216, i1 false)
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %t12)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t10 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %a0, i64 %a1, i64 %t6)
  store { i64, ptr } %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l13
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store i64 %t15, ptr %l12
  br label %bb2
bb2:
  %t19 = load i64, ptr %l12, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l10, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %l17, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = icmp sge i64 0, 0
  br i1 %t28, label %bb8, label %bb9
bb7:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = extractvalue { i64, ptr } %t30, 0
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t32, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l16, !tbaa !27
  br label %bb14
bb8:
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sle i64 0, %t38
  br i1 %t39, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_33cf42576bc92052_8a57929dd960fbd6)
  unreachable
bb10:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = load i64, ptr %l18, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_33cf42576bc92052_8a57929dd960fbd6)
  unreachable
bb12:
  %t45 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l17, !tbaa !24
  %t48 = getelementptr i8, ptr %t46, i64 0
  %t49 = sub i64 %t47, 0
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l16, !tbaa !27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_33cf42576bc92052_8a57929dd960fbd6)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l11 = alloca i1
  %l16 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l30 = alloca { i64, [3 x i64] }
  %l31 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %t47 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i64 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t5, %t6
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t20 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t11, i64 %t12, i64 %t16)
  store i64 %t20, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t21, i64 %t22, i64 %t26)
  store i64 %t30, ptr %l21
  br label %bb7
bb7:
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = icmp eq i64 %t31, %t32
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i64 %a1, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t40 = load i32, ptr %t39, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = sext i32 %t44 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 0
  store i64 3, ptr %t48
  %t50 = insertvalue { i64, i64, i64 } undef, i64 %t38, 0
  %t52 = insertvalue { i64, i64, i64 } %t50, i64 %t42, 1
  %t54 = insertvalue { i64, i64, i64 } %t52, i64 %t46, 2
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  store { i64, i64, i64 } %t54, ptr %t55
  %t56 = load { i64, [3 x i64] }, ptr %t47
  store { i64, [3 x i64] } %t56, ptr %l30
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s0)
  store %"compiler/msgs:Msg" %t57, ptr %l31
  br label %bb12
bb12:
  %t58 = load ptr, ptr %l23, !tbaa !29
  %t59 = load i64, ptr %l24, !tbaa !24
  %t60 = load { i64, [3 x i64] }, ptr %l30
  %t61 = load %"compiler/msgs:Msg", ptr %l31
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t58, i64 %t59, { i64, [3 x i64] } %t60, %"compiler/msgs:Msg" %t61)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_53f8f52e2a7db594_7d67e05921593da8)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_937c5ec6da42b121_d38194c1cca770f5)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, %"compiler/source:Span" }
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l15 = alloca { i64, [3 x i64] }
  %l16 = alloca %"compiler/msgs:Msg"
  %l19 = alloca { i64, %"compiler/source:Span" }
  %l24 = alloca ptr
  %l25 = alloca i64
  %l31 = alloca { i64, [3 x i64] }
  %l32 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t12 = alloca { i64, [3 x i64] }, align 8
  %t54 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  store i64 %t2, ptr %l9, !tbaa !24
  %t4 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t8 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t15 = insertvalue { i64, i64, i64 } undef, i64 %a3, 0
  %t17 = insertvalue { i64, i64, i64 } %t15, i64 %t7, 1
  %t19 = insertvalue { i64, i64, i64 } %t17, i64 %t11, 2
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t12, i32 0, i32 1
  store { i64, i64, i64 } %t19, ptr %t20
  %t21 = load { i64, [3 x i64] }, ptr %t12
  store { i64, [3 x i64] } %t21, ptr %l15
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s0)
  store %"compiler/msgs:Msg" %t22, ptr %l16
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l8, !tbaa !29
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = load { i64, [3 x i64] }, ptr %l15
  %t26 = load %"compiler/msgs:Msg", ptr %l16
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v1, ptr %s0, ptr %t23, i64 %t24, { i64, [3 x i64] } %t25, %"compiler/msgs:Msg" %t26)
  br label %bb2
bb2:
  %t29 = getelementptr %"compiler/interp:Exec", ptr %a0, i32 0, i32 4
  %t31 = call { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %t29)
  store { i64, %"compiler/source:Span" } %t31, ptr %l19
  br label %bb3
bb3:
  %t32 = load { i64, %"compiler/source:Span" }, ptr %l19
  store { i64, %"compiler/source:Span" } %t32, ptr %l5
  %t33 = getelementptr { i64, %"compiler/source:Span" }, ptr %l5, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, %"compiler/source:Span" }, ptr %l5, i32 0, i32 1
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l7
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l25, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t50 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = sext i32 %t51 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 0
  store i64 3, ptr %t55
  %t57 = insertvalue { i64, i64, i64 } undef, i64 %t45, 0
  %t59 = insertvalue { i64, i64, i64 } %t57, i64 %t49, 1
  %t61 = insertvalue { i64, i64, i64 } %t59, i64 %t53, 2
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 1
  store { i64, i64, i64 } %t61, ptr %t62
  %t63 = load { i64, [3 x i64] }, ptr %t54
  store { i64, [3 x i64] } %t63, ptr %l31
  %t64 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrewHere(ptr %s1)
  store %"compiler/msgs:Msg" %t64, ptr %l32
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t65 = load ptr, ptr %l24, !tbaa !29
  %t66 = load i64, ptr %l25, !tbaa !24
  %t67 = load { i64, [3 x i64] }, ptr %l31
  %t68 = load %"compiler/msgs:Msg", ptr %l32
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v1, ptr %s1, ptr %t65, i64 %t66, { i64, [3 x i64] } %t67, %"compiler/msgs:Msg" %t68)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %v1, { i64, [5 x i64] } %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca { i64, [5 x i64] }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, ptr }
  %l13 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l34 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  store { i64, [5 x i64] } %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t7 = load %"compiler/source:Span", ptr %l1
  %t9 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t6, 0
  %t10 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t9, i64 -1, 1
  %t12 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t10, %"compiler/source:Span" %t7, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t12, ptr %l13
  %t13 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l14, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13, i32 0, i32 0
  store { i64, ptr } %t28, ptr %t29, !tbaa !27
  %t30 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t30, ptr %rv
  br label %ret
bb4:
  %t31 = load { i64, [5 x i64] }, ptr %l0
  %t33 = extractvalue { i64, [5 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 3
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t36 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t37 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t36, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37
  store { i64, ptr } %t38, ptr %l2, !tbaa !27
  %t40 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t41 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t40, i32 0, i32 1
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t44, i32 0, i32 2
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l4
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = extractvalue { i64, ptr } %t48, 0
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t50, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load %"compiler/source:Span", ptr %l4
  %t58 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t54, 0
  %t60 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t58, i64 %t55, 1
  %t62 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t60, %"compiler/source:Span" %t56, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t62, ptr %rv
  br label %ret
bb8:
  %t64 = load { i64, [5 x i64] }, ptr %l0
  %t66 = extractvalue { i64, [5 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 2
  br i1 %t67, label %bb9, label %bb10
bb9:
  %t69 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t70 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l5
  %t73 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t74 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t73, i32 0, i32 1
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t78 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t77, i32 0, i32 2
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l7
  br label %bb11
bb10:
  br label %bb19
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load i32, ptr %l5
  %t83 = trunc i64 3 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb12, label %bb13
bb12:
  %t86 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t92 = icmp eq i32 %t87, %t89
  store i1 %t92, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t94 = load i1, ptr %l34, !tbaa !21
  br i1 %t94, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t96 = load %"compiler/source:Span", ptr %l1
  %t98 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t95, 0
  %t99 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t98, i64 -1, 1
  %t101 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t99, %"compiler/source:Span" %t96, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t101, ptr %l41
  %t102 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l41, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l42, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l43, !tbaa !24
  %t106 = load i64, ptr %l43, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l44, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l43, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t118 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l41, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  %t119 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l41
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t119, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t120 = load i32, ptr %l5
  %t122 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s4, i32 %t120)
  store { i64, ptr } %t122, ptr %l46
  br label %bb18
bb18:
  %t123 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t129 = load i64, ptr %l6, !tbaa !24
  %t130 = load %"compiler/source:Span", ptr %l7
  %t132 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t128, 0
  %t134 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t132, i64 %t129, 1
  %t136 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t134, %"compiler/source:Span" %t130, 2
  call void @__olang_scope_close(ptr %s4)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t136, ptr %rv
  br label %ret
bb19:
  %t138 = load { i64, [5 x i64] }, ptr %l0
  %t140 = extractvalue { i64, [5 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 1
  br i1 %t141, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t144 = load %"compiler/source:Span", ptr %l1
  %t146 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t143, 0
  %t147 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t146, i64 -1, 1
  %t149 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t147, %"compiler/source:Span" %t144, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t149, ptr %l56
  %t150 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l56, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  store { i64, ptr } %t151, ptr %l57, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  store i64 %t153, ptr %l58, !tbaa !24
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = mul i64 %t154, 1
  %t156 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t155)
  %t157 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l59, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = load i64, ptr %l58, !tbaa !24
  %t164 = mul i64 %t163, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t160, ptr %t162, i64 %t164, i1 false)
  %t165 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t166 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l56, i32 0, i32 0
  store { i64, ptr } %t165, ptr %t166, !tbaa !27
  %t167 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l56
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t167, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9aa13344fea3f6d8_5ff568fedc30749c)
  unreachable
ret:
  %rr = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %rv
  ret { { i64, ptr }, i64, %"compiler/source:Span" } %rr
}

define dso_local i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:VarDecl", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:VarDecl", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l1, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t30, i32 0, i32 2
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load i1, ptr %l2, !tbaa !21
  store i1 %t34, ptr %l12, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a437b17fd6ef2726_85fb06efd955f512)
  unreachable
bb17:
  %t36 = load i1, ptr %l12, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, [3 x i64] }, { i64, ptr } } @compiler_2finterp_2ezeroUseArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i8
  %l9 = alloca i8
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %lp13 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l29 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l74 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i1
  %l83 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l131 = alloca i1
  %l132 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l143 = alloca i1
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l163 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i64
  %l184 = alloca { i64, ptr }
  %l186 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l193 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %rv = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %t377 = alloca { i64, [3 x i64] }, align 8
  store { i64, [3 x i64] } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [3 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [3 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t15 = getelementptr { i64, i64, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  br label %bb98
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %t19)
  store { i64, ptr } %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = add i64 %t26, %t29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sle i64 %t32, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = add i64 %t38, %t41
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t50 = icmp sle i64 %t44, %t47
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l29, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb9, label %bb10
bb9:
  br label %bb97
bb10:
  br label %bb11
bb11:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l39, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = add i64 %t57, %t60
  store i64 %t63, ptr %l43, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l44, !tbaa !24
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = load i64, ptr %l39, !tbaa !24
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_69f8faa22d82cef9_e064f09003af3e5d)
  unreachable
bb14:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_69f8faa22d82cef9_e064f09003af3e5d)
  unreachable
bb16:
  %t77 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = load i64, ptr %l43, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t84, { i64, ptr } %t85)
  store i1 %t88, ptr %l50
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_69f8faa22d82cef9_e064f09003af3e5d)
  unreachable
bb18:
  %t89 = load i1, ptr %l50, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  store i1 %t92, ptr %l51, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = add i64 %t95, %t98
  %t102 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t107 = icmp slt i64 %t101, %t104
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l54, !tbaa !21
  br i1 %t109, label %bb25, label %bb26
bb25:
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = sub i64 %t111, 1
  %t115 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i8, ptr %t116, i64 %t113
  %t118 = load i8, ptr %t117, !tbaa !32
  store i8 %t118, ptr %l8, !tbaa !22
  %t120 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t120, ptr %l66, !tbaa !27
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t127 = add i64 %t121, %t124
  %t129 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 %t127
  %t132 = load i8, ptr %t131, !tbaa !32
  store i8 %t132, ptr %l9, !tbaa !22
  %t134 = load i8, ptr %l8, !tbaa !22
  %t136 = icmp eq i8 %t134, 60
  br i1 %t136, label %bb27, label %bb28
bb26:
  br label %bb95
bb27:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb29
bb28:
  %t138 = load i8, ptr %l8, !tbaa !22
  %t140 = icmp eq i8 %t138, 32
  store i1 %t140, ptr %l74, !tbaa !21
  br label %bb29
bb29:
  %t142 = load i1, ptr %l74, !tbaa !21
  br i1 %t142, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb32
bb31:
  %t143 = load i8, ptr %l8, !tbaa !22
  %t145 = icmp eq i8 %t143, 44
  store i1 %t145, ptr %l77, !tbaa !21
  br label %bb32
bb32:
  %t147 = load i1, ptr %l77, !tbaa !21
  br i1 %t147, label %bb33, label %bb34
bb33:
  %t148 = load i8, ptr %l9, !tbaa !22
  %t150 = icmp eq i8 %t148, 62
  br i1 %t150, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb38
bb35:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb37
bb36:
  %t152 = load i8, ptr %l9, !tbaa !22
  %t154 = icmp eq i8 %t152, 44
  store i1 %t154, ptr %l83, !tbaa !21
  br label %bb37
bb37:
  %t156 = load i1, ptr %l83, !tbaa !21
  store i1 %t156, ptr %l80, !tbaa !21
  br label %bb38
bb38:
  %t157 = load i1, ptr %l80, !tbaa !21
  br i1 %t157, label %bb39, label %bb40
bb39:
  %t158 = load i64, ptr %l7, !tbaa !24
  %t160 = sub i64 %t158, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb41
bb40:
  br label %bb94
bb41:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t163 = load i64, ptr %l4, !tbaa !24
  %t166 = icmp sgt i64 %t162, %t163
  br i1 %t166, label %bb42, label %bb43
bb42:
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t168, ptr %l92, !tbaa !27
  %t169 = load i64, ptr %l10, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i8, ptr %t172, i64 %t169
  %t174 = load i8, ptr %t173, !tbaa !32
  %t176 = icmp ne i8 %t174, 60
  store i1 %t176, ptr %l91, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb44
bb44:
  %t178 = load i1, ptr %l91, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t183 = sub i64 %t181, 1
  store i64 %t183, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  br label %bb41
bb49:
  %t185 = load i64, ptr %l10, !tbaa !24
  store i64 %t185, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i64, ptr %l4, !tbaa !24
  %t191 = icmp sgt i64 %t187, %t188
  br i1 %t191, label %bb51, label %bb52
bb51:
  %t193 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t193, ptr %l104, !tbaa !27
  %t194 = load i64, ptr %l11, !tbaa !24
  %t196 = sub i64 %t194, 1
  %t198 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i8, ptr %t199, i64 %t196
  %t201 = load i8, ptr %t200, !tbaa !32
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t201)
  store i1 %t203, ptr %l108
  br label %bb53
bb52:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb61
bb53:
  %t204 = load i1, ptr %l108, !tbaa !21
  br i1 %t204, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb57
bb55:
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t205, ptr %l110, !tbaa !27
  %t206 = load i64, ptr %l11, !tbaa !24
  %t208 = sub i64 %t206, 1
  %t210 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i8, ptr %t211, i64 %t208
  %t213 = load i8, ptr %t212, !tbaa !32
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t213)
  store i1 %t215, ptr %l114
  br label %bb56
bb56:
  %t216 = load i1, ptr %l114, !tbaa !21
  store i1 %t216, ptr %l109, !tbaa !21
  br label %bb57
bb57:
  %t217 = load i1, ptr %l109, !tbaa !21
  br i1 %t217, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb60
bb59:
  %t218 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t218, ptr %l116, !tbaa !27
  %t219 = load i64, ptr %l11, !tbaa !24
  %t221 = sub i64 %t219, 1
  %t223 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i8, ptr %t224, i64 %t221
  %t226 = load i8, ptr %t225, !tbaa !32
  %t228 = icmp eq i8 %t226, 95
  store i1 %t228, ptr %l115, !tbaa !21
  br label %bb60
bb60:
  %t230 = load i1, ptr %l115, !tbaa !21
  store i1 %t230, ptr %l103, !tbaa !21
  br label %bb61
bb61:
  %t231 = load i1, ptr %l103, !tbaa !21
  %t232 = xor i1 %t231, true
  br i1 %t232, label %bb62, label %bb63
bb62:
  br label %bb66
bb63:
  br label %bb64
bb64:
  %t234 = load i64, ptr %l11, !tbaa !24
  %t236 = sub i64 %t234, 1
  store i64 %t236, ptr %l11, !tbaa !24
  br label %bb65
bb65:
  br label %bb50
bb66:
  %t238 = load i64, ptr %l7, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t244 = add i64 %t238, %t241
  store i64 %t244, ptr %l12, !tbaa !24
  br label %bb67
bb67:
  %t246 = load i64, ptr %l12, !tbaa !24
  %t247 = load i64, ptr %l5, !tbaa !24
  %t250 = icmp slt i64 %t246, %t247
  br i1 %t250, label %bb68, label %bb69
bb68:
  %t252 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t252, ptr %l132, !tbaa !27
  %t253 = load i64, ptr %l12, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i8, ptr %t256, i64 %t253
  %t258 = load i8, ptr %t257, !tbaa !32
  %t260 = icmp ne i8 %t258, 62
  store i1 %t260, ptr %l131, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb70
bb70:
  %t262 = load i1, ptr %l131, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb71, label %bb72
bb71:
  br label %bb75
bb72:
  br label %bb73
bb73:
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l12, !tbaa !24
  br label %bb74
bb74:
  br label %bb67
bb75:
  %t269 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t269, ptr %l139, !tbaa !27
  %t270 = load i64, ptr %l10, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i8, ptr %t273, i64 %t270
  %t275 = load i8, ptr %t274, !tbaa !32
  %t277 = icmp eq i8 %t275, 60
  br i1 %t277, label %bb76, label %bb77
bb76:
  %t279 = load i64, ptr %l12, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t285 = icmp slt i64 %t279, %t282
  store i1 %t285, ptr %l143, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb78
bb78:
  %t287 = load i1, ptr %l143, !tbaa !21
  br i1 %t287, label %bb79, label %bb80
bb79:
  %t288 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t288, ptr %l148, !tbaa !27
  %t289 = load i64, ptr %l11, !tbaa !24
  store i64 %t289, ptr %l149, !tbaa !24
  %t290 = load i64, ptr %l7, !tbaa !24
  %t291 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t291, 0
  %t296 = add i64 %t290, %t293
  store i64 %t296, ptr %l153, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  store i64 %t298, ptr %l154, !tbaa !24
  %t299 = load i64, ptr %l149, !tbaa !24
  %t300 = icmp sge i64 %t299, 0
  br i1 %t300, label %bb81, label %bb82
bb80:
  br label %bb93
bb81:
  %t302 = load i64, ptr %l149, !tbaa !24
  %t303 = load i64, ptr %l153, !tbaa !24
  %t304 = icmp sle i64 %t302, %t303
  br i1 %t304, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb83:
  %t306 = load i64, ptr %l153, !tbaa !24
  %t307 = load i64, ptr %l154, !tbaa !24
  %t308 = icmp sle i64 %t306, %t307
  br i1 %t308, label %bb85, label %bb86
bb84:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb85:
  %t310 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = load i64, ptr %l149, !tbaa !24
  %t313 = load i64, ptr %l153, !tbaa !24
  %t314 = getelementptr i8, ptr %t311, i64 %t312
  %t315 = sub i64 %t313, %t312
  %t316 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t314, 1
  store { i64, ptr } %t317, ptr %l158, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t318, ptr %l159, !tbaa !27
  %t319 = load i64, ptr %l7, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t325 = add i64 %t319, %t322
  store i64 %t325, ptr %l163, !tbaa !24
  %t326 = load i64, ptr %l12, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l165, !tbaa !24
  %t329 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  store i64 %t330, ptr %l166, !tbaa !24
  %t331 = load i64, ptr %l163, !tbaa !24
  %t332 = icmp sge i64 %t331, 0
  br i1 %t332, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb87:
  %t334 = load i64, ptr %l163, !tbaa !24
  %t335 = load i64, ptr %l165, !tbaa !24
  %t336 = icmp sle i64 %t334, %t335
  br i1 %t336, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb89:
  %t338 = load i64, ptr %l165, !tbaa !24
  %t339 = load i64, ptr %l166, !tbaa !24
  %t340 = icmp sle i64 %t338, %t339
  br i1 %t340, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb91:
  %t342 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = load i64, ptr %l163, !tbaa !24
  %t345 = load i64, ptr %l165, !tbaa !24
  %t346 = getelementptr i8, ptr %t343, i64 %t344
  %t347 = sub i64 %t345, %t344
  %t348 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t346, 1
  %t350 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t354 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t355 = add i64 %t352, %t354
  %t357 = extractvalue { i64, ptr } %t349, 1
  %t358 = extractvalue { i64, ptr } %t349, 0
  %t359 = add i64 %t355, %t358
  %t360 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t359)
  call void @olang_textcopy(ptr %t360, ptr %t351, i64 %t352)
  %t361 = getelementptr i8, ptr %t360, i64 %t352
  call void @olang_textcopy(ptr %t361, ptr %t353, i64 %t354)
  %t362 = getelementptr i8, ptr %t361, i64 %t354
  call void @olang_textcopy(ptr %t362, ptr %t357, i64 %t358)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t360, 1
  %t365 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t365, ptr %lp13
  %t367 = load ptr, ptr %lp13
  store { i64, ptr } %t364, ptr %t367, !tbaa !27
  %t368 = load i64, ptr %l3, !tbaa !24
  %t369 = load i64, ptr %l7, !tbaa !24
  %t370 = load i64, ptr %l7, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t371, 0
  %t376 = add i64 %t370, %t373
  store { i64, [3 x i64] } zeroinitializer, ptr %t377
  %t378 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 0
  store i64 3, ptr %t378
  %t380 = insertvalue { i64, i64, i64 } undef, i64 %t368, 0
  %t382 = insertvalue { i64, i64, i64 } %t380, i64 %t369, 1
  %t384 = insertvalue { i64, i64, i64 } %t382, i64 %t376, 2
  %t385 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 1
  store { i64, i64, i64 } %t384, ptr %t385
  %t386 = load { i64, [3 x i64] }, ptr %t377
  %t387 = load ptr, ptr %lp13
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  %t390 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t386, 0
  %t392 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t390, { i64, ptr } %t388, 1
  store { { i64, [3 x i64] }, { i64, ptr } } %t392, ptr %rv
  br label %ret
bb92:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t394 = load i64, ptr %l7, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l7, !tbaa !24
  br label %bb96
bb96:
  br label %bb5
bb97:
  %t398 = load { i64, [3 x i64] }, ptr %l1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l184, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t401 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t398, 0
  %t403 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t401, { i64, ptr } %t399, 1
  store { { i64, [3 x i64] }, { i64, ptr } } %t403, ptr %l186
  %t404 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186, i32 0, i32 1
  %t405 = load { i64, ptr }, ptr %t404, !tbaa !27
  store { i64, ptr } %t405, ptr %l187, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  store i64 %t407, ptr %l188, !tbaa !24
  %t408 = load i64, ptr %l188, !tbaa !24
  %t409 = mul i64 %t408, 1
  %t410 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t409)
  %t411 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  store { i64, ptr } %t412, ptr %l189, !tbaa !27
  %t413 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = load i64, ptr %l188, !tbaa !24
  %t418 = mul i64 %t417, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t414, ptr %t416, i64 %t418, i1 false)
  %t419 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t420 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186, i32 0, i32 1
  store { i64, ptr } %t419, ptr %t420, !tbaa !27
  %t421 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186
  store { { i64, [3 x i64] }, { i64, ptr } } %t421, ptr %rv
  br label %ret
bb98:
  %t422 = load { i64, [3 x i64] }, ptr %l1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) }, ptr %l191, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t425 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t422, 0
  %t427 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t425, { i64, ptr } %t423, 1
  store { { i64, [3 x i64] }, { i64, ptr } } %t427, ptr %l193
  %t428 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193, i32 0, i32 1
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  store { i64, ptr } %t429, ptr %l194, !tbaa !27
  %t430 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t430, 0
  store i64 %t431, ptr %l195, !tbaa !24
  %t432 = load i64, ptr %l195, !tbaa !24
  %t433 = mul i64 %t432, 1
  %t434 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t433)
  %t435 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t436 = insertvalue { i64, ptr } %t435, ptr %t434, 1
  store { i64, ptr } %t436, ptr %l196, !tbaa !27
  %t437 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = load i64, ptr %l195, !tbaa !24
  %t442 = mul i64 %t441, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t438, ptr %t440, i64 %t442, i1 false)
  %t443 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t444 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193, i32 0, i32 1
  store { i64, ptr } %t443, ptr %t444, !tbaa !27
  %t445 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193
  store { { i64, [3 x i64] }, { i64, ptr } } %t445, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %rv
  ret { { i64, [3 x i64] }, { i64, ptr } } %rr
}

define dso_local %"compiler/interp:CondErr" @compiler_2finterp_3aCondErr_2ector(ptr %v0, ptr %v1, { i64, [3 x i64] } %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %rv = alloca %"compiler/interp:CondErr"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/interp:CondErr" undef, { i64, [3 x i64] } %a0, 0
  %t8 = insertvalue %"compiler/interp:CondErr" %t6, %"compiler/msgs:Msg" %a1, 1
  store %"compiler/interp:CondErr" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/interp:CondErr", ptr %rv
  ret %"compiler/interp:CondErr" %rr
}

define dso_local void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i32
  %l6 = alloca %"compiler/lower:Lowerer"
  %l7 = alloca %"compiler/eval:Machine"
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"compiler/lower:Lowerer"
  %l25 = alloca %"compiler/eval:Machine"
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"compiler/interp:Exec"
  %t17 = alloca %"compiler/eval:Machine", align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t11 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %t7, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  store %"compiler/lower:Lowerer" %t11, ptr %l21
  br label %bb1
bb1:
  %t12 = load %"compiler/lower:Lowerer", ptr %l21
  store %"compiler/lower:Lowerer" %t12, ptr %l6
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l2
  call void @compiler_2feval_2eNewMachine(ptr %t17, ptr %v0, ptr %v2, ptr %t15, i32 %t16)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t17, i64 768, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l25, i64 768, i1 false)
  %t20 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l26
  br label %bb3
bb3:
  %t21 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l8
  %t22 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l27
  br label %bb4
bb4:
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l9
  %t24 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l28
  br label %bb5
bb5:
  %t25 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l10
  %t26 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l29
  br label %bb6
bb6:
  %t27 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l11
  %t28 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l30
  br label %bb7
bb7:
  %t29 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l12
  %t30 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l31
  br label %bb8
bb8:
  %t31 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l13
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l32
  br label %bb9
bb9:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  %t34 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 0
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %t34, !tbaa !29
  %t36 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 1
  %t37 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %t36
  %t38 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 2
  %t39 = load i32, ptr %l5
  store i32 %t39, ptr %t38
  %t40 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 3
  %t41 = load %"compiler/lower:Lowerer", ptr %l6
  store %"compiler/lower:Lowerer" %t41, ptr %t40
  %t42 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %l7, i64 768, i1 false)
  %t43 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 5
  %t44 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %t43
  %t45 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 6
  %t46 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t45
  %t47 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 7
  %t48 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %t47
  %t49 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 8
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %t49
  %t51 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 9
  %t52 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %t51
  %t53 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 10
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t53
  %t55 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t55
  %t57 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 12
  store i1 false, ptr %t57, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l33, i64 976, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"it reaches unreachable code, which aborts the program" }>, align 8
@.d1 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"a '!' in it meets a null, which aborts the program" }>, align 8
@.d2 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"an assertion in it fails, which aborts the program" }>, align 8
@.d3 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"it slices out of range, which aborts the program" }>, align 8
@.d4 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"it makes an array of a length out of range, which aborts the program" }>, align 8
@.d5 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"it copies an array of another length into fixed storage, which aborts the program" }>, align 8
@.d6 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"a lane operation in it meets arrays of different lengths, which aborts the program" }>, align 8
@.d7 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"an 'as' that does not hold aborts the program" }>, align 8
@.d8 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"it asks a generator for its next value from inside the generator's own walk, which aborts the program" }>, align 8
@.d9 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"an error reaches '!', which ends the program" }>, align 8
@.d10 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"an error leaves the test, which ends it" }>, align 8
@.d11 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"it ends the test or the process" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hfa18c4028fc14c940207bea2352eb53b(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  br label %bb3
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i64 }, ptr %t47, i32 0, i32 1
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i64 }, ptr %t51, i32 0, i32 1
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64, i64 }, ptr %t71, i32 0, i32 2
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb12, label %bb1
bb12:
  br label %bb3
bb13:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-l" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"lib" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".a" }>, align 8
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".o" }>, align 8
@.d22 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"a static library or an object, which only a link takes" }>, align 8
declare ptr @dlopen(ptr, i32)
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @dlerror()
@.d24 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"dlopen failed" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"an error escapes, code " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d38 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"it fails with an error no clause handles" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d43 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no main\0A" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d45 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang interpret: " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d47 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang interpret: " }>, align 8
@.d48 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": the Vec grew here\0A" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ok - " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d55 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"FAIL - " }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d57 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" passed, " }>, align 8
@.d58 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" failed\0A" }>, align 8
@.d59 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unhandled error: " }>, align 8
@.d60 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" - here in the task spawned at " }>, align 8
@.d61 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d65 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" earlier places not kept)\0A" }>, align 8
@.d66 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"raised here" }>, align 8
@.d67 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"try passed it on" }>, align 8
@.d68 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a task failed, and its join passed it on" }>, align 8
@.d69 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d74 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d75 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d77 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d78 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d79 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error " }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d81 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d92 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"it fails with an error no clause handles" }>, align 8
@.d93 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"it fails with an error no clause handles" }>, align 8
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_3aProgram_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_3aChecker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2eLen_3ccompiler_2finterp_3aCondErr_3e(ptr %v0, ptr %a0)
declare %"compiler/interp:CondErr" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2eAt_3ccompiler_2finterp_3aCondErr_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, %"compiler/eval:Image" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eImage(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_23ba8871310952f4_ff8b68d1da902468 = external constant [0 x i8]
@G_2ecompiler_2feval_2eWhyStale = external constant <{ [8 x i8], ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalStale(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalAborts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
@olang_loc_1c176b23f7e86d25_2ef9862bd1101439 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/eval:Image" %a2)
@olang_loc_e5af19e5316a916e_83bce7741a9ff3c2 = external constant [0 x i8]
declare { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0)
@olang_loc_3773d5026fcce970_1368cc7afcdc192c = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H3ccda5e77fabf86fda89ecfc77eff03d(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H8e3ab02101333f4dae95aad48f2e722e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
declare %"compiler/eval:Blob" @compiler_2feval_3aBlob_2ector(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Blob" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_Hd47ddefe3838698aaa5711f2f63b01ed(ptr %v0, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %a0)
declare %"compiler/check:AssertAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eAt_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7edf3cf7ccf8e57f_276bde685bbe381b = external constant [0 x i8]
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d8df33bf7c2af1a9_d617709f0680343d = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0)
declare %"compiler/check:ValueAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eAt_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e1183b54591591ba_6784d54d52bb291e = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eResultHoldsAddress(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eZeroValueShared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralCtorFails(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroByReference(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroReferenceHasOne(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_31552f310cf75527_9d9c34da119f96fb = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToC(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aCStr_2eStringFromC(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0)
@olang_loc_5ef8759083cc657e_8312724bf589cc02 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_97cc5832d0a5683f_9bb5deb899ee2c5b = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_9c0b486f116f3620_d1f759da60f3616c = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_b7cf027bc3b091ec_6e850e1bd8f0ff28 = external constant [0 x i8]
@G_2ecompiler_2fload_2eNoBranch = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_d3dcaf488556181a_337076a643e912ae = external constant [0 x i8]
@olang_loc_e80992fd1d33d452_12ec5773a31f7726 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5b75817b97c7703f_a9caa4d803bddbab = external constant [0 x i8]
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_fce8d31b7e62f371_71870e12b086bddd = external constant [0 x i8]
@olang_loc_6d054a657ae82b6f_99a66fec87b1ac03 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePop_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_26fab0deca850fb9_a904bdf0227cd14d = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_f78c9384d4051fe8_f87279dcad65e91c = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c21b7649f9083df0_c859438e5e055394 = external constant [0 x i8]
declare { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %a0)
@olang_loc_736b533d144489ee_c645810c81b1a7fa = external constant [0 x i8]
@G_2ecompiler_2feval_2eWhyWaits = external constant <{ [8 x i8], ptr }>
@olang_loc_177aae49e1a91f38_175ec48f508568b4 = external constant [0 x i8]
@olang_loc_eb59e3d17e209b69_67e25fc5a7a9951d = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_475297ef6b70163a_9a972925e80d4cae = external constant [0 x i8]
@olang_loc_d8a47822f9024607_7785834784e2e59b = external constant [0 x i8]
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceWhat(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_6b327bc23f54125b_df118949941dcc1f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cc02f93ad90a889a_227f669eebce755e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2)
@olang_loc_8861c203007a29b_3eff7fe7d80c41df = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i1 %a4, { i64, [2 x i64] } %a5)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eBuildGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_5218513f7b2d35ff_8134a4fdf2d394bb = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6661ff5fcd5a0e74_cadc672e97162150 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H8bd9ddbe6d7efc10dd35c4d42ad9dacf(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eLen_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v0, ptr %a0)
declare %"compiler/check:EmbedAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eAt_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4b90e82c7a9c5937397e46eef988cfe3(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94076cc109da9d789864820ff05c3ac1(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/check:Ask" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2ePush_3ccompiler_2fast_3aIf_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
@G_2ecompiler_2fgeneric_2eRunTimeLength = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\80" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_4d4f35a1b1719400_5211f6c42998ad34 = external constant [0 x i8]
@olang_loc_ba0df268265cfa7e_806ddae02611f59a = external constant [0 x i8]
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H7486c711b8ab0d124cd9b327dc5d14f9(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnseen(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUndecidable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2ePush_3ccompiler_2finterp_3aCondErr_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/interp:CondErr" %a1)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2eLen_3ccompiler_2fast_3aIf_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2eAt_3ccompiler_2fast_3aIf_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eAt_H56c1cddaee4bc4aa5c09605de1331e44(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_d213ae2acd73c837_819e6544d8b9fb33 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eConversionDoesNotFit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractFalse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteContractCondition(ptr %v0)
@olang_loc_3238838aabc16991_ed85858096edfcc5 = external constant [0 x i8]
@olang_loc_ef1298413c90a2dc_ba44d1693e670768 = external constant [0 x i8]
@olang_loc_2f4ce1a9e181e1f2_bd4ae6421df971e = external constant [0 x i8]
@olang_loc_6beaad51a5cbbd4f_ba25a08250cd8123 = external constant [0 x i8]
@olang_loc_337e2febbb969070_fe2fc98a6d253614 = external constant [0 x i8]
@olang_loc_972a61363a9ec592_fd7ddbe7b61f56ae = external constant [0 x i8]
@olang_loc_2a2178e5d5b03d3c_5603e1310e4875e0 = external constant [0 x i8]
@olang_loc_17914f4f6ca28ab_f546bfb1cda272ff = external constant [0 x i8]
@olang_loc_c5607a0551bceea3_a83aa459e58f2847 = external constant [0 x i8]
@olang_loc_4efe4c4a78894057_5e75e4c074554d53 = external constant [0 x i8]
@olang_loc_1ec4d19c7606c42f_38a78c76cd6682ab = external constant [0 x i8]
declare void @compiler_2fviews_3aViewer_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_33cf42576bc92052_8a57929dd960fbd6 = external constant [0 x i8]
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
@olang_loc_53f8f52e2a7db594_7d67e05921593da8 = external constant [0 x i8]
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_937c5ec6da42b121_d38194c1cca770f5 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrewHere(ptr %v0)
@olang_loc_9aa13344fea3f6d8_5ff568fedc30749c = external constant [0 x i8]
@olang_loc_a437b17fd6ef2726_85fb06efd955f512 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_69f8faa22d82cef9_e064f09003af3e5d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800 = external constant [0 x i8]
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2feval_2eNewMachine(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
