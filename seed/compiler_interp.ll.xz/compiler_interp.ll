; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/interp:CondErr" = type { { i64, [3 x i64] }, %"compiler/msgs:Msg" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/eval:Blob" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i32, i32 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/eval:Image" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:ConstAsk" = type { i64, ptr, i32, i64, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
%"compiler/mir:Fn" = type { { i64, [1 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Call" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Task" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [7 x i64] } }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/views:Viewer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
define dso_local { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 3 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 53, ptr @.d0 }, ptr %l1, !tbaa !27
  br label %bb33
bb4:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 4 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 50, ptr @.d1 }, ptr %l1, !tbaa !27
  br label %bb33
bb8:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 5 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 48, ptr @.d2 }, ptr %l1, !tbaa !27
  br label %bb33
bb12:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 6 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 68, ptr @.d3 }, ptr %l1, !tbaa !27
  br label %bb33
bb16:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 8 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 81, ptr @.d4 }, ptr %l1, !tbaa !27
  br label %bb33
bb20:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 7 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 45, ptr @.d5 }, ptr %l1, !tbaa !27
  br label %bb33
bb24:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 9 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 44, ptr @.d6 }, ptr %l1, !tbaa !27
  br label %bb33
bb28:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 10 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 39, ptr @.d7 }, ptr %l1, !tbaa !27
  br label %bb33
bb32:
  store { i64, ptr } { i64 31, ptr @.d8 }, ptr %l1, !tbaa !27
  br label %bb33
bb33:
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %lp7 = alloca ptr
  %lp8 = alloca ptr
  %lp9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/interp:CondErr"
  %l16 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l24 = alloca %"compiler/names:Resolver"
  %l28 = alloca %"compiler/generic:Program"
  %l32 = alloca %"compiler/check:Checker"
  %l42 = alloca i1
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca i64
  %l73 = alloca i64
  %l77 = alloca %"compiler/check:Checker"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t36 = alloca %"compiler/generic:Program", align 8
  %t48 = alloca %"compiler/check:Checker", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l16
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t5 = load ptr, ptr %lp2
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t6)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l17
  br label %bb2
bb2:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t8, ptr %lp3
  %t9 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t10 = load ptr, ptr %lp3
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %t10
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t11)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l18
  br label %bb3
bb3:
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t13, ptr %lp4
  %t14 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  %t15 = load ptr, ptr %lp4
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %t15
  %t16 = load ptr, ptr @__olang_prog_scope
  %t17 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2finterp_3aCondErr_3e(ptr %t16)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l19
  br label %bb4
bb4:
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l5
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 4
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l22
  br label %bb6
bb6:
  %t25 = load i64, ptr %l22, !tbaa !24
  store i64 %t25, ptr %l6, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %v0, ptr %v1, ptr %t26)
  store %"compiler/names:Resolver" %t28, ptr %l24
  br label %bb7
bb7:
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 128, i64 8)
  store ptr %t29, ptr %lp7
  %t30 = load %"compiler/names:Resolver", ptr %l24
  %t31 = load ptr, ptr %lp7
  store %"compiler/names:Resolver" %t30, ptr %t31
  %t32 = load ptr, ptr %lp7
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v1, ptr %t32)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %lp7
  call void @compiler_2fgeneric_3aProgram_2ector(ptr %t36, ptr %v0, ptr %v1, ptr %v1, ptr %t34, ptr %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t36, i64 560, i1 false)
  br label %bb9
bb9:
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 560, i64 8)
  store ptr %t39, ptr %lp8
  %t40 = load ptr, ptr %lp8
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %l28, i64 560, i1 false)
  %t41 = load ptr, ptr %lp4
  %t42 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t41
  %t44 = load ptr, ptr %lp8
  %t45 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 34
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %t45
  %t46 = load ptr, ptr %lp8
  call void @compiler_2fcheck_3aChecker_2ector(ptr %t48, ptr %v1, ptr %v1, ptr %t46, i1 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t48, i64 568, i1 false)
  br label %bb10
bb10:
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 568, i64 8)
  store ptr %t51, ptr %lp9
  %t52 = load ptr, ptr %lp9
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %l32, i64 568, i1 false)
  %t53 = load ptr, ptr %lp2
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t53
  %t56 = load ptr, ptr %lp9
  %t57 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 63
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t57
  %t58 = load ptr, ptr %lp3
  %t59 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t58
  %t61 = load ptr, ptr %lp9
  %t62 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 74
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %t62
  %t63 = load ptr, ptr %lp9
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v1, ptr %t63)
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %lp9
  %t67 = load ptr, ptr %lp2
  %t68 = load ptr, ptr %lp3
  %t69 = load ptr, ptr %lp4
  %t76 = call i1 @compiler_2finterp_2edecide(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %s0, ptr %t65, ptr %t66, ptr %t67, ptr %t68, ptr %t69, ptr %l5)
  store i1 %t76, ptr %l42
  br label %bb12
bb12:
  %t77 = load i1, ptr %l42, !tbaa !21
  %t78 = xor i1 %t77, true
  br i1 %t78, label %bb13, label %bb14
bb13:
  store ptr %l5, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb15
bb14:
  br label %bb36
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load ptr, ptr %l10, !tbaa !29
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2finterp_3aCondErr_3e_2eRu_H922c29a79a89b0be9ccf5ed4b75b0111(ptr %s0, ptr %t81, i64 %t82)
  %t86 = extractvalue { i32, { i64, ptr } } %t85, 1
  %t87 = extractvalue { i32, { i64, ptr } } %t85, 0
  store i32 %t87, ptr %l49
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb17, label %ok.89
ok.89:
  store { i64, ptr } %t86, ptr %l48
  br label %bb16
bb16:
  %t90 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  br label %bb21
bb17:
  %t91 = load i32, ptr %l49, !tbaa !23
  %t92 = ashr i32 %t91, 16
  %t94 = icmp eq i32 %t92, 1
  br i1 %t94, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb21:
  %t96 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t96, ptr %l12, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t101 = load i64, ptr %l14, !tbaa !24
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t109 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t109, ptr %l58, !tbaa !27
  %t110 = load i64, ptr %l14, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr %"compiler/interp:CondErr", ptr %t113, i64 %t110
  %t115 = load %"compiler/interp:CondErr", ptr %t114
  store %"compiler/interp:CondErr" %t115, ptr %l15
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/load:Loader", ptr %t117, i32 0, i32 4
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t121 = getelementptr %"compiler/interp:CondErr", ptr %l15, i32 0, i32 0
  %t122 = load { i64, [3 x i64] }, ptr %t121
  %t123 = getelementptr %"compiler/interp:CondErr", ptr %l15, i32 0, i32 1
  %t124 = load %"compiler/msgs:Msg", ptr %t123
  %t128 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t120, { i64, [3 x i64] } %t122, %"compiler/msgs:Msg" %t124)
  store i64 %t128, ptr %l65
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t129 = load i64, ptr %l14, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l14, !tbaa !24
  br label %bb22
bb28:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t137 = add i64 %t133, %t134
  store i64 %t137, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb29:
  br label %bb15
bb30:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/load:Loader", ptr %t139, i32 0, i32 4
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t142)
  store i64 %t144, ptr %l73
  br label %bb31
bb31:
  %t145 = load i64, ptr %l6, !tbaa !24
  %t146 = load i64, ptr %l73, !tbaa !24
  %t148 = icmp eq i64 %t146, %t145
  br i1 %t148, label %bb32, label %bb33
bb32:
  %t150 = load ptr, ptr %lp9
  call void @compiler_2finterp_2ejudgeViews(ptr %v1, ptr %t150)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  %t152 = load ptr, ptr %lp9
  call void @llvm.memmove.p0.p0.i64(ptr %l77, ptr %t152, i64 568, i1 false)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l77, i64 568, i1 false)
  br label %ret
bb36:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/load:Loader", ptr %t153, i32 0, i32 4
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t157 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t156, i64 %t157)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s1)
  br label %bb38
bb38:
  br label %bb5
ret:
  ret void
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca { i64, [5 x i64] }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i64
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l25 = alloca ptr
  %l27 = alloca i64
  %lp28 = alloca ptr
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %lp36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca %"compiler/eval:Blob"
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %lp62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %lp69 = alloca ptr
  %lp70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l79 = alloca { i64, i32 }
  %l80 = alloca i64
  %l81 = alloca i32
  %l82 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"compiler/interp:Exec"
  %l98 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l114 = alloca { i64, ptr }
  %l120 = alloca ptr
  %l127 = alloca %"compiler/eval:Image"
  %l132 = alloca %"compiler/eval:Image"
  %l133 = alloca i32
  %l145 = alloca i1
  %l150 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l153 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l169 = alloca { i64, [3 x i64] }
  %l171 = alloca %"compiler/msgs:Msg"
  %l172 = alloca i64
  %l183 = alloca i32
  %l185 = alloca i32
  %l187 = alloca i1
  %l188 = alloca i1
  %l189 = alloca i32
  %l191 = alloca i32
  %l193 = alloca i1
  %l197 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l200 = alloca i1
  %l206 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca { i64, [3 x i64] }
  %l219 = alloca { i64, ptr }
  %l220 = alloca %"compiler/msgs:Msg"
  %l221 = alloca i64
  %l226 = alloca i1
  %l231 = alloca i64
  %l238 = alloca i64
  %l240 = alloca ptr
  %l241 = alloca i64
  %l247 = alloca { i64, [3 x i64] }
  %l248 = alloca %"compiler/msgs:Msg"
  %l257 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l260 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l264 = alloca i32
  %l273 = alloca { i64, ptr }
  %l276 = alloca %"compiler/eval:Image"
  %l279 = alloca %"compiler/eval:Image"
  %l280 = alloca i32
  %l284 = alloca ptr
  %l285 = alloca i64
  %l287 = alloca i64
  %l292 = alloca i64
  %l296 = alloca i64
  %l299 = alloca i64
  %l319 = alloca i64
  %l322 = alloca i1
  %l325 = alloca i1
  %l326 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l329 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l330 = alloca i32
  %l331 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l335 = alloca ptr
  %l336 = alloca i64
  %l346 = alloca { i64, ptr }
  %l349 = alloca { i64, ptr }
  %l350 = alloca i32
  %l359 = alloca { i64, ptr }
  %l363 = alloca { i64, ptr }
  %l366 = alloca { i64, ptr }
  %l367 = alloca i32
  %l376 = alloca { i64, ptr }
  %l381 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l384 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l385 = alloca i32
  %l386 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l389 = alloca i1
  %l393 = alloca ptr
  %l394 = alloca i64
  %l411 = alloca i1
  %l412 = alloca %"compiler/eval:Image"
  %l414 = alloca i64
  %l418 = alloca i64
  %l421 = alloca i64
  %l444 = alloca %"compiler/eval:Blob"
  %l445 = alloca %"compiler/eval:Blob"
  %l450 = alloca i64
  %l454 = alloca i64
  %l457 = alloca i64
  %l475 = alloca ptr
  %l478 = alloca i64
  %l479 = alloca ptr
  %l482 = alloca i64
  %l485 = alloca i64
  %l487 = alloca i64
  %l490 = alloca i64
  %l491 = alloca ptr
  %l494 = alloca i64
  %l495 = alloca i64
  %l498 = alloca i64
  %l500 = alloca i1
  %l503 = alloca i64
  %l506 = alloca ptr
  %l509 = alloca i64
  %l512 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l515 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l516 = alloca i32
  %l517 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l521 = alloca ptr
  %l522 = alloca { i64, i32 }
  %l538 = alloca ptr
  %l541 = alloca i64
  %l542 = alloca ptr
  %l545 = alloca i64
  %l549 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %t14 = alloca %"compiler/interp:Exec", align 8
  %t204 = alloca { i64, [3 x i64] }, align 8
  %t303 = alloca { i64, [3 x i64] }, align 8
  %t377 = alloca { i64, [3 x i64] }, align 8
  %t491 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l82
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 4
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t12
  call void @compiler_2finterp_3aExec_2ector(ptr %t14, ptr %v0, ptr %v0, ptr %v0, ptr %t9, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t14, i64 880, i1 false)
  br label %bb2
bb2:
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 880, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %l88, i64 880, i1 false)
  store ptr %t18, ptr %l2, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 69
  %t24 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t23
  %t27 = getelementptr %"compiler/interp:Exec", ptr %t20, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %t27
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t28)
  br label %bb3
bb3:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 4
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l3, !tbaa !29
  %t41 = load ptr, ptr @__olang_prog_scope
  %t42 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t41)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l98
  br label %bb4
bb4:
  %t43 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l4
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/interp:Exec", ptr %t44, i32 0, i32 9
  store ptr %t46, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t48, i64 %t49)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l105
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb7, label %ok.56
ok.56:
  store { i64, ptr } %t53, ptr %l104
  br label %bb6
bb6:
  %t57 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t57, ptr %l101, !tbaa !27
  br label %bb11
bb7:
  %t58 = load i32, ptr %l105, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb91
bb11:
  %t63 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t63, ptr %l7, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb89
bb14:
  br label %bb15
bb15:
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t76, ptr %l114, !tbaa !27
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t77
  %t82 = load i64, ptr %t81, !tbaa !34
  store i64 %t82, ptr %l10, !tbaa !24
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr %"compiler/interp:Exec", ptr %t84, i32 0, i32 1
  %t87 = load i64, ptr %l10, !tbaa !24
  %t90 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l120
  br label %bb16
bb16:
  %t91 = load ptr, ptr %l120, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Body", ptr %t91, i32 0, i32 1
  %t94 = load { i64, [2 x i64] }, ptr %t93
  store { i64, [2 x i64] } %t94, ptr %l11
  %t96 = load { i64, [2 x i64] }, ptr %l11
  %t98 = extractvalue { i64, [2 x i64] } %t96, 0
  %t99 = icmp eq i64 %t98, 6
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t102 = getelementptr { i64, i32 }, ptr %t101, i32 0, i32 0
  %t103 = load i64, ptr %t102
  store i64 %t103, ptr %l12, !tbaa !24
  %t105 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t106 = getelementptr { i64, i32 }, ptr %t105, i32 0, i32 1
  %t107 = load i32, ptr %t106
  store i32 %t107, ptr %l13, !tbaa !23
  br label %bb19
bb18:
  br label %bb82
bb19:
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = getelementptr %"compiler/interp:Exec", ptr %t109, i32 0, i32 4
  %t112 = load i64, ptr %l12, !tbaa !24
  %t113 = load i32, ptr %l13, !tbaa !23
  %t117 = call { i32, %"compiler/eval:Image" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eImage(ptr %v0, ptr %v1, ptr %t111, i64 %t112, i32 %t113)
  %t118 = extractvalue { i32, %"compiler/eval:Image" } %t117, 1
  %t119 = extractvalue { i32, %"compiler/eval:Image" } %t117, 0
  store i32 %t119, ptr %l133
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb21, label %ok.121
ok.121:
  store %"compiler/eval:Image" %t118, ptr %l132
  br label %bb20
bb20:
  %t122 = load %"compiler/eval:Image", ptr %l132
  store %"compiler/eval:Image" %t122, ptr %l127
  br label %bb80
bb21:
  %t123 = load i32, ptr %l133, !tbaa !23
  %t124 = ashr i32 %t123, 16
  %t126 = icmp eq i32 %t124, 1
  br i1 %t126, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb24:
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t130 = getelementptr %"compiler/interp:Exec", ptr %t128, i32 0, i32 4
  %t131 = getelementptr %"compiler/eval:Machine", ptr %t130, i32 0, i32 10
  %t132 = load { i64, [5 x i64] }, ptr %t131
  store { i64, [5 x i64] } %t132, ptr %l14
  %t134 = load { i64, [5 x i64] }, ptr %l14
  %t136 = extractvalue { i64, [5 x i64] } %t134, 0
  %t137 = icmp eq i64 %t136, 3
  br i1 %t137, label %bb25, label %bb26
bb25:
  %t139 = getelementptr { i64, [5 x i64] }, ptr %l14, i32 0, i32 1
  %t140 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t139, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140
  store { i64, ptr } %t141, ptr %l15, !tbaa !27
  %t143 = getelementptr { i64, [5 x i64] }, ptr %l14, i32 0, i32 1
  %t144 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t143, i32 0, i32 1
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l16, !tbaa !24
  %t147 = getelementptr { i64, [5 x i64] }, ptr %l14, i32 0, i32 1
  %t148 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t147, i32 0, i32 2
  %t149 = load %"compiler/source:Span", ptr %t148
  store %"compiler/source:Span" %t149, ptr %l17
  br label %bb27
bb26:
  br label %bb42
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t151 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t152 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t153 = load ptr, ptr @__olang_prog_scope
  %t156 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t153, { i64, ptr } %t151, { i64, ptr } %t152)
  store i1 %t156, ptr %l145
  br label %bb28
bb28:
  %t157 = load i1, ptr %l145, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb88
bb30:
  br label %bb31
bb31:
  %t160 = load i64, ptr %l16, !tbaa !24
  %t161 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t162 = load i32, ptr %t161, !tbaa !23
  %t164 = sext i32 %t162 to i64
  %t167 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s6, i64 %t160, i64 %t164)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t167, ptr %l150
  br label %bb32
bb32:
  %t168 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l150
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t168, ptr %l18
  %t169 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t172 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t169)
  store i1 %t172, ptr %l153
  br label %bb33
bb33:
  %t173 = load i1, ptr %l153, !tbaa !21
  br i1 %t173, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb88
bb35:
  br label %bb36
bb36:
  %t174 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t174, i1 true)
  br label %bb37
bb37:
  %t177 = load ptr, ptr %l2, !tbaa !29
  %t179 = getelementptr %"compiler/interp:Exec", ptr %t177, i32 0, i32 1
  %t180 = load i64, ptr %l10, !tbaa !24
  %t183 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t179, i64 %t180)
  store ptr %t183, ptr %l159
  br label %bb38
bb38:
  %t184 = load ptr, ptr %l159, !tbaa !29
  store ptr %t184, ptr %l19, !tbaa !29
  %t185 = load ptr, ptr %l3, !tbaa !29
  store ptr %t185, ptr %l160, !tbaa !29
  %t186 = load ptr, ptr %l19, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Body", ptr %t186, i32 0, i32 3
  %t189 = load i64, ptr %t188, !tbaa !24
  %t190 = load ptr, ptr %l19, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Body", ptr %t190, i32 0, i32 4
  %t193 = getelementptr %"compiler/source:Span", ptr %t192, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t197 = load ptr, ptr %l19, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Body", ptr %t197, i32 0, i32 4
  %t200 = getelementptr %"compiler/source:Span", ptr %t199, i32 0, i32 1
  %t201 = load i32, ptr %t200, !tbaa !23
  %t203 = sext i32 %t201 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 0
  store i64 3, ptr %t205
  %t207 = insertvalue { i64, i64, i64 } undef, i64 %t189, 0
  %t209 = insertvalue { i64, i64, i64 } %t207, i64 %t196, 1
  %t211 = insertvalue { i64, i64, i64 } %t209, i64 %t203, 2
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  store { i64, i64, i64 } %t211, ptr %t212
  %t213 = load { i64, [3 x i64] }, ptr %t204
  store { i64, [3 x i64] } %t213, ptr %l169
  %t214 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t216 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalStale(ptr %v0, ptr %s6, { i64, ptr } %t214)
  store %"compiler/msgs:Msg" %t216, ptr %l171
  br label %bb39
bb39:
  %t217 = load ptr, ptr %l160, !tbaa !29
  %t218 = load { i64, [3 x i64] }, ptr %l169
  %t219 = load %"compiler/msgs:Msg", ptr %l171
  %t220 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t217, { i64, [3 x i64] } %t218, %"compiler/msgs:Msg" %t219)
  store i64 %t220, ptr %l172
  br label %bb40
bb40:
  %t221 = load i64, ptr %l172, !tbaa !24
  %t222 = load ptr, ptr %l2, !tbaa !29
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t225 = load i64, ptr %l16, !tbaa !24
  %t226 = load %"compiler/source:Span", ptr %l17
  call void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v0, ptr %t222, ptr %t223, i64 %t221, i64 %t225, %"compiler/source:Span" %t226)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb79
bb42:
  %t232 = load { i64, [5 x i64] }, ptr %l14
  %t234 = extractvalue { i64, [5 x i64] } %t232, 0
  %t235 = icmp eq i64 %t234, 2
  br i1 %t235, label %bb43, label %bb44
bb43:
  %t237 = getelementptr { i64, [5 x i64] }, ptr %l14, i32 0, i32 1
  %t238 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t237, i32 0, i32 0
  %t239 = load i32, ptr %t238
  store i32 %t239, ptr %l21
  %t241 = getelementptr { i64, [5 x i64] }, ptr %l14, i32 0, i32 1
  %t242 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t241, i32 0, i32 1
  %t243 = load i64, ptr %t242
  store i64 %t243, ptr %l22, !tbaa !24
  %t245 = getelementptr { i64, [5 x i64] }, ptr %l14, i32 0, i32 1
  %t246 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t245, i32 0, i32 2
  %t247 = load %"compiler/source:Span", ptr %t246
  store %"compiler/source:Span" %t247, ptr %l23
  br label %bb45
bb44:
  br label %bb74
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t249 = load i32, ptr %l21
  store i32 %t249, ptr %l183
  store i32 0, ptr %l185
  %t252 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l183, ptr %l185)
  store i1 %t252, ptr %l187
  br label %bb46
bb46:
  %t253 = load i1, ptr %l187, !tbaa !21
  br i1 %t253, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l188, !tbaa !21
  br label %bb50
bb48:
  %t254 = load i32, ptr %l21
  store i32 %t254, ptr %l189
  store i32 1, ptr %l191
  %t257 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l189, ptr %l191)
  store i1 %t257, ptr %l193
  br label %bb49
bb49:
  %t258 = load i1, ptr %l193, !tbaa !21
  store i1 %t258, ptr %l188, !tbaa !21
  br label %bb50
bb50:
  %t259 = load i1, ptr %l188, !tbaa !21
  br i1 %t259, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s3)
  br label %bb88
bb52:
  br label %bb53
bb53:
  %t260 = load i64, ptr %l22, !tbaa !24
  %t261 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 0
  %t262 = load i32, ptr %t261, !tbaa !23
  %t264 = sext i32 %t262 to i64
  %t267 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s9, i64 %t260, i64 %t264)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t267, ptr %l197
  br label %bb54
bb54:
  %t268 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l197
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t268, ptr %l24
  %t269 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l24
  %t272 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t269)
  store i1 %t272, ptr %l200
  br label %bb55
bb55:
  %t273 = load i1, ptr %l200, !tbaa !21
  br i1 %t273, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s3)
  br label %bb88
bb57:
  br label %bb58
bb58:
  %t274 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t274, i1 true)
  br label %bb59
bb59:
  %t277 = load ptr, ptr %l2, !tbaa !29
  %t279 = getelementptr %"compiler/interp:Exec", ptr %t277, i32 0, i32 1
  %t280 = load i64, ptr %l10, !tbaa !24
  %t283 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t279, i64 %t280)
  store ptr %t283, ptr %l206
  br label %bb60
bb60:
  %t284 = load ptr, ptr %l206, !tbaa !29
  store ptr %t284, ptr %l25, !tbaa !29
  %t285 = load ptr, ptr %l25, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Body", ptr %t285, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = load ptr, ptr %l25, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Body", ptr %t289, i32 0, i32 4
  %t292 = getelementptr %"compiler/source:Span", ptr %t291, i32 0, i32 0
  %t293 = load i32, ptr %t292, !tbaa !23
  %t295 = sext i32 %t293 to i64
  %t296 = load ptr, ptr %l25, !tbaa !29
  %t298 = getelementptr %"compiler/typed:Body", ptr %t296, i32 0, i32 4
  %t299 = getelementptr %"compiler/source:Span", ptr %t298, i32 0, i32 1
  %t300 = load i32, ptr %t299, !tbaa !23
  %t302 = sext i32 %t300 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t303
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t303, i32 0, i32 0
  store i64 3, ptr %t304
  %t306 = insertvalue { i64, i64, i64 } undef, i64 %t288, 0
  %t308 = insertvalue { i64, i64, i64 } %t306, i64 %t295, 1
  %t310 = insertvalue { i64, i64, i64 } %t308, i64 %t302, 2
  %t311 = getelementptr { i64, [3 x i64] }, ptr %t303, i32 0, i32 1
  store { i64, i64, i64 } %t310, ptr %t311
  %t312 = load { i64, [3 x i64] }, ptr %t303
  %t314 = load ptr, ptr %l3, !tbaa !29
  store ptr %t314, ptr %l216, !tbaa !29
  store { i64, [3 x i64] } %t312, ptr %l217
  %t316 = load i32, ptr %l21
  %t318 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s9, i32 %t316)
  store { i64, ptr } %t318, ptr %l219
  br label %bb61
bb61:
  %t319 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t320 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalAborts(ptr %s9, ptr %s9, { i64, ptr } %t319)
  store %"compiler/msgs:Msg" %t320, ptr %l220
  br label %bb62
bb62:
  %t321 = load ptr, ptr %l216, !tbaa !29
  %t322 = load { i64, [3 x i64] }, ptr %l217
  %t323 = load %"compiler/msgs:Msg", ptr %l220
  %t324 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t321, { i64, [3 x i64] } %t322, %"compiler/msgs:Msg" %t323)
  store i64 %t324, ptr %l221
  br label %bb63
bb63:
  %t325 = load i64, ptr %l221, !tbaa !24
  store i64 %t325, ptr %l27, !tbaa !24
  %t326 = load i64, ptr %l22, !tbaa !24
  %t327 = load ptr, ptr %l25, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Body", ptr %t327, i32 0, i32 3
  %t330 = load i64, ptr %t329, !tbaa !24
  %t333 = icmp ne i64 %t326, %t330
  br i1 %t333, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l226, !tbaa !21
  br label %bb68
bb65:
  %t335 = load ptr, ptr %l3, !tbaa !29
  %t336 = load i64, ptr %l22, !tbaa !24
  %t337 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 0
  %t338 = load i32, ptr %t337, !tbaa !23
  %t340 = sext i32 %t338 to i64
  %t344 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t335, i64 %t336, i64 %t340)
  store i64 %t344, ptr %l231
  br label %bb66
bb66:
  %t345 = load ptr, ptr %l3, !tbaa !29
  %t346 = load ptr, ptr %l25, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Body", ptr %t346, i32 0, i32 3
  %t349 = load i64, ptr %t348, !tbaa !24
  %t350 = load ptr, ptr %l25, !tbaa !29
  %t352 = getelementptr %"compiler/typed:Body", ptr %t350, i32 0, i32 4
  %t353 = getelementptr %"compiler/source:Span", ptr %t352, i32 0, i32 0
  %t354 = load i32, ptr %t353, !tbaa !23
  %t356 = sext i32 %t354 to i64
  %t360 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t345, i64 %t349, i64 %t356)
  store i64 %t360, ptr %l238
  br label %bb67
bb67:
  %t361 = load i64, ptr %l231, !tbaa !24
  %t362 = load i64, ptr %l238, !tbaa !24
  %t363 = icmp ne i64 %t361, %t362
  store i1 %t363, ptr %l226, !tbaa !21
  br label %bb68
bb68:
  %t365 = load i1, ptr %l226, !tbaa !21
  br i1 %t365, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s12
  %t366 = load ptr, ptr %l3, !tbaa !29
  store ptr %t366, ptr %l240, !tbaa !29
  %t367 = load i64, ptr %l27, !tbaa !24
  store i64 %t367, ptr %l241, !tbaa !24
  %t368 = load i64, ptr %l22, !tbaa !24
  %t369 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 0
  %t370 = load i32, ptr %t369, !tbaa !23
  %t372 = sext i32 %t370 to i64
  %t373 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 1
  %t374 = load i32, ptr %t373, !tbaa !23
  %t376 = sext i32 %t374 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t377
  %t378 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 0
  store i64 3, ptr %t378
  %t380 = insertvalue { i64, i64, i64 } undef, i64 %t368, 0
  %t382 = insertvalue { i64, i64, i64 } %t380, i64 %t372, 1
  %t384 = insertvalue { i64, i64, i64 } %t382, i64 %t376, 2
  %t385 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 1
  store { i64, i64, i64 } %t384, ptr %t385
  %t386 = load { i64, [3 x i64] }, ptr %t377
  store { i64, [3 x i64] } %t386, ptr %l247
  %t387 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s12)
  store %"compiler/msgs:Msg" %t387, ptr %l248
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t388 = load ptr, ptr %l240, !tbaa !29
  %t389 = load i64, ptr %l241, !tbaa !24
  %t390 = load { i64, [3 x i64] }, ptr %l247
  %t391 = load %"compiler/msgs:Msg", ptr %l248
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s12, ptr %t388, i64 %t389, { i64, [3 x i64] } %t390, %"compiler/msgs:Msg" %t391)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s12)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s9)
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb79:
  call void @__olang_scope_close(ptr %s3)
  br label %bb88
bb80:
  %t392 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t392, ptr %lp28
  %t393 = load %"compiler/eval:Image", ptr %l127
  %t394 = load ptr, ptr %lp28
  store %"compiler/eval:Image" %t393, ptr %t394
  %t395 = load ptr, ptr %lp1
  %t396 = load i64, ptr %l10, !tbaa !24
  %t397 = load ptr, ptr %lp28
  %t398 = load %"compiler/eval:Image", ptr %t397
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v1, ptr %v1, ptr %t395, i64 %t396, %"compiler/eval:Image" %t398)
  br label %bb81
bb81:
  br label %bb87
bb82:
  br i1 true, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb87:
  call void @__olang_scope_close(ptr %s3)
  br label %bb88
bb88:
  %t402 = load i64, ptr %l9, !tbaa !24
  %t404 = add i64 %t402, 1
  store i64 %t404, ptr %l9, !tbaa !24
  br label %bb12
bb89:
  %t406 = load i64, ptr %l6, !tbaa !24
  %t407 = load i64, ptr %l8, !tbaa !24
  %t410 = add i64 %t406, %t407
  store i64 %t410, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb90:
  br label %bb5
bb91:
  %t412 = load ptr, ptr @__olang_prog_scope
  %t413 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %t412)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t413, ptr %l257
  br label %bb92
bb92:
  %t414 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l257
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t414, ptr %l29
  %t415 = load ptr, ptr %l2, !tbaa !29
  %t417 = getelementptr %"compiler/interp:Exec", ptr %t415, i32 0, i32 9
  store ptr %t417, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s17
  %t419 = load ptr, ptr %l30, !tbaa !29
  %t420 = load i64, ptr %l31, !tbaa !24
  %t423 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t419, i64 %t420)
  %t424 = extractvalue { i32, { i64, ptr } } %t423, 1
  %t425 = extractvalue { i32, { i64, ptr } } %t423, 0
  store i32 %t425, ptr %l264
  %t426 = icmp ne i32 %t425, 0
  br i1 %t426, label %bb95, label %ok.427
ok.427:
  store { i64, ptr } %t424, ptr %l263
  br label %bb94
bb94:
  %t428 = load { i64, ptr }, ptr %l263, !tbaa !27
  store { i64, ptr } %t428, ptr %l260, !tbaa !27
  br label %bb99
bb95:
  %t429 = load i32, ptr %l264, !tbaa !23
  %t430 = ashr i32 %t429, 16
  %t432 = icmp eq i32 %t430, 1
  br i1 %t432, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb98:
  call void @__olang_scope_close(ptr %s17)
  br label %bb272
bb99:
  %t434 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t434, ptr %l32, !tbaa !27
  %t435 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t435, 0
  store i64 %t437, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t439 = load i64, ptr %l34, !tbaa !24
  %t440 = load i64, ptr %l33, !tbaa !24
  %t443 = icmp slt i64 %t439, %t440
  %t445 = xor i1 %t443, true
  br i1 %t445, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s18)
  br label %bb270
bb102:
  br label %bb103
bb103:
  %t447 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t447, ptr %l273, !tbaa !27
  %t448 = load i64, ptr %l34, !tbaa !24
  %t450 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !27
  %t452 = getelementptr i64, ptr %t451, i64 %t448
  %t453 = load i64, ptr %t452, !tbaa !34
  store i64 %t453, ptr %l35, !tbaa !24
  %t455 = load ptr, ptr %lp1
  %t456 = load i64, ptr %l35, !tbaa !24
  %t459 = call { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v1, ptr %v1, ptr %t455, i64 %t456)
  %t460 = extractvalue { i32, %"compiler/eval:Image" } %t459, 1
  %t461 = extractvalue { i32, %"compiler/eval:Image" } %t459, 0
  store i32 %t461, ptr %l280
  %t462 = icmp ne i32 %t461, 0
  br i1 %t462, label %bb105, label %ok.463
ok.463:
  store %"compiler/eval:Image" %t460, ptr %l279
  br label %bb104
bb104:
  %t464 = load %"compiler/eval:Image", ptr %l279
  store %"compiler/eval:Image" %t464, ptr %l276
  br label %bb107
bb105:
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s18)
  br label %bb269
bb107:
  %t465 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t465, ptr %lp36
  %t466 = load %"compiler/eval:Image", ptr %l276
  %t467 = load ptr, ptr %lp36
  store %"compiler/eval:Image" %t466, ptr %t467
  %t468 = load ptr, ptr %l2, !tbaa !29
  %t470 = getelementptr %"compiler/interp:Exec", ptr %t468, i32 0, i32 1
  %t471 = load i64, ptr %l35, !tbaa !24
  %t474 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t470, i64 %t471)
  store ptr %t474, ptr %l284
  br label %bb108
bb108:
  %t475 = load ptr, ptr %l284, !tbaa !29
  %t476 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t475)
  store i64 %t476, ptr %l285
  br label %bb109
bb109:
  %t477 = load i64, ptr %l285, !tbaa !24
  store i64 %t477, ptr %l37, !tbaa !24
  store i1 true, ptr %l38, !tbaa !21
  %t478 = load ptr, ptr %lp36
  %t479 = getelementptr %"compiler/eval:Image", ptr %t478, i32 0, i32 0
  %t481 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t479)
  store i64 %t481, ptr %l287
  br label %bb110
bb110:
  %t482 = load i64, ptr %l287, !tbaa !24
  %t483 = icmp sge i64 %t482, 0
  br i1 %t483, label %bb111, label %bb112
bb111:
  %t485 = load i64, ptr %l287, !tbaa !24
  %t486 = icmp sle i64 %t485, 1152921504606846975
  br i1 %t486, label %bb113, label %bb114
bb112:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb113:
  %t488 = load i64, ptr %l287, !tbaa !24
  %t489 = mul i64 %t488, 8
  %t490 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t489)
  store i64 0, ptr %t491
  br label %fill.492
fill.492:
  %t495 = load i64, ptr %t491
  %t496 = icmp slt i64 %t495, %t488
  br i1 %t496, label %fillb.493, label %filld.494
fillb.493:
  %t497 = getelementptr i64, ptr %t490, i64 %t495
  store i64 -1, ptr %t497
  %t498 = add i64 %t495, 1
  store i64 %t498, ptr %t491
  br label %fill.492
filld.494:
  %t499 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t490, 1
  store { i64, ptr } %t500, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  %t502 = load ptr, ptr %lp36
  %t503 = getelementptr %"compiler/eval:Image", ptr %t502, i32 0, i32 0
  %t505 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t503)
  store i64 %t505, ptr %l292
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb115:
  %t506 = load i64, ptr %l292, !tbaa !24
  store i64 %t506, ptr %l42, !tbaa !24
  store i64 1, ptr %l43, !tbaa !24
  %t507 = load i64, ptr %l42, !tbaa !24
  %t508 = load i64, ptr %l41, !tbaa !24
  %t511 = icmp sgt i64 %t507, %t508
  br i1 %t511, label %bb116, label %bb117
bb116:
  %t513 = load i64, ptr %l43, !tbaa !24
  %t515 = icmp sgt i64 %t513, 0
  br i1 %t515, label %bb118, label %bb119
bb117:
  store i64 0, ptr %l296, !tbaa !24
  br label %bb121
bb118:
  %t517 = load i64, ptr %l42, !tbaa !24
  %t518 = load i64, ptr %l41, !tbaa !24
  %t521 = sub i64 %t517, %t518
  %t522 = load i64, ptr %l43, !tbaa !24
  %t525 = add i64 %t521, %t522
  %t527 = sub i64 %t525, 1
  %t528 = load i64, ptr %l43, !tbaa !24
  %t531 = sdiv i64 %t527, %t528
  store i64 %t531, ptr %l299, !tbaa !24
  br label %bb120
bb119:
  store i64 0, ptr %l299, !tbaa !24
  br label %bb120
bb120:
  %t533 = load i64, ptr %l299, !tbaa !24
  store i64 %t533, ptr %l296, !tbaa !24
  br label %bb121
bb121:
  %t534 = load i64, ptr %l296, !tbaa !24
  store i64 %t534, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s21
  %t535 = load i64, ptr %l45, !tbaa !24
  %t536 = load i64, ptr %l44, !tbaa !24
  %t539 = icmp slt i64 %t535, %t536
  %t541 = xor i1 %t539, true
  br i1 %t541, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s21)
  br label %bb145
bb124:
  br label %bb125
bb125:
  %t543 = load i64, ptr %l41, !tbaa !24
  %t544 = load i64, ptr %l45, !tbaa !24
  %t545 = load i64, ptr %l43, !tbaa !24
  %t548 = mul i64 %t544, %t545
  %t551 = add i64 %t543, %t548
  store i64 %t551, ptr %l46, !tbaa !24
  %t553 = load ptr, ptr %lp36
  %t554 = getelementptr %"compiler/eval:Image", ptr %t553, i32 0, i32 1
  %t555 = load i64, ptr %l46, !tbaa !24
  %t558 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t554, i64 %t555)
  store i64 %t558, ptr %l319
  br label %bb126
bb126:
  %t559 = load i64, ptr %l319, !tbaa !24
  store i64 %t559, ptr %l47, !tbaa !24
  %t560 = load i64, ptr %l46, !tbaa !24
  %t562 = icmp sgt i64 %t560, 0
  br i1 %t562, label %bb127, label %bb128
bb127:
  %t564 = load i64, ptr %l47, !tbaa !24
  %t567 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H3ccda5e77fabf86fda89ecfc77eff03d(ptr %s0, ptr %l29, i64 %t564)
  store i1 %t567, ptr %l325
  br label %bb129
bb128:
  store i1 false, ptr %l322, !tbaa !21
  br label %bb130
bb129:
  %t568 = load i1, ptr %l325, !tbaa !21
  store i1 %t568, ptr %l322, !tbaa !21
  br label %bb130
bb130:
  %t569 = load i1, ptr %l322, !tbaa !21
  br i1 %t569, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s22
  %t570 = load i64, ptr %l47, !tbaa !24
  %t573 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l29, i64 %t570)
  %t574 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t573, 1
  %t575 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t573, 0
  store i32 %t575, ptr %l330
  %t576 = icmp ne i32 %t575, 0
  br i1 %t576, label %bb134, label %ok.577
ok.577:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t574, ptr %l329
  br label %bb133
bb132:
  br label %bb143
bb133:
  %t578 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l329
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t578, ptr %l326
  br label %bb137
bb134:
  br label %bb135
bb135:
  %t579 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s22, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t579, ptr %l331
  br label %bb136
bb136:
  %t580 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l331
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t580, ptr %l326
  br label %bb137
bb137:
  %t581 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l326
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t581, ptr %l48
  %t582 = load ptr, ptr %l2, !tbaa !29
  %t584 = getelementptr %"compiler/interp:Exec", ptr %t582, i32 0, i32 1
  %t585 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l48, i32 0, i32 0
  %t586 = load i64, ptr %t585, !tbaa !24
  %t589 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t584, i64 %t586)
  store ptr %t589, ptr %l335
  br label %bb138
bb138:
  %t590 = load ptr, ptr %l335, !tbaa !29
  %t591 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t590)
  store i64 %t591, ptr %l336
  br label %bb139
bb139:
  %t592 = load i64, ptr %l37, !tbaa !24
  %t593 = load i64, ptr %l336, !tbaa !24
  %t595 = icmp ne i64 %t593, %t592
  br i1 %t595, label %bb140, label %bb141
bb140:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb142
bb141:
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  br label %bb144
bb143:
  %t597 = load i64, ptr %l46, !tbaa !24
  %t598 = load i64, ptr %l40, !tbaa !24
  %t601 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !27
  %t603 = getelementptr i64, ptr %t602, i64 %t597
  store i64 %t598, ptr %t603, !tbaa !34
  %t604 = load i64, ptr %l40, !tbaa !24
  %t606 = add i64 %t604, 1
  store i64 %t606, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb144
bb144:
  %t608 = load i64, ptr %l45, !tbaa !24
  %t610 = add i64 %t608, 1
  store i64 %t610, ptr %l45, !tbaa !24
  br label %bb122
bb145:
  %t612 = load ptr, ptr %lp36
  %t613 = getelementptr %"compiler/eval:Image", ptr %t612, i32 0, i32 0
  store ptr %t613, ptr %l49, !tbaa !29
  store i64 0, ptr %l50, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s26
  %t615 = load ptr, ptr %l49, !tbaa !29
  %t616 = load i64, ptr %l50, !tbaa !24
  %t619 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eRunFrom_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t615, i64 %t616)
  %t620 = extractvalue { i32, { i64, ptr } } %t619, 1
  %t621 = extractvalue { i32, { i64, ptr } } %t619, 0
  store i32 %t621, ptr %l350
  %t622 = icmp ne i32 %t621, 0
  br i1 %t622, label %bb148, label %ok.623
ok.623:
  store { i64, ptr } %t620, ptr %l349
  br label %bb147
bb147:
  %t624 = load { i64, ptr }, ptr %l349, !tbaa !27
  store { i64, ptr } %t624, ptr %l346, !tbaa !27
  br label %bb152
bb148:
  %t625 = load i32, ptr %l350, !tbaa !23
  %t626 = ashr i32 %t625, 16
  %t628 = icmp eq i32 %t626, 1
  br i1 %t628, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb151:
  call void @__olang_scope_close(ptr %s26)
  br label %bb191
bb152:
  %t630 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t630, ptr %l51, !tbaa !27
  %t631 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t633 = extractvalue { i64, ptr } %t631, 0
  store i64 %t633, ptr %l52, !tbaa !24
  store i64 0, ptr %l53, !tbaa !24
  br label %bb153
bb153:
  store %olang.scope zeroinitializer, ptr %s27
  %t635 = load i64, ptr %l53, !tbaa !24
  %t636 = load i64, ptr %l52, !tbaa !24
  %t639 = icmp slt i64 %t635, %t636
  %t641 = xor i1 %t639, true
  br i1 %t641, label %bb154, label %bb155
bb154:
  call void @__olang_scope_close(ptr %s27)
  br label %bb189
bb155:
  br label %bb156
bb156:
  %t643 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t643, ptr %l359, !tbaa !27
  %t644 = load i64, ptr %l53, !tbaa !24
  %t646 = getelementptr { i64, ptr }, ptr %l359, i32 0, i32 1
  %t647 = load ptr, ptr %t646, !tbaa !27
  %t648 = getelementptr %"compiler/eval:Blob", ptr %t647, i64 %t644
  %t649 = load %"compiler/eval:Blob", ptr %t648
  store %"compiler/eval:Blob" %t649, ptr %l54
  %t651 = getelementptr %"compiler/eval:Blob", ptr %l54, i32 0, i32 6
  store ptr %t651, ptr %l55, !tbaa !29
  store i64 0, ptr %l56, !tbaa !24
  br label %bb157
bb157:
  store %olang.scope zeroinitializer, ptr %s29
  %t653 = load ptr, ptr %l55, !tbaa !29
  %t654 = load i64, ptr %l56, !tbaa !24
  %t657 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t653, i64 %t654)
  %t658 = extractvalue { i32, { i64, ptr } } %t657, 1
  %t659 = extractvalue { i32, { i64, ptr } } %t657, 0
  store i32 %t659, ptr %l367
  %t660 = icmp ne i32 %t659, 0
  br i1 %t660, label %bb159, label %ok.661
ok.661:
  store { i64, ptr } %t658, ptr %l366
  br label %bb158
bb158:
  %t662 = load { i64, ptr }, ptr %l366, !tbaa !27
  store { i64, ptr } %t662, ptr %l363, !tbaa !27
  br label %bb163
bb159:
  %t663 = load i32, ptr %l367, !tbaa !23
  %t664 = ashr i32 %t663, 16
  %t666 = icmp eq i32 %t664, 1
  br i1 %t666, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb162:
  call void @__olang_scope_close(ptr %s29)
  br label %bb187
bb163:
  %t668 = load { i64, ptr }, ptr %l363, !tbaa !27
  store { i64, ptr } %t668, ptr %l57, !tbaa !27
  %t669 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t671 = extractvalue { i64, ptr } %t669, 0
  store i64 %t671, ptr %l58, !tbaa !24
  store i64 0, ptr %l59, !tbaa !24
  br label %bb164
bb164:
  store %olang.scope zeroinitializer, ptr %s30
  %t673 = load i64, ptr %l59, !tbaa !24
  %t674 = load i64, ptr %l58, !tbaa !24
  %t677 = icmp slt i64 %t673, %t674
  %t679 = xor i1 %t677, true
  br i1 %t679, label %bb165, label %bb166
bb165:
  call void @__olang_scope_close(ptr %s30)
  br label %bb185
bb166:
  br label %bb167
bb167:
  %t681 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t681, ptr %l376, !tbaa !27
  %t682 = load i64, ptr %l59, !tbaa !24
  %t684 = getelementptr { i64, ptr }, ptr %l376, i32 0, i32 1
  %t685 = load ptr, ptr %t684, !tbaa !27
  %t686 = getelementptr i64, ptr %t685, i64 %t682
  %t687 = load i64, ptr %t686, !tbaa !34
  store i64 %t687, ptr %l60, !tbaa !24
  %t689 = load i64, ptr %l60, !tbaa !24
  %t691 = icmp slt i64 %t689, 0
  br i1 %t691, label %bb168, label %bb169
bb168:
  call void @__olang_scope_close(ptr %s30)
  br label %bb184
bb169:
  br label %bb170
bb170:
  %t693 = load i64, ptr %l60, !tbaa !24
  %t696 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l29, i64 %t693)
  %t697 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t696, 1
  %t698 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t696, 0
  store i32 %t698, ptr %l385
  %t699 = icmp ne i32 %t698, 0
  br i1 %t699, label %bb172, label %ok.700
ok.700:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t697, ptr %l384
  br label %bb171
bb171:
  %t701 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l384
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t701, ptr %l381
  br label %bb175
bb172:
  br label %bb173
bb173:
  %t702 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s30, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t702, ptr %l386
  br label %bb174
bb174:
  %t703 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l386
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t703, ptr %l381
  br label %bb175
bb175:
  %t704 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l381
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t704, ptr %l61
  %t705 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l61, i32 0, i32 0
  %t706 = load i64, ptr %t705, !tbaa !24
  %t708 = icmp slt i64 %t706, 0
  br i1 %t708, label %bb176, label %bb177
bb176:
  store i1 true, ptr %l389, !tbaa !21
  br label %bb180
bb177:
  %t710 = load ptr, ptr %l2, !tbaa !29
  %t712 = getelementptr %"compiler/interp:Exec", ptr %t710, i32 0, i32 1
  %t713 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l61, i32 0, i32 0
  %t714 = load i64, ptr %t713, !tbaa !24
  %t717 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t712, i64 %t714)
  store ptr %t717, ptr %l393
  br label %bb178
bb178:
  %t718 = load ptr, ptr %l393, !tbaa !29
  %t719 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t718)
  store i64 %t719, ptr %l394
  br label %bb179
bb179:
  %t720 = load i64, ptr %l37, !tbaa !24
  %t721 = load i64, ptr %l394, !tbaa !24
  %t723 = icmp ne i64 %t721, %t720
  store i1 %t723, ptr %l389, !tbaa !21
  br label %bb180
bb180:
  %t725 = load i1, ptr %l389, !tbaa !21
  br i1 %t725, label %bb181, label %bb182
bb181:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb183
bb182:
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s30)
  br label %bb184
bb184:
  %t726 = load i64, ptr %l59, !tbaa !24
  %t728 = add i64 %t726, 1
  store i64 %t728, ptr %l59, !tbaa !24
  br label %bb164
bb185:
  %t730 = load i64, ptr %l56, !tbaa !24
  %t731 = load i64, ptr %l58, !tbaa !24
  %t734 = add i64 %t730, %t731
  store i64 %t734, ptr %l56, !tbaa !24
  call void @__olang_scope_close(ptr %s29)
  br label %bb186
bb186:
  br label %bb157
bb187:
  call void @__olang_scope_close(ptr %s27)
  br label %bb188
bb188:
  %t736 = load i64, ptr %l53, !tbaa !24
  %t738 = add i64 %t736, 1
  store i64 %t738, ptr %l53, !tbaa !24
  br label %bb153
bb189:
  %t740 = load i64, ptr %l50, !tbaa !24
  %t741 = load i64, ptr %l52, !tbaa !24
  %t744 = add i64 %t740, %t741
  store i64 %t744, ptr %l50, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb190
bb190:
  br label %bb146
bb191:
  %t746 = load i1, ptr %l38, !tbaa !21
  %t748 = xor i1 %t746, true
  br i1 %t748, label %bb192, label %bb193
bb192:
  %t750 = load ptr, ptr %lp1
  %t751 = load i64, ptr %l35, !tbaa !24
  %t754 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H8e3ab02101333f4dae95aad48f2e722e(ptr %v1, ptr %t750, i64 %t751)
  store i1 %t754, ptr %l411
  br label %bb194
bb193:
  br label %bb195
bb194:
  call void @__olang_scope_close(ptr %s18)
  br label %bb269
bb195:
  %t755 = call %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v1)
  store %"compiler/eval:Image" %t755, ptr %l412
  br label %bb196
bb196:
  %t756 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t756, ptr %lp62
  %t757 = load %"compiler/eval:Image", ptr %l412
  %t758 = load ptr, ptr %lp62
  store %"compiler/eval:Image" %t757, ptr %t758
  store i64 0, ptr %l63, !tbaa !24
  %t759 = load ptr, ptr %lp36
  %t760 = getelementptr %"compiler/eval:Image", ptr %t759, i32 0, i32 0
  %t762 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t760)
  store i64 %t762, ptr %l414
  br label %bb197
bb197:
  %t763 = load i64, ptr %l414, !tbaa !24
  store i64 %t763, ptr %l64, !tbaa !24
  store i64 1, ptr %l65, !tbaa !24
  %t764 = load i64, ptr %l64, !tbaa !24
  %t765 = load i64, ptr %l63, !tbaa !24
  %t768 = icmp sgt i64 %t764, %t765
  br i1 %t768, label %bb198, label %bb199
bb198:
  %t770 = load i64, ptr %l65, !tbaa !24
  %t772 = icmp sgt i64 %t770, 0
  br i1 %t772, label %bb200, label %bb201
bb199:
  store i64 0, ptr %l418, !tbaa !24
  br label %bb203
bb200:
  %t774 = load i64, ptr %l64, !tbaa !24
  %t775 = load i64, ptr %l63, !tbaa !24
  %t778 = sub i64 %t774, %t775
  %t779 = load i64, ptr %l65, !tbaa !24
  %t782 = add i64 %t778, %t779
  %t784 = sub i64 %t782, 1
  %t785 = load i64, ptr %l65, !tbaa !24
  %t788 = sdiv i64 %t784, %t785
  store i64 %t788, ptr %l421, !tbaa !24
  br label %bb202
bb201:
  store i64 0, ptr %l421, !tbaa !24
  br label %bb202
bb202:
  %t790 = load i64, ptr %l421, !tbaa !24
  store i64 %t790, ptr %l418, !tbaa !24
  br label %bb203
bb203:
  %t791 = load i64, ptr %l418, !tbaa !24
  store i64 %t791, ptr %l66, !tbaa !24
  store i64 0, ptr %l67, !tbaa !24
  br label %bb204
bb204:
  store %olang.scope zeroinitializer, ptr %s37
  %t792 = load i64, ptr %l67, !tbaa !24
  %t793 = load i64, ptr %l66, !tbaa !24
  %t796 = icmp slt i64 %t792, %t793
  %t798 = xor i1 %t796, true
  br i1 %t798, label %bb205, label %bb206
bb205:
  call void @__olang_scope_close(ptr %s37)
  br label %bb267
bb206:
  br label %bb207
bb207:
  %t800 = load i64, ptr %l63, !tbaa !24
  %t801 = load i64, ptr %l67, !tbaa !24
  %t802 = load i64, ptr %l65, !tbaa !24
  %t805 = mul i64 %t801, %t802
  %t808 = add i64 %t800, %t805
  store i64 %t808, ptr %l68, !tbaa !24
  %t810 = load i64, ptr %l68, !tbaa !24
  %t812 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t813 = load ptr, ptr %t812, !tbaa !27
  %t814 = getelementptr i64, ptr %t813, i64 %t810
  %t815 = load i64, ptr %t814, !tbaa !34
  %t817 = icmp slt i64 %t815, 0
  br i1 %t817, label %bb208, label %bb209
bb208:
  call void @__olang_scope_close(ptr %s37)
  br label %bb266
bb209:
  br label %bb210
bb210:
  %t819 = load ptr, ptr %lp36
  %t820 = getelementptr %"compiler/eval:Image", ptr %t819, i32 0, i32 0
  %t821 = load i64, ptr %l68, !tbaa !24
  %t824 = call %"compiler/eval:Blob" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t820, i64 %t821)
  store %"compiler/eval:Blob" %t824, ptr %l444
  br label %bb211
bb211:
  %t825 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store ptr %t825, ptr %lp69
  %t826 = load %"compiler/eval:Blob", ptr %l444
  %t827 = load ptr, ptr %lp69
  store %"compiler/eval:Blob" %t826, ptr %t827
  %t828 = call %"compiler/eval:Blob" @compiler_2feval_3aBlob_2ector(ptr %v1)
  store %"compiler/eval:Blob" %t828, ptr %l445
  br label %bb212
bb212:
  %t829 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store ptr %t829, ptr %lp70
  %t830 = load %"compiler/eval:Blob", ptr %l445
  %t831 = load ptr, ptr %lp70
  store %"compiler/eval:Blob" %t830, ptr %t831
  %t832 = load ptr, ptr %lp69
  %t833 = getelementptr %"compiler/eval:Blob", ptr %t832, i32 0, i32 0
  %t834 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t833
  %t836 = load ptr, ptr %lp70
  %t837 = getelementptr %"compiler/eval:Blob", ptr %t836, i32 0, i32 0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t834, ptr %t837
  %t838 = load ptr, ptr %lp69
  %t839 = getelementptr %"compiler/eval:Blob", ptr %t838, i32 0, i32 1
  %t840 = load i64, ptr %t839, !tbaa !24
  %t842 = load ptr, ptr %lp70
  %t843 = getelementptr %"compiler/eval:Blob", ptr %t842, i32 0, i32 1
  store i64 %t840, ptr %t843, !tbaa !24
  %t844 = load ptr, ptr %lp69
  %t845 = getelementptr %"compiler/eval:Blob", ptr %t844, i32 0, i32 2
  %t846 = load i1, ptr %t845, !tbaa !21
  %t848 = load ptr, ptr %lp70
  %t849 = getelementptr %"compiler/eval:Blob", ptr %t848, i32 0, i32 2
  store i1 %t846, ptr %t849, !tbaa !21
  store i64 0, ptr %l71, !tbaa !24
  %t850 = load ptr, ptr %lp69
  %t851 = getelementptr %"compiler/eval:Blob", ptr %t850, i32 0, i32 3
  %t853 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t851)
  store i64 %t853, ptr %l450
  br label %bb213
bb213:
  %t854 = load i64, ptr %l450, !tbaa !24
  store i64 %t854, ptr %l72, !tbaa !24
  store i64 1, ptr %l73, !tbaa !24
  %t855 = load i64, ptr %l72, !tbaa !24
  %t856 = load i64, ptr %l71, !tbaa !24
  %t859 = icmp sgt i64 %t855, %t856
  br i1 %t859, label %bb214, label %bb215
bb214:
  %t861 = load i64, ptr %l73, !tbaa !24
  %t863 = icmp sgt i64 %t861, 0
  br i1 %t863, label %bb216, label %bb217
bb215:
  store i64 0, ptr %l454, !tbaa !24
  br label %bb219
bb216:
  %t865 = load i64, ptr %l72, !tbaa !24
  %t866 = load i64, ptr %l71, !tbaa !24
  %t869 = sub i64 %t865, %t866
  %t870 = load i64, ptr %l73, !tbaa !24
  %t873 = add i64 %t869, %t870
  %t875 = sub i64 %t873, 1
  %t876 = load i64, ptr %l73, !tbaa !24
  %t879 = sdiv i64 %t875, %t876
  store i64 %t879, ptr %l457, !tbaa !24
  br label %bb218
bb217:
  store i64 0, ptr %l457, !tbaa !24
  br label %bb218
bb218:
  %t881 = load i64, ptr %l457, !tbaa !24
  store i64 %t881, ptr %l454, !tbaa !24
  br label %bb219
bb219:
  %t882 = load i64, ptr %l454, !tbaa !24
  store i64 %t882, ptr %l74, !tbaa !24
  store i64 0, ptr %l75, !tbaa !24
  br label %bb220
bb220:
  store %olang.scope zeroinitializer, ptr %s40
  %t883 = load i64, ptr %l75, !tbaa !24
  %t884 = load i64, ptr %l74, !tbaa !24
  %t887 = icmp slt i64 %t883, %t884
  %t889 = xor i1 %t887, true
  br i1 %t889, label %bb221, label %bb222
bb221:
  call void @__olang_scope_close(ptr %s40)
  br label %bb259
bb222:
  br label %bb223
bb223:
  %t891 = load i64, ptr %l71, !tbaa !24
  %t892 = load i64, ptr %l75, !tbaa !24
  %t893 = load i64, ptr %l73, !tbaa !24
  %t896 = mul i64 %t892, %t893
  %t899 = add i64 %t891, %t896
  store i64 %t899, ptr %l76, !tbaa !24
  %t901 = load ptr, ptr %lp70
  %t902 = getelementptr %"compiler/eval:Blob", ptr %t901, i32 0, i32 3
  store ptr %t902, ptr %l475, !tbaa !29
  %t903 = load ptr, ptr %lp69
  %t904 = getelementptr %"compiler/eval:Blob", ptr %t903, i32 0, i32 3
  %t905 = load i64, ptr %l76, !tbaa !24
  %t908 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t904, i64 %t905)
  store i64 %t908, ptr %l478
  br label %bb224
bb224:
  %t909 = load ptr, ptr %l475, !tbaa !29
  %t910 = load i64, ptr %l478, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t909, i64 %t910)
  br label %bb225
bb225:
  %t911 = load ptr, ptr %lp70
  %t912 = getelementptr %"compiler/eval:Blob", ptr %t911, i32 0, i32 5
  store ptr %t912, ptr %l479, !tbaa !29
  %t913 = load ptr, ptr %lp69
  %t914 = getelementptr %"compiler/eval:Blob", ptr %t913, i32 0, i32 5
  %t915 = load i64, ptr %l76, !tbaa !24
  %t918 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t914, i64 %t915)
  store i64 %t918, ptr %l482
  br label %bb226
bb226:
  %t919 = load ptr, ptr %l479, !tbaa !29
  %t920 = load i64, ptr %l482, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t919, i64 %t920)
  br label %bb227
bb227:
  %t921 = load ptr, ptr %lp69
  %t922 = getelementptr %"compiler/eval:Blob", ptr %t921, i32 0, i32 4
  %t923 = load i64, ptr %l76, !tbaa !24
  %t926 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t922, i64 %t923)
  store i64 %t926, ptr %l485
  br label %bb228
bb228:
  %t927 = load i64, ptr %l485, !tbaa !24
  %t928 = icmp slt i64 %t927, 0
  br i1 %t928, label %bb229, label %bb230
bb229:
  %t930 = load ptr, ptr %lp69
  %t931 = getelementptr %"compiler/eval:Blob", ptr %t930, i32 0, i32 6
  %t932 = load i64, ptr %l76, !tbaa !24
  %t935 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t931, i64 %t932)
  store i64 %t935, ptr %l490
  br label %bb231
bb230:
  %t936 = load ptr, ptr %lp36
  %t937 = getelementptr %"compiler/eval:Image", ptr %t936, i32 0, i32 1
  store ptr %t937, ptr %l491, !tbaa !29
  %t938 = load ptr, ptr %lp69
  %t939 = getelementptr %"compiler/eval:Blob", ptr %t938, i32 0, i32 4
  %t940 = load i64, ptr %l76, !tbaa !24
  %t943 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t939, i64 %t940)
  store i64 %t943, ptr %l494
  br label %bb232
bb231:
  %t944 = load i64, ptr %l490, !tbaa !24
  store i64 %t944, ptr %l487, !tbaa !24
  br label %bb234
bb232:
  %t945 = load ptr, ptr %l491, !tbaa !29
  %t946 = load i64, ptr %l494, !tbaa !24
  %t947 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t945, i64 %t946)
  store i64 %t947, ptr %l495
  br label %bb233
bb233:
  %t948 = load i64, ptr %l495, !tbaa !24
  store i64 %t948, ptr %l487, !tbaa !24
  br label %bb234
bb234:
  %t949 = load i64, ptr %l487, !tbaa !24
  store i64 %t949, ptr %l77, !tbaa !24
  %t950 = load ptr, ptr %lp69
  %t951 = getelementptr %"compiler/eval:Blob", ptr %t950, i32 0, i32 4
  %t952 = load i64, ptr %l76, !tbaa !24
  %t955 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t951, i64 %t952)
  store i64 %t955, ptr %l498
  br label %bb235
bb235:
  %t956 = load i64, ptr %l498, !tbaa !24
  %t957 = icmp sge i64 %t956, 0
  br i1 %t957, label %bb236, label %bb237
bb236:
  %t959 = load ptr, ptr %lp69
  %t960 = getelementptr %"compiler/eval:Blob", ptr %t959, i32 0, i32 4
  %t961 = load i64, ptr %l76, !tbaa !24
  %t964 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t960, i64 %t961)
  store i64 %t964, ptr %l503
  br label %bb238
bb237:
  store i1 false, ptr %l500, !tbaa !21
  br label %bb239
bb238:
  %t965 = load i64, ptr %l503, !tbaa !24
  %t966 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t967 = load ptr, ptr %t966, !tbaa !27
  %t968 = getelementptr i64, ptr %t967, i64 %t965
  %t969 = load i64, ptr %t968, !tbaa !34
  %t971 = icmp sge i64 %t969, 0
  store i1 %t971, ptr %l500, !tbaa !21
  br label %bb239
bb239:
  %t973 = load i1, ptr %l500, !tbaa !21
  br i1 %t973, label %bb240, label %bb241
bb240:
  %t974 = load ptr, ptr %lp70
  %t975 = getelementptr %"compiler/eval:Blob", ptr %t974, i32 0, i32 4
  store ptr %t975, ptr %l506, !tbaa !29
  %t976 = load ptr, ptr %lp69
  %t977 = getelementptr %"compiler/eval:Blob", ptr %t976, i32 0, i32 4
  %t978 = load i64, ptr %l76, !tbaa !24
  %t981 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t977, i64 %t978)
  store i64 %t981, ptr %l509
  br label %bb242
bb241:
  br label %bb245
bb242:
  %t982 = load i64, ptr %l509, !tbaa !24
  %t983 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t984 = load ptr, ptr %t983, !tbaa !27
  %t985 = getelementptr i64, ptr %t984, i64 %t982
  %t986 = load i64, ptr %t985, !tbaa !34
  %t987 = load ptr, ptr %l506, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t987, i64 %t986)
  br label %bb243
bb243:
  %t989 = load ptr, ptr %lp70
  %t990 = getelementptr %"compiler/eval:Blob", ptr %t989, i32 0, i32 6
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t990, i64 -1)
  br label %bb244
bb244:
  call void @__olang_scope_close(ptr %s40)
  br label %bb258
bb245:
  %t992 = load i64, ptr %l77, !tbaa !24
  %t995 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l29, i64 %t992)
  %t996 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t995, 1
  %t997 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t995, 0
  store i32 %t997, ptr %l516
  %t998 = icmp ne i32 %t997, 0
  br i1 %t998, label %bb247, label %ok.999
ok.999:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t996, ptr %l515
  br label %bb246
bb246:
  %t1000 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l515
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1000, ptr %l512
  br label %bb250
bb247:
  br label %bb248
bb248:
  %t1001 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s40, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1001, ptr %l517
  br label %bb249
bb249:
  %t1002 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l517
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1002, ptr %l512
  br label %bb250
bb250:
  %t1003 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l512
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1003, ptr %l78
  %t1004 = load ptr, ptr %l2, !tbaa !29
  %t1006 = getelementptr %"compiler/interp:Exec", ptr %t1004, i32 0, i32 1
  %t1007 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l78, i32 0, i32 0
  %t1008 = load i64, ptr %t1007, !tbaa !24
  %t1011 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t1006, i64 %t1008)
  store ptr %t1011, ptr %l521
  br label %bb251
bb251:
  %t1012 = load ptr, ptr %l521, !tbaa !29
  %t1013 = call { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %t1012)
  store { i64, i32 } %t1013, ptr %l522
  br label %bb252
bb252:
  %t1014 = load { i64, i32 }, ptr %l522
  store { i64, i32 } %t1014, ptr %l79
  %t1015 = getelementptr { i64, i32 }, ptr %l79, i32 0, i32 0
  %t1016 = load i64, ptr %t1015, !tbaa !24
  store i64 %t1016, ptr %l80, !tbaa !24
  %t1018 = getelementptr { i64, i32 }, ptr %l79, i32 0, i32 1
  %t1019 = load i32, ptr %t1018, !tbaa !23
  store i32 %t1019, ptr %l81, !tbaa !23
  %t1021 = load ptr, ptr %lp70
  %t1022 = getelementptr %"compiler/eval:Blob", ptr %t1021, i32 0, i32 4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1022, i64 -1)
  br label %bb253
bb253:
  %t1024 = load ptr, ptr %lp70
  %t1025 = getelementptr %"compiler/eval:Blob", ptr %t1024, i32 0, i32 6
  %t1026 = load i64, ptr %l77, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1025, i64 %t1026)
  br label %bb254
bb254:
  %t1029 = load ptr, ptr %lp70
  %t1030 = getelementptr %"compiler/eval:Blob", ptr %t1029, i32 0, i32 7
  %t1031 = load i64, ptr %l80, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1030, i64 %t1031)
  br label %bb255
bb255:
  %t1034 = load ptr, ptr %lp70
  %t1035 = getelementptr %"compiler/eval:Blob", ptr %t1034, i32 0, i32 8
  %t1036 = load i32, ptr %l81, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v1, ptr %t1035, i32 %t1036)
  br label %bb256
bb256:
  %t1039 = load ptr, ptr %lp70
  %t1040 = getelementptr %"compiler/eval:Blob", ptr %t1039, i32 0, i32 9
  %t1041 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l78, i32 0, i32 1
  %t1042 = load i64, ptr %t1041, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1040, i64 %t1042)
  br label %bb257
bb257:
  call void @__olang_scope_close(ptr %s40)
  br label %bb258
bb258:
  %t1045 = load i64, ptr %l75, !tbaa !24
  %t1047 = add i64 %t1045, 1
  store i64 %t1047, ptr %l75, !tbaa !24
  br label %bb220
bb259:
  %t1049 = load ptr, ptr %lp62
  %t1050 = getelementptr %"compiler/eval:Image", ptr %t1049, i32 0, i32 0
  %t1051 = load ptr, ptr %lp70
  %t1052 = load %"compiler/eval:Blob", ptr %t1051
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t1050, %"compiler/eval:Blob" %t1052)
  br label %bb260
bb260:
  %t1055 = load ptr, ptr %lp62
  %t1056 = getelementptr %"compiler/eval:Image", ptr %t1055, i32 0, i32 1
  store ptr %t1056, ptr %l538, !tbaa !29
  %t1057 = load ptr, ptr %lp36
  %t1058 = getelementptr %"compiler/eval:Image", ptr %t1057, i32 0, i32 1
  %t1059 = load i64, ptr %l68, !tbaa !24
  %t1062 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1058, i64 %t1059)
  store i64 %t1062, ptr %l541
  br label %bb261
bb261:
  %t1063 = load ptr, ptr %l538, !tbaa !29
  %t1064 = load i64, ptr %l541, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1063, i64 %t1064)
  br label %bb262
bb262:
  store ptr %l29, ptr %l542, !tbaa !29
  %t1065 = load ptr, ptr %lp36
  %t1066 = getelementptr %"compiler/eval:Image", ptr %t1065, i32 0, i32 1
  %t1067 = load i64, ptr %l68, !tbaa !24
  %t1070 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1066, i64 %t1067)
  store i64 %t1070, ptr %l545
  br label %bb263
bb263:
  %t1071 = load i64, ptr %l35, !tbaa !24
  %t1072 = load i64, ptr %l68, !tbaa !24
  %t1074 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t1075 = load ptr, ptr %t1074, !tbaa !27
  %t1076 = getelementptr i64, ptr %t1075, i64 %t1072
  %t1077 = load i64, ptr %t1076, !tbaa !34
  %t1080 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s37, i64 %t1071, i64 %t1077)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1080, ptr %l549
  br label %bb264
bb264:
  %t1081 = load ptr, ptr %l542, !tbaa !29
  %t1082 = load i64, ptr %l545, !tbaa !24
  %t1083 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l549
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_Hd47ddefe3838698aaa5711f2f63b01ed(ptr %s0, ptr %t1081, i64 %t1082, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1083)
  br label %bb265
bb265:
  call void @__olang_scope_close(ptr %s37)
  br label %bb266
bb266:
  %t1084 = load i64, ptr %l67, !tbaa !24
  %t1086 = add i64 %t1084, 1
  store i64 %t1086, ptr %l67, !tbaa !24
  br label %bb204
bb267:
  %t1088 = load ptr, ptr %lp1
  %t1089 = load i64, ptr %l35, !tbaa !24
  %t1090 = load ptr, ptr %lp62
  %t1091 = load %"compiler/eval:Image", ptr %t1090
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v1, ptr %v1, ptr %t1088, i64 %t1089, %"compiler/eval:Image" %t1091)
  br label %bb268
bb268:
  call void @__olang_scope_close(ptr %s18)
  br label %bb269
bb269:
  %t1095 = load i64, ptr %l34, !tbaa !24
  %t1097 = add i64 %t1095, 1
  store i64 %t1097, ptr %l34, !tbaa !24
  br label %bb100
bb270:
  %t1099 = load i64, ptr %l31, !tbaa !24
  %t1100 = load i64, ptr %l33, !tbaa !24
  %t1103 = add i64 %t1099, %t1100
  store i64 %t1103, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb271
bb271:
  br label %bb93
bb272:
  %t1105 = load ptr, ptr %lp1
  %t1106 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1105
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1106, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/check:AssertAsk"
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca { i64, [5 x i64] }
  %l14 = alloca { i64, [3 x i64] }
  %l15 = alloca { { i64, ptr }, i1 }
  %l16 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l29 = alloca i64
  %l41 = alloca %"compiler/interp:Exec"
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l61 = alloca { i64, ptr }
  %l67 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l70 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca { i64, [1 x i64] }
  %l83 = alloca { i64, [5 x i64] }
  %l99 = alloca i64
  %l105 = alloca { { i64, ptr }, i1 }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l111 = alloca { i64, [3 x i64] }
  %l113 = alloca %"compiler/msgs:Msg"
  %l115 = alloca %"compiler/msgs:Msg"
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %l119 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca { i64, [3 x i64] }
  %l124 = alloca %"compiler/msgs:Msg"
  %l127 = alloca %"compiler/msgs:Msg"
  %l135 = alloca ptr
  %l136 = alloca { i64, [3 x i64] }
  %l138 = alloca { i64, ptr }
  %l139 = alloca %"compiler/msgs:Msg"
  %l140 = alloca i64
  %l141 = alloca ptr
  %l142 = alloca i64
  %l148 = alloca { i64, [3 x i64] }
  %l149 = alloca %"compiler/msgs:Msg"
  %l157 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca { i64, [3 x i64] }
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i64
  %t29 = alloca %"compiler/interp:Exec", align 8
  %t105 = alloca { i64, [1 x i64] }, align 8
  %t145 = alloca { i64, [3 x i64] }, align 8
  %t293 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 65
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eL_H74c4c659bc848d1046c0a3f6eab69368(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l29
  br label %bb1
bb1:
  %t6 = load i64, ptr %l29, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 4
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 4
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27
  call void @compiler_2finterp_3aExec_2ector(ptr %t29, ptr %v0, ptr %v0, ptr %v0, ptr %t24, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l41, ptr %t29, i64 880, i1 false)
  br label %bb5
bb5:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 880, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l41, i64 880, i1 false)
  store ptr %t33, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 69
  %t39 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t38
  %t42 = getelementptr %"compiler/interp:Exec", ptr %t35, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %t42
  store i64 0, ptr %l4, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 65
  store ptr %t45, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eR_H23a25d26bcb7a81e9bb7522f4174946e(ptr %v0, ptr %t47, i64 %t48)
  %t52 = extractvalue { i32, { i64, ptr } } %t51, 1
  %t53 = extractvalue { i32, { i64, ptr } } %t51, 0
  store i32 %t53, ptr %l52
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb8, label %ok.55
ok.55:
  store { i64, ptr } %t52, ptr %l51
  br label %bb7
bb7:
  %t56 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t56, ptr %l48, !tbaa !27
  br label %bb12
bb8:
  %t57 = load i32, ptr %l52, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  br i1 %t60, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb12:
  %t62 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t62, ptr %l7, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb77
bb15:
  br label %bb16
bb16:
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t75, ptr %l61, !tbaa !27
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr %"compiler/check:AssertAsk", ptr %t79, i64 %t76
  %t81 = load %"compiler/check:AssertAsk", ptr %t80
  store %"compiler/check:AssertAsk" %t81, ptr %l10
  %t83 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 0
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 2
  %t86 = getelementptr %"compiler/source:Span", ptr %t85, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t92 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t84, i64 %t89)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t92, ptr %l67
  br label %bb17
bb17:
  %t93 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l67
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t93, ptr %l11
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t95 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  %t98 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v1, ptr %t94, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t95)
  store i1 %t98, ptr %l70
  br label %bb18
bb18:
  %t99 = load i1, ptr %l70, !tbaa !21
  br i1 %t99, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb76
bb20:
  br label %bb21
bb21:
  %t100 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 4
  %t101 = load i64, ptr %t100, !tbaa !24
  %t103 = trunc i64 %t101 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [1 x i64] }, ptr %t105, i32 0, i32 0
  store i64 0, ptr %t106
  %t108 = insertvalue { i32 } undef, i32 %t103, 0
  %t109 = getelementptr { i64, [1 x i64] }, ptr %t105, i32 0, i32 1
  store { i32 } %t108, ptr %t109
  %t110 = load { i64, [1 x i64] }, ptr %t105
  store { i64, [1 x i64] } %t110, ptr %l12
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t113 = load { i64, [1 x i64] }, ptr %l12
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t112, { i64, [1 x i64] } %t113)
  br label %bb22
bb22:
  %t116 = load ptr, ptr %l3, !tbaa !29
  %t118 = getelementptr %"compiler/interp:Exec", ptr %t116, i32 0, i32 4
  store ptr %t118, ptr %l78, !tbaa !29
  %t119 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t119, ptr %l79
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb23, label %bb24
bb23:
  %t122 = icmp sle i64 0, 1152921504606846975
  br i1 %t122, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb25:
  %t124 = mul i64 0, 8
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t128 = load ptr, ptr %l78, !tbaa !29
  %t129 = load { i64, [1 x i64] }, ptr %l79
  %t131 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t128, { i64, [1 x i64] } %t129, { i64, ptr } %t127)
  store { i64, [5 x i64] } %t131, ptr %l83
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb27:
  %t132 = load { i64, [5 x i64] }, ptr %l83
  store { i64, [5 x i64] } %t132, ptr %l13
  %t133 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 1
  %t134 = load i64, ptr %t133, !tbaa !24
  %t135 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 3
  %t136 = getelementptr %"compiler/source:Span", ptr %t135, i32 0, i32 0
  %t137 = load i32, ptr %t136, !tbaa !23
  %t139 = sext i32 %t137 to i64
  %t140 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 3
  %t141 = getelementptr %"compiler/source:Span", ptr %t140, i32 0, i32 1
  %t142 = load i32, ptr %t141, !tbaa !23
  %t144 = sext i32 %t142 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [3 x i64] }, ptr %t145, i32 0, i32 0
  store i64 3, ptr %t146
  %t148 = insertvalue { i64, i64, i64 } undef, i64 %t134, 0
  %t150 = insertvalue { i64, i64, i64 } %t148, i64 %t139, 1
  %t152 = insertvalue { i64, i64, i64 } %t150, i64 %t144, 2
  %t153 = getelementptr { i64, [3 x i64] }, ptr %t145, i32 0, i32 1
  store { i64, i64, i64 } %t152, ptr %t153
  %t154 = load { i64, [3 x i64] }, ptr %t145
  store { i64, [3 x i64] } %t154, ptr %l14
  %t156 = load { i64, [5 x i64] }, ptr %l13
  %t158 = extractvalue { i64, [5 x i64] } %t156, 0
  %t159 = icmp eq i64 %t158, 0
  br i1 %t159, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb50
bb30:
  %t161 = load i64, ptr %l4, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l4, !tbaa !24
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/interp:Exec", ptr %t165, i32 0, i32 4
  %t168 = load ptr, ptr %l3, !tbaa !29
  %t170 = getelementptr %"compiler/interp:Exec", ptr %t168, i32 0, i32 4
  %t171 = getelementptr %"compiler/eval:Machine", ptr %t170, i32 0, i32 8
  %t172 = load %"compiler/eval:Ptr", ptr %t171
  %t173 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t177 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t167, %"compiler/eval:Ptr" %t172, i32 %t173)
  store i64 %t177, ptr %l99
  br label %bb31
bb31:
  %t178 = load i64, ptr %l99, !tbaa !24
  %t179 = icmp ne i64 %t178, 0
  br i1 %t179, label %bb32, label %bb33
bb32:
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t182 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v1, ptr %t181, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t182, i1 true)
  br label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t186 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 5
  %t187 = load i64, ptr %t186, !tbaa !24
  %t190 = call { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %s8, ptr %t185, i64 %t187)
  store { { i64, ptr }, i1 } %t190, ptr %l105
  br label %bb35
bb34:
  br label %bb49
bb35:
  %t191 = load { { i64, ptr }, i1 }, ptr %l105
  store { { i64, ptr }, i1 } %t191, ptr %l15
  %t192 = getelementptr { { i64, ptr }, i1 }, ptr %l15, i32 0, i32 0
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l106, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l107, !tbaa !24
  %t196 = load i64, ptr %l107, !tbaa !24
  %t197 = mul i64 %t196, 1
  %t198 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l108, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = load i64, ptr %l107, !tbaa !24
  %t206 = mul i64 %t205, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t202, ptr %t204, i64 %t206, i1 false)
  %t207 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t207, ptr %l16, !tbaa !27
  %t208 = getelementptr { { i64, ptr }, i1 }, ptr %l15, i32 0, i32 1
  %t209 = load i1, ptr %t208, !tbaa !21
  %t211 = load ptr, ptr %l2, !tbaa !29
  store ptr %t211, ptr %l110, !tbaa !29
  %t212 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t212, ptr %l111
  br i1 %t209, label %bb36, label %bb37
bb36:
  %t215 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t217 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %s8, ptr %s8, { i64, ptr } %t215)
  store %"compiler/msgs:Msg" %t217, ptr %l115
  br label %bb38
bb37:
  %t218 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %s8)
  store %"compiler/msgs:Msg" %t218, ptr %l116
  br label %bb39
bb38:
  %t219 = load %"compiler/msgs:Msg", ptr %l115
  store %"compiler/msgs:Msg" %t219, ptr %l113
  br label %bb40
bb39:
  %t220 = load %"compiler/msgs:Msg", ptr %l116
  store %"compiler/msgs:Msg" %t220, ptr %l113
  br label %bb40
bb40:
  %t221 = load ptr, ptr %l110, !tbaa !29
  %t222 = load { i64, [3 x i64] }, ptr %l111
  %t223 = load %"compiler/msgs:Msg", ptr %l113
  %t224 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t221, { i64, [3 x i64] } %t222, %"compiler/msgs:Msg" %t223)
  store i64 %t224, ptr %l117
  br label %bb41
bb41:
  %t225 = load i64, ptr %l117, !tbaa !24
  store i64 %t225, ptr %l18, !tbaa !24
  %t226 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 8
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t229 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t227, { i64, ptr } { i64 0, ptr @.d20 })
  store i1 %t229, ptr %l119
  br label %bb42
bb42:
  %t230 = load i1, ptr %l119, !tbaa !21
  %t231 = xor i1 %t230, true
  br i1 %t231, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t233 = load ptr, ptr %l2, !tbaa !29
  store ptr %t233, ptr %l121, !tbaa !29
  %t234 = load i64, ptr %l18, !tbaa !24
  store i64 %t234, ptr %l122, !tbaa !24
  %t235 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 7
  %t236 = load { i64, [3 x i64] }, ptr %t235
  store { i64, [3 x i64] } %t236, ptr %l123
  %t237 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s9)
  store %"compiler/msgs:Msg" %t237, ptr %l124
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t238 = getelementptr %"compiler/msgs:Msg", ptr %l124, i32 0, i32 0
  %t239 = load i32, ptr %t238
  %t240 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 8
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t244 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s9, ptr %v0, ptr %s9, i32 %t239, { i64, ptr } { i64 0, ptr @.d21 }, { i64, ptr } %t241)
  store %"compiler/msgs:Msg" %t244, ptr %l127
  br label %bb46
bb46:
  %t245 = load ptr, ptr %l121, !tbaa !29
  %t246 = load i64, ptr %l122, !tbaa !24
  %t247 = load { i64, [3 x i64] }, ptr %l123
  %t248 = load %"compiler/msgs:Msg", ptr %l127
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s9, ptr %t245, i64 %t246, { i64, [3 x i64] } %t247, %"compiler/msgs:Msg" %t248)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb49:
  br label %bb75
bb50:
  %t249 = load { i64, [5 x i64] }, ptr %l13
  %t251 = extractvalue { i64, [5 x i64] } %t249, 0
  %t252 = icmp eq i64 %t251, 2
  br i1 %t252, label %bb51, label %bb52
bb51:
  %t254 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t255 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t254, i32 0, i32 0
  %t256 = load i32, ptr %t255
  store i32 %t256, ptr %l19
  %t258 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t259 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t258, i32 0, i32 1
  %t260 = load i64, ptr %t259
  store i64 %t260, ptr %l20, !tbaa !24
  %t262 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t263 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t262, i32 0, i32 2
  %t264 = load %"compiler/source:Span", ptr %t263
  store %"compiler/source:Span" %t264, ptr %l21
  br label %bb53
bb52:
  br label %bb59
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t266 = load i64, ptr %l4, !tbaa !24
  %t268 = add i64 %t266, 1
  store i64 %t268, ptr %l4, !tbaa !24
  %t270 = load ptr, ptr %l2, !tbaa !29
  store ptr %t270, ptr %l135, !tbaa !29
  %t271 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t271, ptr %l136
  %t272 = load i32, ptr %l19
  %t274 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s10, i32 %t272)
  store { i64, ptr } %t274, ptr %l138
  br label %bb54
bb54:
  %t275 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t276 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %s10, ptr %s10, { i64, ptr } %t275)
  store %"compiler/msgs:Msg" %t276, ptr %l139
  br label %bb55
bb55:
  %t277 = load ptr, ptr %l135, !tbaa !29
  %t278 = load { i64, [3 x i64] }, ptr %l136
  %t279 = load %"compiler/msgs:Msg", ptr %l139
  %t280 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t277, { i64, [3 x i64] } %t278, %"compiler/msgs:Msg" %t279)
  store i64 %t280, ptr %l140
  br label %bb56
bb56:
  %t281 = load i64, ptr %l140, !tbaa !24
  %t282 = load ptr, ptr %l2, !tbaa !29
  store ptr %t282, ptr %l141, !tbaa !29
  store i64 %t281, ptr %l142, !tbaa !24
  %t284 = load i64, ptr %l20, !tbaa !24
  %t285 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 0
  %t286 = load i32, ptr %t285, !tbaa !23
  %t288 = sext i32 %t286 to i64
  %t289 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 1
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = sext i32 %t290 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t293
  %t294 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 0
  store i64 3, ptr %t294
  %t296 = insertvalue { i64, i64, i64 } undef, i64 %t284, 0
  %t298 = insertvalue { i64, i64, i64 } %t296, i64 %t288, 1
  %t300 = insertvalue { i64, i64, i64 } %t298, i64 %t292, 2
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 1
  store { i64, i64, i64 } %t300, ptr %t301
  %t302 = load { i64, [3 x i64] }, ptr %t293
  store { i64, [3 x i64] } %t302, ptr %l148
  %t303 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s10)
  store %"compiler/msgs:Msg" %t303, ptr %l149
  br label %bb57
bb57:
  %t304 = load ptr, ptr %l141, !tbaa !29
  %t305 = load i64, ptr %l142, !tbaa !24
  %t306 = load { i64, [3 x i64] }, ptr %l148
  %t307 = load %"compiler/msgs:Msg", ptr %l149
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s10, ptr %t304, i64 %t305, { i64, [3 x i64] } %t306, %"compiler/msgs:Msg" %t307)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb75
bb59:
  %t308 = load { i64, [5 x i64] }, ptr %l13
  %t310 = extractvalue { i64, [5 x i64] } %t308, 0
  %t311 = icmp eq i64 %t310, 3
  br i1 %t311, label %bb60, label %bb61
bb60:
  %t313 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t314 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t313, i32 0, i32 0
  %t315 = load { i64, ptr }, ptr %t314
  store { i64, ptr } %t315, ptr %l23, !tbaa !27
  %t317 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t318 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t317, i32 0, i32 1
  %t319 = load i64, ptr %t318
  store i64 %t319, ptr %l24, !tbaa !24
  %t321 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t322 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t321, i32 0, i32 2
  %t323 = load %"compiler/source:Span", ptr %t322
  store %"compiler/source:Span" %t323, ptr %l25
  br label %bb62
bb61:
  br label %bb70
bb62:
  %t325 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t326 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t327 = load ptr, ptr @__olang_prog_scope
  %t330 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t327, { i64, ptr } %t325, { i64, ptr } %t326)
  store i1 %t330, ptr %l157
  br label %bb63
bb63:
  %t331 = load i1, ptr %l157, !tbaa !21
  br i1 %t331, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t332 = load i64, ptr %l4, !tbaa !24
  %t334 = add i64 %t332, 1
  store i64 %t334, ptr %l4, !tbaa !24
  %t336 = load ptr, ptr %l2, !tbaa !29
  store ptr %t336, ptr %l160, !tbaa !29
  %t337 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t337, ptr %l161
  %t338 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t340 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %v0, ptr %s12, { i64, ptr } %t338)
  store %"compiler/msgs:Msg" %t340, ptr %l163
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t341 = load ptr, ptr %l160, !tbaa !29
  %t342 = load { i64, [3 x i64] }, ptr %l161
  %t343 = load %"compiler/msgs:Msg", ptr %l163
  %t344 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t341, { i64, [3 x i64] } %t342, %"compiler/msgs:Msg" %t343)
  store i64 %t344, ptr %l164
  br label %bb67
bb67:
  %t345 = load i64, ptr %l164, !tbaa !24
  %t346 = load ptr, ptr %l3, !tbaa !29
  %t347 = load ptr, ptr %l2, !tbaa !29
  %t349 = load i64, ptr %l24, !tbaa !24
  %t350 = load %"compiler/source:Span", ptr %l25
  call void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v0, ptr %t346, ptr %t347, i64 %t345, i64 %t349, %"compiler/source:Span" %t350)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s12)
  br label %bb69
bb69:
  br label %bb75
bb70:
  br i1 true, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb75:
  call void @__olang_scope_close(ptr %s4)
  br label %bb76
bb76:
  %t356 = load i64, ptr %l9, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l9, !tbaa !24
  br label %bb13
bb77:
  %t360 = load i64, ptr %l6, !tbaa !24
  %t361 = load i64, ptr %l8, !tbaa !24
  %t364 = add i64 %t360, %t361
  store i64 %t364, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb78:
  br label %bb6
bb79:
  %t366 = load i64, ptr %l4, !tbaa !24
  store i64 %t366, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/check:ValueAsk"
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca { i64, [1 x i64] }
  %l14 = alloca { i64, [3 x i64] }
  %l15 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca i1
  %l21 = alloca { i64, [3 x i64] }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l24 = alloca i64
  %l27 = alloca i64
  %l39 = alloca %"compiler/interp:Exec"
  %l44 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l60 = alloca { i64, ptr }
  %l66 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l69 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca { i64, [1 x i64] }
  %l82 = alloca { i64, [5 x i64] }
  %l91 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l98 = alloca i1
  %l101 = alloca i32
  %l103 = alloca i32
  %l105 = alloca i1
  %l106 = alloca i1
  %l109 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca { i64, [3 x i64] }
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %l122 = alloca i32
  %l124 = alloca i32
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca { i64, [3 x i64] }
  %l131 = alloca { i64, ptr }
  %l134 = alloca %"compiler/msgs:Msg"
  %l135 = alloca i64
  %l142 = alloca { i64, [3 x i64] }
  %l144 = alloca { i64, [3 x i64] }
  %l146 = alloca i1
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca { i64, [3 x i64] }
  %l158 = alloca { i64, ptr }
  %l160 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l162 = alloca { i64, ptr }
  %l164 = alloca i64
  %l166 = alloca i64
  %l167 = alloca { i64, ptr }
  %l168 = alloca ptr
  %l169 = alloca { i64, [3 x i64] }
  %l172 = alloca { i64, ptr }
  %l175 = alloca %"compiler/msgs:Msg"
  %l176 = alloca i64
  %l178 = alloca ptr
  %l179 = alloca i64
  %l180 = alloca { i64, [3 x i64] }
  %l181 = alloca %"compiler/msgs:Msg"
  %l189 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i64
  %l193 = alloca { i64, [3 x i64] }
  %l195 = alloca %"compiler/msgs:Msg"
  %l197 = alloca ptr
  %l198 = alloca i64
  %l199 = alloca { i64, [3 x i64] }
  %l202 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l208 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i64
  %t29 = alloca %"compiler/interp:Exec", align 8
  %t107 = alloca { i64, [1 x i64] }, align 8
  %t147 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 66
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2eLe_H6dd36e51154e44ba851d649a77b16b98(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load i64, ptr %l27, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 4
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 4
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27
  call void @compiler_2finterp_3aExec_2ector(ptr %t29, ptr %v0, ptr %v0, ptr %v0, ptr %t24, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t29, i64 880, i1 false)
  br label %bb5
bb5:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 880, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l39, i64 880, i1 false)
  store ptr %t33, ptr %l2, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 69
  %t39 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t38
  %t42 = getelementptr %"compiler/interp:Exec", ptr %t35, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %t42
  %t43 = load ptr, ptr @__olang_prog_scope
  %t44 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t43)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l44
  br label %bb6
bb6:
  %t45 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 66
  store ptr %t48, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2eRu_H15098c5dcd0d2a6000e8beb539003606(ptr %v0, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, { i64, ptr } } %t54, 1
  %t56 = extractvalue { i32, { i64, ptr } } %t54, 0
  store i32 %t56, ptr %l51
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb9, label %ok.58
ok.58:
  store { i64, ptr } %t55, ptr %l50
  br label %bb8
bb8:
  %t59 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t59, ptr %l47, !tbaa !27
  br label %bb13
bb9:
  %t60 = load i32, ptr %l51, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  br i1 %t63, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb89
bb13:
  %t65 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t65, ptr %l7, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb87
bb16:
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t78, ptr %l60, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"compiler/check:ValueAsk", ptr %t82, i64 %t79
  %t84 = load %"compiler/check:ValueAsk", ptr %t83
  store %"compiler/check:ValueAsk" %t84, ptr %l10
  %t86 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 2
  %t89 = getelementptr %"compiler/source:Span", ptr %t88, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t92 = sext i32 %t90 to i64
  %t95 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t87, i64 %t92)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t95, ptr %l66
  br label %bb18
bb18:
  %t96 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l66
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t96, ptr %l11
  %t97 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  %t100 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t97)
  store i1 %t100, ptr %l69
  br label %bb19
bb19:
  %t101 = load i1, ptr %l69, !tbaa !21
  br i1 %t101, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb86
bb21:
  br label %bb22
bb22:
  %t102 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 4
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = trunc i64 %t103 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [1 x i64] }, ptr %t107, i32 0, i32 0
  store i64 0, ptr %t108
  %t110 = insertvalue { i32 } undef, i32 %t105, 0
  %t111 = getelementptr { i64, [1 x i64] }, ptr %t107, i32 0, i32 1
  store { i32 } %t110, ptr %t111
  %t112 = load { i64, [1 x i64] }, ptr %t107
  store { i64, [1 x i64] } %t112, ptr %l12
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t115 = load { i64, [1 x i64] }, ptr %l12
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t114, { i64, [1 x i64] } %t115)
  br label %bb23
bb23:
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t120 = getelementptr %"compiler/interp:Exec", ptr %t118, i32 0, i32 4
  store ptr %t120, ptr %l77, !tbaa !29
  %t121 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t121, ptr %l78
  %t122 = icmp sge i64 0, 0
  br i1 %t122, label %bb24, label %bb25
bb24:
  %t124 = icmp sle i64 0, 1152921504606846975
  br i1 %t124, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb26:
  %t126 = mul i64 0, 8
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 0, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load ptr, ptr %l77, !tbaa !29
  %t131 = load { i64, [1 x i64] }, ptr %l78
  %t133 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t130, { i64, [1 x i64] } %t131, { i64, ptr } %t129)
  store { i64, [5 x i64] } %t133, ptr %l82
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb28:
  %t134 = load { i64, [5 x i64] }, ptr %l82
  %t135 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 1
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 2
  %t138 = getelementptr %"compiler/source:Span", ptr %t137, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  %t141 = sext i32 %t139 to i64
  %t142 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 2
  %t143 = getelementptr %"compiler/source:Span", ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143, !tbaa !23
  %t146 = sext i32 %t144 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 0
  store i64 3, ptr %t148
  %t150 = insertvalue { i64, i64, i64 } undef, i64 %t136, 0
  %t152 = insertvalue { i64, i64, i64 } %t150, i64 %t141, 1
  %t154 = insertvalue { i64, i64, i64 } %t152, i64 %t146, 2
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  store { i64, i64, i64 } %t154, ptr %t155
  %t156 = load { i64, [3 x i64] }, ptr %t147
  store { i64, [3 x i64] } %t156, ptr %l14
  %t159 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 2
  %t160 = load %"compiler/source:Span", ptr %t159
  %t163 = call { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %s4, { i64, [5 x i64] } %t134, %"compiler/source:Span" %t160)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t163, ptr %l91
  br label %bb29
bb29:
  %t164 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l91
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t164, ptr %l15
  %t165 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l15, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l92, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l93, !tbaa !24
  %t169 = load i64, ptr %l93, !tbaa !24
  %t170 = mul i64 %t169, 1
  %t171 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l94, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l93, !tbaa !24
  %t179 = mul i64 %t178, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t175, ptr %t177, i64 %t179, i1 false)
  %t180 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t180, ptr %l16, !tbaa !27
  %t181 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l15, i32 0, i32 1
  %t182 = load i64, ptr %t181, !tbaa !24
  store i64 %t182, ptr %l17, !tbaa !24
  %t184 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l15, i32 0, i32 2
  %t185 = load %"compiler/source:Span", ptr %t184
  store %"compiler/source:Span" %t185, ptr %l18
  %t187 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t187, { i64, ptr } { i64 0, ptr @.d25 })
  store i1 %t189, ptr %l98
  br label %bb30
bb30:
  %t190 = load i1, ptr %l98, !tbaa !21
  br i1 %t190, label %bb31, label %bb32
bb31:
  %t191 = load i64, ptr %l4, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l4, !tbaa !24
  %t195 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 0
  %t196 = load i32, ptr %t195
  store i32 %t196, ptr %l101
  store i32 2, ptr %l103
  %t199 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcheck_3aValueKind(ptr %l101, ptr %l103)
  store i1 %t199, ptr %l105
  br label %bb33
bb32:
  br label %bb45
bb33:
  %t200 = load i1, ptr %l105, !tbaa !21
  br i1 %t200, label %bb34, label %bb35
bb34:
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t203 = getelementptr %"compiler/interp:Exec", ptr %t201, i32 0, i32 4
  %t205 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eResultHoldsAddress(ptr %v0, ptr %t203)
  store i1 %t205, ptr %l109
  br label %bb36
bb35:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb37
bb36:
  %t206 = load i1, ptr %l109, !tbaa !21
  store i1 %t206, ptr %l106, !tbaa !21
  br label %bb37
bb37:
  %t207 = load i1, ptr %l106, !tbaa !21
  br i1 %t207, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t208 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t208, i1 true)
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t211 = load ptr, ptr %l1, !tbaa !29
  store ptr %t211, ptr %l112, !tbaa !29
  %t212 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t212, ptr %l113
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 3
  %t215 = load i32, ptr %t214, !tbaa !23
  %t218 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t213, i32 %t215)
  store { i64, ptr } %t218, ptr %l116
  br label %bb41
bb41:
  %t219 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t227 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eZeroValueShared(ptr %s7, ptr %s7, { i64, ptr } %t225)
  store %"compiler/msgs:Msg" %t227, ptr %l118
  br label %bb42
bb42:
  %t228 = load ptr, ptr %l112, !tbaa !29
  %t229 = load { i64, [3 x i64] }, ptr %l113
  %t230 = load %"compiler/msgs:Msg", ptr %l118
  %t231 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t228, { i64, [3 x i64] } %t229, %"compiler/msgs:Msg" %t230)
  store i64 %t231, ptr %l119
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb86
bb45:
  %t232 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t232, i1 true)
  br label %bb46
bb46:
  %t235 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 0
  %t236 = load i32, ptr %t235
  store i32 %t236, ptr %l122
  store i32 0, ptr %l124
  %t239 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcheck_3aValueKind(ptr %l122, ptr %l124)
  store i1 %t239, ptr %l126
  br label %bb47
bb47:
  %t240 = load i1, ptr %l126, !tbaa !21
  br i1 %t240, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l127, !tbaa !29
  %t242 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t242, ptr %l128
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 3
  %t245 = load i32, ptr %t244, !tbaa !23
  %t248 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s8, ptr %t243, i32 %t245)
  store { i64, ptr } %t248, ptr %l131
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t249 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 0
  %t251 = extractvalue { i64, ptr } %t249, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  %t256 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t259 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralCtorFails(ptr %s8, ptr %s4, ptr %s8, { i64, ptr } %t255, { i64, ptr } %t256)
  store %"compiler/msgs:Msg" %t259, ptr %l134
  br label %bb51
bb51:
  %t260 = load ptr, ptr %l127, !tbaa !29
  %t261 = load { i64, [3 x i64] }, ptr %l128
  %t262 = load %"compiler/msgs:Msg", ptr %l134
  %t263 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t260, { i64, [3 x i64] } %t261, %"compiler/msgs:Msg" %t262)
  store i64 %t263, ptr %l135
  br label %bb52
bb52:
  %t264 = load i64, ptr %l135, !tbaa !24
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 1
  %t268 = load i64, ptr %t267, !tbaa !24
  %t269 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 2
  %t270 = load %"compiler/source:Span", ptr %t269
  %t271 = load i64, ptr %l17, !tbaa !24
  %t272 = load %"compiler/source:Span", ptr %l18
  call void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %t265, i64 %t264, i64 %t268, %"compiler/source:Span" %t270, i64 %t271, %"compiler/source:Span" %t272)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  br label %bb86
bb54:
  %t279 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 5
  %t280 = load { i64, [3 x i64] }, ptr %t279
  store { i64, [3 x i64] } %t280, ptr %l142
  %t281 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t281, ptr %l144
  %t284 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %l142, ptr %l144)
  store i1 %t284, ptr %l146
  br label %bb55
bb55:
  %t285 = load i1, ptr %l146, !tbaa !21
  %t286 = xor i1 %t285, true
  store i1 %t286, ptr %l20, !tbaa !21
  %t288 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 5
  %t289 = load { i64, [3 x i64] }, ptr %t288
  store { i64, [3 x i64] } %t289, ptr %l21
  store { i64, ptr } { i64 0, ptr @.d26 }, ptr %l149, !tbaa !27
  %t291 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t291, ptr %l150, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  store i64 %t293, ptr %l151, !tbaa !24
  %t294 = load i64, ptr %l151, !tbaa !24
  %t295 = mul i64 %t294, 1
  %t296 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t295)
  %t297 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  store { i64, ptr } %t298, ptr %l152, !tbaa !27
  %t299 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = load i64, ptr %l151, !tbaa !24
  %t304 = mul i64 %t303, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t300, ptr %t302, i64 %t304, i1 false)
  %t305 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t305, ptr %l22, !tbaa !27
  %t306 = load i1, ptr %l20, !tbaa !21
  br i1 %t306, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %l154, !tbaa !29
  %t309 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 5
  %t310 = load { i64, [3 x i64] }, ptr %t309
  store { i64, [3 x i64] } %t310, ptr %l155
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 3
  %t313 = load i32, ptr %t312, !tbaa !23
  %t316 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s9, ptr %t311, i32 %t313)
  store { i64, ptr } %t316, ptr %l158
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t317 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  %t319 = extractvalue { i64, ptr } %t317, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  %t324 = load ptr, ptr %l154, !tbaa !29
  %t325 = load { i64, [3 x i64] }, ptr %l155
  %t327 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2finterp_2ezeroUseArg(ptr %v0, ptr %s9, ptr %s9, ptr %t324, { i64, [3 x i64] } %t325, { i64, ptr } %t323)
  store { { i64, [3 x i64] }, { i64, ptr } } %t327, ptr %l160
  br label %bb59
bb59:
  %t328 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l160
  store { { i64, [3 x i64] }, { i64, ptr } } %t328, ptr %l23
  %t329 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l23, i32 0, i32 0
  %t330 = load { i64, [3 x i64] }, ptr %t329
  store { i64, [3 x i64] } %t330, ptr %l21
  %t332 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l23, i32 0, i32 1
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  store { i64, ptr } %t333, ptr %l162, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  store i64 %t337, ptr %l164, !tbaa !24
  %t339 = load i64, ptr %l164, !tbaa !24
  %t340 = icmp eq i64 %t335, %t339
  br i1 %t340, label %bb60, label %bb61
bb60:
  %t342 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = load i64, ptr %l164, !tbaa !24
  %t347 = mul i64 %t346, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t343, ptr %t345, i64 %t347, i1 false)
  br label %bb62
bb61:
  %t348 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  store i64 %t349, ptr %l166, !tbaa !24
  %t350 = load i64, ptr %l166, !tbaa !24
  %t351 = mul i64 %t350, 1
  %t352 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t351)
  %t353 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  store { i64, ptr } %t354, ptr %l167, !tbaa !27
  %t355 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !27
  %t357 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = load i64, ptr %l166, !tbaa !24
  %t360 = mul i64 %t359, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t356, ptr %t358, i64 %t360, i1 false)
  %t361 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t361, ptr %l22, !tbaa !27
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb63:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l168, !tbaa !29
  %t363 = load { i64, [3 x i64] }, ptr %l21
  store { i64, [3 x i64] } %t363, ptr %l169
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 3
  %t366 = load i32, ptr %t365, !tbaa !23
  %t369 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s4, ptr %t364, i32 %t366)
  store { i64, ptr } %t369, ptr %l172
  br label %bb64
bb64:
  %t370 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 0
  %t372 = extractvalue { i64, ptr } %t370, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t377 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t380 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t376, { i64, ptr } %t377)
  store %"compiler/msgs:Msg" %t380, ptr %l175
  br label %bb65
bb65:
  %t381 = load ptr, ptr %l168, !tbaa !29
  %t382 = load { i64, [3 x i64] }, ptr %l169
  %t383 = load %"compiler/msgs:Msg", ptr %l175
  %t384 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t381, { i64, [3 x i64] } %t382, %"compiler/msgs:Msg" %t383)
  store i64 %t384, ptr %l176
  br label %bb66
bb66:
  %t385 = load i64, ptr %l176, !tbaa !24
  store i64 %t385, ptr %l24, !tbaa !24
  %t386 = load i1, ptr %l20, !tbaa !21
  br i1 %t386, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t388 = load ptr, ptr %l1, !tbaa !29
  store ptr %t388, ptr %l178, !tbaa !29
  %t389 = load i64, ptr %l24, !tbaa !24
  store i64 %t389, ptr %l179, !tbaa !24
  %t390 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t390, ptr %l180
  %t391 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %s10)
  store %"compiler/msgs:Msg" %t391, ptr %l181
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t392 = load ptr, ptr %l178, !tbaa !29
  %t393 = load i64, ptr %l179, !tbaa !24
  %t394 = load { i64, [3 x i64] }, ptr %l180
  %t395 = load %"compiler/msgs:Msg", ptr %l181
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s10, ptr %t392, i64 %t393, { i64, [3 x i64] } %t394, %"compiler/msgs:Msg" %t395)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb71
bb71:
  %t396 = load ptr, ptr %l1, !tbaa !29
  %t397 = load i64, ptr %l24, !tbaa !24
  %t398 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 1
  %t399 = load i64, ptr %t398, !tbaa !24
  %t400 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 2
  %t401 = load %"compiler/source:Span", ptr %t400
  %t402 = load i64, ptr %l17, !tbaa !24
  %t403 = load %"compiler/source:Span", ptr %l18
  call void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %t396, i64 %t397, i64 %t399, %"compiler/source:Span" %t401, i64 %t402, %"compiler/source:Span" %t403)
  br label %bb72
bb72:
  %t410 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t412 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t410, { i64, ptr } { i64 0, ptr @.d27 })
  store i1 %t412, ptr %l189
  br label %bb73
bb73:
  %t413 = load i1, ptr %l189, !tbaa !21
  %t414 = xor i1 %t413, true
  br i1 %t414, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s11
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l191, !tbaa !29
  %t417 = load i64, ptr %l24, !tbaa !24
  store i64 %t417, ptr %l192, !tbaa !24
  %t418 = load { i64, [3 x i64] }, ptr %l21
  store { i64, [3 x i64] } %t418, ptr %l193
  %t419 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t421 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroByReference(ptr %s4, ptr %s11, { i64, ptr } %t419)
  store %"compiler/msgs:Msg" %t421, ptr %l195
  br label %bb76
bb75:
  %t422 = load i1, ptr %l20, !tbaa !21
  br i1 %t422, label %bb78, label %bb79
bb76:
  %t424 = load ptr, ptr %l191, !tbaa !29
  %t425 = load i64, ptr %l192, !tbaa !24
  %t426 = load { i64, [3 x i64] }, ptr %l193
  %t427 = load %"compiler/msgs:Msg", ptr %l195
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s11, ptr %t424, i64 %t425, { i64, [3 x i64] } %t426, %"compiler/msgs:Msg" %t427)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb78:
  store %olang.scope zeroinitializer, ptr %s13
  %t428 = load ptr, ptr %l1, !tbaa !29
  store ptr %t428, ptr %l197, !tbaa !29
  %t429 = load i64, ptr %l24, !tbaa !24
  store i64 %t429, ptr %l198, !tbaa !24
  %t430 = load { i64, [3 x i64] }, ptr %l21
  store { i64, [3 x i64] } %t430, ptr %l199
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 3
  %t433 = load i32, ptr %t432, !tbaa !23
  %t436 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s13, ptr %t431, i32 %t433)
  store { i64, ptr } %t436, ptr %l202
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t437 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t437, 0
  %t439 = extractvalue { i64, ptr } %t437, 1
  %t440 = mul i64 %t438, 1
  %t441 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t441, ptr %t439, i64 %t440, i1 false)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  store { i64, ptr } %t443, ptr %l203, !tbaa !27
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:ValueAsk", ptr %l10, i32 0, i32 3
  %t446 = load i32, ptr %t445, !tbaa !23
  %t449 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s13, ptr %t444, i32 %t446)
  store { i64, ptr } %t449, ptr %l206
  br label %bb81
bb81:
  %t450 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 0
  %t452 = extractvalue { i64, ptr } %t450, 1
  %t453 = mul i64 %t451, 1
  %t454 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t453)
  call void @llvm.memcpy.p0.p0.i64(ptr %t454, ptr %t452, i64 %t453, i1 false)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t454, 1
  %t457 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t459 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroReferenceHasOne(ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t457, { i64, ptr } %t456)
  store %"compiler/msgs:Msg" %t459, ptr %l208
  br label %bb82
bb82:
  %t460 = load ptr, ptr %l197, !tbaa !29
  %t461 = load i64, ptr %l198, !tbaa !24
  %t462 = load { i64, [3 x i64] }, ptr %l199
  %t463 = load %"compiler/msgs:Msg", ptr %l208
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s13, ptr %t460, i64 %t461, { i64, [3 x i64] } %t462, %"compiler/msgs:Msg" %t463)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s13)
  br label %bb84
bb84:
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s4)
  br label %bb86
bb86:
  %t464 = load i64, ptr %l9, !tbaa !24
  %t466 = add i64 %t464, 1
  store i64 %t466, ptr %l9, !tbaa !24
  br label %bb14
bb87:
  %t468 = load i64, ptr %l6, !tbaa !24
  %t469 = load i64, ptr %l8, !tbaa !24
  %t472 = add i64 %t468, %t469
  store i64 %t472, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb88
bb88:
  br label %bb7
bb89:
  %t474 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t474, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2eStopText(ptr %v0, ptr %v1, ptr %v2, { i64, [5 x i64] } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, [5 x i64] }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i1
  %l38 = alloca { i64, ptr }
  %l42 = alloca i1
  %l46 = alloca i1
  %l50 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, [5 x i64] } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr @.d28 }, ptr %l13, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l14, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb4:
  %t22 = load { i64, [5 x i64] }, ptr %l0
  %t24 = extractvalue { i64, [5 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 1
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = extractvalue { i64, ptr } { i64 23, ptr @.d29 }, 1
  %t33 = extractvalue { i64, ptr } { i64 23, ptr @.d29 }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t31)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb8:
  %t43 = load { i64, [5 x i64] }, ptr %l0
  %t45 = extractvalue { i64, [5 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 2
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t49 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t48, i32 0, i32 0
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l3
  %t52 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t53 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t52, i32 0, i32 1
  %t54 = load i64, ptr %t53
  store i64 %t54, ptr %l4, !tbaa !24
  %t56 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t57 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t56, i32 0, i32 2
  %t58 = load %"compiler/source:Span", ptr %t57
  store %"compiler/source:Span" %t58, ptr %l5
  %t60 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t61 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t60, i32 0, i32 3
  %t62 = load { i64, ptr }, ptr %t61
  store { i64, ptr } %t62, ptr %l6, !tbaa !27
  br label %bb11
bb10:
  br label %bb28
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i32, ptr %l3
  %t66 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s4, i32 %t64)
  store { i64, ptr } %t66, ptr %l29
  br label %bb12
bb12:
  %t67 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t67, ptr %l7, !tbaa !27
  %t68 = load i32, ptr %l3
  store i32 %t68, ptr %l30
  store i32 9, ptr %l32
  %t71 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l30, ptr %l32)
  store i1 %t71, ptr %l34
  br label %bb13
bb13:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  %t75 = load %"compiler/source:Span", ptr %l5
  %t79 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s5, ptr %t73, i64 %t74, %"compiler/source:Span" %t75)
  store { i64, ptr } %t79, ptr %l38
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } { i64 2, ptr @.d30 }, 1
  %t85 = extractvalue { i64, ptr } { i64 2, ptr @.d30 }, 0
  %t86 = add i64 %t83, %t85
  %t88 = extractvalue { i64, ptr } %t80, 1
  %t89 = extractvalue { i64, ptr } %t80, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t84, i64 %t85)
  %t93 = getelementptr i8, ptr %t92, i64 %t85
  call void @olang_textcopy(ptr %t93, ptr %t88, i64 %t89)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t91, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
bb17:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t97, { i64, ptr } { i64 0, ptr @.d31 })
  store i1 %t99, ptr %l42
  br label %bb18
bb18:
  %t100 = load i1, ptr %l42, !tbaa !21
  br i1 %t100, label %bb19, label %bb20
bb19:
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = extractvalue { i64, ptr } %t101, 0
  %t105 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t103, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t109, { i64, ptr } { i64 0, ptr @.d32 })
  store i1 %t111, ptr %l46
  br label %bb22
bb22:
  %t112 = load i1, ptr %l46, !tbaa !21
  br i1 %t112, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s9
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load %"compiler/source:Span", ptr %l5
  %t119 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s9, ptr %t113, i64 %t114, %"compiler/source:Span" %t115)
  store { i64, ptr } %t119, ptr %l50
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = extractvalue { i64, ptr } { i64 2, ptr @.d33 }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr @.d33 }, 0
  %t126 = add i64 %t123, %t125
  %t128 = extractvalue { i64, ptr } %t120, 1
  %t129 = extractvalue { i64, ptr } %t120, 0
  %t130 = add i64 %t126, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = getelementptr i8, ptr %t131, i64 %t123
  call void @olang_textcopy(ptr %t132, ptr %t124, i64 %t125)
  %t133 = getelementptr i8, ptr %t132, i64 %t125
  call void @olang_textcopy(ptr %t133, ptr %t128, i64 %t129)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t131, 1
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t135, ptr %rv
  br label %ret
bb26:
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t138 = load i64, ptr %l4, !tbaa !24
  %t139 = load %"compiler/source:Span", ptr %l5
  %t143 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t137, i64 %t138, %"compiler/source:Span" %t139)
  store { i64, ptr } %t143, ptr %l56
  br label %bb27
bb27:
  %t144 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = extractvalue { i64, ptr } { i64 2, ptr @.d34 }, 1
  %t150 = extractvalue { i64, ptr } { i64 2, ptr @.d34 }, 0
  %t151 = add i64 %t148, %t150
  %t153 = extractvalue { i64, ptr } %t144, 1
  %t154 = extractvalue { i64, ptr } %t144, 0
  %t155 = add i64 %t151, %t154
  %t156 = extractvalue { i64, ptr } { i64 2, ptr @.d35 }, 1
  %t157 = extractvalue { i64, ptr } { i64 2, ptr @.d35 }, 0
  %t158 = add i64 %t155, %t157
  %t160 = extractvalue { i64, ptr } %t145, 1
  %t161 = extractvalue { i64, ptr } %t145, 0
  %t162 = add i64 %t158, %t161
  %t163 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t147, i64 %t148)
  %t164 = getelementptr i8, ptr %t163, i64 %t148
  call void @olang_textcopy(ptr %t164, ptr %t149, i64 %t150)
  %t165 = getelementptr i8, ptr %t164, i64 %t150
  call void @olang_textcopy(ptr %t165, ptr %t153, i64 %t154)
  %t166 = getelementptr i8, ptr %t165, i64 %t154
  call void @olang_textcopy(ptr %t166, ptr %t156, i64 %t157)
  %t167 = getelementptr i8, ptr %t166, i64 %t157
  call void @olang_textcopy(ptr %t167, ptr %t160, i64 %t161)
  %t168 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t163, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t169, ptr %rv
  br label %ret
bb28:
  %t171 = load { i64, [5 x i64] }, ptr %l0
  %t173 = extractvalue { i64, [5 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 3
  br i1 %t174, label %bb29, label %bb30
bb29:
  %t176 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t177 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t176, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177
  store { i64, ptr } %t178, ptr %l8, !tbaa !27
  %t180 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t180, i32 0, i32 1
  %t182 = load i64, ptr %t181
  store i64 %t182, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t185 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t184, i32 0, i32 2
  %t186 = load %"compiler/source:Span", ptr %t185
  store %"compiler/source:Span" %t186, ptr %l10
  br label %bb31
bb30:
  br label %bb33
bb31:
  store %olang.scope zeroinitializer, ptr %s12
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t189 = load i64, ptr %l9, !tbaa !24
  %t190 = load %"compiler/source:Span", ptr %l10
  %t194 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s12, ptr %t188, i64 %t189, %"compiler/source:Span" %t190)
  store { i64, ptr } %t194, ptr %l68
  br label %bb32
bb32:
  %t195 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = extractvalue { i64, ptr } { i64 2, ptr @.d36 }, 1
  %t200 = extractvalue { i64, ptr } { i64 2, ptr @.d36 }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %t195, 1
  %t204 = extractvalue { i64, ptr } %t195, 0
  %t205 = add i64 %t201, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t197, i64 %t198)
  %t207 = getelementptr i8, ptr %t206, i64 %t198
  call void @olang_textcopy(ptr %t207, ptr %t199, i64 %t200)
  %t208 = getelementptr i8, ptr %t207, i64 %t200
  call void @olang_textcopy(ptr %t208, ptr %t203, i64 %t204)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t206, 1
  call void @__olang_scope_close(ptr %s12)
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @.c37)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2easkNote(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca %"compiler/generic:Origin"
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i1
  %l20 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca %"compiler/generic:Origin"
  %l46 = alloca %"std/prelude/text:StringBuilder"
  %l54 = alloca i64
  %l57 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l104 = alloca i64
  %l110 = alloca { i64, [3 x i64] }
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca i32
  %l114 = alloca { i64, ptr }
  %l115 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t213 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/generic:ConstAsk", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/generic:ConstAsk", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = srem i64 %t11, 2
  %t15 = icmp ne i64 %t13, 0
  store i1 %t15, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l15, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/generic:ConstAsk", ptr %t18, i32 0, i32 5
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp eq i64 %t23, 0
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l20, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/generic:ConstAsk", ptr %t28, i32 0, i32 3
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = sdiv i64 %t31, 2
  %t35 = trunc i64 %t33 to i32
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l31, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  store ptr %t47, ptr %l34, !tbaa !29
  store i32 %t35, ptr %l35, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/generic:ConstAsk", ptr %t55, i32 0, i32 5
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t54, { i64, ptr } %t58)
  store i32 %t61, ptr %l41
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l34, !tbaa !29
  %t63 = load i32, ptr %l35, !tbaa !23
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i32 %t65, ptr %l42
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load i32, ptr %l42, !tbaa !23
  %t68 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t66, i32 %t67)
  store %"compiler/generic:Origin" %t68, ptr %l43
  br label %bb12
bb12:
  %t69 = load %"compiler/generic:Origin", ptr %l43
  store %"compiler/generic:Origin" %t69, ptr %l4
  %t70 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 0
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp slt i64 %t71, 0
  br i1 %t73, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t75 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t75, ptr %l46
  br label %bb16
bb16:
  %t76 = load %"std/prelude/text:StringBuilder", ptr %l46
  store %"std/prelude/text:StringBuilder" %t76, ptr %l5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 17, ptr @.d38 })
  br label %bb17
bb17:
  store i64 0, ptr %l6, !tbaa !24
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/generic:ConstAsk", ptr %t78, i32 0, i32 5
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp sgt i64 %t85, %t86
  br i1 %t89, label %bb18, label %bb19
bb18:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  br i1 %t93, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb20:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = sub i64 %t95, %t96
  %t100 = load i64, ptr %l8, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t105 = sub i64 %t103, 1
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = sdiv i64 %t105, %t106
  store i64 %t109, ptr %l57, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb22
bb22:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t112 = load i64, ptr %l54, !tbaa !24
  store i64 %t112, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb26:
  br label %bb27
bb27:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = mul i64 %t122, %t123
  %t129 = add i64 %t121, %t126
  store i64 %t129, ptr %l11, !tbaa !24
  store ptr %l5, ptr %l75, !tbaa !29
  %t131 = load i64, ptr %l11, !tbaa !24
  %t133 = icmp eq i64 %t131, 0
  br i1 %t133, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 7, ptr @.d39 }, ptr %l78, !tbaa !27
  br label %bb30
bb29:
  store { i64, ptr } { i64 2, ptr @.d40 }, ptr %l78, !tbaa !27
  br label %bb30
bb30:
  %t135 = load ptr, ptr %l75, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l78, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t135, { i64, ptr } %t136)
  br label %bb31
bb31:
  store ptr %l5, ptr %l79, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/load:Loader", ptr %t143, i32 0, i32 3
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/generic:ConstAsk", ptr %t147, i32 0, i32 4
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l85, !tbaa !27
  %t151 = load i64, ptr %l11, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 %t151
  %t156 = load i32, ptr %t155, !tbaa !33
  %t159 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t146, i32 %t156)
  store { i64, ptr } %t159, ptr %l88
  br label %bb32
bb32:
  %t160 = load ptr, ptr %l79, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t160, { i64, ptr } %t161)
  br label %bb33
bb33:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l5, { i64, ptr } { i64 3, ptr @.d41 })
  br label %bb34
bb34:
  store ptr %l5, ptr %l90, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr %"compiler/generic:ConstAsk", ptr %t164, i32 0, i32 5
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  store { i64, ptr } %t167, ptr %l93, !tbaa !27
  %t168 = load i64, ptr %l11, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i32, ptr %t171, i64 %t168
  %t173 = load i32, ptr %t172, !tbaa !33
  %t176 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s4, ptr %t163, i32 %t173)
  store { i64, ptr } %t176, ptr %l96
  br label %bb35
bb35:
  %t177 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t184, { i64, ptr } %t183)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb37:
  %t186 = load i64, ptr %l10, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l10, !tbaa !24
  br label %bb24
bb38:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/check:Checker", ptr %t190, i32 0, i32 0
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = getelementptr %"compiler/generic:Program", ptr %t193, i32 0, i32 0
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/load:Loader", ptr %t196, i32 0, i32 4
  %t199 = load ptr, ptr %t198, !tbaa !29
  store ptr %t199, ptr %l103, !tbaa !29
  store i64 %a2, ptr %l104, !tbaa !24
  %t201 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 0
  %t202 = load i64, ptr %t201, !tbaa !24
  %t203 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 1
  %t204 = getelementptr %"compiler/source:Span", ptr %t203, i32 0, i32 0
  %t205 = load i32, ptr %t204, !tbaa !23
  %t207 = sext i32 %t205 to i64
  %t208 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 1
  %t209 = getelementptr %"compiler/source:Span", ptr %t208, i32 0, i32 1
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = sext i32 %t210 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 0
  store i64 3, ptr %t214
  %t216 = insertvalue { i64, i64, i64 } undef, i64 %t202, 0
  %t218 = insertvalue { i64, i64, i64 } %t216, i64 %t207, 1
  %t220 = insertvalue { i64, i64, i64 } %t218, i64 %t212, 2
  %t221 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  store { i64, i64, i64 } %t220, ptr %t221
  %t222 = load { i64, [3 x i64] }, ptr %t213
  store { i64, [3 x i64] } %t222, ptr %l110
  %t223 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s0)
  store %"compiler/msgs:Msg" %t223, ptr %l111
  br label %bb39
bb39:
  %t224 = getelementptr %"compiler/msgs:Msg", ptr %l111, i32 0, i32 0
  %t225 = load i32, ptr %t224
  store i32 %t225, ptr %l112
  %t227 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t227, ptr %l114
  br label %bb40
bb40:
  %t228 = load i32, ptr %l112
  %t229 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t230 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s0, ptr %s0, ptr %s0, i32 %t228, { i64, ptr } { i64 0, ptr @.d42 }, { i64, ptr } %t229)
  store %"compiler/msgs:Msg" %t230, ptr %l115
  br label %bb41
bb41:
  %t231 = load ptr, ptr %l103, !tbaa !29
  %t232 = load i64, ptr %l104, !tbaa !24
  %t233 = load { i64, [3 x i64] }, ptr %l110
  %t234 = load %"compiler/msgs:Msg", ptr %l115
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t231, i64 %t232, { i64, [3 x i64] } %t233, %"compiler/msgs:Msg" %t234)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, i1, { i64, ptr }, { i64, [3 x i64] } } @compiler_2finterp_2echain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca i64
  %l11 = alloca { i1, { i64, [5 x i64] } }
  %l12 = alloca i1
  %l13 = alloca { i64, [5 x i64] }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l49 = alloca i64
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i1, { i64, [5 x i64] } }
  %l71 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l107 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l119 = alloca i64
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l136 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %t54 = alloca { i64, [3 x i64] }, align 8
  %t347 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 5
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v1, ptr %v1, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l29
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l29, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store ptr %a3, ptr %l7, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l7, !tbaa !29
  %t34 = icmp ne ptr %t32, null
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb42
bb4:
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l7, !tbaa !29
  %t40 = getelementptr %"compiler/ast:TopIf", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t41)
  store %"compiler/source:Span" %t43, ptr %l38
  br label %bb6
bb6:
  %t44 = load %"compiler/source:Span", ptr %l38
  store %"compiler/source:Span" %t44, ptr %l8
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t50 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = sext i32 %t51 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 0
  store i64 3, ptr %t55
  %t57 = insertvalue { i64, i64, i64 } undef, i64 %t45, 0
  %t59 = insertvalue { i64, i64, i64 } %t57, i64 %t49, 1
  %t61 = insertvalue { i64, i64, i64 } %t59, i64 %t53, 2
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 1
  store { i64, i64, i64 } %t61, ptr %t62
  %t63 = load { i64, [3 x i64] }, ptr %t54
  store { i64, [3 x i64] } %t63, ptr %l9
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TopIf", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t74 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v1, ptr %v2, ptr %t65, i64 %t66, ptr %t70)
  store i64 %t74, ptr %l49
  br label %bb7
bb7:
  %t75 = load i64, ptr %l49, !tbaa !24
  store i64 %t75, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = icmp slt i64 %t76, 0
  br i1 %t78, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr @.d43 }, ptr %l52, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t81 = load { i64, [3 x i64] }, ptr %l9
  %t82 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 0, 0
  %t83 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t82, i1 false, 1
  %t85 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t83, { i64, ptr } %t80, 2
  %t87 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t85, { i64, [3 x i64] } %t81, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t87, ptr %l55
  %t88 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l55, i32 0, i32 2
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l56, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l57, !tbaa !24
  %t92 = load i64, ptr %l57, !tbaa !24
  %t93 = mul i64 %t92, 1
  %t94 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l58, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l57, !tbaa !24
  %t102 = mul i64 %t101, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t98, ptr %t100, i64 %t102, i1 false)
  %t103 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t104 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l55, i32 0, i32 2
  store { i64, ptr } %t103, ptr %t104, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t105 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l55
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t105, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = call { i1, { i64, [5 x i64] } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCondStop(ptr %v0, ptr %s1, ptr %a0, i64 %t107)
  store { i1, { i64, [5 x i64] } } %t110, ptr %l61
  br label %bb11
bb11:
  %t111 = load { i1, { i64, [5 x i64] } }, ptr %l61
  store { i1, { i64, [5 x i64] } } %t111, ptr %l11
  %t112 = getelementptr { i1, { i64, [5 x i64] } }, ptr %l11, i32 0, i32 0
  %t113 = load i1, ptr %t112, !tbaa !21
  store i1 %t113, ptr %l12, !tbaa !21
  %t115 = getelementptr { i1, { i64, [5 x i64] } }, ptr %l11, i32 0, i32 1
  %t116 = load { i64, [5 x i64] }, ptr %t115
  store { i64, [5 x i64] } %t116, ptr %l13
  %t118 = load { i64, [5 x i64] }, ptr %l13
  %t120 = extractvalue { i64, [5 x i64] } %t118, 0
  %t121 = icmp eq i64 %t120, 0
  br i1 %t121, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb31
bb15:
  %t123 = load { i64, [5 x i64] }, ptr %l13
  %t125 = extractvalue { i64, [5 x i64] } %t123, 0
  %t126 = icmp eq i64 %t125, 3
  br i1 %t126, label %bb16, label %bb17
bb16:
  %t128 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t129 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t128, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129
  store { i64, ptr } %t130, ptr %l14, !tbaa !27
  %t132 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t133 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t132, i32 0, i32 1
  %t134 = load i64, ptr %t133
  store i64 %t134, ptr %l15, !tbaa !24
  %t136 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t137 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t136, i32 0, i32 2
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l16
  br label %bb18
bb17:
  br label %bb20
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t140 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t140, ptr %l71, !tbaa !27
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t142 = load i64, ptr %l15, !tbaa !24
  %t143 = load %"compiler/source:Span", ptr %l16
  %t147 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t141, i64 %t142, %"compiler/source:Span" %t143)
  store { i64, ptr } %t147, ptr %l75
  br label %bb19
bb19:
  %t148 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } { i64 2, ptr @.d44 }, 1
  %t152 = extractvalue { i64, ptr } { i64 2, ptr @.d44 }, 0
  %t153 = add i64 %t150, %t152
  %t154 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = add i64 %t153, %t156
  %t158 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 1
  %t159 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t149, i64 %t150)
  %t162 = getelementptr i8, ptr %t161, i64 %t150
  call void @olang_textcopy(ptr %t162, ptr %t151, i64 %t152)
  %t163 = getelementptr i8, ptr %t162, i64 %t152
  call void @olang_textcopy(ptr %t163, ptr %t155, i64 %t156)
  %t164 = getelementptr i8, ptr %t163, i64 %t156
  call void @olang_textcopy(ptr %t164, ptr %t158, i64 %t159)
  %t165 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t161, 1
  %t167 = load { i64, [3 x i64] }, ptr %l9
  %t168 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 0, 0
  %t169 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t168, i1 false, 1
  %t171 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t169, { i64, ptr } %t166, 2
  %t173 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t171, { i64, [3 x i64] } %t167, 3
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t173, ptr %rv
  br label %ret
bb20:
  %t175 = load { i64, [5 x i64] }, ptr %l13
  %t177 = extractvalue { i64, [5 x i64] } %t175, 0
  %t178 = icmp eq i64 %t177, 2
  br i1 %t178, label %bb21, label %bb22
bb21:
  %t180 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t181 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t180, i32 0, i32 0
  %t182 = load i32, ptr %t181
  store i32 %t182, ptr %l17
  %t184 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t185 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t184, i32 0, i32 1
  %t186 = load i64, ptr %t185
  store i64 %t186, ptr %l18, !tbaa !24
  %t188 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t189 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t188, i32 0, i32 2
  %t190 = load %"compiler/source:Span", ptr %t189
  store %"compiler/source:Span" %t190, ptr %l19
  br label %bb23
bb22:
  br label %bb26
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t192 = load i32, ptr %l17
  %t194 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s6, i32 %t192)
  store { i64, ptr } %t194, ptr %l85
  br label %bb24
bb24:
  %t195 = load ptr, ptr %l4, !tbaa !29
  %t196 = load i64, ptr %l18, !tbaa !24
  %t197 = load %"compiler/source:Span", ptr %l19
  %t201 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s6, ptr %t195, i64 %t196, %"compiler/source:Span" %t197)
  store { i64, ptr } %t201, ptr %l89
  br label %bb25
bb25:
  %t202 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } { i64 2, ptr @.d46 }, 1
  %t206 = extractvalue { i64, ptr } { i64 2, ptr @.d46 }, 0
  %t207 = add i64 %t204, %t206
  %t208 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = add i64 %t207, %t210
  %t212 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 1
  %t213 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 0
  %t214 = add i64 %t211, %t213
  %t215 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t203, i64 %t204)
  %t216 = getelementptr i8, ptr %t215, i64 %t204
  call void @olang_textcopy(ptr %t216, ptr %t205, i64 %t206)
  %t217 = getelementptr i8, ptr %t216, i64 %t206
  call void @olang_textcopy(ptr %t217, ptr %t209, i64 %t210)
  %t218 = getelementptr i8, ptr %t217, i64 %t210
  call void @olang_textcopy(ptr %t218, ptr %t212, i64 %t213)
  %t219 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t215, 1
  %t221 = load { i64, [3 x i64] }, ptr %l9
  %t222 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 0, 0
  %t223 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t222, i1 false, 1
  %t225 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t223, { i64, ptr } %t220, 2
  %t227 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t225, { i64, [3 x i64] } %t221, 3
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t227, ptr %rv
  br label %ret
bb26:
  %t229 = load { i64, [5 x i64] }, ptr %l13
  %t231 = extractvalue { i64, [5 x i64] } %t229, 0
  %t232 = icmp eq i64 %t231, 1
  br i1 %t232, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 40, ptr @.d48 }, ptr %l95, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t235 = load { i64, [3 x i64] }, ptr %l9
  %t236 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 0, 0
  %t237 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t236, i1 false, 1
  %t239 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t237, { i64, ptr } %t234, 2
  %t241 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t239, { i64, [3 x i64] } %t235, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t241, ptr %l98
  %t242 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l98, i32 0, i32 2
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !27
  store { i64, ptr } %t243, ptr %l99, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  store i64 %t245, ptr %l100, !tbaa !24
  %t246 = load i64, ptr %l100, !tbaa !24
  %t247 = mul i64 %t246, 1
  %t248 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t247)
  %t249 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  store { i64, ptr } %t250, ptr %l101, !tbaa !27
  %t251 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = load i64, ptr %l100, !tbaa !24
  %t256 = mul i64 %t255, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t252, ptr %t254, i64 %t256, i1 false)
  %t257 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t258 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l98, i32 0, i32 2
  store { i64, ptr } %t257, ptr %t258, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t259 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l98
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t259, ptr %rv
  br label %ret
bb30:
  call void @__olang_check_failed(ptr @.c49)
  unreachable
bb31:
  %t260 = load i1, ptr %l12, !tbaa !21
  br i1 %t260, label %bb32, label %bb33
bb32:
  %t262 = load i64, ptr %l6, !tbaa !24
  store { i64, ptr } { i64 0, ptr @.d50 }, ptr %l104, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t264 = load { i64, [3 x i64] }, ptr %l9
  %t266 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 %t262, 0
  %t267 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t266, i1 true, 1
  %t269 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t267, { i64, ptr } %t263, 2
  %t271 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t269, { i64, [3 x i64] } %t264, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t271, ptr %l107
  %t272 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l107, i32 0, i32 2
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  store { i64, ptr } %t273, ptr %l108, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l109, !tbaa !24
  %t276 = load i64, ptr %l109, !tbaa !24
  %t277 = mul i64 %t276, 1
  %t278 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t277)
  %t279 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  store { i64, ptr } %t280, ptr %l110, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = load i64, ptr %l109, !tbaa !24
  %t286 = mul i64 %t285, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t282, ptr %t284, i64 %t286, i1 false)
  %t287 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t288 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l107, i32 0, i32 2
  store { i64, ptr } %t287, ptr %t288, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t289 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l107
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t289, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t290 = load i64, ptr %l6, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l6, !tbaa !24
  %t294 = load ptr, ptr %l7, !tbaa !29
  %t296 = getelementptr %"compiler/ast:TopIf", ptr %t294, i32 0, i32 2
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = icmp eq ptr %t297, null
  br i1 %t299, label %bb35, label %bb36
bb35:
  %t301 = load ptr, ptr %l7, !tbaa !29
  %t303 = getelementptr %"compiler/ast:TopIf", ptr %t301, i32 0, i32 3
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = icmp ne ptr %t304, null
  br i1 %t306, label %bb37, label %bb38
bb36:
  br label %bb40
bb37:
  %t308 = load i64, ptr %l6, !tbaa !24
  store i64 %t308, ptr %l119, !tbaa !24
  br label %bb39
bb38:
  %t310 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store i64 %t310, ptr %l119, !tbaa !24
  br label %bb39
bb39:
  store { i64, ptr } { i64 0, ptr @.d51 }, ptr %l122, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t313 = load { i64, [3 x i64] }, ptr %l9
  %t314 = load i64, ptr %l119, !tbaa !24
  %t315 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 %t314, 0
  %t316 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t315, i1 true, 1
  %t318 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t316, { i64, ptr } %t312, 2
  %t320 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t318, { i64, [3 x i64] } %t313, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t320, ptr %l125
  %t321 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l125, i32 0, i32 2
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l126, !tbaa !27
  %t323 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t323, 0
  store i64 %t324, ptr %l127, !tbaa !24
  %t325 = load i64, ptr %l127, !tbaa !24
  %t326 = mul i64 %t325, 1
  %t327 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t326)
  %t328 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t327, 1
  store { i64, ptr } %t329, ptr %l128, !tbaa !27
  %t330 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = load i64, ptr %l127, !tbaa !24
  %t335 = mul i64 %t334, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t331, ptr %t333, i64 %t335, i1 false)
  %t336 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t337 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l125, i32 0, i32 2
  store { i64, ptr } %t336, ptr %t337, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t338 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l125
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t338, ptr %rv
  br label %ret
bb40:
  %t339 = load ptr, ptr %l7, !tbaa !29
  %t341 = getelementptr %"compiler/ast:TopIf", ptr %t339, i32 0, i32 2
  %t342 = load ptr, ptr %t341, !tbaa !29
  store ptr %t342, ptr %l7, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  br label %bb41
bb41:
  br label %bb2
bb42:
  %t344 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store { i64, ptr } { i64 0, ptr @.d52 }, ptr %l132, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t346 = load i64, ptr %l5, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [3 x i64] }, ptr %t347, i32 0, i32 0
  store i64 3, ptr %t348
  %t350 = insertvalue { i64, i64, i64 } undef, i64 %t346, 0
  %t351 = insertvalue { i64, i64, i64 } %t350, i64 0, 1
  %t352 = insertvalue { i64, i64, i64 } %t351, i64 0, 2
  %t353 = getelementptr { i64, [3 x i64] }, ptr %t347, i32 0, i32 1
  store { i64, i64, i64 } %t352, ptr %t353
  %t354 = load { i64, [3 x i64] }, ptr %t347
  %t356 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } undef, i64 %t344, 0
  %t357 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t356, i1 true, 1
  %t359 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t357, { i64, ptr } %t345, 2
  %t361 = insertvalue { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t359, { i64, [3 x i64] } %t354, 3
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t361, ptr %l136
  %t362 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l136, i32 0, i32 2
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  store { i64, ptr } %t363, ptr %l137, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  store i64 %t365, ptr %l138, !tbaa !24
  %t366 = load i64, ptr %l138, !tbaa !24
  %t367 = mul i64 %t366, 1
  %t368 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t367)
  %t369 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  store { i64, ptr } %t370, ptr %l139, !tbaa !27
  %t371 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = load i64, ptr %l138, !tbaa !24
  %t376 = mul i64 %t375, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t372, ptr %t374, i64 %t376, i1 false)
  %t377 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t378 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l136, i32 0, i32 2
  store { i64, ptr } %t377, ptr %t378, !tbaa !27
  %t379 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l136
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t379, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %rv
  ret { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %rr
}

define dso_local { i1, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca { i64, [5 x i64] }
  %l4 = alloca { i64, [5 x i64] }
  %l12 = alloca ptr
  %l13 = alloca { i64, [1 x i64] }
  %l17 = alloca { i64, [5 x i64] }
  %l21 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i32
  %l43 = alloca i32
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca i1
  %l58 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i64
  %l74 = alloca i64
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca i1
  %l90 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i1, i1 }
  %t5 = alloca { i64, [1 x i64] }, align 8
  %t33 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = trunc i64 %a1 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t5
  store { i64, [1 x i64] } %t10, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t12, { i64, [1 x i64] } %t13)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 4
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t19, ptr %l13
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c53)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = load ptr, ptr %l12, !tbaa !29
  %t29 = load { i64, [1 x i64] }, ptr %l13
  %t31 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t28, { i64, [1 x i64] } %t29, { i64, ptr } %t27)
  store { i64, [5 x i64] } %t31, ptr %l17
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c53)
  unreachable
bb6:
  %t32 = load { i64, [5 x i64] }, ptr %l17
  store { i64, [5 x i64] } %t32, ptr %l3
  store { i64, [5 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t35 = load { i64, [5 x i64] }, ptr %t33
  store { i64, [5 x i64] } %t35, ptr %l4
  %t37 = load { i64, [5 x i64] }, ptr %l3
  %t39 = extractvalue { i64, [5 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 0
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load { i64, [5 x i64] }, ptr %l4
  %t44 = extractvalue { i64, [5 x i64] } %t42, 0
  %t45 = icmp eq i64 %t44, 0
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb50
bb8:
  %t47 = load { i64, [5 x i64] }, ptr %l3
  %t49 = extractvalue { i64, [5 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load { i64, [5 x i64] }, ptr %l4
  %t54 = extractvalue { i64, [5 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 1
  br i1 %t55, label %bb11, label %bb12
bb10:
  %t57 = load { i64, [5 x i64] }, ptr %l3
  %t59 = extractvalue { i64, [5 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 2
  br i1 %t60, label %bb15, label %bb16
bb11:
  %t62 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  store i64 %t64, ptr %l30, !tbaa !24
  %t65 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t66 = getelementptr { i64 }, ptr %t65, i32 0, i32 0
  %t67 = load i64, ptr %t66
  store i64 %t67, ptr %l32, !tbaa !24
  %t70 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l30, ptr %l32)
  store i1 %t70, ptr %l34
  br label %bb13
bb12:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb14
bb13:
  %t71 = load i1, ptr %l34, !tbaa !21
  store i1 %t71, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t72 = load i1, ptr %l29, !tbaa !21
  store i1 %t72, ptr %l26, !tbaa !21
  br label %bb49
bb15:
  %t73 = load { i64, [5 x i64] }, ptr %l4
  %t75 = extractvalue { i64, [5 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 2
  br i1 %t76, label %bb17, label %bb18
bb16:
  %t78 = load { i64, [5 x i64] }, ptr %l3
  %t80 = extractvalue { i64, [5 x i64] } %t78, 0
  %t81 = icmp eq i64 %t80, 3
  br i1 %t81, label %bb33, label %bb34
bb17:
  %t83 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t84 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t83, i32 0, i32 0
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l41
  %t86 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t87 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l43
  %t91 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l41, ptr %l43)
  store i1 %t91, ptr %l45
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb20
bb19:
  %t92 = load i1, ptr %l45, !tbaa !21
  store i1 %t92, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t93 = load i1, ptr %l40, !tbaa !21
  br i1 %t93, label %bb21, label %bb22
bb21:
  %t94 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t95 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t94, i32 0, i32 1
  %t96 = load i64, ptr %t95
  store i64 %t96, ptr %l47, !tbaa !24
  %t97 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t98 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t97, i32 0, i32 1
  %t99 = load i64, ptr %t98
  store i64 %t99, ptr %l49, !tbaa !24
  %t102 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l47, ptr %l49)
  store i1 %t102, ptr %l51
  br label %bb23
bb22:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb24
bb23:
  %t103 = load i1, ptr %l51, !tbaa !21
  store i1 %t103, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l46, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t105 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t106 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t105, i32 0, i32 2
  %t107 = load %"compiler/source:Span", ptr %t106
  store %"compiler/source:Span" %t107, ptr %l53
  %t108 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t109 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t108, i32 0, i32 2
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l55
  %t113 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l53, ptr %l55)
  store i1 %t113, ptr %l57
  br label %bb27
bb26:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb28
bb27:
  %t114 = load i1, ptr %l57, !tbaa !21
  store i1 %t114, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t115 = load i1, ptr %l52, !tbaa !21
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t116 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t117 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t116, i32 0, i32 3
  %t118 = load { i64, ptr }, ptr %t117
  %t119 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t120 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t119, i32 0, i32 3
  %t121 = load { i64, ptr }, ptr %t120
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t118, { i64, ptr } %t121)
  store i1 %t124, ptr %l61
  br label %bb31
bb30:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb32
bb31:
  %t125 = load i1, ptr %l61, !tbaa !21
  store i1 %t125, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t126 = load i1, ptr %l58, !tbaa !21
  store i1 %t126, ptr %l37, !tbaa !21
  br label %bb48
bb33:
  %t127 = load { i64, [5 x i64] }, ptr %l4
  %t129 = extractvalue { i64, [5 x i64] } %t127, 0
  %t130 = icmp eq i64 %t129, 3
  br i1 %t130, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb47
bb35:
  %t132 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t133 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t132, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t136 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t135, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t134, { i64, ptr } %t137)
  store i1 %t140, ptr %l70
  br label %bb37
bb36:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb38
bb37:
  %t141 = load i1, ptr %l70, !tbaa !21
  store i1 %t141, ptr %l67, !tbaa !21
  br label %bb38
bb38:
  %t142 = load i1, ptr %l67, !tbaa !21
  br i1 %t142, label %bb39, label %bb40
bb39:
  %t143 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t144 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t143, i32 0, i32 1
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l72, !tbaa !24
  %t146 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t147 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t146, i32 0, i32 1
  %t148 = load i64, ptr %t147
  store i64 %t148, ptr %l74, !tbaa !24
  %t151 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l72, ptr %l74)
  store i1 %t151, ptr %l76
  br label %bb41
bb40:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb42
bb41:
  %t152 = load i1, ptr %l76, !tbaa !21
  store i1 %t152, ptr %l71, !tbaa !21
  br label %bb42
bb42:
  %t153 = load i1, ptr %l71, !tbaa !21
  br i1 %t153, label %bb43, label %bb44
bb43:
  %t154 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t155 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t154, i32 0, i32 2
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l78
  %t157 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t158 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t157, i32 0, i32 2
  %t159 = load %"compiler/source:Span", ptr %t158
  store %"compiler/source:Span" %t159, ptr %l80
  %t162 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l78, ptr %l80)
  store i1 %t162, ptr %l82
  br label %bb45
bb44:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb46
bb45:
  %t163 = load i1, ptr %l82, !tbaa !21
  store i1 %t163, ptr %l77, !tbaa !21
  br label %bb46
bb46:
  %t164 = load i1, ptr %l77, !tbaa !21
  store i1 %t164, ptr %l64, !tbaa !21
  br label %bb47
bb47:
  %t165 = load i1, ptr %l64, !tbaa !21
  store i1 %t165, ptr %l37, !tbaa !21
  br label %bb48
bb48:
  %t166 = load i1, ptr %l37, !tbaa !21
  store i1 %t166, ptr %l26, !tbaa !21
  br label %bb49
bb49:
  %t167 = load i1, ptr %l26, !tbaa !21
  store i1 %t167, ptr %l21, !tbaa !21
  br label %bb50
bb50:
  %t168 = load i1, ptr %l21, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb51, label %bb52
bb51:
  %t171 = insertvalue { i1, i1 } undef, i1 false, 0
  %t172 = insertvalue { i1, i1 } %t171, i1 false, 1
  call void @__olang_scope_close(ptr %s0)
  store { i1, i1 } %t172, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/interp:Exec", ptr %t174, i32 0, i32 4
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/interp:Exec", ptr %t177, i32 0, i32 4
  %t180 = getelementptr %"compiler/eval:Machine", ptr %t179, i32 0, i32 8
  %t181 = load %"compiler/eval:Ptr", ptr %t180
  %t182 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t186 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t176, %"compiler/eval:Ptr" %t181, i32 %t182)
  store i64 %t186, ptr %l90
  br label %bb54
bb54:
  %t187 = load i64, ptr %l90, !tbaa !24
  %t188 = icmp ne i64 %t187, 0
  %t190 = insertvalue { i1, i1 } undef, i1 %t188, 0
  %t191 = insertvalue { i1, i1 } %t190, i1 true, 1
  call void @__olang_scope_close(ptr %s0)
  store { i1, i1 } %t191, ptr %rv
  br label %ret
ret:
  %rr = load { i1, i1 }, ptr %rv
  ret { i1, i1 } %rr
}

define dso_local { i1, { i64, [5 x i64] } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCondStop(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %lp3 = alloca ptr
  %l4 = alloca { i64, [5 x i64] }
  %l12 = alloca ptr
  %l13 = alloca { i64, [1 x i64] }
  %l17 = alloca { i64, [5 x i64] }
  %l21 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i32
  %l43 = alloca i32
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca i1
  %l58 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i64
  %l74 = alloca i64
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca i1
  %l91 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i1, { i64, [5 x i64] } }
  %t5 = alloca { i64, [1 x i64] }, align 8
  %t35 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = trunc i64 %a1 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t5
  store { i64, [1 x i64] } %t10, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t12, { i64, [1 x i64] } %t13)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 4
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t19, ptr %l13
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c54)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = load ptr, ptr %l12, !tbaa !29
  %t29 = load { i64, [1 x i64] }, ptr %l13
  %t31 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v1, ptr %t28, { i64, [1 x i64] } %t29, { i64, ptr } %t27)
  store { i64, [5 x i64] } %t31, ptr %l17
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c54)
  unreachable
bb6:
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t32, ptr %lp3
  %t33 = load { i64, [5 x i64] }, ptr %l17
  %t34 = load ptr, ptr %lp3
  store { i64, [5 x i64] } %t33, ptr %t34
  store { i64, [5 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 0
  store i64 0, ptr %t36
  %t37 = load { i64, [5 x i64] }, ptr %t35
  store { i64, [5 x i64] } %t37, ptr %l4
  %t39 = load ptr, ptr %lp3
  %t40 = load { i64, [5 x i64] }, ptr %t39
  %t42 = extractvalue { i64, [5 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 0
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load { i64, [5 x i64] }, ptr %l4
  %t47 = extractvalue { i64, [5 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 0
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb50
bb8:
  %t50 = load ptr, ptr %lp3
  %t51 = load { i64, [5 x i64] }, ptr %t50
  %t53 = extractvalue { i64, [5 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 1
  br i1 %t54, label %bb9, label %bb10
bb9:
  %t56 = load { i64, [5 x i64] }, ptr %l4
  %t58 = extractvalue { i64, [5 x i64] } %t56, 0
  %t59 = icmp eq i64 %t58, 1
  br i1 %t59, label %bb11, label %bb12
bb10:
  %t61 = load ptr, ptr %lp3
  %t62 = load { i64, [5 x i64] }, ptr %t61
  %t64 = extractvalue { i64, [5 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 2
  br i1 %t65, label %bb15, label %bb16
bb11:
  %t67 = load ptr, ptr %lp3
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t69 = getelementptr { i64 }, ptr %t68, i32 0, i32 0
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l30, !tbaa !24
  %t71 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t72 = getelementptr { i64 }, ptr %t71, i32 0, i32 0
  %t73 = load i64, ptr %t72
  store i64 %t73, ptr %l32, !tbaa !24
  %t76 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l30, ptr %l32)
  store i1 %t76, ptr %l34
  br label %bb13
bb12:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb14
bb13:
  %t77 = load i1, ptr %l34, !tbaa !21
  store i1 %t77, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t78 = load i1, ptr %l29, !tbaa !21
  store i1 %t78, ptr %l26, !tbaa !21
  br label %bb49
bb15:
  %t79 = load { i64, [5 x i64] }, ptr %l4
  %t81 = extractvalue { i64, [5 x i64] } %t79, 0
  %t82 = icmp eq i64 %t81, 2
  br i1 %t82, label %bb17, label %bb18
bb16:
  %t84 = load ptr, ptr %lp3
  %t85 = load { i64, [5 x i64] }, ptr %t84
  %t87 = extractvalue { i64, [5 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 3
  br i1 %t88, label %bb33, label %bb34
bb17:
  %t90 = load ptr, ptr %lp3
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t92 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t91, i32 0, i32 0
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l41
  %t94 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t95 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l43
  %t99 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l41, ptr %l43)
  store i1 %t99, ptr %l45
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb20
bb19:
  %t100 = load i1, ptr %l45, !tbaa !21
  store i1 %t100, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t101 = load i1, ptr %l40, !tbaa !21
  br i1 %t101, label %bb21, label %bb22
bb21:
  %t102 = load ptr, ptr %lp3
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t104 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t103, i32 0, i32 1
  %t105 = load i64, ptr %t104
  store i64 %t105, ptr %l47, !tbaa !24
  %t106 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t107 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t106, i32 0, i32 1
  %t108 = load i64, ptr %t107
  store i64 %t108, ptr %l49, !tbaa !24
  %t111 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l47, ptr %l49)
  store i1 %t111, ptr %l51
  br label %bb23
bb22:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb24
bb23:
  %t112 = load i1, ptr %l51, !tbaa !21
  store i1 %t112, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t113 = load i1, ptr %l46, !tbaa !21
  br i1 %t113, label %bb25, label %bb26
bb25:
  %t114 = load ptr, ptr %lp3
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t116 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t115, i32 0, i32 2
  %t117 = load %"compiler/source:Span", ptr %t116
  store %"compiler/source:Span" %t117, ptr %l53
  %t118 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t119 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t118, i32 0, i32 2
  %t120 = load %"compiler/source:Span", ptr %t119
  store %"compiler/source:Span" %t120, ptr %l55
  %t123 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l53, ptr %l55)
  store i1 %t123, ptr %l57
  br label %bb27
bb26:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb28
bb27:
  %t124 = load i1, ptr %l57, !tbaa !21
  store i1 %t124, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t125 = load i1, ptr %l52, !tbaa !21
  br i1 %t125, label %bb29, label %bb30
bb29:
  %t126 = load ptr, ptr %lp3
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t126, i32 0, i32 1
  %t128 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t127, i32 0, i32 3
  %t129 = load { i64, ptr }, ptr %t128
  %t130 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t131 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t130, i32 0, i32 3
  %t132 = load { i64, ptr }, ptr %t131
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t129, { i64, ptr } %t132)
  store i1 %t135, ptr %l61
  br label %bb31
bb30:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb32
bb31:
  %t136 = load i1, ptr %l61, !tbaa !21
  store i1 %t136, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t137 = load i1, ptr %l58, !tbaa !21
  store i1 %t137, ptr %l37, !tbaa !21
  br label %bb48
bb33:
  %t138 = load { i64, [5 x i64] }, ptr %l4
  %t140 = extractvalue { i64, [5 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 3
  br i1 %t141, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb47
bb35:
  %t143 = load ptr, ptr %lp3
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t145 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t144, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145
  %t147 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t148 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t147, i32 0, i32 0
  %t149 = load { i64, ptr }, ptr %t148
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t146, { i64, ptr } %t149)
  store i1 %t152, ptr %l70
  br label %bb37
bb36:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb38
bb37:
  %t153 = load i1, ptr %l70, !tbaa !21
  store i1 %t153, ptr %l67, !tbaa !21
  br label %bb38
bb38:
  %t154 = load i1, ptr %l67, !tbaa !21
  br i1 %t154, label %bb39, label %bb40
bb39:
  %t155 = load ptr, ptr %lp3
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t155, i32 0, i32 1
  %t157 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t156, i32 0, i32 1
  %t158 = load i64, ptr %t157
  store i64 %t158, ptr %l72, !tbaa !24
  %t159 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t160 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t159, i32 0, i32 1
  %t161 = load i64, ptr %t160
  store i64 %t161, ptr %l74, !tbaa !24
  %t164 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l72, ptr %l74)
  store i1 %t164, ptr %l76
  br label %bb41
bb40:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb42
bb41:
  %t165 = load i1, ptr %l76, !tbaa !21
  store i1 %t165, ptr %l71, !tbaa !21
  br label %bb42
bb42:
  %t166 = load i1, ptr %l71, !tbaa !21
  br i1 %t166, label %bb43, label %bb44
bb43:
  %t167 = load ptr, ptr %lp3
  %t168 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t169 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t168, i32 0, i32 2
  %t170 = load %"compiler/source:Span", ptr %t169
  store %"compiler/source:Span" %t170, ptr %l78
  %t171 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t172 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t171, i32 0, i32 2
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l80
  %t176 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l78, ptr %l80)
  store i1 %t176, ptr %l82
  br label %bb45
bb44:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb46
bb45:
  %t177 = load i1, ptr %l82, !tbaa !21
  store i1 %t177, ptr %l77, !tbaa !21
  br label %bb46
bb46:
  %t178 = load i1, ptr %l77, !tbaa !21
  store i1 %t178, ptr %l64, !tbaa !21
  br label %bb47
bb47:
  %t179 = load i1, ptr %l64, !tbaa !21
  store i1 %t179, ptr %l37, !tbaa !21
  br label %bb48
bb48:
  %t180 = load i1, ptr %l37, !tbaa !21
  store i1 %t180, ptr %l26, !tbaa !21
  br label %bb49
bb49:
  %t181 = load i1, ptr %l26, !tbaa !21
  store i1 %t181, ptr %l21, !tbaa !21
  br label %bb50
bb50:
  %t182 = load i1, ptr %l21, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb51, label %bb52
bb51:
  %t185 = load ptr, ptr %lp3
  %t186 = load { i64, [5 x i64] }, ptr %t185
  %t187 = insertvalue { i1, { i64, [5 x i64] } } undef, i1 false, 0
  %t189 = insertvalue { i1, { i64, [5 x i64] } } %t187, { i64, [5 x i64] } %t186, 1
  call void @__olang_scope_close(ptr %s0)
  store { i1, { i64, [5 x i64] } } %t189, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/interp:Exec", ptr %t191, i32 0, i32 4
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/interp:Exec", ptr %t194, i32 0, i32 4
  %t197 = getelementptr %"compiler/eval:Machine", ptr %t196, i32 0, i32 8
  %t198 = load %"compiler/eval:Ptr", ptr %t197
  %t199 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t203 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t193, %"compiler/eval:Ptr" %t198, i32 %t199)
  store i64 %t203, ptr %l91
  br label %bb54
bb54:
  %t204 = load i64, ptr %l91, !tbaa !24
  %t205 = icmp ne i64 %t204, 0
  %t206 = load ptr, ptr %lp3
  %t207 = load { i64, [5 x i64] }, ptr %t206
  %t209 = insertvalue { i1, { i64, [5 x i64] } } undef, i1 %t205, 0
  %t211 = insertvalue { i1, { i64, [5 x i64] } } %t209, { i64, [5 x i64] } %t207, 1
  call void @__olang_scope_close(ptr %s0)
  store { i1, { i64, [5 x i64] } } %t211, ptr %rv
  br label %ret
ret:
  %rr = load { i1, { i64, [5 x i64] } }, ptr %rv
  ret { i1, { i64, [5 x i64] } } %rr
}

define dso_local { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca ptr
  %l54 = alloca ptr
  %l65 = alloca i64
  %l68 = alloca i64
  %l73 = alloca i1
  %l75 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l82 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l13
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store i64 -1, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/interp:Exec", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/interp:Exec", ptr %t11, i32 0, i32 1
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l18
  br label %bb2
bb2:
  %t16 = load i64, ptr %l18, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l22, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/interp:Exec", ptr %t63, i32 0, i32 1
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t65, i64 %t66)
  store ptr %t69, ptr %l46
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l46, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 1
  %t73 = load { i64, [2 x i64] }, ptr %t72
  store { i64, [2 x i64] } %t73, ptr %l10
  %t75 = load { i64, [2 x i64] }, ptr %l10
  %t77 = extractvalue { i64, [2 x i64] } %t75, 0
  %t78 = icmp eq i64 %t77, 5
  br i1 %t78, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/interp:Exec", ptr %t80, i32 0, i32 1
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l54
  br label %bb17
bb17:
  %t87 = load ptr, ptr %l54, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Body", ptr %t87, i32 0, i32 11
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = icmp ne ptr %t90, null
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load ptr, ptr %lp1
  %t95 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t94, i64 %t95)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb42
bb22:
  %t98 = load { i64, [2 x i64] }, ptr %l10
  %t100 = extractvalue { i64, [2 x i64] } %t98, 0
  %t101 = icmp eq i64 %t100, 0
  br i1 %t101, label %bb23, label %bb24
bb23:
  %t103 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t104 = getelementptr { i64 }, ptr %t103, i32 0, i32 0
  %t105 = load i64, ptr %t104
  store i64 %t105, ptr %l11, !tbaa !24
  br label %bb25
bb24:
  br label %bb37
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t107, i64 %t108)
  store i64 %t111, ptr %l65
  br label %bb26
bb26:
  %t112 = load i64, ptr %l65, !tbaa !24
  store i64 %t112, ptr %l12, !tbaa !24
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t114 = load i64, ptr %l12, !tbaa !24
  %t117 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t113, i64 %t114)
  store i64 %t117, ptr %l68
  br label %bb27
bb27:
  %t118 = load ptr, ptr %l3, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 0
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/load:Loader", ptr %t121, i32 0, i32 7
  %t124 = load i64, ptr %t123, !tbaa !24
  %t125 = load i64, ptr %l68, !tbaa !24
  %t127 = icmp eq i64 %t125, %t124
  br i1 %t127, label %bb28, label %bb29
bb28:
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = getelementptr %"compiler/types:Table", ptr %t131, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  store ptr %t133, ptr %l75, !tbaa !29
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t134, i64 %t135)
  store ptr %t138, ptr %l78
  br label %bb30
bb29:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb33
bb30:
  %t139 = load ptr, ptr %l78, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Func", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %t141, !tbaa !23
  %t143 = load ptr, ptr %l75, !tbaa !29
  %t145 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t143, i32 %t142)
  store { i64, ptr } %t145, ptr %l81
  br label %bb31
bb31:
  %t146 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t146, { i64, ptr } { i64 4, ptr @.d55 })
  store i1 %t147, ptr %l82
  br label %bb32
bb32:
  %t148 = load i1, ptr %l82, !tbaa !21
  store i1 %t148, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t149 = load i1, ptr %l73, !tbaa !21
  br i1 %t149, label %bb34, label %bb35
bb34:
  %t150 = load i64, ptr %l9, !tbaa !24
  store i64 %t150, ptr %l2, !tbaa !24
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @.c56)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  %t152 = load i64, ptr %l8, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l8, !tbaa !24
  br label %bb9
bb44:
  %t156 = load ptr, ptr %lp1
  %t157 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t156
  %t158 = load i64, ptr %l2, !tbaa !24
  %t160 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t157, 0
  %t162 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t160, i64 %t158, 1
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t162, ptr %rv
  br label %ret
ret:
  %rr = load { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %rv
  ret { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %rr
}

define dso_local { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, [5 x i64] }
  %l12 = alloca { i64, [5 x i64] }
  %l13 = alloca { i64, [5 x i64] }
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l48 = alloca { i64, [5 x i64] }
  %l52 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i64
  %l63 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l80 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca %"compiler/source:Span"
  %l86 = alloca %"compiler/source:Span"
  %l88 = alloca i1
  %l89 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i64
  %l105 = alloca i64
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca %"compiler/source:Span"
  %l111 = alloca %"compiler/source:Span"
  %l113 = alloca i1
  %l115 = alloca i1
  %l119 = alloca i1
  %l124 = alloca i1
  %l127 = alloca i1
  %l128 = alloca i64
  %l130 = alloca i64
  %l132 = alloca i1
  %l135 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i32
  %l141 = alloca i32
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca i64
  %l147 = alloca i64
  %l149 = alloca i1
  %l150 = alloca i1
  %l151 = alloca %"compiler/source:Span"
  %l153 = alloca %"compiler/source:Span"
  %l155 = alloca i1
  %l156 = alloca i1
  %l159 = alloca i1
  %l162 = alloca i1
  %l165 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i1
  %l170 = alloca i64
  %l172 = alloca i64
  %l174 = alloca i1
  %l175 = alloca i1
  %l176 = alloca %"compiler/source:Span"
  %l178 = alloca %"compiler/source:Span"
  %l180 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, [5 x i64] }
  %t3 = alloca { i64, [5 x i64] }, align 8
  %t84 = alloca { i64, [5 x i64] }, align 8
  %t222 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store { i64, [5 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load { i64, [5 x i64] }, ptr %t3
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t6, ptr %lp1
  %t8 = load ptr, ptr %lp1
  store { i64, [5 x i64] } %t5, ptr %t8
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/interp:Exec", ptr %t9, i32 0, i32 9
  store ptr %t11, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l22
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb4, label %ok.21
ok.21:
  store { i64, ptr } %t18, ptr %l21
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  br label %bb8
bb4:
  %t23 = load i32, ptr %l22, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c57)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb8:
  %t28 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb119
bb11:
  br label %bb12
bb12:
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t41, ptr %l31, !tbaa !27
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i64, ptr %t45, i64 %t42
  %t47 = load i64, ptr %t46, !tbaa !34
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/interp:Exec", ptr %t49, i32 0, i32 1
  %t55 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t51, i64 %t47)
  store ptr %t55, ptr %l37
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l37, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 1
  %t59 = load { i64, [2 x i64] }, ptr %t58
  store { i64, [2 x i64] } %t59, ptr %l8
  %t61 = load { i64, [2 x i64] }, ptr %l8
  %t63 = extractvalue { i64, [2 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 6
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t67 = getelementptr { i64, i32 }, ptr %t66, i32 0, i32 0
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l9, !tbaa !24
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t71 = getelementptr { i64, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l10, !tbaa !23
  br label %bb16
bb15:
  br label %bb112
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/interp:Exec", ptr %t74, i32 0, i32 4
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i32, ptr %l10, !tbaa !23
  %t82 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v0, ptr %t76, i64 %t77, i32 %t78)
  store { i64, [5 x i64] } %t82, ptr %l48
  br label %bb17
bb17:
  %t83 = load { i64, [5 x i64] }, ptr %l48
  store { i64, [5 x i64] } %t83, ptr %l11
  store { i64, [5 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load { i64, [5 x i64] }, ptr %t84
  store { i64, [5 x i64] } %t86, ptr %l12
  %t88 = load { i64, [5 x i64] }, ptr %l11
  %t90 = extractvalue { i64, [5 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 0
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t93 = load { i64, [5 x i64] }, ptr %l12
  %t95 = extractvalue { i64, [5 x i64] } %t93, 0
  %t96 = icmp eq i64 %t95, 0
  store i1 %t96, ptr %l52, !tbaa !21
  br label %bb61
bb19:
  %t98 = load { i64, [5 x i64] }, ptr %l11
  %t100 = extractvalue { i64, [5 x i64] } %t98, 0
  %t101 = icmp eq i64 %t100, 1
  br i1 %t101, label %bb20, label %bb21
bb20:
  %t103 = load { i64, [5 x i64] }, ptr %l12
  %t105 = extractvalue { i64, [5 x i64] } %t103, 0
  %t106 = icmp eq i64 %t105, 1
  br i1 %t106, label %bb22, label %bb23
bb21:
  %t108 = load { i64, [5 x i64] }, ptr %l11
  %t110 = extractvalue { i64, [5 x i64] } %t108, 0
  %t111 = icmp eq i64 %t110, 2
  br i1 %t111, label %bb26, label %bb27
bb22:
  %t113 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t114 = getelementptr { i64 }, ptr %t113, i32 0, i32 0
  %t115 = load i64, ptr %t114
  store i64 %t115, ptr %l61, !tbaa !24
  %t116 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t117 = getelementptr { i64 }, ptr %t116, i32 0, i32 0
  %t118 = load i64, ptr %t117
  store i64 %t118, ptr %l63, !tbaa !24
  %t121 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l61, ptr %l63)
  store i1 %t121, ptr %l65
  br label %bb24
bb23:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  %t122 = load i1, ptr %l65, !tbaa !21
  store i1 %t122, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t123 = load i1, ptr %l60, !tbaa !21
  store i1 %t123, ptr %l57, !tbaa !21
  br label %bb60
bb26:
  %t124 = load { i64, [5 x i64] }, ptr %l12
  %t126 = extractvalue { i64, [5 x i64] } %t124, 0
  %t127 = icmp eq i64 %t126, 2
  br i1 %t127, label %bb28, label %bb29
bb27:
  %t129 = load { i64, [5 x i64] }, ptr %l11
  %t131 = extractvalue { i64, [5 x i64] } %t129, 0
  %t132 = icmp eq i64 %t131, 3
  br i1 %t132, label %bb44, label %bb45
bb28:
  %t134 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t135 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t134, i32 0, i32 0
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l72
  %t137 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t138 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t137, i32 0, i32 0
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l74
  %t142 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l72, ptr %l74)
  store i1 %t142, ptr %l76
  br label %bb30
bb29:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb31
bb30:
  %t143 = load i1, ptr %l76, !tbaa !21
  store i1 %t143, ptr %l71, !tbaa !21
  br label %bb31
bb31:
  %t144 = load i1, ptr %l71, !tbaa !21
  br i1 %t144, label %bb32, label %bb33
bb32:
  %t145 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t146 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t145, i32 0, i32 1
  %t147 = load i64, ptr %t146
  store i64 %t147, ptr %l78, !tbaa !24
  %t148 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t149 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t148, i32 0, i32 1
  %t150 = load i64, ptr %t149
  store i64 %t150, ptr %l80, !tbaa !24
  %t153 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l78, ptr %l80)
  store i1 %t153, ptr %l82
  br label %bb34
bb33:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb35
bb34:
  %t154 = load i1, ptr %l82, !tbaa !21
  store i1 %t154, ptr %l77, !tbaa !21
  br label %bb35
bb35:
  %t155 = load i1, ptr %l77, !tbaa !21
  br i1 %t155, label %bb36, label %bb37
bb36:
  %t156 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t157 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t156, i32 0, i32 2
  %t158 = load %"compiler/source:Span", ptr %t157
  store %"compiler/source:Span" %t158, ptr %l84
  %t159 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t160 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t159, i32 0, i32 2
  %t161 = load %"compiler/source:Span", ptr %t160
  store %"compiler/source:Span" %t161, ptr %l86
  %t164 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l84, ptr %l86)
  store i1 %t164, ptr %l88
  br label %bb38
bb37:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb39
bb38:
  %t165 = load i1, ptr %l88, !tbaa !21
  store i1 %t165, ptr %l83, !tbaa !21
  br label %bb39
bb39:
  %t166 = load i1, ptr %l83, !tbaa !21
  br i1 %t166, label %bb40, label %bb41
bb40:
  %t167 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t168 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t167, i32 0, i32 3
  %t169 = load { i64, ptr }, ptr %t168
  %t170 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t171 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t170, i32 0, i32 3
  %t172 = load { i64, ptr }, ptr %t171
  %t175 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t169, { i64, ptr } %t172)
  store i1 %t175, ptr %l92
  br label %bb42
bb41:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb43
bb42:
  %t176 = load i1, ptr %l92, !tbaa !21
  store i1 %t176, ptr %l89, !tbaa !21
  br label %bb43
bb43:
  %t177 = load i1, ptr %l89, !tbaa !21
  store i1 %t177, ptr %l68, !tbaa !21
  br label %bb59
bb44:
  %t178 = load { i64, [5 x i64] }, ptr %l12
  %t180 = extractvalue { i64, [5 x i64] } %t178, 0
  %t181 = icmp eq i64 %t180, 3
  br i1 %t181, label %bb46, label %bb47
bb45:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb58
bb46:
  %t183 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t184 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t183, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184
  %t186 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t187 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t186, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187
  %t191 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t185, { i64, ptr } %t188)
  store i1 %t191, ptr %l101
  br label %bb48
bb47:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb49
bb48:
  %t192 = load i1, ptr %l101, !tbaa !21
  store i1 %t192, ptr %l98, !tbaa !21
  br label %bb49
bb49:
  %t193 = load i1, ptr %l98, !tbaa !21
  br i1 %t193, label %bb50, label %bb51
bb50:
  %t194 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t195 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t194, i32 0, i32 1
  %t196 = load i64, ptr %t195
  store i64 %t196, ptr %l103, !tbaa !24
  %t197 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t198 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t197, i32 0, i32 1
  %t199 = load i64, ptr %t198
  store i64 %t199, ptr %l105, !tbaa !24
  %t202 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l103, ptr %l105)
  store i1 %t202, ptr %l107
  br label %bb52
bb51:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb53
bb52:
  %t203 = load i1, ptr %l107, !tbaa !21
  store i1 %t203, ptr %l102, !tbaa !21
  br label %bb53
bb53:
  %t204 = load i1, ptr %l102, !tbaa !21
  br i1 %t204, label %bb54, label %bb55
bb54:
  %t205 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t206 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t205, i32 0, i32 2
  %t207 = load %"compiler/source:Span", ptr %t206
  store %"compiler/source:Span" %t207, ptr %l109
  %t208 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t209 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t208, i32 0, i32 2
  %t210 = load %"compiler/source:Span", ptr %t209
  store %"compiler/source:Span" %t210, ptr %l111
  %t213 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l109, ptr %l111)
  store i1 %t213, ptr %l113
  br label %bb56
bb55:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb57
bb56:
  %t214 = load i1, ptr %l113, !tbaa !21
  store i1 %t214, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t215 = load i1, ptr %l108, !tbaa !21
  store i1 %t215, ptr %l95, !tbaa !21
  br label %bb58
bb58:
  %t216 = load i1, ptr %l95, !tbaa !21
  store i1 %t216, ptr %l68, !tbaa !21
  br label %bb59
bb59:
  %t217 = load i1, ptr %l68, !tbaa !21
  store i1 %t217, ptr %l57, !tbaa !21
  br label %bb60
bb60:
  %t218 = load i1, ptr %l57, !tbaa !21
  store i1 %t218, ptr %l52, !tbaa !21
  br label %bb61
bb61:
  %t219 = load i1, ptr %l52, !tbaa !21
  %t220 = xor i1 %t219, true
  br i1 %t220, label %bb62, label %bb63
bb62:
  store { i64, [5 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 0
  store i64 0, ptr %t223
  %t224 = load { i64, [5 x i64] }, ptr %t222
  store { i64, [5 x i64] } %t224, ptr %l13
  %t226 = load ptr, ptr %lp1
  %t227 = load { i64, [5 x i64] }, ptr %t226
  %t229 = extractvalue { i64, [5 x i64] } %t227, 0
  %t230 = icmp eq i64 %t229, 0
  br i1 %t230, label %bb64, label %bb65
bb63:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb108
bb64:
  %t232 = load { i64, [5 x i64] }, ptr %l13
  %t234 = extractvalue { i64, [5 x i64] } %t232, 0
  %t235 = icmp eq i64 %t234, 0
  store i1 %t235, ptr %l119, !tbaa !21
  br label %bb107
bb65:
  %t237 = load ptr, ptr %lp1
  %t238 = load { i64, [5 x i64] }, ptr %t237
  %t240 = extractvalue { i64, [5 x i64] } %t238, 0
  %t241 = icmp eq i64 %t240, 1
  br i1 %t241, label %bb66, label %bb67
bb66:
  %t243 = load { i64, [5 x i64] }, ptr %l13
  %t245 = extractvalue { i64, [5 x i64] } %t243, 0
  %t246 = icmp eq i64 %t245, 1
  br i1 %t246, label %bb68, label %bb69
bb67:
  %t248 = load ptr, ptr %lp1
  %t249 = load { i64, [5 x i64] }, ptr %t248
  %t251 = extractvalue { i64, [5 x i64] } %t249, 0
  %t252 = icmp eq i64 %t251, 2
  br i1 %t252, label %bb72, label %bb73
bb68:
  %t254 = load ptr, ptr %lp1
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  %t256 = getelementptr { i64 }, ptr %t255, i32 0, i32 0
  %t257 = load i64, ptr %t256
  store i64 %t257, ptr %l128, !tbaa !24
  %t258 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t259 = getelementptr { i64 }, ptr %t258, i32 0, i32 0
  %t260 = load i64, ptr %t259
  store i64 %t260, ptr %l130, !tbaa !24
  %t263 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l128, ptr %l130)
  store i1 %t263, ptr %l132
  br label %bb70
bb69:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb71
bb70:
  %t264 = load i1, ptr %l132, !tbaa !21
  store i1 %t264, ptr %l127, !tbaa !21
  br label %bb71
bb71:
  %t265 = load i1, ptr %l127, !tbaa !21
  store i1 %t265, ptr %l124, !tbaa !21
  br label %bb106
bb72:
  %t266 = load { i64, [5 x i64] }, ptr %l13
  %t268 = extractvalue { i64, [5 x i64] } %t266, 0
  %t269 = icmp eq i64 %t268, 2
  br i1 %t269, label %bb74, label %bb75
bb73:
  %t271 = load ptr, ptr %lp1
  %t272 = load { i64, [5 x i64] }, ptr %t271
  %t274 = extractvalue { i64, [5 x i64] } %t272, 0
  %t275 = icmp eq i64 %t274, 3
  br i1 %t275, label %bb90, label %bb91
bb74:
  %t277 = load ptr, ptr %lp1
  %t278 = getelementptr { i64, [5 x i64] }, ptr %t277, i32 0, i32 1
  %t279 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t278, i32 0, i32 0
  %t280 = load i32, ptr %t279
  store i32 %t280, ptr %l139
  %t281 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t282 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t281, i32 0, i32 0
  %t283 = load i32, ptr %t282
  store i32 %t283, ptr %l141
  %t286 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l139, ptr %l141)
  store i1 %t286, ptr %l143
  br label %bb76
bb75:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb77
bb76:
  %t287 = load i1, ptr %l143, !tbaa !21
  store i1 %t287, ptr %l138, !tbaa !21
  br label %bb77
bb77:
  %t288 = load i1, ptr %l138, !tbaa !21
  br i1 %t288, label %bb78, label %bb79
bb78:
  %t289 = load ptr, ptr %lp1
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  %t291 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t290, i32 0, i32 1
  %t292 = load i64, ptr %t291
  store i64 %t292, ptr %l145, !tbaa !24
  %t293 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t294 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t293, i32 0, i32 1
  %t295 = load i64, ptr %t294
  store i64 %t295, ptr %l147, !tbaa !24
  %t298 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l145, ptr %l147)
  store i1 %t298, ptr %l149
  br label %bb80
bb79:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb81
bb80:
  %t299 = load i1, ptr %l149, !tbaa !21
  store i1 %t299, ptr %l144, !tbaa !21
  br label %bb81
bb81:
  %t300 = load i1, ptr %l144, !tbaa !21
  br i1 %t300, label %bb82, label %bb83
bb82:
  %t301 = load ptr, ptr %lp1
  %t302 = getelementptr { i64, [5 x i64] }, ptr %t301, i32 0, i32 1
  %t303 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t302, i32 0, i32 2
  %t304 = load %"compiler/source:Span", ptr %t303
  store %"compiler/source:Span" %t304, ptr %l151
  %t305 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t306 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t305, i32 0, i32 2
  %t307 = load %"compiler/source:Span", ptr %t306
  store %"compiler/source:Span" %t307, ptr %l153
  %t310 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l151, ptr %l153)
  store i1 %t310, ptr %l155
  br label %bb84
bb83:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb85
bb84:
  %t311 = load i1, ptr %l155, !tbaa !21
  store i1 %t311, ptr %l150, !tbaa !21
  br label %bb85
bb85:
  %t312 = load i1, ptr %l150, !tbaa !21
  br i1 %t312, label %bb86, label %bb87
bb86:
  %t313 = load ptr, ptr %lp1
  %t314 = getelementptr { i64, [5 x i64] }, ptr %t313, i32 0, i32 1
  %t315 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t314, i32 0, i32 3
  %t316 = load { i64, ptr }, ptr %t315
  %t317 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t318 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t317, i32 0, i32 3
  %t319 = load { i64, ptr }, ptr %t318
  %t322 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t316, { i64, ptr } %t319)
  store i1 %t322, ptr %l159
  br label %bb88
bb87:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb89
bb88:
  %t323 = load i1, ptr %l159, !tbaa !21
  store i1 %t323, ptr %l156, !tbaa !21
  br label %bb89
bb89:
  %t324 = load i1, ptr %l156, !tbaa !21
  store i1 %t324, ptr %l135, !tbaa !21
  br label %bb105
bb90:
  %t325 = load { i64, [5 x i64] }, ptr %l13
  %t327 = extractvalue { i64, [5 x i64] } %t325, 0
  %t328 = icmp eq i64 %t327, 3
  br i1 %t328, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb104
bb92:
  %t330 = load ptr, ptr %lp1
  %t331 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 1
  %t332 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t331, i32 0, i32 0
  %t333 = load { i64, ptr }, ptr %t332
  %t334 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t335 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t334, i32 0, i32 0
  %t336 = load { i64, ptr }, ptr %t335
  %t339 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t333, { i64, ptr } %t336)
  store i1 %t339, ptr %l168
  br label %bb94
bb93:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb95
bb94:
  %t340 = load i1, ptr %l168, !tbaa !21
  store i1 %t340, ptr %l165, !tbaa !21
  br label %bb95
bb95:
  %t341 = load i1, ptr %l165, !tbaa !21
  br i1 %t341, label %bb96, label %bb97
bb96:
  %t342 = load ptr, ptr %lp1
  %t343 = getelementptr { i64, [5 x i64] }, ptr %t342, i32 0, i32 1
  %t344 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t343, i32 0, i32 1
  %t345 = load i64, ptr %t344
  store i64 %t345, ptr %l170, !tbaa !24
  %t346 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t347 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t346, i32 0, i32 1
  %t348 = load i64, ptr %t347
  store i64 %t348, ptr %l172, !tbaa !24
  %t351 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l170, ptr %l172)
  store i1 %t351, ptr %l174
  br label %bb98
bb97:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb99
bb98:
  %t352 = load i1, ptr %l174, !tbaa !21
  store i1 %t352, ptr %l169, !tbaa !21
  br label %bb99
bb99:
  %t353 = load i1, ptr %l169, !tbaa !21
  br i1 %t353, label %bb100, label %bb101
bb100:
  %t354 = load ptr, ptr %lp1
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t354, i32 0, i32 1
  %t356 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t355, i32 0, i32 2
  %t357 = load %"compiler/source:Span", ptr %t356
  store %"compiler/source:Span" %t357, ptr %l176
  %t358 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t359 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t358, i32 0, i32 2
  %t360 = load %"compiler/source:Span", ptr %t359
  store %"compiler/source:Span" %t360, ptr %l178
  %t363 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l176, ptr %l178)
  store i1 %t363, ptr %l180
  br label %bb102
bb101:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb103
bb102:
  %t364 = load i1, ptr %l180, !tbaa !21
  store i1 %t364, ptr %l175, !tbaa !21
  br label %bb103
bb103:
  %t365 = load i1, ptr %l175, !tbaa !21
  store i1 %t365, ptr %l162, !tbaa !21
  br label %bb104
bb104:
  %t366 = load i1, ptr %l162, !tbaa !21
  store i1 %t366, ptr %l135, !tbaa !21
  br label %bb105
bb105:
  %t367 = load i1, ptr %l135, !tbaa !21
  store i1 %t367, ptr %l124, !tbaa !21
  br label %bb106
bb106:
  %t368 = load i1, ptr %l124, !tbaa !21
  store i1 %t368, ptr %l119, !tbaa !21
  br label %bb107
bb107:
  %t369 = load i1, ptr %l119, !tbaa !21
  store i1 %t369, ptr %l115, !tbaa !21
  br label %bb108
bb108:
  %t370 = load i1, ptr %l115, !tbaa !21
  br i1 %t370, label %bb109, label %bb110
bb109:
  %t371 = load { i64, [5 x i64] }, ptr %l11
  %t373 = load ptr, ptr %lp1
  store { i64, [5 x i64] } %t371, ptr %t373
  br label %bb111
bb110:
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s4)
  br label %bb117
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @.c58)
  unreachable
bb117:
  call void @__olang_scope_close(ptr %s3)
  br label %bb118
bb118:
  %t374 = load i64, ptr %l6, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l6, !tbaa !24
  br label %bb9
bb119:
  %t378 = load i64, ptr %l3, !tbaa !24
  %t379 = load i64, ptr %l5, !tbaa !24
  %t382 = add i64 %t378, %t379
  store i64 %t382, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb120
bb120:
  br label %bb2
bb121:
  %t384 = load ptr, ptr %lp1
  %t385 = load { i64, [5 x i64] }, ptr %t384
  store { i64, [5 x i64] } %t385, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { i64, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInt(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca { i64, [5 x i64] }
  %l5 = alloca { i64, [5 x i64] }
  %l13 = alloca ptr
  %l14 = alloca { i64, [1 x i64] }
  %l18 = alloca { i64, [5 x i64] }
  %l22 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i32
  %l44 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/source:Span"
  %l58 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i64
  %l75 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/source:Span"
  %l83 = alloca i1
  %l91 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, i1 }
  %t5 = alloca { i64, [1 x i64] }, align 8
  %t33 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = trunc i64 %a1 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t5
  store { i64, [1 x i64] } %t10, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [1 x i64] }, ptr %l3
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t12, { i64, [1 x i64] } %t13)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 4
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t19, ptr %l14
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = load { i64, [1 x i64] }, ptr %l14
  %t31 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t28, { i64, [1 x i64] } %t29, { i64, ptr } %t27)
  store { i64, [5 x i64] } %t31, ptr %l18
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb6:
  %t32 = load { i64, [5 x i64] }, ptr %l18
  store { i64, [5 x i64] } %t32, ptr %l4
  store { i64, [5 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t35 = load { i64, [5 x i64] }, ptr %t33
  store { i64, [5 x i64] } %t35, ptr %l5
  %t37 = load { i64, [5 x i64] }, ptr %l4
  %t39 = extractvalue { i64, [5 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 0
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load { i64, [5 x i64] }, ptr %l5
  %t44 = extractvalue { i64, [5 x i64] } %t42, 0
  %t45 = icmp eq i64 %t44, 0
  store i1 %t45, ptr %l22, !tbaa !21
  br label %bb50
bb8:
  %t47 = load { i64, [5 x i64] }, ptr %l4
  %t49 = extractvalue { i64, [5 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load { i64, [5 x i64] }, ptr %l5
  %t54 = extractvalue { i64, [5 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 1
  br i1 %t55, label %bb11, label %bb12
bb10:
  %t57 = load { i64, [5 x i64] }, ptr %l4
  %t59 = extractvalue { i64, [5 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 2
  br i1 %t60, label %bb15, label %bb16
bb11:
  %t62 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t66 = getelementptr { i64 }, ptr %t65, i32 0, i32 0
  %t67 = load i64, ptr %t66
  store i64 %t67, ptr %l33, !tbaa !24
  %t70 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l31, ptr %l33)
  store i1 %t70, ptr %l35
  br label %bb13
bb12:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t71 = load i1, ptr %l35, !tbaa !21
  store i1 %t71, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t72 = load i1, ptr %l30, !tbaa !21
  store i1 %t72, ptr %l27, !tbaa !21
  br label %bb49
bb15:
  %t73 = load { i64, [5 x i64] }, ptr %l5
  %t75 = extractvalue { i64, [5 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 2
  br i1 %t76, label %bb17, label %bb18
bb16:
  %t78 = load { i64, [5 x i64] }, ptr %l4
  %t80 = extractvalue { i64, [5 x i64] } %t78, 0
  %t81 = icmp eq i64 %t80, 3
  br i1 %t81, label %bb33, label %bb34
bb17:
  %t83 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t84 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t83, i32 0, i32 0
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l42
  %t86 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t87 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l44
  %t91 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l42, ptr %l44)
  store i1 %t91, ptr %l46
  br label %bb19
bb18:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb20
bb19:
  %t92 = load i1, ptr %l46, !tbaa !21
  store i1 %t92, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t93 = load i1, ptr %l41, !tbaa !21
  br i1 %t93, label %bb21, label %bb22
bb21:
  %t94 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t95 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t94, i32 0, i32 1
  %t96 = load i64, ptr %t95
  store i64 %t96, ptr %l48, !tbaa !24
  %t97 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t98 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t97, i32 0, i32 1
  %t99 = load i64, ptr %t98
  store i64 %t99, ptr %l50, !tbaa !24
  %t102 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l48, ptr %l50)
  store i1 %t102, ptr %l52
  br label %bb23
bb22:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb24
bb23:
  %t103 = load i1, ptr %l52, !tbaa !21
  store i1 %t103, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l47, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t105 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t106 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t105, i32 0, i32 2
  %t107 = load %"compiler/source:Span", ptr %t106
  store %"compiler/source:Span" %t107, ptr %l54
  %t108 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t109 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t108, i32 0, i32 2
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l56
  %t113 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l54, ptr %l56)
  store i1 %t113, ptr %l58
  br label %bb27
bb26:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb28
bb27:
  %t114 = load i1, ptr %l58, !tbaa !21
  store i1 %t114, ptr %l53, !tbaa !21
  br label %bb28
bb28:
  %t115 = load i1, ptr %l53, !tbaa !21
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t116 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t117 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t116, i32 0, i32 3
  %t118 = load { i64, ptr }, ptr %t117
  %t119 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t120 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t119, i32 0, i32 3
  %t121 = load { i64, ptr }, ptr %t120
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t118, { i64, ptr } %t121)
  store i1 %t124, ptr %l62
  br label %bb31
bb30:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb32
bb31:
  %t125 = load i1, ptr %l62, !tbaa !21
  store i1 %t125, ptr %l59, !tbaa !21
  br label %bb32
bb32:
  %t126 = load i1, ptr %l59, !tbaa !21
  store i1 %t126, ptr %l38, !tbaa !21
  br label %bb48
bb33:
  %t127 = load { i64, [5 x i64] }, ptr %l5
  %t129 = extractvalue { i64, [5 x i64] } %t127, 0
  %t130 = icmp eq i64 %t129, 3
  br i1 %t130, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb47
bb35:
  %t132 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t133 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t132, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t136 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t135, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t134, { i64, ptr } %t137)
  store i1 %t140, ptr %l71
  br label %bb37
bb36:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb38
bb37:
  %t141 = load i1, ptr %l71, !tbaa !21
  store i1 %t141, ptr %l68, !tbaa !21
  br label %bb38
bb38:
  %t142 = load i1, ptr %l68, !tbaa !21
  br i1 %t142, label %bb39, label %bb40
bb39:
  %t143 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t144 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t143, i32 0, i32 1
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l73, !tbaa !24
  %t146 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t147 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t146, i32 0, i32 1
  %t148 = load i64, ptr %t147
  store i64 %t148, ptr %l75, !tbaa !24
  %t151 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l73, ptr %l75)
  store i1 %t151, ptr %l77
  br label %bb41
bb40:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb42
bb41:
  %t152 = load i1, ptr %l77, !tbaa !21
  store i1 %t152, ptr %l72, !tbaa !21
  br label %bb42
bb42:
  %t153 = load i1, ptr %l72, !tbaa !21
  br i1 %t153, label %bb43, label %bb44
bb43:
  %t154 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t155 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t154, i32 0, i32 2
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l79
  %t157 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t158 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t157, i32 0, i32 2
  %t159 = load %"compiler/source:Span", ptr %t158
  store %"compiler/source:Span" %t159, ptr %l81
  %t162 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l79, ptr %l81)
  store i1 %t162, ptr %l83
  br label %bb45
bb44:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb46
bb45:
  %t163 = load i1, ptr %l83, !tbaa !21
  store i1 %t163, ptr %l78, !tbaa !21
  br label %bb46
bb46:
  %t164 = load i1, ptr %l78, !tbaa !21
  store i1 %t164, ptr %l65, !tbaa !21
  br label %bb47
bb47:
  %t165 = load i1, ptr %l65, !tbaa !21
  store i1 %t165, ptr %l38, !tbaa !21
  br label %bb48
bb48:
  %t166 = load i1, ptr %l38, !tbaa !21
  store i1 %t166, ptr %l27, !tbaa !21
  br label %bb49
bb49:
  %t167 = load i1, ptr %l27, !tbaa !21
  store i1 %t167, ptr %l22, !tbaa !21
  br label %bb50
bb50:
  %t168 = load i1, ptr %l22, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb51, label %bb52
bb51:
  %t171 = insertvalue { i64, i1 } undef, i64 0, 0
  %t172 = insertvalue { i64, i1 } %t171, i1 false, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, i1 } %t172, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/interp:Exec", ptr %t174, i32 0, i32 4
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/interp:Exec", ptr %t177, i32 0, i32 4
  %t180 = getelementptr %"compiler/eval:Machine", ptr %t179, i32 0, i32 8
  %t181 = load %"compiler/eval:Ptr", ptr %t180
  %t186 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t176, %"compiler/eval:Ptr" %t181, i32 %a2)
  store i64 %t186, ptr %l91
  br label %bb54
bb54:
  %t187 = load i64, ptr %l91, !tbaa !24
  %t188 = insertvalue { i64, i1 } undef, i64 %t187, 0
  %t189 = insertvalue { i64, i1 } %t188, i1 true, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, i1 } %t189, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i1 }, ptr %rv
  ret { i64, i1 } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l5 = alloca %"compiler/mir:Fn"
  %l6 = alloca i32
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l15 = alloca { i64, [1 x i64] }
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca i32
  %l22 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca i1
  %l39 = alloca i1
  %l46 = alloca %"compiler/mir:Fn"
  %l59 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t75 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l8
  br label %bb2
bb2:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2, { i64, [1 x i64] } %a1)
  br label %bb3
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2)
  store i64 %t10, ptr %l12
  br label %bb5
bb5:
  %t11 = load i64, ptr %l12, !tbaa !24
  %t12 = icmp sgt i64 %t11, 0
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb58
bb7:
  br label %bb8
bb8:
  %t17 = call { i32, { i64, [1 x i64] } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePop_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2)
  %t18 = extractvalue { i32, { i64, [1 x i64] } } %t17, 1
  %t19 = extractvalue { i32, { i64, [1 x i64] } } %t17, 0
  store i32 %t19, ptr %l18
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb10, label %ok.21
ok.21:
  store { i64, [1 x i64] } %t18, ptr %l17
  br label %bb9
bb9:
  %t22 = load { i64, [1 x i64] }, ptr %l17
  store { i64, [1 x i64] } %t22, ptr %l15
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb58
bb12:
  %t23 = load { i64, [1 x i64] }, ptr %l15
  store { i64, [1 x i64] } %t23, ptr %l3
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/interp:Exec", ptr %t24, i32 0, i32 6
  %t27 = load { i64, [1 x i64] }, ptr %l3
  %t30 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t26, { i64, [1 x i64] } %t27)
  store i1 %t30, ptr %l22
  br label %bb13
bb13:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb15:
  br label %bb16
bb16:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/interp:Exec", ptr %t32, i32 0, i32 6
  %t35 = load { i64, [1 x i64] }, ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t34, { i64, [1 x i64] } %t35, i1 true)
  br label %bb17
bb17:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/interp:Exec", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l27
  store i32 0, ptr %l29
  %t44 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3aMode(ptr %l27, ptr %l29)
  store i1 %t44, ptr %l31
  br label %bb18
bb18:
  %t45 = load i1, ptr %l31, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t46 = load { i64, [1 x i64] }, ptr %l3
  %t48 = extractvalue { i64, [1 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 0
  br i1 %t49, label %bb21, label %bb22
bb20:
  br label %bb35
bb21:
  %t51 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t52 = getelementptr { i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l4, !tbaa !23
  br label %bb23
bb22:
  br label %bb29
bb23:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/interp:Exec", ptr %t55, i32 0, i32 10
  %t58 = load i32, ptr %l4, !tbaa !23
  %t60 = sext i32 %t58 to i64
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t57, i64 %t60)
  store i1 %t63, ptr %l39
  br label %bb24
bb24:
  %t64 = load i1, ptr %l39, !tbaa !21
  br i1 %t64, label %bb25, label %bb26
bb25:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/interp:Exec", ptr %t65, i32 0, i32 5
  %t68 = load { i64, [1 x i64] }, ptr %l3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t67, { i64, [1 x i64] } %t68)
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @.c60)
  unreachable
bb34:
  br label %bb35
bb35:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/interp:Exec", ptr %t71, i32 0, i32 3
  %t74 = load { i64, [1 x i64] }, ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t75, ptr %v0, ptr %v0, ptr %t73, { i64, [1 x i64] } %t74)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t75, i64 192, i1 false)
  br label %bb36
bb36:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l46, i64 192, i1 false)
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/interp:Exec", ptr %t78, i32 0, i32 3
  %t81 = getelementptr %"compiler/lower:Lowerer", ptr %t80, i32 0, i32 4
  %t82 = load i1, ptr %t81, !tbaa !21
  br i1 %t82, label %bb37, label %bb38
bb37:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/interp:Exec", ptr %t84, i32 0, i32 5
  %t87 = load { i64, [1 x i64] }, ptr %l3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t86, { i64, [1 x i64] } %t87)
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb40:
  %t90 = load { i64, [1 x i64] }, ptr %l3
  %t92 = extractvalue { i64, [1 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb41, label %bb42
bb41:
  %t95 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t96 = getelementptr { i32 }, ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96
  store i32 %t97, ptr %l6, !tbaa !23
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/interp:Exec", ptr %t99, i32 0, i32 11
  %t102 = load i32, ptr %l6, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t101, i64 %t104)
  store i1 %t107, ptr %l59
  br label %bb44
bb44:
  %t108 = load i1, ptr %l59, !tbaa !21
  br i1 %t108, label %bb45, label %bb46
bb45:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/interp:Exec", ptr %t109, i32 0, i32 4
  %t112 = getelementptr %"compiler/eval:Machine", ptr %t111, i32 0, i32 13
  %t113 = load { i64, [1 x i64] }, ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t112, { i64, [1 x i64] } %t113, i1 true)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @.c61)
  unreachable
bb54:
  %t116 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ereach(ptr %v0, ptr %v0, ptr %s0, ptr %t116, ptr %l5, ptr %l2)
  br label %bb55
bb55:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/interp:Exec", ptr %t120, i32 0, i32 4
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v0, ptr %t122, ptr %l5)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb57:
  br label %bb4
bb58:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ePlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l17 = alloca i64
  %l22 = alloca %"compiler/scope:Scoper"
  %l26 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l61 = alloca ptr
  %l72 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i64
  %l77 = alloca %"compiler/typed:Plan"
  %s2 = alloca %olang.scope
  %t24 = alloca %"compiler/scope:Scoper", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l17
  br label %bb1
bb1:
  %t15 = load i64, ptr %l17, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/interp:Exec", ptr %t20, i32 0, i32 1
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t22
  call void @compiler_2fscope_3aScoper_2ector(ptr %t24, ptr %v0, ptr %v0, ptr %v0, ptr %t19, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t24, i64 992, i1 false)
  br label %bb2
bb2:
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %l22, i64 992, i1 false)
  store ptr %t27, ptr %l3, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %t29)
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRecordCount(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l26
  br label %bb4
bb4:
  %t34 = load i64, ptr %l26, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/interp:Exec", ptr %t35, i32 0, i32 1
  %t39 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l29
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 2
  %t44 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l32
  br label %bb6
bb6:
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t45, i64 %t46)
  store i64 %t47, ptr %l33
  br label %bb7
bb7:
  %t48 = load i64, ptr %l33, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp sgt i64 %t49, %t50
  br i1 %t53, label %bb8, label %bb9
bb8:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb13
bb10:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = sub i64 %t59, %t60
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = add i64 %t63, %t64
  %t69 = sub i64 %t67, 1
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = sdiv i64 %t69, %t70
  store i64 %t73, ptr %l40, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb12
bb12:
  %t75 = load i64, ptr %l40, !tbaa !24
  store i64 %t75, ptr %l37, !tbaa !24
  br label %bb13
bb13:
  %t76 = load i64, ptr %l37, !tbaa !24
  store i64 %t76, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = mul i64 %t86, %t87
  %t93 = add i64 %t85, %t90
  store i64 %t93, ptr %l10, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/interp:Exec", ptr %t95, i32 0, i32 1
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t97, i64 %t98)
  store ptr %t101, ptr %l61
  br label %bb18
bb18:
  %t102 = load ptr, ptr %l61, !tbaa !29
  store ptr %t102, ptr %l11, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t104 = load ptr, ptr %l11, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Body", ptr %t104, i32 0, i32 3
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load ptr, ptr %l11, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 4
  %t111 = getelementptr %"compiler/source:Span", ptr %t110, i32 0, i32 0
  %t112 = load i32, ptr %t111, !tbaa !23
  %t114 = sext i32 %t112 to i64
  %t115 = load ptr, ptr %l11, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Body", ptr %t115, i32 0, i32 4
  %t118 = getelementptr %"compiler/source:Span", ptr %t117, i32 0, i32 1
  %t119 = load i32, ptr %t118, !tbaa !23
  %t121 = sext i32 %t119 to i64
  %t122 = load i64, ptr %l4, !tbaa !24
  %t128 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %t103, i64 %t107, i64 %t114, i64 %t121, i64 %t122)
  store i1 %t128, ptr %l72
  br label %bb19
bb19:
  %t129 = load i1, ptr %l72, !tbaa !21
  br i1 %t129, label %bb20, label %bb21
bb20:
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 2
  store ptr %t132, ptr %l74, !tbaa !29
  %t133 = load i64, ptr %l10, !tbaa !24
  store i64 %t133, ptr %l75, !tbaa !24
  %t134 = load ptr, ptr %l11, !tbaa !29
  %t136 = call %"compiler/typed:Plan" @compiler_2ftyped_2eNewPlan(ptr %v0, ptr %v0, ptr %t134)
  store %"compiler/typed:Plan" %t136, ptr %l77
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t137 = load ptr, ptr %l74, !tbaa !29
  %t138 = load i64, ptr %l75, !tbaa !24
  %t139 = load %"compiler/typed:Plan", ptr %l77
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t137, i64 %t138, %"compiler/typed:Plan" %t139)
  br label %bb23
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l9, !tbaa !24
  br label %bb14
bb26:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t145 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t144, i64 %t145)
  br label %bb27
bb27:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t151 = getelementptr %"compiler/scope:Scoper", ptr %t149, i32 0, i32 2
  %t152 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t151
  %t155 = getelementptr %"compiler/interp:Exec", ptr %t148, i32 0, i32 3
  %t156 = getelementptr %"compiler/lower:Lowerer", ptr %t155, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %t156
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca { i64, [5 x i64] }
  %l6 = alloca { i64, [5 x i64] }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, %"compiler/source:Span" }
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l13 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l25 = alloca { i64, [5 x i64] }
  %l29 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l40 = alloca i64
  %l42 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i32
  %l51 = alloca i32
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %l65 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i64
  %l82 = alloca i64
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca %"compiler/source:Span"
  %l88 = alloca %"compiler/source:Span"
  %l90 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca { i64, [1 x i64] }
  %l97 = alloca { i64, [5 x i64] }
  %l107 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l127 = alloca i1
  %l130 = alloca { i64, %"compiler/source:Span" }
  %l138 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l152 = alloca i32
  %l154 = alloca i32
  %l156 = alloca i1
  %l159 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  %t17 = alloca { i64, [1 x i64] }, align 8
  %t32 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %s0, ptr %t1)
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l13
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t4, ptr %l2
  %t5 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l2, i32 0, i32 1
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @compiler_2finterp_2esayErr(ptr %s1, { i64, ptr } { i64 8, ptr @.d62 })
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb5:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = trunc i64 %t13 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t20 = insertvalue { i32 } undef, i32 %t15, 0
  %t21 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 1
  store { i32 } %t20, ptr %t21
  %t22 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t22, ptr %l4
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, [1 x i64] }, ptr %l4
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t24, { i64, [1 x i64] } %t25)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %s0, ptr %t28)
  store { i64, [5 x i64] } %t30, ptr %l25
  br label %bb7
bb7:
  %t31 = load { i64, [5 x i64] }, ptr %l25
  store { i64, [5 x i64] } %t31, ptr %l5
  store { i64, [5 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [5 x i64] }, ptr %t32
  store { i64, [5 x i64] } %t34, ptr %l6
  %t36 = load { i64, [5 x i64] }, ptr %l5
  %t38 = extractvalue { i64, [5 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load { i64, [5 x i64] }, ptr %l6
  %t43 = extractvalue { i64, [5 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 0
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb51
bb9:
  %t46 = load { i64, [5 x i64] }, ptr %l5
  %t48 = extractvalue { i64, [5 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb10, label %bb11
bb10:
  %t51 = load { i64, [5 x i64] }, ptr %l6
  %t53 = extractvalue { i64, [5 x i64] } %t51, 0
  %t54 = icmp eq i64 %t53, 1
  br i1 %t54, label %bb12, label %bb13
bb11:
  %t56 = load { i64, [5 x i64] }, ptr %l5
  %t58 = extractvalue { i64, [5 x i64] } %t56, 0
  %t59 = icmp eq i64 %t58, 2
  br i1 %t59, label %bb16, label %bb17
bb12:
  %t61 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t62 = getelementptr { i64 }, ptr %t61, i32 0, i32 0
  %t63 = load i64, ptr %t62
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t65 = getelementptr { i64 }, ptr %t64, i32 0, i32 0
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l40, !tbaa !24
  %t69 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l38, ptr %l40)
  store i1 %t69, ptr %l42
  br label %bb14
bb13:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb15
bb14:
  %t70 = load i1, ptr %l42, !tbaa !21
  store i1 %t70, ptr %l37, !tbaa !21
  br label %bb15
bb15:
  %t71 = load i1, ptr %l37, !tbaa !21
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb50
bb16:
  %t72 = load { i64, [5 x i64] }, ptr %l6
  %t74 = extractvalue { i64, [5 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 2
  br i1 %t75, label %bb18, label %bb19
bb17:
  %t77 = load { i64, [5 x i64] }, ptr %l5
  %t79 = extractvalue { i64, [5 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 3
  br i1 %t80, label %bb34, label %bb35
bb18:
  %t82 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t83 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l49
  %t85 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t86 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t85, i32 0, i32 0
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l51
  %t90 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l49, ptr %l51)
  store i1 %t90, ptr %l53
  br label %bb20
bb19:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb21
bb20:
  %t91 = load i1, ptr %l53, !tbaa !21
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l48, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t94 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t93, i32 0, i32 1
  %t95 = load i64, ptr %t94
  store i64 %t95, ptr %l55, !tbaa !24
  %t96 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t97 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t96, i32 0, i32 1
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l57, !tbaa !24
  %t101 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l55, ptr %l57)
  store i1 %t101, ptr %l59
  br label %bb24
bb23:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb25
bb24:
  %t102 = load i1, ptr %l59, !tbaa !21
  store i1 %t102, ptr %l54, !tbaa !21
  br label %bb25
bb25:
  %t103 = load i1, ptr %l54, !tbaa !21
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t104 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t105 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t104, i32 0, i32 2
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l61
  %t107 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t108 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t107, i32 0, i32 2
  %t109 = load %"compiler/source:Span", ptr %t108
  store %"compiler/source:Span" %t109, ptr %l63
  %t112 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l61, ptr %l63)
  store i1 %t112, ptr %l65
  br label %bb28
bb27:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb29
bb28:
  %t113 = load i1, ptr %l65, !tbaa !21
  store i1 %t113, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t114 = load i1, ptr %l60, !tbaa !21
  br i1 %t114, label %bb30, label %bb31
bb30:
  %t115 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t116 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t115, i32 0, i32 3
  %t117 = load { i64, ptr }, ptr %t116
  %t118 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t119 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t118, i32 0, i32 3
  %t120 = load { i64, ptr }, ptr %t119
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t117, { i64, ptr } %t120)
  store i1 %t123, ptr %l69
  br label %bb32
bb31:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb33
bb32:
  %t124 = load i1, ptr %l69, !tbaa !21
  store i1 %t124, ptr %l66, !tbaa !21
  br label %bb33
bb33:
  %t125 = load i1, ptr %l66, !tbaa !21
  store i1 %t125, ptr %l45, !tbaa !21
  br label %bb49
bb34:
  %t126 = load { i64, [5 x i64] }, ptr %l6
  %t128 = extractvalue { i64, [5 x i64] } %t126, 0
  %t129 = icmp eq i64 %t128, 3
  br i1 %t129, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb48
bb36:
  %t131 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t132 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t131, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132
  %t134 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t135 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t134, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t133, { i64, ptr } %t136)
  store i1 %t139, ptr %l78
  br label %bb38
bb37:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb39
bb38:
  %t140 = load i1, ptr %l78, !tbaa !21
  store i1 %t140, ptr %l75, !tbaa !21
  br label %bb39
bb39:
  %t141 = load i1, ptr %l75, !tbaa !21
  br i1 %t141, label %bb40, label %bb41
bb40:
  %t142 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t143 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t142, i32 0, i32 1
  %t144 = load i64, ptr %t143
  store i64 %t144, ptr %l80, !tbaa !24
  %t145 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t146 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t145, i32 0, i32 1
  %t147 = load i64, ptr %t146
  store i64 %t147, ptr %l82, !tbaa !24
  %t150 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l80, ptr %l82)
  store i1 %t150, ptr %l84
  br label %bb42
bb41:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb43
bb42:
  %t151 = load i1, ptr %l84, !tbaa !21
  store i1 %t151, ptr %l79, !tbaa !21
  br label %bb43
bb43:
  %t152 = load i1, ptr %l79, !tbaa !21
  br i1 %t152, label %bb44, label %bb45
bb44:
  %t153 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t154 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t153, i32 0, i32 2
  %t155 = load %"compiler/source:Span", ptr %t154
  store %"compiler/source:Span" %t155, ptr %l86
  %t156 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t157 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t156, i32 0, i32 2
  %t158 = load %"compiler/source:Span", ptr %t157
  store %"compiler/source:Span" %t158, ptr %l88
  %t161 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l86, ptr %l88)
  store i1 %t161, ptr %l90
  br label %bb46
bb45:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb47
bb46:
  %t162 = load i1, ptr %l90, !tbaa !21
  store i1 %t162, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t163 = load i1, ptr %l85, !tbaa !21
  store i1 %t163, ptr %l72, !tbaa !21
  br label %bb48
bb48:
  %t164 = load i1, ptr %l72, !tbaa !21
  store i1 %t164, ptr %l45, !tbaa !21
  br label %bb49
bb49:
  %t165 = load i1, ptr %l45, !tbaa !21
  store i1 %t165, ptr %l34, !tbaa !21
  br label %bb50
bb50:
  %t166 = load i1, ptr %l34, !tbaa !21
  store i1 %t166, ptr %l29, !tbaa !21
  br label %bb51
bb51:
  %t167 = load i1, ptr %l29, !tbaa !21
  br i1 %t167, label %bb52, label %bb53
bb52:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/interp:Exec", ptr %t168, i32 0, i32 4
  store ptr %t170, ptr %l92, !tbaa !29
  %t171 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t171, ptr %l93
  %t172 = icmp sge i64 0, 0
  br i1 %t172, label %bb54, label %bb55
bb53:
  br label %bb59
bb54:
  %t174 = icmp sle i64 0, 1152921504606846975
  br i1 %t174, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @.c63)
  unreachable
bb56:
  %t176 = mul i64 0, 8
  %t177 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 0, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t180 = load ptr, ptr %l92, !tbaa !29
  %t181 = load { i64, [1 x i64] }, ptr %l93
  %t183 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %s0, ptr %t180, { i64, [1 x i64] } %t181, { i64, ptr } %t179)
  store { i64, [5 x i64] } %t183, ptr %l97
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @.c63)
  unreachable
bb58:
  %t184 = load { i64, [5 x i64] }, ptr %l97
  store { i64, [5 x i64] } %t184, ptr %l5
  br label %bb59
bb59:
  %t185 = load { i64, [5 x i64] }, ptr %l5
  %t187 = extractvalue { i64, [5 x i64] } %t185, 0
  %t188 = icmp eq i64 %t187, 0
  br i1 %t188, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb63:
  %t191 = load { i64, [5 x i64] }, ptr %l5
  %t193 = extractvalue { i64, [5 x i64] } %t191, 0
  %t194 = icmp eq i64 %t193, 1
  br i1 %t194, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb71
bb66:
  store %olang.scope zeroinitializer, ptr %s4
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, [5 x i64] }, ptr %l5
  %t198 = load i64, ptr %l3, !tbaa !24
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t204 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s4, ptr %t196, { i64, [5 x i64] } %t197, i64 %t198, ptr %t199)
  store { i64, ptr } %t204, ptr %l107
  br label %bb67
bb67:
  %t205 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 0
  %t210 = add i64 %t207, %t209
  %t211 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t210)
  call void @olang_textcopy(ptr %t211, ptr %t206, i64 %t207)
  %t212 = getelementptr i8, ptr %t211, i64 %t207
  call void @olang_textcopy(ptr %t212, ptr %t208, i64 %t209)
  %t213 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t211, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = extractvalue { i64, ptr } %t214, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  call void @compiler_2finterp_2esayErr(ptr %s4, { i64, ptr } %t221)
  br label %bb68
bb68:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t227 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %s4, ptr %t223, ptr %t224)
  store { i64, ptr } %t227, ptr %l112
  br label %bb69
bb69:
  %t228 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  %t230 = extractvalue { i64, ptr } %t228, 1
  %t231 = mul i64 %t229, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  call void @compiler_2finterp_2esayErr(ptr %s4, { i64, ptr } %t234)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb71:
  %t237 = load { i64, [5 x i64] }, ptr %l5
  %t239 = extractvalue { i64, [5 x i64] } %t237, 0
  %t240 = icmp eq i64 %t239, 3
  br i1 %t240, label %bb72, label %bb73
bb72:
  %t242 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t243 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t242, i32 0, i32 0
  %t244 = load { i64, ptr }, ptr %t243
  store { i64, ptr } %t244, ptr %l7, !tbaa !27
  br label %bb74
bb73:
  br label %bb87
bb74:
  store %olang.scope zeroinitializer, ptr %s6
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load { i64, [5 x i64] }, ptr %l5
  %t248 = load i64, ptr %l3, !tbaa !24
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t254 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s6, ptr %t246, { i64, [5 x i64] } %t247, i64 %t248, ptr %t249)
  store { i64, ptr } %t254, ptr %l122
  br label %bb75
bb75:
  %t255 = extractvalue { i64, ptr } { i64 17, ptr @.d65 }, 1
  %t256 = extractvalue { i64, ptr } { i64 17, ptr @.d65 }, 0
  %t257 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 0
  %t263 = add i64 %t260, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t255, i64 %t256)
  %t265 = getelementptr i8, ptr %t264, i64 %t256
  call void @olang_textcopy(ptr %t265, ptr %t258, i64 %t259)
  %t266 = getelementptr i8, ptr %t265, i64 %t259
  call void @olang_textcopy(ptr %t266, ptr %t261, i64 %t262)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t264, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = extractvalue { i64, ptr } %t268, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  call void @compiler_2finterp_2esayErr(ptr %s6, { i64, ptr } %t275)
  br label %bb76
bb76:
  %t277 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t278 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t279 = load ptr, ptr @__olang_prog_scope
  %t282 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %t279, { i64, ptr } %t277, { i64, ptr } %t278)
  store i1 %t282, ptr %l127
  br label %bb77
bb77:
  %t283 = load i1, ptr %l127, !tbaa !21
  br i1 %t283, label %bb78, label %bb79
bb78:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/interp:Exec", ptr %t284, i32 0, i32 4
  %t288 = call { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %t286)
  store { i64, %"compiler/source:Span" } %t288, ptr %l130
  br label %bb80
bb79:
  br label %bb86
bb80:
  %t289 = load { i64, %"compiler/source:Span" }, ptr %l130
  store { i64, %"compiler/source:Span" } %t289, ptr %l8
  %t290 = getelementptr { i64, %"compiler/source:Span" }, ptr %l8, i32 0, i32 0
  %t291 = load i64, ptr %t290, !tbaa !24
  store i64 %t291, ptr %l9, !tbaa !24
  %t293 = getelementptr { i64, %"compiler/source:Span" }, ptr %l8, i32 0, i32 1
  %t294 = load %"compiler/source:Span", ptr %t293
  store %"compiler/source:Span" %t294, ptr %l10
  %t296 = load i64, ptr %l9, !tbaa !24
  %t298 = icmp sge i64 %t296, 0
  br i1 %t298, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s9
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t301 = load i64, ptr %l9, !tbaa !24
  %t302 = load %"compiler/source:Span", ptr %l10
  %t306 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s9, ptr %t300, i64 %t301, %"compiler/source:Span" %t302)
  store { i64, ptr } %t306, ptr %l138
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t307 = extractvalue { i64, ptr } { i64 17, ptr @.d67 }, 1
  %t308 = extractvalue { i64, ptr } { i64 17, ptr @.d67 }, 0
  %t309 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = add i64 %t308, %t311
  %t313 = extractvalue { i64, ptr } { i64 20, ptr @.d68 }, 1
  %t314 = extractvalue { i64, ptr } { i64 20, ptr @.d68 }, 0
  %t315 = add i64 %t312, %t314
  %t316 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t315)
  call void @olang_textcopy(ptr %t316, ptr %t307, i64 %t308)
  %t317 = getelementptr i8, ptr %t316, i64 %t308
  call void @olang_textcopy(ptr %t317, ptr %t310, i64 %t311)
  %t318 = getelementptr i8, ptr %t317, i64 %t311
  call void @olang_textcopy(ptr %t318, ptr %t313, i64 %t314)
  %t319 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t316, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  call void @compiler_2finterp_2esayErr(ptr %s9, { i64, ptr } %t327)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s9)
  br label %bb85
bb85:
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb87:
  %t330 = load { i64, [5 x i64] }, ptr %l5
  %t332 = extractvalue { i64, [5 x i64] } %t330, 0
  %t333 = icmp eq i64 %t332, 2
  br i1 %t333, label %bb88, label %bb89
bb88:
  %t335 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t336 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t335, i32 0, i32 0
  %t337 = load i32, ptr %t336
  store i32 %t337, ptr %l11
  br label %bb90
bb89:
  br label %bb99
bb90:
  store %olang.scope zeroinitializer, ptr %s11
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load { i64, [5 x i64] }, ptr %l5
  %t341 = load i64, ptr %l3, !tbaa !24
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t347 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s11, ptr %t339, { i64, [5 x i64] } %t340, i64 %t341, ptr %t342)
  store { i64, ptr } %t347, ptr %l149
  br label %bb91
bb91:
  %t348 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 1
  %t350 = extractvalue { i64, ptr } %t348, 0
  %t351 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 1
  %t352 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 0
  %t353 = add i64 %t350, %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t353)
  call void @olang_textcopy(ptr %t354, ptr %t349, i64 %t350)
  %t355 = getelementptr i8, ptr %t354, i64 %t350
  call void @olang_textcopy(ptr %t355, ptr %t351, i64 %t352)
  %t356 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t354, 1
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t360 = extractvalue { i64, ptr } %t357, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  call void @compiler_2finterp_2esayErr(ptr %s11, { i64, ptr } %t364)
  br label %bb92
bb92:
  %t366 = load i32, ptr %l11
  store i32 %t366, ptr %l152
  store i32 9, ptr %l154
  %t369 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l152, ptr %l154)
  store i1 %t369, ptr %l156
  br label %bb93
bb93:
  %t370 = load i1, ptr %l156, !tbaa !21
  br i1 %t370, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s13
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t375 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %s13, ptr %t371, ptr %t372)
  store { i64, ptr } %t375, ptr %l159
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t376 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 0
  %t378 = extractvalue { i64, ptr } %t376, 1
  %t379 = mul i64 %t377, 1
  %t380 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t380, ptr %t378, i64 %t379, i1 false)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  call void @compiler_2finterp_2esayErr(ptr %s13, { i64, ptr } %t382)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s13)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 134, ptr %rv
  br label %ret
bb99:
  br i1 true, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb105
bb102:
  store %olang.scope zeroinitializer, ptr %s14
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load { i64, [5 x i64] }, ptr %l5
  %t387 = load i64, ptr %l3, !tbaa !24
  %t388 = load ptr, ptr %l1, !tbaa !29
  %t393 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s14, ptr %t385, { i64, [5 x i64] } %t386, i64 %t387, ptr %t388)
  store { i64, ptr } %t393, ptr %l166
  br label %bb103
bb103:
  %t394 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 1
  %t398 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 0
  %t399 = add i64 %t396, %t398
  %t400 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t399)
  call void @olang_textcopy(ptr %t400, ptr %t395, i64 %t396)
  %t401 = getelementptr i8, ptr %t400, i64 %t396
  call void @olang_textcopy(ptr %t401, ptr %t397, i64 %t398)
  %t402 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t400, 1
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t406 = extractvalue { i64, ptr } %t403, 1
  %t407 = mul i64 %t405, 1
  %t408 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t407)
  call void @llvm.memcpy.p0.p0.i64(ptr %t408, ptr %t406, i64 %t407, i1 false)
  %t409 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t408, 1
  call void @compiler_2finterp_2esayErr(ptr %s14, { i64, ptr } %t410)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  store i32 134, ptr %rv
  br label %ret
bb105:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunTests(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca [0 x i64]
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, [5 x i64] }
  %l21 = alloca { i64, [5 x i64] }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l40 = alloca { i64, ptr }
  %l54 = alloca { i64, [5 x i64] }
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l70 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l84 = alloca { i64, [5 x i64] }
  %l88 = alloca i1
  %l93 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i64
  %l99 = alloca i64
  %l101 = alloca i1
  %l104 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i32
  %l110 = alloca i32
  %l112 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i64
  %l116 = alloca i64
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/source:Span"
  %l124 = alloca i1
  %l125 = alloca i1
  %l128 = alloca i1
  %l131 = alloca i1
  %l134 = alloca i1
  %l137 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i64
  %l141 = alloca i64
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca %"compiler/source:Span"
  %l147 = alloca %"compiler/source:Span"
  %l149 = alloca i1
  %l161 = alloca { i64, ptr }
  %l163 = alloca i1
  %l182 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  %t50 = alloca { i64, [1 x i64] }, align 8
  %t122 = alloca { i64, [1 x i64] }, align 8
  %t136 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %s0, ptr %t1)
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t3, ptr %l24
  br label %bb1
bb1:
  %t4 = load { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l24
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t4, ptr %l2
  %t5 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l2, i32 0, i32 0
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t9, i64 %t10)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l31
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb4, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l30
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t18, ptr %l27, !tbaa !27
  br label %bb8
bb4:
  %t19 = load i32, ptr %l31, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t24 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t24, ptr %l6, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t37, ptr %l40, !tbaa !27
  %t38 = load i64, ptr %l8, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i64, ptr %t41, i64 %t38
  %t43 = load i64, ptr %t42, !tbaa !34
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t48 = trunc i64 %t43 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [1 x i64] }, ptr %t50, i32 0, i32 0
  store i64 0, ptr %t51
  %t53 = insertvalue { i32 } undef, i32 %t48, 0
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t50, i32 0, i32 1
  store { i32 } %t53, ptr %t54
  %t55 = load { i64, [1 x i64] }, ptr %t50
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t45, { i64, [1 x i64] } %t55)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = add i64 %t62, %t63
  store i64 %t66, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb2
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %s0, ptr %t68)
  store { i64, [5 x i64] } %t70, ptr %l54
  br label %bb18
bb18:
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  store [0 x i64] zeroinitializer, ptr %l12
  store ptr %l3, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t73 = load ptr, ptr %l13, !tbaa !29
  %t74 = load i64, ptr %l14, !tbaa !24
  %t77 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t73, i64 %t74)
  %t78 = extractvalue { i32, { i64, ptr } } %t77, 1
  %t79 = extractvalue { i32, { i64, ptr } } %t77, 0
  store i32 %t79, ptr %l61
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb21, label %ok.81
ok.81:
  store { i64, ptr } %t78, ptr %l60
  br label %bb20
bb20:
  %t82 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t82, ptr %l57, !tbaa !27
  br label %bb25
bb21:
  %t83 = load i32, ptr %l61, !tbaa !23
  %t84 = ashr i32 %t83, 16
  %t86 = icmp eq i32 %t84, 1
  br i1 %t86, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @.c73)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb25:
  %t88 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t88, ptr %l15, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t93 = load i64, ptr %l17, !tbaa !24
  %t94 = load i64, ptr %l16, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb88
bb28:
  br label %bb29
bb29:
  %t101 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t101, ptr %l70, !tbaa !27
  %t102 = load i64, ptr %l17, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i64, ptr %t105, i64 %t102
  %t107 = load i64, ptr %t106, !tbaa !34
  store i64 %t107, ptr %l18, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i64, ptr %l18, !tbaa !24
  %t113 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTestName(ptr %v0, ptr %s7, ptr %t109, i64 %t110)
  store { i64, ptr } %t113, ptr %l75
  br label %bb30
bb30:
  %t114 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t114, ptr %l19, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/interp:Exec", ptr %t115, i32 0, i32 4
  %t118 = load i64, ptr %l18, !tbaa !24
  %t120 = trunc i64 %t118 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t122
  %t123 = getelementptr { i64, [1 x i64] }, ptr %t122, i32 0, i32 0
  store i64 0, ptr %t123
  %t125 = insertvalue { i32 } undef, i32 %t120, 0
  %t126 = getelementptr { i64, [1 x i64] }, ptr %t122, i32 0, i32 1
  store { i32 } %t125, ptr %t126
  %t127 = load { i64, [1 x i64] }, ptr %t122
  %t129 = insertvalue { i64, ptr } undef, i64 0, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %l12, 1
  %t134 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %v0, ptr %t117, { i64, [1 x i64] } %t127, { i64, ptr } %t130)
  store { i64, [5 x i64] } %t134, ptr %l84
  br label %bb31
bb31:
  %t135 = load { i64, [5 x i64] }, ptr %l84
  store { i64, [5 x i64] } %t135, ptr %l20
  store { i64, [5 x i64] } zeroinitializer, ptr %t136
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t136, i32 0, i32 0
  store i64 0, ptr %t137
  %t138 = load { i64, [5 x i64] }, ptr %t136
  store { i64, [5 x i64] } %t138, ptr %l21
  %t140 = load { i64, [5 x i64] }, ptr %l20
  %t142 = extractvalue { i64, [5 x i64] } %t140, 0
  %t143 = icmp eq i64 %t142, 0
  br i1 %t143, label %bb32, label %bb33
bb32:
  %t145 = load { i64, [5 x i64] }, ptr %l21
  %t147 = extractvalue { i64, [5 x i64] } %t145, 0
  %t148 = icmp eq i64 %t147, 0
  store i1 %t148, ptr %l88, !tbaa !21
  br label %bb75
bb33:
  %t150 = load { i64, [5 x i64] }, ptr %l20
  %t152 = extractvalue { i64, [5 x i64] } %t150, 0
  %t153 = icmp eq i64 %t152, 1
  br i1 %t153, label %bb34, label %bb35
bb34:
  %t155 = load { i64, [5 x i64] }, ptr %l21
  %t157 = extractvalue { i64, [5 x i64] } %t155, 0
  %t158 = icmp eq i64 %t157, 1
  br i1 %t158, label %bb36, label %bb37
bb35:
  %t160 = load { i64, [5 x i64] }, ptr %l20
  %t162 = extractvalue { i64, [5 x i64] } %t160, 0
  %t163 = icmp eq i64 %t162, 2
  br i1 %t163, label %bb40, label %bb41
bb36:
  %t165 = getelementptr { i64, [5 x i64] }, ptr %l20, i32 0, i32 1
  %t166 = getelementptr { i64 }, ptr %t165, i32 0, i32 0
  %t167 = load i64, ptr %t166
  store i64 %t167, ptr %l97, !tbaa !24
  %t168 = getelementptr { i64, [5 x i64] }, ptr %l21, i32 0, i32 1
  %t169 = getelementptr { i64 }, ptr %t168, i32 0, i32 0
  %t170 = load i64, ptr %t169
  store i64 %t170, ptr %l99, !tbaa !24
  %t173 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l97, ptr %l99)
  store i1 %t173, ptr %l101
  br label %bb38
bb37:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb39
bb38:
  %t174 = load i1, ptr %l101, !tbaa !21
  store i1 %t174, ptr %l96, !tbaa !21
  br label %bb39
bb39:
  %t175 = load i1, ptr %l96, !tbaa !21
  store i1 %t175, ptr %l93, !tbaa !21
  br label %bb74
bb40:
  %t176 = load { i64, [5 x i64] }, ptr %l21
  %t178 = extractvalue { i64, [5 x i64] } %t176, 0
  %t179 = icmp eq i64 %t178, 2
  br i1 %t179, label %bb42, label %bb43
bb41:
  %t181 = load { i64, [5 x i64] }, ptr %l20
  %t183 = extractvalue { i64, [5 x i64] } %t181, 0
  %t184 = icmp eq i64 %t183, 3
  br i1 %t184, label %bb58, label %bb59
bb42:
  %t186 = getelementptr { i64, [5 x i64] }, ptr %l20, i32 0, i32 1
  %t187 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t186, i32 0, i32 0
  %t188 = load i32, ptr %t187
  store i32 %t188, ptr %l108
  %t189 = getelementptr { i64, [5 x i64] }, ptr %l21, i32 0, i32 1
  %t190 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t189, i32 0, i32 0
  %t191 = load i32, ptr %t190
  store i32 %t191, ptr %l110
  %t194 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l108, ptr %l110)
  store i1 %t194, ptr %l112
  br label %bb44
bb43:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb45
bb44:
  %t195 = load i1, ptr %l112, !tbaa !21
  store i1 %t195, ptr %l107, !tbaa !21
  br label %bb45
bb45:
  %t196 = load i1, ptr %l107, !tbaa !21
  br i1 %t196, label %bb46, label %bb47
bb46:
  %t197 = getelementptr { i64, [5 x i64] }, ptr %l20, i32 0, i32 1
  %t198 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t197, i32 0, i32 1
  %t199 = load i64, ptr %t198
  store i64 %t199, ptr %l114, !tbaa !24
  %t200 = getelementptr { i64, [5 x i64] }, ptr %l21, i32 0, i32 1
  %t201 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t200, i32 0, i32 1
  %t202 = load i64, ptr %t201
  store i64 %t202, ptr %l116, !tbaa !24
  %t205 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l114, ptr %l116)
  store i1 %t205, ptr %l118
  br label %bb48
bb47:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb49
bb48:
  %t206 = load i1, ptr %l118, !tbaa !21
  store i1 %t206, ptr %l113, !tbaa !21
  br label %bb49
bb49:
  %t207 = load i1, ptr %l113, !tbaa !21
  br i1 %t207, label %bb50, label %bb51
bb50:
  %t208 = getelementptr { i64, [5 x i64] }, ptr %l20, i32 0, i32 1
  %t209 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t208, i32 0, i32 2
  %t210 = load %"compiler/source:Span", ptr %t209
  store %"compiler/source:Span" %t210, ptr %l120
  %t211 = getelementptr { i64, [5 x i64] }, ptr %l21, i32 0, i32 1
  %t212 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t211, i32 0, i32 2
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l122
  %t216 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l120, ptr %l122)
  store i1 %t216, ptr %l124
  br label %bb52
bb51:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb53
bb52:
  %t217 = load i1, ptr %l124, !tbaa !21
  store i1 %t217, ptr %l119, !tbaa !21
  br label %bb53
bb53:
  %t218 = load i1, ptr %l119, !tbaa !21
  br i1 %t218, label %bb54, label %bb55
bb54:
  %t219 = getelementptr { i64, [5 x i64] }, ptr %l20, i32 0, i32 1
  %t220 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t219, i32 0, i32 3
  %t221 = load { i64, ptr }, ptr %t220
  %t222 = getelementptr { i64, [5 x i64] }, ptr %l21, i32 0, i32 1
  %t223 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t222, i32 0, i32 3
  %t224 = load { i64, ptr }, ptr %t223
  %t227 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t221, { i64, ptr } %t224)
  store i1 %t227, ptr %l128
  br label %bb56
bb55:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb57
bb56:
  %t228 = load i1, ptr %l128, !tbaa !21
  store i1 %t228, ptr %l125, !tbaa !21
  br label %bb57
bb57:
  %t229 = load i1, ptr %l125, !tbaa !21
  store i1 %t229, ptr %l104, !tbaa !21
  br label %bb73
bb58:
  %t230 = load { i64, [5 x i64] }, ptr %l21
  %t232 = extractvalue { i64, [5 x i64] } %t230, 0
  %t233 = icmp eq i64 %t232, 3
  br i1 %t233, label %bb60, label %bb61
bb59:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb72
bb60:
  %t235 = getelementptr { i64, [5 x i64] }, ptr %l20, i32 0, i32 1
  %t236 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t235, i32 0, i32 0
  %t237 = load { i64, ptr }, ptr %t236
  %t238 = getelementptr { i64, [5 x i64] }, ptr %l21, i32 0, i32 1
  %t239 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t238, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239
  %t243 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t237, { i64, ptr } %t240)
  store i1 %t243, ptr %l137
  br label %bb62
bb61:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb63
bb62:
  %t244 = load i1, ptr %l137, !tbaa !21
  store i1 %t244, ptr %l134, !tbaa !21
  br label %bb63
bb63:
  %t245 = load i1, ptr %l134, !tbaa !21
  br i1 %t245, label %bb64, label %bb65
bb64:
  %t246 = getelementptr { i64, [5 x i64] }, ptr %l20, i32 0, i32 1
  %t247 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t246, i32 0, i32 1
  %t248 = load i64, ptr %t247
  store i64 %t248, ptr %l139, !tbaa !24
  %t249 = getelementptr { i64, [5 x i64] }, ptr %l21, i32 0, i32 1
  %t250 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t249, i32 0, i32 1
  %t251 = load i64, ptr %t250
  store i64 %t251, ptr %l141, !tbaa !24
  %t254 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l139, ptr %l141)
  store i1 %t254, ptr %l143
  br label %bb66
bb65:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb67
bb66:
  %t255 = load i1, ptr %l143, !tbaa !21
  store i1 %t255, ptr %l138, !tbaa !21
  br label %bb67
bb67:
  %t256 = load i1, ptr %l138, !tbaa !21
  br i1 %t256, label %bb68, label %bb69
bb68:
  %t257 = getelementptr { i64, [5 x i64] }, ptr %l20, i32 0, i32 1
  %t258 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t257, i32 0, i32 2
  %t259 = load %"compiler/source:Span", ptr %t258
  store %"compiler/source:Span" %t259, ptr %l145
  %t260 = getelementptr { i64, [5 x i64] }, ptr %l21, i32 0, i32 1
  %t261 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t260, i32 0, i32 2
  %t262 = load %"compiler/source:Span", ptr %t261
  store %"compiler/source:Span" %t262, ptr %l147
  %t265 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l145, ptr %l147)
  store i1 %t265, ptr %l149
  br label %bb70
bb69:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb71
bb70:
  %t266 = load i1, ptr %l149, !tbaa !21
  store i1 %t266, ptr %l144, !tbaa !21
  br label %bb71
bb71:
  %t267 = load i1, ptr %l144, !tbaa !21
  store i1 %t267, ptr %l131, !tbaa !21
  br label %bb72
bb72:
  %t268 = load i1, ptr %l131, !tbaa !21
  store i1 %t268, ptr %l104, !tbaa !21
  br label %bb73
bb73:
  %t269 = load i1, ptr %l104, !tbaa !21
  store i1 %t269, ptr %l93, !tbaa !21
  br label %bb74
bb74:
  %t270 = load i1, ptr %l93, !tbaa !21
  store i1 %t270, ptr %l88, !tbaa !21
  br label %bb75
bb75:
  %t271 = load i1, ptr %l88, !tbaa !21
  br i1 %t271, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s8
  %t272 = load i64, ptr %l10, !tbaa !24
  %t274 = add i64 %t272, 1
  store i64 %t274, ptr %l10, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t277 = extractvalue { i64, ptr } { i64 5, ptr @.d74 }, 1
  %t278 = extractvalue { i64, ptr } { i64 5, ptr @.d74 }, 0
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = extractvalue { i64, ptr } %t276, 0
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 1
  %t284 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 0
  %t285 = add i64 %t282, %t284
  %t286 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  call void @olang_textcopy(ptr %t287, ptr %t280, i64 %t281)
  %t288 = getelementptr i8, ptr %t287, i64 %t281
  call void @olang_textcopy(ptr %t288, ptr %t283, i64 %t284)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t286, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = extractvalue { i64, ptr } %t290, 1
  %t294 = mul i64 %t292, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  call void @compiler_2finterp_2esay(ptr %s8, { i64, ptr } %t297)
  br label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s10
  %t299 = load i64, ptr %l11, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l11, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load { i64, [5 x i64] }, ptr %l20
  %t305 = load i64, ptr %l18, !tbaa !24
  %t311 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %v0, ptr %v1, ptr %s10, ptr %t303, { i64, [5 x i64] } %t304, i64 %t305, ptr %a1)
  store { i64, ptr } %t311, ptr %l161
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s8)
  br label %bb86
bb79:
  %t312 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t312, ptr %l22, !tbaa !27
  %t313 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t315 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t313, { i64, ptr } { i64 0, ptr @.d76 })
  store i1 %t315, ptr %l163
  br label %bb80
bb80:
  %t316 = load i1, ptr %l163, !tbaa !21
  %t317 = xor i1 %t316, true
  br i1 %t317, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s11
  %t319 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 1
  %t322 = extractvalue { i64, ptr } %t319, 0
  %t323 = extractvalue { i64, ptr } { i64 1, ptr @.d77 }, 1
  %t324 = extractvalue { i64, ptr } { i64 1, ptr @.d77 }, 0
  %t325 = add i64 %t322, %t324
  %t326 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t325)
  call void @olang_textcopy(ptr %t326, ptr %t321, i64 %t322)
  %t327 = getelementptr i8, ptr %t326, i64 %t322
  call void @olang_textcopy(ptr %t327, ptr %t323, i64 %t324)
  %t328 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t326, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = extractvalue { i64, ptr } %t329, 1
  %t333 = mul i64 %t331, 1
  %t334 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t334, ptr %t332, i64 %t333, i1 false)
  %t335 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  call void @compiler_2finterp_2esay(ptr %s11, { i64, ptr } %t336)
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s11)
  br label %bb84
bb84:
  %t338 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t339 = extractvalue { i64, ptr } { i64 7, ptr @.d78 }, 1
  %t340 = extractvalue { i64, ptr } { i64 7, ptr @.d78 }, 0
  %t342 = extractvalue { i64, ptr } %t338, 1
  %t343 = extractvalue { i64, ptr } %t338, 0
  %t344 = add i64 %t340, %t343
  %t345 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 1
  %t346 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 0
  %t347 = add i64 %t344, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t339, i64 %t340)
  %t349 = getelementptr i8, ptr %t348, i64 %t340
  call void @olang_textcopy(ptr %t349, ptr %t342, i64 %t343)
  %t350 = getelementptr i8, ptr %t349, i64 %t343
  call void @olang_textcopy(ptr %t350, ptr %t345, i64 %t346)
  %t351 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t348, 1
  %t354 = extractvalue { i64, ptr } %t352, 0
  %t355 = extractvalue { i64, ptr } %t352, 1
  %t356 = mul i64 %t354, 1
  %t357 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t357, ptr %t355, i64 %t356, i1 false)
  %t358 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  call void @compiler_2finterp_2esay(ptr %s10, { i64, ptr } %t359)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s10)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s7)
  br label %bb87
bb87:
  %t361 = load i64, ptr %l17, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l17, !tbaa !24
  br label %bb26
bb88:
  %t365 = load i64, ptr %l14, !tbaa !24
  %t366 = load i64, ptr %l16, !tbaa !24
  %t369 = add i64 %t365, %t366
  store i64 %t369, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb89
bb89:
  br label %bb19
bb90:
  %t371 = load i64, ptr %l10, !tbaa !24
  %t372 = load i64, ptr %l11, !tbaa !24
  %t374 = call i64 @__olang_fmt_i64(ptr null, i64 %t371)
  %t375 = extractvalue { i64, ptr } { i64 9, ptr @.d80 }, 1
  %t376 = extractvalue { i64, ptr } { i64 9, ptr @.d80 }, 0
  %t377 = add i64 %t374, %t376
  %t379 = call i64 @__olang_fmt_i64(ptr null, i64 %t372)
  %t380 = add i64 %t377, %t379
  %t381 = extractvalue { i64, ptr } { i64 8, ptr @.d81 }, 1
  %t382 = extractvalue { i64, ptr } { i64 8, ptr @.d81 }, 0
  %t383 = add i64 %t380, %t382
  %t384 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t383)
  %t385 = call i64 @__olang_fmt_i64(ptr %t384, i64 %t371)
  %t386 = getelementptr i8, ptr %t384, i64 %t374
  call void @olang_textcopy(ptr %t386, ptr %t375, i64 %t376)
  %t387 = getelementptr i8, ptr %t386, i64 %t376
  %t388 = call i64 @__olang_fmt_i64(ptr %t387, i64 %t372)
  %t389 = getelementptr i8, ptr %t387, i64 %t379
  call void @olang_textcopy(ptr %t389, ptr %t381, i64 %t382)
  %t390 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t384, 1
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t394 = extractvalue { i64, ptr } %t391, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  call void @compiler_2finterp_2esay(ptr %s0, { i64, ptr } %t398)
  br label %bb91
bb91:
  %t400 = load i64, ptr %l11, !tbaa !24
  %t402 = icmp sgt i64 %t400, 0
  br i1 %t402, label %bb92, label %bb93
bb92:
  store i32 1, ptr %l182, !tbaa !23
  br label %bb94
bb93:
  store i32 0, ptr %l182, !tbaa !23
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s0)
  %t404 = load i32, ptr %l182, !tbaa !23
  store i32 %t404, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [5 x i64] } %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [5 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l31 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [5 x i64] } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb6
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/interp:Exec", ptr %t12, i32 0, i32 1
  %t18 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t14, i64 %a2)
  store ptr %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t23 = load ptr, ptr %l9, !tbaa !29
  %t24 = load i64, ptr %l10, !tbaa !24
  %t26 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eerrorName(ptr %v0, ptr %s1, ptr %t23, i64 %t24, i32 %t22)
  store { i64, ptr } %t26, ptr %l17
  br label %bb5
bb5:
  %t27 = extractvalue { i64, ptr } { i64 17, ptr @.d82 }, 1
  %t28 = extractvalue { i64, ptr } { i64 17, ptr @.d82 }, 0
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t27, i64 %t28)
  %t34 = getelementptr i8, ptr %t33, i64 %t28
  call void @olang_textcopy(ptr %t34, ptr %t30, i64 %t31)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb6:
  %t38 = load { i64, [5 x i64] }, ptr %l1
  %t40 = extractvalue { i64, [5 x i64] } %t38, 0
  %t41 = icmp eq i64 %t40, 3
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t44 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t43, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  br label %bb9
bb8:
  br label %bb20
bb9:
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWaits, !tbaa !27
  %t49 = load ptr, ptr @__olang_prog_scope
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %t49, { i64, ptr } %t47, { i64, ptr } %t48)
  store i1 %t52, ptr %l24
  br label %bb10
bb10:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 4
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 68
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = icmp sge i64 %t58, 0
  store i1 %t60, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l25, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load { i64, [5 x i64] }, ptr %l1
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %s4, { i64, [5 x i64] } %t63, ptr %t64)
  store { i64, ptr } %t67, ptr %l31
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t69, i32 0, i32 4
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 68
  %t73 = load i64, ptr %t72, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/interp:Exec", ptr %t74, i32 0, i32 4
  %t77 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 69
  %t78 = load %"compiler/source:Span", ptr %t77
  %t82 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v2, ptr %s4, ptr %t68, i64 %t73, %"compiler/source:Span" %t78)
  store { i64, ptr } %t82, ptr %l37
  br label %bb17
bb17:
  %t83 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } { i64 31, ptr @.d83 }, 1
  %t87 = extractvalue { i64, ptr } { i64 31, ptr @.d83 }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t84, i64 %t85)
  %t94 = getelementptr i8, ptr %t93, i64 %t85
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = getelementptr i8, ptr %t94, i64 %t87
  call void @olang_textcopy(ptr %t95, ptr %t90, i64 %t91)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb18:
  %t99 = load { i64, [5 x i64] }, ptr %l1
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t103 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %v3, { i64, [5 x i64] } %t99, ptr %t100)
  store { i64, ptr } %t103, ptr %l41
  br label %bb19
bb19:
  %t104 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t105 = load { i64, [5 x i64] }, ptr %l1
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t109 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %v3, { i64, [5 x i64] } %t105, ptr %t106)
  store { i64, ptr } %t109, ptr %l44
  br label %bb24
bb24:
  %t110 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @.c84)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTestName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/interp:Exec", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t9, i64 %t19)
  store ptr %t22, ptr %l13
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l13, !tbaa !29
  store ptr %t23, ptr %l2, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 8
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/interp:Exec", ptr %t28, i32 0, i32 1
  %t34 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t30, i64 %a1)
  store ptr %t34, ptr %l19
  br label %bb2
bb2:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 4
  %t38 = load %"compiler/source:Span", ptr %t37
  %t39 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t41 = call %"compiler/source:Span" @compiler_2finterp_2efindTest(ptr %v0, { i64, ptr } %t39, %"compiler/source:Span" %t38)
  store %"compiler/source:Span" %t41, ptr %l22
  br label %bb3
bb3:
  %t42 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t42, ptr %l3
  %t43 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp eq i32 %t44, 0
  br i1 %t46, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 4, ptr @.d85 }, ptr %l25, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l27, !tbaa !24
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l28, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l27, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t62, ptr %l26, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 6
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l3
  %t71 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %t67, %"compiler/source:Span" %t68)
  store { i64, ptr } %t71, ptr %l32
  br label %bb7
bb7:
  %t72 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t72, ptr %l4, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t77 = icmp sge i64 %t75, 2
  br i1 %t77, label %bb8, label %bb9
bb8:
  %t79 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t79, ptr %l37, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 0
  %t83 = load i8, ptr %t82, !tbaa !32
  %t85 = icmp eq i8 %t83, 34
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t87 = load i1, ptr %l36, !tbaa !21
  br i1 %t87, label %bb11, label %bb12
bb11:
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t88, ptr %l40, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t93 = sub i64 %t91, 1
  store i64 %t93, ptr %l43, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l44, !tbaa !24
  %t96 = icmp sge i64 1, 0
  br i1 %t96, label %bb13, label %bb14
bb12:
  br label %bb19
bb13:
  %t98 = load i64, ptr %l43, !tbaa !24
  %t99 = icmp sle i64 1, %t98
  br i1 %t99, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c86)
  unreachable
bb15:
  %t101 = load i64, ptr %l43, !tbaa !24
  %t102 = load i64, ptr %l44, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  br i1 %t103, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c86)
  unreachable
bb17:
  %t105 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l43, !tbaa !24
  %t108 = getelementptr i8, ptr %t106, i64 1
  %t109 = sub i64 %t107, 1
  %t110 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = extractvalue { i64, ptr } %t111, 0
  %t115 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t113, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @.c86)
  unreachable
bb19:
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = extractvalue { i64, ptr } %t119, 0
  %t123 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t121, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca { i64, [5 x i64] }
  %l4 = alloca { i64, [5 x i64] }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { { i64, ptr }, i1 }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca { i64, [1 x i64] }
  %l25 = alloca { i64, [5 x i64] }
  %l29 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l40 = alloca i64
  %l42 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i32
  %l51 = alloca i32
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %l65 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i64
  %l82 = alloca i64
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca %"compiler/source:Span"
  %l88 = alloca %"compiler/source:Span"
  %l90 = alloca i1
  %l92 = alloca { i64, ptr }
  %l94 = alloca { { i64, ptr }, i1 }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i1 }
  %t31 = alloca { i64, [1 x i64] }, align 8
  %t59 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr @.d87 }, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t7 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t5, 0
  %t8 = insertvalue { { i64, ptr }, i1 } %t7, i1 false, 1
  store { { i64, ptr }, i1 } %t8, ptr %l9
  %t9 = getelementptr { { i64, ptr }, i1 }, ptr %l9, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l10, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l11, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t25 = getelementptr { { i64, ptr }, i1 }, ptr %l9, i32 0, i32 0
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { { i64, ptr }, i1 }, ptr %l9
  store { { i64, ptr }, i1 } %t26, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t27 = load i64, ptr %l1, !tbaa !24
  %t29 = trunc i64 %t27 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [1 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t34 = insertvalue { i32 } undef, i32 %t29, 0
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t31, i32 0, i32 1
  store { i32 } %t34, ptr %t35
  %t36 = load { i64, [1 x i64] }, ptr %t31
  store { i64, [1 x i64] } %t36, ptr %l2
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t38, { i64, [1 x i64] } %t39)
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/interp:Exec", ptr %t42, i32 0, i32 4
  store ptr %t44, ptr %l20, !tbaa !29
  %t45 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t45, ptr %l21
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb5, label %bb6
bb5:
  %t48 = icmp sle i64 0, 1152921504606846975
  br i1 %t48, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb7:
  %t50 = mul i64 0, 8
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 0, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t54 = load ptr, ptr %l20, !tbaa !29
  %t55 = load { i64, [1 x i64] }, ptr %l21
  %t57 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t54, { i64, [1 x i64] } %t55, { i64, ptr } %t53)
  store { i64, [5 x i64] } %t57, ptr %l25
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb9:
  %t58 = load { i64, [5 x i64] }, ptr %l25
  store { i64, [5 x i64] } %t58, ptr %l3
  store { i64, [5 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 0
  store i64 0, ptr %t60
  %t61 = load { i64, [5 x i64] }, ptr %t59
  store { i64, [5 x i64] } %t61, ptr %l4
  %t63 = load { i64, [5 x i64] }, ptr %l3
  %t65 = extractvalue { i64, [5 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 0
  br i1 %t66, label %bb10, label %bb11
bb10:
  %t68 = load { i64, [5 x i64] }, ptr %l4
  %t70 = extractvalue { i64, [5 x i64] } %t68, 0
  %t71 = icmp eq i64 %t70, 0
  store i1 %t71, ptr %l29, !tbaa !21
  br label %bb53
bb11:
  %t73 = load { i64, [5 x i64] }, ptr %l3
  %t75 = extractvalue { i64, [5 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 1
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = load { i64, [5 x i64] }, ptr %l4
  %t80 = extractvalue { i64, [5 x i64] } %t78, 0
  %t81 = icmp eq i64 %t80, 1
  br i1 %t81, label %bb14, label %bb15
bb13:
  %t83 = load { i64, [5 x i64] }, ptr %l3
  %t85 = extractvalue { i64, [5 x i64] } %t83, 0
  %t86 = icmp eq i64 %t85, 2
  br i1 %t86, label %bb18, label %bb19
bb14:
  %t88 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t89 = getelementptr { i64 }, ptr %t88, i32 0, i32 0
  %t90 = load i64, ptr %t89
  store i64 %t90, ptr %l38, !tbaa !24
  %t91 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t92 = getelementptr { i64 }, ptr %t91, i32 0, i32 0
  %t93 = load i64, ptr %t92
  store i64 %t93, ptr %l40, !tbaa !24
  %t96 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l38, ptr %l40)
  store i1 %t96, ptr %l42
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  %t97 = load i1, ptr %l42, !tbaa !21
  store i1 %t97, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t98 = load i1, ptr %l37, !tbaa !21
  store i1 %t98, ptr %l34, !tbaa !21
  br label %bb52
bb18:
  %t99 = load { i64, [5 x i64] }, ptr %l4
  %t101 = extractvalue { i64, [5 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 2
  br i1 %t102, label %bb20, label %bb21
bb19:
  %t104 = load { i64, [5 x i64] }, ptr %l3
  %t106 = extractvalue { i64, [5 x i64] } %t104, 0
  %t107 = icmp eq i64 %t106, 3
  br i1 %t107, label %bb36, label %bb37
bb20:
  %t109 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t110 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t109, i32 0, i32 0
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l49
  %t112 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t113 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t112, i32 0, i32 0
  %t114 = load i32, ptr %t113
  store i32 %t114, ptr %l51
  %t117 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l49, ptr %l51)
  store i1 %t117, ptr %l53
  br label %bb22
bb21:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb23
bb22:
  %t118 = load i1, ptr %l53, !tbaa !21
  store i1 %t118, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t119 = load i1, ptr %l48, !tbaa !21
  br i1 %t119, label %bb24, label %bb25
bb24:
  %t120 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t121 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t120, i32 0, i32 1
  %t122 = load i64, ptr %t121
  store i64 %t122, ptr %l55, !tbaa !24
  %t123 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t124 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load i64, ptr %t124
  store i64 %t125, ptr %l57, !tbaa !24
  %t128 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l55, ptr %l57)
  store i1 %t128, ptr %l59
  br label %bb26
bb25:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb27
bb26:
  %t129 = load i1, ptr %l59, !tbaa !21
  store i1 %t129, ptr %l54, !tbaa !21
  br label %bb27
bb27:
  %t130 = load i1, ptr %l54, !tbaa !21
  br i1 %t130, label %bb28, label %bb29
bb28:
  %t131 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t132 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t131, i32 0, i32 2
  %t133 = load %"compiler/source:Span", ptr %t132
  store %"compiler/source:Span" %t133, ptr %l61
  %t134 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t135 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t134, i32 0, i32 2
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l63
  %t139 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l61, ptr %l63)
  store i1 %t139, ptr %l65
  br label %bb30
bb29:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb31
bb30:
  %t140 = load i1, ptr %l65, !tbaa !21
  store i1 %t140, ptr %l60, !tbaa !21
  br label %bb31
bb31:
  %t141 = load i1, ptr %l60, !tbaa !21
  br i1 %t141, label %bb32, label %bb33
bb32:
  %t142 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t143 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t142, i32 0, i32 3
  %t144 = load { i64, ptr }, ptr %t143
  %t145 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t146 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t145, i32 0, i32 3
  %t147 = load { i64, ptr }, ptr %t146
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t144, { i64, ptr } %t147)
  store i1 %t150, ptr %l69
  br label %bb34
bb33:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb35
bb34:
  %t151 = load i1, ptr %l69, !tbaa !21
  store i1 %t151, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t152 = load i1, ptr %l66, !tbaa !21
  store i1 %t152, ptr %l45, !tbaa !21
  br label %bb51
bb36:
  %t153 = load { i64, [5 x i64] }, ptr %l4
  %t155 = extractvalue { i64, [5 x i64] } %t153, 0
  %t156 = icmp eq i64 %t155, 3
  br i1 %t156, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb50
bb38:
  %t158 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t159 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t158, i32 0, i32 0
  %t160 = load { i64, ptr }, ptr %t159
  %t161 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t162 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t161, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t160, { i64, ptr } %t163)
  store i1 %t166, ptr %l78
  br label %bb40
bb39:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb41
bb40:
  %t167 = load i1, ptr %l78, !tbaa !21
  store i1 %t167, ptr %l75, !tbaa !21
  br label %bb41
bb41:
  %t168 = load i1, ptr %l75, !tbaa !21
  br i1 %t168, label %bb42, label %bb43
bb42:
  %t169 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t170 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t169, i32 0, i32 1
  %t171 = load i64, ptr %t170
  store i64 %t171, ptr %l80, !tbaa !24
  %t172 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t173 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t172, i32 0, i32 1
  %t174 = load i64, ptr %t173
  store i64 %t174, ptr %l82, !tbaa !24
  %t177 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %l80, ptr %l82)
  store i1 %t177, ptr %l84
  br label %bb44
bb43:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  %t178 = load i1, ptr %l84, !tbaa !21
  store i1 %t178, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t179 = load i1, ptr %l79, !tbaa !21
  br i1 %t179, label %bb46, label %bb47
bb46:
  %t180 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t180, i32 0, i32 2
  %t182 = load %"compiler/source:Span", ptr %t181
  store %"compiler/source:Span" %t182, ptr %l86
  %t183 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t184 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t183, i32 0, i32 2
  %t185 = load %"compiler/source:Span", ptr %t184
  store %"compiler/source:Span" %t185, ptr %l88
  %t188 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l86, ptr %l88)
  store i1 %t188, ptr %l90
  br label %bb48
bb47:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb49
bb48:
  %t189 = load i1, ptr %l90, !tbaa !21
  store i1 %t189, ptr %l85, !tbaa !21
  br label %bb49
bb49:
  %t190 = load i1, ptr %l85, !tbaa !21
  store i1 %t190, ptr %l72, !tbaa !21
  br label %bb50
bb50:
  %t191 = load i1, ptr %l72, !tbaa !21
  store i1 %t191, ptr %l45, !tbaa !21
  br label %bb51
bb51:
  %t192 = load i1, ptr %l45, !tbaa !21
  store i1 %t192, ptr %l34, !tbaa !21
  br label %bb52
bb52:
  %t193 = load i1, ptr %l34, !tbaa !21
  store i1 %t193, ptr %l29, !tbaa !21
  br label %bb53
bb53:
  %t194 = load i1, ptr %l29, !tbaa !21
  %t195 = xor i1 %t194, true
  br i1 %t195, label %bb54, label %bb55
bb54:
  store { i64, ptr } { i64 0, ptr @.d89 }, ptr %l92, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t199 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t197, 0
  %t200 = insertvalue { { i64, ptr }, i1 } %t199, i1 false, 1
  store { { i64, ptr }, i1 } %t200, ptr %l94
  %t201 = getelementptr { { i64, ptr }, i1 }, ptr %l94, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l95, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  store i64 %t204, ptr %l96, !tbaa !24
  %t205 = load i64, ptr %l96, !tbaa !24
  %t206 = mul i64 %t205, 1
  %t207 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t206)
  %t208 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  store { i64, ptr } %t209, ptr %l97, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = load i64, ptr %l96, !tbaa !24
  %t215 = mul i64 %t214, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t211, ptr %t213, i64 %t215, i1 false)
  %t216 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t217 = getelementptr { { i64, ptr }, i1 }, ptr %l94, i32 0, i32 0
  store { i64, ptr } %t216, ptr %t217, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t218 = load { { i64, ptr }, i1 }, ptr %l94
  store { { i64, ptr }, i1 } %t218, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/interp:Exec", ptr %t219, i32 0, i32 4
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/interp:Exec", ptr %t222, i32 0, i32 4
  %t225 = getelementptr %"compiler/eval:Machine", ptr %t224, i32 0, i32 8
  %t226 = load %"compiler/eval:Ptr", ptr %t225
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/interp:Exec", ptr %t227, i32 0, i32 4
  %t230 = getelementptr %"compiler/eval:Machine", ptr %t229, i32 0, i32 9
  %t231 = load i32, ptr %t230, !tbaa !23
  %t235 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %t221, %"compiler/eval:Ptr" %t226, i32 %t231)
  store { i64, ptr } %t235, ptr %l104
  br label %bb57
bb57:
  %t236 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t237 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t236, 0
  %t238 = insertvalue { { i64, ptr }, i1 } %t237, i1 true, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i1 } %t238, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i1 }, ptr %rv
  ret { { i64, ptr }, i1 } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i64
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/interp:Exec", ptr %t3, i32 0, i32 4
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 66
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/interp:Exec", ptr %t11, i32 0, i32 4
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 66
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 0
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %t15)
  %t20 = add i64 %t17, %t19
  %t21 = extractvalue { i64, ptr } { i64 26, ptr @.d91 }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr @.d91 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t16, i64 %t17)
  %t25 = getelementptr i8, ptr %t24, i64 %t17
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %t15)
  %t27 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } %t36)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  store i64 0, ptr %l3, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/interp:Exec", ptr %t39, i32 0, i32 4
  %t43 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l25
  br label %bb6
bb6:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb12
bb9:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l32, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t71 = load i64, ptr %l32, !tbaa !24
  store i64 %t71, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t72 = load i64, ptr %l29, !tbaa !24
  store i64 %t72, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t81 = load i64, ptr %l3, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/interp:Exec", ptr %t91, i32 0, i32 4
  %t97 = call { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %t93, i64 %t89)
  store { i64, i64, i64 } %t97, ptr %l53
  br label %bb17
bb17:
  %t98 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t98, ptr %l9
  %t99 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 0
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l10, !tbaa !24
  %t102 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l11, !tbaa !24
  %t105 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 2
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp eq i64 %t108, 0
  br i1 %t110, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 11, ptr @.d92 }, ptr %l59, !tbaa !27
  br label %bb23
bb19:
  %t112 = load i64, ptr %l12, !tbaa !24
  %t114 = icmp eq i64 %t112, 1
  br i1 %t114, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 16, ptr @.d93 }, ptr %l62, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 40, ptr @.d94 }, ptr %l62, !tbaa !27
  br label %bb22
bb22:
  %t116 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t116, ptr %l59, !tbaa !27
  br label %bb23
bb23:
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t117, ptr %l13, !tbaa !27
  store ptr %l2, ptr %l63, !tbaa !29
  store ptr %a1, ptr %l64, !tbaa !29
  %t119 = load i64, ptr %l10, !tbaa !24
  store i64 %t119, ptr %l65, !tbaa !24
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = trunc i64 %t120 to i32
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = trunc i64 %t123 to i32
  %t128 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t122, i32 %t125)
  store %"compiler/source:Span" %t128, ptr %l70
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l64, !tbaa !29
  %t130 = load i64, ptr %l65, !tbaa !24
  %t131 = load %"compiler/source:Span", ptr %l70
  %t132 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t129, i64 %t130, %"compiler/source:Span" %t131)
  store { i64, ptr } %t132, ptr %l71
  br label %bb25
bb25:
  %t133 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = extractvalue { i64, ptr } { i64 2, ptr @.d95 }, 1
  %t138 = extractvalue { i64, ptr } { i64 2, ptr @.d95 }, 0
  %t139 = add i64 %t136, %t138
  %t141 = extractvalue { i64, ptr } %t133, 1
  %t142 = extractvalue { i64, ptr } %t133, 0
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 0
  %t146 = add i64 %t143, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t135, i64 %t136)
  %t148 = getelementptr i8, ptr %t147, i64 %t136
  call void @olang_textcopy(ptr %t148, ptr %t137, i64 %t138)
  %t149 = getelementptr i8, ptr %t148, i64 %t138
  call void @olang_textcopy(ptr %t149, ptr %t141, i64 %t142)
  %t150 = getelementptr i8, ptr %t149, i64 %t142
  call void @olang_textcopy(ptr %t150, ptr %t144, i64 %t145)
  %t151 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t147, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t160 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t160, { i64, ptr } %t159)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  %t162 = load i64, ptr %l7, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l7, !tbaa !24
  br label %bb13
bb28:
  %t167 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t167, ptr %l78
  br label %bb29
bb29:
  %t168 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t168, ptr %l79, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  store i64 %t170, ptr %l80, !tbaa !24
  %t171 = load i64, ptr %l80, !tbaa !24
  %t172 = mul i64 %t171, 1
  %t173 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t172)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %l81, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = load i64, ptr %l80, !tbaa !24
  %t181 = mul i64 %t180, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t177, ptr %t179, i64 %t181, i1 false)
  %t182 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t182, ptr %l79, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t183 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t183, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2finterp_2ecompiler_2finterp_3aExec_2ebuildDefault(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca i1
  %l35 = alloca i32
  %l40 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/interp:Exec", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 5
  %t16 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t12, i64 %a1)
  store ptr %t16, ptr %l16
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = getelementptr %"compiler/load:Module", ptr %t18, i32 0, i32 3
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 4, ptr @.d97 })
  store i1 %t28, ptr %l22
  br label %bb7
bb7:
  %t29 = load i1, ptr %l22, !tbaa !21
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr @.d98 }, 0
  %t33 = insertvalue [5 x { i64, ptr }] %t32, { i64, ptr } { i64 3, ptr @.d99 }, 1
  %t34 = insertvalue [5 x { i64, ptr }] %t33, { i64, ptr } { i64 3, ptr @.d100 }, 2
  %t35 = insertvalue [5 x { i64, ptr }] %t34, { i64, ptr } { i64 3, ptr @.d101 }, 3
  %t36 = insertvalue [5 x { i64, ptr }] %t35, { i64, ptr } { i64 3, ptr @.d102 }, 4
  %t38 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 80, i64 8)
  store [5 x { i64, ptr }] %t36, ptr %t38
  store ptr %t38, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t40 = load ptr, ptr %l5
  store i64 5, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l5
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr [5 x { i64, ptr }], ptr %t51, i64 0, i64 %t52
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !37
  %t58 = load i32, ptr %l2, !tbaa !23
  store i32 %t58, ptr %l35, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/interp:Exec", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t66 = load ptr, ptr @__olang_prog_scope
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %t66, ptr %t64, { i64, ptr } %t56)
  store i32 %t69, ptr %l40
  br label %bb16
bb16:
  %t70 = load i32, ptr %l35, !tbaa !23
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = icmp eq i32 %t70, %t71
  br i1 %t72, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb12
bb21:
  call void @__olang_scope_close(ptr %s3)
  %t79 = load i32, ptr %l2, !tbaa !23
  store i32 %t79, ptr %l45, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/interp:Exec", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t83, { i64, ptr } { i64 16, ptr @.d103 }, { i64, ptr } { i64 6, ptr @.d104 })
  store i32 %t85, ptr %l48
  br label %bb22
bb22:
  %t86 = load i32, ptr %l45, !tbaa !23
  %t87 = load i32, ptr %l48, !tbaa !23
  %t88 = icmp eq i32 %t86, %t87
  call void @__olang_scope_close(ptr %s0)
  store i1 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [5 x i64] }
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i64
  %l16 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [5 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [1 x i64] }, ptr %t7
  store { i64, [1 x i64] } %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [1 x i64] }, ptr %l3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v1, ptr %a2, { i64, [1 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb22
bb5:
  %t14 = load { i64, [5 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [5 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i64, i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/interp:Exec", ptr %t23, i32 0, i32 8
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t25, i64 %t26)
  store i1 %t29, ptr %l16
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/interp:Exec", ptr %t33, i32 0, i32 8
  %t36 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t35, i64 %t36, i1 true)
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/interp:Exec", ptr %t39, i32 0, i32 4
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  store i64 %t42, ptr %l23, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/interp:Exec", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = getelementptr %"compiler/types:Table", ptr %t48, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/interp:Exec", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t54, i64 %t55)
  store ptr %t58, ptr %l30
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l26, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t63, i32 %t62)
  store { i64, ptr } %t65, ptr %l33
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l22, !tbaa !29
  %t67 = load i64, ptr %l23, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v0, ptr %t66, i64 %t67, { i64, ptr } %t68)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  %t69 = load { i64, [5 x i64] }, ptr %l1
  %t71 = extractvalue { i64, [5 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 2
  br i1 %t72, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb22:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eerrorName(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l25 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca i32
  %l43 = alloca i32
  %l47 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/interp:Exec", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t12, i32 %a2)
  store i32 %t16, ptr %l18
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l18, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l19
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = ashr i64 %t21, 16
  %t25 = sub i64 %t23, 1
  store i64 %t25, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb4:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp sge i64 %t31, %t34
  store i1 %t37, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t39 = load i1, ptr %l25, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 1
  %t42 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 0
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t40)
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = getelementptr i8, ptr %t46, i64 %t42
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t40)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/interp:Exec", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t57, i32 %t64)
  store i32 %t67, ptr %l38
  br label %bb9
bb9:
  %t68 = load i32, ptr %l38, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t74, i32 %t68)
  store i32 %t78, ptr %l43
  br label %bb10
bb10:
  %t79 = load i32, ptr %l43, !tbaa !23
  store i32 %t79, ptr %l6, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/interp:Exec", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i32, ptr %l6, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t83, i32 %t84)
  store { i64, ptr } %t87, ptr %l47
  br label %bb11
bb11:
  %t88 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  %t89 = load i64, ptr %l1, !tbaa !24
  %t91 = and i64 %t89, 65535
  store i64 %t91, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t99 = icmp slt i64 %t93, %t96
  br i1 %t99, label %bb12, label %bb13
bb12:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/interp:Exec", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = getelementptr %"compiler/types:Table", ptr %t106, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t109, ptr %l58, !tbaa !27
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  %t118 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t108, i32 %t115)
  store { i64, ptr } %t118, ptr %l61
  br label %bb14
bb13:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = call i64 @__olang_fmt_i64(ptr null, i64 %t119)
  %t122 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t121)
  %t123 = call i64 @__olang_fmt_i64(ptr %t122, i64 %t119)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t122, 1
  store { i64, ptr } %t125, ptr %l54, !tbaa !27
  br label %bb15
bb14:
  %t127 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t128, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l54, !tbaa !27
  br label %bb15
bb15:
  %t134 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t134, ptr %l9, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/interp:Exec", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = getelementptr %"compiler/types:Table", ptr %t140, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  store ptr %t142, ptr %l67, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/interp:Exec", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l6, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l72
  br label %bb16
bb16:
  %t153 = load ptr, ptr %l67, !tbaa !29
  %t154 = load i32, ptr %l72, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t153, i32 %t154)
  store { i64, ptr } %t155, ptr %l73
  br label %bb17
bb17:
  %t156 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t156, 1
  %t161 = extractvalue { i64, ptr } %t156, 0
  %t162 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 1
  %t163 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 0
  %t164 = add i64 %t161, %t163
  %t166 = extractvalue { i64, ptr } %t158, 1
  %t167 = extractvalue { i64, ptr } %t158, 0
  %t168 = add i64 %t164, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t160, i64 %t161)
  %t170 = getelementptr i8, ptr %t169, i64 %t161
  call void @olang_textcopy(ptr %t170, ptr %t162, i64 %t163)
  %t171 = getelementptr i8, ptr %t170, i64 %t163
  call void @olang_textcopy(ptr %t171, ptr %t166, i64 %t167)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t169, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/mir:Call"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/mir:Task"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/mir:BasicBlock"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, [21 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca { i64, [1 x i64] }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i32
  %l46 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l72 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l98 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i32
  %l115 = alloca { i64, ptr }
  %l117 = alloca { i64, [21 x i64] }
  %l118 = alloca { i64, [21 x i64] }
  %l120 = alloca i1
  %l126 = alloca { i64, [21 x i64] }
  %l129 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t242 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 14
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eRunFrom_3ccompiler_2fmir_3aCall_3e(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l37
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l36
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t14, ptr %l33, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l37, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c108)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb7:
  %t20 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l46, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/mir:Call", ptr %t37, i64 %t34
  %t39 = load %"compiler/mir:Call", ptr %t38
  store %"compiler/mir:Call" %t39, ptr %l8
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/mir:Call", ptr %l8, i32 0, i32 0
  %t43 = load { i64, [5 x i64] }, ptr %t42
  %t44 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v2, ptr %t41, { i64, [5 x i64] } %t43, ptr %t44)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l7, !tbaa !24
  br label %bb8
bb14:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t52, %t53
  store i64 %t56, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb1
bb16:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/mir:Fn", ptr %t58, i32 0, i32 16
  store ptr %t60, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t62 = load ptr, ptr %l9, !tbaa !29
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eRunFrom_3ccompiler_2fmir_3aTask_3e(ptr %v1, ptr %t62, i64 %t63)
  %t67 = extractvalue { i32, { i64, ptr } } %t66, 1
  %t68 = extractvalue { i32, { i64, ptr } } %t66, 0
  store i32 %t68, ptr %l63
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb19, label %ok.70
ok.70:
  store { i64, ptr } %t67, ptr %l62
  br label %bb18
bb18:
  %t71 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t71, ptr %l59, !tbaa !27
  br label %bb23
bb19:
  %t72 = load i32, ptr %l63, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb23:
  %t77 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t77, ptr %l11, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t82 = load i64, ptr %l13, !tbaa !24
  %t83 = load i64, ptr %l12, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb26:
  br label %bb27
bb27:
  %t90 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t90, ptr %l72, !tbaa !27
  %t91 = load i64, ptr %l13, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr %"compiler/mir:Task", ptr %t94, i64 %t91
  %t96 = load %"compiler/mir:Task", ptr %t95
  store %"compiler/mir:Task" %t96, ptr %l14
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/mir:Task", ptr %l14, i32 0, i32 0
  %t100 = load { i64, [5 x i64] }, ptr %t99
  %t101 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v2, ptr %t98, { i64, [5 x i64] } %t100, ptr %t101)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb29:
  %t105 = load i64, ptr %l13, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l13, !tbaa !24
  br label %bb24
bb30:
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = add i64 %t109, %t110
  store i64 %t113, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  br label %bb17
bb32:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/mir:Fn", ptr %t115, i32 0, i32 9
  store ptr %t117, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s10
  %t119 = load ptr, ptr %l15, !tbaa !29
  %t120 = load i64, ptr %l16, !tbaa !24
  %t123 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v1, ptr %t119, i64 %t120)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l89
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb35, label %ok.127
ok.127:
  store { i64, ptr } %t124, ptr %l88
  br label %bb34
bb34:
  %t128 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t128, ptr %l85, !tbaa !27
  br label %bb39
bb35:
  %t129 = load i32, ptr %l89, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  br i1 %t132, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb39:
  %t134 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t134, ptr %l17, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t139 = load i64, ptr %l19, !tbaa !24
  %t140 = load i64, ptr %l18, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb42:
  br label %bb43
bb43:
  %t147 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t147, ptr %l98, !tbaa !27
  %t148 = load i64, ptr %l19, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr %"compiler/mir:BasicBlock", ptr %t151, i64 %t148
  %t153 = load %"compiler/mir:BasicBlock", ptr %t152
  store %"compiler/mir:BasicBlock" %t153, ptr %l20
  %t155 = getelementptr %"compiler/mir:BasicBlock", ptr %l20, i32 0, i32 0
  store ptr %t155, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s13
  %t157 = load ptr, ptr %l21, !tbaa !29
  %t158 = load i64, ptr %l22, !tbaa !24
  %t161 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t157, i64 %t158)
  %t162 = extractvalue { i32, { i64, ptr } } %t161, 1
  %t163 = extractvalue { i32, { i64, ptr } } %t161, 0
  store i32 %t163, ptr %l106
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb46, label %ok.165
ok.165:
  store { i64, ptr } %t162, ptr %l105
  br label %bb45
bb45:
  %t166 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t166, ptr %l102, !tbaa !27
  br label %bb50
bb46:
  %t167 = load i32, ptr %l106, !tbaa !23
  %t168 = ashr i32 %t167, 16
  %t170 = icmp eq i32 %t168, 1
  br i1 %t170, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c111)
  unreachable
bb49:
  call void @__olang_scope_close(ptr %s13)
  br label %bb84
bb50:
  %t172 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t172, ptr %l23, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s14
  %t177 = load i64, ptr %l25, !tbaa !24
  %t178 = load i64, ptr %l24, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s14)
  br label %bb82
bb53:
  br label %bb54
bb54:
  %t185 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t185, ptr %l115, !tbaa !27
  %t186 = load i64, ptr %l25, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr { i64, [21 x i64] }, ptr %t189, i64 %t186
  call void @llvm.memmove.p0.p0.i64(ptr %l117, ptr %t190, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %l117, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l118, ptr %l26, i64 176, i1 false)
  %t191 = load { i64, [21 x i64] }, ptr %l118
  %t192 = extractvalue { i64, [21 x i64] } %t191, 0
  %t193 = icmp eq i64 %t192, 0
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t195 = getelementptr { i64, [21 x i64] }, ptr %l26, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t195, i32 0, i32 2
  %t197 = load { i64, [15 x i64] }, ptr %t196
  %t199 = extractvalue { i64, [15 x i64] } %t197, 0
  %t200 = icmp eq i64 %t199, 10
  store i1 %t200, ptr %l120, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb57
bb57:
  %t202 = load i1, ptr %l120, !tbaa !21
  br i1 %t202, label %bb58, label %bb59
bb58:
  %t203 = getelementptr { i64, [21 x i64] }, ptr %l26, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t203, i32 0, i32 2
  %t205 = getelementptr { i64, [15 x i64] }, ptr %t204, i32 0, i32 1
  %t206 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t205, i32 0, i32 0
  %t207 = load { i64, [1 x i64] }, ptr %t206
  store { i64, [1 x i64] } %t207, ptr %l27
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t209 = load ptr, ptr %l2, !tbaa !29
  %t210 = load { i64, [1 x i64] }, ptr %l27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v2, ptr %t209, { i64, [1 x i64] } %t210)
  br label %bb61
bb61:
  br label %bb80
bb62:
  call void @llvm.memmove.p0.p0.i64(ptr %l126, ptr %l26, i64 176, i1 false)
  %t213 = load { i64, [21 x i64] }, ptr %l126
  %t214 = extractvalue { i64, [21 x i64] } %t213, 0
  %t215 = icmp eq i64 %t214, 6
  br i1 %t215, label %bb63, label %bb64
bb63:
  %t217 = getelementptr { i64, [21 x i64] }, ptr %l26, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t217, i32 0, i32 2
  %t219 = load i32, ptr %t218
  store i32 %t219, ptr %l28, !tbaa !23
  br label %bb65
bb64:
  br label %bb75
bb65:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/interp:Exec", ptr %t221, i32 0, i32 7
  %t224 = load i32, ptr %l28, !tbaa !23
  %t227 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t223, i32 %t224)
  %t228 = extractvalue { i32, i64 } %t227, 1
  %t229 = extractvalue { i32, i64 } %t227, 0
  store i32 %t229, ptr %l134
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb67, label %ok.231
ok.231:
  store i64 %t228, ptr %l133
  br label %bb66
bb66:
  %t232 = load i64, ptr %l133, !tbaa !24
  store i64 %t232, ptr %l129, !tbaa !24
  br label %bb69
bb67:
  br label %bb68
bb68:
  store i64 -1, ptr %l129, !tbaa !24
  br label %bb69
bb69:
  %t233 = load i64, ptr %l129, !tbaa !24
  store i64 %t233, ptr %l29, !tbaa !24
  %t234 = load i64, ptr %l29, !tbaa !24
  %t236 = icmp sge i64 %t234, 0
  br i1 %t236, label %bb70, label %bb71
bb70:
  %t238 = load i64, ptr %l29, !tbaa !24
  %t240 = trunc i64 %t238 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t242
  %t243 = getelementptr { i64, [1 x i64] }, ptr %t242, i32 0, i32 0
  store i64 0, ptr %t243
  %t245 = insertvalue { i32 } undef, i32 %t240, 0
  %t246 = getelementptr { i64, [1 x i64] }, ptr %t242, i32 0, i32 1
  store { i32 } %t245, ptr %t246
  %t247 = load { i64, [1 x i64] }, ptr %t242
  store { i64, [1 x i64] } %t247, ptr %l30
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/interp:Exec", ptr %t249, i32 0, i32 4
  %t252 = load i32, ptr %l28, !tbaa !23
  %t253 = load { i64, [1 x i64] }, ptr %l30
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %t251, i32 %t252, { i64, [1 x i64] } %t253)
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t258 = load { i64, [1 x i64] }, ptr %l30
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v2, ptr %t257, { i64, [1 x i64] } %t258)
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb80
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb80:
  call void @__olang_scope_close(ptr %s14)
  br label %bb81
bb81:
  %t261 = load i64, ptr %l25, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l25, !tbaa !24
  br label %bb51
bb82:
  %t265 = load i64, ptr %l22, !tbaa !24
  %t266 = load i64, ptr %l24, !tbaa !24
  %t269 = add i64 %t265, %t266
  store i64 %t269, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb83
bb83:
  br label %bb44
bb84:
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb85:
  %t271 = load i64, ptr %l19, !tbaa !24
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l19, !tbaa !24
  br label %bb40
bb86:
  %t275 = load i64, ptr %l16, !tbaa !24
  %t276 = load i64, ptr %l18, !tbaa !24
  %t279 = add i64 %t275, %t276
  store i64 %t279, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb87
bb87:
  br label %bb33
bb88:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, [1 x i64] }
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i32
  %l67 = alloca { i64, ptr }
  %l72 = alloca i1
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l112 = alloca ptr
  %l132 = alloca i32
  %l141 = alloca ptr
  %l142 = alloca i64
  %l143 = alloca i32
  %l144 = alloca i32
  %l149 = alloca ptr
  %l150 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i32
  %l159 = alloca ptr
  %l160 = alloca i1
  %l161 = alloca i1
  %l171 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l175 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca i32
  %l188 = alloca { i64, ptr }
  %l195 = alloca i1
  %l205 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l209 = alloca i32
  %l218 = alloca { i64, ptr }
  %l224 = alloca i1
  %l236 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca i32
  %l249 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l266 = alloca i32
  %l275 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %t202 = alloca { i64, [1 x i64] }, align 8
  %t506 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/interp:Exec", ptr %t6, i32 0, i32 12
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/interp:Exec", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 5
  store ptr %t17, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %t19, i64 %t20)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l58
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb6, label %ok.27
ok.27:
  store { i64, ptr } %t24, ptr %l57
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t28, ptr %l54, !tbaa !27
  br label %bb10
bb6:
  %t29 = load i32, ptr %l58, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  br i1 %t32, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @.c113)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb10:
  %t34 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t34, ptr %l3, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l67, !tbaa !27
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  store ptr %t53, ptr %l6, !tbaa !29
  %t55 = load ptr, ptr %l6, !tbaa !29
  %t57 = getelementptr %"compiler/load:Module", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s4, { i64, ptr } %t58, { i64, ptr } { i64 4, ptr @.d114 })
  store i1 %t60, ptr %l72
  br label %bb15
bb15:
  %t61 = load i1, ptr %l72, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/interp:Exec", ptr %t62, i32 0, i32 4
  %t65 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 63
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 4
  %t69 = load i64, ptr %t68, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t65, i64 %t69, i1 true)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb11
bb21:
  %t76 = load i64, ptr %l2, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t76, %t77
  store i64 %t80, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  br label %bb4
bb23:
  store i64 0, ptr %l7, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/interp:Exec", ptr %t82, i32 0, i32 1
  %t86 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l84
  br label %bb24
bb24:
  %t87 = load i64, ptr %l84, !tbaa !24
  store i64 %t87, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb30
bb27:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l91, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb29
bb29:
  %t114 = load i64, ptr %l91, !tbaa !24
  store i64 %t114, ptr %l88, !tbaa !24
  br label %bb30
bb30:
  %t115 = load i64, ptr %l88, !tbaa !24
  store i64 %t115, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t116 = load i64, ptr %l11, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb69
bb33:
  br label %bb34
bb34:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t125 = load i64, ptr %l11, !tbaa !24
  %t126 = load i64, ptr %l9, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l12, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/interp:Exec", ptr %t134, i32 0, i32 1
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t136, i64 %t137)
  store ptr %t140, ptr %l112
  br label %bb35
bb35:
  %t141 = load ptr, ptr %l112, !tbaa !29
  store ptr %t141, ptr %l13, !tbaa !29
  %t142 = load ptr, ptr %l13, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 1
  %t145 = load { i64, [2 x i64] }, ptr %t144
  store { i64, [2 x i64] } %t145, ptr %l14
  %t147 = load { i64, [2 x i64] }, ptr %l14
  %t149 = extractvalue { i64, [2 x i64] } %t147, 0
  %t150 = icmp eq i64 %t149, 3
  br i1 %t150, label %bb36, label %bb37
bb36:
  %t152 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t153 = getelementptr { i32 }, ptr %t152, i32 0, i32 0
  %t154 = load i32, ptr %t153
  store i32 %t154, ptr %l15, !tbaa !23
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/interp:Exec", ptr %t156, i32 0, i32 7
  %t159 = load i32, ptr %l15, !tbaa !23
  %t160 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t158, i32 %t159, i64 %t160)
  br label %bb39
bb39:
  br label %bb67
bb40:
  %t164 = load { i64, [2 x i64] }, ptr %l14
  %t166 = extractvalue { i64, [2 x i64] } %t164, 0
  %t167 = icmp eq i64 %t166, 6
  br i1 %t167, label %bb41, label %bb42
bb41:
  %t169 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t170 = getelementptr { i64, i32 }, ptr %t169, i32 0, i32 0
  %t171 = load i64, ptr %t170
  store i64 %t171, ptr %l16, !tbaa !24
  %t173 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t174 = getelementptr { i64, i32 }, ptr %t173, i32 0, i32 1
  %t175 = load i32, ptr %t174
  store i32 %t175, ptr %l17, !tbaa !23
  br label %bb43
bb42:
  br label %bb62
bb43:
  %t177 = load ptr, ptr %l13, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Body", ptr %t177, i32 0, i32 11
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = icmp eq ptr %t180, null
  br i1 %t182, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb45:
  br label %bb46
bb46:
  %t184 = load ptr, ptr %l13, !tbaa !29
  %t185 = load i64, ptr %l16, !tbaa !24
  %t186 = load i32, ptr %l17, !tbaa !23
  %t190 = call i32 @compiler_2finterp_2eglobalType(ptr %v0, ptr %t184, i64 %t185, i32 %t186)
  store i32 %t190, ptr %l132
  br label %bb47
bb47:
  %t191 = load i32, ptr %l132, !tbaa !23
  store i32 %t191, ptr %l18, !tbaa !23
  %t192 = load i32, ptr %l18, !tbaa !23
  %t193 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t196 = icmp eq i32 %t192, %t193
  br i1 %t196, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb49:
  br label %bb50
bb50:
  %t198 = load i64, ptr %l12, !tbaa !24
  %t200 = trunc i64 %t198 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [1 x i64] }, ptr %t202, i32 0, i32 0
  store i64 0, ptr %t203
  %t205 = insertvalue { i32 } undef, i32 %t200, 0
  %t206 = getelementptr { i64, [1 x i64] }, ptr %t202, i32 0, i32 1
  store { i32 } %t205, ptr %t206
  %t207 = load { i64, [1 x i64] }, ptr %t202
  store { i64, [1 x i64] } %t207, ptr %l19
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/interp:Exec", ptr %t209, i32 0, i32 4
  store ptr %t211, ptr %l141, !tbaa !29
  %t212 = load i64, ptr %l16, !tbaa !24
  store i64 %t212, ptr %l142, !tbaa !24
  %t213 = load i32, ptr %l17, !tbaa !23
  store i32 %t213, ptr %l143, !tbaa !23
  %t214 = load i32, ptr %l18, !tbaa !23
  store i32 %t214, ptr %l144, !tbaa !23
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/interp:Exec", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t219 = load i64, ptr %l16, !tbaa !24
  %t220 = load i32, ptr %l17, !tbaa !23
  %t224 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t218, i64 %t219, i32 %t220)
  store ptr %t224, ptr %l149
  br label %bb51
bb51:
  %t225 = load ptr, ptr %l149, !tbaa !29
  %t226 = call i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %t225)
  store i1 %t226, ptr %l150
  br label %bb52
bb52:
  %t227 = load { i64, [1 x i64] }, ptr %l19
  %t228 = load ptr, ptr %l141, !tbaa !29
  %t229 = load i64, ptr %l142, !tbaa !24
  %t230 = load i32, ptr %l143, !tbaa !23
  %t231 = load i32, ptr %l144, !tbaa !23
  %t232 = load i1, ptr %l150, !tbaa !21
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %t228, i64 %t229, i32 %t230, i32 %t231, i1 %t232, { i64, [1 x i64] } %t227)
  br label %bb53
bb53:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l152, !tbaa !29
  %t235 = load i64, ptr %l16, !tbaa !24
  store i64 %t235, ptr %l153, !tbaa !24
  %t236 = load i32, ptr %l18, !tbaa !23
  store i32 %t236, ptr %l154, !tbaa !23
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/interp:Exec", ptr %t237, i32 0, i32 0
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t241 = load i64, ptr %l16, !tbaa !24
  %t242 = load i32, ptr %l17, !tbaa !23
  %t246 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t240, i64 %t241, i32 %t242)
  store ptr %t246, ptr %l159
  br label %bb54
bb54:
  %t247 = load ptr, ptr %l159, !tbaa !29
  %t248 = call i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %t247)
  store i1 %t248, ptr %l160
  br label %bb55
bb55:
  %t249 = load ptr, ptr %l152, !tbaa !29
  %t250 = load i64, ptr %l153, !tbaa !24
  %t251 = load i32, ptr %l154, !tbaa !23
  %t252 = load i1, ptr %l160, !tbaa !21
  %t253 = call i1 @compiler_2finterp_2ecompiler_2finterp_3aExec_2ebuildDefault(ptr %v0, ptr %t249, i64 %t250, i32 %t251, i1 %t252)
  store i1 %t253, ptr %l161
  br label %bb56
bb56:
  %t254 = load i1, ptr %l161, !tbaa !21
  br i1 %t254, label %bb57, label %bb58
bb57:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/interp:Exec", ptr %t255, i32 0, i32 4
  %t258 = load i64, ptr %l16, !tbaa !24
  %t259 = load i32, ptr %l17, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eBuildGlobal(ptr %v0, ptr %t257, i64 %t258, i32 %t259)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/interp:Exec", ptr %t263, i32 0, i32 9
  %t266 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t265, i64 %t266)
  br label %bb61
bb61:
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @.c115)
  unreachable
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb68:
  %t269 = load i64, ptr %l11, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l11, !tbaa !24
  br label %bb31
bb69:
  %t273 = load ptr, ptr @__olang_prog_scope
  %t274 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t273)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t274, ptr %l171
  br label %bb70
bb70:
  %t275 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l171
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t275, ptr %l20
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/interp:Exec", ptr %t276, i32 0, i32 0
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 36
  store ptr %t281, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s17
  %t283 = load ptr, ptr %l21, !tbaa !29
  %t284 = load i64, ptr %l22, !tbaa !24
  %t287 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t283, i64 %t284)
  %t288 = extractvalue { i32, { i64, ptr } } %t287, 1
  %t289 = extractvalue { i32, { i64, ptr } } %t287, 0
  store i32 %t289, ptr %l179
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb73, label %ok.291
ok.291:
  store { i64, ptr } %t288, ptr %l178
  br label %bb72
bb72:
  %t292 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t292, ptr %l175, !tbaa !27
  br label %bb77
bb73:
  %t293 = load i32, ptr %l179, !tbaa !23
  %t294 = ashr i32 %t293, 16
  %t296 = icmp eq i32 %t294, 1
  br i1 %t296, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb76:
  call void @__olang_scope_close(ptr %s17)
  br label %bb90
bb77:
  %t298 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t298, ptr %l23, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s18
  %t303 = load i64, ptr %l25, !tbaa !24
  %t304 = load i64, ptr %l24, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s18)
  br label %bb88
bb80:
  br label %bb81
bb81:
  %t311 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t311, ptr %l188, !tbaa !27
  %t312 = load i64, ptr %l25, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr i64, ptr %t315, i64 %t312
  %t317 = load i64, ptr %t316, !tbaa !34
  store i64 %t317, ptr %l26, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/interp:Exec", ptr %t321, i32 0, i32 9
  %t327 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t323, i64 %t319)
  store i1 %t327, ptr %l195
  br label %bb82
bb82:
  %t328 = load i1, ptr %l195, !tbaa !21
  br i1 %t328, label %bb83, label %bb84
bb83:
  %t329 = load i64, ptr %l26, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t329)
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s18)
  br label %bb87
bb87:
  %t332 = load i64, ptr %l25, !tbaa !24
  %t334 = add i64 %t332, 1
  store i64 %t334, ptr %l25, !tbaa !24
  br label %bb78
bb88:
  %t336 = load i64, ptr %l22, !tbaa !24
  %t337 = load i64, ptr %l24, !tbaa !24
  %t340 = add i64 %t336, %t337
  store i64 %t340, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb89
bb89:
  br label %bb71
bb90:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/interp:Exec", ptr %t342, i32 0, i32 9
  store ptr %t344, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s22
  %t346 = load ptr, ptr %l28, !tbaa !29
  %t347 = load i64, ptr %l29, !tbaa !24
  %t350 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t346, i64 %t347)
  %t351 = extractvalue { i32, { i64, ptr } } %t350, 1
  %t352 = extractvalue { i32, { i64, ptr } } %t350, 0
  store i32 %t352, ptr %l209
  %t353 = icmp ne i32 %t352, 0
  br i1 %t353, label %bb93, label %ok.354
ok.354:
  store { i64, ptr } %t351, ptr %l208
  br label %bb92
bb92:
  %t355 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t355, ptr %l205, !tbaa !27
  br label %bb97
bb93:
  %t356 = load i32, ptr %l209, !tbaa !23
  %t357 = ashr i32 %t356, 16
  %t359 = icmp eq i32 %t357, 1
  br i1 %t359, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @.c117)
  unreachable
bb96:
  call void @__olang_scope_close(ptr %s22)
  br label %bb110
bb97:
  %t361 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t361, ptr %l30, !tbaa !27
  %t362 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s23
  %t366 = load i64, ptr %l32, !tbaa !24
  %t367 = load i64, ptr %l31, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s23)
  br label %bb108
bb100:
  br label %bb101
bb101:
  %t374 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t374, ptr %l218, !tbaa !27
  %t375 = load i64, ptr %l32, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i64, ptr %t378, i64 %t375
  %t380 = load i64, ptr %t379, !tbaa !34
  store i64 %t380, ptr %l33, !tbaa !24
  %t382 = load i64, ptr %l33, !tbaa !24
  %t387 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l20, i64 %t382)
  store i1 %t387, ptr %l224
  br label %bb102
bb102:
  %t388 = load i1, ptr %l224, !tbaa !21
  %t389 = xor i1 %t388, true
  br i1 %t389, label %bb103, label %bb104
bb103:
  %t391 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t391)
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s23)
  br label %bb107
bb107:
  %t394 = load i64, ptr %l32, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l32, !tbaa !24
  br label %bb98
bb108:
  %t398 = load i64, ptr %l29, !tbaa !24
  %t399 = load i64, ptr %l31, !tbaa !24
  %t402 = add i64 %t398, %t399
  store i64 %t402, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb109
bb109:
  br label %bb91
bb110:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/interp:Exec", ptr %t404, i32 0, i32 9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t406)
  br label %bb111
bb111:
  store ptr %l20, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s27
  %t409 = load ptr, ptr %l35, !tbaa !29
  %t410 = load i64, ptr %l36, !tbaa !24
  %t413 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t409, i64 %t410)
  %t414 = extractvalue { i32, { i64, ptr } } %t413, 1
  %t415 = extractvalue { i32, { i64, ptr } } %t413, 0
  store i32 %t415, ptr %l240
  %t416 = icmp ne i32 %t415, 0
  br i1 %t416, label %bb114, label %ok.417
ok.417:
  store { i64, ptr } %t414, ptr %l239
  br label %bb113
bb113:
  %t418 = load { i64, ptr }, ptr %l239, !tbaa !27
  store { i64, ptr } %t418, ptr %l236, !tbaa !27
  br label %bb118
bb114:
  %t419 = load i32, ptr %l240, !tbaa !23
  %t420 = ashr i32 %t419, 16
  %t422 = icmp eq i32 %t420, 1
  br i1 %t422, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @.c118)
  unreachable
bb117:
  call void @__olang_scope_close(ptr %s27)
  br label %bb127
bb118:
  %t424 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t424, ptr %l37, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 0
  store i64 %t427, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s28
  %t429 = load i64, ptr %l39, !tbaa !24
  %t430 = load i64, ptr %l38, !tbaa !24
  %t433 = icmp slt i64 %t429, %t430
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s28)
  br label %bb125
bb121:
  br label %bb122
bb122:
  %t437 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t437, ptr %l249, !tbaa !27
  %t438 = load i64, ptr %l39, !tbaa !24
  %t440 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = getelementptr i64, ptr %t441, i64 %t438
  %t443 = load i64, ptr %t442, !tbaa !34
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/interp:Exec", ptr %t445, i32 0, i32 9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t447, i64 %t443)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s28)
  br label %bb124
bb124:
  %t451 = load i64, ptr %l39, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l39, !tbaa !24
  br label %bb119
bb125:
  %t455 = load i64, ptr %l36, !tbaa !24
  %t456 = load i64, ptr %l38, !tbaa !24
  %t459 = add i64 %t455, %t456
  store i64 %t459, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb126
bb126:
  br label %bb112
bb127:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/interp:Exec", ptr %t461, i32 0, i32 9
  store ptr %t463, ptr %l41, !tbaa !29
  store i64 0, ptr %l42, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s31
  %t465 = load ptr, ptr %l41, !tbaa !29
  %t466 = load i64, ptr %l42, !tbaa !24
  %t469 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t465, i64 %t466)
  %t470 = extractvalue { i32, { i64, ptr } } %t469, 1
  %t471 = extractvalue { i32, { i64, ptr } } %t469, 0
  store i32 %t471, ptr %l266
  %t472 = icmp ne i32 %t471, 0
  br i1 %t472, label %bb130, label %ok.473
ok.473:
  store { i64, ptr } %t470, ptr %l265
  br label %bb129
bb129:
  %t474 = load { i64, ptr }, ptr %l265, !tbaa !27
  store { i64, ptr } %t474, ptr %l262, !tbaa !27
  br label %bb134
bb130:
  %t475 = load i32, ptr %l266, !tbaa !23
  %t476 = ashr i32 %t475, 16
  %t478 = icmp eq i32 %t476, 1
  br i1 %t478, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @.c119)
  unreachable
bb133:
  call void @__olang_scope_close(ptr %s31)
  br label %bb143
bb134:
  %t480 = load { i64, ptr }, ptr %l262, !tbaa !27
  store { i64, ptr } %t480, ptr %l43, !tbaa !27
  %t481 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t481, 0
  store i64 %t483, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb135
bb135:
  store %olang.scope zeroinitializer, ptr %s32
  %t485 = load i64, ptr %l45, !tbaa !24
  %t486 = load i64, ptr %l44, !tbaa !24
  %t489 = icmp slt i64 %t485, %t486
  %t491 = xor i1 %t489, true
  br i1 %t491, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s32)
  br label %bb141
bb137:
  br label %bb138
bb138:
  %t493 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t493, ptr %l275, !tbaa !27
  %t494 = load i64, ptr %l45, !tbaa !24
  %t496 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t497 = load ptr, ptr %t496, !tbaa !27
  %t498 = getelementptr i64, ptr %t497, i64 %t494
  %t499 = load i64, ptr %t498, !tbaa !34
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t504 = trunc i64 %t499 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t506
  %t507 = getelementptr { i64, [1 x i64] }, ptr %t506, i32 0, i32 0
  store i64 0, ptr %t507
  %t509 = insertvalue { i32 } undef, i32 %t504, 0
  %t510 = getelementptr { i64, [1 x i64] }, ptr %t506, i32 0, i32 1
  store { i32 } %t509, ptr %t510
  %t511 = load { i64, [1 x i64] }, ptr %t506
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t501, { i64, [1 x i64] } %t511)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s32)
  br label %bb140
bb140:
  %t514 = load i64, ptr %l45, !tbaa !24
  %t516 = add i64 %t514, 1
  store i64 %t516, ptr %l45, !tbaa !24
  br label %bb135
bb141:
  %t518 = load i64, ptr %l42, !tbaa !24
  %t519 = load i64, ptr %l44, !tbaa !24
  %t522 = add i64 %t518, %t519
  store i64 %t522, ptr %l42, !tbaa !24
  call void @__olang_scope_close(ptr %s31)
  br label %bb142
bb142:
  br label %bb128
bb143:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2finterp_2econdSaid(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [3 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [3 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l3, !tbaa !24
  %t14 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t15 = getelementptr { i64, i64, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l15
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l10, !tbaa !29
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = load i64, ptr %l15, !tbaa !24
  %t30 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %t25, i64 %t26, i64 %t27, i64 %t28, i64 %t29)
  store i1 %t30, ptr %l16
  br label %bb5
bb5:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2finterp_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/check:Ask"
  %l16 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca { i1, i1 }
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/generic:ConstAsk"
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca { i64, [5 x i64] }
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, [3 x i64] }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l40 = alloca ptr
  %l41 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, [3 x i64] }
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l53 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca i64
  %l57 = alloca i1
  %l60 = alloca i64
  %l62 = alloca i1
  %l66 = alloca i64
  %l74 = alloca %"compiler/interp:Exec"
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l98 = alloca { i64, ptr }
  %l104 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l107 = alloca i1
  %l108 = alloca i1
  %l111 = alloca i1
  %l114 = alloca { i1, i1 }
  %l118 = alloca i1
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i32
  %l151 = alloca { i64, ptr }
  %l157 = alloca i1
  %l165 = alloca i64
  %l181 = alloca ptr
  %l182 = alloca { i64, [1 x i64] }
  %l186 = alloca { i64, [5 x i64] }
  %l188 = alloca %"compiler/source:Span"
  %l192 = alloca ptr
  %l202 = alloca ptr
  %l205 = alloca { i64, ptr }
  %l211 = alloca i64
  %l221 = alloca ptr
  %l222 = alloca ptr
  %l224 = alloca ptr
  %l225 = alloca { i64, [3 x i64] }
  %l227 = alloca %"compiler/msgs:Msg"
  %l228 = alloca i64
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca { i64, [3 x i64] }
  %l244 = alloca { i64, ptr }
  %l245 = alloca %"compiler/msgs:Msg"
  %l246 = alloca i64
  %l259 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca i32
  %l272 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l282 = alloca ptr
  %l289 = alloca { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
  %l292 = alloca { i64, ptr }
  %l293 = alloca i64
  %l294 = alloca { i64, ptr }
  %l298 = alloca i1
  %l300 = alloca i1
  %l301 = alloca i1
  %l305 = alloca i1
  %l308 = alloca ptr
  %l309 = alloca { i64, [3 x i64] }
  %l311 = alloca i1
  %l312 = alloca %"compiler/msgs:Msg"
  %l313 = alloca %"compiler/msgs:Msg"
  %l315 = alloca %"compiler/msgs:Msg"
  %l316 = alloca %"compiler/interp:CondErr"
  %l330 = alloca { i64, ptr }
  %l333 = alloca { i64, ptr }
  %l334 = alloca i32
  %l343 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %rv = alloca i1
  %t40 = alloca %"compiler/interp:Exec", align 8
  %t282 = alloca { i64, [1 x i64] }, align 8
  %t335 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %s0, ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l53
  br label %bb1
bb1:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l6
  %t6 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_H19ac89f3ce4c777c1c093c5956529937(ptr %s0, ptr %l6)
  store i64 %t6, ptr %l55
  br label %bb2
bb2:
  %t7 = load i64, ptr %l55, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 64
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l60
  br label %bb5
bb4:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb6
bb5:
  %t15 = load i64, ptr %l60, !tbaa !24
  %t16 = icmp eq i64 %t15, 0
  store i1 %t16, ptr %l57, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l57, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 35
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aConstAsk_3e_2e_H7246041139e13b84a5c0718a267d329f(ptr %v1, ptr %t24)
  store i64 %t26, ptr %l66
  br label %bb9
bb8:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb10
bb9:
  %t27 = load i64, ptr %l66, !tbaa !24
  %t28 = icmp eq i64 %t27, 0
  store i1 %t28, ptr %l62, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l62, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 4
  %t39 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t38
  call void @compiler_2finterp_3aExec_2ector(ptr %t40, ptr %v1, ptr %v1, ptr %v1, ptr %t35, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t40, i64 880, i1 false)
  br label %bb14
bb14:
  %t44 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 880, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %l74, i64 880, i1 false)
  store ptr %t44, ptr %l7, !tbaa !29
  %t46 = load ptr, ptr %l7, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 69
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t49
  %t53 = getelementptr %"compiler/interp:Exec", ptr %t46, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %t53
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 73
  %t58 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t57
  %t61 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %t61
  store i1 false, ptr %l8, !tbaa !21
  %t62 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aIf_26_3e(ptr %t62)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l82
  br label %bb15
bb15:
  %t64 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l9
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 64
  store ptr %t67, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load ptr, ptr %l10, !tbaa !29
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eRunFrom_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %t69, i64 %t70)
  %t74 = extractvalue { i32, { i64, ptr } } %t73, 1
  %t75 = extractvalue { i32, { i64, ptr } } %t73, 0
  store i32 %t75, ptr %l89
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb18, label %ok.77
ok.77:
  store { i64, ptr } %t74, ptr %l88
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t78, ptr %l85, !tbaa !27
  br label %bb22
bb18:
  %t79 = load i32, ptr %l89, !tbaa !23
  %t80 = ashr i32 %t79, 16
  %t82 = icmp eq i32 %t80, 1
  br i1 %t82, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @.c120)
  unreachable
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb52
bb22:
  %t84 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t84, ptr %l12, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load i64, ptr %l14, !tbaa !24
  %t90 = load i64, ptr %l13, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb25:
  br label %bb26
bb26:
  %t97 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t97, ptr %l98, !tbaa !27
  %t98 = load i64, ptr %l14, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr %"compiler/check:Ask", ptr %t101, i64 %t98
  %t103 = load %"compiler/check:Ask", ptr %t102
  store %"compiler/check:Ask" %t103, ptr %l15
  %t105 = getelementptr %"compiler/check:Ask", ptr %l15, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = getelementptr %"compiler/check:Ask", ptr %l15, i32 0, i32 2
  %t108 = load i32, ptr %t107, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t113 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t106, i64 %t110)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t113, ptr %l104
  br label %bb27
bb27:
  %t114 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l104
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l16
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t116 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l16
  %t119 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v2, ptr %t115, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t116)
  store i1 %t119, ptr %l107
  br label %bb28
bb28:
  %t120 = load i1, ptr %l107, !tbaa !21
  br i1 %t120, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb32
bb30:
  %t121 = load ptr, ptr %l3, !tbaa !29
  %t122 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l16
  %t125 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v3, ptr %t121, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t122)
  store i1 %t125, ptr %l111
  br label %bb31
bb31:
  %t126 = load i1, ptr %l111, !tbaa !21
  store i1 %t126, ptr %l108, !tbaa !21
  br label %bb32
bb32:
  %t127 = load i1, ptr %l108, !tbaa !21
  br i1 %t127, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb49
bb34:
  br label %bb35
bb35:
  %t128 = load ptr, ptr %l7, !tbaa !29
  %t129 = getelementptr %"compiler/check:Ask", ptr %l15, i32 0, i32 0
  %t130 = load i64, ptr %t129, !tbaa !24
  %t133 = call { i1, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v1, ptr %t128, i64 %t130)
  store { i1, i1 } %t133, ptr %l114
  br label %bb36
bb36:
  %t134 = load { i1, i1 }, ptr %l114
  store { i1, i1 } %t134, ptr %l17
  %t135 = getelementptr { i1, i1 }, ptr %l17, i32 0, i32 0
  %t136 = load i1, ptr %t135, !tbaa !21
  store i1 %t136, ptr %l18, !tbaa !21
  %t138 = getelementptr { i1, i1 }, ptr %l17, i32 0, i32 1
  %t139 = load i1, ptr %t138, !tbaa !21
  store i1 %t139, ptr %l19, !tbaa !21
  %t141 = load i1, ptr %l19, !tbaa !21
  br i1 %t141, label %bb37, label %bb38
bb37:
  %t143 = load ptr, ptr %l7, !tbaa !29
  %t145 = getelementptr %"compiler/interp:Exec", ptr %t143, i32 0, i32 4
  %t146 = getelementptr %"compiler/eval:Machine", ptr %t145, i32 0, i32 12
  %t147 = load i1, ptr %t146, !tbaa !21
  %t149 = xor i1 %t147, true
  store i1 %t149, ptr %l118, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb39
bb39:
  %t151 = load i1, ptr %l118, !tbaa !21
  br i1 %t151, label %bb40, label %bb41
bb40:
  %t152 = load ptr, ptr %l3, !tbaa !29
  %t153 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l16
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v3, ptr %t152, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t153, i1 true)
  br label %bb42
bb41:
  %t156 = load i1, ptr %l19, !tbaa !21
  br i1 %t156, label %bb43, label %bb44
bb42:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb48
bb43:
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t159 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l16
  %t160 = load i1, ptr %l18, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v2, ptr %t158, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t159, i1 %t160)
  br label %bb45
bb44:
  %t164 = getelementptr %"compiler/check:Ask", ptr %l15, i32 0, i32 3
  %t165 = load ptr, ptr %t164, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aIf_26_3e_2ePush_3ccompiler_2fast_3aIf_26_3e(ptr %s0, ptr %v1, ptr %l9, ptr %t165)
  br label %bb46
bb45:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s4)
  br label %bb49
bb49:
  %t168 = load i64, ptr %l14, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l14, !tbaa !24
  br label %bb23
bb50:
  %t172 = load i64, ptr %l11, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  %t176 = add i64 %t172, %t173
  store i64 %t176, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb51:
  br label %bb16
bb52:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/generic:Program", ptr %t181, i32 0, i32 35
  store ptr %t183, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t185 = load ptr, ptr %l20, !tbaa !29
  %t186 = load i64, ptr %l21, !tbaa !24
  %t189 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aConstAsk_3e_2e_H3755acdd817c9ece2266e75be7a7be94(ptr %v1, ptr %t185, i64 %t186)
  %t190 = extractvalue { i32, { i64, ptr } } %t189, 1
  %t191 = extractvalue { i32, { i64, ptr } } %t189, 0
  store i32 %t191, ptr %l142
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb55, label %ok.193
ok.193:
  store { i64, ptr } %t190, ptr %l141
  br label %bb54
bb54:
  %t194 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t194, ptr %l138, !tbaa !27
  br label %bb59
bb55:
  %t195 = load i32, ptr %l142, !tbaa !23
  %t196 = ashr i32 %t195, 16
  %t198 = icmp eq i32 %t196, 1
  br i1 %t198, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb125
bb59:
  %t200 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t200, ptr %l22, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  store i64 %t203, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s13
  %t205 = load i64, ptr %l24, !tbaa !24
  %t206 = load i64, ptr %l23, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb123
bb62:
  br label %bb63
bb63:
  %t213 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t213, ptr %l151, !tbaa !27
  %t214 = load i64, ptr %l24, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr %"compiler/generic:ConstAsk", ptr %t217, i64 %t214
  %t219 = load %"compiler/generic:ConstAsk", ptr %t218
  store %"compiler/generic:ConstAsk" %t219, ptr %l25
  %t221 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 6
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l26, !tbaa !27
  %t224 = load ptr, ptr %l4, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t228 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v4, ptr %v1, ptr %t224, { i64, ptr } %t225)
  store i1 %t228, ptr %l157
  br label %bb64
bb64:
  %t229 = load i1, ptr %l157, !tbaa !21
  br i1 %t229, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s13)
  br label %bb122
bb66:
  br label %bb67
bb67:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 0
  %t232 = load i64, ptr %t231, !tbaa !24
  %t233 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 3
  %t234 = load i64, ptr %t233, !tbaa !24
  %t235 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 4
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t237 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 5
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t239 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t241 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 2
  %t242 = load i32, ptr %t241, !tbaa !23
  %t250 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t230, i64 %t232, i64 %t234, { i64, ptr } %t236, { i64, ptr } %t238, ptr %t240, i32 %t242)
  store i64 %t250, ptr %l165
  br label %bb68
bb68:
  %t251 = load i64, ptr %l165, !tbaa !24
  store i64 %t251, ptr %l27, !tbaa !24
  %t252 = load i64, ptr %l27, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb69, label %bb70
bb69:
  %t256 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 7
  %t257 = load i1, ptr %t256, !tbaa !21
  br i1 %t257, label %bb71, label %bb72
bb70:
  br label %bb75
bb71:
  %t259 = load ptr, ptr %l4, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 1
  %t263 = extractvalue { i64, ptr } %t260, 0
  %t264 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t262, i64 %t263)
  %t265 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = extractvalue { i64, ptr } %t266, 1
  %t270 = mul i64 %t268, 1
  %t271 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t270)
  call void @llvm.memcpy.p0.p0.i64(ptr %t271, ptr %t269, i64 %t270, i1 false)
  %t272 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  %t274 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t259, { i64, ptr } %t273, i64 %t274)
  br label %bb73
bb72:
  br label %bb74
bb73:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb122
bb75:
  %t278 = load i64, ptr %l27, !tbaa !24
  %t280 = trunc i64 %t278 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t282
  %t283 = getelementptr { i64, [1 x i64] }, ptr %t282, i32 0, i32 0
  store i64 0, ptr %t283
  %t285 = insertvalue { i32 } undef, i32 %t280, 0
  %t286 = getelementptr { i64, [1 x i64] }, ptr %t282, i32 0, i32 1
  store { i32 } %t285, ptr %t286
  %t287 = load { i64, [1 x i64] }, ptr %t282
  store { i64, [1 x i64] } %t287, ptr %l28
  %t289 = load ptr, ptr %l7, !tbaa !29
  %t290 = load { i64, [1 x i64] }, ptr %l28
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v1, ptr %t289, { i64, [1 x i64] } %t290)
  br label %bb76
bb76:
  %t293 = load ptr, ptr %l7, !tbaa !29
  %t295 = getelementptr %"compiler/interp:Exec", ptr %t293, i32 0, i32 4
  store ptr %t295, ptr %l181, !tbaa !29
  %t296 = load { i64, [1 x i64] }, ptr %l28
  store { i64, [1 x i64] } %t296, ptr %l182
  %t297 = icmp sge i64 0, 0
  br i1 %t297, label %bb77, label %bb78
bb77:
  %t299 = icmp sle i64 0, 1152921504606846975
  br i1 %t299, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @.c122)
  unreachable
bb79:
  %t301 = mul i64 0, 8
  %t302 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t301)
  %t303 = insertvalue { i64, ptr } undef, i64 0, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t305 = load ptr, ptr %l181, !tbaa !29
  %t306 = load { i64, [1 x i64] }, ptr %l182
  %t308 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v1, ptr %v1, ptr %v1, ptr %t305, { i64, [1 x i64] } %t306, { i64, ptr } %t304)
  store { i64, [5 x i64] } %t308, ptr %l186
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @.c122)
  unreachable
bb81:
  %t309 = load { i64, [5 x i64] }, ptr %l186
  store { i64, [5 x i64] } %t309, ptr %l29
  %t310 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t311)
  store %"compiler/source:Span" %t313, ptr %l188
  br label %bb82
bb82:
  %t314 = load %"compiler/source:Span", ptr %l188
  store %"compiler/source:Span" %t314, ptr %l30
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/load:Loader", ptr %t315, i32 0, i32 5
  %t318 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 0
  %t319 = load i64, ptr %t318, !tbaa !24
  %t322 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t317, i64 %t319)
  store ptr %t322, ptr %l192
  br label %bb83
bb83:
  %t323 = load ptr, ptr %l192, !tbaa !29
  %t325 = getelementptr %"compiler/load:Module", ptr %t323, i32 0, i32 4
  %t326 = load i64, ptr %t325, !tbaa !24
  %t327 = getelementptr %"compiler/source:Span", ptr %l30, i32 0, i32 0
  %t328 = load i32, ptr %t327, !tbaa !23
  %t330 = sext i32 %t328 to i64
  %t331 = getelementptr %"compiler/source:Span", ptr %l30, i32 0, i32 1
  %t332 = load i32, ptr %t331, !tbaa !23
  %t334 = sext i32 %t332 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 0
  store i64 3, ptr %t336
  %t338 = insertvalue { i64, i64, i64 } undef, i64 %t326, 0
  %t340 = insertvalue { i64, i64, i64 } %t338, i64 %t330, 1
  %t342 = insertvalue { i64, i64, i64 } %t340, i64 %t334, 2
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  store { i64, i64, i64 } %t342, ptr %t343
  %t344 = load { i64, [3 x i64] }, ptr %t335
  store { i64, [3 x i64] } %t344, ptr %l31
  %t346 = load { i64, [5 x i64] }, ptr %l29
  %t348 = extractvalue { i64, [5 x i64] } %t346, 0
  %t349 = icmp eq i64 %t348, 0
  br i1 %t349, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t351 = load ptr, ptr %l4, !tbaa !29
  store ptr %t351, ptr %l202, !tbaa !29
  %t352 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 1
  %t355 = extractvalue { i64, ptr } %t352, 0
  %t356 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t355)
  call void @olang_textcopy(ptr %t356, ptr %t354, i64 %t355)
  %t357 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t356, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = extractvalue { i64, ptr } %t358, 1
  %t362 = mul i64 %t360, 1
  %t363 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t363, ptr %t361, i64 %t362, i1 false)
  %t364 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  store { i64, ptr } %t365, ptr %l205, !tbaa !27
  %t366 = load ptr, ptr %l7, !tbaa !29
  %t368 = getelementptr %"compiler/interp:Exec", ptr %t366, i32 0, i32 4
  %t369 = load ptr, ptr %l7, !tbaa !29
  %t371 = getelementptr %"compiler/interp:Exec", ptr %t369, i32 0, i32 4
  %t372 = getelementptr %"compiler/eval:Machine", ptr %t371, i32 0, i32 8
  %t373 = load %"compiler/eval:Ptr", ptr %t372
  %t374 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 2
  %t375 = load i32, ptr %t374, !tbaa !23
  %t379 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v1, ptr %t368, %"compiler/eval:Ptr" %t373, i32 %t375)
  store i64 %t379, ptr %l211
  br label %bb87
bb87:
  %t380 = load ptr, ptr %l202, !tbaa !29
  %t381 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t382 = load i64, ptr %l211, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t380, { i64, ptr } %t381, i64 %t382)
  br label %bb88
bb88:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb121
bb89:
  %t383 = load { i64, [5 x i64] }, ptr %l29
  %t385 = extractvalue { i64, [5 x i64] } %t383, 0
  %t386 = icmp eq i64 %t385, 3
  br i1 %t386, label %bb90, label %bb91
bb90:
  %t388 = getelementptr { i64, [5 x i64] }, ptr %l29, i32 0, i32 1
  %t389 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t388, i32 0, i32 0
  %t390 = load { i64, ptr }, ptr %t389
  store { i64, ptr } %t390, ptr %l32, !tbaa !27
  br label %bb92
bb91:
  br label %bb100
bb92:
  %t392 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 7
  %t393 = load i1, ptr %t392, !tbaa !21
  br i1 %t393, label %bb93, label %bb94
bb93:
  %t395 = load ptr, ptr %l4, !tbaa !29
  %t396 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t396, 1
  %t399 = extractvalue { i64, ptr } %t396, 0
  %t400 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t399)
  call void @olang_textcopy(ptr %t400, ptr %t398, i64 %t399)
  %t401 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  %t404 = extractvalue { i64, ptr } %t402, 0
  %t405 = extractvalue { i64, ptr } %t402, 1
  %t406 = mul i64 %t404, 1
  %t407 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t406)
  call void @llvm.memcpy.p0.p0.i64(ptr %t407, ptr %t405, i64 %t406, i1 false)
  %t408 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t407, 1
  %t410 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t395, { i64, ptr } %t409, i64 %t410)
  br label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s23
  %t414 = load ptr, ptr %l1, !tbaa !29
  store ptr %t414, ptr %l221, !tbaa !29
  store ptr %l25, ptr %l222, !tbaa !29
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/load:Loader", ptr %t415, i32 0, i32 4
  %t418 = load ptr, ptr %t417, !tbaa !29
  store ptr %t418, ptr %l224, !tbaa !29
  %t419 = load { i64, [3 x i64] }, ptr %l31
  store { i64, [3 x i64] } %t419, ptr %l225
  %t420 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t422 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstArgNotComputable(ptr %v1, ptr %s23, { i64, ptr } %t420)
  store %"compiler/msgs:Msg" %t422, ptr %l227
  br label %bb96
bb95:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb99
bb96:
  %t423 = load ptr, ptr %l224, !tbaa !29
  %t424 = load { i64, [3 x i64] }, ptr %l225
  %t425 = load %"compiler/msgs:Msg", ptr %l227
  %t426 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s23, ptr %t423, { i64, [3 x i64] } %t424, %"compiler/msgs:Msg" %t425)
  store i64 %t426, ptr %l228
  br label %bb97
bb97:
  %t427 = load ptr, ptr %l221, !tbaa !29
  %t428 = load ptr, ptr %l222, !tbaa !29
  %t429 = load i64, ptr %l228, !tbaa !24
  call void @compiler_2finterp_2easkNote(ptr %v1, ptr %s13, ptr %t427, ptr %t428, i64 %t429)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s23)
  br label %bb99
bb99:
  br label %bb121
bb100:
  %t430 = load { i64, [5 x i64] }, ptr %l29
  %t432 = extractvalue { i64, [5 x i64] } %t430, 0
  %t433 = icmp eq i64 %t432, 2
  br i1 %t433, label %bb101, label %bb102
bb101:
  %t435 = getelementptr { i64, [5 x i64] }, ptr %l29, i32 0, i32 1
  %t436 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t435, i32 0, i32 0
  %t437 = load i32, ptr %t436
  store i32 %t437, ptr %l33
  br label %bb103
bb102:
  br label %bb112
bb103:
  %t439 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 7
  %t440 = load i1, ptr %t439, !tbaa !21
  br i1 %t440, label %bb104, label %bb105
bb104:
  %t442 = load ptr, ptr %l4, !tbaa !29
  %t443 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t443, 1
  %t446 = extractvalue { i64, ptr } %t443, 0
  %t447 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t446)
  call void @olang_textcopy(ptr %t447, ptr %t445, i64 %t446)
  %t448 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  %t451 = extractvalue { i64, ptr } %t449, 0
  %t452 = extractvalue { i64, ptr } %t449, 1
  %t453 = mul i64 %t451, 1
  %t454 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t453)
  call void @llvm.memcpy.p0.p0.i64(ptr %t454, ptr %t452, i64 %t453, i1 false)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t454, 1
  %t457 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t442, { i64, ptr } %t456, i64 %t457)
  br label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s27
  %t461 = load ptr, ptr %l1, !tbaa !29
  store ptr %t461, ptr %l238, !tbaa !29
  store ptr %l25, ptr %l239, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/load:Loader", ptr %t462, i32 0, i32 4
  %t465 = load ptr, ptr %t464, !tbaa !29
  store ptr %t465, ptr %l241, !tbaa !29
  %t466 = load { i64, [3 x i64] }, ptr %l31
  store { i64, [3 x i64] } %t466, ptr %l242
  %t467 = load i32, ptr %l33
  %t469 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s27, i32 %t467)
  store { i64, ptr } %t469, ptr %l244
  br label %bb107
bb106:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb111
bb107:
  %t470 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t471 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstArgNotComputable(ptr %s27, ptr %s27, { i64, ptr } %t470)
  store %"compiler/msgs:Msg" %t471, ptr %l245
  br label %bb108
bb108:
  %t472 = load ptr, ptr %l241, !tbaa !29
  %t473 = load { i64, [3 x i64] }, ptr %l242
  %t474 = load %"compiler/msgs:Msg", ptr %l245
  %t475 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s27, ptr %t472, { i64, [3 x i64] } %t473, %"compiler/msgs:Msg" %t474)
  store i64 %t475, ptr %l246
  br label %bb109
bb109:
  %t476 = load ptr, ptr %l238, !tbaa !29
  %t477 = load ptr, ptr %l239, !tbaa !29
  %t478 = load i64, ptr %l246, !tbaa !24
  call void @compiler_2finterp_2easkNote(ptr %v1, ptr %s13, ptr %t476, ptr %t477, i64 %t478)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s27)
  br label %bb111
bb111:
  br label %bb121
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb120
bb115:
  %t479 = getelementptr %"compiler/generic:ConstAsk", ptr %l25, i32 0, i32 7
  %t480 = load i1, ptr %t479, !tbaa !21
  br i1 %t480, label %bb116, label %bb117
bb116:
  %t482 = load ptr, ptr %l4, !tbaa !29
  %t483 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t483, 1
  %t486 = extractvalue { i64, ptr } %t483, 0
  %t487 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t485, i64 %t486)
  %t488 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t489 = insertvalue { i64, ptr } %t488, ptr %t487, 1
  %t491 = extractvalue { i64, ptr } %t489, 0
  %t492 = extractvalue { i64, ptr } %t489, 1
  %t493 = mul i64 %t491, 1
  %t494 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t493)
  call void @llvm.memcpy.p0.p0.i64(ptr %t494, ptr %t492, i64 %t493, i1 false)
  %t495 = insertvalue { i64, ptr } undef, i64 %t491, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t494, 1
  %t497 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t482, { i64, ptr } %t496, i64 %t497)
  br label %bb118
bb117:
  br label %bb119
bb118:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb119
bb119:
  br label %bb121
bb120:
  call void @__olang_check_failed(ptr @.c123)
  unreachable
bb121:
  call void @__olang_scope_close(ptr %s13)
  br label %bb122
bb122:
  %t501 = load i64, ptr %l24, !tbaa !24
  %t503 = add i64 %t501, 1
  store i64 %t503, ptr %l24, !tbaa !24
  br label %bb60
bb123:
  %t505 = load i64, ptr %l21, !tbaa !24
  %t506 = load i64, ptr %l23, !tbaa !24
  %t509 = add i64 %t505, %t506
  store i64 %t509, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb124
bb124:
  br label %bb53
bb125:
  store ptr %l6, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s33
  %t512 = load ptr, ptr %l34, !tbaa !29
  %t513 = load i64, ptr %l35, !tbaa !24
  %t516 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_H2d785e59a328798ef633c598d7682c46(ptr %s0, ptr %t512, i64 %t513)
  %t517 = extractvalue { i32, { i64, ptr } } %t516, 1
  %t518 = extractvalue { i32, { i64, ptr } } %t516, 0
  store i32 %t518, ptr %l263
  %t519 = icmp ne i32 %t518, 0
  br i1 %t519, label %bb128, label %ok.520
ok.520:
  store { i64, ptr } %t517, ptr %l262
  br label %bb127
bb127:
  %t521 = load { i64, ptr }, ptr %l262, !tbaa !27
  store { i64, ptr } %t521, ptr %l259, !tbaa !27
  br label %bb132
bb128:
  %t522 = load i32, ptr %l263, !tbaa !23
  %t523 = ashr i32 %t522, 16
  %t525 = icmp eq i32 %t523, 1
  br i1 %t525, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @.c124)
  unreachable
bb131:
  call void @__olang_scope_close(ptr %s33)
  br label %bb169
bb132:
  %t527 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t527, ptr %l36, !tbaa !27
  %t528 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t528, 0
  store i64 %t530, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb133
bb133:
  store %olang.scope zeroinitializer, ptr %s34
  %t532 = load i64, ptr %l38, !tbaa !24
  %t533 = load i64, ptr %l37, !tbaa !24
  %t536 = icmp slt i64 %t532, %t533
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s34)
  br label %bb167
bb135:
  br label %bb136
bb136:
  %t540 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t540, ptr %l272, !tbaa !27
  %t541 = load i64, ptr %l38, !tbaa !24
  %t543 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %t544, i64 %t541
  %t546 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %t545
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t546, ptr %l39
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = getelementptr %"compiler/load:Loader", ptr %t548, i32 0, i32 5
  %t551 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l39, i32 0, i32 0
  %t552 = load i64, ptr %t551, !tbaa !24
  %t555 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t550, i64 %t552)
  store ptr %t555, ptr %l278
  br label %bb137
bb137:
  %t556 = load ptr, ptr %l278, !tbaa !29
  %t558 = getelementptr %"compiler/load:Module", ptr %t556, i32 0, i32 8
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  %t560 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l39, i32 0, i32 1
  %t561 = load i32, ptr %t560, !tbaa !23
  %t564 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t559, i32 %t561)
  store ptr %t564, ptr %l282
  br label %bb138
bb138:
  %t565 = load ptr, ptr %l282, !tbaa !29
  store ptr %t565, ptr %l40, !tbaa !29
  %t566 = load ptr, ptr %l40, !tbaa !29
  %t568 = icmp eq ptr %t566, null
  br i1 %t568, label %bb139, label %bb140
bb139:
  call void @__olang_scope_close(ptr %s34)
  br label %bb166
bb140:
  br label %bb141
bb141:
  %t570 = load ptr, ptr %l7, !tbaa !29
  %t571 = load ptr, ptr %l1, !tbaa !29
  %t572 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l39, i32 0, i32 0
  %t573 = load i64, ptr %t572, !tbaa !24
  %t574 = load ptr, ptr %l40, !tbaa !29
  %t579 = call { i64, i1, { i64, ptr }, { i64, [3 x i64] } } @compiler_2finterp_2echain(ptr %v1, ptr %v1, ptr %v0, ptr %s34, ptr %t570, ptr %t571, i64 %t573, ptr %t574)
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t579, ptr %l289
  br label %bb142
bb142:
  %t580 = load { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l289
  store { i64, i1, { i64, ptr }, { i64, [3 x i64] } } %t580, ptr %l41
  %t581 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l41, i32 0, i32 0
  %t582 = load i64, ptr %t581, !tbaa !24
  store i64 %t582, ptr %l42, !tbaa !24
  %t584 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l41, i32 0, i32 1
  %t585 = load i1, ptr %t584, !tbaa !21
  store i1 %t585, ptr %l43, !tbaa !21
  %t587 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l41, i32 0, i32 2
  %t588 = load { i64, ptr }, ptr %t587, !tbaa !27
  store { i64, ptr } %t588, ptr %l292, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t589, 0
  store i64 %t590, ptr %l293, !tbaa !24
  %t591 = load i64, ptr %l293, !tbaa !24
  %t592 = mul i64 %t591, 1
  %t593 = call ptr @__olang_scope_alloc_zeroed(ptr %s34, i64 %t592)
  %t594 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t595 = insertvalue { i64, ptr } %t594, ptr %t593, 1
  store { i64, ptr } %t595, ptr %l294, !tbaa !27
  %t596 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !27
  %t598 = getelementptr { i64, ptr }, ptr %l292, i32 0, i32 1
  %t599 = load ptr, ptr %t598, !tbaa !27
  %t600 = load i64, ptr %l293, !tbaa !24
  %t601 = mul i64 %t600, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t597, ptr %t599, i64 %t601, i1 false)
  %t602 = load { i64, ptr }, ptr %l294, !tbaa !27
  store { i64, ptr } %t602, ptr %l44, !tbaa !27
  %t603 = getelementptr { i64, i1, { i64, ptr }, { i64, [3 x i64] } }, ptr %l41, i32 0, i32 3
  %t604 = load { i64, [3 x i64] }, ptr %t603
  store { i64, [3 x i64] } %t604, ptr %l45
  %t606 = load i1, ptr %l43, !tbaa !21
  %t608 = xor i1 %t606, true
  br i1 %t608, label %bb143, label %bb144
bb143:
  %t610 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t612 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s34, ptr %s34, { i64, ptr } %t610, { i64, ptr } { i64 0, ptr @.d125 })
  store i1 %t612, ptr %l300
  br label %bb145
bb144:
  store i1 false, ptr %l298, !tbaa !21
  br label %bb146
bb145:
  %t613 = load i1, ptr %l300, !tbaa !21
  store i1 %t613, ptr %l298, !tbaa !21
  br label %bb146
bb146:
  %t614 = load i1, ptr %l298, !tbaa !21
  br i1 %t614, label %bb147, label %bb148
bb147:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/load:Loader", ptr %t615, i32 0, i32 4
  %t618 = load ptr, ptr %t617, !tbaa !29
  %t619 = load { i64, [3 x i64] }, ptr %l45
  %t622 = call i1 @compiler_2finterp_2econdSaid(ptr %v0, ptr %t618, { i64, [3 x i64] } %t619)
  store i1 %t622, ptr %l305
  br label %bb149
bb148:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb150
bb149:
  %t623 = load i1, ptr %l305, !tbaa !21
  store i1 %t623, ptr %l301, !tbaa !21
  br label %bb150
bb150:
  %t624 = load i1, ptr %l301, !tbaa !21
  br i1 %t624, label %bb151, label %bb152
bb151:
  call void @__olang_scope_close(ptr %s34)
  br label %bb166
bb152:
  br label %bb153
bb153:
  %t625 = load i1, ptr %l43, !tbaa !21
  %t627 = xor i1 %t625, true
  br i1 %t627, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s37
  store ptr %a5, ptr %l308, !tbaa !29
  %t630 = load { i64, [3 x i64] }, ptr %l45
  store { i64, [3 x i64] } %t630, ptr %l309
  %t631 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t633 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s34, ptr %s37, { i64, ptr } %t631, { i64, ptr } { i64 0, ptr @.d126 })
  store i1 %t633, ptr %l311
  br label %bb156
bb155:
  br label %bb164
bb156:
  %t634 = load i1, ptr %l311, !tbaa !21
  br i1 %t634, label %bb157, label %bb158
bb157:
  %t635 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnseen(ptr %v5)
  store %"compiler/msgs:Msg" %t635, ptr %l313
  br label %bb159
bb158:
  %t636 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t638 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUndecidable(ptr %s34, ptr %v5, { i64, ptr } %t636)
  store %"compiler/msgs:Msg" %t638, ptr %l315
  br label %bb160
bb159:
  %t639 = load %"compiler/msgs:Msg", ptr %l313
  store %"compiler/msgs:Msg" %t639, ptr %l312
  br label %bb161
bb160:
  %t640 = load %"compiler/msgs:Msg", ptr %l315
  store %"compiler/msgs:Msg" %t640, ptr %l312
  br label %bb161
bb161:
  %t641 = load { i64, [3 x i64] }, ptr %l309
  %t642 = load %"compiler/msgs:Msg", ptr %l312
  %t643 = call %"compiler/interp:CondErr" @compiler_2finterp_3aCondErr_2ector(ptr %v5, ptr %v5, { i64, [3 x i64] } %t641, %"compiler/msgs:Msg" %t642)
  store %"compiler/interp:CondErr" %t643, ptr %l316
  br label %bb162
bb162:
  %t644 = load ptr, ptr %l308, !tbaa !29
  %t645 = load %"compiler/interp:CondErr", ptr %l316
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2finterp_3aCondErr_3e_2ePu_H06e56a62b7eaa5d9f34ed929f2594f0e(ptr %v5, ptr %v5, ptr %t644, %"compiler/interp:CondErr" %t645)
  br label %bb163
bb163:
  %t646 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store i64 %t646, ptr %l42, !tbaa !24
  call void @__olang_scope_close(ptr %s37)
  br label %bb164
bb164:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l39, i32 0, i32 0
  %t650 = load i64, ptr %t649, !tbaa !24
  %t651 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l39, i32 0, i32 1
  %t652 = load i32, ptr %t651, !tbaa !23
  %t653 = load i64, ptr %l42, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %t648, i64 %t650, i32 %t652, i64 %t653)
  br label %bb165
bb165:
  store i1 true, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s34)
  br label %bb166
bb166:
  %t658 = load i64, ptr %l38, !tbaa !24
  %t660 = add i64 %t658, 1
  store i64 %t660, ptr %l38, !tbaa !24
  br label %bb133
bb167:
  %t662 = load i64, ptr %l35, !tbaa !24
  %t663 = load i64, ptr %l37, !tbaa !24
  %t666 = add i64 %t662, %t663
  store i64 %t666, ptr %l35, !tbaa !24
  call void @__olang_scope_close(ptr %s33)
  br label %bb168
bb168:
  br label %bb126
bb169:
  %t668 = load i1, ptr %l8, !tbaa !21
  %t670 = xor i1 %t668, true
  br i1 %t670, label %bb170, label %bb171
bb170:
  store ptr %l9, ptr %l46, !tbaa !29
  store i64 0, ptr %l47, !tbaa !24
  br label %bb172
bb171:
  br label %bb188
bb172:
  store %olang.scope zeroinitializer, ptr %s41
  %t673 = load ptr, ptr %l46, !tbaa !29
  %t674 = load i64, ptr %l47, !tbaa !24
  %t677 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aIf_26_3e_2eRunFrom_3ccompiler_2fast_3aIf_26_3e(ptr %s0, ptr %t673, i64 %t674)
  %t678 = extractvalue { i32, { i64, ptr } } %t677, 1
  %t679 = extractvalue { i32, { i64, ptr } } %t677, 0
  store i32 %t679, ptr %l334
  %t680 = icmp ne i32 %t679, 0
  br i1 %t680, label %bb174, label %ok.681
ok.681:
  store { i64, ptr } %t678, ptr %l333
  br label %bb173
bb173:
  %t682 = load { i64, ptr }, ptr %l333, !tbaa !27
  store { i64, ptr } %t682, ptr %l330, !tbaa !27
  br label %bb178
bb174:
  %t683 = load i32, ptr %l334, !tbaa !23
  %t684 = ashr i32 %t683, 16
  %t686 = icmp eq i32 %t684, 1
  br i1 %t686, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  call void @__olang_check_failed(ptr @.c127)
  unreachable
bb177:
  call void @__olang_scope_close(ptr %s41)
  br label %bb187
bb178:
  %t688 = load { i64, ptr }, ptr %l330, !tbaa !27
  store { i64, ptr } %t688, ptr %l48, !tbaa !27
  %t689 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t691 = extractvalue { i64, ptr } %t689, 0
  store i64 %t691, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb179
bb179:
  store %olang.scope zeroinitializer, ptr %s42
  %t693 = load i64, ptr %l50, !tbaa !24
  %t694 = load i64, ptr %l49, !tbaa !24
  %t697 = icmp slt i64 %t693, %t694
  %t699 = xor i1 %t697, true
  br i1 %t699, label %bb180, label %bb181
bb180:
  call void @__olang_scope_close(ptr %s42)
  br label %bb185
bb181:
  br label %bb182
bb182:
  %t701 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t701, ptr %l343, !tbaa !27
  %t702 = load i64, ptr %l50, !tbaa !24
  %t704 = getelementptr { i64, ptr }, ptr %l343, i32 0, i32 1
  %t705 = load ptr, ptr %t704, !tbaa !27
  %t706 = getelementptr ptr, ptr %t705, i64 %t702
  %t707 = load ptr, ptr %t706, !tbaa !39
  %t709 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v1, ptr %s0, ptr %t709, ptr %t707)
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s42)
  br label %bb184
bb184:
  %t713 = load i64, ptr %l50, !tbaa !24
  %t715 = add i64 %t713, 1
  store i64 %t715, ptr %l50, !tbaa !24
  br label %bb179
bb185:
  %t717 = load i64, ptr %l47, !tbaa !24
  %t718 = load i64, ptr %l49, !tbaa !24
  %t721 = add i64 %t717, %t718
  store i64 %t721, ptr %l47, !tbaa !24
  call void @__olang_scope_close(ptr %s41)
  br label %bb186
bb186:
  br label %bb172
bb187:
  br label %bb188
bb188:
  %t723 = load i1, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t723, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l33 = alloca %"compiler/source:Span"
  %l40 = alloca ptr
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l5, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t35 = load ptr, ptr %l21, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = load i64, ptr %t38
  %t41 = icmp eq i64 %t39, 7
  store i1 %t41, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l22, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb24
bb12:
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = getelementptr %"compiler/ast:TopIf", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp ne ptr %t52, null
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t58 = getelementptr %"compiler/ast:TopIf", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t59)
  store %"compiler/source:Span" %t61, ptr %l33
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb15:
  %t62 = getelementptr %"compiler/source:Span", ptr %l33, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = icmp eq i32 %t63, %t64
  store i1 %t67, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l30, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t70, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t73 = load i32, ptr %l1, !tbaa !23
  %t76 = call ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %t72, i32 %t73)
  store ptr %t76, ptr %l40
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l40, !tbaa !29
  store ptr %t77, ptr %l7, !tbaa !29
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = icmp ne ptr %t78, null
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l7, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t82, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c128)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t84 = load i64, ptr %l3, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l3, !tbaa !24
  br label %bb4
bb31:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l14 = alloca ptr
  %l25 = alloca ptr
  %l32 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/ast:TopIf", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = icmp ne ptr %t9, null
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TopIf", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/ast:TopBranch", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t19, i32 %t20)
  store ptr %t23, ptr %l14
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t24 = load ptr, ptr %l14, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = icmp ne ptr %t25, null
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/ast:TopIf", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp ne ptr %t34, null
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/ast:TopIf", ptr %t38, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t44, i32 %t45)
  store ptr %t48, ptr %l25
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t49 = load ptr, ptr %l25, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = icmp ne ptr %t50, null
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l3, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/ast:TopIf", ptr %t56, i32 0, i32 2
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  %t63 = call ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %t59, i32 %t60)
  store ptr %t63, ptr %l32
  br label %bb18
bb18:
  %t64 = load ptr, ptr %l32, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2finterp_2efindTest(ptr %v0, { i64, ptr } %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t11, ptr %l12
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t12, ptr %rv
  br label %ret
bb4:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb7:
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l20, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  store ptr %t33, ptr %l5, !tbaa !29
  %t35 = load ptr, ptr %l5, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 6
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  store %"compiler/source:Span" %t48, ptr %l6
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t52, i32 0, i32 1
  %t54 = load %"compiler/source:Span", ptr %t53
  store %"compiler/source:Span" %t54, ptr %l7
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t56 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t56, ptr %l31
  %t57 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t57, ptr %l33
  %t60 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l31, ptr %l33)
  store i1 %t60, ptr %l35
  br label %bb14
bb14:
  %t61 = load i1, ptr %l35, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load %"compiler/source:Span", ptr %l7
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t62, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb33
bb18:
  %t64 = load ptr, ptr %l5, !tbaa !29
  store ptr %t64, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t65 = load ptr, ptr %l37, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 7
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l8, !tbaa !29
  br label %bb23
bb22:
  br label %bb28
bb23:
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t83 = call %"compiler/source:Span" @compiler_2finterp_2efindTestIf(ptr %v0, ptr %t79, %"compiler/source:Span" %t80)
  store %"compiler/source:Span" %t83, ptr %l45
  br label %bb24
bb24:
  %t84 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t84, ptr %l9
  %t85 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 1
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = icmp sgt i32 %t86, 0
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load %"compiler/source:Span", ptr %l9
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t90, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @.c129)
  unreachable
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l3, !tbaa !24
  br label %bb5
bb35:
  %t96 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t96, ptr %l51
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t97 = load %"compiler/source:Span", ptr %l51
  store %"compiler/source:Span" %t97, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2finterp_2efindTestIf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l6
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  %t6 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp ne ptr %t10, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t21 = load %"compiler/source:Span", ptr %l1
  %t24 = call %"compiler/source:Span" @compiler_2finterp_2efindTest(ptr %v0, { i64, ptr } %t20, %"compiler/source:Span" %t21)
  store %"compiler/source:Span" %t24, ptr %l14
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t25 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t25, ptr %l2
  %t26 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp sgt i32 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t31, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/ast:TopIf", ptr %t33, i32 0, i32 3
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp ne ptr %t36, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopIf", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TopBranch", ptr %t43, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = load %"compiler/source:Span", ptr %l1
  %t50 = call %"compiler/source:Span" @compiler_2finterp_2efindTest(ptr %v0, { i64, ptr } %t46, %"compiler/source:Span" %t47)
  store %"compiler/source:Span" %t50, ptr %l25
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t51 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t51, ptr %l3
  %t52 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t53 = load i32, ptr %t52, !tbaa !23
  %t55 = icmp sgt i32 %t53, 0
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t57 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t57, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  %t66 = call %"compiler/source:Span" @compiler_2finterp_2efindTestIf(ptr %v0, ptr %t62, %"compiler/source:Span" %t63)
  store %"compiler/source:Span" %t66, ptr %l32
  br label %bb19
bb19:
  %t67 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, i32 }
  %l4 = alloca { i64, i32 }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %a0)
  store { i64, i32 } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, i32 }, ptr %l4
  store { i64, i32 } %t4, ptr %l1
  %t5 = getelementptr { i64, i32 }, ptr %l1, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i32
  %rv = alloca { i64, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l1
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64, i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l2, !tbaa !24
  %t15 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i32, ptr %l3, !tbaa !23
  %t22 = insertvalue { i64, i32 } undef, i64 %t19, 0
  %t24 = insertvalue { i64, i32 } %t22, i32 %t20, 1
  store { i64, i32 } %t24, ptr %rv
  br label %ret
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t26 = insertvalue { i64, i32 } undef, i64 -1, 0
  %t27 = insertvalue { i64, i32 } %t26, i32 0, 1
  store { i64, i32 } %t27, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @.c130)
  unreachable
ret:
  %rr = load { i64, i32 }, ptr %rv
  ret { i64, i32 } %rr
}

define dso_local i32 @compiler_2finterp_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Block", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l6, !tbaa !29
  %t29 = load ptr, ptr %l6, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t40, i32 0, i32 1
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb9:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t58, i32 0, i32 1
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l7, !tbaa !23
  %t62 = load ptr, ptr %l6, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t68, i32 0, i32 2
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l8, !tbaa !24
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load ptr, ptr %t75
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t78, i32 0, i32 3
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l9, !tbaa !23
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t86 = icmp eq i64 %t82, %a1
  br i1 %t86, label %bb15, label %bb16
bb15:
  %t88 = load i32, ptr %l9, !tbaa !23
  %t92 = icmp eq i32 %t88, %a2
  store i1 %t92, ptr %l44, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t94 = load i1, ptr %l44, !tbaa !21
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t95 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t95, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c131)
  unreachable
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t97 = load i64, ptr %l4, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l4, !tbaa !24
  br label %bb1
bb28:
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2finterp_2ejudgeViews(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca %"compiler/views:Viewer"
  %t9 = alloca %"compiler/views:Viewer", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 4
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7
  call void @compiler_2fviews_3aViewer_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v0, ptr %t4, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t9, i64 216, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 216, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l6, i64 216, i1 false)
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %t12)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t10 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %a0, i64 %a1, i64 %t6)
  store { i64, ptr } %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr @.d132 })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l13
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store i64 %t15, ptr %l12
  br label %bb2
bb2:
  %t19 = load i64, ptr %l12, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l10, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %l17, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = icmp sge i64 0, 0
  br i1 %t28, label %bb8, label %bb9
bb7:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = extractvalue { i64, ptr } %t30, 0
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t32, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l16, !tbaa !27
  br label %bb14
bb8:
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sle i64 0, %t38
  br i1 %t39, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c133)
  unreachable
bb10:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = load i64, ptr %l18, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c133)
  unreachable
bb12:
  %t45 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l17, !tbaa !24
  %t48 = getelementptr i8, ptr %t46, i64 0
  %t49 = sub i64 %t47, 0
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l16, !tbaa !27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c133)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l11 = alloca i1
  %l16 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l30 = alloca { i64, [3 x i64] }
  %l31 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %t47 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i64 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t5, %t6
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t20 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t11, i64 %t12, i64 %t16)
  store i64 %t20, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t21, i64 %t22, i64 %t26)
  store i64 %t30, ptr %l21
  br label %bb7
bb7:
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = icmp eq i64 %t31, %t32
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i64 %a1, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t40 = load i32, ptr %t39, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = sext i32 %t44 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 0
  store i64 3, ptr %t48
  %t50 = insertvalue { i64, i64, i64 } undef, i64 %t38, 0
  %t52 = insertvalue { i64, i64, i64 } %t50, i64 %t42, 1
  %t54 = insertvalue { i64, i64, i64 } %t52, i64 %t46, 2
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  store { i64, i64, i64 } %t54, ptr %t55
  %t56 = load { i64, [3 x i64] }, ptr %t47
  store { i64, [3 x i64] } %t56, ptr %l30
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s0)
  store %"compiler/msgs:Msg" %t57, ptr %l31
  br label %bb12
bb12:
  %t58 = load ptr, ptr %l23, !tbaa !29
  %t59 = load i64, ptr %l24, !tbaa !24
  %t60 = load { i64, [3 x i64] }, ptr %l30
  %t61 = load %"compiler/msgs:Msg", ptr %l31
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t58, i64 %t59, { i64, [3 x i64] } %t60, %"compiler/msgs:Msg" %t61)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c134)
  unreachable
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c135)
  unreachable
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, %"compiler/source:Span" }
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l15 = alloca { i64, [3 x i64] }
  %l16 = alloca %"compiler/msgs:Msg"
  %l19 = alloca { i64, %"compiler/source:Span" }
  %l24 = alloca ptr
  %l25 = alloca i64
  %l31 = alloca { i64, [3 x i64] }
  %l32 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t12 = alloca { i64, [3 x i64] }, align 8
  %t54 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  store i64 %t2, ptr %l9, !tbaa !24
  %t4 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t8 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t15 = insertvalue { i64, i64, i64 } undef, i64 %a3, 0
  %t17 = insertvalue { i64, i64, i64 } %t15, i64 %t7, 1
  %t19 = insertvalue { i64, i64, i64 } %t17, i64 %t11, 2
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t12, i32 0, i32 1
  store { i64, i64, i64 } %t19, ptr %t20
  %t21 = load { i64, [3 x i64] }, ptr %t12
  store { i64, [3 x i64] } %t21, ptr %l15
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s0)
  store %"compiler/msgs:Msg" %t22, ptr %l16
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l8, !tbaa !29
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = load { i64, [3 x i64] }, ptr %l15
  %t26 = load %"compiler/msgs:Msg", ptr %l16
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v1, ptr %s0, ptr %t23, i64 %t24, { i64, [3 x i64] } %t25, %"compiler/msgs:Msg" %t26)
  br label %bb2
bb2:
  %t29 = getelementptr %"compiler/interp:Exec", ptr %a0, i32 0, i32 4
  %t31 = call { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %t29)
  store { i64, %"compiler/source:Span" } %t31, ptr %l19
  br label %bb3
bb3:
  %t32 = load { i64, %"compiler/source:Span" }, ptr %l19
  store { i64, %"compiler/source:Span" } %t32, ptr %l5
  %t33 = getelementptr { i64, %"compiler/source:Span" }, ptr %l5, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, %"compiler/source:Span" }, ptr %l5, i32 0, i32 1
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l7
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l25, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t50 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = sext i32 %t51 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 0
  store i64 3, ptr %t55
  %t57 = insertvalue { i64, i64, i64 } undef, i64 %t45, 0
  %t59 = insertvalue { i64, i64, i64 } %t57, i64 %t49, 1
  %t61 = insertvalue { i64, i64, i64 } %t59, i64 %t53, 2
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 1
  store { i64, i64, i64 } %t61, ptr %t62
  %t63 = load { i64, [3 x i64] }, ptr %t54
  store { i64, [3 x i64] } %t63, ptr %l31
  %t64 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrewHere(ptr %s1)
  store %"compiler/msgs:Msg" %t64, ptr %l32
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t65 = load ptr, ptr %l24, !tbaa !29
  %t66 = load i64, ptr %l25, !tbaa !24
  %t67 = load { i64, [3 x i64] }, ptr %l31
  %t68 = load %"compiler/msgs:Msg", ptr %l32
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v1, ptr %s1, ptr %t65, i64 %t66, { i64, [3 x i64] } %t67, %"compiler/msgs:Msg" %t68)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %v1, { i64, [5 x i64] } %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca { i64, [5 x i64] }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, ptr }
  %l13 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l32 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  store { i64, [5 x i64] } %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr @.d136 }, ptr %l10, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t7 = load %"compiler/source:Span", ptr %l1
  %t9 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t6, 0
  %t10 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t9, i64 -1, 1
  %t12 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t10, %"compiler/source:Span" %t7, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t12, ptr %l13
  %t13 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l14, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13, i32 0, i32 0
  store { i64, ptr } %t28, ptr %t29, !tbaa !27
  %t30 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t30, ptr %rv
  br label %ret
bb4:
  %t31 = load { i64, [5 x i64] }, ptr %l0
  %t33 = extractvalue { i64, [5 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 3
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t36 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t37 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t36, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37
  store { i64, ptr } %t38, ptr %l2, !tbaa !27
  %t40 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t41 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t40, i32 0, i32 1
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t44, i32 0, i32 2
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l4
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = extractvalue { i64, ptr } %t48, 0
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t50, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load %"compiler/source:Span", ptr %l4
  %t58 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t54, 0
  %t60 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t58, i64 %t55, 1
  %t62 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t60, %"compiler/source:Span" %t56, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t62, ptr %rv
  br label %ret
bb8:
  %t64 = load { i64, [5 x i64] }, ptr %l0
  %t66 = extractvalue { i64, [5 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 2
  br i1 %t67, label %bb9, label %bb10
bb9:
  %t69 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t70 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l5
  %t73 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t74 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t73, i32 0, i32 1
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t78 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t77, i32 0, i32 2
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l7
  br label %bb11
bb10:
  br label %bb20
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load i32, ptr %l5
  store i32 %t81, ptr %l32
  store i32 3, ptr %l34
  %t84 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %l32, ptr %l34)
  store i1 %t84, ptr %l36
  br label %bb12
bb12:
  %t85 = load i1, ptr %l36, !tbaa !21
  br i1 %t85, label %bb13, label %bb14
bb13:
  %t86 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t92 = icmp eq i32 %t87, %t89
  store i1 %t92, ptr %l37, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb15
bb15:
  %t94 = load i1, ptr %l37, !tbaa !21
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 40, ptr @.d137 }, ptr %l41, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t96 = load %"compiler/source:Span", ptr %l1
  %t98 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t95, 0
  %t99 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t98, i64 -1, 1
  %t101 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t99, %"compiler/source:Span" %t96, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t101, ptr %l44
  %t102 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l44, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l45, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l46, !tbaa !24
  %t106 = load i64, ptr %l46, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l47, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l46, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t118 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l44, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  %t119 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l44
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t119, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t120 = load i32, ptr %l5
  %t122 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s4, i32 %t120)
  store { i64, ptr } %t122, ptr %l49
  br label %bb19
bb19:
  %t123 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t129 = load i64, ptr %l6, !tbaa !24
  %t130 = load %"compiler/source:Span", ptr %l7
  %t132 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t128, 0
  %t134 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t132, i64 %t129, 1
  %t136 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t134, %"compiler/source:Span" %t130, 2
  call void @__olang_scope_close(ptr %s4)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t136, ptr %rv
  br label %ret
bb20:
  %t138 = load { i64, [5 x i64] }, ptr %l0
  %t140 = extractvalue { i64, [5 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 1
  br i1 %t141, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 40, ptr @.d138 }, ptr %l56, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t144 = load %"compiler/source:Span", ptr %l1
  %t146 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t143, 0
  %t147 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t146, i64 -1, 1
  %t149 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t147, %"compiler/source:Span" %t144, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t149, ptr %l59
  %t150 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l59, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  store { i64, ptr } %t151, ptr %l60, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  store i64 %t153, ptr %l61, !tbaa !24
  %t154 = load i64, ptr %l61, !tbaa !24
  %t155 = mul i64 %t154, 1
  %t156 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t155)
  %t157 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l62, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = load i64, ptr %l61, !tbaa !24
  %t164 = mul i64 %t163, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t160, ptr %t162, i64 %t164, i1 false)
  %t165 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t166 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l59, i32 0, i32 0
  store { i64, ptr } %t165, ptr %t166, !tbaa !27
  %t167 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l59
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t167, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @.c139)
  unreachable
ret:
  %rr = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %rv
  ret { { i64, ptr }, i64, %"compiler/source:Span" } %rr
}

define dso_local i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:VarDecl", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:VarDecl", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l1, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t30, i32 0, i32 2
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load i1, ptr %l2, !tbaa !21
  store i1 %t34, ptr %l12, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c140)
  unreachable
bb17:
  %t36 = load i1, ptr %l12, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, [3 x i64] }, { i64, ptr } } @compiler_2finterp_2ezeroUseArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i8
  %l9 = alloca i8
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %lp13 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l29 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l74 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i1
  %l83 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l131 = alloca i1
  %l132 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l143 = alloca i1
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l163 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i64
  %l184 = alloca { i64, ptr }
  %l186 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l193 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %t377 = alloca { i64, [3 x i64] }, align 8
  store { i64, [3 x i64] } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [3 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [3 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t15 = getelementptr { i64, i64, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  br label %bb98
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %t19)
  store { i64, ptr } %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load i64, ptr %l7, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = add i64 %t26, %t29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sle i64 %t32, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = add i64 %t38, %t41
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t50 = icmp sle i64 %t44, %t47
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l29, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb97
bb10:
  br label %bb11
bb11:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l39, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = add i64 %t57, %t60
  store i64 %t63, ptr %l43, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l44, !tbaa !24
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = load i64, ptr %l39, !tbaa !24
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c141)
  unreachable
bb14:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c141)
  unreachable
bb16:
  %t77 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = load i64, ptr %l43, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t84, { i64, ptr } %t85)
  store i1 %t88, ptr %l50
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @.c141)
  unreachable
bb18:
  %t89 = load i1, ptr %l50, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  store i1 %t92, ptr %l51, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = add i64 %t95, %t98
  %t102 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t107 = icmp slt i64 %t101, %t104
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l54, !tbaa !21
  br i1 %t109, label %bb25, label %bb26
bb25:
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = sub i64 %t111, 1
  %t115 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i8, ptr %t116, i64 %t113
  %t118 = load i8, ptr %t117, !tbaa !32
  store i8 %t118, ptr %l8, !tbaa !22
  %t120 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t120, ptr %l66, !tbaa !27
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t127 = add i64 %t121, %t124
  %t129 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 %t127
  %t132 = load i8, ptr %t131, !tbaa !32
  store i8 %t132, ptr %l9, !tbaa !22
  %t134 = load i8, ptr %l8, !tbaa !22
  %t136 = icmp eq i8 %t134, 60
  br i1 %t136, label %bb27, label %bb28
bb26:
  br label %bb95
bb27:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb29
bb28:
  %t138 = load i8, ptr %l8, !tbaa !22
  %t140 = icmp eq i8 %t138, 32
  store i1 %t140, ptr %l74, !tbaa !21
  br label %bb29
bb29:
  %t142 = load i1, ptr %l74, !tbaa !21
  br i1 %t142, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb32
bb31:
  %t143 = load i8, ptr %l8, !tbaa !22
  %t145 = icmp eq i8 %t143, 44
  store i1 %t145, ptr %l77, !tbaa !21
  br label %bb32
bb32:
  %t147 = load i1, ptr %l77, !tbaa !21
  br i1 %t147, label %bb33, label %bb34
bb33:
  %t148 = load i8, ptr %l9, !tbaa !22
  %t150 = icmp eq i8 %t148, 62
  br i1 %t150, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb38
bb35:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb37
bb36:
  %t152 = load i8, ptr %l9, !tbaa !22
  %t154 = icmp eq i8 %t152, 44
  store i1 %t154, ptr %l83, !tbaa !21
  br label %bb37
bb37:
  %t156 = load i1, ptr %l83, !tbaa !21
  store i1 %t156, ptr %l80, !tbaa !21
  br label %bb38
bb38:
  %t157 = load i1, ptr %l80, !tbaa !21
  br i1 %t157, label %bb39, label %bb40
bb39:
  %t158 = load i64, ptr %l7, !tbaa !24
  %t160 = sub i64 %t158, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb41
bb40:
  br label %bb94
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t162 = load i64, ptr %l10, !tbaa !24
  %t163 = load i64, ptr %l4, !tbaa !24
  %t166 = icmp sgt i64 %t162, %t163
  br i1 %t166, label %bb42, label %bb43
bb42:
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t168, ptr %l92, !tbaa !27
  %t169 = load i64, ptr %l10, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i8, ptr %t172, i64 %t169
  %t174 = load i8, ptr %t173, !tbaa !32
  %t176 = icmp ne i8 %t174, 60
  store i1 %t176, ptr %l91, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb44
bb44:
  %t178 = load i1, ptr %l91, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t183 = sub i64 %t181, 1
  store i64 %t183, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  br label %bb41
bb49:
  %t185 = load i64, ptr %l10, !tbaa !24
  store i64 %t185, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s6
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i64, ptr %l4, !tbaa !24
  %t191 = icmp sgt i64 %t187, %t188
  br i1 %t191, label %bb51, label %bb52
bb51:
  %t193 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t193, ptr %l104, !tbaa !27
  %t194 = load i64, ptr %l11, !tbaa !24
  %t196 = sub i64 %t194, 1
  %t198 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i8, ptr %t199, i64 %t196
  %t201 = load i8, ptr %t200, !tbaa !32
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t201)
  store i1 %t203, ptr %l108
  br label %bb53
bb52:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb61
bb53:
  %t204 = load i1, ptr %l108, !tbaa !21
  br i1 %t204, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb57
bb55:
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t205, ptr %l110, !tbaa !27
  %t206 = load i64, ptr %l11, !tbaa !24
  %t208 = sub i64 %t206, 1
  %t210 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i8, ptr %t211, i64 %t208
  %t213 = load i8, ptr %t212, !tbaa !32
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t213)
  store i1 %t215, ptr %l114
  br label %bb56
bb56:
  %t216 = load i1, ptr %l114, !tbaa !21
  store i1 %t216, ptr %l109, !tbaa !21
  br label %bb57
bb57:
  %t217 = load i1, ptr %l109, !tbaa !21
  br i1 %t217, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb60
bb59:
  %t218 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t218, ptr %l116, !tbaa !27
  %t219 = load i64, ptr %l11, !tbaa !24
  %t221 = sub i64 %t219, 1
  %t223 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i8, ptr %t224, i64 %t221
  %t226 = load i8, ptr %t225, !tbaa !32
  %t228 = icmp eq i8 %t226, 95
  store i1 %t228, ptr %l115, !tbaa !21
  br label %bb60
bb60:
  %t230 = load i1, ptr %l115, !tbaa !21
  store i1 %t230, ptr %l103, !tbaa !21
  br label %bb61
bb61:
  %t231 = load i1, ptr %l103, !tbaa !21
  %t232 = xor i1 %t231, true
  br i1 %t232, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb63:
  br label %bb64
bb64:
  %t234 = load i64, ptr %l11, !tbaa !24
  %t236 = sub i64 %t234, 1
  store i64 %t236, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb65
bb65:
  br label %bb50
bb66:
  %t238 = load i64, ptr %l7, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t244 = add i64 %t238, %t241
  store i64 %t244, ptr %l12, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s7
  %t246 = load i64, ptr %l12, !tbaa !24
  %t247 = load i64, ptr %l5, !tbaa !24
  %t250 = icmp slt i64 %t246, %t247
  br i1 %t250, label %bb68, label %bb69
bb68:
  %t252 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t252, ptr %l132, !tbaa !27
  %t253 = load i64, ptr %l12, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i8, ptr %t256, i64 %t253
  %t258 = load i8, ptr %t257, !tbaa !32
  %t260 = icmp ne i8 %t258, 62
  store i1 %t260, ptr %l131, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb70
bb70:
  %t262 = load i1, ptr %l131, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb72:
  br label %bb73
bb73:
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb74
bb74:
  br label %bb67
bb75:
  %t269 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t269, ptr %l139, !tbaa !27
  %t270 = load i64, ptr %l10, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i8, ptr %t273, i64 %t270
  %t275 = load i8, ptr %t274, !tbaa !32
  %t277 = icmp eq i8 %t275, 60
  br i1 %t277, label %bb76, label %bb77
bb76:
  %t279 = load i64, ptr %l12, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t285 = icmp slt i64 %t279, %t282
  store i1 %t285, ptr %l143, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb78
bb78:
  %t287 = load i1, ptr %l143, !tbaa !21
  br i1 %t287, label %bb79, label %bb80
bb79:
  %t288 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t288, ptr %l148, !tbaa !27
  %t289 = load i64, ptr %l11, !tbaa !24
  store i64 %t289, ptr %l149, !tbaa !24
  %t290 = load i64, ptr %l7, !tbaa !24
  %t291 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t291, 0
  %t296 = add i64 %t290, %t293
  store i64 %t296, ptr %l153, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  store i64 %t298, ptr %l154, !tbaa !24
  %t299 = load i64, ptr %l149, !tbaa !24
  %t300 = icmp sge i64 %t299, 0
  br i1 %t300, label %bb81, label %bb82
bb80:
  br label %bb93
bb81:
  %t302 = load i64, ptr %l149, !tbaa !24
  %t303 = load i64, ptr %l153, !tbaa !24
  %t304 = icmp sle i64 %t302, %t303
  br i1 %t304, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @.c142)
  unreachable
bb83:
  %t306 = load i64, ptr %l153, !tbaa !24
  %t307 = load i64, ptr %l154, !tbaa !24
  %t308 = icmp sle i64 %t306, %t307
  br i1 %t308, label %bb85, label %bb86
bb84:
  call void @__olang_check_failed(ptr @.c142)
  unreachable
bb85:
  %t310 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = load i64, ptr %l149, !tbaa !24
  %t313 = load i64, ptr %l153, !tbaa !24
  %t314 = getelementptr i8, ptr %t311, i64 %t312
  %t315 = sub i64 %t313, %t312
  %t316 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t314, 1
  store { i64, ptr } %t317, ptr %l158, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t318, ptr %l159, !tbaa !27
  %t319 = load i64, ptr %l7, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t325 = add i64 %t319, %t322
  store i64 %t325, ptr %l163, !tbaa !24
  %t326 = load i64, ptr %l12, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l165, !tbaa !24
  %t329 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  store i64 %t330, ptr %l166, !tbaa !24
  %t331 = load i64, ptr %l163, !tbaa !24
  %t332 = icmp sge i64 %t331, 0
  br i1 %t332, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @.c142)
  unreachable
bb87:
  %t334 = load i64, ptr %l163, !tbaa !24
  %t335 = load i64, ptr %l165, !tbaa !24
  %t336 = icmp sle i64 %t334, %t335
  br i1 %t336, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @.c142)
  unreachable
bb89:
  %t338 = load i64, ptr %l165, !tbaa !24
  %t339 = load i64, ptr %l166, !tbaa !24
  %t340 = icmp sle i64 %t338, %t339
  br i1 %t340, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @.c142)
  unreachable
bb91:
  %t342 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = load i64, ptr %l163, !tbaa !24
  %t345 = load i64, ptr %l165, !tbaa !24
  %t346 = getelementptr i8, ptr %t343, i64 %t344
  %t347 = sub i64 %t345, %t344
  %t348 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t346, 1
  %t350 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } { i64 1, ptr @.d143 }, 1
  %t354 = extractvalue { i64, ptr } { i64 1, ptr @.d143 }, 0
  %t355 = add i64 %t352, %t354
  %t357 = extractvalue { i64, ptr } %t349, 1
  %t358 = extractvalue { i64, ptr } %t349, 0
  %t359 = add i64 %t355, %t358
  %t360 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t359)
  call void @olang_textcopy(ptr %t360, ptr %t351, i64 %t352)
  %t361 = getelementptr i8, ptr %t360, i64 %t352
  call void @olang_textcopy(ptr %t361, ptr %t353, i64 %t354)
  %t362 = getelementptr i8, ptr %t361, i64 %t354
  call void @olang_textcopy(ptr %t362, ptr %t357, i64 %t358)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t360, 1
  %t365 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t365, ptr %lp13
  %t367 = load ptr, ptr %lp13
  store { i64, ptr } %t364, ptr %t367, !tbaa !27
  %t368 = load i64, ptr %l3, !tbaa !24
  %t369 = load i64, ptr %l7, !tbaa !24
  %t370 = load i64, ptr %l7, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t371, 0
  %t376 = add i64 %t370, %t373
  store { i64, [3 x i64] } zeroinitializer, ptr %t377
  %t378 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 0
  store i64 3, ptr %t378
  %t380 = insertvalue { i64, i64, i64 } undef, i64 %t368, 0
  %t382 = insertvalue { i64, i64, i64 } %t380, i64 %t369, 1
  %t384 = insertvalue { i64, i64, i64 } %t382, i64 %t376, 2
  %t385 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 1
  store { i64, i64, i64 } %t384, ptr %t385
  %t386 = load { i64, [3 x i64] }, ptr %t377
  %t387 = load ptr, ptr %lp13
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  %t390 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t386, 0
  %t392 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t390, { i64, ptr } %t388, 1
  call void @__olang_scope_close(ptr %s2)
  store { { i64, [3 x i64] }, { i64, ptr } } %t392, ptr %rv
  br label %ret
bb92:
  call void @__olang_check_failed(ptr @.c142)
  unreachable
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t394 = load i64, ptr %l7, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb96:
  br label %bb5
bb97:
  %t398 = load { i64, [3 x i64] }, ptr %l1
  store { i64, ptr } { i64 0, ptr @.d144 }, ptr %l184, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t401 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t398, 0
  %t403 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t401, { i64, ptr } %t399, 1
  store { { i64, [3 x i64] }, { i64, ptr } } %t403, ptr %l186
  %t404 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186, i32 0, i32 1
  %t405 = load { i64, ptr }, ptr %t404, !tbaa !27
  store { i64, ptr } %t405, ptr %l187, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  store i64 %t407, ptr %l188, !tbaa !24
  %t408 = load i64, ptr %l188, !tbaa !24
  %t409 = mul i64 %t408, 1
  %t410 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t409)
  %t411 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  store { i64, ptr } %t412, ptr %l189, !tbaa !27
  %t413 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = load i64, ptr %l188, !tbaa !24
  %t418 = mul i64 %t417, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t414, ptr %t416, i64 %t418, i1 false)
  %t419 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t420 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186, i32 0, i32 1
  store { i64, ptr } %t419, ptr %t420, !tbaa !27
  %t421 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186
  store { { i64, [3 x i64] }, { i64, ptr } } %t421, ptr %rv
  br label %ret
bb98:
  %t422 = load { i64, [3 x i64] }, ptr %l1
  store { i64, ptr } { i64 0, ptr @.d145 }, ptr %l191, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t425 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t422, 0
  %t427 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t425, { i64, ptr } %t423, 1
  store { { i64, [3 x i64] }, { i64, ptr } } %t427, ptr %l193
  %t428 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193, i32 0, i32 1
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  store { i64, ptr } %t429, ptr %l194, !tbaa !27
  %t430 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t430, 0
  store i64 %t431, ptr %l195, !tbaa !24
  %t432 = load i64, ptr %l195, !tbaa !24
  %t433 = mul i64 %t432, 1
  %t434 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t433)
  %t435 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t436 = insertvalue { i64, ptr } %t435, ptr %t434, 1
  store { i64, ptr } %t436, ptr %l196, !tbaa !27
  %t437 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = load i64, ptr %l195, !tbaa !24
  %t442 = mul i64 %t441, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t438, ptr %t440, i64 %t442, i1 false)
  %t443 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t444 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193, i32 0, i32 1
  store { i64, ptr } %t443, ptr %t444, !tbaa !27
  %t445 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193
  store { { i64, [3 x i64] }, { i64, ptr } } %t445, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %rv
  ret { { i64, [3 x i64] }, { i64, ptr } } %rr
}

define dso_local %"compiler/interp:CondErr" @compiler_2finterp_3aCondErr_2ector(ptr %v0, ptr %v1, { i64, [3 x i64] } %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %rv = alloca %"compiler/interp:CondErr"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/interp:CondErr" undef, { i64, [3 x i64] } %a0, 0
  %t8 = insertvalue %"compiler/interp:CondErr" %t6, %"compiler/msgs:Msg" %a1, 1
  store %"compiler/interp:CondErr" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/interp:CondErr", ptr %rv
  ret %"compiler/interp:CondErr" %rr
}

define dso_local void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i32
  %l6 = alloca %"compiler/lower:Lowerer"
  %l7 = alloca %"compiler/eval:Machine"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"compiler/lower:Lowerer"
  %l25 = alloca %"compiler/eval:Machine"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"compiler/interp:Exec"
  %t17 = alloca %"compiler/eval:Machine", align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t11 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %t7, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  store %"compiler/lower:Lowerer" %t11, ptr %l21
  br label %bb1
bb1:
  %t12 = load %"compiler/lower:Lowerer", ptr %l21
  store %"compiler/lower:Lowerer" %t12, ptr %l6
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l2
  call void @compiler_2feval_2eNewMachine(ptr %t17, ptr %v0, ptr %v2, ptr %t15, i32 %t16)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t17, i64 696, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l25, i64 696, i1 false)
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t20)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l26
  br label %bb3
bb3:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l8
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %t23)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l27
  br label %bb4
bb4:
  %t25 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l9
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t26)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l28
  br label %bb5
bb5:
  %t28 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l10
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t29)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l29
  br label %bb6
bb6:
  %t31 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l11
  %t32 = load ptr, ptr @__olang_prog_scope
  %t33 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t32)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l30
  br label %bb7
bb7:
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l12
  %t35 = load ptr, ptr @__olang_prog_scope
  %t36 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t35)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l31
  br label %bb8
bb8:
  %t37 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l13
  %t38 = load ptr, ptr @__olang_prog_scope
  %t39 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t38)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l32
  br label %bb9
bb9:
  %t40 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  %t41 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 0
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %t41, !tbaa !29
  %t43 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 1
  %t44 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %t43
  %t45 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 2
  %t46 = load i32, ptr %l5
  store i32 %t46, ptr %t45
  %t47 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 3
  %t48 = load %"compiler/lower:Lowerer", ptr %l6
  store %"compiler/lower:Lowerer" %t48, ptr %t47
  %t49 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %l7, i64 696, i1 false)
  %t50 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 5
  %t51 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %t50
  %t52 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 6
  %t53 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %t52
  %t54 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 7
  %t55 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %t54
  %t56 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 8
  %t57 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %t56
  %t58 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 9
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %t58
  %t60 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 10
  %t61 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %t60
  %t62 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %t62
  %t64 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 12
  store i1 false, ptr %t64, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l33, i64 880, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant [53 x i8] c"it reaches unreachable code, which aborts the program"
@.d1 = private constant [50 x i8] c"an assertion in it fails, which aborts the program"
@.d2 = private constant [48 x i8] c"it slices out of range, which aborts the program"
@.d3 = private constant [68 x i8] c"it makes an array of a length out of range, which aborts the program"
@.d4 = private constant [81 x i8] c"it copies an array of another length into fixed storage, which aborts the program"
@.d5 = private constant [45 x i8] c"an 'as' that does not hold aborts the program"
@.d6 = private constant [44 x i8] c"an error reaches '!', which ends the program"
@.d7 = private constant [39 x i8] c"an error leaves the test, which ends it"
@.d8 = private constant [31 x i8] c"it ends the test or the process"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2finterp_3aCondErr_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2finterp_3aCondErr_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr)
@.c9 = private unnamed_addr constant [52 x i8] c"compiler/interp.olang:52: reached unreachable code\0A\00"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c10 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:422: reached unreachable code\0A\00"
@.c11 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:425: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c12 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:428: reached unreachable code\0A\00"
@.c13 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:423: reached unreachable code\0A\00"
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c14 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:464: reached unreachable code\0A\00"
@.c15 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:468: array length out of range\0A\00"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.c16 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:480: reached unreachable code\0A\00"
@.c17 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:481: reached unreachable code\0A\00"
@.c18 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:265: reached unreachable code\0A\00"
@.c19 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:270: array length out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d20 = private constant [0 x i8] c""
@.d21 = private constant [0 x i8] c""
@.c22 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:272: reached unreachable code\0A\00"
@.c23 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:316: reached unreachable code\0A\00"
@.c24 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:321: array length out of range\0A\00"
@.d25 = private constant [0 x i8] c""
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcheck_3aValueKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  br label %bb3
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i64 }, ptr %t47, i32 0, i32 1
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i64 }, ptr %t51, i32 0, i32 1
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64, i64 }, ptr %t71, i32 0, i32 2
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb12, label %bb1
bb12:
  br label %bb3
bb13:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d26 = private constant [0 x i8] c""
@.d27 = private constant [0 x i8] c""
@.d28 = private constant [0 x i8] c""
@.d29 = private constant [23 x i8] c"an error escapes, code "
declare i64 @__olang_fmt_i64(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d30 = private constant [2 x i8] c": "
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [0 x i8] c""
@.d33 = private constant [2 x i8] c": "
@.d34 = private constant [2 x i8] c": "
@.d35 = private constant [2 x i8] c": "
@.d36 = private constant [2 x i8] c": "
@.c37 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:841: reached unreachable code\0A\00"
@.d38 = private constant [17 x i8] c"instantiated here"
@.d39 = private constant [7 x i8] c", with "
@.d40 = private constant [2 x i8] c", "
@.d41 = private constant [3 x i8] c" = "
@.d42 = private constant [0 x i8] c""
@.d43 = private constant [0 x i8] c""
@.d44 = private constant [2 x i8] c" ("
@.d45 = private constant [1 x i8] c")"
@.d46 = private constant [2 x i8] c" ("
@.d47 = private constant [1 x i8] c")"
@.d48 = private constant [40 x i8] c"it fails with an error no clause handles"
@.c49 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:210: reached unreachable code\0A\00"
@.d50 = private constant [0 x i8] c""
@.d51 = private constant [0 x i8] c""
@.d52 = private constant [0 x i8] c""
@.c53 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:574: array length out of range\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %a0, ptr %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr %a0, !tbaa !24
  %t4 = load i64, ptr %a1, !tbaa !24
  %t7 = icmp eq i64 %t2, %t4
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c54 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:583: array length out of range\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d55 = private constant [4 x i8] c"main"
@.c56 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:785: reached unreachable code\0A\00"
@.c57 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:870: reached unreachable code\0A\00"
@.c58 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:871: reached unreachable code\0A\00"
@.c59 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:592: array length out of range\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3aMode(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c60 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:715: reached unreachable code\0A\00"
@.c61 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:730: reached unreachable code\0A\00"
@.d62 = private constant [8 x i8] c"no main\0A"
@.c63 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:920: array length out of range\0A\00"
@.d64 = private constant [1 x i8] c"\0A"
@.d65 = private constant [17 x i8] c"olang interpret: "
@.d66 = private constant [1 x i8] c"\0A"
@.d67 = private constant [17 x i8] c"olang interpret: "
@.d68 = private constant [20 x i8] c": the Vec grew here\0A"
@.d69 = private constant [1 x i8] c"\0A"
@.d70 = private constant [1 x i8] c"\0A"
@.c71 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:921: reached unreachable code\0A\00"
@.c72 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:886: reached unreachable code\0A\00"
@.c73 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:890: reached unreachable code\0A\00"
@.d74 = private constant [5 x i8] c"ok - "
@.d75 = private constant [1 x i8] c"\0A"
@.d76 = private constant [0 x i8] c""
@.d77 = private constant [1 x i8] c"\0A"
@.d78 = private constant [7 x i8] c"FAIL - "
@.d79 = private constant [1 x i8] c"\0A"
@.d80 = private constant [9 x i8] c" passed, "
@.d81 = private constant [8 x i8] c" failed\0A"
@.d82 = private constant [17 x i8] c"unhandled error: "
@.d83 = private constant [31 x i8] c" - here in the task spawned at "
@.c84 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:954: reached unreachable code\0A\00"
@.d85 = private constant [4 x i8] c"test"
@.c86 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:805: slice bounds out of range\0A\00"
@.d87 = private constant [0 x i8] c""
@.c88 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:565: array length out of range\0A\00"
@.d89 = private constant [0 x i8] c""
@.d90 = private constant [1 x i8] c"("
@.d91 = private constant [26 x i8] c" earlier places not kept)\0A"
@.d92 = private constant [11 x i8] c"raised here"
@.d93 = private constant [16 x i8] c"try passed it on"
@.d94 = private constant [40 x i8] c"a task failed, and its join passed it on"
@.d95 = private constant [2 x i8] c": "
@.d96 = private constant [1 x i8] c"\0A"
@.d97 = private constant [4 x i8] c"std/"
@.d98 = private constant [4 x i8] c"Bool"
@.d99 = private constant [3 x i8] c"I32"
@.d100 = private constant [3 x i8] c"I64"
@.d101 = private constant [3 x i8] c"U64"
@.d102 = private constant [3 x i8] c"F64"
@.d103 = private constant [16 x i8] c"std/prelude/text"
@.d104 = private constant [6 x i8] c"String"
@.c105 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:765: reached unreachable code\0A\00"
@.d106 = private constant [6 x i8] c"error "
@.d107 = private constant [1 x i8] c"."
@.c108 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:744: reached unreachable code\0A\00"
@.c109 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:745: reached unreachable code\0A\00"
@.c110 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:746: reached unreachable code\0A\00"
@.c111 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:747: reached unreachable code\0A\00"
@.c112 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:748: reached unreachable code\0A\00"
@.c113 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:640: reached unreachable code\0A\00"
@.d114 = private constant [4 x i8] c"std/"
@.c115 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:645: reached unreachable code\0A\00"
@.c116 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:661: reached unreachable code\0A\00"
@.c117 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:664: reached unreachable code\0A\00"
@.c118 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:668: reached unreachable code\0A\00"
@.c119 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:669: reached unreachable code\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aIf_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aIf_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c120 = private unnamed_addr constant [52 x i8] c"compiler/interp.olang:76: reached unreachable code\0A\00"
@.c121 = private unnamed_addr constant [52 x i8] c"compiler/interp.olang:92: reached unreachable code\0A\00"
@.c122 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:106: array length out of range\0A\00"
@.c123 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:109: reached unreachable code\0A\00"
@.c124 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:141: reached unreachable code\0A\00"
@.d125 = private constant [0 x i8] c""
@.d126 = private constant [0 x i8] c""
@.c127 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:159: reached unreachable code\0A\00"
@.c128 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:228: reached unreachable code\0A\00"
@.c129 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:812: reached unreachable code\0A\00"
@.c130 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:532: reached unreachable code\0A\00"
@.c131 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:687: reached unreachable code\0A\00"
@.d132 = private constant [1 x i8] c":"
@.c133 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:860: slice bounds out of range\0A\00"
@.c134 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:995: reached unreachable code\0A\00"
@.c135 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:996: reached unreachable code\0A\00"
@.d136 = private constant [0 x i8] c""
@.d137 = private constant [40 x i8] c"it fails with an error no clause handles"
@.d138 = private constant [40 x i8] c"it fails with an error no clause handles"
@.c139 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:399: reached unreachable code\0A\00"
@.c140 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:699: reached unreachable code\0A\00"
@.c141 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:371: slice bounds out of range\0A\00"
@.c142 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:382: slice bounds out of range\0A\00"
@.d143 = private constant [1 x i8] c"&"
@.d144 = private constant [0 x i8] c""
@.d145 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_3aProgram_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_3aChecker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2finterp_3aCondErr_3e_2eRu_H922c29a79a89b0be9ccf5ed4b75b0111(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, %"compiler/eval:Image" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eImage(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2feval_2eWhyStale = external constant <{ [8 x i8], ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalStale(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalAborts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/eval:Image" %a2)
declare { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H3ccda5e77fabf86fda89ecfc77eff03d(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eRunFrom_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H8e3ab02101333f4dae95aad48f2e722e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
declare %"compiler/eval:Blob" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/eval:Blob" @compiler_2feval_3aBlob_2ector(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Blob" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_Hd47ddefe3838698aaa5711f2f63b01ed(ptr %v0, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eL_H74c4c659bc848d1046c0a3f6eab69368(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eR_H23a25d26bcb7a81e9bb7522f4174946e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2eLe_H6dd36e51154e44ba851d649a77b16b98(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2eRu_H15098c5dcd0d2a6000e8beb539003606(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eResultHoldsAddress(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eZeroValueShared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralCtorFails(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroByReference(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroReferenceHasOne(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@G_2ecompiler_2fload_2eNoBranch = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare { i32, { i64, [1 x i64] } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePop_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRecordCount(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/typed:Plan" @compiler_2ftyped_2eNewPlan(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/typed:Plan" %a2)
declare { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eWhyWaits = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eRunFrom_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eRunFrom_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %a0, i32 %a1, { i64, [1 x i64] } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i1 %a4, { i64, [1 x i64] } %a5)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eBuildGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_H19ac89f3ce4c777c1c093c5956529937(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aConstAsk_3e_2e_H7246041139e13b84a5c0718a267d329f(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eRunFrom_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aIf_26_3e_2ePush_3ccompiler_2fast_3aIf_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aConstAsk_3e_2e_H3755acdd817c9ece2266e75be7a7be94(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
@G_2ecompiler_2fgeneric_2eRunTimeLength = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\80" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstArgNotComputable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_H2d785e59a328798ef633c598d7682c46(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnseen(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUndecidable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2finterp_3aCondErr_3e_2ePu_H06e56a62b7eaa5d9f34ed929f2594f0e(ptr %v0, ptr %v1, ptr %a0, %"compiler/interp:CondErr" %a1)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aIf_26_3e_2eRunFrom_3ccompiler_2fast_3aIf_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fviews_3aViewer_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrewHere(ptr %v0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2feval_2eNewMachine(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2finterp_3aCondErr_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aIf_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
