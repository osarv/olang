; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, I64>" = type { ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List<mut compiler/names:Table&>", %"std/prelude/map:Map<compiler/source:NameId, I64>", %"std/prelude/map:Map<compiler/source:NameId, compiler/names:Ref>", %"std/prelude/map:Map<I64, compiler/names:Ref>", %"std/prelude/map:Map<I64, compiler/names:Ref>", i64, %"std/prelude/list:List<compiler/names:local>", %"std/prelude/map:Map<compiler/source:NameId, I64>", %"std/prelude/list:List<std/pair:Pair<compiler/source:NameId, I64>>", %"std/prelude/list:List<compiler/source:NameId>", i1, i64, %"std/prelude/list:List<std/pair:Pair<compiler/source:NameId, I64>>" }
%"std/prelude/list:List<mut compiler/names:Table&>" = type { ptr }
%"std/prelude/map:Map<compiler/source:NameId, I64>" = type { ptr }
%"std/prelude/map:Map<compiler/source:NameId, compiler/names:Ref>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/names:Ref>" = type { ptr }
%"std/prelude/list:List<compiler/names:local>" = type { ptr }
%"std/prelude/list:List<std/pair:Pair<compiler/source:NameId, I64>>" = type { ptr }
%"std/prelude/list:List<compiler/source:NameId>" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map<I64, compiler/types:DeclId>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/list:List<compiler/generic:varRow>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", i64, %"std/prelude/map:Map<I64, compiler/generic:pattern>", %"std/prelude/list:List<compiler/generic:fnRow>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<I64, compiler/types:TypeId>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/generic:instance>", %"std/prelude/map:Map<std/pair:Pair<I64, compiler/types:ListId>, I64>", %"std/prelude/map:Map<compiler/types:ListId, compiler/types:ListId>", %"std/prelude/map:Map<I64, Bool>", i64, %"std/prelude/map:Map<I64, Bool>", i64, %"compiler/generic:Origin", %"std/prelude/map:Map<compiler/types:TypeId, compiler/generic:Origin>", %"std/prelude/map:Map<compiler/types:TypeId, Bool>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<compiler/generic:ConstAsk>" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List<compiler/types:data>", %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>", %"std/prelude/list:List<I32>", %"std/prelude/list:List<Array<compiler/types:TypeId>&>", %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>", %"std/prelude/list:List<Array<compiler/source:NameId>&>", %"std/prelude/list:List<compiler/types:ListId>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<compiler/types:decl>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>", %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>", %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/types:TypeId>", %"std/prelude/list:List<Array<I64>&>", %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>", %"std/prelude/list:List<Array<I64>&>", %"std/prelude/map:Map<Array<I64>&, I64>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", i1 }
%"std/prelude/list:List<compiler/types:data>" = type { ptr }
%"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<I32>" = type { ptr }
%"std/prelude/list:List<Array<compiler/types:TypeId>&>" = type { ptr }
%"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" = type { ptr }
%"std/prelude/list:List<Array<compiler/source:NameId>&>" = type { ptr }
%"std/prelude/list:List<compiler/types:ListId>" = type { ptr }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/prelude/list:List<compiler/types:decl>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" = type { ptr }
%"std/prelude/list:List<I64>" = type { ptr }
%"std/prelude/list:List<compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<Array<I64>&>" = type { ptr }
%"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" = type { ptr }
%"std/prelude/map:Map<Array<I64>&, I64>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, I64>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/types:DeclId>" = type { ptr }
%"std/prelude/map:Map<I64, I64>" = type { ptr }
%"std/prelude/list:List<compiler/generic:varRow>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>" = type { ptr }
%"std/prelude/map:Map<I64, Bool>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/generic:pattern>" = type { ptr }
%"std/prelude/list:List<compiler/generic:fnRow>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<compiler/generic:instance>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, compiler/types:ListId>, I64>" = type { ptr }
%"std/prelude/map:Map<compiler/types:ListId, compiler/types:ListId>" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/map:Map<compiler/types:TypeId, compiler/generic:Origin>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, Bool>" = type { ptr }
%"std/prelude/list:List<compiler/generic:ConstAsk>" = type { ptr }
%"compiler/check:Checker" = type { ptr, i1, i1, %"std/prelude/list:List<compiler/typed:Place&>", %"std/prelude/list:List<mut compiler/typed:Body&>", %"std/prelude/list:List<compiler/check:Gap>", %"std/prelude/list:List<mut compiler/check:frame&>", %"std/prelude/list:List<I64>", i64, %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<I64, I64>", i32, %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:TypeId>", %"std/prelude/list:List<compiler/typed:Expr&>", %"std/prelude/list:List<compiler/typed:Stmt&>", %"std/prelude/list:List<compiler/check:atRec>", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<I64, compiler/types:ListId>", %"std/prelude/list:List<std/pair:Pair<I64, I64>>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:ListId>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:ListId>", i64, %"std/prelude/map:Map<compiler/types:TypeId, Bool>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/source:NameId>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/check:roOrigin>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/list:List<std/pair:Pair<std/pair:Pair<I64, I64>, std/pair:Pair<I64, I64>>>", %"std/prelude/list:List<compiler/check:roArg>", %"std/prelude/list:List<compiler/check:roFn>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, std/prelude/list:List<compiler/typed:Expr&>>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/list:List<std/pair:Pair<I64, compiler/typed:Expr&>>", %"std/prelude/list:List<std/pair:Pair<I64, compiler/typed:Expr&>>", %"std/prelude/list:List<compiler/check:roDeepArg>", %"std/prelude/list:List<compiler/check:roArg>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/map:Map<I64, Bool>", i64, %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/list:List<compiler/check:Ask>", %"std/prelude/list:List<compiler/check:AssertAsk>", %"std/prelude/map:Map<I64, Bool>" }
%"std/prelude/list:List<compiler/typed:Place&>" = type { ptr }
%"std/prelude/list:List<mut compiler/typed:Body&>" = type { ptr }
%"std/prelude/list:List<compiler/check:Gap>" = type { ptr }
%"std/prelude/list:List<mut compiler/check:frame&>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<compiler/typed:Expr&>" = type { ptr }
%"std/prelude/list:List<compiler/typed:Stmt&>" = type { ptr }
%"std/prelude/list:List<compiler/check:atRec>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/types:ListId>" = type { ptr }
%"std/prelude/list:List<std/pair:Pair<I64, I64>>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:ListId>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/source:NameId>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/check:roOrigin>" = type { ptr }
%"std/prelude/list:List<std/pair:Pair<std/pair:Pair<I64, I64>, std/pair:Pair<I64, I64>>>" = type { ptr }
%"std/prelude/list:List<compiler/check:roArg>" = type { ptr }
%"std/prelude/list:List<compiler/check:roFn>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, std/prelude/list:List<compiler/typed:Expr&>>" = type { ptr }
%"std/prelude/list:List<std/pair:Pair<I64, compiler/typed:Expr&>>" = type { ptr }
%"std/prelude/list:List<compiler/check:roDeepArg>" = type { ptr }
%"std/prelude/list:List<compiler/check:Ask>" = type { ptr }
%"std/prelude/list:List<compiler/check:AssertAsk>" = type { ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List<mut compiler/load:Module&>", %"std/prelude/list:List<std/prelude/text:String&>", i64, { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List<mut compiler/load:Module&>" = type { ptr }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64 }
%"std/pair:Pair<I64, I64>" = type { i64, i64 }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/list:List<mut compiler/typed:Body&>", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, Bool>", i1 }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List<mut compiler/typed:Body&>", %"std/prelude/list:List<compiler/typed:Plan>", %"std/prelude/list:List<compiler/lower:Gap>", i1, %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", i1, i32, i32, i32 }
%"std/prelude/list:List<compiler/typed:Plan>" = type { ptr }
%"std/prelude/list:List<compiler/lower:Gap>" = type { ptr }
%"std/prelude/list:List<compiler/mir:FnKey>" = type { ptr }
%"std/prelude/map:Map<compiler/mir:FnKey, Bool>" = type { ptr }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, %"std/prelude/list:List<compiler/mir:Fn>", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map<compiler/mir:FnKey, I64>", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/map:Map<compiler/mir:FnKey, I64>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, std/prelude/text:String&>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/map:Map<compiler/types:TypeId, compiler/mir:FnKey>", %"std/prelude/list:List<compiler/eval:global>", %"std/prelude/map:Map<compiler/eval:gkey, I64>", %"std/prelude/map:Map<compiler/eval:dkey, I64>", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/eval:scope>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/eval:reg>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/eval:task>", %"std/prelude/list:List<I64>", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/list:List<I64>", i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<compiler/types:TypeId, Bool>", i64, %"compiler/source:Span", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<I64>", i64, %"std/prelude/list:List<I64>", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"std/prelude/list:List<compiler/mir:Fn>" = type { ptr }
%"std/prelude/map:Map<compiler/mir:FnKey, I64>" = type { ptr }
%"std/prelude/map:Map<I64, std/prelude/text:String&>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, compiler/mir:FnKey>" = type { ptr }
%"std/prelude/list:List<compiler/eval:global>" = type { ptr }
%"std/prelude/map:Map<compiler/eval:gkey, I64>" = type { ptr }
%"std/prelude/map:Map<compiler/eval:dkey, I64>" = type { ptr }
%"std/prelude/list:List<compiler/eval:scope>" = type { ptr }
%"std/prelude/list:List<compiler/eval:reg>" = type { ptr }
%"std/prelude/list:List<compiler/eval:task>" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List<compiler/typed:LocalId>", %"std/prelude/list:List<compiler/typed:ScopeVar>", %"std/prelude/list:List<compiler/typed:Local>", %"std/prelude/list:List<compiler/typed:BlockInfo>", %"std/prelude/list:List<compiler/typed:SiteInfo>", %"std/prelude/list:List<compiler/typed:LocalId>", ptr }
%"std/prelude/list:List<compiler/typed:LocalId>" = type { ptr }
%"std/prelude/list:List<compiler/typed:ScopeVar>" = type { ptr }
%"std/prelude/list:List<compiler/typed:Local>" = type { ptr }
%"std/prelude/list:List<compiler/typed:BlockInfo>" = type { ptr }
%"std/prelude/list:List<compiler/typed:SiteInfo>" = type { ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
%"compiler/mir:Fn" = type { { i64, [1 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List<compiler/mir:LocalId>", %"std/prelude/list:List<compiler/mir:LocalId>", %"std/prelude/list:List<compiler/mir:VarKind>", %"std/prelude/list:List<compiler/mir:Local>", %"std/prelude/list:List<compiler/mir:ScopeInfo>", %"std/prelude/list:List<compiler/mir:BasicBlock>", %"std/prelude/list:List<compiler/mir:Proj>", %"std/prelude/list:List<compiler/mir:Operand>", %"std/prelude/list:List<compiler/mir:ScopeRef>", %"std/prelude/list:List<compiler/mir:Place>", %"std/prelude/list:List<compiler/mir:Call>", %"std/prelude/list:List<compiler/mir:Case>", %"std/prelude/list:List<compiler/mir:Task>", %"std/prelude/list:List<compiler/mir:TaskClause>", %"std/prelude/list:List<compiler/typed:Item>", %"std/prelude/list:List<compiler/mir:ConstNode>", %"std/prelude/list:List<I32>", %"std/prelude/list:List<U8>" }
%"std/prelude/list:List<compiler/mir:LocalId>" = type { ptr }
%"std/prelude/list:List<compiler/mir:VarKind>" = type { ptr }
%"std/prelude/list:List<compiler/mir:Local>" = type { ptr }
%"std/prelude/list:List<compiler/mir:ScopeInfo>" = type { ptr }
%"std/prelude/list:List<compiler/mir:BasicBlock>" = type { ptr }
%"std/prelude/list:List<compiler/mir:Proj>" = type { ptr }
%"std/prelude/list:List<compiler/mir:Operand>" = type { ptr }
%"std/prelude/list:List<compiler/mir:ScopeRef>" = type { ptr }
%"std/prelude/list:List<compiler/mir:Place>" = type { ptr }
%"std/prelude/list:List<compiler/mir:Call>" = type { ptr }
%"std/prelude/list:List<compiler/mir:Case>" = type { ptr }
%"std/prelude/list:List<compiler/mir:Task>" = type { ptr }
%"std/prelude/list:List<compiler/mir:TaskClause>" = type { ptr }
%"std/prelude/list:List<compiler/typed:Item>" = type { ptr }
%"std/prelude/list:List<compiler/mir:ConstNode>" = type { ptr }
%"std/prelude/list:List<U8>" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, ptr, ptr, { i64, ptr }, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/load:Import>", ptr, ptr, %"std/prelude/list:List<I32>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List<I64>" }
%"std/prelude/list:List<compiler/load:Import>" = type { ptr }
%"std/prelude/list:List<Bool>" = type { ptr }
%"compiler/mir:Call" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Task" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List<compiler/mir:Stmt>", { i64, [7 x i64] } }
%"std/prelude/list:List<compiler/mir:Stmt>" = type { ptr }
%"std/prelude/list:List<std/pair:Pair<I64, I32>>" = type { ptr }
%"compiler/check:Ask" = type { i64, i64, i32, ptr }
%"compiler/generic:ConstAsk" = type { i64, ptr, i32, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair<I64, I32>" = type { i64, i32 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/views:Viewer" = type { ptr, %"std/prelude/list:List<mut compiler/typed:Body&>", %"std/prelude/list:List<mut compiler/views:summary&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/map:Map<I64, std/prelude/text:String&>", %"std/prelude/map:Map<I64, Bool>", i64, %"std/prelude/map:Map<compiler/types:DeclId, I64>", %"std/prelude/list:List<std/prelude/list:List<compiler/source:NameId>>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", i64, %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", ptr, i64, i1, i1, i1, i1, %"std/prelude/list:List<I64>", %"std/prelude/list:List<mut compiler/views:loopFrame&>", %"std/prelude/list:List<compiler/typed:Place&>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<I64, Bool>" }
%"std/prelude/list:List<mut compiler/views:summary&>" = type { ptr }
%"std/prelude/map:Map<compiler/types:DeclId, I64>" = type { ptr }
%"std/prelude/list:List<std/prelude/list:List<compiler/source:NameId>>" = type { ptr }
%"std/prelude/list:List<mut compiler/views:loopFrame&>" = type { ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
define dso_local { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l2
  %t3 = trunc i64 3 to i32
  %t4 = icmp eq i32 %t2, %t3
  store i1 %t4, ptr %l3
  %t5 = load i1, ptr %l3
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 53, ptr @.d0 }, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb4:
  %t6 = load i32, ptr %l0
  store i32 %t6, ptr %l4
  %t7 = load i32, ptr %l4
  %t8 = trunc i64 4 to i32
  %t9 = icmp eq i32 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 50, ptr @.d1 }, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb8:
  %t11 = load i32, ptr %l0
  store i32 %t11, ptr %l6
  %t12 = load i32, ptr %l6
  %t13 = trunc i64 5 to i32
  %t14 = icmp eq i32 %t12, %t13
  store i1 %t14, ptr %l7
  %t15 = load i1, ptr %l7
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 48, ptr @.d2 }, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb12:
  %t16 = load i32, ptr %l0
  store i32 %t16, ptr %l8
  %t17 = load i32, ptr %l8
  %t18 = trunc i64 6 to i32
  %t19 = icmp eq i32 %t17, %t18
  store i1 %t19, ptr %l9
  %t20 = load i1, ptr %l9
  br i1 %t20, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 68, ptr @.d3 }, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb16:
  %t21 = load i32, ptr %l0
  store i32 %t21, ptr %l10
  %t22 = load i32, ptr %l10
  %t23 = trunc i64 8 to i32
  %t24 = icmp eq i32 %t22, %t23
  store i1 %t24, ptr %l11
  %t25 = load i1, ptr %l11
  br i1 %t25, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 81, ptr @.d4 }, ptr %l1
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb20:
  %t26 = load i32, ptr %l0
  store i32 %t26, ptr %l12
  %t27 = load i32, ptr %l12
  %t28 = trunc i64 7 to i32
  %t29 = icmp eq i32 %t27, %t28
  store i1 %t29, ptr %l13
  %t30 = load i1, ptr %l13
  br i1 %t30, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  store { i64, ptr } { i64 45, ptr @.d5 }, ptr %l1
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb24:
  %t31 = load i32, ptr %l0
  store i32 %t31, ptr %l14
  %t32 = load i32, ptr %l14
  %t33 = trunc i64 9 to i32
  %t34 = icmp eq i32 %t32, %t33
  store i1 %t34, ptr %l15
  %t35 = load i1, ptr %l15
  br i1 %t35, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 44, ptr @.d6 }, ptr %l1
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb28:
  %t36 = load i32, ptr %l0
  store i32 %t36, ptr %l16
  %t37 = load i32, ptr %l16
  %t38 = trunc i64 10 to i32
  %t39 = icmp eq i32 %t37, %t38
  store i1 %t39, ptr %l17
  %t40 = load i1, ptr %l17
  br i1 %t40, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 39, ptr @.d7 }, ptr %l1
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  store { i64, ptr } { i64 31, ptr @.d8 }, ptr %l1
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>"
  %l9 = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"compiler/names:Resolver"
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca %"compiler/generic:Program"
  %l19 = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca %"compiler/check:Checker"
  %l23 = alloca %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>"
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca %"compiler/check:Checker"
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t28 = alloca %"compiler/generic:Program", align 8
  %t41 = alloca %"compiler/check:Checker", align 8
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t1)
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t2, ptr %l8
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %l8
  %t5 = load ptr, ptr %lp2
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t4, ptr %t5
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/map:Map<std/prelude/text:String&, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t6)
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t8, ptr %lp3
  %t9 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %l9
  %t10 = load ptr, ptr %lp3
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t9, ptr %t10
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0
  store ptr %t11, ptr %l10
  %t12 = load ptr, ptr %l10
  %t13 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 4
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l11
  %t15 = load ptr, ptr %l11
  %t16 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t15)
  store i64 %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load i64, ptr %l12
  store i64 %t17, ptr %l4
  %t18 = load ptr, ptr %l0
  store ptr %t18, ptr %l13
  %t19 = load ptr, ptr %l13
  %t20 = call %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %v0, ptr %v1, ptr %t19)
  store %"compiler/names:Resolver" %t20, ptr %l14
  br label %bb5
bb5:
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 112, i64 8)
  store ptr %t21, ptr %lp5
  %t22 = load %"compiler/names:Resolver", ptr %l14
  %t23 = load ptr, ptr %lp5
  store %"compiler/names:Resolver" %t22, ptr %t23
  %t24 = load ptr, ptr %lp5
  store ptr %t24, ptr %l15
  %t25 = load ptr, ptr %l15
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v1, ptr %t25)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0
  store ptr %t26, ptr %l16
  %t27 = load ptr, ptr %lp5
  store ptr %t27, ptr %l17
  %t29 = load ptr, ptr %l16
  %t30 = load ptr, ptr %l17
  call void @compiler_2fgeneric_3aProgram_2ector(ptr %t28, ptr %v0, ptr %v1, ptr %v1, ptr %t29, ptr %t30)
  %t31 = load %"compiler/generic:Program", ptr %t28
  store %"compiler/generic:Program" %t31, ptr %l18
  br label %bb7
bb7:
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 520, i64 8)
  store ptr %t32, ptr %lp6
  %t33 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l18, i64 520, i1 false)
  %t34 = load ptr, ptr %lp3
  %t35 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %t34
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t35, ptr %l19
  %t36 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %l19
  %t37 = load ptr, ptr %lp6
  %t38 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 32
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t36, ptr %t38
  %t39 = load ptr, ptr %lp6
  store ptr %t39, ptr %l20
  %t40 = load i1, ptr %l1
  store i1 %t40, ptr %l21
  %t42 = load ptr, ptr %l20
  %t43 = load i1, ptr %l21
  call void @compiler_2fcheck_3aChecker_2ector(ptr %t41, ptr %v1, ptr %v1, ptr %t42, i1 %t43)
  %t44 = load %"compiler/check:Checker", ptr %t41
  store %"compiler/check:Checker" %t44, ptr %l22
  br label %bb8
bb8:
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 432, i64 8)
  store ptr %t45, ptr %lp7
  %t46 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %l22, i64 432, i1 false)
  %t47 = load ptr, ptr %lp2
  %t48 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %t47
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t48, ptr %l23
  %t49 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %l23
  %t50 = load ptr, ptr %lp7
  %t51 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 53
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t49, ptr %t51
  %t52 = load ptr, ptr %lp7
  store ptr %t52, ptr %l24
  %t53 = load ptr, ptr %l24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v1, ptr %t53)
  br label %bb9
bb9:
  %t54 = load ptr, ptr %l0
  store ptr %t54, ptr %l25
  %t55 = load ptr, ptr %lp7
  store ptr %t55, ptr %l26
  %t56 = load ptr, ptr %lp2
  store ptr %t56, ptr %l27
  %t57 = load ptr, ptr %lp3
  store ptr %t57, ptr %l28
  %t58 = load ptr, ptr %l25
  %t59 = load ptr, ptr %l26
  %t60 = load ptr, ptr %l27
  %t61 = load ptr, ptr %l28
  %t62 = call i1 @compiler_2finterp_2edecide(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t58, ptr %t59, ptr %t60, ptr %t61)
  store i1 %t62, ptr %l29
  br label %bb10
bb10:
  %t63 = load i1, ptr %l29
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l30
  %t65 = load i1, ptr %l30
  br i1 %t65, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load ptr, ptr %l0
  store ptr %t66, ptr %l31
  %t67 = load ptr, ptr %l31
  %t68 = getelementptr %"compiler/load:Loader", ptr %t67, i32 0, i32 4
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l32
  %t70 = load ptr, ptr %l32
  %t71 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t70)
  store i64 %t71, ptr %l33
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t72 = load i64, ptr %l4
  store i64 %t72, ptr %l34
  %t73 = load i64, ptr %l33
  %t74 = load i64, ptr %l34
  %t75 = icmp eq i64 %t73, %t74
  store i1 %t75, ptr %l35
  %t76 = load i1, ptr %l35
  br i1 %t76, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %lp7
  store ptr %t77, ptr %l36
  %t78 = load ptr, ptr %l36
  call void @compiler_2finterp_2ejudgeViews(ptr %v1, ptr %t78)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t79 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t79, i64 432, i1 false)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t80 = load %"compiler/check:Checker", ptr %l37
  store %"compiler/check:Checker" %t80, ptr %out
  br label %ret
bb18:
  %t81 = load ptr, ptr %l0
  store ptr %t81, ptr %l38
  %t82 = load ptr, ptr %l38
  %t83 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 4
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l39
  %t85 = load i64, ptr %l4
  store i64 %t85, ptr %l40
  %t86 = load ptr, ptr %l39
  %t87 = load i64, ptr %l40
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t86, i64 %t87)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  br label %bb3
ret:
  ret void
}

define dso_local i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/check:AssertAsk"
  %l11 = alloca %"std/pair:Pair<I64, I64>"
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca { i64, [5 x i64] }
  %l14 = alloca { i64, [3 x i64] }
  %l15 = alloca { { i64, ptr }, i1 }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l35 = alloca i32
  %l36 = alloca %"compiler/interp:Exec"
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca %"std/prelude/map:Map<I64, Bool>"
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca %"compiler/check:AssertAsk"
  %l59 = alloca i64
  %l60 = alloca i32
  %l61 = alloca i64
  %l62 = alloca %"std/pair:Pair<I64, I64>"
  %l63 = alloca ptr
  %l64 = alloca %"std/pair:Pair<I64, I64>"
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca { i64, [1 x i64] }
  %l70 = alloca ptr
  %l71 = alloca { i64, [1 x i64] }
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca { i64, [1 x i64] }
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, [5 x i64] }
  %l80 = alloca i64
  %l81 = alloca i32
  %l82 = alloca i64
  %l83 = alloca i32
  %l84 = alloca i64
  %l85 = alloca { i64, [3 x i64] }
  %l86 = alloca { i64, [5 x i64] }
  %l87 = alloca i1
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca %"compiler/eval:Ptr"
  %l94 = alloca i32
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca %"std/pair:Pair<I64, I64>"
  %l99 = alloca ptr
  %l100 = alloca i64
  %l101 = alloca { { i64, ptr }, i1 }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca { i64, [3 x i64] }
  %l108 = alloca i1
  %l109 = alloca %"compiler/msgs:Msg"
  %l110 = alloca { i64, ptr }
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca %"compiler/msgs:Msg"
  %l113 = alloca i64
  %l114 = alloca { i64, [5 x i64] }
  %l115 = alloca i1
  %l116 = alloca i32
  %l117 = alloca i64
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca { i64, [3 x i64] }
  %l123 = alloca i32
  %l124 = alloca { i64, ptr }
  %l125 = alloca %"compiler/msgs:Msg"
  %l126 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i32
  %l131 = alloca i64
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca { i64, [3 x i64] }
  %l135 = alloca %"compiler/msgs:Msg"
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i64
  %t29 = alloca %"compiler/interp:Exec", align 8
  %t107 = alloca { i64, [1 x i64] }, align 8
  %t154 = alloca { i64, [3 x i64] }, align 8
  %t278 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l22
  %t2 = load ptr, ptr %l22
  %t3 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 55
  store ptr %t3, ptr %l23
  %t4 = load ptr, ptr %l23
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eL_H74c4c659bc848d1046c0a3f6eab69368(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24
  %t7 = icmp eq i64 %t6, 0
  store i1 %t7, ptr %l25
  %t8 = load i1, ptr %l25
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l26
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i64, ptr %l26
  store i64 %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l27
  %t11 = load ptr, ptr %l27
  %t12 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 0
  %t13 = load ptr, ptr %t12
  store ptr %t13, ptr %l28
  %t14 = load ptr, ptr %l28
  %t15 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t16 = load ptr, ptr %t15
  store ptr %t16, ptr %l29
  %t17 = load ptr, ptr %l29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 4
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l30
  %t20 = load ptr, ptr %l30
  store ptr %t20, ptr %l2
  %t21 = load ptr, ptr %l0
  store ptr %t21, ptr %l31
  %t22 = load ptr, ptr %l31
  %t23 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 0
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l32
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l33
  %t26 = load ptr, ptr %l33
  %t27 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 4
  %t28 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %t27
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t28, ptr %l34
  store i32 0, ptr %l35
  %t30 = load ptr, ptr %l32
  %t31 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l34
  %t32 = load i32, ptr %l35
  call void @compiler_2finterp_3aExec_2ector(ptr %t29, ptr %v0, ptr %v0, ptr %v0, ptr %t30, %"std/prelude/list:List<mut compiler/typed:Body&>" %t31, i32 %t32)
  %t33 = load %"compiler/interp:Exec", ptr %t29
  store %"compiler/interp:Exec" %t33, ptr %l36
  br label %bb5
bb5:
  %t34 = load %"compiler/interp:Exec", ptr %l36
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 800, i64 8)
  store %"compiler/interp:Exec" %t34, ptr %t35
  store ptr %t35, ptr %l37
  %t36 = load ptr, ptr %l37
  store ptr %t36, ptr %l3
  %t37 = load ptr, ptr %l3
  store ptr %t37, ptr %l38
  %t38 = load ptr, ptr %l0
  store ptr %t38, ptr %l39
  %t39 = load ptr, ptr %l39
  %t40 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 56
  %t41 = load %"std/prelude/map:Map<I64, Bool>", ptr %t40
  store %"std/prelude/map:Map<I64, Bool>" %t41, ptr %l40
  %t42 = load %"std/prelude/map:Map<I64, Bool>", ptr %l40
  %t43 = load ptr, ptr %l38
  %t44 = getelementptr %"compiler/interp:Exec", ptr %t43, i32 0, i32 10
  store %"std/prelude/map:Map<I64, Bool>" %t42, ptr %t44
  store i64 0, ptr %l4
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0
  store ptr %t45, ptr %l41
  %t46 = load ptr, ptr %l41
  %t47 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 55
  store ptr %t47, ptr %l42
  %t48 = load ptr, ptr %l42
  store ptr %t48, ptr %l5
  store i64 0, ptr %l6
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l5
  store ptr %t49, ptr %l44
  %t50 = load i64, ptr %l6
  store i64 %t50, ptr %l45
  %t51 = load ptr, ptr %l44
  %t52 = load i64, ptr %l45
  %t53 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eR_H23a25d26bcb7a81e9bb7522f4174946e(ptr %v0, ptr %t51, i64 %t52)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l47
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb8, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l46
  br label %bb7
bb7:
  %t58 = load { i64, ptr }, ptr %l46
  store { i64, ptr } %t58, ptr %l43
  br label %bb12
bb8:
  %t59 = load i32, ptr %l47
  %t60 = ashr i32 %t59, 16
  store i32 %t60, ptr %l48
  %t61 = load i32, ptr %l48
  %t62 = icmp eq i32 %t61, 1
  store i1 %t62, ptr %l49
  %t63 = load i1, ptr %l49
  br i1 %t63, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb12:
  %t64 = load { i64, ptr }, ptr %l43
  store { i64, ptr } %t64, ptr %l7
  %t65 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t65, ptr %l50
  %t66 = load { i64, ptr }, ptr %l50
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l51
  %t68 = load i64, ptr %l51
  store i64 %t68, ptr %l8
  store i64 0, ptr %l9
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load i64, ptr %l9
  store i64 %t69, ptr %l52
  %t70 = load i64, ptr %l8
  store i64 %t70, ptr %l53
  %t71 = load i64, ptr %l52
  %t72 = load i64, ptr %l53
  %t73 = icmp slt i64 %t71, %t72
  store i1 %t73, ptr %l54
  %t74 = load i1, ptr %l54
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l55
  %t76 = load i1, ptr %l55
  br i1 %t76, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb15:
  br label %bb16
bb16:
  %t77 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t77, ptr %l56
  %t78 = load i64, ptr %l9
  store i64 %t78, ptr %l57
  %t79 = load i64, ptr %l57
  %t80 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  %t82 = getelementptr %"compiler/check:AssertAsk", ptr %t81, i64 %t79
  %t83 = load %"compiler/check:AssertAsk", ptr %t82
  store %"compiler/check:AssertAsk" %t83, ptr %l58
  %t84 = load %"compiler/check:AssertAsk", ptr %l58
  store %"compiler/check:AssertAsk" %t84, ptr %l10
  %t85 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 0
  %t86 = load i64, ptr %t85
  store i64 %t86, ptr %l59
  %t87 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 2
  %t88 = getelementptr %"compiler/source:Span", ptr %t87, i32 0, i32 0
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l60
  %t90 = load i32, ptr %l60
  %t91 = sext i32 %t90 to i64
  store i64 %t91, ptr %l61
  %t92 = load i64, ptr %l59
  %t93 = load i64, ptr %l61
  %t94 = call %"std/pair:Pair<I64, I64>" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t92, i64 %t93)
  store %"std/pair:Pair<I64, I64>" %t94, ptr %l62
  br label %bb17
bb17:
  %t95 = load %"std/pair:Pair<I64, I64>", ptr %l62
  store %"std/pair:Pair<I64, I64>" %t95, ptr %l11
  %t96 = load ptr, ptr %l1
  store ptr %t96, ptr %l63
  %t97 = load %"std/pair:Pair<I64, I64>", ptr %l11
  store %"std/pair:Pair<I64, I64>" %t97, ptr %l64
  %t98 = load ptr, ptr %l63
  %t99 = load %"std/pair:Pair<I64, I64>", ptr %l64
  %t100 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v1, ptr %t98, %"std/pair:Pair<I64, I64>" %t99)
  store i1 %t100, ptr %l65
  br label %bb18
bb18:
  %t101 = load i1, ptr %l65
  br i1 %t101, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb58
bb20:
  br label %bb21
bb21:
  %t102 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 4
  %t103 = load i64, ptr %t102
  store i64 %t103, ptr %l66
  %t104 = load i64, ptr %l66
  %t105 = trunc i64 %t104 to i32
  store i32 %t105, ptr %l67
  %t106 = load i32, ptr %l67
  store i32 %t106, ptr %l68
  store { i64, [1 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [1 x i64] }, ptr %t107, i32 0, i32 0
  store i64 0, ptr %t108
  %t109 = load i32, ptr %l68
  %t110 = insertvalue { i32 } undef, i32 %t109, 0
  %t111 = getelementptr { i64, [1 x i64] }, ptr %t107, i32 0, i32 1
  store { i32 } %t110, ptr %t111
  %t112 = load { i64, [1 x i64] }, ptr %t107
  store { i64, [1 x i64] } %t112, ptr %l69
  %t113 = load { i64, [1 x i64] }, ptr %l69
  store { i64, [1 x i64] } %t113, ptr %l12
  %t114 = load ptr, ptr %l3
  store ptr %t114, ptr %l70
  %t115 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t115, ptr %l71
  %t116 = load ptr, ptr %l70
  %t117 = load { i64, [1 x i64] }, ptr %l71
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t116, { i64, [1 x i64] } %t117)
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l3
  store ptr %t118, ptr %l72
  %t119 = load ptr, ptr %l72
  %t120 = getelementptr %"compiler/interp:Exec", ptr %t119, i32 0, i32 4
  store ptr %t120, ptr %l73
  %t121 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t121, ptr %l74
  %t122 = icmp sge i64 0, 0
  store i1 %t122, ptr %l75
  %t123 = load i1, ptr %l75
  br i1 %t123, label %bb23, label %bb24
bb23:
  %t124 = icmp sle i64 0, 1152921504606846975
  store i1 %t124, ptr %l76
  %t125 = load i1, ptr %l76
  br i1 %t125, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb25:
  %t126 = mul i64 0, 8
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 0, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l77
  %t130 = load { i64, ptr }, ptr %l77
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = mul i64 %t131, 8
  %t134 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l78
  %t137 = load ptr, ptr %l73
  %t138 = load { i64, [1 x i64] }, ptr %l74
  %t139 = load { i64, ptr }, ptr %l78
  %t140 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t137, { i64, [1 x i64] } %t138, { i64, ptr } %t139)
  store { i64, [5 x i64] } %t140, ptr %l79
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb27:
  %t141 = load { i64, [5 x i64] }, ptr %l79
  store { i64, [5 x i64] } %t141, ptr %l13
  %t142 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 1
  %t143 = load i64, ptr %t142
  store i64 %t143, ptr %l80
  %t144 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 3
  %t145 = getelementptr %"compiler/source:Span", ptr %t144, i32 0, i32 0
  %t146 = load i32, ptr %t145
  store i32 %t146, ptr %l81
  %t147 = load i32, ptr %l81
  %t148 = sext i32 %t147 to i64
  store i64 %t148, ptr %l82
  %t149 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 3
  %t150 = getelementptr %"compiler/source:Span", ptr %t149, i32 0, i32 1
  %t151 = load i32, ptr %t150
  store i32 %t151, ptr %l83
  %t152 = load i32, ptr %l83
  %t153 = sext i32 %t152 to i64
  store i64 %t153, ptr %l84
  store { i64, [3 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 0
  store i64 3, ptr %t155
  %t156 = load i64, ptr %l80
  %t157 = insertvalue { i64, i64, i64 } undef, i64 %t156, 0
  %t158 = load i64, ptr %l82
  %t159 = insertvalue { i64, i64, i64 } %t157, i64 %t158, 1
  %t160 = load i64, ptr %l84
  %t161 = insertvalue { i64, i64, i64 } %t159, i64 %t160, 2
  %t162 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 1
  store { i64, i64, i64 } %t161, ptr %t162
  %t163 = load { i64, [3 x i64] }, ptr %t154
  store { i64, [3 x i64] } %t163, ptr %l85
  %t164 = load { i64, [3 x i64] }, ptr %l85
  store { i64, [3 x i64] } %t164, ptr %l14
  %t165 = load { i64, [5 x i64] }, ptr %l13
  store { i64, [5 x i64] } %t165, ptr %l86
  %t166 = load { i64, [5 x i64] }, ptr %l86
  %t167 = extractvalue { i64, [5 x i64] } %t166, 0
  %t168 = icmp eq i64 %t167, 0
  store i1 %t168, ptr %l87
  %t169 = load i1, ptr %l87
  br i1 %t169, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb43
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t170 = load i64, ptr %l4
  store i64 %t170, ptr %l88
  %t171 = load i64, ptr %l88
  %t172 = add i64 %t171, 1
  store i64 %t172, ptr %l89
  %t173 = load i64, ptr %l89
  store i64 %t173, ptr %l4
  %t174 = load ptr, ptr %l3
  store ptr %t174, ptr %l90
  %t175 = load ptr, ptr %l90
  %t176 = getelementptr %"compiler/interp:Exec", ptr %t175, i32 0, i32 4
  store ptr %t176, ptr %l91
  %t177 = load ptr, ptr %l3
  store ptr %t177, ptr %l92
  %t178 = load ptr, ptr %l92
  %t179 = getelementptr %"compiler/interp:Exec", ptr %t178, i32 0, i32 4
  %t180 = getelementptr %"compiler/eval:Machine", ptr %t179, i32 0, i32 7
  %t181 = load %"compiler/eval:Ptr", ptr %t180
  store %"compiler/eval:Ptr" %t181, ptr %l93
  %t182 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT
  store i32 %t182, ptr %l94
  %t183 = load ptr, ptr %l91
  %t184 = load %"compiler/eval:Ptr", ptr %l93
  %t185 = load i32, ptr %l94
  %t186 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t183, %"compiler/eval:Ptr" %t184, i32 %t185)
  store i64 %t186, ptr %l95
  br label %bb31
bb31:
  %t187 = load i64, ptr %l95
  %t188 = icmp ne i64 %t187, 0
  store i1 %t188, ptr %l96
  %t189 = load i1, ptr %l96
  br i1 %t189, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t190 = load ptr, ptr %l1
  store ptr %t190, ptr %l97
  %t191 = load %"std/pair:Pair<I64, I64>", ptr %l11
  store %"std/pair:Pair<I64, I64>" %t191, ptr %l98
  %t192 = load ptr, ptr %l97
  %t193 = load %"std/pair:Pair<I64, I64>", ptr %l98
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v1, ptr %t192, %"std/pair:Pair<I64, I64>" %t193, i1 true)
  br label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t194 = load ptr, ptr %l3
  store ptr %t194, ptr %l99
  %t195 = getelementptr %"compiler/check:AssertAsk", ptr %l10, i32 0, i32 5
  %t196 = load i64, ptr %t195
  store i64 %t196, ptr %l100
  %t197 = load ptr, ptr %l99
  %t198 = load i64, ptr %l100
  %t199 = call { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %s8, ptr %t197, i64 %t198)
  store { { i64, ptr }, i1 } %t199, ptr %l101
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb35:
  %t200 = load { { i64, ptr }, i1 }, ptr %l101
  store { { i64, ptr }, i1 } %t200, ptr %l15
  %t201 = getelementptr { { i64, ptr }, i1 }, ptr %l15, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201
  store { i64, ptr } %t202, ptr %l102
  %t203 = load { i64, ptr }, ptr %l102
  %t204 = extractvalue { i64, ptr } %t203, 0
  store i64 %t204, ptr %l103
  %t205 = load i64, ptr %l103
  %t206 = mul i64 %t205, 1
  %t207 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t206)
  %t208 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  store { i64, ptr } %t209, ptr %l104
  %t210 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t211 = load ptr, ptr %t210
  %t212 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t213 = load ptr, ptr %t212
  %t214 = load i64, ptr %l103
  %t215 = mul i64 %t214, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t211, ptr %t213, i64 %t215, i1 false)
  %t216 = load { i64, ptr }, ptr %l104
  store { i64, ptr } %t216, ptr %l16
  %t217 = getelementptr { { i64, ptr }, i1 }, ptr %l15, i32 0, i32 1
  %t218 = load i1, ptr %t217
  store i1 %t218, ptr %l105
  %t219 = load i1, ptr %l105
  store i1 %t219, ptr %l17
  %t220 = load ptr, ptr %l2
  store ptr %t220, ptr %l106
  %t221 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t221, ptr %l107
  %t222 = load i1, ptr %l17
  store i1 %t222, ptr %l108
  %t223 = load i1, ptr %l108
  br i1 %t223, label %bb36, label %bb37
bb36:
  %t224 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t224, ptr %l110
  %t225 = load { i64, ptr }, ptr %l110
  %t226 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %s8, ptr %s8, { i64, ptr } %t225)
  store %"compiler/msgs:Msg" %t226, ptr %l111
  br label %bb38
bb37:
  %t227 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %s8)
  store %"compiler/msgs:Msg" %t227, ptr %l112
  br label %bb39
bb38:
  %t228 = load %"compiler/msgs:Msg", ptr %l111
  store %"compiler/msgs:Msg" %t228, ptr %l109
  br label %bb40
bb39:
  %t229 = load %"compiler/msgs:Msg", ptr %l112
  store %"compiler/msgs:Msg" %t229, ptr %l109
  br label %bb40
bb40:
  %t230 = load ptr, ptr %l106
  %t231 = load { i64, [3 x i64] }, ptr %l107
  %t232 = load %"compiler/msgs:Msg", ptr %l109
  %t233 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t230, { i64, [3 x i64] } %t231, %"compiler/msgs:Msg" %t232)
  store i64 %t233, ptr %l113
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb43:
  %t234 = load { i64, [5 x i64] }, ptr %l13
  store { i64, [5 x i64] } %t234, ptr %l114
  %t235 = load { i64, [5 x i64] }, ptr %l114
  %t236 = extractvalue { i64, [5 x i64] } %t235, 0
  %t237 = icmp eq i64 %t236, 2
  store i1 %t237, ptr %l115
  %t238 = load i1, ptr %l115
  br i1 %t238, label %bb44, label %bb45
bb44:
  %t239 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t240 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t239, i32 0, i32 0
  %t241 = load i32, ptr %t240
  store i32 %t241, ptr %l116
  %t242 = load i32, ptr %l116
  store i32 %t242, ptr %l18
  %t243 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t244 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t243, i32 0, i32 1
  %t245 = load i64, ptr %t244
  store i64 %t245, ptr %l117
  %t246 = load i64, ptr %l117
  store i64 %t246, ptr %l19
  %t247 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t248 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t247, i32 0, i32 2
  %t249 = load %"compiler/source:Span", ptr %t248
  store %"compiler/source:Span" %t249, ptr %l118
  %t250 = load %"compiler/source:Span", ptr %l118
  store %"compiler/source:Span" %t250, ptr %l20
  br label %bb46
bb45:
  br label %bb52
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t251 = load i64, ptr %l4
  store i64 %t251, ptr %l119
  %t252 = load i64, ptr %l119
  %t253 = add i64 %t252, 1
  store i64 %t253, ptr %l120
  %t254 = load i64, ptr %l120
  store i64 %t254, ptr %l4
  %t255 = load ptr, ptr %l2
  store ptr %t255, ptr %l121
  %t256 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t256, ptr %l122
  %t257 = load i32, ptr %l18
  store i32 %t257, ptr %l123
  %t258 = load i32, ptr %l123
  %t259 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s9, i32 %t258)
  store { i64, ptr } %t259, ptr %l124
  br label %bb47
bb47:
  %t260 = load { i64, ptr }, ptr %l124
  %t261 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %s9, ptr %s9, { i64, ptr } %t260)
  store %"compiler/msgs:Msg" %t261, ptr %l125
  br label %bb48
bb48:
  %t262 = load ptr, ptr %l121
  %t263 = load { i64, [3 x i64] }, ptr %l122
  %t264 = load %"compiler/msgs:Msg", ptr %l125
  %t265 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t262, { i64, [3 x i64] } %t263, %"compiler/msgs:Msg" %t264)
  store i64 %t265, ptr %l126
  br label %bb49
bb49:
  %t266 = load i64, ptr %l126
  store i64 %t266, ptr %l21
  %t267 = load ptr, ptr %l2
  store ptr %t267, ptr %l127
  %t268 = load i64, ptr %l21
  store i64 %t268, ptr %l128
  %t269 = load i64, ptr %l19
  store i64 %t269, ptr %l129
  %t270 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t271 = load i32, ptr %t270
  store i32 %t271, ptr %l130
  %t272 = load i32, ptr %l130
  %t273 = sext i32 %t272 to i64
  store i64 %t273, ptr %l131
  %t274 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 1
  %t275 = load i32, ptr %t274
  store i32 %t275, ptr %l132
  %t276 = load i32, ptr %l132
  %t277 = sext i32 %t276 to i64
  store i64 %t277, ptr %l133
  store { i64, [3 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [3 x i64] }, ptr %t278, i32 0, i32 0
  store i64 3, ptr %t279
  %t280 = load i64, ptr %l129
  %t281 = insertvalue { i64, i64, i64 } undef, i64 %t280, 0
  %t282 = load i64, ptr %l131
  %t283 = insertvalue { i64, i64, i64 } %t281, i64 %t282, 1
  %t284 = load i64, ptr %l133
  %t285 = insertvalue { i64, i64, i64 } %t283, i64 %t284, 2
  %t286 = getelementptr { i64, [3 x i64] }, ptr %t278, i32 0, i32 1
  store { i64, i64, i64 } %t285, ptr %t286
  %t287 = load { i64, [3 x i64] }, ptr %t278
  store { i64, [3 x i64] } %t287, ptr %l134
  %t288 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s9)
  store %"compiler/msgs:Msg" %t288, ptr %l135
  br label %bb50
bb50:
  %t289 = load ptr, ptr %l127
  %t290 = load i64, ptr %l128
  %t291 = load { i64, [3 x i64] }, ptr %l134
  %t292 = load %"compiler/msgs:Msg", ptr %l135
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s9, ptr %t289, i64 %t290, { i64, [3 x i64] } %t291, %"compiler/msgs:Msg" %t292)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb57:
  call void @__olang_scope_close(ptr %s4)
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t293 = load i64, ptr %l9
  store i64 %t293, ptr %l136
  %t294 = load i64, ptr %l136
  %t295 = add i64 %t294, 1
  store i64 %t295, ptr %l137
  %t296 = load i64, ptr %l137
  store i64 %t296, ptr %l9
  call void @__olang_scope_close(ptr %s11)
  br label %bb13
bb59:
  %t297 = load i64, ptr %l6
  store i64 %t297, ptr %l138
  %t298 = load i64, ptr %l8
  store i64 %t298, ptr %l139
  %t299 = load i64, ptr %l138
  %t300 = load i64, ptr %l139
  %t301 = add i64 %t299, %t300
  store i64 %t301, ptr %l140
  %t302 = load i64, ptr %l140
  store i64 %t302, ptr %l6
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb60:
  br label %bb6
bb61:
  call void @__olang_scope_close(ptr %s2)
  %t303 = load i64, ptr %l4
  store i64 %t303, ptr %l141
  call void @__olang_scope_close(ptr %s0)
  %t304 = load i64, ptr %l141
  store i64 %t304, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2eStopText(ptr %v0, ptr %v1, ptr %v2, { i64, [5 x i64] } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, [5 x i64] }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca { i64, [5 x i64] }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, [5 x i64] }
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, [5 x i64] }
  %l23 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, [5 x i64] }
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, [5 x i64] } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [5 x i64] }, ptr %l0
  store { i64, [5 x i64] } %t1, ptr %l11
  %t2 = load { i64, [5 x i64] }, ptr %l11
  %t3 = extractvalue { i64, [5 x i64] } %t2, 0
  %t4 = icmp eq i64 %t3, 0
  store i1 %t4, ptr %l12
  %t5 = load i1, ptr %l12
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d12 }, ptr %l13
  %t6 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t6, ptr %l14
  %t7 = load { i64, ptr }, ptr %l14
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l15
  %t9 = load i64, ptr %l15
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l16
  %t14 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t15 = load ptr, ptr %t14
  %t16 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t17 = load ptr, ptr %t16
  %t18 = load i64, ptr %l15
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t20, ptr %l14
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb4:
  %t22 = load { i64, [5 x i64] }, ptr %l0
  store { i64, [5 x i64] } %t22, ptr %l17
  %t23 = load { i64, [5 x i64] }, ptr %l17
  %t24 = extractvalue { i64, [5 x i64] } %t23, 0
  %t25 = icmp eq i64 %t24, 1
  store i1 %t25, ptr %l18
  %t26 = load i1, ptr %l18
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l19
  %t30 = load i64, ptr %l19
  store i64 %t30, ptr %l2
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l2
  store i64 %t31, ptr %l20
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t32 = extractvalue { i64, ptr } { i64 23, ptr @.d13 }, 1
  %t33 = extractvalue { i64, ptr } { i64 23, ptr @.d13 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t32, i64 %t33)
  %t34 = load i64, ptr %l20
  %t35 = call ptr @__olang_sb_room(ptr %s3, i64 24)
  %t36 = call i64 @__olang_fmt_i64(ptr %t35, i64 %t34)
  call void @__olang_sb_add(ptr %s3, i64 %t36)
  %t37 = load ptr, ptr %s3
  %t38 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t39 = load i64, ptr %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t37, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l21
  call void @__olang_sb_done(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t43 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb8:
  %t44 = load { i64, [5 x i64] }, ptr %l0
  store { i64, [5 x i64] } %t44, ptr %l22
  %t45 = load { i64, [5 x i64] }, ptr %l22
  %t46 = extractvalue { i64, [5 x i64] } %t45, 0
  %t47 = icmp eq i64 %t46, 2
  store i1 %t47, ptr %l23
  %t48 = load i1, ptr %l23
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t49 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t50 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t49, i32 0, i32 0
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l24
  %t52 = load i32, ptr %l24
  store i32 %t52, ptr %l3
  %t53 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t54 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t53, i32 0, i32 1
  %t55 = load i64, ptr %t54
  store i64 %t55, ptr %l25
  %t56 = load i64, ptr %l25
  store i64 %t56, ptr %l4
  %t57 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t58 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t57, i32 0, i32 2
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l26
  %t60 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t60, ptr %l5
  %t61 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t62 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t61, i32 0, i32 3
  %t63 = load { i64, ptr }, ptr %t62
  store { i64, ptr } %t63, ptr %l27
  %t64 = load { i64, ptr }, ptr %l27
  store { i64, ptr } %t64, ptr %l6
  br label %bb11
bb10:
  br label %bb23
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load i32, ptr %l3
  store i32 %t65, ptr %l28
  %t66 = load i32, ptr %l28
  %t67 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s4, i32 %t66)
  store { i64, ptr } %t67, ptr %l29
  br label %bb12
bb12:
  %t68 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t68, ptr %l7
  %t69 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t69, ptr %l30
  %t70 = load { i64, ptr }, ptr %l30
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr @.d14 })
  store i1 %t71, ptr %l31
  br label %bb13
bb13:
  %t72 = load i1, ptr %l31
  br i1 %t72, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t73 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t73, ptr %l32
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t74 = load { i64, ptr }, ptr %l32
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  call void @__olang_sb_put(ptr %s6, ptr %t75, i64 %t76)
  %t77 = load ptr, ptr %s6
  %t78 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t79 = load i64, ptr %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t77, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l33
  call void @__olang_sb_done(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t84, ptr %l34
  %t85 = load { i64, ptr }, ptr %l34
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr @.d15 })
  store i1 %t86, ptr %l35
  br label %bb17
bb17:
  %t87 = load i1, ptr %l35
  br i1 %t87, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = load ptr, ptr %l1
  store ptr %t88, ptr %l36
  %t89 = load i64, ptr %l4
  store i64 %t89, ptr %l37
  %t90 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t90, ptr %l38
  %t91 = load ptr, ptr %l36
  %t92 = load i64, ptr %l37
  %t93 = load %"compiler/source:Span", ptr %l38
  %t94 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s7, ptr %t91, i64 %t92, %"compiler/source:Span" %t93)
  store { i64, ptr } %t94, ptr %l39
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t95 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t95, ptr %l40
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t96 = load { i64, ptr }, ptr %l39
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  call void @__olang_sb_put(ptr %s8, ptr %t97, i64 %t98)
  %t99 = extractvalue { i64, ptr } { i64 2, ptr @.d16 }, 1
  %t100 = extractvalue { i64, ptr } { i64 2, ptr @.d16 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t99, i64 %t100)
  %t101 = load { i64, ptr }, ptr %l40
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  call void @__olang_sb_put(ptr %s8, ptr %t102, i64 %t103)
  %t104 = load ptr, ptr %s8
  %t105 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t106 = load i64, ptr %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t104, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l41
  call void @__olang_sb_done(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t110 = load { i64, ptr }, ptr %l41
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb21:
  %t111 = load ptr, ptr %l1
  store ptr %t111, ptr %l42
  %t112 = load i64, ptr %l4
  store i64 %t112, ptr %l43
  %t113 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t113, ptr %l44
  %t114 = load ptr, ptr %l42
  %t115 = load i64, ptr %l43
  %t116 = load %"compiler/source:Span", ptr %l44
  %t117 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t114, i64 %t115, %"compiler/source:Span" %t116)
  store { i64, ptr } %t117, ptr %l45
  br label %bb22
bb22:
  %t118 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t118, ptr %l46
  %t119 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t119, ptr %l47
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t120 = load { i64, ptr }, ptr %l45
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  call void @__olang_sb_put(ptr %s9, ptr %t121, i64 %t122)
  %t123 = extractvalue { i64, ptr } { i64 2, ptr @.d17 }, 1
  %t124 = extractvalue { i64, ptr } { i64 2, ptr @.d17 }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t123, i64 %t124)
  %t125 = load { i64, ptr }, ptr %l46
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  call void @__olang_sb_put(ptr %s9, ptr %t126, i64 %t127)
  %t128 = extractvalue { i64, ptr } { i64 2, ptr @.d18 }, 1
  %t129 = extractvalue { i64, ptr } { i64 2, ptr @.d18 }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t128, i64 %t129)
  %t130 = load { i64, ptr }, ptr %l47
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  call void @__olang_sb_put(ptr %s9, ptr %t131, i64 %t132)
  %t133 = load ptr, ptr %s9
  %t134 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t135 = load i64, ptr %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t136, ptr %t133, i64 %t135, i1 false)
  %t137 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l48
  call void @__olang_sb_done(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t139 = load { i64, ptr }, ptr %l48
  store { i64, ptr } %t139, ptr %rv
  br label %ret
bb23:
  %t140 = load { i64, [5 x i64] }, ptr %l0
  store { i64, [5 x i64] } %t140, ptr %l49
  %t141 = load { i64, [5 x i64] }, ptr %l49
  %t142 = extractvalue { i64, [5 x i64] } %t141, 0
  %t143 = icmp eq i64 %t142, 3
  store i1 %t143, ptr %l50
  %t144 = load i1, ptr %l50
  br i1 %t144, label %bb24, label %bb25
bb24:
  %t145 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t146 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t145, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146
  store { i64, ptr } %t147, ptr %l51
  %t148 = load { i64, ptr }, ptr %l51
  store { i64, ptr } %t148, ptr %l8
  %t149 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t150 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t149, i32 0, i32 1
  %t151 = load i64, ptr %t150
  store i64 %t151, ptr %l52
  %t152 = load i64, ptr %l52
  store i64 %t152, ptr %l9
  %t153 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t154 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t153, i32 0, i32 2
  %t155 = load %"compiler/source:Span", ptr %t154
  store %"compiler/source:Span" %t155, ptr %l53
  %t156 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t156, ptr %l10
  br label %bb26
bb25:
  br label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s10
  %t157 = load ptr, ptr %l1
  store ptr %t157, ptr %l54
  %t158 = load i64, ptr %l9
  store i64 %t158, ptr %l55
  %t159 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t159, ptr %l56
  %t160 = load ptr, ptr %l54
  %t161 = load i64, ptr %l55
  %t162 = load %"compiler/source:Span", ptr %l56
  %t163 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s10, ptr %t160, i64 %t161, %"compiler/source:Span" %t162)
  store { i64, ptr } %t163, ptr %l57
  br label %bb27
bb27:
  %t164 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t164, ptr %l58
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  %t165 = load { i64, ptr }, ptr %l57
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  call void @__olang_sb_put(ptr %s11, ptr %t166, i64 %t167)
  %t168 = extractvalue { i64, ptr } { i64 2, ptr @.d19 }, 1
  %t169 = extractvalue { i64, ptr } { i64 2, ptr @.d19 }, 0
  call void @__olang_sb_put(ptr %s11, ptr %t168, i64 %t169)
  %t170 = load { i64, ptr }, ptr %l58
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  call void @__olang_sb_put(ptr %s11, ptr %t171, i64 %t172)
  %t173 = load ptr, ptr %s11
  %t174 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t175 = load i64, ptr %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t173, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l59
  call void @__olang_sb_done(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t179 = load { i64, ptr }, ptr %l59
  store { i64, ptr } %t179, ptr %rv
  br label %ret
bb28:
  call void @__olang_check_failed(ptr @.c20)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, i1 } @compiler_2finterp_2echain(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i1, i1 }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca { i64, i1 }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i1, i1 }
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, i1 }
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca { i64, i1 }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, i1 }
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca { i64, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, i1 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l4
  %t1 = load ptr, ptr %l3
  store ptr %t1, ptr %l10
  %t2 = load ptr, ptr %l10
  store ptr %t2, ptr %l5
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l5
  store ptr %t3, ptr %l11
  %t4 = load ptr, ptr %l11
  %t5 = icmp ne ptr %t4, null
  store i1 %t5, ptr %l12
  %t6 = load i1, ptr %l12
  %t7 = xor i1 %t6, true
  store i1 %t7, ptr %l13
  %t8 = load i1, ptr %l13
  br i1 %t8, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1
  store ptr %t9, ptr %l14
  %t10 = load i64, ptr %l2
  store i64 %t10, ptr %l15
  %t11 = load ptr, ptr %l5
  store ptr %t11, ptr %l16
  %t12 = load ptr, ptr %l16
  %t13 = getelementptr %"compiler/ast:TopIf", ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l17
  %t15 = load ptr, ptr %l14
  %t16 = load i64, ptr %l15
  %t17 = load ptr, ptr %l17
  %t18 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v1, ptr %v2, ptr %t15, i64 %t16, ptr %t17)
  store i64 %t18, ptr %l18
  br label %bb5
bb5:
  %t19 = load i64, ptr %l18
  store i64 %t19, ptr %l6
  %t20 = load i64, ptr %l6
  store i64 %t20, ptr %l19
  %t21 = load i64, ptr %l19
  %t22 = icmp slt i64 %t21, 0
  store i1 %t22, ptr %l20
  %t23 = load i1, ptr %l20
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = insertvalue { i64, i1 } undef, i64 0, 0
  %t25 = insertvalue { i64, i1 } %t24, i1 false, 1
  store { i64, i1 } %t25, ptr %l21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, i1 }, ptr %l21
  store { i64, i1 } %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0
  store ptr %t27, ptr %l22
  %t28 = load i64, ptr %l6
  store i64 %t28, ptr %l23
  %t29 = load ptr, ptr %l22
  %t30 = load i64, ptr %l23
  %t31 = call { i1, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v0, ptr %t29, i64 %t30)
  store { i1, i1 } %t31, ptr %l24
  br label %bb9
bb9:
  %t32 = load { i1, i1 }, ptr %l24
  store { i1, i1 } %t32, ptr %l7
  %t33 = getelementptr { i1, i1 }, ptr %l7, i32 0, i32 0
  %t34 = load i1, ptr %t33
  store i1 %t34, ptr %l25
  %t35 = load i1, ptr %l25
  store i1 %t35, ptr %l8
  %t36 = getelementptr { i1, i1 }, ptr %l7, i32 0, i32 1
  %t37 = load i1, ptr %t36
  store i1 %t37, ptr %l26
  %t38 = load i1, ptr %l26
  store i1 %t38, ptr %l9
  %t39 = load i1, ptr %l9
  store i1 %t39, ptr %l27
  %t40 = load i1, ptr %l27
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l28
  %t42 = load i1, ptr %l28
  br i1 %t42, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = insertvalue { i64, i1 } undef, i64 0, 0
  %t44 = insertvalue { i64, i1 } %t43, i1 false, 1
  store { i64, i1 } %t44, ptr %l29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, i1 }, ptr %l29
  store { i64, i1 } %t45, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t46 = load i1, ptr %l8
  store i1 %t46, ptr %l30
  %t47 = load i1, ptr %l30
  br i1 %t47, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l4
  store i64 %t48, ptr %l31
  %t49 = load i64, ptr %l31
  %t50 = insertvalue { i64, i1 } undef, i64 %t49, 0
  %t51 = insertvalue { i64, i1 } %t50, i1 true, 1
  store { i64, i1 } %t51, ptr %l32
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, i1 }, ptr %l32
  store { i64, i1 } %t52, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l4
  store i64 %t53, ptr %l33
  %t54 = load i64, ptr %l33
  %t55 = add i64 %t54, 1
  store i64 %t55, ptr %l34
  %t56 = load i64, ptr %l34
  store i64 %t56, ptr %l4
  %t57 = load ptr, ptr %l5
  store ptr %t57, ptr %l35
  %t58 = load ptr, ptr %l35
  %t59 = getelementptr %"compiler/ast:TopIf", ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l36
  %t61 = load ptr, ptr %l36
  %t62 = icmp eq ptr %t61, null
  store i1 %t62, ptr %l37
  %t63 = load i1, ptr %l37
  br i1 %t63, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load ptr, ptr %l5
  store ptr %t64, ptr %l38
  %t65 = load ptr, ptr %l38
  %t66 = getelementptr %"compiler/ast:TopIf", ptr %t65, i32 0, i32 3
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l39
  %t68 = load ptr, ptr %l39
  %t69 = icmp ne ptr %t68, null
  store i1 %t69, ptr %l40
  %t70 = load i1, ptr %l40
  br i1 %t70, label %bb18, label %bb19
bb17:
  br label %bb21
bb18:
  %t71 = load i64, ptr %l4
  store i64 %t71, ptr %l42
  %t72 = load i64, ptr %l42
  store i64 %t72, ptr %l41
  br label %bb20
bb19:
  %t73 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch
  store i64 %t73, ptr %l43
  %t74 = load i64, ptr %l43
  store i64 %t74, ptr %l41
  br label %bb20
bb20:
  %t75 = load i64, ptr %l41
  %t76 = insertvalue { i64, i1 } undef, i64 %t75, 0
  %t77 = insertvalue { i64, i1 } %t76, i1 true, 1
  store { i64, i1 } %t77, ptr %l44
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t78 = load { i64, i1 }, ptr %l44
  store { i64, i1 } %t78, ptr %rv
  br label %ret
bb21:
  %t79 = load ptr, ptr %l5
  store ptr %t79, ptr %l45
  %t80 = load ptr, ptr %l45
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l46
  %t83 = load ptr, ptr %l46
  store ptr %t83, ptr %l5
  call void @__olang_scope_close(ptr %s1)
  br label %bb22
bb22:
  br label %bb1
bb23:
  %t84 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch
  store i64 %t84, ptr %l47
  %t85 = load i64, ptr %l47
  %t86 = insertvalue { i64, i1 } undef, i64 %t85, 0
  %t87 = insertvalue { i64, i1 } %t86, i1 true, 1
  store { i64, i1 } %t87, ptr %l48
  call void @__olang_scope_close(ptr %s0)
  %t88 = load { i64, i1 }, ptr %l48
  store { i64, i1 } %t88, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i1 }, ptr %rv
  ret { i64, i1 } %rr
}

define dso_local { i1, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca { i64, [5 x i64] }
  %l4 = alloca { i64, [5 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca ptr
  %l10 = alloca { i64, [1 x i64] }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, [5 x i64] }
  %l19 = alloca { i64, [5 x i64] }
  %l20 = alloca { i64, [5 x i64] }
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, [5 x i64] }
  %l24 = alloca i1
  %l25 = alloca { i64, [5 x i64] }
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, [5 x i64] }
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca { i64, [5 x i64] }
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, [5 x i64] }
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i1
  %l63 = alloca { i64, [5 x i64] }
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, [5 x i64] }
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca { i1, i1 }
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca %"compiler/eval:Ptr"
  %l90 = alloca i32
  %l91 = alloca i64
  %l92 = alloca i1
  %l93 = alloca { i1, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i1, i1 }
  %t5 = alloca { i64, [1 x i64] }, align 8
  %t40 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1
  store i64 %t1, ptr %l5
  %t2 = load i64, ptr %l5
  %t3 = trunc i64 %t2 to i32
  store i32 %t3, ptr %l6
  %t4 = load i32, ptr %l6
  store i32 %t4, ptr %l7
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load i32, ptr %l7
  %t8 = insertvalue { i32 } undef, i32 %t7, 0
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t5
  store { i64, [1 x i64] } %t10, ptr %l8
  %t11 = load { i64, [1 x i64] }, ptr %l8
  store { i64, [1 x i64] } %t11, ptr %l2
  %t12 = load ptr, ptr %l0
  store ptr %t12, ptr %l9
  %t13 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t13, ptr %l10
  %t14 = load ptr, ptr %l9
  %t15 = load { i64, [1 x i64] }, ptr %l10
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t14, { i64, [1 x i64] } %t15)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l11
  %t17 = load ptr, ptr %l11
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t17, i32 0, i32 4
  store ptr %t18, ptr %l12
  %t19 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t19, ptr %l13
  %t20 = icmp sge i64 0, 0
  store i1 %t20, ptr %l14
  %t21 = load i1, ptr %l14
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  store i1 %t22, ptr %l15
  %t23 = load i1, ptr %l15
  br i1 %t23, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l16
  %t28 = load { i64, ptr }, ptr %l16
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l17
  %t35 = load ptr, ptr %l12
  %t36 = load { i64, [1 x i64] }, ptr %l13
  %t37 = load { i64, ptr }, ptr %l17
  %t38 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t35, { i64, [1 x i64] } %t36, { i64, ptr } %t37)
  store { i64, [5 x i64] } %t38, ptr %l18
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb6:
  %t39 = load { i64, [5 x i64] }, ptr %l18
  store { i64, [5 x i64] } %t39, ptr %l3
  store { i64, [5 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [5 x i64] }, ptr %t40
  store { i64, [5 x i64] } %t42, ptr %l19
  %t43 = load { i64, [5 x i64] }, ptr %l19
  store { i64, [5 x i64] } %t43, ptr %l4
  %t44 = load { i64, [5 x i64] }, ptr %l3
  store { i64, [5 x i64] } %t44, ptr %l20
  %t45 = load { i64, [5 x i64] }, ptr %l20
  %t46 = extractvalue { i64, [5 x i64] } %t45, 0
  %t47 = icmp eq i64 %t46, 0
  store i1 %t47, ptr %l21
  %t48 = load i1, ptr %l21
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t49 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t49, ptr %l23
  %t50 = load { i64, [5 x i64] }, ptr %l23
  %t51 = extractvalue { i64, [5 x i64] } %t50, 0
  %t52 = icmp eq i64 %t51, 0
  store i1 %t52, ptr %l24
  %t53 = load i1, ptr %l24
  store i1 %t53, ptr %l22
  br label %bb50
bb8:
  %t54 = load { i64, [5 x i64] }, ptr %l3
  store { i64, [5 x i64] } %t54, ptr %l25
  %t55 = load { i64, [5 x i64] }, ptr %l25
  %t56 = extractvalue { i64, [5 x i64] } %t55, 0
  %t57 = icmp eq i64 %t56, 1
  store i1 %t57, ptr %l26
  %t58 = load i1, ptr %l26
  br i1 %t58, label %bb9, label %bb10
bb9:
  %t59 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t59, ptr %l28
  %t60 = load { i64, [5 x i64] }, ptr %l28
  %t61 = extractvalue { i64, [5 x i64] } %t60, 0
  %t62 = icmp eq i64 %t61, 1
  store i1 %t62, ptr %l29
  %t63 = load i1, ptr %l29
  br i1 %t63, label %bb11, label %bb12
bb10:
  %t64 = load { i64, [5 x i64] }, ptr %l3
  store { i64, [5 x i64] } %t64, ptr %l36
  %t65 = load { i64, [5 x i64] }, ptr %l36
  %t66 = extractvalue { i64, [5 x i64] } %t65, 0
  %t67 = icmp eq i64 %t66, 2
  store i1 %t67, ptr %l37
  %t68 = load i1, ptr %l37
  br i1 %t68, label %bb15, label %bb16
bb11:
  %t69 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t70 = getelementptr { i64 }, ptr %t69, i32 0, i32 0
  %t71 = load i64, ptr %t70
  store i64 %t71, ptr %l31
  store ptr %l31, ptr %l32
  %t72 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t73 = getelementptr { i64 }, ptr %t72, i32 0, i32 0
  %t74 = load i64, ptr %t73
  store i64 %t74, ptr %l33
  store ptr %l33, ptr %l34
  %t75 = load ptr, ptr %l32
  %t76 = load ptr, ptr %l34
  %t77 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t75, ptr %t76)
  store i1 %t77, ptr %l35
  br label %bb13
bb12:
  store i1 false, ptr %l30
  br label %bb14
bb13:
  %t78 = load i1, ptr %l35
  store i1 %t78, ptr %l30
  br label %bb14
bb14:
  %t79 = load i1, ptr %l30
  store i1 %t79, ptr %l27
  br label %bb49
bb15:
  %t80 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t80, ptr %l39
  %t81 = load { i64, [5 x i64] }, ptr %l39
  %t82 = extractvalue { i64, [5 x i64] } %t81, 0
  %t83 = icmp eq i64 %t82, 2
  store i1 %t83, ptr %l40
  %t84 = load i1, ptr %l40
  br i1 %t84, label %bb17, label %bb18
bb16:
  %t85 = load { i64, [5 x i64] }, ptr %l3
  store { i64, [5 x i64] } %t85, ptr %l63
  %t86 = load { i64, [5 x i64] }, ptr %l63
  %t87 = extractvalue { i64, [5 x i64] } %t86, 0
  %t88 = icmp eq i64 %t87, 3
  store i1 %t88, ptr %l64
  %t89 = load i1, ptr %l64
  br i1 %t89, label %bb33, label %bb34
bb17:
  %t90 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t91 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91
  store i32 %t92, ptr %l42
  store ptr %l42, ptr %l43
  %t93 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t94 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l44
  store ptr %l44, ptr %l45
  %t96 = load ptr, ptr %l43
  %t97 = load ptr, ptr %l45
  %t98 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %t96, ptr %t97)
  store i1 %t98, ptr %l46
  br label %bb19
bb18:
  store i1 false, ptr %l41
  br label %bb20
bb19:
  %t99 = load i1, ptr %l46
  store i1 %t99, ptr %l41
  br label %bb20
bb20:
  %t100 = load i1, ptr %l41
  br i1 %t100, label %bb21, label %bb22
bb21:
  %t101 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t102 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t101, i32 0, i32 1
  %t103 = load i64, ptr %t102
  store i64 %t103, ptr %l48
  store ptr %l48, ptr %l49
  %t104 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t105 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t104, i32 0, i32 1
  %t106 = load i64, ptr %t105
  store i64 %t106, ptr %l50
  store ptr %l50, ptr %l51
  %t107 = load ptr, ptr %l49
  %t108 = load ptr, ptr %l51
  %t109 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t107, ptr %t108)
  store i1 %t109, ptr %l52
  br label %bb23
bb22:
  store i1 false, ptr %l47
  br label %bb24
bb23:
  %t110 = load i1, ptr %l52
  store i1 %t110, ptr %l47
  br label %bb24
bb24:
  %t111 = load i1, ptr %l47
  br i1 %t111, label %bb25, label %bb26
bb25:
  %t112 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t113 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t112, i32 0, i32 2
  %t114 = load %"compiler/source:Span", ptr %t113
  store %"compiler/source:Span" %t114, ptr %l54
  store ptr %l54, ptr %l55
  %t115 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t116 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t115, i32 0, i32 2
  %t117 = load %"compiler/source:Span", ptr %t116
  store %"compiler/source:Span" %t117, ptr %l56
  store ptr %l56, ptr %l57
  %t118 = load ptr, ptr %l55
  %t119 = load ptr, ptr %l57
  %t120 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t118, ptr %t119)
  store i1 %t120, ptr %l58
  br label %bb27
bb26:
  store i1 false, ptr %l53
  br label %bb28
bb27:
  %t121 = load i1, ptr %l58
  store i1 %t121, ptr %l53
  br label %bb28
bb28:
  %t122 = load i1, ptr %l53
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t123 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t124 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t123, i32 0, i32 3
  %t125 = load { i64, ptr }, ptr %t124
  store { i64, ptr } %t125, ptr %l60
  %t126 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t127 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t126, i32 0, i32 3
  %t128 = load { i64, ptr }, ptr %t127
  store { i64, ptr } %t128, ptr %l61
  %t129 = load { i64, ptr }, ptr %l60
  %t130 = load { i64, ptr }, ptr %l61
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t129, { i64, ptr } %t130)
  store i1 %t131, ptr %l62
  br label %bb31
bb30:
  store i1 false, ptr %l59
  br label %bb32
bb31:
  %t132 = load i1, ptr %l62
  store i1 %t132, ptr %l59
  br label %bb32
bb32:
  %t133 = load i1, ptr %l59
  store i1 %t133, ptr %l38
  br label %bb48
bb33:
  %t134 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t134, ptr %l66
  %t135 = load { i64, [5 x i64] }, ptr %l66
  %t136 = extractvalue { i64, [5 x i64] } %t135, 0
  %t137 = icmp eq i64 %t136, 3
  store i1 %t137, ptr %l67
  %t138 = load i1, ptr %l67
  br i1 %t138, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l65
  br label %bb47
bb35:
  %t139 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t140 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t139, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140
  store { i64, ptr } %t141, ptr %l69
  %t142 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t143 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t142, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143
  store { i64, ptr } %t144, ptr %l70
  %t145 = load { i64, ptr }, ptr %l69
  %t146 = load { i64, ptr }, ptr %l70
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t145, { i64, ptr } %t146)
  store i1 %t147, ptr %l71
  br label %bb37
bb36:
  store i1 false, ptr %l68
  br label %bb38
bb37:
  %t148 = load i1, ptr %l71
  store i1 %t148, ptr %l68
  br label %bb38
bb38:
  %t149 = load i1, ptr %l68
  br i1 %t149, label %bb39, label %bb40
bb39:
  %t150 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t151 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t150, i32 0, i32 1
  %t152 = load i64, ptr %t151
  store i64 %t152, ptr %l73
  store ptr %l73, ptr %l74
  %t153 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t154 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t153, i32 0, i32 1
  %t155 = load i64, ptr %t154
  store i64 %t155, ptr %l75
  store ptr %l75, ptr %l76
  %t156 = load ptr, ptr %l74
  %t157 = load ptr, ptr %l76
  %t158 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t156, ptr %t157)
  store i1 %t158, ptr %l77
  br label %bb41
bb40:
  store i1 false, ptr %l72
  br label %bb42
bb41:
  %t159 = load i1, ptr %l77
  store i1 %t159, ptr %l72
  br label %bb42
bb42:
  %t160 = load i1, ptr %l72
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t161 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t162 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t161, i32 0, i32 2
  %t163 = load %"compiler/source:Span", ptr %t162
  store %"compiler/source:Span" %t163, ptr %l79
  store ptr %l79, ptr %l80
  %t164 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t165 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t164, i32 0, i32 2
  %t166 = load %"compiler/source:Span", ptr %t165
  store %"compiler/source:Span" %t166, ptr %l81
  store ptr %l81, ptr %l82
  %t167 = load ptr, ptr %l80
  %t168 = load ptr, ptr %l82
  %t169 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t167, ptr %t168)
  store i1 %t169, ptr %l83
  br label %bb45
bb44:
  store i1 false, ptr %l78
  br label %bb46
bb45:
  %t170 = load i1, ptr %l83
  store i1 %t170, ptr %l78
  br label %bb46
bb46:
  %t171 = load i1, ptr %l78
  store i1 %t171, ptr %l65
  br label %bb47
bb47:
  %t172 = load i1, ptr %l65
  store i1 %t172, ptr %l38
  br label %bb48
bb48:
  %t173 = load i1, ptr %l38
  store i1 %t173, ptr %l27
  br label %bb49
bb49:
  %t174 = load i1, ptr %l27
  store i1 %t174, ptr %l22
  br label %bb50
bb50:
  %t175 = load i1, ptr %l22
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l84
  %t177 = load i1, ptr %l84
  br i1 %t177, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s1
  %t178 = insertvalue { i1, i1 } undef, i1 false, 0
  %t179 = insertvalue { i1, i1 } %t178, i1 false, 1
  store { i1, i1 } %t179, ptr %l85
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t180 = load { i1, i1 }, ptr %l85
  store { i1, i1 } %t180, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t181 = load ptr, ptr %l0
  store ptr %t181, ptr %l86
  %t182 = load ptr, ptr %l86
  %t183 = getelementptr %"compiler/interp:Exec", ptr %t182, i32 0, i32 4
  store ptr %t183, ptr %l87
  %t184 = load ptr, ptr %l0
  store ptr %t184, ptr %l88
  %t185 = load ptr, ptr %l88
  %t186 = getelementptr %"compiler/interp:Exec", ptr %t185, i32 0, i32 4
  %t187 = getelementptr %"compiler/eval:Machine", ptr %t186, i32 0, i32 7
  %t188 = load %"compiler/eval:Ptr", ptr %t187
  store %"compiler/eval:Ptr" %t188, ptr %l89
  %t189 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT
  store i32 %t189, ptr %l90
  %t190 = load ptr, ptr %l87
  %t191 = load %"compiler/eval:Ptr", ptr %l89
  %t192 = load i32, ptr %l90
  %t193 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t190, %"compiler/eval:Ptr" %t191, i32 %t192)
  store i64 %t193, ptr %l91
  br label %bb54
bb54:
  %t194 = load i64, ptr %l91
  %t195 = icmp ne i64 %t194, 0
  store i1 %t195, ptr %l92
  %t196 = load i1, ptr %l92
  %t197 = insertvalue { i1, i1 } undef, i1 %t196, 0
  %t198 = insertvalue { i1, i1 } %t197, i1 true, 1
  store { i1, i1 } %t198, ptr %l93
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i1, i1 }, ptr %l93
  store { i1, i1 } %t199, ptr %rv
  br label %ret
ret:
  %rr = load { i1, i1 }, ptr %rv
  ret { i1, i1 } %rr
}

define dso_local { %"std/prelude/list:List<I64>", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/list:List<I64>"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca { i64, [2 x i64] }
  %l49 = alloca { i64, [2 x i64] }
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca { i64, [2 x i64] }
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca %"std/prelude/list:List<I64>"
  %l87 = alloca i64
  %l88 = alloca { %"std/prelude/list:List<I64>", i64 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { %"std/prelude/list:List<I64>", i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List<I64>" %t2, ptr %l13
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List<I64>", ptr %l13
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List<I64>" %t4, ptr %t5
  store i64 -1, ptr %l2
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l14
  %t7 = load ptr, ptr %l14
  %t8 = getelementptr %"compiler/interp:Exec", ptr %t7, i32 0, i32 0
  %t9 = load ptr, ptr %t8
  store ptr %t9, ptr %l15
  %t10 = load ptr, ptr %l15
  store ptr %t10, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4
  %t11 = load ptr, ptr %l0
  store ptr %t11, ptr %l16
  %t12 = load ptr, ptr %l16
  %t13 = getelementptr %"compiler/interp:Exec", ptr %t12, i32 0, i32 1
  store ptr %t13, ptr %l17
  %t14 = load ptr, ptr %l17
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t14)
  store i64 %t15, ptr %l18
  br label %bb2
bb2:
  %t16 = load i64, ptr %l18
  store i64 %t16, ptr %l5
  store i64 1, ptr %l6
  %t17 = load i64, ptr %l5
  store i64 %t17, ptr %l19
  %t18 = load i64, ptr %l4
  store i64 %t18, ptr %l20
  %t19 = load i64, ptr %l19
  %t20 = load i64, ptr %l20
  %t21 = icmp sgt i64 %t19, %t20
  store i1 %t21, ptr %l21
  %t22 = load i1, ptr %l21
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l6
  store i64 %t23, ptr %l23
  %t24 = load i64, ptr %l23
  %t25 = icmp sgt i64 %t24, 0
  store i1 %t25, ptr %l24
  %t26 = load i1, ptr %l24
  br i1 %t26, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22
  br label %bb8
bb5:
  %t27 = load i64, ptr %l5
  store i64 %t27, ptr %l26
  %t28 = load i64, ptr %l4
  store i64 %t28, ptr %l27
  %t29 = load i64, ptr %l26
  %t30 = load i64, ptr %l27
  %t31 = sub i64 %t29, %t30
  store i64 %t31, ptr %l28
  %t32 = load i64, ptr %l6
  store i64 %t32, ptr %l29
  %t33 = load i64, ptr %l28
  %t34 = load i64, ptr %l29
  %t35 = add i64 %t33, %t34
  store i64 %t35, ptr %l30
  %t36 = load i64, ptr %l30
  %t37 = sub i64 %t36, 1
  store i64 %t37, ptr %l31
  %t38 = load i64, ptr %l6
  store i64 %t38, ptr %l32
  %t39 = load i64, ptr %l31
  %t40 = load i64, ptr %l32
  %t41 = sdiv i64 %t39, %t40
  store i64 %t41, ptr %l33
  %t42 = load i64, ptr %l33
  store i64 %t42, ptr %l25
  br label %bb7
bb6:
  store i64 0, ptr %l25
  br label %bb7
bb7:
  %t43 = load i64, ptr %l25
  store i64 %t43, ptr %l22
  br label %bb8
bb8:
  %t44 = load i64, ptr %l22
  store i64 %t44, ptr %l7
  store i64 0, ptr %l8
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l8
  store i64 %t45, ptr %l34
  %t46 = load i64, ptr %l7
  store i64 %t46, ptr %l35
  %t47 = load i64, ptr %l34
  %t48 = load i64, ptr %l35
  %t49 = icmp slt i64 %t47, %t48
  store i1 %t49, ptr %l36
  %t50 = load i1, ptr %l36
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l37
  %t52 = load i1, ptr %l37
  br i1 %t52, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l4
  store i64 %t53, ptr %l38
  %t54 = load i64, ptr %l8
  store i64 %t54, ptr %l39
  %t55 = load i64, ptr %l6
  store i64 %t55, ptr %l40
  %t56 = load i64, ptr %l39
  %t57 = load i64, ptr %l40
  %t58 = mul i64 %t56, %t57
  store i64 %t58, ptr %l41
  %t59 = load i64, ptr %l38
  %t60 = load i64, ptr %l41
  %t61 = add i64 %t59, %t60
  store i64 %t61, ptr %l42
  %t62 = load i64, ptr %l42
  store i64 %t62, ptr %l9
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l43
  %t64 = load ptr, ptr %l43
  %t65 = getelementptr %"compiler/interp:Exec", ptr %t64, i32 0, i32 1
  store ptr %t65, ptr %l44
  %t66 = load i64, ptr %l9
  store i64 %t66, ptr %l45
  %t67 = load ptr, ptr %l44
  %t68 = load i64, ptr %l45
  %t69 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t69, ptr %l46
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l46
  store ptr %t70, ptr %l47
  %t71 = load ptr, ptr %l47
  %t72 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 1
  %t73 = load { i64, [2 x i64] }, ptr %t72
  store { i64, [2 x i64] } %t73, ptr %l48
  %t74 = load { i64, [2 x i64] }, ptr %l48
  store { i64, [2 x i64] } %t74, ptr %l10
  %t75 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t75, ptr %l49
  %t76 = load { i64, [2 x i64] }, ptr %l49
  %t77 = extractvalue { i64, [2 x i64] } %t76, 0
  %t78 = icmp eq i64 %t77, 5
  store i1 %t78, ptr %l50
  %t79 = load i1, ptr %l50
  br i1 %t79, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb22
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t80 = load ptr, ptr %l0
  store ptr %t80, ptr %l51
  %t81 = load ptr, ptr %l51
  %t82 = getelementptr %"compiler/interp:Exec", ptr %t81, i32 0, i32 1
  store ptr %t82, ptr %l52
  %t83 = load i64, ptr %l9
  store i64 %t83, ptr %l53
  %t84 = load ptr, ptr %l52
  %t85 = load i64, ptr %l53
  %t86 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t84, i64 %t85)
  store ptr %t86, ptr %l54
  br label %bb17
bb17:
  %t87 = load ptr, ptr %l54
  store ptr %t87, ptr %l55
  %t88 = load ptr, ptr %l55
  %t89 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 11
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l56
  %t91 = load ptr, ptr %l56
  %t92 = icmp ne ptr %t91, null
  store i1 %t92, ptr %l57
  %t93 = load i1, ptr %l57
  br i1 %t93, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t94 = load ptr, ptr %lp1
  store ptr %t94, ptr %l58
  %t95 = load i64, ptr %l9
  store i64 %t95, ptr %l59
  %t96 = load ptr, ptr %l58
  %t97 = load i64, ptr %l59
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t96, i64 %t97)
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb22:
  %t98 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t98, ptr %l60
  %t99 = load { i64, [2 x i64] }, ptr %l60
  %t100 = extractvalue { i64, [2 x i64] } %t99, 0
  %t101 = icmp eq i64 %t100, 0
  store i1 %t101, ptr %l61
  %t102 = load i1, ptr %l61
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t103 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t104 = getelementptr { i64 }, ptr %t103, i32 0, i32 0
  %t105 = load i64, ptr %t104
  store i64 %t105, ptr %l62
  %t106 = load i64, ptr %l62
  store i64 %t106, ptr %l11
  br label %bb25
bb24:
  br label %bb37
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l3
  store ptr %t107, ptr %l63
  %t108 = load i64, ptr %l11
  store i64 %t108, ptr %l64
  %t109 = load ptr, ptr %l63
  %t110 = load i64, ptr %l64
  %t111 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t109, i64 %t110)
  store i64 %t111, ptr %l65
  br label %bb26
bb26:
  %t112 = load i64, ptr %l65
  store i64 %t112, ptr %l12
  %t113 = load ptr, ptr %l3
  store ptr %t113, ptr %l66
  %t114 = load i64, ptr %l12
  store i64 %t114, ptr %l67
  %t115 = load ptr, ptr %l66
  %t116 = load i64, ptr %l67
  %t117 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t115, i64 %t116)
  store i64 %t117, ptr %l68
  br label %bb27
bb27:
  %t118 = load ptr, ptr %l3
  store ptr %t118, ptr %l69
  %t119 = load ptr, ptr %l69
  %t120 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 0
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l70
  %t122 = load ptr, ptr %l70
  %t123 = getelementptr %"compiler/load:Loader", ptr %t122, i32 0, i32 7
  %t124 = load i64, ptr %t123
  store i64 %t124, ptr %l71
  %t125 = load i64, ptr %l68
  %t126 = load i64, ptr %l71
  %t127 = icmp eq i64 %t125, %t126
  store i1 %t127, ptr %l72
  %t128 = load i1, ptr %l72
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t129 = load ptr, ptr %l3
  store ptr %t129, ptr %l74
  %t130 = load ptr, ptr %l74
  %t131 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t132 = getelementptr %"compiler/types:Table", ptr %t131, i32 0, i32 0
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l75
  %t134 = load ptr, ptr %l3
  store ptr %t134, ptr %l76
  %t135 = load i64, ptr %l12
  store i64 %t135, ptr %l77
  %t136 = load ptr, ptr %l76
  %t137 = load i64, ptr %l77
  %t138 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t136, i64 %t137)
  store ptr %t138, ptr %l78
  br label %bb30
bb29:
  store i1 false, ptr %l73
  br label %bb33
bb30:
  %t139 = load ptr, ptr %l78
  store ptr %t139, ptr %l79
  %t140 = load ptr, ptr %l79
  %t141 = getelementptr %"compiler/ast:Func", ptr %t140, i32 0, i32 2
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l80
  %t143 = load ptr, ptr %l75
  %t144 = load i32, ptr %l80
  %t145 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t143, i32 %t144)
  store { i64, ptr } %t145, ptr %l81
  br label %bb31
bb31:
  %t146 = load { i64, ptr }, ptr %l81
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t146, { i64, ptr } { i64 4, ptr @.d22 })
  store i1 %t147, ptr %l82
  br label %bb32
bb32:
  %t148 = load i1, ptr %l82
  store i1 %t148, ptr %l73
  br label %bb33
bb33:
  %t149 = load i1, ptr %l73
  br i1 %t149, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t150 = load i64, ptr %l9
  store i64 %t150, ptr %l83
  %t151 = load i64, ptr %l83
  store i64 %t151, ptr %l2
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t152 = load i64, ptr %l8
  store i64 %t152, ptr %l84
  %t153 = load i64, ptr %l84
  %t154 = add i64 %t153, 1
  store i64 %t154, ptr %l85
  %t155 = load i64, ptr %l85
  store i64 %t155, ptr %l8
  call void @__olang_scope_close(ptr %s8)
  br label %bb9
bb44:
  call void @__olang_scope_close(ptr %s1)
  %t156 = load ptr, ptr %lp1
  %t157 = load %"std/prelude/list:List<I64>", ptr %t156
  store %"std/prelude/list:List<I64>" %t157, ptr %l86
  %t158 = load i64, ptr %l2
  store i64 %t158, ptr %l87
  %t159 = load %"std/prelude/list:List<I64>", ptr %l86
  %t160 = insertvalue { %"std/prelude/list:List<I64>", i64 } undef, %"std/prelude/list:List<I64>" %t159, 0
  %t161 = load i64, ptr %l87
  %t162 = insertvalue { %"std/prelude/list:List<I64>", i64 } %t160, i64 %t161, 1
  store { %"std/prelude/list:List<I64>", i64 } %t162, ptr %l88
  call void @__olang_scope_close(ptr %s0)
  %t163 = load { %"std/prelude/list:List<I64>", i64 }, ptr %l88
  store { %"std/prelude/list:List<I64>", i64 } %t163, ptr %rv
  br label %ret
ret:
  %rr = load { %"std/prelude/list:List<I64>", i64 }, ptr %rv
  ret { %"std/prelude/list:List<I64>", i64 } %rr
}

define dso_local { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, [5 x i64] }
  %l12 = alloca { i64, [5 x i64] }
  %l13 = alloca { i64, [5 x i64] }
  %l14 = alloca ptr
  %l15 = alloca { i64, [5 x i64] }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca { i64, [2 x i64] }
  %l40 = alloca { i64, [2 x i64] }
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca { i64, [5 x i64] }
  %l49 = alloca { i64, [5 x i64] }
  %l50 = alloca { i64, [5 x i64] }
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, [5 x i64] }
  %l54 = alloca i1
  %l55 = alloca { i64, [5 x i64] }
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, [5 x i64] }
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i1
  %l66 = alloca { i64, [5 x i64] }
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, [5 x i64] }
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i32
  %l73 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca { i64, [5 x i64] }
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca { i64, [5 x i64] }
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca ptr
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca { i64, [5 x i64] }
  %l117 = alloca { i64, [5 x i64] }
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca { i64, [5 x i64] }
  %l121 = alloca i1
  %l122 = alloca { i64, [5 x i64] }
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca { i64, [5 x i64] }
  %l126 = alloca i1
  %l127 = alloca i1
  %l128 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca i1
  %l133 = alloca { i64, [5 x i64] }
  %l134 = alloca i1
  %l135 = alloca i1
  %l136 = alloca { i64, [5 x i64] }
  %l137 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca i64
  %l146 = alloca ptr
  %l147 = alloca i64
  %l148 = alloca ptr
  %l149 = alloca i1
  %l150 = alloca i1
  %l151 = alloca %"compiler/source:Span"
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca ptr
  %l155 = alloca i1
  %l156 = alloca i1
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l159 = alloca i1
  %l160 = alloca { i64, [5 x i64] }
  %l161 = alloca i1
  %l162 = alloca i1
  %l163 = alloca { i64, [5 x i64] }
  %l164 = alloca i1
  %l165 = alloca i1
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca i1
  %l169 = alloca i1
  %l170 = alloca i64
  %l171 = alloca ptr
  %l172 = alloca i64
  %l173 = alloca ptr
  %l174 = alloca i1
  %l175 = alloca i1
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca ptr
  %l180 = alloca i1
  %l181 = alloca { i64, [5 x i64] }
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i64
  %l187 = alloca { i64, [5 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, [5 x i64] }
  %t3 = alloca { i64, [5 x i64] }, align 8
  %t84 = alloca { i64, [5 x i64] }, align 8
  %t222 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l14
  %t2 = load ptr, ptr %l14
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t2)
  br label %bb1
bb1:
  store { i64, [5 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load { i64, [5 x i64] }, ptr %t3
  store { i64, [5 x i64] } %t5, ptr %l15
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t6, ptr %lp1
  %t7 = load { i64, [5 x i64] }, ptr %l15
  %t8 = load ptr, ptr %lp1
  store { i64, [5 x i64] } %t7, ptr %t8
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0
  store ptr %t9, ptr %l16
  %t10 = load ptr, ptr %l16
  %t11 = getelementptr %"compiler/interp:Exec", ptr %t10, i32 0, i32 9
  store ptr %t11, ptr %l17
  %t12 = load ptr, ptr %l17
  store ptr %t12, ptr %l2
  store i64 0, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l2
  store ptr %t13, ptr %l19
  %t14 = load i64, ptr %l3
  store i64 %t14, ptr %l20
  %t15 = load ptr, ptr %l19
  %t16 = load i64, ptr %l20
  %t17 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l22
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb4, label %ok.21
ok.21:
  store { i64, ptr } %t18, ptr %l21
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t22, ptr %l18
  br label %bb8
bb4:
  %t23 = load i32, ptr %l22
  %t24 = ashr i32 %t23, 16
  store i32 %t24, ptr %l23
  %t25 = load i32, ptr %l23
  %t26 = icmp eq i32 %t25, 1
  store i1 %t26, ptr %l24
  %t27 = load i1, ptr %l24
  br i1 %t27, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb8:
  %t28 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t28, ptr %l4
  %t29 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t29, ptr %l25
  %t30 = load { i64, ptr }, ptr %l25
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l26
  %t32 = load i64, ptr %l26
  store i64 %t32, ptr %l5
  store i64 0, ptr %l6
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l6
  store i64 %t33, ptr %l27
  %t34 = load i64, ptr %l5
  store i64 %t34, ptr %l28
  %t35 = load i64, ptr %l27
  %t36 = load i64, ptr %l28
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l29
  %t38 = load i1, ptr %l29
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l30
  %t40 = load i1, ptr %l30
  br i1 %t40, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb119
bb11:
  br label %bb12
bb12:
  %t41 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t41, ptr %l31
  %t42 = load i64, ptr %l6
  store i64 %t42, ptr %l32
  %t43 = load i64, ptr %l32
  %t44 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  %t46 = getelementptr i64, ptr %t45, i64 %t43
  %t47 = load i64, ptr %t46
  store i64 %t47, ptr %l33
  %t48 = load i64, ptr %l33
  store i64 %t48, ptr %l7
  %t49 = load ptr, ptr %l0
  store ptr %t49, ptr %l34
  %t50 = load ptr, ptr %l34
  %t51 = getelementptr %"compiler/interp:Exec", ptr %t50, i32 0, i32 1
  store ptr %t51, ptr %l35
  %t52 = load i64, ptr %l7
  store i64 %t52, ptr %l36
  %t53 = load ptr, ptr %l35
  %t54 = load i64, ptr %l36
  %t55 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t55, ptr %l37
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l37
  store ptr %t56, ptr %l38
  %t57 = load ptr, ptr %l38
  %t58 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 1
  %t59 = load { i64, [2 x i64] }, ptr %t58
  store { i64, [2 x i64] } %t59, ptr %l39
  %t60 = load { i64, [2 x i64] }, ptr %l39
  store { i64, [2 x i64] } %t60, ptr %l8
  %t61 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t61, ptr %l40
  %t62 = load { i64, [2 x i64] }, ptr %l40
  %t63 = extractvalue { i64, [2 x i64] } %t62, 0
  %t64 = icmp eq i64 %t63, 6
  store i1 %t64, ptr %l41
  %t65 = load i1, ptr %l41
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t66 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t67 = getelementptr { i64, i32 }, ptr %t66, i32 0, i32 0
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l42
  %t69 = load i64, ptr %l42
  store i64 %t69, ptr %l9
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t71 = getelementptr { i64, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l43
  %t73 = load i32, ptr %l43
  store i32 %t73, ptr %l10
  br label %bb16
bb15:
  br label %bb112
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t74 = load ptr, ptr %l0
  store ptr %t74, ptr %l44
  %t75 = load ptr, ptr %l44
  %t76 = getelementptr %"compiler/interp:Exec", ptr %t75, i32 0, i32 4
  store ptr %t76, ptr %l45
  %t77 = load i64, ptr %l9
  store i64 %t77, ptr %l46
  %t78 = load i32, ptr %l10
  store i32 %t78, ptr %l47
  %t79 = load ptr, ptr %l45
  %t80 = load i64, ptr %l46
  %t81 = load i32, ptr %l47
  %t82 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v0, ptr %t79, i64 %t80, i32 %t81)
  store { i64, [5 x i64] } %t82, ptr %l48
  br label %bb17
bb17:
  %t83 = load { i64, [5 x i64] }, ptr %l48
  store { i64, [5 x i64] } %t83, ptr %l11
  store { i64, [5 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load { i64, [5 x i64] }, ptr %t84
  store { i64, [5 x i64] } %t86, ptr %l49
  %t87 = load { i64, [5 x i64] }, ptr %l49
  store { i64, [5 x i64] } %t87, ptr %l12
  %t88 = load { i64, [5 x i64] }, ptr %l11
  store { i64, [5 x i64] } %t88, ptr %l50
  %t89 = load { i64, [5 x i64] }, ptr %l50
  %t90 = extractvalue { i64, [5 x i64] } %t89, 0
  %t91 = icmp eq i64 %t90, 0
  store i1 %t91, ptr %l51
  %t92 = load i1, ptr %l51
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t93 = load { i64, [5 x i64] }, ptr %l12
  store { i64, [5 x i64] } %t93, ptr %l53
  %t94 = load { i64, [5 x i64] }, ptr %l53
  %t95 = extractvalue { i64, [5 x i64] } %t94, 0
  %t96 = icmp eq i64 %t95, 0
  store i1 %t96, ptr %l54
  %t97 = load i1, ptr %l54
  store i1 %t97, ptr %l52
  br label %bb61
bb19:
  %t98 = load { i64, [5 x i64] }, ptr %l11
  store { i64, [5 x i64] } %t98, ptr %l55
  %t99 = load { i64, [5 x i64] }, ptr %l55
  %t100 = extractvalue { i64, [5 x i64] } %t99, 0
  %t101 = icmp eq i64 %t100, 1
  store i1 %t101, ptr %l56
  %t102 = load i1, ptr %l56
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t103 = load { i64, [5 x i64] }, ptr %l12
  store { i64, [5 x i64] } %t103, ptr %l58
  %t104 = load { i64, [5 x i64] }, ptr %l58
  %t105 = extractvalue { i64, [5 x i64] } %t104, 0
  %t106 = icmp eq i64 %t105, 1
  store i1 %t106, ptr %l59
  %t107 = load i1, ptr %l59
  br i1 %t107, label %bb22, label %bb23
bb21:
  %t108 = load { i64, [5 x i64] }, ptr %l11
  store { i64, [5 x i64] } %t108, ptr %l66
  %t109 = load { i64, [5 x i64] }, ptr %l66
  %t110 = extractvalue { i64, [5 x i64] } %t109, 0
  %t111 = icmp eq i64 %t110, 2
  store i1 %t111, ptr %l67
  %t112 = load i1, ptr %l67
  br i1 %t112, label %bb26, label %bb27
bb22:
  %t113 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t114 = getelementptr { i64 }, ptr %t113, i32 0, i32 0
  %t115 = load i64, ptr %t114
  store i64 %t115, ptr %l61
  store ptr %l61, ptr %l62
  %t116 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t117 = getelementptr { i64 }, ptr %t116, i32 0, i32 0
  %t118 = load i64, ptr %t117
  store i64 %t118, ptr %l63
  store ptr %l63, ptr %l64
  %t119 = load ptr, ptr %l62
  %t120 = load ptr, ptr %l64
  %t121 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t119, ptr %t120)
  store i1 %t121, ptr %l65
  br label %bb24
bb23:
  store i1 false, ptr %l60
  br label %bb25
bb24:
  %t122 = load i1, ptr %l65
  store i1 %t122, ptr %l60
  br label %bb25
bb25:
  %t123 = load i1, ptr %l60
  store i1 %t123, ptr %l57
  br label %bb60
bb26:
  %t124 = load { i64, [5 x i64] }, ptr %l12
  store { i64, [5 x i64] } %t124, ptr %l69
  %t125 = load { i64, [5 x i64] }, ptr %l69
  %t126 = extractvalue { i64, [5 x i64] } %t125, 0
  %t127 = icmp eq i64 %t126, 2
  store i1 %t127, ptr %l70
  %t128 = load i1, ptr %l70
  br i1 %t128, label %bb28, label %bb29
bb27:
  %t129 = load { i64, [5 x i64] }, ptr %l11
  store { i64, [5 x i64] } %t129, ptr %l93
  %t130 = load { i64, [5 x i64] }, ptr %l93
  %t131 = extractvalue { i64, [5 x i64] } %t130, 0
  %t132 = icmp eq i64 %t131, 3
  store i1 %t132, ptr %l94
  %t133 = load i1, ptr %l94
  br i1 %t133, label %bb44, label %bb45
bb28:
  %t134 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t135 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t134, i32 0, i32 0
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l72
  store ptr %l72, ptr %l73
  %t137 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t138 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t137, i32 0, i32 0
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l74
  store ptr %l74, ptr %l75
  %t140 = load ptr, ptr %l73
  %t141 = load ptr, ptr %l75
  %t142 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %t140, ptr %t141)
  store i1 %t142, ptr %l76
  br label %bb30
bb29:
  store i1 false, ptr %l71
  br label %bb31
bb30:
  %t143 = load i1, ptr %l76
  store i1 %t143, ptr %l71
  br label %bb31
bb31:
  %t144 = load i1, ptr %l71
  br i1 %t144, label %bb32, label %bb33
bb32:
  %t145 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t146 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t145, i32 0, i32 1
  %t147 = load i64, ptr %t146
  store i64 %t147, ptr %l78
  store ptr %l78, ptr %l79
  %t148 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t149 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t148, i32 0, i32 1
  %t150 = load i64, ptr %t149
  store i64 %t150, ptr %l80
  store ptr %l80, ptr %l81
  %t151 = load ptr, ptr %l79
  %t152 = load ptr, ptr %l81
  %t153 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t151, ptr %t152)
  store i1 %t153, ptr %l82
  br label %bb34
bb33:
  store i1 false, ptr %l77
  br label %bb35
bb34:
  %t154 = load i1, ptr %l82
  store i1 %t154, ptr %l77
  br label %bb35
bb35:
  %t155 = load i1, ptr %l77
  br i1 %t155, label %bb36, label %bb37
bb36:
  %t156 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t157 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t156, i32 0, i32 2
  %t158 = load %"compiler/source:Span", ptr %t157
  store %"compiler/source:Span" %t158, ptr %l84
  store ptr %l84, ptr %l85
  %t159 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t160 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t159, i32 0, i32 2
  %t161 = load %"compiler/source:Span", ptr %t160
  store %"compiler/source:Span" %t161, ptr %l86
  store ptr %l86, ptr %l87
  %t162 = load ptr, ptr %l85
  %t163 = load ptr, ptr %l87
  %t164 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t162, ptr %t163)
  store i1 %t164, ptr %l88
  br label %bb38
bb37:
  store i1 false, ptr %l83
  br label %bb39
bb38:
  %t165 = load i1, ptr %l88
  store i1 %t165, ptr %l83
  br label %bb39
bb39:
  %t166 = load i1, ptr %l83
  br i1 %t166, label %bb40, label %bb41
bb40:
  %t167 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t168 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t167, i32 0, i32 3
  %t169 = load { i64, ptr }, ptr %t168
  store { i64, ptr } %t169, ptr %l90
  %t170 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t171 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t170, i32 0, i32 3
  %t172 = load { i64, ptr }, ptr %t171
  store { i64, ptr } %t172, ptr %l91
  %t173 = load { i64, ptr }, ptr %l90
  %t174 = load { i64, ptr }, ptr %l91
  %t175 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t173, { i64, ptr } %t174)
  store i1 %t175, ptr %l92
  br label %bb42
bb41:
  store i1 false, ptr %l89
  br label %bb43
bb42:
  %t176 = load i1, ptr %l92
  store i1 %t176, ptr %l89
  br label %bb43
bb43:
  %t177 = load i1, ptr %l89
  store i1 %t177, ptr %l68
  br label %bb59
bb44:
  %t178 = load { i64, [5 x i64] }, ptr %l12
  store { i64, [5 x i64] } %t178, ptr %l96
  %t179 = load { i64, [5 x i64] }, ptr %l96
  %t180 = extractvalue { i64, [5 x i64] } %t179, 0
  %t181 = icmp eq i64 %t180, 3
  store i1 %t181, ptr %l97
  %t182 = load i1, ptr %l97
  br i1 %t182, label %bb46, label %bb47
bb45:
  store i1 false, ptr %l95
  br label %bb58
bb46:
  %t183 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t184 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t183, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184
  store { i64, ptr } %t185, ptr %l99
  %t186 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t187 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t186, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187
  store { i64, ptr } %t188, ptr %l100
  %t189 = load { i64, ptr }, ptr %l99
  %t190 = load { i64, ptr }, ptr %l100
  %t191 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t189, { i64, ptr } %t190)
  store i1 %t191, ptr %l101
  br label %bb48
bb47:
  store i1 false, ptr %l98
  br label %bb49
bb48:
  %t192 = load i1, ptr %l101
  store i1 %t192, ptr %l98
  br label %bb49
bb49:
  %t193 = load i1, ptr %l98
  br i1 %t193, label %bb50, label %bb51
bb50:
  %t194 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t195 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t194, i32 0, i32 1
  %t196 = load i64, ptr %t195
  store i64 %t196, ptr %l103
  store ptr %l103, ptr %l104
  %t197 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t198 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t197, i32 0, i32 1
  %t199 = load i64, ptr %t198
  store i64 %t199, ptr %l105
  store ptr %l105, ptr %l106
  %t200 = load ptr, ptr %l104
  %t201 = load ptr, ptr %l106
  %t202 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t200, ptr %t201)
  store i1 %t202, ptr %l107
  br label %bb52
bb51:
  store i1 false, ptr %l102
  br label %bb53
bb52:
  %t203 = load i1, ptr %l107
  store i1 %t203, ptr %l102
  br label %bb53
bb53:
  %t204 = load i1, ptr %l102
  br i1 %t204, label %bb54, label %bb55
bb54:
  %t205 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t206 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t205, i32 0, i32 2
  %t207 = load %"compiler/source:Span", ptr %t206
  store %"compiler/source:Span" %t207, ptr %l109
  store ptr %l109, ptr %l110
  %t208 = getelementptr { i64, [5 x i64] }, ptr %l12, i32 0, i32 1
  %t209 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t208, i32 0, i32 2
  %t210 = load %"compiler/source:Span", ptr %t209
  store %"compiler/source:Span" %t210, ptr %l111
  store ptr %l111, ptr %l112
  %t211 = load ptr, ptr %l110
  %t212 = load ptr, ptr %l112
  %t213 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t211, ptr %t212)
  store i1 %t213, ptr %l113
  br label %bb56
bb55:
  store i1 false, ptr %l108
  br label %bb57
bb56:
  %t214 = load i1, ptr %l113
  store i1 %t214, ptr %l108
  br label %bb57
bb57:
  %t215 = load i1, ptr %l108
  store i1 %t215, ptr %l95
  br label %bb58
bb58:
  %t216 = load i1, ptr %l95
  store i1 %t216, ptr %l68
  br label %bb59
bb59:
  %t217 = load i1, ptr %l68
  store i1 %t217, ptr %l57
  br label %bb60
bb60:
  %t218 = load i1, ptr %l57
  store i1 %t218, ptr %l52
  br label %bb61
bb61:
  %t219 = load i1, ptr %l52
  %t220 = xor i1 %t219, true
  store i1 %t220, ptr %l114
  %t221 = load i1, ptr %l114
  br i1 %t221, label %bb62, label %bb63
bb62:
  store { i64, [5 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 0
  store i64 0, ptr %t223
  %t224 = load { i64, [5 x i64] }, ptr %t222
  store { i64, [5 x i64] } %t224, ptr %l116
  %t225 = load { i64, [5 x i64] }, ptr %l116
  store { i64, [5 x i64] } %t225, ptr %l13
  %t226 = load ptr, ptr %lp1
  %t227 = load { i64, [5 x i64] }, ptr %t226
  store { i64, [5 x i64] } %t227, ptr %l117
  %t228 = load { i64, [5 x i64] }, ptr %l117
  %t229 = extractvalue { i64, [5 x i64] } %t228, 0
  %t230 = icmp eq i64 %t229, 0
  store i1 %t230, ptr %l118
  %t231 = load i1, ptr %l118
  br i1 %t231, label %bb64, label %bb65
bb63:
  store i1 false, ptr %l115
  br label %bb108
bb64:
  %t232 = load { i64, [5 x i64] }, ptr %l13
  store { i64, [5 x i64] } %t232, ptr %l120
  %t233 = load { i64, [5 x i64] }, ptr %l120
  %t234 = extractvalue { i64, [5 x i64] } %t233, 0
  %t235 = icmp eq i64 %t234, 0
  store i1 %t235, ptr %l121
  %t236 = load i1, ptr %l121
  store i1 %t236, ptr %l119
  br label %bb107
bb65:
  %t237 = load ptr, ptr %lp1
  %t238 = load { i64, [5 x i64] }, ptr %t237
  store { i64, [5 x i64] } %t238, ptr %l122
  %t239 = load { i64, [5 x i64] }, ptr %l122
  %t240 = extractvalue { i64, [5 x i64] } %t239, 0
  %t241 = icmp eq i64 %t240, 1
  store i1 %t241, ptr %l123
  %t242 = load i1, ptr %l123
  br i1 %t242, label %bb66, label %bb67
bb66:
  %t243 = load { i64, [5 x i64] }, ptr %l13
  store { i64, [5 x i64] } %t243, ptr %l125
  %t244 = load { i64, [5 x i64] }, ptr %l125
  %t245 = extractvalue { i64, [5 x i64] } %t244, 0
  %t246 = icmp eq i64 %t245, 1
  store i1 %t246, ptr %l126
  %t247 = load i1, ptr %l126
  br i1 %t247, label %bb68, label %bb69
bb67:
  %t248 = load ptr, ptr %lp1
  %t249 = load { i64, [5 x i64] }, ptr %t248
  store { i64, [5 x i64] } %t249, ptr %l133
  %t250 = load { i64, [5 x i64] }, ptr %l133
  %t251 = extractvalue { i64, [5 x i64] } %t250, 0
  %t252 = icmp eq i64 %t251, 2
  store i1 %t252, ptr %l134
  %t253 = load i1, ptr %l134
  br i1 %t253, label %bb72, label %bb73
bb68:
  %t254 = load ptr, ptr %lp1
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  %t256 = getelementptr { i64 }, ptr %t255, i32 0, i32 0
  %t257 = load i64, ptr %t256
  store i64 %t257, ptr %l128
  store ptr %l128, ptr %l129
  %t258 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t259 = getelementptr { i64 }, ptr %t258, i32 0, i32 0
  %t260 = load i64, ptr %t259
  store i64 %t260, ptr %l130
  store ptr %l130, ptr %l131
  %t261 = load ptr, ptr %l129
  %t262 = load ptr, ptr %l131
  %t263 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t261, ptr %t262)
  store i1 %t263, ptr %l132
  br label %bb70
bb69:
  store i1 false, ptr %l127
  br label %bb71
bb70:
  %t264 = load i1, ptr %l132
  store i1 %t264, ptr %l127
  br label %bb71
bb71:
  %t265 = load i1, ptr %l127
  store i1 %t265, ptr %l124
  br label %bb106
bb72:
  %t266 = load { i64, [5 x i64] }, ptr %l13
  store { i64, [5 x i64] } %t266, ptr %l136
  %t267 = load { i64, [5 x i64] }, ptr %l136
  %t268 = extractvalue { i64, [5 x i64] } %t267, 0
  %t269 = icmp eq i64 %t268, 2
  store i1 %t269, ptr %l137
  %t270 = load i1, ptr %l137
  br i1 %t270, label %bb74, label %bb75
bb73:
  %t271 = load ptr, ptr %lp1
  %t272 = load { i64, [5 x i64] }, ptr %t271
  store { i64, [5 x i64] } %t272, ptr %l160
  %t273 = load { i64, [5 x i64] }, ptr %l160
  %t274 = extractvalue { i64, [5 x i64] } %t273, 0
  %t275 = icmp eq i64 %t274, 3
  store i1 %t275, ptr %l161
  %t276 = load i1, ptr %l161
  br i1 %t276, label %bb90, label %bb91
bb74:
  %t277 = load ptr, ptr %lp1
  %t278 = getelementptr { i64, [5 x i64] }, ptr %t277, i32 0, i32 1
  %t279 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t278, i32 0, i32 0
  %t280 = load i32, ptr %t279
  store i32 %t280, ptr %l139
  store ptr %l139, ptr %l140
  %t281 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t282 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t281, i32 0, i32 0
  %t283 = load i32, ptr %t282
  store i32 %t283, ptr %l141
  store ptr %l141, ptr %l142
  %t284 = load ptr, ptr %l140
  %t285 = load ptr, ptr %l142
  %t286 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %t284, ptr %t285)
  store i1 %t286, ptr %l143
  br label %bb76
bb75:
  store i1 false, ptr %l138
  br label %bb77
bb76:
  %t287 = load i1, ptr %l143
  store i1 %t287, ptr %l138
  br label %bb77
bb77:
  %t288 = load i1, ptr %l138
  br i1 %t288, label %bb78, label %bb79
bb78:
  %t289 = load ptr, ptr %lp1
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  %t291 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t290, i32 0, i32 1
  %t292 = load i64, ptr %t291
  store i64 %t292, ptr %l145
  store ptr %l145, ptr %l146
  %t293 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t294 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t293, i32 0, i32 1
  %t295 = load i64, ptr %t294
  store i64 %t295, ptr %l147
  store ptr %l147, ptr %l148
  %t296 = load ptr, ptr %l146
  %t297 = load ptr, ptr %l148
  %t298 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t296, ptr %t297)
  store i1 %t298, ptr %l149
  br label %bb80
bb79:
  store i1 false, ptr %l144
  br label %bb81
bb80:
  %t299 = load i1, ptr %l149
  store i1 %t299, ptr %l144
  br label %bb81
bb81:
  %t300 = load i1, ptr %l144
  br i1 %t300, label %bb82, label %bb83
bb82:
  %t301 = load ptr, ptr %lp1
  %t302 = getelementptr { i64, [5 x i64] }, ptr %t301, i32 0, i32 1
  %t303 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t302, i32 0, i32 2
  %t304 = load %"compiler/source:Span", ptr %t303
  store %"compiler/source:Span" %t304, ptr %l151
  store ptr %l151, ptr %l152
  %t305 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t306 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t305, i32 0, i32 2
  %t307 = load %"compiler/source:Span", ptr %t306
  store %"compiler/source:Span" %t307, ptr %l153
  store ptr %l153, ptr %l154
  %t308 = load ptr, ptr %l152
  %t309 = load ptr, ptr %l154
  %t310 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t308, ptr %t309)
  store i1 %t310, ptr %l155
  br label %bb84
bb83:
  store i1 false, ptr %l150
  br label %bb85
bb84:
  %t311 = load i1, ptr %l155
  store i1 %t311, ptr %l150
  br label %bb85
bb85:
  %t312 = load i1, ptr %l150
  br i1 %t312, label %bb86, label %bb87
bb86:
  %t313 = load ptr, ptr %lp1
  %t314 = getelementptr { i64, [5 x i64] }, ptr %t313, i32 0, i32 1
  %t315 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t314, i32 0, i32 3
  %t316 = load { i64, ptr }, ptr %t315
  store { i64, ptr } %t316, ptr %l157
  %t317 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t318 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t317, i32 0, i32 3
  %t319 = load { i64, ptr }, ptr %t318
  store { i64, ptr } %t319, ptr %l158
  %t320 = load { i64, ptr }, ptr %l157
  %t321 = load { i64, ptr }, ptr %l158
  %t322 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t320, { i64, ptr } %t321)
  store i1 %t322, ptr %l159
  br label %bb88
bb87:
  store i1 false, ptr %l156
  br label %bb89
bb88:
  %t323 = load i1, ptr %l159
  store i1 %t323, ptr %l156
  br label %bb89
bb89:
  %t324 = load i1, ptr %l156
  store i1 %t324, ptr %l135
  br label %bb105
bb90:
  %t325 = load { i64, [5 x i64] }, ptr %l13
  store { i64, [5 x i64] } %t325, ptr %l163
  %t326 = load { i64, [5 x i64] }, ptr %l163
  %t327 = extractvalue { i64, [5 x i64] } %t326, 0
  %t328 = icmp eq i64 %t327, 3
  store i1 %t328, ptr %l164
  %t329 = load i1, ptr %l164
  br i1 %t329, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l162
  br label %bb104
bb92:
  %t330 = load ptr, ptr %lp1
  %t331 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 1
  %t332 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t331, i32 0, i32 0
  %t333 = load { i64, ptr }, ptr %t332
  store { i64, ptr } %t333, ptr %l166
  %t334 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t335 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t334, i32 0, i32 0
  %t336 = load { i64, ptr }, ptr %t335
  store { i64, ptr } %t336, ptr %l167
  %t337 = load { i64, ptr }, ptr %l166
  %t338 = load { i64, ptr }, ptr %l167
  %t339 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t337, { i64, ptr } %t338)
  store i1 %t339, ptr %l168
  br label %bb94
bb93:
  store i1 false, ptr %l165
  br label %bb95
bb94:
  %t340 = load i1, ptr %l168
  store i1 %t340, ptr %l165
  br label %bb95
bb95:
  %t341 = load i1, ptr %l165
  br i1 %t341, label %bb96, label %bb97
bb96:
  %t342 = load ptr, ptr %lp1
  %t343 = getelementptr { i64, [5 x i64] }, ptr %t342, i32 0, i32 1
  %t344 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t343, i32 0, i32 1
  %t345 = load i64, ptr %t344
  store i64 %t345, ptr %l170
  store ptr %l170, ptr %l171
  %t346 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t347 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t346, i32 0, i32 1
  %t348 = load i64, ptr %t347
  store i64 %t348, ptr %l172
  store ptr %l172, ptr %l173
  %t349 = load ptr, ptr %l171
  %t350 = load ptr, ptr %l173
  %t351 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t349, ptr %t350)
  store i1 %t351, ptr %l174
  br label %bb98
bb97:
  store i1 false, ptr %l169
  br label %bb99
bb98:
  %t352 = load i1, ptr %l174
  store i1 %t352, ptr %l169
  br label %bb99
bb99:
  %t353 = load i1, ptr %l169
  br i1 %t353, label %bb100, label %bb101
bb100:
  %t354 = load ptr, ptr %lp1
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t354, i32 0, i32 1
  %t356 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t355, i32 0, i32 2
  %t357 = load %"compiler/source:Span", ptr %t356
  store %"compiler/source:Span" %t357, ptr %l176
  store ptr %l176, ptr %l177
  %t358 = getelementptr { i64, [5 x i64] }, ptr %l13, i32 0, i32 1
  %t359 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t358, i32 0, i32 2
  %t360 = load %"compiler/source:Span", ptr %t359
  store %"compiler/source:Span" %t360, ptr %l178
  store ptr %l178, ptr %l179
  %t361 = load ptr, ptr %l177
  %t362 = load ptr, ptr %l179
  %t363 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t361, ptr %t362)
  store i1 %t363, ptr %l180
  br label %bb102
bb101:
  store i1 false, ptr %l175
  br label %bb103
bb102:
  %t364 = load i1, ptr %l180
  store i1 %t364, ptr %l175
  br label %bb103
bb103:
  %t365 = load i1, ptr %l175
  store i1 %t365, ptr %l162
  br label %bb104
bb104:
  %t366 = load i1, ptr %l162
  store i1 %t366, ptr %l135
  br label %bb105
bb105:
  %t367 = load i1, ptr %l135
  store i1 %t367, ptr %l124
  br label %bb106
bb106:
  %t368 = load i1, ptr %l124
  store i1 %t368, ptr %l119
  br label %bb107
bb107:
  %t369 = load i1, ptr %l119
  store i1 %t369, ptr %l115
  br label %bb108
bb108:
  %t370 = load i1, ptr %l115
  br i1 %t370, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s5
  %t371 = load { i64, [5 x i64] }, ptr %l11
  store { i64, [5 x i64] } %t371, ptr %l181
  %t372 = load { i64, [5 x i64] }, ptr %l181
  %t373 = load ptr, ptr %lp1
  store { i64, [5 x i64] } %t372, ptr %t373
  call void @__olang_scope_close(ptr %s5)
  br label %bb111
bb110:
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s4)
  br label %bb117
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb117:
  call void @__olang_scope_close(ptr %s3)
  br label %bb118
bb118:
  store %olang.scope zeroinitializer, ptr %s7
  %t374 = load i64, ptr %l6
  store i64 %t374, ptr %l182
  %t375 = load i64, ptr %l182
  %t376 = add i64 %t375, 1
  store i64 %t376, ptr %l183
  %t377 = load i64, ptr %l183
  store i64 %t377, ptr %l6
  call void @__olang_scope_close(ptr %s7)
  br label %bb9
bb119:
  %t378 = load i64, ptr %l3
  store i64 %t378, ptr %l184
  %t379 = load i64, ptr %l5
  store i64 %t379, ptr %l185
  %t380 = load i64, ptr %l184
  %t381 = load i64, ptr %l185
  %t382 = add i64 %t380, %t381
  store i64 %t382, ptr %l186
  %t383 = load i64, ptr %l186
  store i64 %t383, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb120
bb120:
  br label %bb2
bb121:
  call void @__olang_scope_close(ptr %s1)
  %t384 = load ptr, ptr %lp1
  %t385 = load { i64, [5 x i64] }, ptr %t384
  store { i64, [5 x i64] } %t385, ptr %l187
  call void @__olang_scope_close(ptr %s0)
  %t386 = load { i64, [5 x i64] }, ptr %l187
  store { i64, [5 x i64] } %t386, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { i64, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInt(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca { i64, [5 x i64] }
  %l5 = alloca { i64, [5 x i64] }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, [1 x i64] }
  %l10 = alloca ptr
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, [5 x i64] }
  %l20 = alloca { i64, [5 x i64] }
  %l21 = alloca { i64, [5 x i64] }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, [5 x i64] }
  %l25 = alloca i1
  %l26 = alloca { i64, [5 x i64] }
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, [5 x i64] }
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca { i64, [5 x i64] }
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, [5 x i64] }
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca ptr
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i1
  %l64 = alloca { i64, [5 x i64] }
  %l65 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, [5 x i64] }
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca ptr
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca { i64, i1 }
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca %"compiler/eval:Ptr"
  %l91 = alloca i32
  %l92 = alloca i64
  %l93 = alloca { i64, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, i1 }
  %t5 = alloca { i64, [1 x i64] }, align 8
  %t40 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1
  store i64 %t1, ptr %l6
  %t2 = load i64, ptr %l6
  %t3 = trunc i64 %t2 to i32
  store i32 %t3, ptr %l7
  %t4 = load i32, ptr %l7
  store i32 %t4, ptr %l8
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load i32, ptr %l8
  %t8 = insertvalue { i32 } undef, i32 %t7, 0
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t5
  store { i64, [1 x i64] } %t10, ptr %l9
  %t11 = load { i64, [1 x i64] }, ptr %l9
  store { i64, [1 x i64] } %t11, ptr %l3
  %t12 = load ptr, ptr %l0
  store ptr %t12, ptr %l10
  %t13 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t13, ptr %l11
  %t14 = load ptr, ptr %l10
  %t15 = load { i64, [1 x i64] }, ptr %l11
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t14, { i64, [1 x i64] } %t15)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l12
  %t17 = load ptr, ptr %l12
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t17, i32 0, i32 4
  store ptr %t18, ptr %l13
  %t19 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t19, ptr %l14
  %t20 = icmp sge i64 0, 0
  store i1 %t20, ptr %l15
  %t21 = load i1, ptr %l15
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  store i1 %t22, ptr %l16
  %t23 = load i1, ptr %l16
  br i1 %t23, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 0, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l17
  %t28 = load { i64, ptr }, ptr %l17
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l18
  %t35 = load ptr, ptr %l13
  %t36 = load { i64, [1 x i64] }, ptr %l14
  %t37 = load { i64, ptr }, ptr %l18
  %t38 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t35, { i64, [1 x i64] } %t36, { i64, ptr } %t37)
  store { i64, [5 x i64] } %t38, ptr %l19
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb6:
  %t39 = load { i64, [5 x i64] }, ptr %l19
  store { i64, [5 x i64] } %t39, ptr %l4
  store { i64, [5 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [5 x i64] }, ptr %t40
  store { i64, [5 x i64] } %t42, ptr %l20
  %t43 = load { i64, [5 x i64] }, ptr %l20
  store { i64, [5 x i64] } %t43, ptr %l5
  %t44 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t44, ptr %l21
  %t45 = load { i64, [5 x i64] }, ptr %l21
  %t46 = extractvalue { i64, [5 x i64] } %t45, 0
  %t47 = icmp eq i64 %t46, 0
  store i1 %t47, ptr %l22
  %t48 = load i1, ptr %l22
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t49 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t49, ptr %l24
  %t50 = load { i64, [5 x i64] }, ptr %l24
  %t51 = extractvalue { i64, [5 x i64] } %t50, 0
  %t52 = icmp eq i64 %t51, 0
  store i1 %t52, ptr %l25
  %t53 = load i1, ptr %l25
  store i1 %t53, ptr %l23
  br label %bb50
bb8:
  %t54 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t54, ptr %l26
  %t55 = load { i64, [5 x i64] }, ptr %l26
  %t56 = extractvalue { i64, [5 x i64] } %t55, 0
  %t57 = icmp eq i64 %t56, 1
  store i1 %t57, ptr %l27
  %t58 = load i1, ptr %l27
  br i1 %t58, label %bb9, label %bb10
bb9:
  %t59 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t59, ptr %l29
  %t60 = load { i64, [5 x i64] }, ptr %l29
  %t61 = extractvalue { i64, [5 x i64] } %t60, 0
  %t62 = icmp eq i64 %t61, 1
  store i1 %t62, ptr %l30
  %t63 = load i1, ptr %l30
  br i1 %t63, label %bb11, label %bb12
bb10:
  %t64 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t64, ptr %l37
  %t65 = load { i64, [5 x i64] }, ptr %l37
  %t66 = extractvalue { i64, [5 x i64] } %t65, 0
  %t67 = icmp eq i64 %t66, 2
  store i1 %t67, ptr %l38
  %t68 = load i1, ptr %l38
  br i1 %t68, label %bb15, label %bb16
bb11:
  %t69 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t70 = getelementptr { i64 }, ptr %t69, i32 0, i32 0
  %t71 = load i64, ptr %t70
  store i64 %t71, ptr %l32
  store ptr %l32, ptr %l33
  %t72 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t73 = getelementptr { i64 }, ptr %t72, i32 0, i32 0
  %t74 = load i64, ptr %t73
  store i64 %t74, ptr %l34
  store ptr %l34, ptr %l35
  %t75 = load ptr, ptr %l33
  %t76 = load ptr, ptr %l35
  %t77 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t75, ptr %t76)
  store i1 %t77, ptr %l36
  br label %bb13
bb12:
  store i1 false, ptr %l31
  br label %bb14
bb13:
  %t78 = load i1, ptr %l36
  store i1 %t78, ptr %l31
  br label %bb14
bb14:
  %t79 = load i1, ptr %l31
  store i1 %t79, ptr %l28
  br label %bb49
bb15:
  %t80 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t80, ptr %l40
  %t81 = load { i64, [5 x i64] }, ptr %l40
  %t82 = extractvalue { i64, [5 x i64] } %t81, 0
  %t83 = icmp eq i64 %t82, 2
  store i1 %t83, ptr %l41
  %t84 = load i1, ptr %l41
  br i1 %t84, label %bb17, label %bb18
bb16:
  %t85 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t85, ptr %l64
  %t86 = load { i64, [5 x i64] }, ptr %l64
  %t87 = extractvalue { i64, [5 x i64] } %t86, 0
  %t88 = icmp eq i64 %t87, 3
  store i1 %t88, ptr %l65
  %t89 = load i1, ptr %l65
  br i1 %t89, label %bb33, label %bb34
bb17:
  %t90 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t91 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91
  store i32 %t92, ptr %l43
  store ptr %l43, ptr %l44
  %t93 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t94 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l45
  store ptr %l45, ptr %l46
  %t96 = load ptr, ptr %l44
  %t97 = load ptr, ptr %l46
  %t98 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %t96, ptr %t97)
  store i1 %t98, ptr %l47
  br label %bb19
bb18:
  store i1 false, ptr %l42
  br label %bb20
bb19:
  %t99 = load i1, ptr %l47
  store i1 %t99, ptr %l42
  br label %bb20
bb20:
  %t100 = load i1, ptr %l42
  br i1 %t100, label %bb21, label %bb22
bb21:
  %t101 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t102 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t101, i32 0, i32 1
  %t103 = load i64, ptr %t102
  store i64 %t103, ptr %l49
  store ptr %l49, ptr %l50
  %t104 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t105 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t104, i32 0, i32 1
  %t106 = load i64, ptr %t105
  store i64 %t106, ptr %l51
  store ptr %l51, ptr %l52
  %t107 = load ptr, ptr %l50
  %t108 = load ptr, ptr %l52
  %t109 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t107, ptr %t108)
  store i1 %t109, ptr %l53
  br label %bb23
bb22:
  store i1 false, ptr %l48
  br label %bb24
bb23:
  %t110 = load i1, ptr %l53
  store i1 %t110, ptr %l48
  br label %bb24
bb24:
  %t111 = load i1, ptr %l48
  br i1 %t111, label %bb25, label %bb26
bb25:
  %t112 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t113 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t112, i32 0, i32 2
  %t114 = load %"compiler/source:Span", ptr %t113
  store %"compiler/source:Span" %t114, ptr %l55
  store ptr %l55, ptr %l56
  %t115 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t116 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t115, i32 0, i32 2
  %t117 = load %"compiler/source:Span", ptr %t116
  store %"compiler/source:Span" %t117, ptr %l57
  store ptr %l57, ptr %l58
  %t118 = load ptr, ptr %l56
  %t119 = load ptr, ptr %l58
  %t120 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t118, ptr %t119)
  store i1 %t120, ptr %l59
  br label %bb27
bb26:
  store i1 false, ptr %l54
  br label %bb28
bb27:
  %t121 = load i1, ptr %l59
  store i1 %t121, ptr %l54
  br label %bb28
bb28:
  %t122 = load i1, ptr %l54
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t123 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t124 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t123, i32 0, i32 3
  %t125 = load { i64, ptr }, ptr %t124
  store { i64, ptr } %t125, ptr %l61
  %t126 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t127 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t126, i32 0, i32 3
  %t128 = load { i64, ptr }, ptr %t127
  store { i64, ptr } %t128, ptr %l62
  %t129 = load { i64, ptr }, ptr %l61
  %t130 = load { i64, ptr }, ptr %l62
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t129, { i64, ptr } %t130)
  store i1 %t131, ptr %l63
  br label %bb31
bb30:
  store i1 false, ptr %l60
  br label %bb32
bb31:
  %t132 = load i1, ptr %l63
  store i1 %t132, ptr %l60
  br label %bb32
bb32:
  %t133 = load i1, ptr %l60
  store i1 %t133, ptr %l39
  br label %bb48
bb33:
  %t134 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t134, ptr %l67
  %t135 = load { i64, [5 x i64] }, ptr %l67
  %t136 = extractvalue { i64, [5 x i64] } %t135, 0
  %t137 = icmp eq i64 %t136, 3
  store i1 %t137, ptr %l68
  %t138 = load i1, ptr %l68
  br i1 %t138, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l66
  br label %bb47
bb35:
  %t139 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t140 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t139, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140
  store { i64, ptr } %t141, ptr %l70
  %t142 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t143 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t142, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143
  store { i64, ptr } %t144, ptr %l71
  %t145 = load { i64, ptr }, ptr %l70
  %t146 = load { i64, ptr }, ptr %l71
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t145, { i64, ptr } %t146)
  store i1 %t147, ptr %l72
  br label %bb37
bb36:
  store i1 false, ptr %l69
  br label %bb38
bb37:
  %t148 = load i1, ptr %l72
  store i1 %t148, ptr %l69
  br label %bb38
bb38:
  %t149 = load i1, ptr %l69
  br i1 %t149, label %bb39, label %bb40
bb39:
  %t150 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t151 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t150, i32 0, i32 1
  %t152 = load i64, ptr %t151
  store i64 %t152, ptr %l74
  store ptr %l74, ptr %l75
  %t153 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t154 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t153, i32 0, i32 1
  %t155 = load i64, ptr %t154
  store i64 %t155, ptr %l76
  store ptr %l76, ptr %l77
  %t156 = load ptr, ptr %l75
  %t157 = load ptr, ptr %l77
  %t158 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t156, ptr %t157)
  store i1 %t158, ptr %l78
  br label %bb41
bb40:
  store i1 false, ptr %l73
  br label %bb42
bb41:
  %t159 = load i1, ptr %l78
  store i1 %t159, ptr %l73
  br label %bb42
bb42:
  %t160 = load i1, ptr %l73
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t161 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t162 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t161, i32 0, i32 2
  %t163 = load %"compiler/source:Span", ptr %t162
  store %"compiler/source:Span" %t163, ptr %l80
  store ptr %l80, ptr %l81
  %t164 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t165 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t164, i32 0, i32 2
  %t166 = load %"compiler/source:Span", ptr %t165
  store %"compiler/source:Span" %t166, ptr %l82
  store ptr %l82, ptr %l83
  %t167 = load ptr, ptr %l81
  %t168 = load ptr, ptr %l83
  %t169 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t167, ptr %t168)
  store i1 %t169, ptr %l84
  br label %bb45
bb44:
  store i1 false, ptr %l79
  br label %bb46
bb45:
  %t170 = load i1, ptr %l84
  store i1 %t170, ptr %l79
  br label %bb46
bb46:
  %t171 = load i1, ptr %l79
  store i1 %t171, ptr %l66
  br label %bb47
bb47:
  %t172 = load i1, ptr %l66
  store i1 %t172, ptr %l39
  br label %bb48
bb48:
  %t173 = load i1, ptr %l39
  store i1 %t173, ptr %l28
  br label %bb49
bb49:
  %t174 = load i1, ptr %l28
  store i1 %t174, ptr %l23
  br label %bb50
bb50:
  %t175 = load i1, ptr %l23
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l85
  %t177 = load i1, ptr %l85
  br i1 %t177, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s1
  %t178 = insertvalue { i64, i1 } undef, i64 0, 0
  %t179 = insertvalue { i64, i1 } %t178, i1 false, 1
  store { i64, i1 } %t179, ptr %l86
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t180 = load { i64, i1 }, ptr %l86
  store { i64, i1 } %t180, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t181 = load ptr, ptr %l0
  store ptr %t181, ptr %l87
  %t182 = load ptr, ptr %l87
  %t183 = getelementptr %"compiler/interp:Exec", ptr %t182, i32 0, i32 4
  store ptr %t183, ptr %l88
  %t184 = load ptr, ptr %l0
  store ptr %t184, ptr %l89
  %t185 = load ptr, ptr %l89
  %t186 = getelementptr %"compiler/interp:Exec", ptr %t185, i32 0, i32 4
  %t187 = getelementptr %"compiler/eval:Machine", ptr %t186, i32 0, i32 7
  %t188 = load %"compiler/eval:Ptr", ptr %t187
  store %"compiler/eval:Ptr" %t188, ptr %l90
  %t189 = load i32, ptr %l2
  store i32 %t189, ptr %l91
  %t190 = load ptr, ptr %l88
  %t191 = load %"compiler/eval:Ptr", ptr %l90
  %t192 = load i32, ptr %l91
  %t193 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t190, %"compiler/eval:Ptr" %t191, i32 %t192)
  store i64 %t193, ptr %l92
  br label %bb54
bb54:
  %t194 = load i64, ptr %l92
  %t195 = insertvalue { i64, i1 } undef, i64 %t194, 0
  %t196 = insertvalue { i64, i1 } %t195, i1 true, 1
  store { i64, i1 } %t196, ptr %l93
  call void @__olang_scope_close(ptr %s0)
  %t197 = load { i64, i1 }, ptr %l93
  store { i64, i1 } %t197, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i1 }, ptr %rv
  ret { i64, i1 } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca %"std/prelude/list:List<compiler/mir:FnKey>"
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l5 = alloca %"compiler/mir:Fn"
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/list:List<compiler/mir:FnKey>"
  %l8 = alloca ptr
  %l9 = alloca { i64, [1 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca ptr
  %l16 = alloca { i64, [1 x i64] }
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, [1 x i64] }
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca { i64, [1 x i64] }
  %l32 = alloca i1
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca { i64, [1 x i64] }
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, [1 x i64] }
  %l45 = alloca %"compiler/mir:Fn"
  %l46 = alloca ptr
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca { i64, [1 x i64] }
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %t75 = alloca %"compiler/mir:Fn", align 8
  %t100 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t2)
  br label %bb1
bb1:
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List<compiler/mir:FnKey>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t3)
  store %"std/prelude/list:List<compiler/mir:FnKey>" %t4, ptr %l7
  br label %bb2
bb2:
  %t5 = load %"std/prelude/list:List<compiler/mir:FnKey>", ptr %l7
  store %"std/prelude/list:List<compiler/mir:FnKey>" %t5, ptr %l2
  store ptr %l2, ptr %l8
  %t6 = load { i64, [1 x i64] }, ptr %l1
  store { i64, [1 x i64] } %t6, ptr %l9
  %t7 = load ptr, ptr %l8
  %t8 = load { i64, [1 x i64] }, ptr %l9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %t7, { i64, [1 x i64] } %t8)
  br label %bb3
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l10
  %t9 = load ptr, ptr %l10
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %t9)
  store i64 %t10, ptr %l11
  br label %bb5
bb5:
  %t11 = load i64, ptr %l11
  %t12 = icmp sgt i64 %t11, 0
  store i1 %t12, ptr %l12
  %t13 = load i1, ptr %l12
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l13
  %t15 = load i1, ptr %l13
  br i1 %t15, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb44
bb7:
  br label %bb8
bb8:
  store ptr %l2, ptr %l15
  %t16 = load ptr, ptr %l15
  %t17 = call { i32, { i64, [1 x i64] } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePop_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %t16)
  %t18 = extractvalue { i32, { i64, [1 x i64] } } %t17, 1
  %t19 = extractvalue { i32, { i64, [1 x i64] } } %t17, 0
  store i32 %t19, ptr %l17
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb10, label %ok.21
ok.21:
  store { i64, [1 x i64] } %t18, ptr %l16
  br label %bb9
bb9:
  %t22 = load { i64, [1 x i64] }, ptr %l16
  store { i64, [1 x i64] } %t22, ptr %l14
  br label %bb12
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %bb44
bb12:
  %t23 = load { i64, [1 x i64] }, ptr %l14
  store { i64, [1 x i64] } %t23, ptr %l3
  %t24 = load ptr, ptr %l0
  store ptr %t24, ptr %l18
  %t25 = load ptr, ptr %l18
  %t26 = getelementptr %"compiler/interp:Exec", ptr %t25, i32 0, i32 6
  store ptr %t26, ptr %l19
  %t27 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t27, ptr %l20
  %t28 = load ptr, ptr %l19
  %t29 = load { i64, [1 x i64] }, ptr %l20
  %t30 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t28, { i64, [1 x i64] } %t29)
  store i1 %t30, ptr %l21
  br label %bb13
bb13:
  %t31 = load i1, ptr %l21
  br i1 %t31, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  br label %bb43
bb15:
  br label %bb16
bb16:
  %t32 = load ptr, ptr %l0
  store ptr %t32, ptr %l22
  %t33 = load ptr, ptr %l22
  %t34 = getelementptr %"compiler/interp:Exec", ptr %t33, i32 0, i32 6
  store ptr %t34, ptr %l23
  %t35 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t35, ptr %l24
  %t36 = load ptr, ptr %l23
  %t37 = load { i64, [1 x i64] }, ptr %l24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t36, { i64, [1 x i64] } %t37, i1 true)
  br label %bb17
bb17:
  %t38 = load ptr, ptr %l0
  store ptr %t38, ptr %l25
  %t39 = load ptr, ptr %l25
  %t40 = getelementptr %"compiler/interp:Exec", ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l26
  store ptr %l26, ptr %l27
  store i32 0, ptr %l28
  store ptr %l28, ptr %l29
  %t42 = load ptr, ptr %l27
  %t43 = load ptr, ptr %l29
  %t44 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3aMode(ptr %t42, ptr %t43)
  store i1 %t44, ptr %l30
  br label %bb18
bb18:
  %t45 = load i1, ptr %l30
  br i1 %t45, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t46, ptr %l31
  %t47 = load { i64, [1 x i64] }, ptr %l31
  %t48 = extractvalue { i64, [1 x i64] } %t47, 0
  %t49 = icmp eq i64 %t48, 0
  store i1 %t49, ptr %l32
  %t50 = load i1, ptr %l32
  br i1 %t50, label %bb21, label %bb22
bb20:
  br label %bb35
bb21:
  %t51 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t52 = getelementptr { i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l33
  %t54 = load i32, ptr %l33
  store i32 %t54, ptr %l4
  br label %bb23
bb22:
  br label %bb29
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l34
  %t56 = load ptr, ptr %l34
  %t57 = getelementptr %"compiler/interp:Exec", ptr %t56, i32 0, i32 10
  store ptr %t57, ptr %l35
  %t58 = load i32, ptr %l4
  store i32 %t58, ptr %l36
  %t59 = load i32, ptr %l36
  %t60 = sext i32 %t59 to i64
  store i64 %t60, ptr %l37
  %t61 = load ptr, ptr %l35
  %t62 = load i64, ptr %l37
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t63, ptr %l38
  br label %bb24
bb24:
  %t64 = load i1, ptr %l38
  br i1 %t64, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t65 = load ptr, ptr %l0
  store ptr %t65, ptr %l39
  %t66 = load ptr, ptr %l39
  %t67 = getelementptr %"compiler/interp:Exec", ptr %t66, i32 0, i32 5
  store ptr %t67, ptr %l40
  %t68 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t68, ptr %l41
  %t69 = load ptr, ptr %l40
  %t70 = load { i64, [1 x i64] }, ptr %l41
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t69, { i64, [1 x i64] } %t70)
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  br label %bb43
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t71 = load ptr, ptr %l0
  store ptr %t71, ptr %l42
  %t72 = load ptr, ptr %l42
  %t73 = getelementptr %"compiler/interp:Exec", ptr %t72, i32 0, i32 3
  store ptr %t73, ptr %l43
  %t74 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t74, ptr %l44
  %t76 = load ptr, ptr %l43
  %t77 = load { i64, [1 x i64] }, ptr %l44
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t75, ptr %v0, ptr %v0, ptr %t76, { i64, [1 x i64] } %t77)
  %t78 = load %"compiler/mir:Fn", ptr %t75
  store %"compiler/mir:Fn" %t78, ptr %l45
  br label %bb36
bb36:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l45, i64 184, i1 false)
  %t79 = load ptr, ptr %l0
  store ptr %t79, ptr %l46
  %t80 = load ptr, ptr %l46
  %t81 = getelementptr %"compiler/interp:Exec", ptr %t80, i32 0, i32 3
  %t82 = getelementptr %"compiler/lower:Lowerer", ptr %t81, i32 0, i32 4
  %t83 = load i1, ptr %t82
  store i1 %t83, ptr %l47
  %t84 = load i1, ptr %l47
  br i1 %t84, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t85 = load ptr, ptr %l0
  store ptr %t85, ptr %l48
  %t86 = load ptr, ptr %l48
  %t87 = getelementptr %"compiler/interp:Exec", ptr %t86, i32 0, i32 5
  store ptr %t87, ptr %l49
  %t88 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t88, ptr %l50
  %t89 = load ptr, ptr %l49
  %t90 = load { i64, [1 x i64] }, ptr %l50
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t89, { i64, [1 x i64] } %t90)
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  br label %bb43
bb40:
  %t91 = load ptr, ptr %l0
  store ptr %t91, ptr %l51
  store ptr %l5, ptr %l52
  store ptr %l2, ptr %l53
  %t92 = load ptr, ptr %l51
  %t93 = load ptr, ptr %l52
  %t94 = load ptr, ptr %l53
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ereach(ptr %v0, ptr %v0, ptr %s0, ptr %t92, ptr %t93, ptr %t94)
  br label %bb41
bb41:
  %t95 = load ptr, ptr %l0
  store ptr %t95, ptr %l54
  %t96 = load ptr, ptr %l54
  %t97 = getelementptr %"compiler/interp:Exec", ptr %t96, i32 0, i32 4
  store ptr %t97, ptr %l55
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %l5, i64 184, i1 false)
  %t98 = load ptr, ptr %l55
  %t99 = load %"compiler/mir:Fn", ptr %l56
  store %"compiler/mir:Fn" %t99, ptr %t100
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v0, ptr %t98, ptr %t100)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s1)
  br label %bb43
bb43:
  br label %bb4
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { %"std/prelude/list:List<I64>", i64 }
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca { i64, [5 x i64] }
  %l6 = alloca { i64, [5 x i64] }
  %l7 = alloca ptr
  %l8 = alloca { %"std/prelude/list:List<I64>", i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [1 x i64] }
  %l17 = alloca ptr
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca ptr
  %l20 = alloca { i64, [5 x i64] }
  %l21 = alloca { i64, [5 x i64] }
  %l22 = alloca { i64, [5 x i64] }
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, [5 x i64] }
  %l26 = alloca i1
  %l27 = alloca { i64, [5 x i64] }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, [5 x i64] }
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca { i64, [5 x i64] }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, [5 x i64] }
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca { i64, [5 x i64] }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, [5 x i64] }
  %l69 = alloca i1
  %l70 = alloca i1
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l84 = alloca ptr
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca { i64, [1 x i64] }
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, [5 x i64] }
  %l94 = alloca { i64, [5 x i64] }
  %l95 = alloca i1
  %l96 = alloca i32
  %l97 = alloca { i64, [5 x i64] }
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca { i64, [5 x i64] }
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca { i64, [5 x i64] }
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca { i64, [5 x i64] }
  %l115 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca i32
  %l121 = alloca ptr
  %l122 = alloca { i64, [5 x i64] }
  %l123 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %rv = alloca i32
  %t17 = alloca { i64, [1 x i64] }, align 8
  %t32 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l7
  %t2 = load ptr, ptr %l7
  %t3 = call { %"std/prelude/list:List<I64>", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %s0, ptr %t2)
  store { %"std/prelude/list:List<I64>", i64 } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { %"std/prelude/list:List<I64>", i64 }, ptr %l8
  store { %"std/prelude/list:List<I64>", i64 } %t4, ptr %l2
  %t5 = getelementptr { %"std/prelude/list:List<I64>", i64 }, ptr %l2, i32 0, i32 1
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l9
  %t7 = load i64, ptr %l9
  store i64 %t7, ptr %l3
  %t8 = load i64, ptr %l3
  store i64 %t8, ptr %l10
  %t9 = load i64, ptr %l10
  %t10 = icmp slt i64 %t9, 0
  store i1 %t10, ptr %l11
  %t11 = load i1, ptr %l11
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @compiler_2finterp_2esayErr(ptr %s1, { i64, ptr } { i64 8, ptr @.d28 })
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 1, ptr %l12
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i32, ptr %l12
  store i32 %t12, ptr %rv
  br label %ret
bb5:
  %t13 = load i64, ptr %l3
  store i64 %t13, ptr %l13
  %t14 = load i64, ptr %l13
  %t15 = trunc i64 %t14 to i32
  store i32 %t15, ptr %l14
  %t16 = load i32, ptr %l14
  store i32 %t16, ptr %l15
  store { i64, [1 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t19 = load i32, ptr %l15
  %t20 = insertvalue { i32 } undef, i32 %t19, 0
  %t21 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 1
  store { i32 } %t20, ptr %t21
  %t22 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t22, ptr %l16
  %t23 = load { i64, [1 x i64] }, ptr %l16
  store { i64, [1 x i64] } %t23, ptr %l4
  %t24 = load ptr, ptr %l0
  store ptr %t24, ptr %l17
  %t25 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t25, ptr %l18
  %t26 = load ptr, ptr %l17
  %t27 = load { i64, [1 x i64] }, ptr %l18
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t26, { i64, [1 x i64] } %t27)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0
  store ptr %t28, ptr %l19
  %t29 = load ptr, ptr %l19
  %t30 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %s0, ptr %t29)
  store { i64, [5 x i64] } %t30, ptr %l20
  br label %bb7
bb7:
  %t31 = load { i64, [5 x i64] }, ptr %l20
  store { i64, [5 x i64] } %t31, ptr %l5
  store { i64, [5 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [5 x i64] }, ptr %t32
  store { i64, [5 x i64] } %t34, ptr %l21
  %t35 = load { i64, [5 x i64] }, ptr %l21
  store { i64, [5 x i64] } %t35, ptr %l6
  %t36 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t36, ptr %l22
  %t37 = load { i64, [5 x i64] }, ptr %l22
  %t38 = extractvalue { i64, [5 x i64] } %t37, 0
  %t39 = icmp eq i64 %t38, 0
  store i1 %t39, ptr %l23
  %t40 = load i1, ptr %l23
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t41 = load { i64, [5 x i64] }, ptr %l6
  store { i64, [5 x i64] } %t41, ptr %l25
  %t42 = load { i64, [5 x i64] }, ptr %l25
  %t43 = extractvalue { i64, [5 x i64] } %t42, 0
  %t44 = icmp eq i64 %t43, 0
  store i1 %t44, ptr %l26
  %t45 = load i1, ptr %l26
  store i1 %t45, ptr %l24
  br label %bb51
bb9:
  %t46 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t46, ptr %l27
  %t47 = load { i64, [5 x i64] }, ptr %l27
  %t48 = extractvalue { i64, [5 x i64] } %t47, 0
  %t49 = icmp eq i64 %t48, 1
  store i1 %t49, ptr %l28
  %t50 = load i1, ptr %l28
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t51 = load { i64, [5 x i64] }, ptr %l6
  store { i64, [5 x i64] } %t51, ptr %l30
  %t52 = load { i64, [5 x i64] }, ptr %l30
  %t53 = extractvalue { i64, [5 x i64] } %t52, 0
  %t54 = icmp eq i64 %t53, 1
  store i1 %t54, ptr %l31
  %t55 = load i1, ptr %l31
  br i1 %t55, label %bb12, label %bb13
bb11:
  %t56 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t56, ptr %l38
  %t57 = load { i64, [5 x i64] }, ptr %l38
  %t58 = extractvalue { i64, [5 x i64] } %t57, 0
  %t59 = icmp eq i64 %t58, 2
  store i1 %t59, ptr %l39
  %t60 = load i1, ptr %l39
  br i1 %t60, label %bb16, label %bb17
bb12:
  %t61 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t62 = getelementptr { i64 }, ptr %t61, i32 0, i32 0
  %t63 = load i64, ptr %t62
  store i64 %t63, ptr %l33
  store ptr %l33, ptr %l34
  %t64 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t65 = getelementptr { i64 }, ptr %t64, i32 0, i32 0
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l35
  store ptr %l35, ptr %l36
  %t67 = load ptr, ptr %l34
  %t68 = load ptr, ptr %l36
  %t69 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t67, ptr %t68)
  store i1 %t69, ptr %l37
  br label %bb14
bb13:
  store i1 false, ptr %l32
  br label %bb15
bb14:
  %t70 = load i1, ptr %l37
  store i1 %t70, ptr %l32
  br label %bb15
bb15:
  %t71 = load i1, ptr %l32
  store i1 %t71, ptr %l29
  br label %bb50
bb16:
  %t72 = load { i64, [5 x i64] }, ptr %l6
  store { i64, [5 x i64] } %t72, ptr %l41
  %t73 = load { i64, [5 x i64] }, ptr %l41
  %t74 = extractvalue { i64, [5 x i64] } %t73, 0
  %t75 = icmp eq i64 %t74, 2
  store i1 %t75, ptr %l42
  %t76 = load i1, ptr %l42
  br i1 %t76, label %bb18, label %bb19
bb17:
  %t77 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t77, ptr %l65
  %t78 = load { i64, [5 x i64] }, ptr %l65
  %t79 = extractvalue { i64, [5 x i64] } %t78, 0
  %t80 = icmp eq i64 %t79, 3
  store i1 %t80, ptr %l66
  %t81 = load i1, ptr %l66
  br i1 %t81, label %bb34, label %bb35
bb18:
  %t82 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t83 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l44
  store ptr %l44, ptr %l45
  %t85 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t86 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t85, i32 0, i32 0
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l46
  store ptr %l46, ptr %l47
  %t88 = load ptr, ptr %l45
  %t89 = load ptr, ptr %l47
  %t90 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %t88, ptr %t89)
  store i1 %t90, ptr %l48
  br label %bb20
bb19:
  store i1 false, ptr %l43
  br label %bb21
bb20:
  %t91 = load i1, ptr %l48
  store i1 %t91, ptr %l43
  br label %bb21
bb21:
  %t92 = load i1, ptr %l43
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t94 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t93, i32 0, i32 1
  %t95 = load i64, ptr %t94
  store i64 %t95, ptr %l50
  store ptr %l50, ptr %l51
  %t96 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t97 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t96, i32 0, i32 1
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l52
  store ptr %l52, ptr %l53
  %t99 = load ptr, ptr %l51
  %t100 = load ptr, ptr %l53
  %t101 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t99, ptr %t100)
  store i1 %t101, ptr %l54
  br label %bb24
bb23:
  store i1 false, ptr %l49
  br label %bb25
bb24:
  %t102 = load i1, ptr %l54
  store i1 %t102, ptr %l49
  br label %bb25
bb25:
  %t103 = load i1, ptr %l49
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t104 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t105 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t104, i32 0, i32 2
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l56
  store ptr %l56, ptr %l57
  %t107 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t108 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t107, i32 0, i32 2
  %t109 = load %"compiler/source:Span", ptr %t108
  store %"compiler/source:Span" %t109, ptr %l58
  store ptr %l58, ptr %l59
  %t110 = load ptr, ptr %l57
  %t111 = load ptr, ptr %l59
  %t112 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t110, ptr %t111)
  store i1 %t112, ptr %l60
  br label %bb28
bb27:
  store i1 false, ptr %l55
  br label %bb29
bb28:
  %t113 = load i1, ptr %l60
  store i1 %t113, ptr %l55
  br label %bb29
bb29:
  %t114 = load i1, ptr %l55
  br i1 %t114, label %bb30, label %bb31
bb30:
  %t115 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t116 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t115, i32 0, i32 3
  %t117 = load { i64, ptr }, ptr %t116
  store { i64, ptr } %t117, ptr %l62
  %t118 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t119 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t118, i32 0, i32 3
  %t120 = load { i64, ptr }, ptr %t119
  store { i64, ptr } %t120, ptr %l63
  %t121 = load { i64, ptr }, ptr %l62
  %t122 = load { i64, ptr }, ptr %l63
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t121, { i64, ptr } %t122)
  store i1 %t123, ptr %l64
  br label %bb32
bb31:
  store i1 false, ptr %l61
  br label %bb33
bb32:
  %t124 = load i1, ptr %l64
  store i1 %t124, ptr %l61
  br label %bb33
bb33:
  %t125 = load i1, ptr %l61
  store i1 %t125, ptr %l40
  br label %bb49
bb34:
  %t126 = load { i64, [5 x i64] }, ptr %l6
  store { i64, [5 x i64] } %t126, ptr %l68
  %t127 = load { i64, [5 x i64] }, ptr %l68
  %t128 = extractvalue { i64, [5 x i64] } %t127, 0
  %t129 = icmp eq i64 %t128, 3
  store i1 %t129, ptr %l69
  %t130 = load i1, ptr %l69
  br i1 %t130, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l67
  br label %bb48
bb36:
  %t131 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t132 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t131, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132
  store { i64, ptr } %t133, ptr %l71
  %t134 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t135 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t134, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135
  store { i64, ptr } %t136, ptr %l72
  %t137 = load { i64, ptr }, ptr %l71
  %t138 = load { i64, ptr }, ptr %l72
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t137, { i64, ptr } %t138)
  store i1 %t139, ptr %l73
  br label %bb38
bb37:
  store i1 false, ptr %l70
  br label %bb39
bb38:
  %t140 = load i1, ptr %l73
  store i1 %t140, ptr %l70
  br label %bb39
bb39:
  %t141 = load i1, ptr %l70
  br i1 %t141, label %bb40, label %bb41
bb40:
  %t142 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t143 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t142, i32 0, i32 1
  %t144 = load i64, ptr %t143
  store i64 %t144, ptr %l75
  store ptr %l75, ptr %l76
  %t145 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t146 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t145, i32 0, i32 1
  %t147 = load i64, ptr %t146
  store i64 %t147, ptr %l77
  store ptr %l77, ptr %l78
  %t148 = load ptr, ptr %l76
  %t149 = load ptr, ptr %l78
  %t150 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t148, ptr %t149)
  store i1 %t150, ptr %l79
  br label %bb42
bb41:
  store i1 false, ptr %l74
  br label %bb43
bb42:
  %t151 = load i1, ptr %l79
  store i1 %t151, ptr %l74
  br label %bb43
bb43:
  %t152 = load i1, ptr %l74
  br i1 %t152, label %bb44, label %bb45
bb44:
  %t153 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t154 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t153, i32 0, i32 2
  %t155 = load %"compiler/source:Span", ptr %t154
  store %"compiler/source:Span" %t155, ptr %l81
  store ptr %l81, ptr %l82
  %t156 = getelementptr { i64, [5 x i64] }, ptr %l6, i32 0, i32 1
  %t157 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t156, i32 0, i32 2
  %t158 = load %"compiler/source:Span", ptr %t157
  store %"compiler/source:Span" %t158, ptr %l83
  store ptr %l83, ptr %l84
  %t159 = load ptr, ptr %l82
  %t160 = load ptr, ptr %l84
  %t161 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t159, ptr %t160)
  store i1 %t161, ptr %l85
  br label %bb46
bb45:
  store i1 false, ptr %l80
  br label %bb47
bb46:
  %t162 = load i1, ptr %l85
  store i1 %t162, ptr %l80
  br label %bb47
bb47:
  %t163 = load i1, ptr %l80
  store i1 %t163, ptr %l67
  br label %bb48
bb48:
  %t164 = load i1, ptr %l67
  store i1 %t164, ptr %l40
  br label %bb49
bb49:
  %t165 = load i1, ptr %l40
  store i1 %t165, ptr %l29
  br label %bb50
bb50:
  %t166 = load i1, ptr %l29
  store i1 %t166, ptr %l24
  br label %bb51
bb51:
  %t167 = load i1, ptr %l24
  br i1 %t167, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s2
  %t168 = load ptr, ptr %l0
  store ptr %t168, ptr %l86
  %t169 = load ptr, ptr %l86
  %t170 = getelementptr %"compiler/interp:Exec", ptr %t169, i32 0, i32 4
  store ptr %t170, ptr %l87
  %t171 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t171, ptr %l88
  %t172 = icmp sge i64 0, 0
  store i1 %t172, ptr %l89
  %t173 = load i1, ptr %l89
  br i1 %t173, label %bb54, label %bb55
bb53:
  br label %bb59
bb54:
  %t174 = icmp sle i64 0, 1152921504606846975
  store i1 %t174, ptr %l90
  %t175 = load i1, ptr %l90
  br i1 %t175, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb56:
  %t176 = mul i64 0, 8
  %t177 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 0, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  store { i64, ptr } %t179, ptr %l91
  %t180 = load { i64, ptr }, ptr %l91
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  %t183 = mul i64 %t181, 8
  %t184 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  store { i64, ptr } %t186, ptr %l92
  %t187 = load ptr, ptr %l87
  %t188 = load { i64, [1 x i64] }, ptr %l88
  %t189 = load { i64, ptr }, ptr %l92
  %t190 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %s0, ptr %t187, { i64, [1 x i64] } %t188, { i64, ptr } %t189)
  store { i64, [5 x i64] } %t190, ptr %l93
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb58:
  %t191 = load { i64, [5 x i64] }, ptr %l93
  store { i64, [5 x i64] } %t191, ptr %l5
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb59:
  %t192 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t192, ptr %l94
  %t193 = load { i64, [5 x i64] }, ptr %l94
  %t194 = extractvalue { i64, [5 x i64] } %t193, 0
  %t195 = icmp eq i64 %t194, 0
  store i1 %t195, ptr %l95
  %t196 = load i1, ptr %l95
  br i1 %t196, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 0, ptr %l96
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t197 = load i32, ptr %l96
  store i32 %t197, ptr %rv
  br label %ret
bb63:
  %t198 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t198, ptr %l97
  %t199 = load { i64, [5 x i64] }, ptr %l97
  %t200 = extractvalue { i64, [5 x i64] } %t199, 0
  %t201 = icmp eq i64 %t200, 1
  store i1 %t201, ptr %l98
  %t202 = load i1, ptr %l98
  br i1 %t202, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb71
bb66:
  store %olang.scope zeroinitializer, ptr %s4
  %t203 = load ptr, ptr %l0
  store ptr %t203, ptr %l99
  %t204 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t204, ptr %l100
  %t205 = load i64, ptr %l3
  store i64 %t205, ptr %l101
  %t206 = load ptr, ptr %l1
  store ptr %t206, ptr %l102
  %t207 = load ptr, ptr %l99
  %t208 = load { i64, [5 x i64] }, ptr %l100
  %t209 = load i64, ptr %l101
  %t210 = load ptr, ptr %l102
  %t211 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s4, ptr %t207, { i64, [5 x i64] } %t208, i64 %t209, ptr %t210)
  store { i64, ptr } %t211, ptr %l103
  br label %bb67
bb67:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t212 = load { i64, ptr }, ptr %l103
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  call void @__olang_sb_put(ptr %s5, ptr %t213, i64 %t214)
  %t215 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t215, i64 %t216)
  %t217 = load ptr, ptr %s5
  %t218 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t219 = load i64, ptr %t218
  %t220 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t217, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  store { i64, ptr } %t222, ptr %l104
  call void @__olang_sb_done(ptr %s5)
  %t223 = load { i64, ptr }, ptr %l104
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l105
  %t230 = load { i64, ptr }, ptr %l105
  call void @compiler_2finterp_2esayErr(ptr %s4, { i64, ptr } %t230)
  br label %bb68
bb68:
  %t231 = load ptr, ptr %l0
  store ptr %t231, ptr %l106
  %t232 = load ptr, ptr %l1
  store ptr %t232, ptr %l107
  %t233 = load ptr, ptr %l106
  %t234 = load ptr, ptr %l107
  %t235 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %s4, ptr %t233, ptr %t234)
  store { i64, ptr } %t235, ptr %l108
  br label %bb69
bb69:
  %t236 = load { i64, ptr }, ptr %l108
  %t237 = extractvalue { i64, ptr } %t236, 0
  %t238 = extractvalue { i64, ptr } %t236, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l109
  %t243 = load { i64, ptr }, ptr %l109
  call void @compiler_2finterp_2esayErr(ptr %s4, { i64, ptr } %t243)
  br label %bb70
bb70:
  store i32 1, ptr %l110
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t244 = load i32, ptr %l110
  store i32 %t244, ptr %rv
  br label %ret
bb71:
  %t245 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t245, ptr %l111
  %t246 = load { i64, [5 x i64] }, ptr %l111
  %t247 = extractvalue { i64, [5 x i64] } %t246, 0
  %t248 = icmp eq i64 %t247, 3
  store i1 %t248, ptr %l112
  %t249 = load i1, ptr %l112
  br i1 %t249, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb77
bb74:
  store %olang.scope zeroinitializer, ptr %s6
  %t250 = load ptr, ptr %l0
  store ptr %t250, ptr %l113
  %t251 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t251, ptr %l114
  %t252 = load i64, ptr %l3
  store i64 %t252, ptr %l115
  %t253 = load ptr, ptr %l1
  store ptr %t253, ptr %l116
  %t254 = load ptr, ptr %l113
  %t255 = load { i64, [5 x i64] }, ptr %l114
  %t256 = load i64, ptr %l115
  %t257 = load ptr, ptr %l116
  %t258 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s6, ptr %t254, { i64, [5 x i64] } %t255, i64 %t256, ptr %t257)
  store { i64, ptr } %t258, ptr %l117
  br label %bb75
bb75:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t259 = extractvalue { i64, ptr } { i64 17, ptr @.d31 }, 1
  %t260 = extractvalue { i64, ptr } { i64 17, ptr @.d31 }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t259, i64 %t260)
  %t261 = load { i64, ptr }, ptr %l117
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  call void @__olang_sb_put(ptr %s7, ptr %t262, i64 %t263)
  %t264 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t265 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t264, i64 %t265)
  %t266 = load ptr, ptr %s7
  %t267 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t268 = load i64, ptr %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t268)
  call void @llvm.memcpy.p0.p0.i64(ptr %t269, ptr %t266, i64 %t268, i1 false)
  %t270 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l118
  call void @__olang_sb_done(ptr %s7)
  %t272 = load { i64, ptr }, ptr %l118
  %t273 = extractvalue { i64, ptr } %t272, 0
  %t274 = extractvalue { i64, ptr } %t272, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l119
  %t279 = load { i64, ptr }, ptr %l119
  call void @compiler_2finterp_2esayErr(ptr %s6, { i64, ptr } %t279)
  br label %bb76
bb76:
  store i32 1, ptr %l120
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t280 = load i32, ptr %l120
  store i32 %t280, ptr %rv
  br label %ret
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb83
bb80:
  store %olang.scope zeroinitializer, ptr %s8
  %t281 = load ptr, ptr %l0
  store ptr %t281, ptr %l121
  %t282 = load { i64, [5 x i64] }, ptr %l5
  store { i64, [5 x i64] } %t282, ptr %l122
  %t283 = load i64, ptr %l3
  store i64 %t283, ptr %l123
  %t284 = load ptr, ptr %l1
  store ptr %t284, ptr %l124
  %t285 = load ptr, ptr %l121
  %t286 = load { i64, [5 x i64] }, ptr %l122
  %t287 = load i64, ptr %l123
  %t288 = load ptr, ptr %l124
  %t289 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s8, ptr %t285, { i64, [5 x i64] } %t286, i64 %t287, ptr %t288)
  store { i64, ptr } %t289, ptr %l125
  br label %bb81
bb81:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t290 = load { i64, ptr }, ptr %l125
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  call void @__olang_sb_put(ptr %s9, ptr %t291, i64 %t292)
  %t293 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 1
  %t294 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t293, i64 %t294)
  %t295 = load ptr, ptr %s9
  %t296 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t297 = load i64, ptr %t296
  %t298 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t297)
  call void @llvm.memcpy.p0.p0.i64(ptr %t298, ptr %t295, i64 %t297, i1 false)
  %t299 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  store { i64, ptr } %t300, ptr %l126
  call void @__olang_sb_done(ptr %s9)
  %t301 = load { i64, ptr }, ptr %l126
  %t302 = extractvalue { i64, ptr } %t301, 0
  %t303 = extractvalue { i64, ptr } %t301, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  store { i64, ptr } %t307, ptr %l127
  %t308 = load { i64, ptr }, ptr %l127
  call void @compiler_2finterp_2esayErr(ptr %s8, { i64, ptr } %t308)
  br label %bb82
bb82:
  store i32 134, ptr %l128
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load i32, ptr %l128
  store i32 %t309, ptr %rv
  br label %ret
bb83:
  call void @__olang_check_failed(ptr @.c34)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [5 x i64] } %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [5 x i64] }
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, [5 x i64] }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, [5 x i64] }
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca { i64, [5 x i64] }
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, [5 x i64] }
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, [5 x i64] }
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [5 x i64] } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [5 x i64] }, ptr %l1
  store { i64, [5 x i64] } %t1, ptr %l6
  %t2 = load { i64, [5 x i64] }, ptr %l6
  %t3 = extractvalue { i64, [5 x i64] } %t2, 0
  %t4 = icmp eq i64 %t3, 1
  store i1 %t4, ptr %l7
  %t5 = load i1, ptr %l7
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l8
  %t9 = load i64, ptr %l8
  store i64 %t9, ptr %l4
  br label %bb3
bb2:
  br label %bb6
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l9
  %t11 = load i64, ptr %l4
  store i64 %t11, ptr %l10
  %t12 = load ptr, ptr %l0
  store ptr %t12, ptr %l11
  %t13 = load ptr, ptr %l11
  %t14 = getelementptr %"compiler/interp:Exec", ptr %t13, i32 0, i32 1
  store ptr %t14, ptr %l12
  %t15 = load i64, ptr %l2
  store i64 %t15, ptr %l13
  %t16 = load ptr, ptr %l12
  %t17 = load i64, ptr %l13
  %t18 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l14
  store ptr %t19, ptr %l15
  %t20 = load ptr, ptr %l15
  %t21 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 2
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l16
  %t23 = load ptr, ptr %l9
  %t24 = load i64, ptr %l10
  %t25 = load i32, ptr %l16
  %t26 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eerrorName(ptr %v0, ptr %s1, ptr %t23, i64 %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l17
  br label %bb5
bb5:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t27 = extractvalue { i64, ptr } { i64 17, ptr @.d35 }, 1
  %t28 = extractvalue { i64, ptr } { i64 17, ptr @.d35 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t27, i64 %t28)
  %t29 = load { i64, ptr }, ptr %l17
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  call void @__olang_sb_put(ptr %s2, ptr %t30, i64 %t31)
  %t32 = load ptr, ptr %s2
  %t33 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t34 = load i64, ptr %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t32, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l18
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb6:
  %t39 = load { i64, [5 x i64] }, ptr %l1
  store { i64, [5 x i64] } %t39, ptr %l19
  %t40 = load { i64, [5 x i64] }, ptr %l19
  %t41 = extractvalue { i64, [5 x i64] } %t40, 0
  %t42 = icmp eq i64 %t41, 3
  store i1 %t42, ptr %l20
  %t43 = load i1, ptr %l20
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t44 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l21
  %t47 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t47, ptr %l5
  br label %bb9
bb8:
  br label %bb20
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t48, ptr %l22
  %t49 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWaits
  store { i64, ptr } %t49, ptr %l23
  %t50 = load ptr, ptr @__olang_prog_scope
  %t51 = load { i64, ptr }, ptr %l22
  %t52 = load { i64, ptr }, ptr %l23
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %t50, { i64, ptr } %t51, { i64, ptr } %t52)
  store i1 %t53, ptr %l24
  br label %bb10
bb10:
  %t54 = load i1, ptr %l24
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l26
  %t56 = load ptr, ptr %l26
  %t57 = getelementptr %"compiler/interp:Exec", ptr %t56, i32 0, i32 4
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t57, i32 0, i32 58
  %t59 = load i64, ptr %t58
  store i64 %t59, ptr %l27
  %t60 = load i64, ptr %l27
  %t61 = icmp sge i64 %t60, 0
  store i1 %t61, ptr %l28
  %t62 = load i1, ptr %l28
  store i1 %t62, ptr %l25
  br label %bb13
bb12:
  store i1 false, ptr %l25
  br label %bb13
bb13:
  %t63 = load i1, ptr %l25
  br i1 %t63, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load { i64, [5 x i64] }, ptr %l1
  store { i64, [5 x i64] } %t64, ptr %l29
  %t65 = load ptr, ptr %l3
  store ptr %t65, ptr %l30
  %t66 = load { i64, [5 x i64] }, ptr %l29
  %t67 = load ptr, ptr %l30
  %t68 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %s4, { i64, [5 x i64] } %t66, ptr %t67)
  store { i64, ptr } %t68, ptr %l31
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t69 = load ptr, ptr %l3
  store ptr %t69, ptr %l32
  %t70 = load ptr, ptr %l0
  store ptr %t70, ptr %l33
  %t71 = load ptr, ptr %l33
  %t72 = getelementptr %"compiler/interp:Exec", ptr %t71, i32 0, i32 4
  %t73 = getelementptr %"compiler/eval:Machine", ptr %t72, i32 0, i32 58
  %t74 = load i64, ptr %t73
  store i64 %t74, ptr %l34
  %t75 = load ptr, ptr %l0
  store ptr %t75, ptr %l35
  %t76 = load ptr, ptr %l35
  %t77 = getelementptr %"compiler/interp:Exec", ptr %t76, i32 0, i32 4
  %t78 = getelementptr %"compiler/eval:Machine", ptr %t77, i32 0, i32 59
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l36
  %t80 = load ptr, ptr %l32
  %t81 = load i64, ptr %l34
  %t82 = load %"compiler/source:Span", ptr %l36
  %t83 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v2, ptr %s4, ptr %t80, i64 %t81, %"compiler/source:Span" %t82)
  store { i64, ptr } %t83, ptr %l37
  br label %bb17
bb17:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t84 = load { i64, ptr }, ptr %l31
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  call void @__olang_sb_put(ptr %s5, ptr %t85, i64 %t86)
  %t87 = extractvalue { i64, ptr } { i64 31, ptr @.d36 }, 1
  %t88 = extractvalue { i64, ptr } { i64 31, ptr @.d36 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t87, i64 %t88)
  %t89 = load { i64, ptr }, ptr %l37
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  call void @__olang_sb_put(ptr %s5, ptr %t90, i64 %t91)
  %t92 = load ptr, ptr %s5
  %t93 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t94 = load i64, ptr %t93
  %t95 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t92, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l38
  call void @__olang_sb_done(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load { i64, ptr }, ptr %l38
  store { i64, ptr } %t98, ptr %rv
  br label %ret
bb18:
  %t99 = load { i64, [5 x i64] }, ptr %l1
  store { i64, [5 x i64] } %t99, ptr %l39
  %t100 = load ptr, ptr %l3
  store ptr %t100, ptr %l40
  %t101 = load { i64, [5 x i64] }, ptr %l39
  %t102 = load ptr, ptr %l40
  %t103 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %v3, { i64, [5 x i64] } %t101, ptr %t102)
  store { i64, ptr } %t103, ptr %l41
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t104 = load { i64, ptr }, ptr %l41
  store { i64, ptr } %t104, ptr %rv
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb25
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t105 = load { i64, [5 x i64] }, ptr %l1
  store { i64, [5 x i64] } %t105, ptr %l42
  %t106 = load ptr, ptr %l3
  store ptr %t106, ptr %l43
  %t107 = load { i64, [5 x i64] }, ptr %l42
  %t108 = load ptr, ptr %l43
  %t109 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %v3, { i64, [5 x i64] } %t107, ptr %t108)
  store { i64, ptr } %t109, ptr %l44
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t110 = load { i64, ptr }, ptr %l44
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @.c37)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca { i64, [5 x i64] }
  %l4 = alloca { i64, [5 x i64] }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { { i64, ptr }, i1 }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [1 x i64] }
  %l17 = alloca ptr
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, [1 x i64] }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, [5 x i64] }
  %l27 = alloca { i64, [5 x i64] }
  %l28 = alloca { i64, [5 x i64] }
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, [5 x i64] }
  %l32 = alloca i1
  %l33 = alloca { i64, [5 x i64] }
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca { i64, [5 x i64] }
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca { i64, [5 x i64] }
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, [5 x i64] }
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca ptr
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca { i64, [5 x i64] }
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca { i64, [5 x i64] }
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca { { i64, ptr }, i1 }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca %"compiler/eval:Ptr"
  %l103 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca { i64, ptr }
  %l106 = alloca { { i64, ptr }, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i1 }
  %t31 = alloca { i64, [1 x i64] }, align 8
  %t66 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1
  store i64 %t1, ptr %l5
  %t2 = load i64, ptr %l5
  %t3 = icmp slt i64 %t2, 0
  store i1 %t3, ptr %l6
  %t4 = load i1, ptr %l6
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d38 }, ptr %l7
  %t5 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  %t7 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t6, 0
  %t8 = insertvalue { { i64, ptr }, i1 } %t7, i1 false, 1
  store { { i64, ptr }, i1 } %t8, ptr %l9
  %t9 = getelementptr { { i64, ptr }, i1 }, ptr %l9, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9
  store { i64, ptr } %t10, ptr %l10
  %t11 = load { i64, ptr }, ptr %l10
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l11
  %t13 = load i64, ptr %l11
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l12
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t21 = load ptr, ptr %t20
  %t22 = load i64, ptr %l11
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l12
  %t25 = getelementptr { { i64, ptr }, i1 }, ptr %l9, i32 0, i32 0
  store { i64, ptr } %t24, ptr %t25
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { { i64, ptr }, i1 }, ptr %l9
  store { { i64, ptr }, i1 } %t26, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t27 = load i64, ptr %l1
  store i64 %t27, ptr %l13
  %t28 = load i64, ptr %l13
  %t29 = trunc i64 %t28 to i32
  store i32 %t29, ptr %l14
  %t30 = load i32, ptr %l14
  store i32 %t30, ptr %l15
  store { i64, [1 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [1 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load i32, ptr %l15
  %t34 = insertvalue { i32 } undef, i32 %t33, 0
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t31, i32 0, i32 1
  store { i32 } %t34, ptr %t35
  %t36 = load { i64, [1 x i64] }, ptr %t31
  store { i64, [1 x i64] } %t36, ptr %l16
  %t37 = load { i64, [1 x i64] }, ptr %l16
  store { i64, [1 x i64] } %t37, ptr %l2
  %t38 = load ptr, ptr %l0
  store ptr %t38, ptr %l17
  %t39 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t39, ptr %l18
  %t40 = load ptr, ptr %l17
  %t41 = load { i64, [1 x i64] }, ptr %l18
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t40, { i64, [1 x i64] } %t41)
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l0
  store ptr %t42, ptr %l19
  %t43 = load ptr, ptr %l19
  %t44 = getelementptr %"compiler/interp:Exec", ptr %t43, i32 0, i32 4
  store ptr %t44, ptr %l20
  %t45 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t45, ptr %l21
  %t46 = icmp sge i64 0, 0
  store i1 %t46, ptr %l22
  %t47 = load i1, ptr %l22
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t48 = icmp sle i64 0, 1152921504606846975
  store i1 %t48, ptr %l23
  %t49 = load i1, ptr %l23
  br i1 %t49, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb7:
  %t50 = mul i64 0, 8
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 0, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l24
  %t54 = load { i64, ptr }, ptr %l24
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 8
  %t58 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l25
  %t61 = load ptr, ptr %l20
  %t62 = load { i64, [1 x i64] }, ptr %l21
  %t63 = load { i64, ptr }, ptr %l25
  %t64 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t61, { i64, [1 x i64] } %t62, { i64, ptr } %t63)
  store { i64, [5 x i64] } %t64, ptr %l26
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb9:
  %t65 = load { i64, [5 x i64] }, ptr %l26
  store { i64, [5 x i64] } %t65, ptr %l3
  store { i64, [5 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [5 x i64] }, ptr %t66
  store { i64, [5 x i64] } %t68, ptr %l27
  %t69 = load { i64, [5 x i64] }, ptr %l27
  store { i64, [5 x i64] } %t69, ptr %l4
  %t70 = load { i64, [5 x i64] }, ptr %l3
  store { i64, [5 x i64] } %t70, ptr %l28
  %t71 = load { i64, [5 x i64] }, ptr %l28
  %t72 = extractvalue { i64, [5 x i64] } %t71, 0
  %t73 = icmp eq i64 %t72, 0
  store i1 %t73, ptr %l29
  %t74 = load i1, ptr %l29
  br i1 %t74, label %bb10, label %bb11
bb10:
  %t75 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t75, ptr %l31
  %t76 = load { i64, [5 x i64] }, ptr %l31
  %t77 = extractvalue { i64, [5 x i64] } %t76, 0
  %t78 = icmp eq i64 %t77, 0
  store i1 %t78, ptr %l32
  %t79 = load i1, ptr %l32
  store i1 %t79, ptr %l30
  br label %bb53
bb11:
  %t80 = load { i64, [5 x i64] }, ptr %l3
  store { i64, [5 x i64] } %t80, ptr %l33
  %t81 = load { i64, [5 x i64] }, ptr %l33
  %t82 = extractvalue { i64, [5 x i64] } %t81, 0
  %t83 = icmp eq i64 %t82, 1
  store i1 %t83, ptr %l34
  %t84 = load i1, ptr %l34
  br i1 %t84, label %bb12, label %bb13
bb12:
  %t85 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t85, ptr %l36
  %t86 = load { i64, [5 x i64] }, ptr %l36
  %t87 = extractvalue { i64, [5 x i64] } %t86, 0
  %t88 = icmp eq i64 %t87, 1
  store i1 %t88, ptr %l37
  %t89 = load i1, ptr %l37
  br i1 %t89, label %bb14, label %bb15
bb13:
  %t90 = load { i64, [5 x i64] }, ptr %l3
  store { i64, [5 x i64] } %t90, ptr %l44
  %t91 = load { i64, [5 x i64] }, ptr %l44
  %t92 = extractvalue { i64, [5 x i64] } %t91, 0
  %t93 = icmp eq i64 %t92, 2
  store i1 %t93, ptr %l45
  %t94 = load i1, ptr %l45
  br i1 %t94, label %bb18, label %bb19
bb14:
  %t95 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t96 = getelementptr { i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l39
  store ptr %l39, ptr %l40
  %t98 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t99 = getelementptr { i64 }, ptr %t98, i32 0, i32 0
  %t100 = load i64, ptr %t99
  store i64 %t100, ptr %l41
  store ptr %l41, ptr %l42
  %t101 = load ptr, ptr %l40
  %t102 = load ptr, ptr %l42
  %t103 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t101, ptr %t102)
  store i1 %t103, ptr %l43
  br label %bb16
bb15:
  store i1 false, ptr %l38
  br label %bb17
bb16:
  %t104 = load i1, ptr %l43
  store i1 %t104, ptr %l38
  br label %bb17
bb17:
  %t105 = load i1, ptr %l38
  store i1 %t105, ptr %l35
  br label %bb52
bb18:
  %t106 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t106, ptr %l47
  %t107 = load { i64, [5 x i64] }, ptr %l47
  %t108 = extractvalue { i64, [5 x i64] } %t107, 0
  %t109 = icmp eq i64 %t108, 2
  store i1 %t109, ptr %l48
  %t110 = load i1, ptr %l48
  br i1 %t110, label %bb20, label %bb21
bb19:
  %t111 = load { i64, [5 x i64] }, ptr %l3
  store { i64, [5 x i64] } %t111, ptr %l71
  %t112 = load { i64, [5 x i64] }, ptr %l71
  %t113 = extractvalue { i64, [5 x i64] } %t112, 0
  %t114 = icmp eq i64 %t113, 3
  store i1 %t114, ptr %l72
  %t115 = load i1, ptr %l72
  br i1 %t115, label %bb36, label %bb37
bb20:
  %t116 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t117 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t116, i32 0, i32 0
  %t118 = load i32, ptr %t117
  store i32 %t118, ptr %l50
  store ptr %l50, ptr %l51
  %t119 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t120 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t119, i32 0, i32 0
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l52
  store ptr %l52, ptr %l53
  %t122 = load ptr, ptr %l51
  %t123 = load ptr, ptr %l53
  %t124 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %t122, ptr %t123)
  store i1 %t124, ptr %l54
  br label %bb22
bb21:
  store i1 false, ptr %l49
  br label %bb23
bb22:
  %t125 = load i1, ptr %l54
  store i1 %t125, ptr %l49
  br label %bb23
bb23:
  %t126 = load i1, ptr %l49
  br i1 %t126, label %bb24, label %bb25
bb24:
  %t127 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t128 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t127, i32 0, i32 1
  %t129 = load i64, ptr %t128
  store i64 %t129, ptr %l56
  store ptr %l56, ptr %l57
  %t130 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t131 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t130, i32 0, i32 1
  %t132 = load i64, ptr %t131
  store i64 %t132, ptr %l58
  store ptr %l58, ptr %l59
  %t133 = load ptr, ptr %l57
  %t134 = load ptr, ptr %l59
  %t135 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t133, ptr %t134)
  store i1 %t135, ptr %l60
  br label %bb26
bb25:
  store i1 false, ptr %l55
  br label %bb27
bb26:
  %t136 = load i1, ptr %l60
  store i1 %t136, ptr %l55
  br label %bb27
bb27:
  %t137 = load i1, ptr %l55
  br i1 %t137, label %bb28, label %bb29
bb28:
  %t138 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t139 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t138, i32 0, i32 2
  %t140 = load %"compiler/source:Span", ptr %t139
  store %"compiler/source:Span" %t140, ptr %l62
  store ptr %l62, ptr %l63
  %t141 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t142 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t141, i32 0, i32 2
  %t143 = load %"compiler/source:Span", ptr %t142
  store %"compiler/source:Span" %t143, ptr %l64
  store ptr %l64, ptr %l65
  %t144 = load ptr, ptr %l63
  %t145 = load ptr, ptr %l65
  %t146 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t144, ptr %t145)
  store i1 %t146, ptr %l66
  br label %bb30
bb29:
  store i1 false, ptr %l61
  br label %bb31
bb30:
  %t147 = load i1, ptr %l66
  store i1 %t147, ptr %l61
  br label %bb31
bb31:
  %t148 = load i1, ptr %l61
  br i1 %t148, label %bb32, label %bb33
bb32:
  %t149 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t150 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t149, i32 0, i32 3
  %t151 = load { i64, ptr }, ptr %t150
  store { i64, ptr } %t151, ptr %l68
  %t152 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t153 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t152, i32 0, i32 3
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l69
  %t155 = load { i64, ptr }, ptr %l68
  %t156 = load { i64, ptr }, ptr %l69
  %t157 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t155, { i64, ptr } %t156)
  store i1 %t157, ptr %l70
  br label %bb34
bb33:
  store i1 false, ptr %l67
  br label %bb35
bb34:
  %t158 = load i1, ptr %l70
  store i1 %t158, ptr %l67
  br label %bb35
bb35:
  %t159 = load i1, ptr %l67
  store i1 %t159, ptr %l46
  br label %bb51
bb36:
  %t160 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t160, ptr %l74
  %t161 = load { i64, [5 x i64] }, ptr %l74
  %t162 = extractvalue { i64, [5 x i64] } %t161, 0
  %t163 = icmp eq i64 %t162, 3
  store i1 %t163, ptr %l75
  %t164 = load i1, ptr %l75
  br i1 %t164, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l73
  br label %bb50
bb38:
  %t165 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t166 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t165, i32 0, i32 0
  %t167 = load { i64, ptr }, ptr %t166
  store { i64, ptr } %t167, ptr %l77
  %t168 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t169 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t168, i32 0, i32 0
  %t170 = load { i64, ptr }, ptr %t169
  store { i64, ptr } %t170, ptr %l78
  %t171 = load { i64, ptr }, ptr %l77
  %t172 = load { i64, ptr }, ptr %l78
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t171, { i64, ptr } %t172)
  store i1 %t173, ptr %l79
  br label %bb40
bb39:
  store i1 false, ptr %l76
  br label %bb41
bb40:
  %t174 = load i1, ptr %l79
  store i1 %t174, ptr %l76
  br label %bb41
bb41:
  %t175 = load i1, ptr %l76
  br i1 %t175, label %bb42, label %bb43
bb42:
  %t176 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t177 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t176, i32 0, i32 1
  %t178 = load i64, ptr %t177
  store i64 %t178, ptr %l81
  store ptr %l81, ptr %l82
  %t179 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t180 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t179, i32 0, i32 1
  %t181 = load i64, ptr %t180
  store i64 %t181, ptr %l83
  store ptr %l83, ptr %l84
  %t182 = load ptr, ptr %l82
  %t183 = load ptr, ptr %l84
  %t184 = call i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %t182, ptr %t183)
  store i1 %t184, ptr %l85
  br label %bb44
bb43:
  store i1 false, ptr %l80
  br label %bb45
bb44:
  %t185 = load i1, ptr %l85
  store i1 %t185, ptr %l80
  br label %bb45
bb45:
  %t186 = load i1, ptr %l80
  br i1 %t186, label %bb46, label %bb47
bb46:
  %t187 = getelementptr { i64, [5 x i64] }, ptr %l3, i32 0, i32 1
  %t188 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t187, i32 0, i32 2
  %t189 = load %"compiler/source:Span", ptr %t188
  store %"compiler/source:Span" %t189, ptr %l87
  store ptr %l87, ptr %l88
  %t190 = getelementptr { i64, [5 x i64] }, ptr %l4, i32 0, i32 1
  %t191 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t190, i32 0, i32 2
  %t192 = load %"compiler/source:Span", ptr %t191
  store %"compiler/source:Span" %t192, ptr %l89
  store ptr %l89, ptr %l90
  %t193 = load ptr, ptr %l88
  %t194 = load ptr, ptr %l90
  %t195 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t193, ptr %t194)
  store i1 %t195, ptr %l91
  br label %bb48
bb47:
  store i1 false, ptr %l86
  br label %bb49
bb48:
  %t196 = load i1, ptr %l91
  store i1 %t196, ptr %l86
  br label %bb49
bb49:
  %t197 = load i1, ptr %l86
  store i1 %t197, ptr %l73
  br label %bb50
bb50:
  %t198 = load i1, ptr %l73
  store i1 %t198, ptr %l46
  br label %bb51
bb51:
  %t199 = load i1, ptr %l46
  store i1 %t199, ptr %l35
  br label %bb52
bb52:
  %t200 = load i1, ptr %l35
  store i1 %t200, ptr %l30
  br label %bb53
bb53:
  %t201 = load i1, ptr %l30
  %t202 = xor i1 %t201, true
  store i1 %t202, ptr %l92
  %t203 = load i1, ptr %l92
  br i1 %t203, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 0, ptr @.d40 }, ptr %l93
  %t204 = load { i64, ptr }, ptr %l93
  store { i64, ptr } %t204, ptr %l94
  %t205 = load { i64, ptr }, ptr %l94
  %t206 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t205, 0
  %t207 = insertvalue { { i64, ptr }, i1 } %t206, i1 false, 1
  store { { i64, ptr }, i1 } %t207, ptr %l95
  %t208 = getelementptr { { i64, ptr }, i1 }, ptr %l95, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208
  store { i64, ptr } %t209, ptr %l96
  %t210 = load { i64, ptr }, ptr %l96
  %t211 = extractvalue { i64, ptr } %t210, 0
  store i64 %t211, ptr %l97
  %t212 = load i64, ptr %l97
  %t213 = mul i64 %t212, 1
  %t214 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t213)
  %t215 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l98
  %t217 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t218 = load ptr, ptr %t217
  %t219 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t220 = load ptr, ptr %t219
  %t221 = load i64, ptr %l97
  %t222 = mul i64 %t221, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t218, ptr %t220, i64 %t222, i1 false)
  %t223 = load { i64, ptr }, ptr %l98
  %t224 = getelementptr { { i64, ptr }, i1 }, ptr %l95, i32 0, i32 0
  store { i64, ptr } %t223, ptr %t224
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t225 = load { { i64, ptr }, i1 }, ptr %l95
  store { { i64, ptr }, i1 } %t225, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t226 = load ptr, ptr %l0
  store ptr %t226, ptr %l99
  %t227 = load ptr, ptr %l99
  %t228 = getelementptr %"compiler/interp:Exec", ptr %t227, i32 0, i32 4
  store ptr %t228, ptr %l100
  %t229 = load ptr, ptr %l0
  store ptr %t229, ptr %l101
  %t230 = load ptr, ptr %l101
  %t231 = getelementptr %"compiler/interp:Exec", ptr %t230, i32 0, i32 4
  %t232 = getelementptr %"compiler/eval:Machine", ptr %t231, i32 0, i32 7
  %t233 = load %"compiler/eval:Ptr", ptr %t232
  store %"compiler/eval:Ptr" %t233, ptr %l102
  %t234 = load ptr, ptr %l0
  store ptr %t234, ptr %l103
  %t235 = load ptr, ptr %l103
  %t236 = getelementptr %"compiler/interp:Exec", ptr %t235, i32 0, i32 4
  %t237 = getelementptr %"compiler/eval:Machine", ptr %t236, i32 0, i32 8
  %t238 = load i32, ptr %t237
  store i32 %t238, ptr %l104
  %t239 = load ptr, ptr %l100
  %t240 = load %"compiler/eval:Ptr", ptr %l102
  %t241 = load i32, ptr %l104
  %t242 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %t239, %"compiler/eval:Ptr" %t240, i32 %t241)
  store { i64, ptr } %t242, ptr %l105
  br label %bb57
bb57:
  %t243 = load { i64, ptr }, ptr %l105
  %t244 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t243, 0
  %t245 = insertvalue { { i64, ptr }, i1 } %t244, i1 true, 1
  store { { i64, ptr }, i1 } %t245, ptr %l106
  call void @__olang_scope_close(ptr %s0)
  %t246 = load { { i64, ptr }, i1 }, ptr %l106
  store { { i64, ptr }, i1 } %t246, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i1 }, ptr %rv
  ret { { i64, ptr }, i1 } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i32
  %l68 = alloca i64
  %l69 = alloca i32
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0
  store ptr %t3, ptr %l15
  %t4 = load ptr, ptr %l15
  %t5 = getelementptr %"compiler/interp:Exec", ptr %t4, i32 0, i32 4
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 56
  %t7 = load i64, ptr %t6
  store i64 %t7, ptr %l16
  %t8 = load i64, ptr %l16
  %t9 = icmp sgt i64 %t8, 0
  store i1 %t9, ptr %l17
  %t10 = load i1, ptr %l17
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l18
  %t11 = load ptr, ptr %l0
  store ptr %t11, ptr %l19
  %t12 = load ptr, ptr %l19
  %t13 = getelementptr %"compiler/interp:Exec", ptr %t12, i32 0, i32 4
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 56
  %t15 = load i64, ptr %t14
  store i64 %t15, ptr %l20
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t16 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t16, i64 %t17)
  %t18 = load i64, ptr %l20
  %t19 = call ptr @__olang_sb_room(ptr %s2, i64 24)
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t18)
  call void @__olang_sb_add(ptr %s2, i64 %t20)
  %t21 = extractvalue { i64, ptr } { i64 26, ptr @.d42 }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr @.d42 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t21, i64 %t22)
  %t23 = load ptr, ptr %s2
  %t24 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t25 = load i64, ptr %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t23, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l21
  call void @__olang_sb_done(ptr %s2)
  %t29 = load { i64, ptr }, ptr %l21
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l22
  %t36 = load ptr, ptr %l18
  %t37 = load { i64, ptr }, ptr %l22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t36, { i64, ptr } %t37)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l3
  %t38 = load ptr, ptr %l0
  store ptr %t38, ptr %l23
  %t39 = load ptr, ptr %l23
  %t40 = getelementptr %"compiler/interp:Exec", ptr %t39, i32 0, i32 4
  store ptr %t40, ptr %l24
  %t41 = load ptr, ptr %l24
  %t42 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %t41)
  store i64 %t42, ptr %l25
  br label %bb6
bb6:
  %t43 = load i64, ptr %l25
  store i64 %t43, ptr %l4
  store i64 1, ptr %l5
  %t44 = load i64, ptr %l4
  store i64 %t44, ptr %l26
  %t45 = load i64, ptr %l3
  store i64 %t45, ptr %l27
  %t46 = load i64, ptr %l26
  %t47 = load i64, ptr %l27
  %t48 = icmp sgt i64 %t46, %t47
  store i1 %t48, ptr %l28
  %t49 = load i1, ptr %l28
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t50 = load i64, ptr %l5
  store i64 %t50, ptr %l30
  %t51 = load i64, ptr %l30
  %t52 = icmp sgt i64 %t51, 0
  store i1 %t52, ptr %l31
  %t53 = load i1, ptr %l31
  br i1 %t53, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l29
  br label %bb12
bb9:
  %t54 = load i64, ptr %l4
  store i64 %t54, ptr %l33
  %t55 = load i64, ptr %l3
  store i64 %t55, ptr %l34
  %t56 = load i64, ptr %l33
  %t57 = load i64, ptr %l34
  %t58 = sub i64 %t56, %t57
  store i64 %t58, ptr %l35
  %t59 = load i64, ptr %l5
  store i64 %t59, ptr %l36
  %t60 = load i64, ptr %l35
  %t61 = load i64, ptr %l36
  %t62 = add i64 %t60, %t61
  store i64 %t62, ptr %l37
  %t63 = load i64, ptr %l37
  %t64 = sub i64 %t63, 1
  store i64 %t64, ptr %l38
  %t65 = load i64, ptr %l5
  store i64 %t65, ptr %l39
  %t66 = load i64, ptr %l38
  %t67 = load i64, ptr %l39
  %t68 = sdiv i64 %t66, %t67
  store i64 %t68, ptr %l40
  %t69 = load i64, ptr %l40
  store i64 %t69, ptr %l32
  br label %bb11
bb10:
  store i64 0, ptr %l32
  br label %bb11
bb11:
  %t70 = load i64, ptr %l32
  store i64 %t70, ptr %l29
  br label %bb12
bb12:
  %t71 = load i64, ptr %l29
  store i64 %t71, ptr %l6
  store i64 0, ptr %l7
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load i64, ptr %l7
  store i64 %t72, ptr %l41
  %t73 = load i64, ptr %l6
  store i64 %t73, ptr %l42
  %t74 = load i64, ptr %l41
  %t75 = load i64, ptr %l42
  %t76 = icmp slt i64 %t74, %t75
  store i1 %t76, ptr %l43
  %t77 = load i1, ptr %l43
  %t78 = xor i1 %t77, true
  store i1 %t78, ptr %l44
  %t79 = load i1, ptr %l44
  br i1 %t79, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t80 = load i64, ptr %l3
  store i64 %t80, ptr %l45
  %t81 = load i64, ptr %l7
  store i64 %t81, ptr %l46
  %t82 = load i64, ptr %l5
  store i64 %t82, ptr %l47
  %t83 = load i64, ptr %l46
  %t84 = load i64, ptr %l47
  %t85 = mul i64 %t83, %t84
  store i64 %t85, ptr %l48
  %t86 = load i64, ptr %l45
  %t87 = load i64, ptr %l48
  %t88 = add i64 %t86, %t87
  store i64 %t88, ptr %l49
  %t89 = load i64, ptr %l49
  store i64 %t89, ptr %l8
  %t90 = load ptr, ptr %l0
  store ptr %t90, ptr %l50
  %t91 = load ptr, ptr %l50
  %t92 = getelementptr %"compiler/interp:Exec", ptr %t91, i32 0, i32 4
  store ptr %t92, ptr %l51
  %t93 = load i64, ptr %l8
  store i64 %t93, ptr %l52
  %t94 = load ptr, ptr %l51
  %t95 = load i64, ptr %l52
  %t96 = call { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %t94, i64 %t95)
  store { i64, i64, i64 } %t96, ptr %l53
  br label %bb17
bb17:
  %t97 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t97, ptr %l9
  %t98 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 0
  %t99 = load i64, ptr %t98
  store i64 %t99, ptr %l54
  %t100 = load i64, ptr %l54
  store i64 %t100, ptr %l10
  %t101 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 1
  %t102 = load i64, ptr %t101
  store i64 %t102, ptr %l55
  %t103 = load i64, ptr %l55
  store i64 %t103, ptr %l11
  %t104 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 2
  %t105 = load i64, ptr %t104
  store i64 %t105, ptr %l56
  %t106 = load i64, ptr %l56
  store i64 %t106, ptr %l12
  %t107 = load i64, ptr %l12
  store i64 %t107, ptr %l57
  %t108 = load i64, ptr %l57
  %t109 = icmp eq i64 %t108, 0
  store i1 %t109, ptr %l58
  %t110 = load i1, ptr %l58
  br i1 %t110, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 11, ptr @.d43 }, ptr %l59
  br label %bb23
bb19:
  %t111 = load i64, ptr %l12
  store i64 %t111, ptr %l60
  %t112 = load i64, ptr %l60
  %t113 = icmp eq i64 %t112, 1
  store i1 %t113, ptr %l61
  %t114 = load i1, ptr %l61
  br i1 %t114, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 16, ptr @.d44 }, ptr %l62
  br label %bb22
bb21:
  store { i64, ptr } { i64 40, ptr @.d45 }, ptr %l62
  br label %bb22
bb22:
  %t115 = load { i64, ptr }, ptr %l62
  store { i64, ptr } %t115, ptr %l59
  br label %bb23
bb23:
  %t116 = load { i64, ptr }, ptr %l59
  store { i64, ptr } %t116, ptr %l13
  store ptr %l2, ptr %l63
  %t117 = load ptr, ptr %l1
  store ptr %t117, ptr %l64
  %t118 = load i64, ptr %l10
  store i64 %t118, ptr %l65
  %t119 = load i64, ptr %l11
  store i64 %t119, ptr %l66
  %t120 = load i64, ptr %l66
  %t121 = trunc i64 %t120 to i32
  store i32 %t121, ptr %l67
  %t122 = load i64, ptr %l11
  store i64 %t122, ptr %l68
  %t123 = load i64, ptr %l68
  %t124 = trunc i64 %t123 to i32
  store i32 %t124, ptr %l69
  %t125 = load i32, ptr %l67
  %t126 = load i32, ptr %l69
  %t127 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t125, i32 %t126)
  store %"compiler/source:Span" %t127, ptr %l70
  br label %bb24
bb24:
  %t128 = load ptr, ptr %l64
  %t129 = load i64, ptr %l65
  %t130 = load %"compiler/source:Span", ptr %l70
  %t131 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t128, i64 %t129, %"compiler/source:Span" %t130)
  store { i64, ptr } %t131, ptr %l71
  br label %bb25
bb25:
  %t132 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t132, ptr %l72
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t133 = load { i64, ptr }, ptr %l71
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  call void @__olang_sb_put(ptr %s5, ptr %t134, i64 %t135)
  %t136 = extractvalue { i64, ptr } { i64 2, ptr @.d46 }, 1
  %t137 = extractvalue { i64, ptr } { i64 2, ptr @.d46 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t136, i64 %t137)
  %t138 = load { i64, ptr }, ptr %l72
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  call void @__olang_sb_put(ptr %s5, ptr %t139, i64 %t140)
  %t141 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t141, i64 %t142)
  %t143 = load ptr, ptr %s5
  %t144 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t145 = load i64, ptr %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t143, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l73
  call void @__olang_sb_done(ptr %s5)
  %t149 = load { i64, ptr }, ptr %l73
  %t150 = extractvalue { i64, ptr } %t149, 0
  %t151 = extractvalue { i64, ptr } %t149, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l74
  %t156 = load ptr, ptr %l63
  %t157 = load { i64, ptr }, ptr %l74
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t156, { i64, ptr } %t157)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t158 = load i64, ptr %l7
  store i64 %t158, ptr %l75
  %t159 = load i64, ptr %l75
  %t160 = add i64 %t159, 1
  store i64 %t160, ptr %l76
  %t161 = load i64, ptr %l76
  store i64 %t161, ptr %l7
  call void @__olang_scope_close(ptr %s6)
  br label %bb13
bb28:
  call void @__olang_scope_close(ptr %s3)
  store ptr %l2, ptr %l77
  %t162 = load ptr, ptr %l77
  %t163 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t162)
  store { i64, ptr } %t163, ptr %l78
  br label %bb29
bb29:
  %t164 = load { i64, ptr }, ptr %l78
  store { i64, ptr } %t164, ptr %l79
  %t165 = load { i64, ptr }, ptr %l79
  %t166 = extractvalue { i64, ptr } %t165, 0
  store i64 %t166, ptr %l80
  %t167 = load i64, ptr %l80
  %t168 = mul i64 %t167, 1
  %t169 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t168)
  %t170 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l81
  %t172 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t173 = load ptr, ptr %t172
  %t174 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t175 = load ptr, ptr %t174
  %t176 = load i64, ptr %l80
  %t177 = mul i64 %t176, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t173, ptr %t175, i64 %t177, i1 false)
  %t178 = load { i64, ptr }, ptr %l81
  store { i64, ptr } %t178, ptr %l79
  call void @__olang_scope_close(ptr %s0)
  %t179 = load { i64, ptr }, ptr %l79
  store { i64, ptr } %t179, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [5 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i64
  %l5 = alloca { i64, [5 x i64] }
  %l6 = alloca i1
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca ptr
  %l9 = alloca { i64, [1 x i64] }
  %l10 = alloca { i64, [5 x i64] }
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, [5 x i64] }
  %l35 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [5 x i64] } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [5 x i64] }, ptr %l1
  store { i64, [5 x i64] } %t1, ptr %l5
  %t2 = load { i64, [5 x i64] }, ptr %l5
  %t3 = extractvalue { i64, [5 x i64] } %t2, 0
  %t4 = icmp eq i64 %t3, 0
  store i1 %t4, ptr %l6
  %t5 = load i1, ptr %l6
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [1 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [1 x i64] }, ptr %t7
  store { i64, [1 x i64] } %t8, ptr %l7
  %t9 = load { i64, [1 x i64] }, ptr %l7
  store { i64, [1 x i64] } %t9, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l2
  store ptr %t10, ptr %l8
  %t11 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t11, ptr %l9
  %t12 = load ptr, ptr %l8
  %t13 = load { i64, [1 x i64] }, ptr %l9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v1, ptr %t12, { i64, [1 x i64] } %t13)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb22
bb5:
  %t14 = load { i64, [5 x i64] }, ptr %l1
  store { i64, [5 x i64] } %t14, ptr %l10
  %t15 = load { i64, [5 x i64] }, ptr %l10
  %t16 = extractvalue { i64, [5 x i64] } %t15, 0
  %t17 = icmp eq i64 %t16, 1
  store i1 %t17, ptr %l11
  %t18 = load i1, ptr %l11
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i64, i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l12
  %t22 = load i64, ptr %l12
  store i64 %t22, ptr %l4
  br label %bb8
bb7:
  br label %bb17
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0
  store ptr %t23, ptr %l13
  %t24 = load ptr, ptr %l13
  %t25 = getelementptr %"compiler/interp:Exec", ptr %t24, i32 0, i32 8
  store ptr %t25, ptr %l14
  %t26 = load i64, ptr %l4
  store i64 %t26, ptr %l15
  %t27 = load ptr, ptr %l14
  %t28 = load i64, ptr %l15
  %t29 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t27, i64 %t28)
  store i1 %t29, ptr %l16
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l17
  %t32 = load i1, ptr %l17
  br i1 %t32, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load ptr, ptr %l0
  store ptr %t33, ptr %l18
  %t34 = load ptr, ptr %l18
  %t35 = getelementptr %"compiler/interp:Exec", ptr %t34, i32 0, i32 8
  store ptr %t35, ptr %l19
  %t36 = load i64, ptr %l4
  store i64 %t36, ptr %l20
  %t37 = load ptr, ptr %l19
  %t38 = load i64, ptr %l20
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t37, i64 %t38, i1 true)
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t39 = load ptr, ptr %l0
  store ptr %t39, ptr %l21
  %t40 = load ptr, ptr %l21
  %t41 = getelementptr %"compiler/interp:Exec", ptr %t40, i32 0, i32 4
  store ptr %t41, ptr %l22
  %t42 = load i64, ptr %l4
  store i64 %t42, ptr %l23
  %t43 = load ptr, ptr %l0
  store ptr %t43, ptr %l24
  %t44 = load ptr, ptr %l24
  %t45 = getelementptr %"compiler/interp:Exec", ptr %t44, i32 0, i32 0
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l25
  %t47 = load ptr, ptr %l25
  %t48 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t49 = getelementptr %"compiler/types:Table", ptr %t48, i32 0, i32 0
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l26
  %t51 = load ptr, ptr %l0
  store ptr %t51, ptr %l27
  %t52 = load ptr, ptr %l27
  %t53 = getelementptr %"compiler/interp:Exec", ptr %t52, i32 0, i32 0
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l28
  %t55 = load i64, ptr %l4
  store i64 %t55, ptr %l29
  %t56 = load ptr, ptr %l28
  %t57 = load i64, ptr %l29
  %t58 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t56, i64 %t57)
  store ptr %t58, ptr %l30
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l30
  store ptr %t59, ptr %l31
  %t60 = load ptr, ptr %l31
  %t61 = getelementptr %"compiler/ast:Func", ptr %t60, i32 0, i32 2
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l32
  %t63 = load ptr, ptr %l26
  %t64 = load i32, ptr %l32
  %t65 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t63, i32 %t64)
  store { i64, ptr } %t65, ptr %l33
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l22
  %t67 = load i64, ptr %l23
  %t68 = load { i64, ptr }, ptr %l33
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v0, ptr %t66, i64 %t67, { i64, ptr } %t68)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb17:
  %t69 = load { i64, [5 x i64] }, ptr %l1
  store { i64, [5 x i64] } %t69, ptr %l34
  %t70 = load { i64, [5 x i64] }, ptr %l34
  %t71 = extractvalue { i64, [5 x i64] } %t70, 0
  %t72 = icmp eq i64 %t71, 2
  store i1 %t72, ptr %l35
  %t73 = load i1, ptr %l35
  br i1 %t73, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c48)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eerrorName(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i1
  %l97 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l14
  %t2 = load ptr, ptr %l14
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t2, i32 0, i32 0
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l15
  %t5 = load ptr, ptr %l15
  %t6 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  store ptr %t6, ptr %l16
  %t7 = load ptr, ptr %l0
  store ptr %t7, ptr %l17
  %t8 = load ptr, ptr %l17
  %t9 = getelementptr %"compiler/interp:Exec", ptr %t8, i32 0, i32 0
  %t10 = load ptr, ptr %t9
  store ptr %t10, ptr %l18
  %t11 = load ptr, ptr %l18
  %t12 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  store ptr %t12, ptr %l19
  %t13 = load i32, ptr %l2
  store i32 %t13, ptr %l20
  %t14 = load ptr, ptr %l19
  %t15 = load i32, ptr %l20
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l21
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l16
  %t18 = load i32, ptr %l21
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t20, ptr %l3
  %t21 = load i64, ptr %l1
  store i64 %t21, ptr %l23
  %t22 = load i64, ptr %l23
  %t23 = ashr i64 %t22, 16
  store i64 %t23, ptr %l24
  %t24 = load i64, ptr %l24
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l25
  %t26 = load i64, ptr %l25
  store i64 %t26, ptr %l4
  %t27 = load i64, ptr %l4
  store i64 %t27, ptr %l26
  %t28 = load i64, ptr %l26
  %t29 = icmp slt i64 %t28, 0
  store i1 %t29, ptr %l27
  %t30 = load i1, ptr %l27
  br i1 %t30, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l28
  br label %bb5
bb4:
  %t31 = load i64, ptr %l4
  store i64 %t31, ptr %l29
  %t32 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t32, ptr %l30
  %t33 = load { i64, ptr }, ptr %l30
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l31
  %t35 = load i64, ptr %l29
  %t36 = load i64, ptr %l31
  %t37 = icmp sge i64 %t35, %t36
  store i1 %t37, ptr %l32
  %t38 = load i1, ptr %l32
  store i1 %t38, ptr %l28
  br label %bb5
bb5:
  %t39 = load i1, ptr %l28
  br i1 %t39, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load i64, ptr %l1
  store i64 %t40, ptr %l33
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t41 = extractvalue { i64, ptr } { i64 6, ptr @.d49 }, 1
  %t42 = extractvalue { i64, ptr } { i64 6, ptr @.d49 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t41, i64 %t42)
  %t43 = load i64, ptr %l33
  %t44 = call ptr @__olang_sb_room(ptr %s2, i64 24)
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t43)
  call void @__olang_sb_add(ptr %s2, i64 %t45)
  %t46 = load ptr, ptr %s2
  %t47 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t48 = load i64, ptr %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t46, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l34
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l34
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t53 = load ptr, ptr %l0
  store ptr %t53, ptr %l35
  %t54 = load ptr, ptr %l35
  %t55 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 0
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l36
  %t57 = load ptr, ptr %l36
  %t58 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  store ptr %t58, ptr %l37
  %t59 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t59, ptr %l38
  %t60 = load i64, ptr %l4
  store i64 %t60, ptr %l39
  %t61 = load i64, ptr %l39
  %t62 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  %t64 = getelementptr i32, ptr %t63, i64 %t61
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l40
  %t66 = load ptr, ptr %l37
  %t67 = load i32, ptr %l40
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t68, ptr %l41
  br label %bb9
bb9:
  %t69 = load i32, ptr %l41
  store i32 %t69, ptr %l5
  %t70 = load ptr, ptr %l0
  store ptr %t70, ptr %l42
  %t71 = load ptr, ptr %l42
  %t72 = getelementptr %"compiler/interp:Exec", ptr %t71, i32 0, i32 0
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l43
  %t74 = load ptr, ptr %l43
  %t75 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t75, ptr %l44
  %t76 = load i32, ptr %l5
  store i32 %t76, ptr %l45
  %t77 = load ptr, ptr %l44
  %t78 = load i32, ptr %l45
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t79, ptr %l46
  br label %bb10
bb10:
  %t80 = load i32, ptr %l46
  store i32 %t80, ptr %l6
  %t81 = load ptr, ptr %l0
  store ptr %t81, ptr %l47
  %t82 = load ptr, ptr %l47
  %t83 = getelementptr %"compiler/interp:Exec", ptr %t82, i32 0, i32 0
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l48
  %t85 = load i32, ptr %l6
  store i32 %t85, ptr %l49
  %t86 = load ptr, ptr %l48
  %t87 = load i32, ptr %l49
  %t88 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t86, i32 %t87)
  store { i64, ptr } %t88, ptr %l50
  br label %bb11
bb11:
  %t89 = load { i64, ptr }, ptr %l50
  store { i64, ptr } %t89, ptr %l7
  %t90 = load i64, ptr %l1
  store i64 %t90, ptr %l51
  %t91 = load i64, ptr %l51
  %t92 = and i64 %t91, 65535
  store i64 %t92, ptr %l52
  %t93 = load i64, ptr %l52
  store i64 %t93, ptr %l8
  %t94 = load i64, ptr %l8
  store i64 %t94, ptr %l53
  %t95 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t95, ptr %l54
  %t96 = load { i64, ptr }, ptr %l54
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l55
  %t98 = load i64, ptr %l53
  %t99 = load i64, ptr %l55
  %t100 = icmp slt i64 %t98, %t99
  store i1 %t100, ptr %l56
  %t101 = load i1, ptr %l56
  br i1 %t101, label %bb12, label %bb13
bb12:
  %t102 = load ptr, ptr %l0
  store ptr %t102, ptr %l58
  %t103 = load ptr, ptr %l58
  %t104 = getelementptr %"compiler/interp:Exec", ptr %t103, i32 0, i32 0
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l59
  %t106 = load ptr, ptr %l59
  %t107 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t108 = getelementptr %"compiler/types:Table", ptr %t107, i32 0, i32 0
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l60
  %t110 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t110, ptr %l61
  %t111 = load i64, ptr %l8
  store i64 %t111, ptr %l62
  %t112 = load i64, ptr %l62
  %t113 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t114 = load ptr, ptr %t113
  %t115 = getelementptr i32, ptr %t114, i64 %t112
  %t116 = load i32, ptr %t115
  store i32 %t116, ptr %l63
  %t117 = load ptr, ptr %l60
  %t118 = load i32, ptr %l63
  %t119 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l64
  br label %bb14
bb13:
  %t120 = load i64, ptr %l8
  store i64 %t120, ptr %l66
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t121 = load i64, ptr %l66
  %t122 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t123 = call i64 @__olang_fmt_i64(ptr %t122, i64 %t121)
  call void @__olang_sb_add(ptr %s4, i64 %t123)
  %t124 = load ptr, ptr %s4
  %t125 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t126 = load i64, ptr %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t124, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l67
  call void @__olang_sb_done(ptr %s4)
  %t130 = load { i64, ptr }, ptr %l67
  store { i64, ptr } %t130, ptr %l57
  br label %bb15
bb14:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t131 = load { i64, ptr }, ptr %l64
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  call void @__olang_sb_put(ptr %s3, ptr %t132, i64 %t133)
  %t134 = load ptr, ptr %s3
  %t135 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t136 = load i64, ptr %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t134, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l65
  call void @__olang_sb_done(ptr %s3)
  %t140 = load { i64, ptr }, ptr %l65
  store { i64, ptr } %t140, ptr %l57
  br label %bb15
bb15:
  %t141 = load { i64, ptr }, ptr %l57
  store { i64, ptr } %t141, ptr %l9
  %t142 = load ptr, ptr %l0
  store ptr %t142, ptr %l68
  %t143 = load ptr, ptr %l68
  %t144 = getelementptr %"compiler/interp:Exec", ptr %t143, i32 0, i32 0
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l69
  %t146 = load ptr, ptr %l69
  %t147 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t148 = getelementptr %"compiler/types:Table", ptr %t147, i32 0, i32 0
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l70
  %t150 = load ptr, ptr %l0
  store ptr %t150, ptr %l71
  %t151 = load ptr, ptr %l71
  %t152 = getelementptr %"compiler/interp:Exec", ptr %t151, i32 0, i32 0
  %t153 = load ptr, ptr %t152
  store ptr %t153, ptr %l72
  %t154 = load ptr, ptr %l72
  %t155 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  store ptr %t155, ptr %l73
  %t156 = load i32, ptr %l6
  store i32 %t156, ptr %l74
  %t157 = load ptr, ptr %l73
  %t158 = load i32, ptr %l74
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t157, i32 %t158)
  store i32 %t159, ptr %l75
  br label %bb16
bb16:
  %t160 = load ptr, ptr %l70
  %t161 = load i32, ptr %l75
  %t162 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t160, i32 %t161)
  store { i64, ptr } %t162, ptr %l76
  br label %bb17
bb17:
  %t163 = load { i64, ptr }, ptr %l76
  store { i64, ptr } %t163, ptr %l10
  %t164 = load ptr, ptr %l0
  store ptr %t164, ptr %l77
  %t165 = load ptr, ptr %l77
  %t166 = getelementptr %"compiler/interp:Exec", ptr %t165, i32 0, i32 0
  %t167 = load ptr, ptr %t166
  store ptr %t167, ptr %l78
  %t168 = load ptr, ptr %l78
  %t169 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  store ptr %t169, ptr %l79
  %t170 = load i32, ptr %l6
  store i32 %t170, ptr %l80
  %t171 = load ptr, ptr %l79
  %t172 = load i32, ptr %l80
  %t173 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t171, i32 %t172)
  store i64 %t173, ptr %l81
  br label %bb18
bb18:
  %t174 = load i64, ptr %l81
  store i64 %t174, ptr %l11
  %t175 = load i64, ptr %l11
  store i64 %t175, ptr %l82
  %t176 = load ptr, ptr %l0
  store ptr %t176, ptr %l83
  %t177 = load ptr, ptr %l83
  %t178 = getelementptr %"compiler/interp:Exec", ptr %t177, i32 0, i32 0
  %t179 = load ptr, ptr %t178
  store ptr %t179, ptr %l84
  %t180 = load ptr, ptr %l84
  %t181 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 0
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l85
  %t183 = load ptr, ptr %l85
  %t184 = getelementptr %"compiler/load:Loader", ptr %t183, i32 0, i32 7
  %t185 = load i64, ptr %t184
  store i64 %t185, ptr %l86
  %t186 = load i64, ptr %l82
  %t187 = load i64, ptr %l86
  %t188 = icmp eq i64 %t186, %t187
  store i1 %t188, ptr %l87
  %t189 = load i1, ptr %l87
  br i1 %t189, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l88
  br label %bb22
bb20:
  %t190 = load ptr, ptr %l0
  store ptr %t190, ptr %l89
  %t191 = load ptr, ptr %l89
  %t192 = getelementptr %"compiler/interp:Exec", ptr %t191, i32 0, i32 0
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l90
  %t194 = load ptr, ptr %l90
  %t195 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 0
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l91
  %t197 = load ptr, ptr %l91
  %t198 = getelementptr %"compiler/load:Loader", ptr %t197, i32 0, i32 5
  store ptr %t198, ptr %l92
  %t199 = load i64, ptr %l11
  store i64 %t199, ptr %l93
  %t200 = load ptr, ptr %l92
  %t201 = load i64, ptr %l93
  %t202 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t200, i64 %t201)
  store ptr %t202, ptr %l94
  br label %bb21
bb21:
  %t203 = load ptr, ptr %l94
  store ptr %t203, ptr %l95
  %t204 = load ptr, ptr %l95
  %t205 = getelementptr %"compiler/load:Module", ptr %t204, i32 0, i32 3
  %t206 = load i1, ptr %t205
  store i1 %t206, ptr %l96
  %t207 = load i1, ptr %l96
  store i1 %t207, ptr %l88
  br label %bb22
bb22:
  %t208 = load i1, ptr %l88
  br i1 %t208, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t209 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t209, ptr %l97
  %t210 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t210, ptr %l98
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t211 = load { i64, ptr }, ptr %l97
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  call void @__olang_sb_put(ptr %s6, ptr %t212, i64 %t213)
  %t214 = extractvalue { i64, ptr } { i64 1, ptr @.d50 }, 1
  %t215 = extractvalue { i64, ptr } { i64 1, ptr @.d50 }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t214, i64 %t215)
  %t216 = load { i64, ptr }, ptr %l98
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  call void @__olang_sb_put(ptr %s6, ptr %t217, i64 %t218)
  %t219 = load ptr, ptr %s6
  %t220 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t221 = load i64, ptr %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t219, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l99
  call void @__olang_sb_done(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t225 = load { i64, ptr }, ptr %l99
  store { i64, ptr } %t225, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t226 = load ptr, ptr %l0
  store ptr %t226, ptr %l100
  %t227 = load ptr, ptr %l100
  %t228 = getelementptr %"compiler/interp:Exec", ptr %t227, i32 0, i32 0
  %t229 = load ptr, ptr %t228
  store ptr %t229, ptr %l101
  %t230 = load ptr, ptr %l101
  %t231 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 0
  %t232 = load ptr, ptr %t231
  store ptr %t232, ptr %l102
  %t233 = load ptr, ptr %l102
  %t234 = getelementptr %"compiler/load:Loader", ptr %t233, i32 0, i32 5
  store ptr %t234, ptr %l103
  %t235 = load ptr, ptr %l0
  store ptr %t235, ptr %l104
  %t236 = load ptr, ptr %l104
  %t237 = getelementptr %"compiler/interp:Exec", ptr %t236, i32 0, i32 0
  %t238 = load ptr, ptr %t237
  store ptr %t238, ptr %l105
  %t239 = load ptr, ptr %l105
  %t240 = getelementptr %"compiler/generic:Program", ptr %t239, i32 0, i32 2
  store ptr %t240, ptr %l106
  %t241 = load i32, ptr %l6
  store i32 %t241, ptr %l107
  %t242 = load ptr, ptr %l106
  %t243 = load i32, ptr %l107
  %t244 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t242, i32 %t243)
  store i64 %t244, ptr %l108
  br label %bb26
bb26:
  %t245 = load ptr, ptr %l103
  %t246 = load i64, ptr %l108
  %t247 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t245, i64 %t246)
  store ptr %t247, ptr %l109
  br label %bb27
bb27:
  %t248 = load ptr, ptr %l109
  store ptr %t248, ptr %l110
  %t249 = load ptr, ptr %l110
  %t250 = getelementptr %"compiler/load:Module", ptr %t249, i32 0, i32 2
  %t251 = load { i64, ptr }, ptr %t250
  store { i64, ptr } %t251, ptr %l111
  %t252 = load { i64, ptr }, ptr %l111
  store { i64, ptr } %t252, ptr %l12
  %t253 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t253, ptr %l113
  %t254 = load { i64, ptr }, ptr %l113
  %t255 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t254, { i64, ptr } { i64 1, ptr @.d51 })
  %t256 = extractvalue { i32, i64 } %t255, 1
  %t257 = extractvalue { i32, i64 } %t255, 0
  store i32 %t257, ptr %l115
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb29, label %ok.259
ok.259:
  store i64 %t256, ptr %l114
  br label %bb28
bb28:
  %t260 = load i64, ptr %l114
  store i64 %t260, ptr %l112
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l112
  br label %bb31
bb31:
  %t261 = load i64, ptr %l112
  store i64 %t261, ptr %l13
  %t262 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t262, ptr %l116
  %t263 = load i64, ptr %l13
  store i64 %t263, ptr %l117
  %t264 = load i64, ptr %l117
  %t265 = add i64 %t264, 1
  store i64 %t265, ptr %l118
  %t266 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t266, ptr %l119
  %t267 = load { i64, ptr }, ptr %l119
  store { i64, ptr } %t267, ptr %l120
  %t268 = load { i64, ptr }, ptr %l120
  %t269 = extractvalue { i64, ptr } %t268, 0
  store i64 %t269, ptr %l121
  %t270 = load { i64, ptr }, ptr %l116
  %t271 = extractvalue { i64, ptr } %t270, 0
  store i64 %t271, ptr %l122
  %t272 = load i64, ptr %l118
  %t273 = icmp sge i64 %t272, 0
  store i1 %t273, ptr %l123
  %t274 = load i1, ptr %l123
  br i1 %t274, label %bb32, label %bb33
bb32:
  %t275 = load i64, ptr %l118
  %t276 = load i64, ptr %l121
  %t277 = icmp sle i64 %t275, %t276
  store i1 %t277, ptr %l124
  %t278 = load i1, ptr %l124
  br i1 %t278, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @.c52)
  unreachable
bb34:
  %t279 = load i64, ptr %l121
  %t280 = load i64, ptr %l122
  %t281 = icmp sle i64 %t279, %t280
  store i1 %t281, ptr %l125
  %t282 = load i1, ptr %l125
  br i1 %t282, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @.c52)
  unreachable
bb36:
  %t283 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t284 = load ptr, ptr %t283
  %t285 = load i64, ptr %l118
  %t286 = load i64, ptr %l121
  %t287 = getelementptr i8, ptr %t284, i64 %t285
  %t288 = sub i64 %t286, %t285
  %t289 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t287, 1
  store { i64, ptr } %t290, ptr %l126
  %t291 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t291, ptr %l127
  %t292 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t292, ptr %l128
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t293 = load { i64, ptr }, ptr %l126
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = extractvalue { i64, ptr } %t293, 0
  call void @__olang_sb_put(ptr %s7, ptr %t294, i64 %t295)
  %t296 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 1
  %t297 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t296, i64 %t297)
  %t298 = load { i64, ptr }, ptr %l127
  %t299 = extractvalue { i64, ptr } %t298, 1
  %t300 = extractvalue { i64, ptr } %t298, 0
  call void @__olang_sb_put(ptr %s7, ptr %t299, i64 %t300)
  %t301 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 1
  %t302 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t301, i64 %t302)
  %t303 = load { i64, ptr }, ptr %l128
  %t304 = extractvalue { i64, ptr } %t303, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  call void @__olang_sb_put(ptr %s7, ptr %t304, i64 %t305)
  %t306 = load ptr, ptr %s7
  %t307 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t308 = load i64, ptr %t307
  %t309 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t308)
  call void @llvm.memcpy.p0.p0.i64(ptr %t309, ptr %t306, i64 %t308, i1 false)
  %t310 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t309, 1
  store { i64, ptr } %t311, ptr %l129
  call void @__olang_sb_done(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t312 = load { i64, ptr }, ptr %l129
  store { i64, ptr } %t312, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @.c52)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/mir:Call"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/mir:Task"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/mir:BasicBlock"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, [21 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca { i64, [1 x i64] }
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca %"compiler/mir:Call"
  %l49 = alloca ptr
  %l50 = alloca { i64, [5 x i64] }
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l64 = alloca i32
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca %"compiler/mir:Task"
  %l75 = alloca ptr
  %l76 = alloca { i64, [5 x i64] }
  %l77 = alloca ptr
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca %"compiler/mir:BasicBlock"
  %l101 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %l106 = alloca i32
  %l107 = alloca i32
  %l108 = alloca i1
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l117 = alloca { i64, [21 x i64] }
  %l118 = alloca { i64, [21 x i64] }
  %l119 = alloca i1
  %l120 = alloca i1
  %l121 = alloca { i64, [15 x i64] }
  %l122 = alloca i1
  %l123 = alloca { i64, [1 x i64] }
  %l124 = alloca ptr
  %l125 = alloca { i64, [1 x i64] }
  %l126 = alloca { i64, [21 x i64] }
  %l127 = alloca i1
  %l128 = alloca i32
  %l129 = alloca i64
  %l130 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca i32
  %l135 = alloca i64
  %l136 = alloca i1
  %l137 = alloca i64
  %l138 = alloca i32
  %l139 = alloca i32
  %l140 = alloca { i64, [1 x i64] }
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca { i64, [1 x i64] }
  %l145 = alloca ptr
  %l146 = alloca { i64, [1 x i64] }
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %t242 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l31
  %t2 = load ptr, ptr %l31
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t2, i32 0, i32 14
  store ptr %t3, ptr %l32
  %t4 = load ptr, ptr %l32
  store ptr %t4, ptr %l3
  store i64 0, ptr %l4
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3
  store ptr %t5, ptr %l34
  %t6 = load i64, ptr %l4
  store i64 %t6, ptr %l35
  %t7 = load ptr, ptr %l34
  %t8 = load i64, ptr %l35
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eRunFrom_3ccompiler_2fmir_3aCall_3e(ptr %v1, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l37
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l36
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l36
  store { i64, ptr } %t14, ptr %l33
  br label %bb7
bb3:
  %t15 = load i32, ptr %l37
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l38
  %t17 = load i32, ptr %l38
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l39
  %t19 = load i1, ptr %l39
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb7:
  %t20 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t20, ptr %l5
  %t21 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t21, ptr %l40
  %t22 = load { i64, ptr }, ptr %l40
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l41
  %t24 = load i64, ptr %l41
  store i64 %t24, ptr %l6
  store i64 0, ptr %l7
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7
  store i64 %t25, ptr %l42
  %t26 = load i64, ptr %l6
  store i64 %t26, ptr %l43
  %t27 = load i64, ptr %l42
  %t28 = load i64, ptr %l43
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l44
  %t30 = load i1, ptr %l44
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l45
  %t32 = load i1, ptr %l45
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t33, ptr %l46
  %t34 = load i64, ptr %l7
  store i64 %t34, ptr %l47
  %t35 = load i64, ptr %l47
  %t36 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  %t38 = getelementptr %"compiler/mir:Call", ptr %t37, i64 %t35
  %t39 = load %"compiler/mir:Call", ptr %t38
  store %"compiler/mir:Call" %t39, ptr %l48
  %t40 = load %"compiler/mir:Call", ptr %l48
  store %"compiler/mir:Call" %t40, ptr %l8
  %t41 = load ptr, ptr %l0
  store ptr %t41, ptr %l49
  %t42 = getelementptr %"compiler/mir:Call", ptr %l8, i32 0, i32 0
  %t43 = load { i64, [5 x i64] }, ptr %t42
  store { i64, [5 x i64] } %t43, ptr %l50
  %t44 = load ptr, ptr %l2
  store ptr %t44, ptr %l51
  %t45 = load ptr, ptr %l49
  %t46 = load { i64, [5 x i64] }, ptr %l50
  %t47 = load ptr, ptr %l51
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v2, ptr %t45, { i64, [5 x i64] } %t46, ptr %t47)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l7
  store i64 %t48, ptr %l52
  %t49 = load i64, ptr %l52
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l53
  %t51 = load i64, ptr %l53
  store i64 %t51, ptr %l7
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb14:
  %t52 = load i64, ptr %l4
  store i64 %t52, ptr %l54
  %t53 = load i64, ptr %l6
  store i64 %t53, ptr %l55
  %t54 = load i64, ptr %l54
  %t55 = load i64, ptr %l55
  %t56 = add i64 %t54, %t55
  store i64 %t56, ptr %l56
  %t57 = load i64, ptr %l56
  store i64 %t57, ptr %l4
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb1
bb16:
  call void @__olang_scope_close(ptr %s1)
  store %olang.scope zeroinitializer, ptr %s5
  %t58 = load ptr, ptr %l1
  store ptr %t58, ptr %l57
  %t59 = load ptr, ptr %l57
  %t60 = getelementptr %"compiler/mir:Fn", ptr %t59, i32 0, i32 16
  store ptr %t60, ptr %l58
  %t61 = load ptr, ptr %l58
  store ptr %t61, ptr %l9
  store i64 0, ptr %l10
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t62 = load ptr, ptr %l9
  store ptr %t62, ptr %l60
  %t63 = load i64, ptr %l10
  store i64 %t63, ptr %l61
  %t64 = load ptr, ptr %l60
  %t65 = load i64, ptr %l61
  %t66 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eRunFrom_3ccompiler_2fmir_3aTask_3e(ptr %v1, ptr %t64, i64 %t65)
  %t67 = extractvalue { i32, { i64, ptr } } %t66, 1
  %t68 = extractvalue { i32, { i64, ptr } } %t66, 0
  store i32 %t68, ptr %l63
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb19, label %ok.70
ok.70:
  store { i64, ptr } %t67, ptr %l62
  br label %bb18
bb18:
  %t71 = load { i64, ptr }, ptr %l62
  store { i64, ptr } %t71, ptr %l59
  br label %bb23
bb19:
  %t72 = load i32, ptr %l63
  %t73 = ashr i32 %t72, 16
  store i32 %t73, ptr %l64
  %t74 = load i32, ptr %l64
  %t75 = icmp eq i32 %t74, 1
  store i1 %t75, ptr %l65
  %t76 = load i1, ptr %l65
  br i1 %t76, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c56)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb23:
  %t77 = load { i64, ptr }, ptr %l59
  store { i64, ptr } %t77, ptr %l11
  %t78 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t78, ptr %l66
  %t79 = load { i64, ptr }, ptr %l66
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l67
  %t81 = load i64, ptr %l67
  store i64 %t81, ptr %l12
  store i64 0, ptr %l13
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t82 = load i64, ptr %l13
  store i64 %t82, ptr %l68
  %t83 = load i64, ptr %l12
  store i64 %t83, ptr %l69
  %t84 = load i64, ptr %l68
  %t85 = load i64, ptr %l69
  %t86 = icmp slt i64 %t84, %t85
  store i1 %t86, ptr %l70
  %t87 = load i1, ptr %l70
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l71
  %t89 = load i1, ptr %l71
  br i1 %t89, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb26:
  br label %bb27
bb27:
  %t90 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t90, ptr %l72
  %t91 = load i64, ptr %l13
  store i64 %t91, ptr %l73
  %t92 = load i64, ptr %l73
  %t93 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  %t95 = getelementptr %"compiler/mir:Task", ptr %t94, i64 %t92
  %t96 = load %"compiler/mir:Task", ptr %t95
  store %"compiler/mir:Task" %t96, ptr %l74
  %t97 = load %"compiler/mir:Task", ptr %l74
  store %"compiler/mir:Task" %t97, ptr %l14
  %t98 = load ptr, ptr %l0
  store ptr %t98, ptr %l75
  %t99 = getelementptr %"compiler/mir:Task", ptr %l14, i32 0, i32 0
  %t100 = load { i64, [5 x i64] }, ptr %t99
  store { i64, [5 x i64] } %t100, ptr %l76
  %t101 = load ptr, ptr %l2
  store ptr %t101, ptr %l77
  %t102 = load ptr, ptr %l75
  %t103 = load { i64, [5 x i64] }, ptr %l76
  %t104 = load ptr, ptr %l77
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v2, ptr %t102, { i64, [5 x i64] } %t103, ptr %t104)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t105 = load i64, ptr %l13
  store i64 %t105, ptr %l78
  %t106 = load i64, ptr %l78
  %t107 = add i64 %t106, 1
  store i64 %t107, ptr %l79
  %t108 = load i64, ptr %l79
  store i64 %t108, ptr %l13
  call void @__olang_scope_close(ptr %s8)
  br label %bb24
bb30:
  %t109 = load i64, ptr %l10
  store i64 %t109, ptr %l80
  %t110 = load i64, ptr %l12
  store i64 %t110, ptr %l81
  %t111 = load i64, ptr %l80
  %t112 = load i64, ptr %l81
  %t113 = add i64 %t111, %t112
  store i64 %t113, ptr %l82
  %t114 = load i64, ptr %l82
  store i64 %t114, ptr %l10
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  br label %bb17
bb32:
  call void @__olang_scope_close(ptr %s5)
  store %olang.scope zeroinitializer, ptr %s9
  %t115 = load ptr, ptr %l1
  store ptr %t115, ptr %l83
  %t116 = load ptr, ptr %l83
  %t117 = getelementptr %"compiler/mir:Fn", ptr %t116, i32 0, i32 9
  store ptr %t117, ptr %l84
  %t118 = load ptr, ptr %l84
  store ptr %t118, ptr %l15
  store i64 0, ptr %l16
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s10
  %t119 = load ptr, ptr %l15
  store ptr %t119, ptr %l86
  %t120 = load i64, ptr %l16
  store i64 %t120, ptr %l87
  %t121 = load ptr, ptr %l86
  %t122 = load i64, ptr %l87
  %t123 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v1, ptr %t121, i64 %t122)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l89
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb35, label %ok.127
ok.127:
  store { i64, ptr } %t124, ptr %l88
  br label %bb34
bb34:
  %t128 = load { i64, ptr }, ptr %l88
  store { i64, ptr } %t128, ptr %l85
  br label %bb39
bb35:
  %t129 = load i32, ptr %l89
  %t130 = ashr i32 %t129, 16
  store i32 %t130, ptr %l90
  %t131 = load i32, ptr %l90
  %t132 = icmp eq i32 %t131, 1
  store i1 %t132, ptr %l91
  %t133 = load i1, ptr %l91
  br i1 %t133, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @.c57)
  unreachable
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb39:
  %t134 = load { i64, ptr }, ptr %l85
  store { i64, ptr } %t134, ptr %l17
  %t135 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t135, ptr %l92
  %t136 = load { i64, ptr }, ptr %l92
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l93
  %t138 = load i64, ptr %l93
  store i64 %t138, ptr %l18
  store i64 0, ptr %l19
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t139 = load i64, ptr %l19
  store i64 %t139, ptr %l94
  %t140 = load i64, ptr %l18
  store i64 %t140, ptr %l95
  %t141 = load i64, ptr %l94
  %t142 = load i64, ptr %l95
  %t143 = icmp slt i64 %t141, %t142
  store i1 %t143, ptr %l96
  %t144 = load i1, ptr %l96
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l97
  %t146 = load i1, ptr %l97
  br i1 %t146, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb42:
  br label %bb43
bb43:
  %t147 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t147, ptr %l98
  %t148 = load i64, ptr %l19
  store i64 %t148, ptr %l99
  %t149 = load i64, ptr %l99
  %t150 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t151 = load ptr, ptr %t150
  %t152 = getelementptr %"compiler/mir:BasicBlock", ptr %t151, i64 %t149
  %t153 = load %"compiler/mir:BasicBlock", ptr %t152
  store %"compiler/mir:BasicBlock" %t153, ptr %l100
  %t154 = load %"compiler/mir:BasicBlock", ptr %l100
  store %"compiler/mir:BasicBlock" %t154, ptr %l20
  store %olang.scope zeroinitializer, ptr %s12
  %t155 = getelementptr %"compiler/mir:BasicBlock", ptr %l20, i32 0, i32 0
  store ptr %t155, ptr %l101
  %t156 = load ptr, ptr %l101
  store ptr %t156, ptr %l21
  store i64 0, ptr %l22
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s13
  %t157 = load ptr, ptr %l21
  store ptr %t157, ptr %l103
  %t158 = load i64, ptr %l22
  store i64 %t158, ptr %l104
  %t159 = load ptr, ptr %l103
  %t160 = load i64, ptr %l104
  %t161 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t159, i64 %t160)
  %t162 = extractvalue { i32, { i64, ptr } } %t161, 1
  %t163 = extractvalue { i32, { i64, ptr } } %t161, 0
  store i32 %t163, ptr %l106
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb46, label %ok.165
ok.165:
  store { i64, ptr } %t162, ptr %l105
  br label %bb45
bb45:
  %t166 = load { i64, ptr }, ptr %l105
  store { i64, ptr } %t166, ptr %l102
  br label %bb50
bb46:
  %t167 = load i32, ptr %l106
  %t168 = ashr i32 %t167, 16
  store i32 %t168, ptr %l107
  %t169 = load i32, ptr %l107
  %t170 = icmp eq i32 %t169, 1
  store i1 %t170, ptr %l108
  %t171 = load i1, ptr %l108
  br i1 %t171, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c58)
  unreachable
bb49:
  call void @__olang_scope_close(ptr %s13)
  br label %bb84
bb50:
  %t172 = load { i64, ptr }, ptr %l102
  store { i64, ptr } %t172, ptr %l23
  %t173 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t173, ptr %l109
  %t174 = load { i64, ptr }, ptr %l109
  %t175 = extractvalue { i64, ptr } %t174, 0
  store i64 %t175, ptr %l110
  %t176 = load i64, ptr %l110
  store i64 %t176, ptr %l24
  store i64 0, ptr %l25
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s14
  %t177 = load i64, ptr %l25
  store i64 %t177, ptr %l111
  %t178 = load i64, ptr %l24
  store i64 %t178, ptr %l112
  %t179 = load i64, ptr %l111
  %t180 = load i64, ptr %l112
  %t181 = icmp slt i64 %t179, %t180
  store i1 %t181, ptr %l113
  %t182 = load i1, ptr %l113
  %t183 = xor i1 %t182, true
  store i1 %t183, ptr %l114
  %t184 = load i1, ptr %l114
  br i1 %t184, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s14)
  br label %bb82
bb53:
  br label %bb54
bb54:
  %t185 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t185, ptr %l115
  %t186 = load i64, ptr %l25
  store i64 %t186, ptr %l116
  %t187 = load i64, ptr %l116
  %t188 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t189 = load ptr, ptr %t188
  %t190 = getelementptr { i64, [21 x i64] }, ptr %t189, i64 %t187
  call void @llvm.memmove.p0.p0.i64(ptr %l117, ptr %t190, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %l117, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l118, ptr %l26, i64 176, i1 false)
  %t191 = load { i64, [21 x i64] }, ptr %l118
  %t192 = extractvalue { i64, [21 x i64] } %t191, 0
  %t193 = icmp eq i64 %t192, 0
  store i1 %t193, ptr %l119
  %t194 = load i1, ptr %l119
  br i1 %t194, label %bb55, label %bb56
bb55:
  %t195 = getelementptr { i64, [21 x i64] }, ptr %l26, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t195, i32 0, i32 2
  %t197 = load { i64, [15 x i64] }, ptr %t196
  store { i64, [15 x i64] } %t197, ptr %l121
  %t198 = load { i64, [15 x i64] }, ptr %l121
  %t199 = extractvalue { i64, [15 x i64] } %t198, 0
  %t200 = icmp eq i64 %t199, 10
  store i1 %t200, ptr %l122
  %t201 = load i1, ptr %l122
  store i1 %t201, ptr %l120
  br label %bb57
bb56:
  store i1 false, ptr %l120
  br label %bb57
bb57:
  %t202 = load i1, ptr %l120
  br i1 %t202, label %bb58, label %bb59
bb58:
  %t203 = getelementptr { i64, [21 x i64] }, ptr %l26, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t203, i32 0, i32 2
  %t205 = getelementptr { i64, [15 x i64] }, ptr %t204, i32 0, i32 1
  %t206 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t205, i32 0, i32 0
  %t207 = load { i64, [1 x i64] }, ptr %t206
  store { i64, [1 x i64] } %t207, ptr %l123
  %t208 = load { i64, [1 x i64] }, ptr %l123
  store { i64, [1 x i64] } %t208, ptr %l27
  br label %bb60
bb59:
  br label %bb62
bb60:
  store %olang.scope zeroinitializer, ptr %s15
  %t209 = load ptr, ptr %l2
  store ptr %t209, ptr %l124
  %t210 = load { i64, [1 x i64] }, ptr %l27
  store { i64, [1 x i64] } %t210, ptr %l125
  %t211 = load ptr, ptr %l124
  %t212 = load { i64, [1 x i64] }, ptr %l125
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v2, ptr %t211, { i64, [1 x i64] } %t212)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s15)
  br label %bb80
bb62:
  call void @llvm.memmove.p0.p0.i64(ptr %l126, ptr %l26, i64 176, i1 false)
  %t213 = load { i64, [21 x i64] }, ptr %l126
  %t214 = extractvalue { i64, [21 x i64] } %t213, 0
  %t215 = icmp eq i64 %t214, 6
  store i1 %t215, ptr %l127
  %t216 = load i1, ptr %l127
  br i1 %t216, label %bb63, label %bb64
bb63:
  %t217 = getelementptr { i64, [21 x i64] }, ptr %l26, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t217, i32 0, i32 2
  %t219 = load i32, ptr %t218
  store i32 %t219, ptr %l128
  %t220 = load i32, ptr %l128
  store i32 %t220, ptr %l28
  br label %bb65
bb64:
  br label %bb75
bb65:
  store %olang.scope zeroinitializer, ptr %s16
  %t221 = load ptr, ptr %l0
  store ptr %t221, ptr %l130
  %t222 = load ptr, ptr %l130
  %t223 = getelementptr %"compiler/interp:Exec", ptr %t222, i32 0, i32 7
  store ptr %t223, ptr %l131
  %t224 = load i32, ptr %l28
  store i32 %t224, ptr %l132
  %t225 = load ptr, ptr %l131
  %t226 = load i32, ptr %l132
  %t227 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t225, i32 %t226)
  %t228 = extractvalue { i32, i64 } %t227, 1
  %t229 = extractvalue { i32, i64 } %t227, 0
  store i32 %t229, ptr %l134
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb67, label %ok.231
ok.231:
  store i64 %t228, ptr %l133
  br label %bb66
bb66:
  %t232 = load i64, ptr %l133
  store i64 %t232, ptr %l129
  br label %bb69
bb67:
  br label %bb68
bb68:
  store i64 -1, ptr %l129
  br label %bb69
bb69:
  %t233 = load i64, ptr %l129
  store i64 %t233, ptr %l29
  %t234 = load i64, ptr %l29
  store i64 %t234, ptr %l135
  %t235 = load i64, ptr %l135
  %t236 = icmp sge i64 %t235, 0
  store i1 %t236, ptr %l136
  %t237 = load i1, ptr %l136
  br i1 %t237, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s17
  %t238 = load i64, ptr %l29
  store i64 %t238, ptr %l137
  %t239 = load i64, ptr %l137
  %t240 = trunc i64 %t239 to i32
  store i32 %t240, ptr %l138
  %t241 = load i32, ptr %l138
  store i32 %t241, ptr %l139
  store { i64, [1 x i64] } zeroinitializer, ptr %t242
  %t243 = getelementptr { i64, [1 x i64] }, ptr %t242, i32 0, i32 0
  store i64 0, ptr %t243
  %t244 = load i32, ptr %l139
  %t245 = insertvalue { i32 } undef, i32 %t244, 0
  %t246 = getelementptr { i64, [1 x i64] }, ptr %t242, i32 0, i32 1
  store { i32 } %t245, ptr %t246
  %t247 = load { i64, [1 x i64] }, ptr %t242
  store { i64, [1 x i64] } %t247, ptr %l140
  %t248 = load { i64, [1 x i64] }, ptr %l140
  store { i64, [1 x i64] } %t248, ptr %l30
  %t249 = load ptr, ptr %l0
  store ptr %t249, ptr %l141
  %t250 = load ptr, ptr %l141
  %t251 = getelementptr %"compiler/interp:Exec", ptr %t250, i32 0, i32 4
  store ptr %t251, ptr %l142
  %t252 = load i32, ptr %l28
  store i32 %t252, ptr %l143
  %t253 = load { i64, [1 x i64] }, ptr %l30
  store { i64, [1 x i64] } %t253, ptr %l144
  %t254 = load ptr, ptr %l142
  %t255 = load i32, ptr %l143
  %t256 = load { i64, [1 x i64] }, ptr %l144
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %t254, i32 %t255, { i64, [1 x i64] } %t256)
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t257 = load ptr, ptr %l2
  store ptr %t257, ptr %l145
  %t258 = load { i64, [1 x i64] }, ptr %l30
  store { i64, [1 x i64] } %t258, ptr %l146
  %t259 = load ptr, ptr %l145
  %t260 = load { i64, [1 x i64] }, ptr %l146
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v2, ptr %t259, { i64, [1 x i64] } %t260)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s17)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s16)
  br label %bb80
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s18
  call void @__olang_scope_close(ptr %s18)
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb80:
  call void @__olang_scope_close(ptr %s14)
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s19
  %t261 = load i64, ptr %l25
  store i64 %t261, ptr %l147
  %t262 = load i64, ptr %l147
  %t263 = add i64 %t262, 1
  store i64 %t263, ptr %l148
  %t264 = load i64, ptr %l148
  store i64 %t264, ptr %l25
  call void @__olang_scope_close(ptr %s19)
  br label %bb51
bb82:
  %t265 = load i64, ptr %l22
  store i64 %t265, ptr %l149
  %t266 = load i64, ptr %l24
  store i64 %t266, ptr %l150
  %t267 = load i64, ptr %l149
  %t268 = load i64, ptr %l150
  %t269 = add i64 %t267, %t268
  store i64 %t269, ptr %l151
  %t270 = load i64, ptr %l151
  store i64 %t270, ptr %l22
  call void @__olang_scope_close(ptr %s13)
  br label %bb83
bb83:
  br label %bb44
bb84:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s20
  %t271 = load i64, ptr %l19
  store i64 %t271, ptr %l152
  %t272 = load i64, ptr %l152
  %t273 = add i64 %t272, 1
  store i64 %t273, ptr %l153
  %t274 = load i64, ptr %l153
  store i64 %t274, ptr %l19
  call void @__olang_scope_close(ptr %s20)
  br label %bb40
bb86:
  %t275 = load i64, ptr %l16
  store i64 %t275, ptr %l154
  %t276 = load i64, ptr %l18
  store i64 %t276, ptr %l155
  %t277 = load i64, ptr %l154
  %t278 = load i64, ptr %l155
  %t279 = add i64 %t277, %t278
  store i64 %t279, ptr %l156
  %t280 = load i64, ptr %l156
  store i64 %t280, ptr %l16
  call void @__olang_scope_close(ptr %s10)
  br label %bb87
bb87:
  br label %bb33
bb88:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca { i64, [2 x i64] }
  %l56 = alloca { i64, [2 x i64] }
  %l57 = alloca i1
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i64
  %l63 = alloca { i64, [2 x i64] }
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca i32
  %l73 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i1
  %l77 = alloca i64
  %l78 = alloca i32
  %l79 = alloca i32
  %l80 = alloca { i64, [1 x i64] }
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca i64
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca i1
  %l92 = alloca { i64, [1 x i64] }
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i32
  %l105 = alloca i32
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca i64
  %l118 = alloca i32
  %l119 = alloca i32
  %l120 = alloca { i64, [1 x i64] }
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t129 = alloca { i64, [1 x i64] }, align 8
  %t216 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l20
  %t2 = load ptr, ptr %l20
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t2, i32 0, i32 11
  %t4 = load i1, ptr %t3
  store i1 %t4, ptr %l21
  %t5 = load i1, ptr %l21
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l22
  %t7 = load ptr, ptr %l22
  %t8 = getelementptr %"compiler/interp:Exec", ptr %t7, i32 0, i32 11
  store i1 true, ptr %t8
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l1
  %t9 = load ptr, ptr %l0
  store ptr %t9, ptr %l23
  %t10 = load ptr, ptr %l23
  %t11 = getelementptr %"compiler/interp:Exec", ptr %t10, i32 0, i32 1
  store ptr %t11, ptr %l24
  %t12 = load ptr, ptr %l24
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t12)
  store i64 %t13, ptr %l25
  br label %bb4
bb4:
  %t14 = load i64, ptr %l25
  store i64 %t14, ptr %l2
  store i64 1, ptr %l3
  %t15 = load i64, ptr %l2
  store i64 %t15, ptr %l26
  %t16 = load i64, ptr %l1
  store i64 %t16, ptr %l27
  %t17 = load i64, ptr %l26
  %t18 = load i64, ptr %l27
  %t19 = icmp sgt i64 %t17, %t18
  store i1 %t19, ptr %l28
  %t20 = load i1, ptr %l28
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l3
  store i64 %t21, ptr %l30
  %t22 = load i64, ptr %l30
  %t23 = icmp sgt i64 %t22, 0
  store i1 %t23, ptr %l31
  %t24 = load i1, ptr %l31
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l29
  br label %bb10
bb7:
  %t25 = load i64, ptr %l2
  store i64 %t25, ptr %l33
  %t26 = load i64, ptr %l1
  store i64 %t26, ptr %l34
  %t27 = load i64, ptr %l33
  %t28 = load i64, ptr %l34
  %t29 = sub i64 %t27, %t28
  store i64 %t29, ptr %l35
  %t30 = load i64, ptr %l3
  store i64 %t30, ptr %l36
  %t31 = load i64, ptr %l35
  %t32 = load i64, ptr %l36
  %t33 = add i64 %t31, %t32
  store i64 %t33, ptr %l37
  %t34 = load i64, ptr %l37
  %t35 = sub i64 %t34, 1
  store i64 %t35, ptr %l38
  %t36 = load i64, ptr %l3
  store i64 %t36, ptr %l39
  %t37 = load i64, ptr %l38
  %t38 = load i64, ptr %l39
  %t39 = sdiv i64 %t37, %t38
  store i64 %t39, ptr %l40
  %t40 = load i64, ptr %l40
  store i64 %t40, ptr %l32
  br label %bb9
bb8:
  store i64 0, ptr %l32
  br label %bb9
bb9:
  %t41 = load i64, ptr %l32
  store i64 %t41, ptr %l29
  br label %bb10
bb10:
  %t42 = load i64, ptr %l29
  store i64 %t42, ptr %l4
  store i64 0, ptr %l5
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load i64, ptr %l5
  store i64 %t43, ptr %l41
  %t44 = load i64, ptr %l4
  store i64 %t44, ptr %l42
  %t45 = load i64, ptr %l41
  %t46 = load i64, ptr %l42
  %t47 = icmp slt i64 %t45, %t46
  store i1 %t47, ptr %l43
  %t48 = load i1, ptr %l43
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l44
  %t50 = load i1, ptr %l44
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb13:
  br label %bb14
bb14:
  %t51 = load i64, ptr %l1
  store i64 %t51, ptr %l45
  %t52 = load i64, ptr %l5
  store i64 %t52, ptr %l46
  %t53 = load i64, ptr %l3
  store i64 %t53, ptr %l47
  %t54 = load i64, ptr %l46
  %t55 = load i64, ptr %l47
  %t56 = mul i64 %t54, %t55
  store i64 %t56, ptr %l48
  %t57 = load i64, ptr %l45
  %t58 = load i64, ptr %l48
  %t59 = add i64 %t57, %t58
  store i64 %t59, ptr %l49
  %t60 = load i64, ptr %l49
  store i64 %t60, ptr %l6
  %t61 = load ptr, ptr %l0
  store ptr %t61, ptr %l50
  %t62 = load ptr, ptr %l50
  %t63 = getelementptr %"compiler/interp:Exec", ptr %t62, i32 0, i32 1
  store ptr %t63, ptr %l51
  %t64 = load i64, ptr %l6
  store i64 %t64, ptr %l52
  %t65 = load ptr, ptr %l51
  %t66 = load i64, ptr %l52
  %t67 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t65, i64 %t66)
  store ptr %t67, ptr %l53
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l53
  store ptr %t68, ptr %l7
  %t69 = load ptr, ptr %l7
  store ptr %t69, ptr %l54
  %t70 = load ptr, ptr %l54
  %t71 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 1
  %t72 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t72, ptr %l55
  %t73 = load { i64, [2 x i64] }, ptr %l55
  store { i64, [2 x i64] } %t73, ptr %l8
  %t74 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t74, ptr %l56
  %t75 = load { i64, [2 x i64] }, ptr %l56
  %t76 = extractvalue { i64, [2 x i64] } %t75, 0
  %t77 = icmp eq i64 %t76, 3
  store i1 %t77, ptr %l57
  %t78 = load i1, ptr %l57
  br i1 %t78, label %bb16, label %bb17
bb16:
  %t79 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t80 = getelementptr { i32 }, ptr %t79, i32 0, i32 0
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l58
  %t82 = load i32, ptr %l58
  store i32 %t82, ptr %l9
  br label %bb18
bb17:
  br label %bb20
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load ptr, ptr %l0
  store ptr %t83, ptr %l59
  %t84 = load ptr, ptr %l59
  %t85 = getelementptr %"compiler/interp:Exec", ptr %t84, i32 0, i32 7
  store ptr %t85, ptr %l60
  %t86 = load i32, ptr %l9
  store i32 %t86, ptr %l61
  %t87 = load i64, ptr %l6
  store i64 %t87, ptr %l62
  %t88 = load ptr, ptr %l60
  %t89 = load i32, ptr %l61
  %t90 = load i64, ptr %l62
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t88, i32 %t89, i64 %t90)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb20:
  %t91 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t91, ptr %l63
  %t92 = load { i64, [2 x i64] }, ptr %l63
  %t93 = extractvalue { i64, [2 x i64] } %t92, 0
  %t94 = icmp eq i64 %t93, 6
  store i1 %t94, ptr %l64
  %t95 = load i1, ptr %l64
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t96 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t97 = getelementptr { i64, i32 }, ptr %t96, i32 0, i32 0
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l65
  %t99 = load i64, ptr %l65
  store i64 %t99, ptr %l10
  %t100 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t101 = getelementptr { i64, i32 }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  store i32 %t102, ptr %l66
  %t103 = load i32, ptr %l66
  store i32 %t103, ptr %l11
  br label %bb23
bb22:
  br label %bb35
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load ptr, ptr %l7
  store ptr %t104, ptr %l67
  %t105 = load ptr, ptr %l67
  %t106 = getelementptr %"compiler/typed:Body", ptr %t105, i32 0, i32 11
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l68
  %t108 = load ptr, ptr %l68
  %t109 = icmp eq ptr %t108, null
  store i1 %t109, ptr %l69
  %t110 = load i1, ptr %l69
  br i1 %t110, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t111 = load ptr, ptr %l7
  store ptr %t111, ptr %l70
  %t112 = load i64, ptr %l10
  store i64 %t112, ptr %l71
  %t113 = load i32, ptr %l11
  store i32 %t113, ptr %l72
  %t114 = load ptr, ptr %l70
  %t115 = load i64, ptr %l71
  %t116 = load i32, ptr %l72
  %t117 = call i32 @compiler_2finterp_2eglobalType(ptr %v0, ptr %t114, i64 %t115, i32 %t116)
  store i32 %t117, ptr %l73
  br label %bb27
bb27:
  %t118 = load i32, ptr %l73
  store i32 %t118, ptr %l12
  %t119 = load i32, ptr %l12
  store i32 %t119, ptr %l74
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT
  store i32 %t120, ptr %l75
  %t121 = load i32, ptr %l74
  %t122 = load i32, ptr %l75
  %t123 = icmp eq i32 %t121, %t122
  store i1 %t123, ptr %l76
  %t124 = load i1, ptr %l76
  br i1 %t124, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb29:
  br label %bb30
bb30:
  %t125 = load i64, ptr %l6
  store i64 %t125, ptr %l77
  %t126 = load i64, ptr %l77
  %t127 = trunc i64 %t126 to i32
  store i32 %t127, ptr %l78
  %t128 = load i32, ptr %l78
  store i32 %t128, ptr %l79
  store { i64, [1 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [1 x i64] }, ptr %t129, i32 0, i32 0
  store i64 0, ptr %t130
  %t131 = load i32, ptr %l79
  %t132 = insertvalue { i32 } undef, i32 %t131, 0
  %t133 = getelementptr { i64, [1 x i64] }, ptr %t129, i32 0, i32 1
  store { i32 } %t132, ptr %t133
  %t134 = load { i64, [1 x i64] }, ptr %t129
  store { i64, [1 x i64] } %t134, ptr %l80
  %t135 = load { i64, [1 x i64] }, ptr %l80
  store { i64, [1 x i64] } %t135, ptr %l13
  %t136 = load ptr, ptr %l0
  store ptr %t136, ptr %l81
  %t137 = load ptr, ptr %l81
  %t138 = getelementptr %"compiler/interp:Exec", ptr %t137, i32 0, i32 4
  store ptr %t138, ptr %l82
  %t139 = load i64, ptr %l10
  store i64 %t139, ptr %l83
  %t140 = load i32, ptr %l11
  store i32 %t140, ptr %l84
  %t141 = load i32, ptr %l12
  store i32 %t141, ptr %l85
  %t142 = load ptr, ptr %l0
  store ptr %t142, ptr %l86
  %t143 = load ptr, ptr %l86
  %t144 = getelementptr %"compiler/interp:Exec", ptr %t143, i32 0, i32 0
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l87
  %t146 = load i64, ptr %l10
  store i64 %t146, ptr %l88
  %t147 = load i32, ptr %l11
  store i32 %t147, ptr %l89
  %t148 = load ptr, ptr %l87
  %t149 = load i64, ptr %l88
  %t150 = load i32, ptr %l89
  %t151 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t148, i64 %t149, i32 %t150)
  store ptr %t151, ptr %l90
  br label %bb31
bb31:
  %t152 = load ptr, ptr %l90
  %t153 = call i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %t152)
  store i1 %t153, ptr %l91
  br label %bb32
bb32:
  %t154 = load { i64, [1 x i64] }, ptr %l13
  store { i64, [1 x i64] } %t154, ptr %l92
  %t155 = load ptr, ptr %l82
  %t156 = load i64, ptr %l83
  %t157 = load i32, ptr %l84
  %t158 = load i32, ptr %l85
  %t159 = load i1, ptr %l91
  %t160 = load { i64, [1 x i64] }, ptr %l92
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %t155, i64 %t156, i32 %t157, i32 %t158, i1 %t159, { i64, [1 x i64] } %t160)
  br label %bb33
bb33:
  %t161 = load ptr, ptr %l0
  store ptr %t161, ptr %l93
  %t162 = load ptr, ptr %l93
  %t163 = getelementptr %"compiler/interp:Exec", ptr %t162, i32 0, i32 9
  store ptr %t163, ptr %l94
  %t164 = load i64, ptr %l6
  store i64 %t164, ptr %l95
  %t165 = load ptr, ptr %l94
  %t166 = load i64, ptr %l95
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t165, i64 %t166)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @.c60)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t167 = load i64, ptr %l5
  store i64 %t167, ptr %l96
  %t168 = load i64, ptr %l96
  %t169 = add i64 %t168, 1
  store i64 %t169, ptr %l97
  %t170 = load i64, ptr %l97
  store i64 %t170, ptr %l5
  call void @__olang_scope_close(ptr %s9)
  br label %bb11
bb42:
  call void @__olang_scope_close(ptr %s2)
  store %olang.scope zeroinitializer, ptr %s10
  %t171 = load ptr, ptr %l0
  store ptr %t171, ptr %l98
  %t172 = load ptr, ptr %l98
  %t173 = getelementptr %"compiler/interp:Exec", ptr %t172, i32 0, i32 9
  store ptr %t173, ptr %l99
  %t174 = load ptr, ptr %l99
  store ptr %t174, ptr %l14
  store i64 0, ptr %l15
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  %t175 = load ptr, ptr %l14
  store ptr %t175, ptr %l101
  %t176 = load i64, ptr %l15
  store i64 %t176, ptr %l102
  %t177 = load ptr, ptr %l101
  %t178 = load i64, ptr %l102
  %t179 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t177, i64 %t178)
  %t180 = extractvalue { i32, { i64, ptr } } %t179, 1
  %t181 = extractvalue { i32, { i64, ptr } } %t179, 0
  store i32 %t181, ptr %l104
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb45, label %ok.183
ok.183:
  store { i64, ptr } %t180, ptr %l103
  br label %bb44
bb44:
  %t184 = load { i64, ptr }, ptr %l103
  store { i64, ptr } %t184, ptr %l100
  br label %bb49
bb45:
  %t185 = load i32, ptr %l104
  %t186 = ashr i32 %t185, 16
  store i32 %t186, ptr %l105
  %t187 = load i32, ptr %l105
  %t188 = icmp eq i32 %t187, 1
  store i1 %t188, ptr %l106
  %t189 = load i1, ptr %l106
  br i1 %t189, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @.c61)
  unreachable
bb48:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb49:
  %t190 = load { i64, ptr }, ptr %l100
  store { i64, ptr } %t190, ptr %l16
  %t191 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t191, ptr %l107
  %t192 = load { i64, ptr }, ptr %l107
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l108
  %t194 = load i64, ptr %l108
  store i64 %t194, ptr %l17
  store i64 0, ptr %l18
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t195 = load i64, ptr %l18
  store i64 %t195, ptr %l109
  %t196 = load i64, ptr %l17
  store i64 %t196, ptr %l110
  %t197 = load i64, ptr %l109
  %t198 = load i64, ptr %l110
  %t199 = icmp slt i64 %t197, %t198
  store i1 %t199, ptr %l111
  %t200 = load i1, ptr %l111
  %t201 = xor i1 %t200, true
  store i1 %t201, ptr %l112
  %t202 = load i1, ptr %l112
  br i1 %t202, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s12)
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t203 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t203, ptr %l113
  %t204 = load i64, ptr %l18
  store i64 %t204, ptr %l114
  %t205 = load i64, ptr %l114
  %t206 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  %t208 = getelementptr i64, ptr %t207, i64 %t205
  %t209 = load i64, ptr %t208
  store i64 %t209, ptr %l115
  %t210 = load i64, ptr %l115
  store i64 %t210, ptr %l19
  %t211 = load ptr, ptr %l0
  store ptr %t211, ptr %l116
  %t212 = load i64, ptr %l19
  store i64 %t212, ptr %l117
  %t213 = load i64, ptr %l117
  %t214 = trunc i64 %t213 to i32
  store i32 %t214, ptr %l118
  %t215 = load i32, ptr %l118
  store i32 %t215, ptr %l119
  store { i64, [1 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [1 x i64] }, ptr %t216, i32 0, i32 0
  store i64 0, ptr %t217
  %t218 = load i32, ptr %l119
  %t219 = insertvalue { i32 } undef, i32 %t218, 0
  %t220 = getelementptr { i64, [1 x i64] }, ptr %t216, i32 0, i32 1
  store { i32 } %t219, ptr %t220
  %t221 = load { i64, [1 x i64] }, ptr %t216
  store { i64, [1 x i64] } %t221, ptr %l120
  %t222 = load ptr, ptr %l116
  %t223 = load { i64, [1 x i64] }, ptr %l120
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t222, { i64, [1 x i64] } %t223)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s13
  %t224 = load i64, ptr %l18
  store i64 %t224, ptr %l121
  %t225 = load i64, ptr %l121
  %t226 = add i64 %t225, 1
  store i64 %t226, ptr %l122
  %t227 = load i64, ptr %l122
  store i64 %t227, ptr %l18
  call void @__olang_scope_close(ptr %s13)
  br label %bb50
bb56:
  %t228 = load i64, ptr %l15
  store i64 %t228, ptr %l123
  %t229 = load i64, ptr %l17
  store i64 %t229, ptr %l124
  %t230 = load i64, ptr %l123
  %t231 = load i64, ptr %l124
  %t232 = add i64 %t230, %t231
  store i64 %t232, ptr %l125
  %t233 = load i64, ptr %l125
  store i64 %t233, ptr %l15
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb57:
  br label %bb43
bb58:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2finterp_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List<std/pair:Pair<I64, I32>>"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/check:Ask"
  %l13 = alloca %"std/pair:Pair<I64, I64>"
  %l14 = alloca { i1, i1 }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/generic:ConstAsk"
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, i1 }
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca %"std/pair:Pair<I64, I32>"
  %l34 = alloca ptr
  %l35 = alloca { i64, i1 }
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca %"std/prelude/list:List<std/pair:Pair<I64, I32>>"
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l59 = alloca i32
  %l60 = alloca %"compiler/interp:Exec"
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca %"std/prelude/map:Map<I64, Bool>"
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l72 = alloca i32
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca %"compiler/check:Ask"
  %l83 = alloca i64
  %l84 = alloca i32
  %l85 = alloca i64
  %l86 = alloca %"std/pair:Pair<I64, I64>"
  %l87 = alloca ptr
  %l88 = alloca %"std/pair:Pair<I64, I64>"
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i64
  %l92 = alloca { i1, i1 }
  %l93 = alloca i1
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"std/pair:Pair<I64, I64>"
  %l98 = alloca i1
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l112 = alloca i32
  %l113 = alloca i1
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca %"compiler/generic:ConstAsk"
  %l123 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i64
  %l139 = alloca i32
  %l140 = alloca { i64, i1 }
  %l141 = alloca i64
  %l142 = alloca i1
  %l143 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l148 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l157 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca i32
  %l160 = alloca i32
  %l161 = alloca i1
  %l162 = alloca { i64, ptr }
  %l163 = alloca i64
  %l164 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i1
  %l167 = alloca i1
  %l168 = alloca { i64, ptr }
  %l169 = alloca i64
  %l170 = alloca %"std/pair:Pair<I64, I32>"
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l173 = alloca i64
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca { i64, ptr }
  %l177 = alloca i32
  %l178 = alloca ptr
  %l179 = alloca ptr
  %l180 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca { i64, i1 }
  %l186 = alloca i64
  %l187 = alloca i1
  %l188 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i64
  %l191 = alloca i32
  %l192 = alloca i64
  %l193 = alloca i64
  %l194 = alloca i64
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i1
  %t40 = alloca %"compiler/interp:Exec", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l38
  %t2 = load ptr, ptr %l38
  %t3 = call %"std/prelude/list:List<std/pair:Pair<I64, I32>>" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %s0, ptr %t2)
  store %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %t3, ptr %l39
  br label %bb1
bb1:
  %t4 = load %"std/prelude/list:List<std/pair:Pair<I64, I32>>", ptr %l39
  store %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %t4, ptr %l4
  store ptr %l4, ptr %l40
  %t5 = load ptr, ptr %l40
  %t6 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_H19ac89f3ce4c777c1c093c5956529937(ptr %s0, ptr %t5)
  store i64 %t6, ptr %l41
  br label %bb2
bb2:
  %t7 = load i64, ptr %l41
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l42
  %t9 = load i1, ptr %l42
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1
  store ptr %t10, ptr %l44
  %t11 = load ptr, ptr %l44
  %t12 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 54
  store ptr %t12, ptr %l45
  %t13 = load ptr, ptr %l45
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %t13)
  store i64 %t14, ptr %l46
  br label %bb5
bb4:
  store i1 false, ptr %l43
  br label %bb6
bb5:
  %t15 = load i64, ptr %l46
  %t16 = icmp eq i64 %t15, 0
  store i1 %t16, ptr %l47
  %t17 = load i1, ptr %l47
  store i1 %t17, ptr %l43
  br label %bb6
bb6:
  %t18 = load i1, ptr %l43
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1
  store ptr %t19, ptr %l49
  %t20 = load ptr, ptr %l49
  %t21 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 0
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l50
  %t23 = load ptr, ptr %l50
  %t24 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 33
  store ptr %t24, ptr %l51
  %t25 = load ptr, ptr %l51
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aConstAsk_3e_2e_H7246041139e13b84a5c0718a267d329f(ptr %v1, ptr %t25)
  store i64 %t26, ptr %l52
  br label %bb9
bb8:
  store i1 false, ptr %l48
  br label %bb10
bb9:
  %t27 = load i64, ptr %l52
  %t28 = icmp eq i64 %t27, 0
  store i1 %t28, ptr %l53
  %t29 = load i1, ptr %l53
  store i1 %t29, ptr %l48
  br label %bb10
bb10:
  %t30 = load i1, ptr %l48
  br i1 %t30, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l54
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i1, ptr %l54
  store i1 %t31, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load ptr, ptr %l1
  store ptr %t32, ptr %l55
  %t33 = load ptr, ptr %l55
  %t34 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 0
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l56
  %t36 = load ptr, ptr %l1
  store ptr %t36, ptr %l57
  %t37 = load ptr, ptr %l57
  %t38 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 4
  %t39 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %t38
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t39, ptr %l58
  store i32 0, ptr %l59
  %t41 = load ptr, ptr %l56
  %t42 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l58
  %t43 = load i32, ptr %l59
  call void @compiler_2finterp_3aExec_2ector(ptr %t40, ptr %v1, ptr %v1, ptr %v1, ptr %t41, %"std/prelude/list:List<mut compiler/typed:Body&>" %t42, i32 %t43)
  %t44 = load %"compiler/interp:Exec", ptr %t40
  store %"compiler/interp:Exec" %t44, ptr %l60
  br label %bb14
bb14:
  %t45 = load %"compiler/interp:Exec", ptr %l60
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 800, i64 8)
  store %"compiler/interp:Exec" %t45, ptr %t46
  store ptr %t46, ptr %l61
  %t47 = load ptr, ptr %l61
  store ptr %t47, ptr %l5
  %t48 = load ptr, ptr %l5
  store ptr %t48, ptr %l62
  %t49 = load ptr, ptr %l1
  store ptr %t49, ptr %l63
  %t50 = load ptr, ptr %l63
  %t51 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 56
  %t52 = load %"std/prelude/map:Map<I64, Bool>", ptr %t51
  store %"std/prelude/map:Map<I64, Bool>" %t52, ptr %l64
  %t53 = load %"std/prelude/map:Map<I64, Bool>", ptr %l64
  %t54 = load ptr, ptr %l62
  %t55 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 10
  store %"std/prelude/map:Map<I64, Bool>" %t53, ptr %t55
  store i1 false, ptr %l6
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l1
  store ptr %t56, ptr %l65
  %t57 = load ptr, ptr %l65
  %t58 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 54
  store ptr %t58, ptr %l66
  %t59 = load ptr, ptr %l66
  store ptr %t59, ptr %l7
  store i64 0, ptr %l8
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l7
  store ptr %t60, ptr %l68
  %t61 = load i64, ptr %l8
  store i64 %t61, ptr %l69
  %t62 = load ptr, ptr %l68
  %t63 = load i64, ptr %l69
  %t64 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eRunFrom_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %t62, i64 %t63)
  %t65 = extractvalue { i32, { i64, ptr } } %t64, 1
  %t66 = extractvalue { i32, { i64, ptr } } %t64, 0
  store i32 %t66, ptr %l71
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb17, label %ok.68
ok.68:
  store { i64, ptr } %t65, ptr %l70
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l70
  store { i64, ptr } %t69, ptr %l67
  br label %bb21
bb17:
  %t70 = load i32, ptr %l71
  %t71 = ashr i32 %t70, 16
  store i32 %t71, ptr %l72
  %t72 = load i32, ptr %l72
  %t73 = icmp eq i32 %t72, 1
  store i1 %t73, ptr %l73
  %t74 = load i1, ptr %l73
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb21:
  %t75 = load { i64, ptr }, ptr %l67
  store { i64, ptr } %t75, ptr %l9
  %t76 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t76, ptr %l74
  %t77 = load { i64, ptr }, ptr %l74
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l75
  %t79 = load i64, ptr %l75
  store i64 %t79, ptr %l10
  store i64 0, ptr %l11
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load i64, ptr %l11
  store i64 %t80, ptr %l76
  %t81 = load i64, ptr %l10
  store i64 %t81, ptr %l77
  %t82 = load i64, ptr %l76
  %t83 = load i64, ptr %l77
  %t84 = icmp slt i64 %t82, %t83
  store i1 %t84, ptr %l78
  %t85 = load i1, ptr %l78
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l79
  %t87 = load i1, ptr %l79
  br i1 %t87, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb24:
  br label %bb25
bb25:
  %t88 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t88, ptr %l80
  %t89 = load i64, ptr %l11
  store i64 %t89, ptr %l81
  %t90 = load i64, ptr %l81
  %t91 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t92 = load ptr, ptr %t91
  %t93 = getelementptr %"compiler/check:Ask", ptr %t92, i64 %t90
  %t94 = load %"compiler/check:Ask", ptr %t93
  store %"compiler/check:Ask" %t94, ptr %l82
  %t95 = load %"compiler/check:Ask", ptr %l82
  store %"compiler/check:Ask" %t95, ptr %l12
  %t96 = getelementptr %"compiler/check:Ask", ptr %l12, i32 0, i32 1
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l83
  %t98 = getelementptr %"compiler/check:Ask", ptr %l12, i32 0, i32 2
  %t99 = load i32, ptr %t98
  store i32 %t99, ptr %l84
  %t100 = load i32, ptr %l84
  %t101 = sext i32 %t100 to i64
  store i64 %t101, ptr %l85
  %t102 = load i64, ptr %l83
  %t103 = load i64, ptr %l85
  %t104 = call %"std/pair:Pair<I64, I64>" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t102, i64 %t103)
  store %"std/pair:Pair<I64, I64>" %t104, ptr %l86
  br label %bb26
bb26:
  %t105 = load %"std/pair:Pair<I64, I64>", ptr %l86
  store %"std/pair:Pair<I64, I64>" %t105, ptr %l13
  %t106 = load ptr, ptr %l2
  store ptr %t106, ptr %l87
  %t107 = load %"std/pair:Pair<I64, I64>", ptr %l13
  store %"std/pair:Pair<I64, I64>" %t107, ptr %l88
  %t108 = load ptr, ptr %l87
  %t109 = load %"std/pair:Pair<I64, I64>", ptr %l88
  %t110 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v2, ptr %t108, %"std/pair:Pair<I64, I64>" %t109)
  store i1 %t110, ptr %l89
  br label %bb27
bb27:
  %t111 = load i1, ptr %l89
  br i1 %t111, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t112 = load ptr, ptr %l5
  store ptr %t112, ptr %l90
  %t113 = getelementptr %"compiler/check:Ask", ptr %l12, i32 0, i32 0
  %t114 = load i64, ptr %t113
  store i64 %t114, ptr %l91
  %t115 = load ptr, ptr %l90
  %t116 = load i64, ptr %l91
  %t117 = call { i1, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v1, ptr %t115, i64 %t116)
  store { i1, i1 } %t117, ptr %l92
  br label %bb31
bb31:
  %t118 = load { i1, i1 }, ptr %l92
  store { i1, i1 } %t118, ptr %l14
  %t119 = getelementptr { i1, i1 }, ptr %l14, i32 0, i32 0
  %t120 = load i1, ptr %t119
  store i1 %t120, ptr %l93
  %t121 = load i1, ptr %l93
  store i1 %t121, ptr %l15
  %t122 = getelementptr { i1, i1 }, ptr %l14, i32 0, i32 1
  %t123 = load i1, ptr %t122
  store i1 %t123, ptr %l94
  %t124 = load i1, ptr %l94
  store i1 %t124, ptr %l16
  %t125 = load i1, ptr %l16
  store i1 %t125, ptr %l95
  %t126 = load i1, ptr %l95
  br i1 %t126, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t127 = load ptr, ptr %l2
  store ptr %t127, ptr %l96
  %t128 = load %"std/pair:Pair<I64, I64>", ptr %l13
  store %"std/pair:Pair<I64, I64>" %t128, ptr %l97
  %t129 = load i1, ptr %l15
  store i1 %t129, ptr %l98
  %t130 = load ptr, ptr %l96
  %t131 = load %"std/pair:Pair<I64, I64>", ptr %l97
  %t132 = load i1, ptr %l98
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v2, ptr %t130, %"std/pair:Pair<I64, I64>" %t131, i1 %t132)
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 true, ptr %l6
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t133 = load i64, ptr %l11
  store i64 %t133, ptr %l99
  %t134 = load i64, ptr %l99
  %t135 = add i64 %t134, 1
  store i64 %t135, ptr %l100
  %t136 = load i64, ptr %l100
  store i64 %t136, ptr %l11
  call void @__olang_scope_close(ptr %s7)
  br label %bb22
bb37:
  %t137 = load i64, ptr %l8
  store i64 %t137, ptr %l101
  %t138 = load i64, ptr %l10
  store i64 %t138, ptr %l102
  %t139 = load i64, ptr %l101
  %t140 = load i64, ptr %l102
  %t141 = add i64 %t139, %t140
  store i64 %t141, ptr %l103
  %t142 = load i64, ptr %l103
  store i64 %t142, ptr %l8
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb38:
  br label %bb15
bb39:
  call void @__olang_scope_close(ptr %s2)
  store %olang.scope zeroinitializer, ptr %s8
  %t143 = load ptr, ptr %l1
  store ptr %t143, ptr %l104
  %t144 = load ptr, ptr %l104
  %t145 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 0
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l105
  %t147 = load ptr, ptr %l105
  %t148 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 33
  store ptr %t148, ptr %l106
  %t149 = load ptr, ptr %l106
  store ptr %t149, ptr %l17
  store i64 0, ptr %l18
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t150 = load ptr, ptr %l17
  store ptr %t150, ptr %l108
  %t151 = load i64, ptr %l18
  store i64 %t151, ptr %l109
  %t152 = load ptr, ptr %l108
  %t153 = load i64, ptr %l109
  %t154 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aConstAsk_3e_2e_H3755acdd817c9ece2266e75be7a7be94(ptr %v1, ptr %t152, i64 %t153)
  %t155 = extractvalue { i32, { i64, ptr } } %t154, 1
  %t156 = extractvalue { i32, { i64, ptr } } %t154, 0
  store i32 %t156, ptr %l111
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb42, label %ok.158
ok.158:
  store { i64, ptr } %t155, ptr %l110
  br label %bb41
bb41:
  %t159 = load { i64, ptr }, ptr %l110
  store { i64, ptr } %t159, ptr %l107
  br label %bb46
bb42:
  %t160 = load i32, ptr %l111
  %t161 = ashr i32 %t160, 16
  store i32 %t161, ptr %l112
  %t162 = load i32, ptr %l112
  %t163 = icmp eq i32 %t162, 1
  store i1 %t163, ptr %l113
  %t164 = load i1, ptr %l113
  br i1 %t164, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @.c63)
  unreachable
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb67
bb46:
  %t165 = load { i64, ptr }, ptr %l107
  store { i64, ptr } %t165, ptr %l19
  %t166 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t166, ptr %l114
  %t167 = load { i64, ptr }, ptr %l114
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l115
  %t169 = load i64, ptr %l115
  store i64 %t169, ptr %l20
  store i64 0, ptr %l21
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t170 = load i64, ptr %l21
  store i64 %t170, ptr %l116
  %t171 = load i64, ptr %l20
  store i64 %t171, ptr %l117
  %t172 = load i64, ptr %l116
  %t173 = load i64, ptr %l117
  %t174 = icmp slt i64 %t172, %t173
  store i1 %t174, ptr %l118
  %t175 = load i1, ptr %l118
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l119
  %t177 = load i1, ptr %l119
  br i1 %t177, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb49:
  br label %bb50
bb50:
  %t178 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t178, ptr %l120
  %t179 = load i64, ptr %l21
  store i64 %t179, ptr %l121
  %t180 = load i64, ptr %l121
  %t181 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t182 = load ptr, ptr %t181
  %t183 = getelementptr %"compiler/generic:ConstAsk", ptr %t182, i64 %t180
  %t184 = load %"compiler/generic:ConstAsk", ptr %t183
  store %"compiler/generic:ConstAsk" %t184, ptr %l122
  %t185 = load %"compiler/generic:ConstAsk", ptr %l122
  store %"compiler/generic:ConstAsk" %t185, ptr %l22
  %t186 = getelementptr %"compiler/generic:ConstAsk", ptr %l22, i32 0, i32 6
  %t187 = load { i64, ptr }, ptr %t186
  store { i64, ptr } %t187, ptr %l123
  %t188 = load { i64, ptr }, ptr %l123
  store { i64, ptr } %t188, ptr %l23
  %t189 = load ptr, ptr %l3
  store ptr %t189, ptr %l124
  %t190 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t190, ptr %l125
  %t191 = load ptr, ptr %l124
  %t192 = load { i64, ptr }, ptr %l125
  %t193 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v3, ptr %v1, ptr %t191, { i64, ptr } %t192)
  store i1 %t193, ptr %l126
  br label %bb51
bb51:
  %t194 = load i1, ptr %l126
  br i1 %t194, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb53:
  br label %bb54
bb54:
  %t195 = load ptr, ptr %l1
  store ptr %t195, ptr %l127
  %t196 = getelementptr %"compiler/generic:ConstAsk", ptr %l22, i32 0, i32 0
  %t197 = load i64, ptr %t196
  store i64 %t197, ptr %l128
  %t198 = getelementptr %"compiler/generic:ConstAsk", ptr %l22, i32 0, i32 3
  %t199 = load i64, ptr %t198
  store i64 %t199, ptr %l129
  %t200 = getelementptr %"compiler/generic:ConstAsk", ptr %l22, i32 0, i32 4
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l130
  %t202 = getelementptr %"compiler/generic:ConstAsk", ptr %l22, i32 0, i32 5
  %t203 = load { i64, ptr }, ptr %t202
  store { i64, ptr } %t203, ptr %l131
  %t204 = getelementptr %"compiler/generic:ConstAsk", ptr %l22, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l132
  %t206 = getelementptr %"compiler/generic:ConstAsk", ptr %l22, i32 0, i32 2
  %t207 = load i32, ptr %t206
  store i32 %t207, ptr %l133
  %t208 = load ptr, ptr %l127
  %t209 = load i64, ptr %l128
  %t210 = load i64, ptr %l129
  %t211 = load { i64, ptr }, ptr %l130
  %t212 = load { i64, ptr }, ptr %l131
  %t213 = load ptr, ptr %l132
  %t214 = load i32, ptr %l133
  %t215 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t208, i64 %t209, i64 %t210, { i64, ptr } %t211, { i64, ptr } %t212, ptr %t213, i32 %t214)
  store i64 %t215, ptr %l134
  br label %bb55
bb55:
  %t216 = load i64, ptr %l134
  store i64 %t216, ptr %l24
  %t217 = load i64, ptr %l24
  store i64 %t217, ptr %l135
  %t218 = load i64, ptr %l135
  %t219 = icmp slt i64 %t218, 0
  store i1 %t219, ptr %l136
  %t220 = load i1, ptr %l136
  br i1 %t220, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s12
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb57:
  br label %bb58
bb58:
  %t221 = load ptr, ptr %l5
  store ptr %t221, ptr %l137
  %t222 = load i64, ptr %l24
  store i64 %t222, ptr %l138
  %t223 = getelementptr %"compiler/generic:ConstAsk", ptr %l22, i32 0, i32 2
  %t224 = load i32, ptr %t223
  store i32 %t224, ptr %l139
  %t225 = load ptr, ptr %l137
  %t226 = load i64, ptr %l138
  %t227 = load i32, ptr %l139
  %t228 = call { i64, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInt(ptr %v1, ptr %t225, i64 %t226, i32 %t227)
  store { i64, i1 } %t228, ptr %l140
  br label %bb59
bb59:
  %t229 = load { i64, i1 }, ptr %l140
  store { i64, i1 } %t229, ptr %l25
  %t230 = getelementptr { i64, i1 }, ptr %l25, i32 0, i32 0
  %t231 = load i64, ptr %t230
  store i64 %t231, ptr %l141
  %t232 = load i64, ptr %l141
  store i64 %t232, ptr %l26
  %t233 = getelementptr { i64, i1 }, ptr %l25, i32 0, i32 1
  %t234 = load i1, ptr %t233
  store i1 %t234, ptr %l142
  %t235 = load i1, ptr %l142
  store i1 %t235, ptr %l27
  %t236 = load i1, ptr %l27
  store i1 %t236, ptr %l143
  %t237 = load i1, ptr %l143
  br i1 %t237, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s13
  %t238 = load ptr, ptr %l3
  store ptr %t238, ptr %l144
  %t239 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t239, ptr %l145
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t240 = load { i64, ptr }, ptr %l145
  %t241 = extractvalue { i64, ptr } %t240, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  call void @__olang_sb_put(ptr %s14, ptr %t241, i64 %t242)
  %t243 = load ptr, ptr %s14
  %t244 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t245 = load i64, ptr %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t245)
  call void @llvm.memcpy.p0.p0.i64(ptr %t246, ptr %t243, i64 %t245, i1 false)
  %t247 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  store { i64, ptr } %t248, ptr %l146
  call void @__olang_sb_done(ptr %s14)
  %t249 = load { i64, ptr }, ptr %l146
  %t250 = extractvalue { i64, ptr } %t249, 0
  %t251 = extractvalue { i64, ptr } %t249, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  store { i64, ptr } %t255, ptr %l147
  %t256 = load i64, ptr %l26
  store i64 %t256, ptr %l148
  %t257 = load ptr, ptr %l144
  %t258 = load { i64, ptr }, ptr %l147
  %t259 = load i64, ptr %l148
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v3, ptr %v3, ptr %t257, { i64, ptr } %t258, i64 %t259)
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 true, ptr %l6
  call void @__olang_scope_close(ptr %s13)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  %t260 = load i64, ptr %l21
  store i64 %t260, ptr %l149
  %t261 = load i64, ptr %l149
  %t262 = add i64 %t261, 1
  store i64 %t262, ptr %l150
  %t263 = load i64, ptr %l150
  store i64 %t263, ptr %l21
  call void @__olang_scope_close(ptr %s15)
  br label %bb47
bb65:
  %t264 = load i64, ptr %l18
  store i64 %t264, ptr %l151
  %t265 = load i64, ptr %l20
  store i64 %t265, ptr %l152
  %t266 = load i64, ptr %l151
  %t267 = load i64, ptr %l152
  %t268 = add i64 %t266, %t267
  store i64 %t268, ptr %l153
  %t269 = load i64, ptr %l153
  store i64 %t269, ptr %l18
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb66:
  br label %bb40
bb67:
  call void @__olang_scope_close(ptr %s8)
  store %olang.scope zeroinitializer, ptr %s16
  store ptr %l4, ptr %l154
  %t270 = load ptr, ptr %l154
  store ptr %t270, ptr %l28
  store i64 0, ptr %l29
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s17
  %t271 = load ptr, ptr %l28
  store ptr %t271, ptr %l156
  %t272 = load i64, ptr %l29
  store i64 %t272, ptr %l157
  %t273 = load ptr, ptr %l156
  %t274 = load i64, ptr %l157
  %t275 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_H2d785e59a328798ef633c598d7682c46(ptr %s0, ptr %t273, i64 %t274)
  %t276 = extractvalue { i32, { i64, ptr } } %t275, 1
  %t277 = extractvalue { i32, { i64, ptr } } %t275, 0
  store i32 %t277, ptr %l159
  %t278 = icmp ne i32 %t277, 0
  br i1 %t278, label %bb70, label %ok.279
ok.279:
  store { i64, ptr } %t276, ptr %l158
  br label %bb69
bb69:
  %t280 = load { i64, ptr }, ptr %l158
  store { i64, ptr } %t280, ptr %l155
  br label %bb74
bb70:
  %t281 = load i32, ptr %l159
  %t282 = ashr i32 %t281, 16
  store i32 %t282, ptr %l160
  %t283 = load i32, ptr %l160
  %t284 = icmp eq i32 %t283, 1
  store i1 %t284, ptr %l161
  %t285 = load i1, ptr %l161
  br i1 %t285, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @.c64)
  unreachable
bb73:
  call void @__olang_scope_close(ptr %s17)
  br label %bb92
bb74:
  %t286 = load { i64, ptr }, ptr %l155
  store { i64, ptr } %t286, ptr %l30
  %t287 = load { i64, ptr }, ptr %l30
  store { i64, ptr } %t287, ptr %l162
  %t288 = load { i64, ptr }, ptr %l162
  %t289 = extractvalue { i64, ptr } %t288, 0
  store i64 %t289, ptr %l163
  %t290 = load i64, ptr %l163
  store i64 %t290, ptr %l31
  store i64 0, ptr %l32
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s18
  %t291 = load i64, ptr %l32
  store i64 %t291, ptr %l164
  %t292 = load i64, ptr %l31
  store i64 %t292, ptr %l165
  %t293 = load i64, ptr %l164
  %t294 = load i64, ptr %l165
  %t295 = icmp slt i64 %t293, %t294
  store i1 %t295, ptr %l166
  %t296 = load i1, ptr %l166
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l167
  %t298 = load i1, ptr %l167
  br i1 %t298, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s18)
  br label %bb90
bb77:
  br label %bb78
bb78:
  %t299 = load { i64, ptr }, ptr %l30
  store { i64, ptr } %t299, ptr %l168
  %t300 = load i64, ptr %l32
  store i64 %t300, ptr %l169
  %t301 = load i64, ptr %l169
  %t302 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t303 = load ptr, ptr %t302
  %t304 = getelementptr %"std/pair:Pair<I64, I32>", ptr %t303, i64 %t301
  %t305 = load %"std/pair:Pair<I64, I32>", ptr %t304
  store %"std/pair:Pair<I64, I32>" %t305, ptr %l170
  %t306 = load %"std/pair:Pair<I64, I32>", ptr %l170
  store %"std/pair:Pair<I64, I32>" %t306, ptr %l33
  %t307 = load ptr, ptr %l0
  store ptr %t307, ptr %l171
  %t308 = load ptr, ptr %l171
  %t309 = getelementptr %"compiler/load:Loader", ptr %t308, i32 0, i32 5
  store ptr %t309, ptr %l172
  %t310 = getelementptr %"std/pair:Pair<I64, I32>", ptr %l33, i32 0, i32 0
  %t311 = load i64, ptr %t310
  store i64 %t311, ptr %l173
  %t312 = load ptr, ptr %l172
  %t313 = load i64, ptr %l173
  %t314 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t312, i64 %t313)
  store ptr %t314, ptr %l174
  br label %bb79
bb79:
  %t315 = load ptr, ptr %l174
  store ptr %t315, ptr %l175
  %t316 = load ptr, ptr %l175
  %t317 = getelementptr %"compiler/load:Module", ptr %t316, i32 0, i32 7
  %t318 = load { i64, ptr }, ptr %t317
  store { i64, ptr } %t318, ptr %l176
  %t319 = getelementptr %"std/pair:Pair<I64, I32>", ptr %l33, i32 0, i32 1
  %t320 = load i32, ptr %t319
  store i32 %t320, ptr %l177
  %t321 = load { i64, ptr }, ptr %l176
  %t322 = load i32, ptr %l177
  %t323 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t321, i32 %t322)
  store ptr %t323, ptr %l178
  br label %bb80
bb80:
  %t324 = load ptr, ptr %l178
  store ptr %t324, ptr %l34
  %t325 = load ptr, ptr %l34
  store ptr %t325, ptr %l179
  %t326 = load ptr, ptr %l179
  %t327 = icmp eq ptr %t326, null
  store i1 %t327, ptr %l180
  %t328 = load i1, ptr %l180
  br i1 %t328, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s19
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  br label %bb89
bb82:
  br label %bb83
bb83:
  %t329 = load ptr, ptr %l5
  store ptr %t329, ptr %l181
  %t330 = load ptr, ptr %l1
  store ptr %t330, ptr %l182
  %t331 = getelementptr %"std/pair:Pair<I64, I32>", ptr %l33, i32 0, i32 0
  %t332 = load i64, ptr %t331
  store i64 %t332, ptr %l183
  %t333 = load ptr, ptr %l34
  store ptr %t333, ptr %l184
  %t334 = load ptr, ptr %l181
  %t335 = load ptr, ptr %l182
  %t336 = load i64, ptr %l183
  %t337 = load ptr, ptr %l184
  %t338 = call { i64, i1 } @compiler_2finterp_2echain(ptr %v1, ptr %v1, ptr %v0, ptr %t334, ptr %t335, i64 %t336, ptr %t337)
  store { i64, i1 } %t338, ptr %l185
  br label %bb84
bb84:
  %t339 = load { i64, i1 }, ptr %l185
  store { i64, i1 } %t339, ptr %l35
  %t340 = getelementptr { i64, i1 }, ptr %l35, i32 0, i32 0
  %t341 = load i64, ptr %t340
  store i64 %t341, ptr %l186
  %t342 = load i64, ptr %l186
  store i64 %t342, ptr %l36
  %t343 = getelementptr { i64, i1 }, ptr %l35, i32 0, i32 1
  %t344 = load i1, ptr %t343
  store i1 %t344, ptr %l187
  %t345 = load i1, ptr %l187
  store i1 %t345, ptr %l37
  %t346 = load i1, ptr %l37
  store i1 %t346, ptr %l188
  %t347 = load i1, ptr %l188
  br i1 %t347, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s20
  %t348 = load ptr, ptr %l0
  store ptr %t348, ptr %l189
  %t349 = getelementptr %"std/pair:Pair<I64, I32>", ptr %l33, i32 0, i32 0
  %t350 = load i64, ptr %t349
  store i64 %t350, ptr %l190
  %t351 = getelementptr %"std/pair:Pair<I64, I32>", ptr %l33, i32 0, i32 1
  %t352 = load i32, ptr %t351
  store i32 %t352, ptr %l191
  %t353 = load i64, ptr %l36
  store i64 %t353, ptr %l192
  %t354 = load ptr, ptr %l189
  %t355 = load i64, ptr %l190
  %t356 = load i32, ptr %l191
  %t357 = load i64, ptr %l192
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %t354, i64 %t355, i32 %t356, i64 %t357)
  br label %bb87
bb86:
  br label %bb88
bb87:
  store i1 true, ptr %l6
  call void @__olang_scope_close(ptr %s20)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s18)
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s21
  %t358 = load i64, ptr %l32
  store i64 %t358, ptr %l193
  %t359 = load i64, ptr %l193
  %t360 = add i64 %t359, 1
  store i64 %t360, ptr %l194
  %t361 = load i64, ptr %l194
  store i64 %t361, ptr %l32
  call void @__olang_scope_close(ptr %s21)
  br label %bb75
bb90:
  %t362 = load i64, ptr %l29
  store i64 %t362, ptr %l195
  %t363 = load i64, ptr %l31
  store i64 %t363, ptr %l196
  %t364 = load i64, ptr %l195
  %t365 = load i64, ptr %l196
  %t366 = add i64 %t364, %t365
  store i64 %t366, ptr %l197
  %t367 = load i64, ptr %l197
  store i64 %t367, ptr %l29
  call void @__olang_scope_close(ptr %s17)
  br label %bb91
bb91:
  br label %bb68
bb92:
  call void @__olang_scope_close(ptr %s16)
  %t368 = load i1, ptr %l6
  store i1 %t368, ptr %l198
  call void @__olang_scope_close(ptr %s0)
  %t369 = load i1, ptr %l198
  store i1 %t369, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l8
  %t2 = load { i64, ptr }, ptr %l8
  %t3 = extractvalue { i64, ptr } %t2, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  store i1 %t9, ptr %l9
  %t10 = load i1, ptr %l9
  br i1 %t10, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr null, ptr %l10
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load ptr, ptr %l10
  store ptr %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t12, ptr %l11
  %t13 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t13, ptr %l2
  store i64 0, ptr %l3
  %t14 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t14, ptr %l12
  %t15 = load { i64, ptr }, ptr %l12
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l13
  %t17 = load i64, ptr %l13
  store i64 %t17, ptr %l4
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t18 = load i64, ptr %l3
  store i64 %t18, ptr %l14
  %t19 = load i64, ptr %l4
  store i64 %t19, ptr %l15
  %t20 = load i64, ptr %l14
  %t21 = load i64, ptr %l15
  %t22 = icmp slt i64 %t20, %t21
  store i1 %t22, ptr %l16
  %t23 = load i1, ptr %l16
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l17
  %t25 = load i1, ptr %l17
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t26, ptr %l18
  %t27 = load i64, ptr %l3
  store i64 %t27, ptr %l19
  %t28 = load i64, ptr %l19
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29
  %t31 = getelementptr ptr, ptr %t30, i64 %t28
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l20
  %t33 = load ptr, ptr %l20
  store ptr %t33, ptr %l5
  %t34 = load ptr, ptr %l5
  store ptr %t34, ptr %l21
  store i1 false, ptr %l22
  %t35 = load ptr, ptr %l21
  %t36 = icmp ne ptr %t35, null
  store i1 %t36, ptr %l23
  %t37 = load i1, ptr %l23
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t38 = load ptr, ptr %l21
  %t39 = load i64, ptr %t38
  store i64 %t39, ptr %l24
  %t40 = load i64, ptr %l24
  %t41 = icmp eq i64 %t40, 7
  store i1 %t41, ptr %l22
  br label %bb9
bb9:
  %t42 = load i1, ptr %l22
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l5
  store ptr %t43, ptr %l25
  %t44 = load ptr, ptr %l25
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l26
  %t48 = load ptr, ptr %l26
  store ptr %t48, ptr %l6
  br label %bb12
bb11:
  br label %bb24
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t49 = load ptr, ptr %l6
  store ptr %t49, ptr %l27
  %t50 = load ptr, ptr %l27
  %t51 = getelementptr %"compiler/ast:TopIf", ptr %t50, i32 0, i32 0
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l28
  %t53 = load ptr, ptr %l28
  %t54 = icmp ne ptr %t53, null
  store i1 %t54, ptr %l29
  %t55 = load i1, ptr %l29
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l6
  store ptr %t56, ptr %l31
  %t57 = load ptr, ptr %l31
  %t58 = getelementptr %"compiler/ast:TopIf", ptr %t57, i32 0, i32 0
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l32
  %t60 = load ptr, ptr %l32
  %t61 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t60)
  store %"compiler/source:Span" %t61, ptr %l33
  br label %bb15
bb14:
  store i1 false, ptr %l30
  br label %bb16
bb15:
  %t62 = getelementptr %"compiler/source:Span", ptr %l33, i32 0, i32 0
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l34
  %t64 = load i32, ptr %l1
  store i32 %t64, ptr %l35
  %t65 = load i32, ptr %l34
  %t66 = load i32, ptr %l35
  %t67 = icmp eq i32 %t65, %t66
  store i1 %t67, ptr %l36
  %t68 = load i1, ptr %l36
  store i1 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i1, ptr %l30
  br i1 %t69, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t70 = load ptr, ptr %l6
  store ptr %t70, ptr %l37
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t71 = load ptr, ptr %l37
  store ptr %t71, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l6
  store ptr %t72, ptr %l38
  %t73 = load i32, ptr %l1
  store i32 %t73, ptr %l39
  %t74 = load ptr, ptr %l38
  %t75 = load i32, ptr %l39
  %t76 = call ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %t74, i32 %t75)
  store ptr %t76, ptr %l40
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l40
  store ptr %t77, ptr %l7
  %t78 = load ptr, ptr %l7
  store ptr %t78, ptr %l41
  %t79 = load ptr, ptr %l41
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l42
  %t81 = load i1, ptr %l42
  br i1 %t81, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load ptr, ptr %l7
  store ptr %t82, ptr %l43
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load ptr, ptr %l43
  store ptr %t83, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t84 = load i64, ptr %l3
  store i64 %t84, ptr %l44
  %t85 = load i64, ptr %l44
  %t86 = add i64 %t85, 1
  store i64 %t86, ptr %l45
  %t87 = load i64, ptr %l45
  store i64 %t87, ptr %l3
  call void @__olang_scope_close(ptr %s8)
  br label %bb4
bb31:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %l46
  call void @__olang_scope_close(ptr %s0)
  %t88 = load ptr, ptr %l46
  store ptr %t88, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  %t3 = icmp eq ptr %t2, null
  store i1 %t3, ptr %l5
  %t4 = load i1, ptr %l5
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr null, ptr %l6
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load ptr, ptr %l6
  store ptr %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l7
  %t7 = load ptr, ptr %l7
  %t8 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t9 = load ptr, ptr %t8
  store ptr %t9, ptr %l8
  %t10 = load ptr, ptr %l8
  %t11 = icmp ne ptr %t10, null
  store i1 %t11, ptr %l9
  %t12 = load i1, ptr %l9
  br i1 %t12, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l0
  store ptr %t13, ptr %l10
  %t14 = load ptr, ptr %l10
  %t15 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t16 = load ptr, ptr %t15
  store ptr %t16, ptr %l11
  %t17 = load ptr, ptr %l11
  %t18 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l12
  %t20 = load i32, ptr %l1
  store i32 %t20, ptr %l13
  %t21 = load { i64, ptr }, ptr %l12
  %t22 = load i32, ptr %l13
  %t23 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t21, i32 %t22)
  store ptr %t23, ptr %l14
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t24 = load ptr, ptr %l14
  store ptr %t24, ptr %l2
  %t25 = load ptr, ptr %l2
  store ptr %t25, ptr %l15
  %t26 = load ptr, ptr %l15
  %t27 = icmp ne ptr %t26, null
  store i1 %t27, ptr %l16
  %t28 = load i1, ptr %l16
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l2
  store ptr %t29, ptr %l17
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t30 = load ptr, ptr %l17
  store ptr %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l18
  %t32 = load ptr, ptr %l18
  %t33 = getelementptr %"compiler/ast:TopIf", ptr %t32, i32 0, i32 3
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l19
  %t35 = load ptr, ptr %l19
  %t36 = icmp ne ptr %t35, null
  store i1 %t36, ptr %l20
  %t37 = load i1, ptr %l20
  br i1 %t37, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t38 = load ptr, ptr %l0
  store ptr %t38, ptr %l21
  %t39 = load ptr, ptr %l21
  %t40 = getelementptr %"compiler/ast:TopIf", ptr %t39, i32 0, i32 3
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l22
  %t42 = load ptr, ptr %l22
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t42, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43
  store { i64, ptr } %t44, ptr %l23
  %t45 = load i32, ptr %l1
  store i32 %t45, ptr %l24
  %t46 = load { i64, ptr }, ptr %l23
  %t47 = load i32, ptr %l24
  %t48 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t46, i32 %t47)
  store ptr %t48, ptr %l25
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t49 = load ptr, ptr %l25
  store ptr %t49, ptr %l3
  %t50 = load ptr, ptr %l3
  store ptr %t50, ptr %l26
  %t51 = load ptr, ptr %l26
  %t52 = icmp ne ptr %t51, null
  store i1 %t52, ptr %l27
  %t53 = load i1, ptr %l27
  br i1 %t53, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t54 = load ptr, ptr %l3
  store ptr %t54, ptr %l28
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t55 = load ptr, ptr %l28
  store ptr %t55, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l0
  store ptr %t56, ptr %l29
  %t57 = load ptr, ptr %l29
  %t58 = getelementptr %"compiler/ast:TopIf", ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l30
  %t60 = load i32, ptr %l1
  store i32 %t60, ptr %l31
  %t61 = load ptr, ptr %l30
  %t62 = load i32, ptr %l31
  %t63 = call ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %t61, i32 %t62)
  store ptr %t63, ptr %l32
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load ptr, ptr %l32
  store ptr %t64, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2finterp_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i32
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l10
  %t2 = load ptr, ptr %l10
  %t3 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 11
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l11
  %t5 = load ptr, ptr %l11
  %t6 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6
  store { i64, ptr } %t7, ptr %l12
  %t8 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t8, ptr %l3
  store i64 0, ptr %l4
  %t9 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t9, ptr %l13
  %t10 = load { i64, ptr }, ptr %l13
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l14
  %t12 = load i64, ptr %l14
  store i64 %t12, ptr %l5
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l4
  store i64 %t13, ptr %l15
  %t14 = load i64, ptr %l5
  store i64 %t14, ptr %l16
  %t15 = load i64, ptr %l15
  %t16 = load i64, ptr %l16
  %t17 = icmp slt i64 %t15, %t16
  store i1 %t17, ptr %l17
  %t18 = load i1, ptr %l17
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l18
  %t20 = load i1, ptr %l18
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t21, ptr %l19
  %t22 = load i64, ptr %l4
  store i64 %t22, ptr %l20
  %t23 = load i64, ptr %l20
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = getelementptr ptr, ptr %t25, i64 %t23
  %t27 = load ptr, ptr %t26
  store ptr %t27, ptr %l21
  %t28 = load ptr, ptr %l21
  store ptr %t28, ptr %l6
  %t29 = load ptr, ptr %l6
  store ptr %t29, ptr %l22
  store i1 false, ptr %l23
  %t30 = load ptr, ptr %l22
  %t31 = icmp ne ptr %t30, null
  store i1 %t31, ptr %l24
  %t32 = load i1, ptr %l24
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t33 = load ptr, ptr %l22
  %t34 = load i64, ptr %t33
  store i64 %t34, ptr %l25
  %t35 = load i64, ptr %l25
  %t36 = icmp eq i64 %t35, 1
  store i1 %t36, ptr %l23
  br label %bb6
bb6:
  %t37 = load i1, ptr %l23
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t38 = load ptr, ptr %l6
  store ptr %t38, ptr %l27
  %t39 = load ptr, ptr %l27
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t40, i32 0, i32 1
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l28
  store i1 false, ptr %l29
  %t43 = load ptr, ptr %l28
  %t44 = icmp ne ptr %t43, null
  store i1 %t44, ptr %l30
  %t45 = load i1, ptr %l30
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l26
  br label %bb11
bb9:
  %t46 = load ptr, ptr %l28
  %t47 = load i64, ptr %t46
  store i64 %t47, ptr %l31
  %t48 = load i64, ptr %l31
  %t49 = icmp eq i64 %t48, 1
  store i1 %t49, ptr %l29
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29
  store i1 %t50, ptr %l26
  br label %bb11
bb11:
  %t51 = load i1, ptr %l26
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l6
  store ptr %t52, ptr %l32
  %t53 = load ptr, ptr %l32
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l33
  %t57 = load ptr, ptr %l33
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t58, i32 0, i32 1
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l34
  %t61 = load i32, ptr %l34
  store i32 %t61, ptr %l7
  %t62 = load ptr, ptr %l6
  store ptr %t62, ptr %l35
  %t63 = load ptr, ptr %l35
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t63, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l36
  %t67 = load ptr, ptr %l36
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t68, i32 0, i32 2
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l37
  %t71 = load i64, ptr %l37
  store i64 %t71, ptr %l8
  %t72 = load ptr, ptr %l6
  store ptr %t72, ptr %l38
  %t73 = load ptr, ptr %l38
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l39
  %t77 = load ptr, ptr %l39
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t78, i32 0, i32 3
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l40
  %t81 = load i32, ptr %l40
  store i32 %t81, ptr %l9
  br label %bb14
bb13:
  br label %bb21
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load i64, ptr %l8
  store i64 %t82, ptr %l41
  %t83 = load i64, ptr %l1
  store i64 %t83, ptr %l42
  %t84 = load i64, ptr %l41
  %t85 = load i64, ptr %l42
  %t86 = icmp eq i64 %t84, %t85
  store i1 %t86, ptr %l43
  %t87 = load i1, ptr %l43
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t88 = load i32, ptr %l9
  store i32 %t88, ptr %l45
  %t89 = load i32, ptr %l2
  store i32 %t89, ptr %l46
  %t90 = load i32, ptr %l45
  %t91 = load i32, ptr %l46
  %t92 = icmp eq i32 %t90, %t91
  store i1 %t92, ptr %l47
  %t93 = load i1, ptr %l47
  store i1 %t93, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l44
  br label %bb17
bb17:
  %t94 = load i1, ptr %l44
  br i1 %t94, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load i32, ptr %l7
  store i32 %t95, ptr %l48
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t96 = load i32, ptr %l48
  store i32 %t96, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l4
  store i64 %t97, ptr %l49
  %t98 = load i64, ptr %l49
  %t99 = add i64 %t98, 1
  store i64 %t99, ptr %l50
  %t100 = load i64, ptr %l50
  store i64 %t100, ptr %l4
  call void @__olang_scope_close(ptr %s6)
  br label %bb1
bb28:
  call void @__olang_scope_close(ptr %s1)
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT
  store i32 %t101, ptr %l51
  call void @__olang_scope_close(ptr %s0)
  %t102 = load i32, ptr %l51
  store i32 %t102, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2finterp_2ejudgeViews(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l6 = alloca %"compiler/views:Viewer"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %s0 = alloca %olang.scope
  %t9 = alloca %"compiler/views:Viewer", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  %t2 = load ptr, ptr %l2
  %t3 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 0
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l3
  %t5 = load ptr, ptr %l0
  store ptr %t5, ptr %l4
  %t6 = load ptr, ptr %l4
  %t7 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 4
  %t8 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %t7
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t8, ptr %l5
  %t10 = load ptr, ptr %l3
  %t11 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l5
  call void @compiler_2fviews_3aViewer_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v0, ptr %t10, %"std/prelude/list:List<mut compiler/typed:Body&>" %t11)
  %t12 = load %"compiler/views:Viewer", ptr %t9
  store %"compiler/views:Viewer" %t12, ptr %l6
  br label %bb1
bb1:
  %t13 = load %"compiler/views:Viewer", ptr %l6
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 216, i64 8)
  store %"compiler/views:Viewer" %t13, ptr %t14
  store ptr %t14, ptr %l7
  %t15 = load ptr, ptr %l7
  store ptr %t15, ptr %l1
  %t16 = load ptr, ptr %l1
  store ptr %t16, ptr %l8
  %t17 = load ptr, ptr %l8
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %t17)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l5
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l6
  %t3 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  store i32 %t4, ptr %l7
  %t5 = load i32, ptr %l7
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l8
  %t7 = load ptr, ptr %l5
  %t8 = load i64, ptr %l6
  %t9 = load i64, ptr %l8
  %t10 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %t7, i64 %t8, i64 %t9)
  store { i64, ptr } %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t11, ptr %l3
  %t12 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t12, ptr %l11
  %t13 = load { i64, ptr }, ptr %l11
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 1, ptr @.d67 })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l13
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store i64 %t15, ptr %l12
  br label %bb2
bb2:
  %t19 = load i64, ptr %l12
  store i64 %t19, ptr %l10
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l10
  br label %bb5
bb5:
  %t20 = load i64, ptr %l10
  store i64 %t20, ptr %l4
  %t21 = load i64, ptr %l4
  store i64 %t21, ptr %l14
  %t22 = load i64, ptr %l14
  %t23 = icmp sge i64 %t22, 0
  store i1 %t23, ptr %l15
  %t24 = load i1, ptr %l15
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr %l4
  store i64 %t25, ptr %l17
  %t26 = load { i64, ptr }, ptr %l3
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l18
  %t28 = icmp sge i64 0, 0
  store i1 %t28, ptr %l19
  %t29 = load i1, ptr %l19
  br i1 %t29, label %bb8, label %bb9
bb7:
  %t30 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t30, ptr %l24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t31 = load { i64, ptr }, ptr %l24
  %t32 = extractvalue { i64, ptr } %t31, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  call void @__olang_sb_put(ptr %s2, ptr %t32, i64 %t33)
  %t34 = load ptr, ptr %s2
  %t35 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t36 = load i64, ptr %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t34, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l25
  call void @__olang_sb_done(ptr %s2)
  %t40 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t40, ptr %l16
  br label %bb14
bb8:
  %t41 = load i64, ptr %l17
  %t42 = icmp sle i64 0, %t41
  store i1 %t42, ptr %l20
  %t43 = load i1, ptr %l20
  br i1 %t43, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb10:
  %t44 = load i64, ptr %l17
  %t45 = load i64, ptr %l18
  %t46 = icmp sle i64 %t44, %t45
  store i1 %t46, ptr %l21
  %t47 = load i1, ptr %l21
  br i1 %t47, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb12:
  %t48 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  %t50 = load i64, ptr %l17
  %t51 = getelementptr i8, ptr %t49, i64 0
  %t52 = sub i64 %t50, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  store { i64, ptr } %t54, ptr %l22
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t55 = load { i64, ptr }, ptr %l22
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  call void @__olang_sb_put(ptr %s1, ptr %t56, i64 %t57)
  %t58 = load ptr, ptr %s1
  %t59 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t60 = load i64, ptr %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t58, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l23
  call void @__olang_sb_done(ptr %s1)
  %t64 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t64, ptr %l16
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t65 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2
  %t7 = ashr i32 %t6, 16
  store i32 %t7, ptr %l3
  %t8 = load i32, ptr %l3
  %t9 = icmp eq i32 %t8, 1
  store i1 %t9, ptr %l4
  %t10 = load i1, ptr %l4
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c69)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  %t3 = icmp eq ptr %t2, null
  store i1 %t3, ptr %l4
  %t4 = load i1, ptr %l4
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0
  store ptr %t5, ptr %l6
  %t6 = load ptr, ptr %l6
  %t7 = getelementptr %"compiler/ast:VarDecl", ptr %t6, i32 0, i32 2
  %t8 = load ptr, ptr %t7
  store ptr %t8, ptr %l7
  %t9 = load ptr, ptr %l7
  %t10 = icmp eq ptr %t9, null
  store i1 %t10, ptr %l8
  %t11 = load i1, ptr %l8
  store i1 %t11, ptr %l5
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5
  br i1 %t12, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l9
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i1, ptr %l9
  store i1 %t13, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0
  store ptr %t14, ptr %l10
  %t15 = load ptr, ptr %l10
  %t16 = getelementptr %"compiler/ast:VarDecl", ptr %t15, i32 0, i32 2
  %t17 = load ptr, ptr %t16
  store ptr %t17, ptr %l11
  %t18 = load ptr, ptr %l11
  store ptr %t18, ptr %l1
  %t19 = load ptr, ptr %l1
  store ptr %t19, ptr %l13
  store i1 false, ptr %l14
  %t20 = load ptr, ptr %l13
  %t21 = icmp ne ptr %t20, null
  store i1 %t21, ptr %l15
  %t22 = load i1, ptr %l15
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l16
  %t25 = load i64, ptr %l16
  %t26 = icmp eq i64 %t25, 5
  store i1 %t26, ptr %l14
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l1
  store ptr %t28, ptr %l17
  %t29 = load ptr, ptr %l17
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t30, i32 0, i32 2
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l18
  %t33 = load i1, ptr %l18
  store i1 %t33, ptr %l2
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i1, ptr %l2
  store i1 %t34, ptr %l19
  %t35 = load i1, ptr %l19
  store i1 %t35, ptr %l12
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 false, ptr %l12
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i1, ptr %l12
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List<mut compiler/typed:Body&>" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l5 = alloca i32
  %l6 = alloca %"compiler/lower:Lowerer"
  %l7 = alloca %"compiler/eval:Machine"
  %l8 = alloca %"std/prelude/list:List<compiler/mir:FnKey>"
  %l9 = alloca %"std/prelude/map:Map<compiler/mir:FnKey, Bool>"
  %l10 = alloca %"std/prelude/map:Map<compiler/types:TypeId, I64>"
  %l11 = alloca %"std/prelude/map:Map<I64, Bool>"
  %l12 = alloca %"std/prelude/list:List<I64>"
  %l13 = alloca %"std/prelude/map:Map<I64, Bool>"
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l20 = alloca %"compiler/lower:Lowerer"
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca %"compiler/eval:Machine"
  %l25 = alloca %"std/prelude/list:List<compiler/mir:FnKey>"
  %l26 = alloca %"std/prelude/map:Map<compiler/mir:FnKey, Bool>"
  %l27 = alloca %"std/prelude/map:Map<compiler/types:TypeId, I64>"
  %l28 = alloca %"std/prelude/map:Map<I64, Bool>"
  %l29 = alloca %"std/prelude/list:List<I64>"
  %l30 = alloca %"std/prelude/map:Map<I64, Bool>"
  %l31 = alloca %"compiler/interp:Exec"
  %s0 = alloca %olang.scope
  %t17 = alloca %"compiler/eval:Machine", align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l15
  %t2 = load ptr, ptr %l15
  store ptr %t2, ptr %l3
  %t3 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l1
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t3, ptr %l16
  %t4 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l16
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t4, ptr %l4
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l17
  %t6 = load i32, ptr %l17
  store i32 %t6, ptr %l5
  %t7 = load ptr, ptr %l0
  store ptr %t7, ptr %l18
  %t8 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l1
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t8, ptr %l19
  %t9 = load ptr, ptr %l18
  %t10 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l19
  %t11 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %t9, %"std/prelude/list:List<mut compiler/typed:Body&>" %t10)
  store %"compiler/lower:Lowerer" %t11, ptr %l20
  br label %bb1
bb1:
  %t12 = load %"compiler/lower:Lowerer", ptr %l20
  store %"compiler/lower:Lowerer" %t12, ptr %l6
  %t13 = load ptr, ptr %l0
  store ptr %t13, ptr %l21
  %t14 = load ptr, ptr %l21
  %t15 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  store ptr %t15, ptr %l22
  %t16 = load i32, ptr %l2
  store i32 %t16, ptr %l23
  %t18 = load ptr, ptr %l22
  %t19 = load i32, ptr %l23
  call void @compiler_2feval_2eNewMachine(ptr %t17, ptr %v0, ptr %v2, ptr %t18, i32 %t19)
  %t20 = load %"compiler/eval:Machine", ptr %t17
  store %"compiler/eval:Machine" %t20, ptr %l24
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l24, i64 624, i1 false)
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/list:List<compiler/mir:FnKey>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t21)
  store %"std/prelude/list:List<compiler/mir:FnKey>" %t22, ptr %l25
  br label %bb3
bb3:
  %t23 = load %"std/prelude/list:List<compiler/mir:FnKey>", ptr %l25
  store %"std/prelude/list:List<compiler/mir:FnKey>" %t23, ptr %l8
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %t24)
  store %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" %t25, ptr %l26
  br label %bb4
bb4:
  %t26 = load %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", ptr %l26
  store %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" %t26, ptr %l9
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/map:Map<compiler/types:TypeId, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t27)
  store %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t28, ptr %l27
  br label %bb5
bb5:
  %t29 = load %"std/prelude/map:Map<compiler/types:TypeId, I64>", ptr %l27
  store %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t29, ptr %l10
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/map:Map<I64, Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t30)
  store %"std/prelude/map:Map<I64, Bool>" %t31, ptr %l28
  br label %bb6
bb6:
  %t32 = load %"std/prelude/map:Map<I64, Bool>", ptr %l28
  store %"std/prelude/map:Map<I64, Bool>" %t32, ptr %l11
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t33)
  store %"std/prelude/list:List<I64>" %t34, ptr %l29
  br label %bb7
bb7:
  %t35 = load %"std/prelude/list:List<I64>", ptr %l29
  store %"std/prelude/list:List<I64>" %t35, ptr %l12
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/map:Map<I64, Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t36)
  store %"std/prelude/map:Map<I64, Bool>" %t37, ptr %l30
  br label %bb8
bb8:
  %t38 = load %"std/prelude/map:Map<I64, Bool>", ptr %l30
  store %"std/prelude/map:Map<I64, Bool>" %t38, ptr %l13
  store i1 false, ptr %l14
  %t39 = load ptr, ptr %l3
  %t40 = insertvalue %"compiler/interp:Exec" undef, ptr %t39, 0
  %t41 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l4
  %t42 = insertvalue %"compiler/interp:Exec" %t40, %"std/prelude/list:List<mut compiler/typed:Body&>" %t41, 1
  %t43 = load i32, ptr %l5
  %t44 = insertvalue %"compiler/interp:Exec" %t42, i32 %t43, 2
  %t45 = load %"compiler/lower:Lowerer", ptr %l6
  %t46 = insertvalue %"compiler/interp:Exec" %t44, %"compiler/lower:Lowerer" %t45, 3
  %t47 = load %"compiler/eval:Machine", ptr %l7
  %t48 = insertvalue %"compiler/interp:Exec" %t46, %"compiler/eval:Machine" %t47, 4
  %t49 = load %"std/prelude/list:List<compiler/mir:FnKey>", ptr %l8
  %t50 = insertvalue %"compiler/interp:Exec" %t48, %"std/prelude/list:List<compiler/mir:FnKey>" %t49, 5
  %t51 = load %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", ptr %l9
  %t52 = insertvalue %"compiler/interp:Exec" %t50, %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" %t51, 6
  %t53 = load %"std/prelude/map:Map<compiler/types:TypeId, I64>", ptr %l10
  %t54 = insertvalue %"compiler/interp:Exec" %t52, %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t53, 7
  %t55 = load %"std/prelude/map:Map<I64, Bool>", ptr %l11
  %t56 = insertvalue %"compiler/interp:Exec" %t54, %"std/prelude/map:Map<I64, Bool>" %t55, 8
  %t57 = load %"std/prelude/list:List<I64>", ptr %l12
  %t58 = insertvalue %"compiler/interp:Exec" %t56, %"std/prelude/list:List<I64>" %t57, 9
  %t59 = load %"std/prelude/map:Map<I64, Bool>", ptr %l13
  %t60 = insertvalue %"compiler/interp:Exec" %t58, %"std/prelude/map:Map<I64, Bool>" %t59, 10
  %t61 = load i1, ptr %l14
  %t62 = insertvalue %"compiler/interp:Exec" %t60, i1 %t61, 11
  store %"compiler/interp:Exec" %t62, ptr %l31
  call void @__olang_scope_close(ptr %s0)
  %t63 = load %"compiler/interp:Exec", ptr %l31
  store %"compiler/interp:Exec" %t63, ptr %out
  br label %ret
ret:
  ret void
}

@.d0 = private constant [53 x i8] c"it reaches unreachable code, which aborts the program"
declare void @__olang_scope_close(ptr)
@.d1 = private constant [50 x i8] c"an assertion in it fails, which aborts the program"
@.d2 = private constant [48 x i8] c"it slices out of range, which aborts the program"
@.d3 = private constant [68 x i8] c"it makes an array of a length out of range, which aborts the program"
@.d4 = private constant [81 x i8] c"it copies an array of another length into fixed storage, which aborts the program"
@.d5 = private constant [45 x i8] c"an 'as' that does not hold aborts the program"
@.d6 = private constant [44 x i8] c"an error reaches '!', which ends the program"
@.d7 = private constant [39 x i8] c"an error leaves the test, which ends it"
@.d8 = private constant [31 x i8] c"it ends the test or the process"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %l0
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %rv
  ret %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %rr
}

declare ptr @__olang_scope_alloc_a(ptr, i64, i64)
define linkonce_odr %"std/prelude/map:Map<std/prelude/text:String&, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<std/prelude/text:String&, I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<std/prelude/text:String&, I64>" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %l0
  store %"std/prelude/map:Map<std/prelude/text:String&, I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<std/prelude/text:String&, I64>", ptr %rv
  ret %"std/prelude/map:Map<std/prelude/text:String&, I64>" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr)
@.c9 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:159: reached unreachable code\0A\00"
@.c10 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:164: array length out of range\0A\00"
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.c11 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:166: reached unreachable code\0A\00"
@.d12 = private constant [0 x i8] c""
@.d13 = private constant [23 x i8] c"an error escapes, code "
declare void @__olang_sb_put(ptr, ptr, i64)
declare ptr @__olang_sb_room(ptr, i64)
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
@.d14 = private constant [0 x i8] c""
@.d15 = private constant [0 x i8] c""
@.d16 = private constant [2 x i8] c": "
@.d17 = private constant [2 x i8] c": "
@.d18 = private constant [2 x i8] c": "
@.d19 = private constant [2 x i8] c": "
@.c20 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:443: reached unreachable code\0A\00"
@.c21 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:238: array length out of range\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eI64(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l2
  %t3 = load ptr, ptr %l1
  %t4 = load i64, ptr %t3
  store i64 %t4, ptr %l3
  %t5 = load i64, ptr %l2
  %t6 = load i64, ptr %l3
  %t7 = icmp eq i64 %t5, %t6
  store i1 %t7, ptr %l4
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i1, ptr %l4
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aExitKind(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2
  %t1 = load ptr, ptr %l0
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3
  %t4 = load ptr, ptr %l1
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4
  %t7 = load i64, ptr %l3
  %t8 = load i64, ptr %l4
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2
  %t1 = load ptr, ptr %l0
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2
  store i32 %t3, ptr %l3
  %t4 = load ptr, ptr %l1
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5
  store i32 %t6, ptr %l4
  %t7 = load i32, ptr %l3
  %t8 = load i32, ptr %l4
  %t9 = icmp eq i32 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l6
  %t14 = load ptr, ptr %l1
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l7
  %t17 = load i32, ptr %l6
  %t18 = load i32, ptr %l7
  %t19 = icmp eq i32 %t17, %t18
  store i1 %t19, ptr %l8
  %t20 = load i1, ptr %l8
  br i1 %t20, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l2
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<I64>", ptr %l0
  store %"std/prelude/list:List<I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<I64>", ptr %rv
  ret %"std/prelude/list:List<I64>" %rr
}

@.d22 = private constant [4 x i8] c"main"
@.c23 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:387: reached unreachable code\0A\00"
@.c24 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:470: reached unreachable code\0A\00"
@.c25 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:471: reached unreachable code\0A\00"
@.c26 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:247: array length out of range\0A\00"
define linkonce_odr %"std/prelude/list:List<compiler/mir:FnKey>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/mir:FnKey>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/mir:FnKey>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/mir:FnKey>" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/mir:FnKey>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/mir:FnKey>", ptr %l0
  store %"std/prelude/list:List<compiler/mir:FnKey>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/mir:FnKey>", ptr %rv
  ret %"std/prelude/list:List<compiler/mir:FnKey>" %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3aMode(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2
  %t1 = load ptr, ptr %l0
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3
  %t4 = load ptr, ptr %l1
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4
  %t7 = load i64, ptr %l3
  %t8 = load i64, ptr %l4
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c27 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:323: reached unreachable code\0A\00"
@.d28 = private constant [8 x i8] c"no main\0A"
@.c29 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:520: array length out of range\0A\00"
@.d30 = private constant [1 x i8] c"\0A"
@.d31 = private constant [17 x i8] c"olang interpret: "
@.d32 = private constant [1 x i8] c"\0A"
@.d33 = private constant [1 x i8] c"\0A"
@.c34 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:521: reached unreachable code\0A\00"
@.d35 = private constant [17 x i8] c"unhandled error: "
@.d36 = private constant [31 x i8] c" - here in the task spawned at "
@.c37 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:543: reached unreachable code\0A\00"
@.d38 = private constant [0 x i8] c""
@.c39 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:229: array length out of range\0A\00"
@.d40 = private constant [0 x i8] c""
@.d41 = private constant [1 x i8] c"("
@.d42 = private constant [26 x i8] c" earlier places not kept)\0A"
@.d43 = private constant [11 x i8] c"raised here"
@.d44 = private constant [16 x i8] c"try passed it on"
@.d45 = private constant [40 x i8] c"a task failed, and its join passed it on"
@.d46 = private constant [2 x i8] c": "
@.d47 = private constant [1 x i8] c"\0A"
@.c48 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:367: reached unreachable code\0A\00"
@.d49 = private constant [6 x i8] c"error "
@.d50 = private constant [1 x i8] c"."
@.d51 = private constant [1 x i8] c"/"
@.c52 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:585: slice bounds out of range\0A\00"
@.d53 = private constant [1 x i8] c"."
@.d54 = private constant [1 x i8] c"."
@.c55 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:346: reached unreachable code\0A\00"
@.c56 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:347: reached unreachable code\0A\00"
@.c57 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:348: reached unreachable code\0A\00"
@.c58 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:349: reached unreachable code\0A\00"
@.c59 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:350: reached unreachable code\0A\00"
@.c60 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:276: reached unreachable code\0A\00"
@.c61 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:289: reached unreachable code\0A\00"
@.c62 = private unnamed_addr constant [52 x i8] c"compiler/interp.olang:67: reached unreachable code\0A\00"
@.c63 = private unnamed_addr constant [52 x i8] c"compiler/interp.olang:77: reached unreachable code\0A\00"
@.c64 = private unnamed_addr constant [52 x i8] c"compiler/interp.olang:88: reached unreachable code\0A\00"
@.c65 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:122: reached unreachable code\0A\00"
@.c66 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:295: reached unreachable code\0A\00"
@.d67 = private constant [1 x i8] c":"
@.c68 = private unnamed_addr constant [54 x i8] c"compiler/interp.olang:460: slice bounds out of range\0A\00"
@.c69 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:589: reached unreachable code\0A\00"
@.c70 = private unnamed_addr constant [53 x i8] c"compiler/interp.olang:307: reached unreachable code\0A\00"
define linkonce_odr %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<compiler/mir:FnKey, Bool>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<compiler/mir:FnKey, Bool>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", ptr %l0
  store %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", ptr %rv
  ret %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" %rr
}

define linkonce_odr %"std/prelude/map:Map<compiler/types:TypeId, I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<compiler/types:TypeId, I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<compiler/types:TypeId, I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<compiler/types:TypeId, I64>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<compiler/types:TypeId, I64>", ptr %l0
  store %"std/prelude/map:Map<compiler/types:TypeId, I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<compiler/types:TypeId, I64>", ptr %rv
  ret %"std/prelude/map:Map<compiler/types:TypeId, I64>" %rr
}

define linkonce_odr %"std/prelude/map:Map<I64, Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<I64, Bool>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<I64, Bool>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<I64, Bool>" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<I64, Bool>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<I64, Bool>", ptr %l0
  store %"std/prelude/map:Map<I64, Bool>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<I64, Bool>", ptr %rv
  ret %"std/prelude/map:Map<I64, Bool>" %rr
}

declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare %"compiler/names:Resolver" @compiler_2fnames_3aResolver_2ector(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_3aProgram_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_3aChecker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eL_H74c4c659bc848d1046c0a3f6eab69368(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eR_H23a25d26bcb7a81e9bb7522f4174946e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair<I64, I64>" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair<I64, I64>" %a1)
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eBoolT = external global i32
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair<I64, I64>" %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@G_2ecompiler_2fload_2eNoBranch = external global i64
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare { i32, { i64, [1 x i64] } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePop_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2feval_2eWhyWaits = external global { i64, ptr }
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eRunFrom_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eRunFrom_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %a0, i32 %a1, { i64, [1 x i64] } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = external global i32
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i1 %a4, { i64, [1 x i64] } %a5)
declare %"std/prelude/list:List<std/pair:Pair<I64, I32>>" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_H19ac89f3ce4c777c1c093c5956529937(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aConstAsk_3e_2e_H7246041139e13b84a5c0718a267d329f(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eRunFrom_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aConstAsk_3e_2e_H3755acdd817c9ece2266e75be7a7be94(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_H2d785e59a328798ef633c598d7682c46(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fviews_3aViewer_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List<mut compiler/typed:Body&>" %a1)
declare void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List<mut compiler/typed:Body&>" %a1)
declare void @compiler_2feval_2eNewMachine(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<std/prelude/text:String&, I64>" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/mir:FnKey>" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<compiler/mir:FnKey, Bool>" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<compiler/types:TypeId, I64>" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<I64, Bool>" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
