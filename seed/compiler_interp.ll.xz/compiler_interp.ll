; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/interp:CondErr" = type { { i64, [3 x i64] }, %"compiler/msgs:Msg" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" = type { i64, %"compiler/source:Span" }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] }, i1, { i64, [3 x i64] } }
%"compiler/interp:chained" = type { i64, i1, { i64, ptr }, { i64, [3 x i64] } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:UnrollAsk" = type { { i64, ptr }, { i64, ptr }, i64, i32 }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/generic:ConstAsk" = type { i64, ptr, i32, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/check:TopAssertAsk" = type { i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/views:Viewer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
define dso_local { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t3 = trunc i64 3 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb4:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t8 = trunc i64 4 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb8:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t13 = trunc i64 5 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb12:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t18 = trunc i64 6 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb16:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t23 = trunc i64 7 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb20:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t28 = trunc i64 8 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb24:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t33 = trunc i64 10 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb28:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t38 = trunc i64 11 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb32:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t43 = trunc i64 9 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb36:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t48 = trunc i64 12 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb40:
  %t51 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t53 = trunc i64 13 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb44:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 15}
  %t58 = trunc i64 14 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_eb3df5da8012cb63_283e587d4f698dd7)
  unreachable
bb53:
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %lp10 = alloca ptr
  %lp11 = alloca ptr
  %lp12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/interp:CondErr"
  %l16 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i64
  %l27 = alloca %"compiler/names:Resolver"
  %l31 = alloca %"compiler/generic:Program"
  %l38 = alloca %"compiler/check:Checker"
  %l51 = alloca i64
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/interp:CondErr"
  %l66 = alloca i64
  %l71 = alloca i64
  %l75 = alloca %"compiler/check:Checker"
  %s0 = alloca %olang.scope
  %t35 = alloca %"compiler/names:Resolver", align 8
  %t43 = alloca %"compiler/generic:Program", align 8
  %t70 = alloca %"compiler/check:Checker", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l17
  br label %bb2
bb2:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t8 = load ptr, ptr %lp3
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %t8
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l18
  br label %bb3
bb3:
  %t10 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t10, ptr %lp4
  %t11 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  %t12 = load ptr, ptr %lp4
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %t12
  %t13 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hfa18c4028fc14c940207bea2352eb53b(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l19
  br label %bb4
bb4:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t14, ptr %lp5
  %t15 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t16 = load ptr, ptr %lp5
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %t16
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cI64_3e_26_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l20
  br label %bb5
bb5:
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t18, ptr %lp6
  %t19 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  %t20 = load ptr, ptr %lp6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %t20
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l21
  br label %bb6
bb6:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t22, ptr %lp7
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  %t24 = load ptr, ptr %lp7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %t24
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l22
  br label %bb7
bb7:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l8
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/load:Loader", ptr %t27, i32 0, i32 4
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l25
  br label %bb9
bb9:
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l9, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_3aResolver_2ector(ptr %t35, ptr %v0, ptr %v1, ptr %t34)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t35, i64 200, i1 false)
  br label %bb10
bb10:
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 200, i64 8)
  store ptr %t37, ptr %lp10
  %t38 = load ptr, ptr %lp10
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %l27, i64 200, i1 false)
  %t39 = load ptr, ptr %lp10
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v1, ptr %t39)
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %lp10
  call void @compiler_2fgeneric_3aProgram_2ector(ptr %t43, ptr %v0, ptr %v1, ptr %v1, ptr %t41, ptr %t42)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t43, i64 688, i1 false)
  br label %bb12
bb12:
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 688, i64 8)
  store ptr %t46, ptr %lp11
  %t47 = load ptr, ptr %lp11
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %l31, i64 688, i1 false)
  %t48 = load ptr, ptr %lp4
  %t49 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t48
  %t51 = load ptr, ptr %lp11
  %t52 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 40
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %t52
  %t53 = load ptr, ptr %lp5
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t53
  %t56 = load ptr, ptr %lp11
  %t57 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 42
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t57
  %t58 = load ptr, ptr %lp6
  %t59 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t58
  %t61 = load ptr, ptr %lp11
  %t62 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 43
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %t62
  %t63 = load ptr, ptr %lp7
  %t64 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t63
  %t66 = load ptr, ptr %lp11
  %t67 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %t67
  %t68 = load ptr, ptr %lp11
  call void @compiler_2fcheck_3aChecker_2ector(ptr %t70, ptr %v1, ptr %v1, ptr %t68, i1 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t70, i64 984, i1 false)
  br label %bb13
bb13:
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 984, i64 8)
  store ptr %t73, ptr %lp12
  %t74 = load ptr, ptr %lp12
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %l38, i64 984, i1 false)
  %t75 = load ptr, ptr %lp2
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t75
  %t78 = load ptr, ptr %lp12
  %t79 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 79
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t79
  %t80 = load ptr, ptr %lp3
  %t81 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t80
  %t83 = load ptr, ptr %lp12
  %t84 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 117
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %t84
  %t85 = load ptr, ptr %lp12
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v1, ptr %t85)
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %lp12
  %t89 = load ptr, ptr %lp2
  %t90 = load ptr, ptr %lp3
  %t91 = load ptr, ptr %lp4
  %t92 = load ptr, ptr %lp5
  %t93 = load ptr, ptr %lp6
  %t94 = load ptr, ptr %lp7
  %t104 = call i64 @compiler_2finterp_2edecide(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %s0, ptr %t87, ptr %t88, ptr %t89, ptr %t90, ptr %t91, ptr %t92, ptr %t93, ptr %t94, ptr %l8)
  store i64 %t104, ptr %l51
  br label %bb15
bb15:
  %t105 = load i64, ptr %l51, !tbaa !24
  %t106 = icmp eq i64 %t105, 0
  br i1 %t106, label %bb16, label %bb17
bb16:
  store ptr %l8, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb18
bb17:
  br label %bb32
bb18:
  %t109 = load i64, ptr %l14, !tbaa !24
  store i64 %t109, ptr %l54, !tbaa !24
  %t110 = load ptr, ptr %l13, !tbaa !29
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2eLen_3ccompiler_2finterp_3aCondErr_3e(ptr %s0, ptr %t110)
  store i64 %t112, ptr %l56
  br label %bb19
bb19:
  %t113 = load i64, ptr %l54, !tbaa !24
  %t114 = load i64, ptr %l56, !tbaa !24
  %t115 = icmp slt i64 %t113, %t114
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t119 = load ptr, ptr %l13, !tbaa !29
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = call %"compiler/interp:CondErr" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2eAt_3ccompiler_2finterp_3aCondErr_3e(ptr %s0, ptr %s0, ptr %t119, i64 %t120)
  store %"compiler/interp:CondErr" %t123, ptr %l61
  br label %bb23
bb23:
  %t124 = load %"compiler/interp:CondErr", ptr %l61
  store %"compiler/interp:CondErr" %t124, ptr %l15
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/load:Loader", ptr %t125, i32 0, i32 4
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t129 = getelementptr %"compiler/interp:CondErr", ptr %l15, i32 0, i32 0
  %t130 = load { i64, [3 x i64] }, ptr %t129
  %t131 = getelementptr %"compiler/interp:CondErr", ptr %l15, i32 0, i32 1
  %t132 = load %"compiler/msgs:Msg", ptr %t131
  %t136 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t128, { i64, [3 x i64] } %t130, %"compiler/msgs:Msg" %t132)
  store i64 %t136, ptr %l66
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t137 = load i64, ptr %l14, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l14, !tbaa !24
  br label %bb18
bb26:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/load:Loader", ptr %t141, i32 0, i32 4
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t144)
  store i64 %t146, ptr %l71
  br label %bb27
bb27:
  %t147 = load i64, ptr %l9, !tbaa !24
  %t148 = load i64, ptr %l71, !tbaa !24
  %t150 = icmp eq i64 %t148, %t147
  br i1 %t150, label %bb28, label %bb29
bb28:
  %t152 = load ptr, ptr %lp12
  call void @compiler_2finterp_2ejudgeViews(ptr %v1, ptr %t152)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t154 = load ptr, ptr %lp12
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr %t154, i64 984, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l75, i64 984, i1 false)
  br label %ret
bb32:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/load:Loader", ptr %t155, i32 0, i32 4
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t158, i64 %t159)
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb8
ret:
  ret void
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l11 = alloca i32
  %lp12 = alloca ptr
  %l13 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, [5 x i64] }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l24 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l30 = alloca ptr
  %l32 = alloca i64
  %lp33 = alloca ptr
  %l34 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %lp38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca %"compiler/eval:Blob"
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %lp58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %lp65 = alloca ptr
  %lp66 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l75 = alloca { i64, i32 }
  %l76 = alloca i64
  %l77 = alloca i32
  %l78 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l79 = alloca %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba"
  %l80 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l82 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"compiler/interp:Exec"
  %l98 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca i64
  %l104 = alloca i64
  %l109 = alloca i64
  %l113 = alloca ptr
  %l124 = alloca ptr
  %l125 = alloca i1
  %l126 = alloca %"compiler/eval:Image"
  %l130 = alloca %"compiler/eval:Image"
  %l131 = alloca i32
  %l133 = alloca i1
  %l137 = alloca %"compiler/eval:Image"
  %l142 = alloca %"compiler/eval:Image"
  %l143 = alloca i32
  %l145 = alloca i1
  %l149 = alloca i1
  %l151 = alloca { i64, [5 x i64] }
  %l155 = alloca ptr
  %l158 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l159 = alloca { i64, ptr }
  %l160 = alloca i64
  %l161 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l175 = alloca i1
  %l181 = alloca ptr
  %l186 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %l193 = alloca i1
  %l195 = alloca i1
  %l197 = alloca i1
  %l199 = alloca ptr
  %l208 = alloca { i64, [3 x i64] }
  %l210 = alloca %"compiler/msgs:Msg"
  %l211 = alloca i64
  %l221 = alloca i1
  %l226 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l229 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca ptr
  %l245 = alloca { i64, [3 x i64] }
  %l247 = alloca %"compiler/msgs:Msg"
  %l248 = alloca i64
  %l261 = alloca i1
  %l267 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l270 = alloca i1
  %l276 = alloca ptr
  %l286 = alloca ptr
  %l287 = alloca { i64, [3 x i64] }
  %l289 = alloca { i64, ptr }
  %l290 = alloca %"compiler/msgs:Msg"
  %l291 = alloca i64
  %l296 = alloca i1
  %l301 = alloca i64
  %l308 = alloca i64
  %l310 = alloca ptr
  %l311 = alloca i64
  %l317 = alloca { i64, [3 x i64] }
  %l318 = alloca %"compiler/msgs:Msg"
  %l324 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l327 = alloca i64
  %l329 = alloca i64
  %l334 = alloca i64
  %l335 = alloca %"compiler/eval:Image"
  %l338 = alloca %"compiler/eval:Image"
  %l339 = alloca i32
  %l343 = alloca ptr
  %l344 = alloca i64
  %l346 = alloca i64
  %l351 = alloca i64
  %l355 = alloca i64
  %l358 = alloca i64
  %l378 = alloca i64
  %l381 = alloca i1
  %l384 = alloca i1
  %l385 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l388 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l389 = alloca i32
  %l390 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l394 = alloca ptr
  %l395 = alloca i64
  %l405 = alloca i64
  %l407 = alloca i64
  %l412 = alloca %"compiler/eval:Blob"
  %l414 = alloca i64
  %l416 = alloca i64
  %l421 = alloca i64
  %l424 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l427 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l428 = alloca i32
  %l429 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l432 = alloca i1
  %l436 = alloca ptr
  %l437 = alloca i64
  %l448 = alloca i1
  %l449 = alloca %"compiler/eval:Image"
  %l452 = alloca i64
  %l456 = alloca i64
  %l459 = alloca i64
  %l482 = alloca %"compiler/eval:Blob"
  %l483 = alloca %"compiler/eval:Blob"
  %l488 = alloca i64
  %l492 = alloca i64
  %l495 = alloca i64
  %l513 = alloca ptr
  %l516 = alloca i64
  %l517 = alloca ptr
  %l520 = alloca i64
  %l523 = alloca i64
  %l525 = alloca i64
  %l528 = alloca i64
  %l529 = alloca ptr
  %l532 = alloca i64
  %l533 = alloca i64
  %l536 = alloca i64
  %l538 = alloca i1
  %l541 = alloca i64
  %l544 = alloca ptr
  %l547 = alloca i64
  %l550 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l553 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l554 = alloca i32
  %l555 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l559 = alloca ptr
  %l560 = alloca { i64, i32 }
  %l576 = alloca ptr
  %l579 = alloca i64
  %l580 = alloca ptr
  %l583 = alloca i64
  %l587 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l597 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l598 = alloca %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba"
  %l600 = alloca %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba"
  %l601 = alloca i32
  %l603 = alloca i1
  %l606 = alloca i1
  %l607 = alloca i1
  %l611 = alloca i1
  %l615 = alloca ptr
  %l616 = alloca { i64, ptr }
  %l619 = alloca { i64, ptr }
  %l620 = alloca i32
  %l622 = alloca i1
  %l623 = alloca ptr
  %l630 = alloca { i64, [3 x i64] }
  %l632 = alloca %"compiler/msgs:Msg"
  %l633 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %t13 = alloca %"compiler/interp:Exec", align 8
  %t304 = alloca { i64, [3 x i64] }, align 8
  %t397 = alloca { i64, [3 x i64] }, align 8
  %t496 = alloca { i64, [3 x i64] }, align 8
  %t570 = alloca { i64, [3 x i64] }, align 8
  %t657 = alloca i64
  %t1293 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l82
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 12
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t11
  call void @compiler_2finterp_3aExec_2ector(ptr %t13, ptr %v0, ptr %v0, ptr %v0, ptr %t8, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t13, i64 992, i1 false)
  br label %bb2
bb2:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %l88, i64 992, i1 false)
  store ptr %t17, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 112
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t22
  %t26 = getelementptr %"compiler/interp:Exec", ptr %t19, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %t26
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t27)
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/load:Loader", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l98
  br label %bb4
bb4:
  %t41 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l4
  %t42 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l99
  br label %bb5
bb5:
  %t43 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l5
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/interp:Exec", ptr %t44, i32 0, i32 9
  store ptr %t46, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  %t48 = load i64, ptr %l7, !tbaa !24
  store i64 %t48, ptr %l102, !tbaa !24
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t49)
  store i64 %t51, ptr %l104
  br label %bb7
bb7:
  %t52 = load i64, ptr %l102, !tbaa !24
  %t53 = load i64, ptr %l104, !tbaa !24
  %t54 = icmp slt i64 %t52, %t53
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb8, label %bb9
bb8:
  br label %bb117
bb9:
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t58, i64 %t59)
  store i64 %t62, ptr %l109
  br label %bb11
bb11:
  %t63 = load i64, ptr %l109, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/interp:Exec", ptr %t64, i32 0, i32 1
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l113
  br label %bb12
bb12:
  %t71 = load ptr, ptr %l113, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 1
  %t74 = load { i64, [2 x i64] }, ptr %t73
  store { i64, [2 x i64] } %t74, ptr %l9
  %t76 = load { i64, [2 x i64] }, ptr %l9
  %t78 = extractvalue { i64, [2 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 6
  br i1 %t79, label %bb13, label %bb14
bb13:
  %t81 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t82 = getelementptr { i64, i32 }, ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t86 = getelementptr { i64, i32 }, ptr %t85, i32 0, i32 1
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l11, !tbaa !23
  br label %bb15
bb14:
  br label %bb110
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i32, ptr %l11, !tbaa !23
  %t98 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t92, i64 %t93, i32 %t94)
  store ptr %t98, ptr %l124
  br label %bb16
bb16:
  %t99 = load ptr, ptr %l124, !tbaa !29
  %t100 = call i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %t99)
  store i1 %t100, ptr %l125
  br label %bb17
bb17:
  %t101 = load i1, ptr %l125, !tbaa !21
  br i1 %t101, label %bb18, label %bb19
bb18:
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t103 = load i64, ptr %l10, !tbaa !24
  %t104 = load i32, ptr %l11, !tbaa !23
  %t108 = call { i32, %"compiler/eval:Image" } @compiler_2finterp_2ecompiler_2finterp_3aExec_2ebakeMutable(ptr %v0, ptr %v1, ptr %t102, i64 %t103, i32 %t104)
  %t109 = extractvalue { i32, %"compiler/eval:Image" } %t108, 1
  %t110 = extractvalue { i32, %"compiler/eval:Image" } %t108, 0
  store i32 %t110, ptr %l131
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb21, label %ok.112, !prof !99
ok.112:
  store %"compiler/eval:Image" %t109, ptr %l130
  br label %bb20
bb19:
  br label %bb25
bb20:
  %t113 = load %"compiler/eval:Image", ptr %l130
  store %"compiler/eval:Image" %t113, ptr %l126
  br label %bb23
bb21:
  %t114 = load i32, ptr %l131, !tbaa !23
  %t115 = ashr i32 %t114, 16
  %t117 = icmp eq i32 %t115, 1
  store i1 %t117, ptr %l133, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  br label %bb116
bb23:
  %t118 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store ptr %t118, ptr %lp12
  %t119 = load %"compiler/eval:Image", ptr %l126
  %t120 = load ptr, ptr %lp12
  store %"compiler/eval:Image" %t119, ptr %t120
  %t121 = load ptr, ptr %lp1
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load ptr, ptr %lp12
  %t124 = load %"compiler/eval:Image", ptr %t123
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v1, ptr %v1, ptr %t121, i64 %t122, %"compiler/eval:Image" %t124)
  br label %bb24
bb24:
  br label %bb116
bb25:
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t130 = getelementptr %"compiler/interp:Exec", ptr %t128, i32 0, i32 4
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i32, ptr %l11, !tbaa !23
  %t136 = call { i32, %"compiler/eval:Image" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eImage(ptr %v0, ptr %v1, ptr %t130, i64 %t131, i32 %t132, i1 false)
  %t137 = extractvalue { i32, %"compiler/eval:Image" } %t136, 1
  %t138 = extractvalue { i32, %"compiler/eval:Image" } %t136, 0
  store i32 %t138, ptr %l143
  %t139 = icmp ne i32 %t138, 0
  br i1 %t139, label %bb27, label %ok.140, !prof !99
ok.140:
  store %"compiler/eval:Image" %t137, ptr %l142
  br label %bb26
bb26:
  %t141 = load %"compiler/eval:Image", ptr %l142
  store %"compiler/eval:Image" %t141, ptr %l137
  br label %bb108
bb27:
  %t142 = load i32, ptr %l143, !tbaa !23
  %t143 = ashr i32 %t142, 16
  %t145 = icmp eq i32 %t143, 1
  store i1 %t145, ptr %l145, !tbaa !21
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 108
  %t149 = load i64, ptr %l8, !tbaa !24
  %t152 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_Hcc4dae5da0ed3c5355f9c78c0e71655b(ptr %v0, ptr %t148, i64 %t149)
  store i1 %t152, ptr %l149
  br label %bb29
bb29:
  %t153 = load i1, ptr %l149, !tbaa !21
  br i1 %t153, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t154 = load ptr, ptr %l2, !tbaa !29
  %t156 = getelementptr %"compiler/interp:Exec", ptr %t154, i32 0, i32 4
  %t157 = getelementptr %"compiler/eval:Machine", ptr %t156, i32 0, i32 12
  %t158 = load { i64, [5 x i64] }, ptr %t157
  store { i64, [5 x i64] } %t158, ptr %l151
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/interp:Exec", ptr %t159, i32 0, i32 1
  %t162 = load i64, ptr %l8, !tbaa !24
  %t165 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t161, i64 %t162)
  store ptr %t165, ptr %l155
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t166 = load ptr, ptr %l155, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Body", ptr %t166, i32 0, i32 4
  %t169 = load %"compiler/source:Span", ptr %t168
  %t170 = load { i64, [5 x i64] }, ptr %l151
  %t172 = call { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %s7, { i64, [5 x i64] } %t170, %"compiler/source:Span" %t169)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t172, ptr %l158
  br label %bb33
bb33:
  %t173 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l158
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t173, ptr %l13
  %t174 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l159, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  store i64 %t177, ptr %l160, !tbaa !24
  %t178 = load i64, ptr %l160, !tbaa !24
  %t179 = mul i64 %t178, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l161, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l160, !tbaa !24
  %t188 = mul i64 %t187, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  %t189 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t190 = load i64, ptr %l8, !tbaa !24
  %t193 = extractvalue { i64, ptr } %t189, 1
  %t194 = extractvalue { i64, ptr } %t189, 0
  %t195 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t193, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = extractvalue { i64, ptr } %t197, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %s0, ptr %s0, ptr %l5, i64 %t190, { i64, ptr } %t204)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb116
bb35:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t212 = load i64, ptr %l10, !tbaa !24
  %t213 = load i32, ptr %l11, !tbaa !23
  %t217 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t211, i64 %t212, i32 %t213)
  store ptr %t217, ptr %l171
  br label %bb36
bb36:
  %t218 = load ptr, ptr %l171, !tbaa !29
  store ptr %t218, ptr %l15, !tbaa !29
  %t219 = load ptr, ptr %l15, !tbaa !29
  %t221 = icmp eq ptr %t219, null
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb37, label %bb38
bb37:
  %t225 = load ptr, ptr %l15, !tbaa !29
  %t227 = getelementptr %"compiler/ast:VarDecl", ptr %t225, i32 0, i32 7
  %t228 = load i1, ptr %t227, !tbaa !21
  store i1 %t228, ptr %l175, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb39
bb39:
  %t230 = load i1, ptr %l175, !tbaa !21
  br i1 %t230, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s9
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t233 = getelementptr %"compiler/interp:Exec", ptr %t231, i32 0, i32 1
  %t234 = load i64, ptr %l8, !tbaa !24
  %t237 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t233, i64 %t234)
  store ptr %t237, ptr %l181
  br label %bb42
bb41:
  br label %bb54
bb42:
  %t238 = load ptr, ptr %l181, !tbaa !29
  store ptr %t238, ptr %l16, !tbaa !29
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t241 = getelementptr %"compiler/interp:Exec", ptr %t239, i32 0, i32 4
  %t242 = getelementptr %"compiler/eval:Machine", ptr %t241, i32 0, i32 12
  %t243 = load { i64, [5 x i64] }, ptr %t242
  %t244 = load ptr, ptr %l16, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Body", ptr %t244, i32 0, i32 4
  %t247 = load %"compiler/source:Span", ptr %t246
  %t250 = call { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %s9, { i64, [5 x i64] } %t243, %"compiler/source:Span" %t247)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t250, ptr %l186
  br label %bb43
bb43:
  %t251 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l186
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t251, ptr %l17
  %t252 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l17, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l187, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  store i64 %t255, ptr %l188, !tbaa !24
  %t256 = load i64, ptr %l188, !tbaa !24
  %t257 = mul i64 %t256, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t257)
  %t259 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  store { i64, ptr } %t260, ptr %l189, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = load i64, ptr %l188, !tbaa !24
  %t266 = mul i64 %t265, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t262, ptr %t264, i64 %t266, i1 false)
  %t267 = load { i64, ptr }, ptr %l189, !tbaa !27
  store { i64, ptr } %t267, ptr %l18, !tbaa !27
  %t268 = load ptr, ptr %l2, !tbaa !29
  %t270 = getelementptr %"compiler/interp:Exec", ptr %t268, i32 0, i32 10
  %t271 = load i64, ptr %l8, !tbaa !24
  %t274 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t270, i64 %t271)
  store i1 %t274, ptr %l193
  br label %bb44
bb44:
  %t275 = load i1, ptr %l193, !tbaa !21
  %t276 = xor i1 %t275, true
  br i1 %t276, label %bb45, label %bb46
bb45:
  %t278 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s9, { i64, ptr } %t278, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t280, ptr %l197
  br label %bb47
bb46:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb48
bb47:
  %t281 = load i1, ptr %l197, !tbaa !21
  %t282 = xor i1 %t281, true
  store i1 %t282, ptr %l195, !tbaa !21
  br label %bb48
bb48:
  %t284 = load i1, ptr %l195, !tbaa !21
  br i1 %t284, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t285 = load ptr, ptr %l3, !tbaa !29
  store ptr %t285, ptr %l199, !tbaa !29
  %t286 = load ptr, ptr %l16, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Body", ptr %t286, i32 0, i32 3
  %t289 = load i64, ptr %t288, !tbaa !24
  %t290 = load ptr, ptr %l16, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Body", ptr %t290, i32 0, i32 4
  %t293 = getelementptr %"compiler/source:Span", ptr %t292, i32 0, i32 0
  %t294 = load i32, ptr %t293, !tbaa !23
  %t296 = sext i32 %t294 to i64
  %t297 = load ptr, ptr %l16, !tbaa !29
  %t299 = getelementptr %"compiler/typed:Body", ptr %t297, i32 0, i32 4
  %t300 = getelementptr %"compiler/source:Span", ptr %t299, i32 0, i32 1
  %t301 = load i32, ptr %t300, !tbaa !23
  %t303 = sext i32 %t301 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t304
  %t305 = getelementptr { i64, [3 x i64] }, ptr %t304, i32 0, i32 0
  store i64 3, ptr %t305
  %t307 = insertvalue { i64, i64, i64 } undef, i64 %t289, 0
  %t309 = insertvalue { i64, i64, i64 } %t307, i64 %t296, 1
  %t311 = insertvalue { i64, i64, i64 } %t309, i64 %t303, 2
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t304, i32 0, i32 1
  store { i64, i64, i64 } %t311, ptr %t312
  %t313 = load { i64, [3 x i64] }, ptr %t304
  store { i64, [3 x i64] } %t313, ptr %l208
  %t314 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t316 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrNotBuilt(ptr %s9, ptr %s10, { i64, ptr } %t314)
  store %"compiler/msgs:Msg" %t316, ptr %l210
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t317 = load ptr, ptr %l199, !tbaa !29
  %t318 = load { i64, [3 x i64] }, ptr %l208
  %t319 = load %"compiler/msgs:Msg", ptr %l210
  %t320 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t317, { i64, [3 x i64] } %t318, %"compiler/msgs:Msg" %t319)
  store i64 %t320, ptr %l211
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s10)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb116
bb54:
  %t321 = load ptr, ptr %l2, !tbaa !29
  %t323 = getelementptr %"compiler/interp:Exec", ptr %t321, i32 0, i32 4
  %t324 = getelementptr %"compiler/eval:Machine", ptr %t323, i32 0, i32 12
  %t325 = load { i64, [5 x i64] }, ptr %t324
  store { i64, [5 x i64] } %t325, ptr %l19
  %t327 = load { i64, [5 x i64] }, ptr %l19
  %t329 = extractvalue { i64, [5 x i64] } %t327, 0
  %t330 = icmp eq i64 %t329, 3
  br i1 %t330, label %bb55, label %bb56
bb55:
  %t332 = getelementptr { i64, [5 x i64] }, ptr %l19, i32 0, i32 1
  %t333 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t332, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333
  store { i64, ptr } %t334, ptr %l20, !tbaa !27
  %t336 = getelementptr { i64, [5 x i64] }, ptr %l19, i32 0, i32 1
  %t337 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t336, i32 0, i32 1
  %t338 = load i64, ptr %t337
  store i64 %t338, ptr %l21, !tbaa !24
  %t340 = getelementptr { i64, [5 x i64] }, ptr %l19, i32 0, i32 1
  %t341 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t340, i32 0, i32 2
  %t342 = load %"compiler/source:Span", ptr %t341
  store %"compiler/source:Span" %t342, ptr %l22
  br label %bb57
bb56:
  br label %bb72
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  %t344 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t345 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t346 = load ptr, ptr @__olang_prog_scope
  %t349 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t346, { i64, ptr } %t344, { i64, ptr } %t345)
  store i1 %t349, ptr %l221
  br label %bb58
bb58:
  %t350 = load i1, ptr %l221, !tbaa !21
  %t351 = xor i1 %t350, true
  br i1 %t351, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb116
bb60:
  br label %bb61
bb61:
  %t353 = load i64, ptr %l21, !tbaa !24
  %t354 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 0
  %t355 = load i32, ptr %t354, !tbaa !23
  %t357 = sext i32 %t355 to i64
  %t360 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s11, i64 %t353, i64 %t357)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t360, ptr %l226
  br label %bb62
bb62:
  %t361 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l226
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t361, ptr %l23
  %t362 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l23
  %t365 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t362)
  store i1 %t365, ptr %l229
  br label %bb63
bb63:
  %t366 = load i1, ptr %l229, !tbaa !21
  br i1 %t366, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb116
bb65:
  br label %bb66
bb66:
  %t367 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t367, i1 true)
  br label %bb67
bb67:
  %t370 = load ptr, ptr %l2, !tbaa !29
  %t372 = getelementptr %"compiler/interp:Exec", ptr %t370, i32 0, i32 1
  %t373 = load i64, ptr %l8, !tbaa !24
  %t376 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t372, i64 %t373)
  store ptr %t376, ptr %l235
  br label %bb68
bb68:
  %t377 = load ptr, ptr %l235, !tbaa !29
  store ptr %t377, ptr %l24, !tbaa !29
  %t378 = load ptr, ptr %l3, !tbaa !29
  store ptr %t378, ptr %l236, !tbaa !29
  %t379 = load ptr, ptr %l24, !tbaa !29
  %t381 = getelementptr %"compiler/typed:Body", ptr %t379, i32 0, i32 3
  %t382 = load i64, ptr %t381, !tbaa !24
  %t383 = load ptr, ptr %l24, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Body", ptr %t383, i32 0, i32 4
  %t386 = getelementptr %"compiler/source:Span", ptr %t385, i32 0, i32 0
  %t387 = load i32, ptr %t386, !tbaa !23
  %t389 = sext i32 %t387 to i64
  %t390 = load ptr, ptr %l24, !tbaa !29
  %t392 = getelementptr %"compiler/typed:Body", ptr %t390, i32 0, i32 4
  %t393 = getelementptr %"compiler/source:Span", ptr %t392, i32 0, i32 1
  %t394 = load i32, ptr %t393, !tbaa !23
  %t396 = sext i32 %t394 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t397
  %t398 = getelementptr { i64, [3 x i64] }, ptr %t397, i32 0, i32 0
  store i64 3, ptr %t398
  %t400 = insertvalue { i64, i64, i64 } undef, i64 %t382, 0
  %t402 = insertvalue { i64, i64, i64 } %t400, i64 %t389, 1
  %t404 = insertvalue { i64, i64, i64 } %t402, i64 %t396, 2
  %t405 = getelementptr { i64, [3 x i64] }, ptr %t397, i32 0, i32 1
  store { i64, i64, i64 } %t404, ptr %t405
  %t406 = load { i64, [3 x i64] }, ptr %t397
  store { i64, [3 x i64] } %t406, ptr %l245
  %t407 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t409 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalStale(ptr %v0, ptr %s11, { i64, ptr } %t407)
  store %"compiler/msgs:Msg" %t409, ptr %l247
  br label %bb69
bb69:
  %t410 = load ptr, ptr %l236, !tbaa !29
  %t411 = load { i64, [3 x i64] }, ptr %l245
  %t412 = load %"compiler/msgs:Msg", ptr %l247
  %t413 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t410, { i64, [3 x i64] } %t411, %"compiler/msgs:Msg" %t412)
  store i64 %t413, ptr %l248
  br label %bb70
bb70:
  %t414 = load i64, ptr %l248, !tbaa !24
  %t415 = load ptr, ptr %l2, !tbaa !29
  %t416 = load ptr, ptr %l3, !tbaa !29
  %t418 = load i64, ptr %l21, !tbaa !24
  %t419 = load %"compiler/source:Span", ptr %l22
  call void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v0, ptr %t415, ptr %t416, i64 %t414, i64 %t418, %"compiler/source:Span" %t419)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb107
bb72:
  %t425 = load { i64, [5 x i64] }, ptr %l19
  %t427 = extractvalue { i64, [5 x i64] } %t425, 0
  %t428 = icmp eq i64 %t427, 2
  br i1 %t428, label %bb73, label %bb74
bb73:
  %t430 = getelementptr { i64, [5 x i64] }, ptr %l19, i32 0, i32 1
  %t431 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t430, i32 0, i32 0
  %t432 = load i32, ptr %t431, !range !{i32 0, i32 15}
  store i32 %t432, ptr %l26
  %t434 = getelementptr { i64, [5 x i64] }, ptr %l19, i32 0, i32 1
  %t435 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t434, i32 0, i32 1
  %t436 = load i64, ptr %t435
  store i64 %t436, ptr %l27, !tbaa !24
  %t438 = getelementptr { i64, [5 x i64] }, ptr %l19, i32 0, i32 1
  %t439 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t438, i32 0, i32 2
  %t440 = load %"compiler/source:Span", ptr %t439
  store %"compiler/source:Span" %t440, ptr %l28
  br label %bb75
bb74:
  br label %bb102
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t442 = load i32, ptr %l26, !range !{i32 0, i32 15}
  %t444 = trunc i64 0 to i32
  %t445 = icmp eq i32 %t442, %t444
  br i1 %t445, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l261, !tbaa !21
  br label %bb78
bb77:
  %t447 = load i32, ptr %l26, !range !{i32 0, i32 15}
  %t449 = trunc i64 1 to i32
  %t450 = icmp eq i32 %t447, %t449
  store i1 %t450, ptr %l261, !tbaa !21
  br label %bb78
bb78:
  %t452 = load i1, ptr %l261, !tbaa !21
  br i1 %t452, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb80:
  br label %bb81
bb81:
  %t453 = load i64, ptr %l27, !tbaa !24
  %t454 = getelementptr %"compiler/source:Span", ptr %l28, i32 0, i32 0
  %t455 = load i32, ptr %t454, !tbaa !23
  %t457 = sext i32 %t455 to i64
  %t460 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s14, i64 %t453, i64 %t457)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t460, ptr %l267
  br label %bb82
bb82:
  %t461 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l267
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t461, ptr %l29
  %t462 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l29
  %t465 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t462)
  store i1 %t465, ptr %l270
  br label %bb83
bb83:
  %t466 = load i1, ptr %l270, !tbaa !21
  br i1 %t466, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb85:
  br label %bb86
bb86:
  %t467 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l4, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t467, i1 true)
  br label %bb87
bb87:
  %t470 = load ptr, ptr %l2, !tbaa !29
  %t472 = getelementptr %"compiler/interp:Exec", ptr %t470, i32 0, i32 1
  %t473 = load i64, ptr %l8, !tbaa !24
  %t476 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t472, i64 %t473)
  store ptr %t476, ptr %l276
  br label %bb88
bb88:
  %t477 = load ptr, ptr %l276, !tbaa !29
  store ptr %t477, ptr %l30, !tbaa !29
  %t478 = load ptr, ptr %l30, !tbaa !29
  %t480 = getelementptr %"compiler/typed:Body", ptr %t478, i32 0, i32 3
  %t481 = load i64, ptr %t480, !tbaa !24
  %t482 = load ptr, ptr %l30, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Body", ptr %t482, i32 0, i32 4
  %t485 = getelementptr %"compiler/source:Span", ptr %t484, i32 0, i32 0
  %t486 = load i32, ptr %t485, !tbaa !23
  %t488 = sext i32 %t486 to i64
  %t489 = load ptr, ptr %l30, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Body", ptr %t489, i32 0, i32 4
  %t492 = getelementptr %"compiler/source:Span", ptr %t491, i32 0, i32 1
  %t493 = load i32, ptr %t492, !tbaa !23
  %t495 = sext i32 %t493 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t496
  %t497 = getelementptr { i64, [3 x i64] }, ptr %t496, i32 0, i32 0
  store i64 3, ptr %t497
  %t499 = insertvalue { i64, i64, i64 } undef, i64 %t481, 0
  %t501 = insertvalue { i64, i64, i64 } %t499, i64 %t488, 1
  %t503 = insertvalue { i64, i64, i64 } %t501, i64 %t495, 2
  %t504 = getelementptr { i64, [3 x i64] }, ptr %t496, i32 0, i32 1
  store { i64, i64, i64 } %t503, ptr %t504
  %t505 = load { i64, [3 x i64] }, ptr %t496
  %t507 = load ptr, ptr %l3, !tbaa !29
  store ptr %t507, ptr %l286, !tbaa !29
  store { i64, [3 x i64] } %t505, ptr %l287
  %t509 = load i32, ptr %l26, !range !{i32 0, i32 15}
  %t511 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s14, i32 %t509)
  store { i64, ptr } %t511, ptr %l289
  br label %bb89
bb89:
  %t512 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t513 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalAborts(ptr %s14, ptr %s14, { i64, ptr } %t512)
  store %"compiler/msgs:Msg" %t513, ptr %l290
  br label %bb90
bb90:
  %t514 = load ptr, ptr %l286, !tbaa !29
  %t515 = load { i64, [3 x i64] }, ptr %l287
  %t516 = load %"compiler/msgs:Msg", ptr %l290
  %t517 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s14, ptr %t514, { i64, [3 x i64] } %t515, %"compiler/msgs:Msg" %t516)
  store i64 %t517, ptr %l291
  br label %bb91
bb91:
  %t518 = load i64, ptr %l291, !tbaa !24
  store i64 %t518, ptr %l32, !tbaa !24
  %t519 = load i64, ptr %l27, !tbaa !24
  %t520 = load ptr, ptr %l30, !tbaa !29
  %t522 = getelementptr %"compiler/typed:Body", ptr %t520, i32 0, i32 3
  %t523 = load i64, ptr %t522, !tbaa !24
  %t526 = icmp ne i64 %t519, %t523
  br i1 %t526, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l296, !tbaa !21
  br label %bb96
bb93:
  %t528 = load ptr, ptr %l3, !tbaa !29
  %t529 = load i64, ptr %l27, !tbaa !24
  %t530 = getelementptr %"compiler/source:Span", ptr %l28, i32 0, i32 0
  %t531 = load i32, ptr %t530, !tbaa !23
  %t533 = sext i32 %t531 to i64
  %t537 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t528, i64 %t529, i64 %t533)
  store i64 %t537, ptr %l301
  br label %bb94
bb94:
  %t538 = load ptr, ptr %l3, !tbaa !29
  %t539 = load ptr, ptr %l30, !tbaa !29
  %t541 = getelementptr %"compiler/typed:Body", ptr %t539, i32 0, i32 3
  %t542 = load i64, ptr %t541, !tbaa !24
  %t543 = load ptr, ptr %l30, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Body", ptr %t543, i32 0, i32 4
  %t546 = getelementptr %"compiler/source:Span", ptr %t545, i32 0, i32 0
  %t547 = load i32, ptr %t546, !tbaa !23
  %t549 = sext i32 %t547 to i64
  %t553 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t538, i64 %t542, i64 %t549)
  store i64 %t553, ptr %l308
  br label %bb95
bb95:
  %t554 = load i64, ptr %l301, !tbaa !24
  %t555 = load i64, ptr %l308, !tbaa !24
  %t556 = icmp ne i64 %t554, %t555
  store i1 %t556, ptr %l296, !tbaa !21
  br label %bb96
bb96:
  %t558 = load i1, ptr %l296, !tbaa !21
  br i1 %t558, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s17
  %t559 = load ptr, ptr %l3, !tbaa !29
  store ptr %t559, ptr %l310, !tbaa !29
  %t560 = load i64, ptr %l32, !tbaa !24
  store i64 %t560, ptr %l311, !tbaa !24
  %t561 = load i64, ptr %l27, !tbaa !24
  %t562 = getelementptr %"compiler/source:Span", ptr %l28, i32 0, i32 0
  %t563 = load i32, ptr %t562, !tbaa !23
  %t565 = sext i32 %t563 to i64
  %t566 = getelementptr %"compiler/source:Span", ptr %l28, i32 0, i32 1
  %t567 = load i32, ptr %t566, !tbaa !23
  %t569 = sext i32 %t567 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t570
  %t571 = getelementptr { i64, [3 x i64] }, ptr %t570, i32 0, i32 0
  store i64 3, ptr %t571
  %t573 = insertvalue { i64, i64, i64 } undef, i64 %t561, 0
  %t575 = insertvalue { i64, i64, i64 } %t573, i64 %t565, 1
  %t577 = insertvalue { i64, i64, i64 } %t575, i64 %t569, 2
  %t578 = getelementptr { i64, [3 x i64] }, ptr %t570, i32 0, i32 1
  store { i64, i64, i64 } %t577, ptr %t578
  %t579 = load { i64, [3 x i64] }, ptr %t570
  store { i64, [3 x i64] } %t579, ptr %l317
  %t580 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s17)
  store %"compiler/msgs:Msg" %t580, ptr %l318
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t581 = load ptr, ptr %l310, !tbaa !29
  %t582 = load i64, ptr %l311, !tbaa !24
  %t583 = load { i64, [3 x i64] }, ptr %l317
  %t584 = load %"compiler/msgs:Msg", ptr %l318
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s17, ptr %t581, i64 %t582, { i64, [3 x i64] } %t583, %"compiler/msgs:Msg" %t584)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s17)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s14)
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_23ba8871310952f4_ff8b68d1da902468)
  unreachable
bb107:
  br label %bb116
bb108:
  %t585 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store ptr %t585, ptr %lp33
  %t586 = load %"compiler/eval:Image", ptr %l137
  %t587 = load ptr, ptr %lp33
  store %"compiler/eval:Image" %t586, ptr %t587
  %t588 = load ptr, ptr %lp1
  %t589 = load i64, ptr %l8, !tbaa !24
  %t590 = load ptr, ptr %lp33
  %t591 = load %"compiler/eval:Image", ptr %t590
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v1, ptr %v1, ptr %t588, i64 %t589, %"compiler/eval:Image" %t591)
  br label %bb109
bb109:
  br label %bb115
bb110:
  br i1 true, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_1c176b23f7e86d25_2ef9862bd1101439)
  unreachable
bb115:
  br label %bb116
bb116:
  %t595 = load i64, ptr %l7, !tbaa !24
  %t597 = add i64 %t595, 1
  store i64 %t597, ptr %l7, !tbaa !24
  br label %bb6
bb117:
  %t599 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t599, ptr %l324
  br label %bb118
bb118:
  %t600 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l324
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t600, ptr %l34
  %t601 = load ptr, ptr %l2, !tbaa !29
  %t603 = getelementptr %"compiler/interp:Exec", ptr %t601, i32 0, i32 9
  store ptr %t603, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s22
  %t605 = load i64, ptr %l36, !tbaa !24
  store i64 %t605, ptr %l327, !tbaa !24
  %t606 = load ptr, ptr %l35, !tbaa !29
  %t608 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t606)
  store i64 %t608, ptr %l329
  br label %bb120
bb120:
  %t609 = load i64, ptr %l327, !tbaa !24
  %t610 = load i64, ptr %l329, !tbaa !24
  %t611 = icmp slt i64 %t609, %t610
  %t613 = xor i1 %t611, true
  br i1 %t613, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s22)
  br label %bb277
bb122:
  br label %bb123
bb123:
  %t615 = load ptr, ptr %l35, !tbaa !29
  %t616 = load i64, ptr %l36, !tbaa !24
  %t619 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t615, i64 %t616)
  store i64 %t619, ptr %l334
  br label %bb124
bb124:
  %t620 = load i64, ptr %l334, !tbaa !24
  store i64 %t620, ptr %l37, !tbaa !24
  %t621 = load ptr, ptr %lp1
  %t622 = load i64, ptr %l37, !tbaa !24
  %t625 = call { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v1, ptr %v1, ptr %t621, i64 %t622)
  %t626 = extractvalue { i32, %"compiler/eval:Image" } %t625, 1
  %t627 = extractvalue { i32, %"compiler/eval:Image" } %t625, 0
  store i32 %t627, ptr %l339
  %t628 = icmp ne i32 %t627, 0
  br i1 %t628, label %bb126, label %ok.629, !prof !99
ok.629:
  store %"compiler/eval:Image" %t626, ptr %l338
  br label %bb125
bb125:
  %t630 = load %"compiler/eval:Image", ptr %l338
  store %"compiler/eval:Image" %t630, ptr %l335
  br label %bb128
bb126:
  br label %bb127
bb127:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb276
bb128:
  %t631 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store ptr %t631, ptr %lp38
  %t632 = load %"compiler/eval:Image", ptr %l335
  %t633 = load ptr, ptr %lp38
  store %"compiler/eval:Image" %t632, ptr %t633
  %t634 = load ptr, ptr %l2, !tbaa !29
  %t636 = getelementptr %"compiler/interp:Exec", ptr %t634, i32 0, i32 1
  %t637 = load i64, ptr %l37, !tbaa !24
  %t640 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t636, i64 %t637)
  store ptr %t640, ptr %l343
  br label %bb129
bb129:
  %t641 = load ptr, ptr %l343, !tbaa !29
  %t642 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t641)
  store i64 %t642, ptr %l344
  br label %bb130
bb130:
  %t643 = load i64, ptr %l344, !tbaa !24
  store i64 %t643, ptr %l39, !tbaa !24
  store i1 true, ptr %l40, !tbaa !21
  %t644 = load ptr, ptr %lp38
  %t645 = getelementptr %"compiler/eval:Image", ptr %t644, i32 0, i32 0
  %t647 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t645)
  store i64 %t647, ptr %l346
  br label %bb131
bb131:
  %t648 = load i64, ptr %l346, !tbaa !24
  %t649 = icmp sge i64 %t648, 0
  br i1 %t649, label %bb132, label %bb133
bb132:
  %t651 = load i64, ptr %l346, !tbaa !24
  %t652 = icmp sle i64 %t651, 1152921504606846975
  br i1 %t652, label %bb134, label %bb135
bb133:
  call void @__olang_check_failed(ptr @olang_loc_743f77b054333c1d_15e2e891552f92b9)
  unreachable
bb134:
  %t654 = load i64, ptr %l346, !tbaa !24
  %t655 = mul i64 %t654, 8
  %t656 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t655)
  store i64 0, ptr %t657
  br label %fill.658
fill.658:
  %t661 = load i64, ptr %t657
  %t662 = icmp slt i64 %t661, %t654
  br i1 %t662, label %fillb.659, label %filld.660
fillb.659:
  %t663 = getelementptr i64, ptr %t656, i64 %t661
  store i64 -1, ptr %t663
  %t664 = add i64 %t661, 1
  store i64 %t664, ptr %t657
  br label %fill.658
filld.660:
  %t665 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t666 = insertvalue { i64, ptr } %t665, ptr %t656, 1
  store { i64, ptr } %t666, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  %t668 = load ptr, ptr %lp38
  %t669 = getelementptr %"compiler/eval:Image", ptr %t668, i32 0, i32 0
  %t671 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t669)
  store i64 %t671, ptr %l351
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @olang_loc_743f77b054333c1d_15e2e891552f92b9)
  unreachable
bb136:
  %t672 = load i64, ptr %l351, !tbaa !24
  store i64 %t672, ptr %l44, !tbaa !24
  store i64 1, ptr %l45, !tbaa !24
  %t673 = load i64, ptr %l44, !tbaa !24
  %t674 = load i64, ptr %l43, !tbaa !24
  %t677 = icmp sgt i64 %t673, %t674
  br i1 %t677, label %bb137, label %bb138
bb137:
  %t679 = load i64, ptr %l45, !tbaa !24
  %t681 = icmp sgt i64 %t679, 0
  br i1 %t681, label %bb139, label %bb140
bb138:
  store i64 0, ptr %l355, !tbaa !24
  br label %bb142
bb139:
  %t683 = load i64, ptr %l44, !tbaa !24
  %t684 = load i64, ptr %l43, !tbaa !24
  %t687 = sub i64 %t683, %t684
  %t688 = load i64, ptr %l45, !tbaa !24
  %t691 = add i64 %t687, %t688
  %t693 = sub i64 %t691, 1
  %t694 = load i64, ptr %l45, !tbaa !24
  %t697 = sdiv i64 %t693, %t694
  store i64 %t697, ptr %l358, !tbaa !24
  br label %bb141
bb140:
  store i64 0, ptr %l358, !tbaa !24
  br label %bb141
bb141:
  %t699 = load i64, ptr %l358, !tbaa !24
  store i64 %t699, ptr %l355, !tbaa !24
  br label %bb142
bb142:
  %t700 = load i64, ptr %l355, !tbaa !24
  store i64 %t700, ptr %l46, !tbaa !24
  store i64 0, ptr %l47, !tbaa !24
  br label %bb143
bb143:
  %t701 = load i64, ptr %l47, !tbaa !24
  %t702 = load i64, ptr %l46, !tbaa !24
  %t705 = icmp slt i64 %t701, %t702
  %t707 = xor i1 %t705, true
  br i1 %t707, label %bb144, label %bb145
bb144:
  br label %bb166
bb145:
  br label %bb146
bb146:
  %t709 = load i64, ptr %l43, !tbaa !24
  %t710 = load i64, ptr %l47, !tbaa !24
  %t711 = load i64, ptr %l45, !tbaa !24
  %t714 = mul i64 %t710, %t711
  %t717 = add i64 %t709, %t714
  store i64 %t717, ptr %l48, !tbaa !24
  %t719 = load ptr, ptr %lp38
  %t720 = getelementptr %"compiler/eval:Image", ptr %t719, i32 0, i32 1
  %t721 = load i64, ptr %l48, !tbaa !24
  %t724 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t720, i64 %t721)
  store i64 %t724, ptr %l378
  br label %bb147
bb147:
  %t725 = load i64, ptr %l378, !tbaa !24
  store i64 %t725, ptr %l49, !tbaa !24
  %t726 = load i64, ptr %l48, !tbaa !24
  %t728 = icmp sgt i64 %t726, 0
  br i1 %t728, label %bb148, label %bb149
bb148:
  %t730 = load i64, ptr %l49, !tbaa !24
  %t733 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H3ccda5e77fabf86fda89ecfc77eff03d(ptr %s0, ptr %l34, i64 %t730)
  store i1 %t733, ptr %l384
  br label %bb150
bb149:
  store i1 false, ptr %l381, !tbaa !21
  br label %bb151
bb150:
  %t734 = load i1, ptr %l384, !tbaa !21
  store i1 %t734, ptr %l381, !tbaa !21
  br label %bb151
bb151:
  %t735 = load i1, ptr %l381, !tbaa !21
  br i1 %t735, label %bb152, label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s26
  %t736 = load i64, ptr %l49, !tbaa !24
  %t739 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l34, i64 %t736)
  %t740 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t739, 1
  %t741 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t739, 0
  store i32 %t741, ptr %l389
  %t742 = icmp ne i32 %t741, 0
  br i1 %t742, label %bb155, label %ok.743, !prof !99
ok.743:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t740, ptr %l388
  br label %bb154
bb153:
  br label %bb164
bb154:
  %t744 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l388
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t744, ptr %l385
  br label %bb158
bb155:
  br label %bb156
bb156:
  call void @__olang_ert_req_clear()
  %t745 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s26, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t745, ptr %l390
  br label %bb157
bb157:
  %t746 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l390
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t746, ptr %l385
  br label %bb158
bb158:
  %t747 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l385
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t747, ptr %l50
  %t748 = load ptr, ptr %l2, !tbaa !29
  %t750 = getelementptr %"compiler/interp:Exec", ptr %t748, i32 0, i32 1
  %t751 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l50, i32 0, i32 0
  %t752 = load i64, ptr %t751, !tbaa !24
  %t755 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t750, i64 %t752)
  store ptr %t755, ptr %l394
  br label %bb159
bb159:
  %t756 = load ptr, ptr %l394, !tbaa !29
  %t757 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t756)
  store i64 %t757, ptr %l395
  br label %bb160
bb160:
  %t758 = load i64, ptr %l39, !tbaa !24
  %t759 = load i64, ptr %l395, !tbaa !24
  %t761 = icmp ne i64 %t759, %t758
  br i1 %t761, label %bb161, label %bb162
bb161:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb163
bb162:
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s26)
  br label %bb165
bb164:
  %t763 = load i64, ptr %l48, !tbaa !24
  %t764 = load i64, ptr %l42, !tbaa !24
  %t767 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t768 = load ptr, ptr %t767, !tbaa !27
  %t769 = getelementptr i64, ptr %t768, i64 %t763
  store i64 %t764, ptr %t769, !tbaa !34
  %t770 = load i64, ptr %l42, !tbaa !24
  %t772 = add i64 %t770, 1
  store i64 %t772, ptr %l42, !tbaa !24
  br label %bb165
bb165:
  %t774 = load i64, ptr %l47, !tbaa !24
  %t776 = add i64 %t774, 1
  store i64 %t776, ptr %l47, !tbaa !24
  br label %bb143
bb166:
  %t778 = load ptr, ptr %lp38
  %t779 = getelementptr %"compiler/eval:Image", ptr %t778, i32 0, i32 0
  store ptr %t779, ptr %l51, !tbaa !29
  store i64 0, ptr %l52, !tbaa !24
  br label %bb167
bb167:
  %t781 = load i64, ptr %l52, !tbaa !24
  store i64 %t781, ptr %l405, !tbaa !24
  %t782 = load ptr, ptr %l51, !tbaa !29
  %t784 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t782)
  store i64 %t784, ptr %l407
  br label %bb168
bb168:
  %t785 = load i64, ptr %l405, !tbaa !24
  %t786 = load i64, ptr %l407, !tbaa !24
  %t787 = icmp slt i64 %t785, %t786
  %t789 = xor i1 %t787, true
  br i1 %t789, label %bb169, label %bb170
bb169:
  br label %bb198
bb170:
  br label %bb171
bb171:
  %t791 = load ptr, ptr %l51, !tbaa !29
  %t792 = load i64, ptr %l52, !tbaa !24
  %t795 = call %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t791, i64 %t792)
  store %"compiler/eval:Blob" %t795, ptr %l412
  br label %bb172
bb172:
  %t796 = load %"compiler/eval:Blob", ptr %l412
  store %"compiler/eval:Blob" %t796, ptr %l53
  %t797 = getelementptr %"compiler/eval:Blob", ptr %l53, i32 0, i32 6
  store ptr %t797, ptr %l54, !tbaa !29
  store i64 0, ptr %l55, !tbaa !24
  br label %bb173
bb173:
  store %olang.scope zeroinitializer, ptr %s32
  %t799 = load i64, ptr %l55, !tbaa !24
  store i64 %t799, ptr %l414, !tbaa !24
  %t800 = load ptr, ptr %l54, !tbaa !29
  %t802 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t800)
  store i64 %t802, ptr %l416
  br label %bb174
bb174:
  %t803 = load i64, ptr %l414, !tbaa !24
  %t804 = load i64, ptr %l416, !tbaa !24
  %t805 = icmp slt i64 %t803, %t804
  %t807 = xor i1 %t805, true
  br i1 %t807, label %bb175, label %bb176
bb175:
  call void @__olang_scope_close(ptr %s32)
  br label %bb196
bb176:
  br label %bb177
bb177:
  %t809 = load ptr, ptr %l54, !tbaa !29
  %t810 = load i64, ptr %l55, !tbaa !24
  %t813 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t809, i64 %t810)
  store i64 %t813, ptr %l421
  br label %bb178
bb178:
  %t814 = load i64, ptr %l421, !tbaa !24
  store i64 %t814, ptr %l56, !tbaa !24
  %t815 = load i64, ptr %l56, !tbaa !24
  %t817 = icmp slt i64 %t815, 0
  br i1 %t817, label %bb179, label %bb180
bb179:
  call void @__olang_scope_close(ptr %s32)
  br label %bb195
bb180:
  br label %bb181
bb181:
  %t819 = load i64, ptr %l56, !tbaa !24
  %t822 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l34, i64 %t819)
  %t823 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t822, 1
  %t824 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t822, 0
  store i32 %t824, ptr %l428
  %t825 = icmp ne i32 %t824, 0
  br i1 %t825, label %bb183, label %ok.826, !prof !99
ok.826:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t823, ptr %l427
  br label %bb182
bb182:
  %t827 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l427
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t827, ptr %l424
  br label %bb186
bb183:
  br label %bb184
bb184:
  call void @__olang_ert_req_clear()
  %t828 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s32, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t828, ptr %l429
  br label %bb185
bb185:
  %t829 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l429
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t829, ptr %l424
  br label %bb186
bb186:
  %t830 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l424
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t830, ptr %l57
  %t831 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l57, i32 0, i32 0
  %t832 = load i64, ptr %t831, !tbaa !24
  %t834 = icmp slt i64 %t832, 0
  br i1 %t834, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l432, !tbaa !21
  br label %bb191
bb188:
  %t836 = load ptr, ptr %l2, !tbaa !29
  %t838 = getelementptr %"compiler/interp:Exec", ptr %t836, i32 0, i32 1
  %t839 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l57, i32 0, i32 0
  %t840 = load i64, ptr %t839, !tbaa !24
  %t843 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t838, i64 %t840)
  store ptr %t843, ptr %l436
  br label %bb189
bb189:
  %t844 = load ptr, ptr %l436, !tbaa !29
  %t845 = call i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %t844)
  store i64 %t845, ptr %l437
  br label %bb190
bb190:
  %t846 = load i64, ptr %l39, !tbaa !24
  %t847 = load i64, ptr %l437, !tbaa !24
  %t849 = icmp ne i64 %t847, %t846
  store i1 %t849, ptr %l432, !tbaa !21
  br label %bb191
bb191:
  %t851 = load i1, ptr %l432, !tbaa !21
  br i1 %t851, label %bb192, label %bb193
bb192:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb194
bb193:
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s32)
  br label %bb195
bb195:
  %t852 = load i64, ptr %l55, !tbaa !24
  %t854 = add i64 %t852, 1
  store i64 %t854, ptr %l55, !tbaa !24
  br label %bb173
bb196:
  br label %bb197
bb197:
  %t856 = load i64, ptr %l52, !tbaa !24
  %t858 = add i64 %t856, 1
  store i64 %t858, ptr %l52, !tbaa !24
  br label %bb167
bb198:
  %t860 = load i1, ptr %l40, !tbaa !21
  %t862 = xor i1 %t860, true
  br i1 %t862, label %bb199, label %bb200
bb199:
  %t864 = load ptr, ptr %lp1
  %t865 = load i64, ptr %l37, !tbaa !24
  %t868 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H8e3ab02101333f4dae95aad48f2e722e(ptr %v1, ptr %t864, i64 %t865)
  store i1 %t868, ptr %l448
  br label %bb201
bb200:
  br label %bb202
bb201:
  call void @__olang_scope_close(ptr %s22)
  br label %bb276
bb202:
  %t869 = call %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v1)
  store %"compiler/eval:Image" %t869, ptr %l449
  br label %bb203
bb203:
  %t870 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store ptr %t870, ptr %lp58
  %t871 = load %"compiler/eval:Image", ptr %l449
  %t872 = load ptr, ptr %lp58
  store %"compiler/eval:Image" %t871, ptr %t872
  %t873 = load ptr, ptr %lp38
  %t874 = getelementptr %"compiler/eval:Image", ptr %t873, i32 0, i32 2
  %t875 = load i1, ptr %t874, !tbaa !21
  %t877 = load ptr, ptr %lp58
  %t878 = getelementptr %"compiler/eval:Image", ptr %t877, i32 0, i32 2
  store i1 %t875, ptr %t878, !tbaa !21
  store i64 0, ptr %l59, !tbaa !24
  %t879 = load ptr, ptr %lp38
  %t880 = getelementptr %"compiler/eval:Image", ptr %t879, i32 0, i32 0
  %t882 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t880)
  store i64 %t882, ptr %l452
  br label %bb204
bb204:
  %t883 = load i64, ptr %l452, !tbaa !24
  store i64 %t883, ptr %l60, !tbaa !24
  store i64 1, ptr %l61, !tbaa !24
  %t884 = load i64, ptr %l60, !tbaa !24
  %t885 = load i64, ptr %l59, !tbaa !24
  %t888 = icmp sgt i64 %t884, %t885
  br i1 %t888, label %bb205, label %bb206
bb205:
  %t890 = load i64, ptr %l61, !tbaa !24
  %t892 = icmp sgt i64 %t890, 0
  br i1 %t892, label %bb207, label %bb208
bb206:
  store i64 0, ptr %l456, !tbaa !24
  br label %bb210
bb207:
  %t894 = load i64, ptr %l60, !tbaa !24
  %t895 = load i64, ptr %l59, !tbaa !24
  %t898 = sub i64 %t894, %t895
  %t899 = load i64, ptr %l61, !tbaa !24
  %t902 = add i64 %t898, %t899
  %t904 = sub i64 %t902, 1
  %t905 = load i64, ptr %l61, !tbaa !24
  %t908 = sdiv i64 %t904, %t905
  store i64 %t908, ptr %l459, !tbaa !24
  br label %bb209
bb208:
  store i64 0, ptr %l459, !tbaa !24
  br label %bb209
bb209:
  %t910 = load i64, ptr %l459, !tbaa !24
  store i64 %t910, ptr %l456, !tbaa !24
  br label %bb210
bb210:
  %t911 = load i64, ptr %l456, !tbaa !24
  store i64 %t911, ptr %l62, !tbaa !24
  store i64 0, ptr %l63, !tbaa !24
  br label %bb211
bb211:
  store %olang.scope zeroinitializer, ptr %s39
  %t912 = load i64, ptr %l63, !tbaa !24
  %t913 = load i64, ptr %l62, !tbaa !24
  %t916 = icmp slt i64 %t912, %t913
  %t918 = xor i1 %t916, true
  br i1 %t918, label %bb212, label %bb213
bb212:
  call void @__olang_scope_close(ptr %s39)
  br label %bb274
bb213:
  br label %bb214
bb214:
  %t920 = load i64, ptr %l59, !tbaa !24
  %t921 = load i64, ptr %l63, !tbaa !24
  %t922 = load i64, ptr %l61, !tbaa !24
  %t925 = mul i64 %t921, %t922
  %t928 = add i64 %t920, %t925
  store i64 %t928, ptr %l64, !tbaa !24
  %t930 = load i64, ptr %l64, !tbaa !24
  %t932 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t933 = load ptr, ptr %t932, !tbaa !27
  %t934 = getelementptr i64, ptr %t933, i64 %t930
  %t935 = load i64, ptr %t934, !tbaa !34
  %t937 = icmp slt i64 %t935, 0
  br i1 %t937, label %bb215, label %bb216
bb215:
  call void @__olang_scope_close(ptr %s39)
  br label %bb273
bb216:
  br label %bb217
bb217:
  %t939 = load ptr, ptr %lp38
  %t940 = getelementptr %"compiler/eval:Image", ptr %t939, i32 0, i32 0
  %t941 = load i64, ptr %l64, !tbaa !24
  %t944 = call %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t940, i64 %t941)
  store %"compiler/eval:Blob" %t944, ptr %l482
  br label %bb218
bb218:
  %t945 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store ptr %t945, ptr %lp65
  %t946 = load %"compiler/eval:Blob", ptr %l482
  %t947 = load ptr, ptr %lp65
  store %"compiler/eval:Blob" %t946, ptr %t947
  %t948 = call %"compiler/eval:Blob" @compiler_2feval_3aBlob_2ector(ptr %v1)
  store %"compiler/eval:Blob" %t948, ptr %l483
  br label %bb219
bb219:
  %t949 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store ptr %t949, ptr %lp66
  %t950 = load %"compiler/eval:Blob", ptr %l483
  %t951 = load ptr, ptr %lp66
  store %"compiler/eval:Blob" %t950, ptr %t951
  %t952 = load ptr, ptr %lp65
  %t953 = getelementptr %"compiler/eval:Blob", ptr %t952, i32 0, i32 0
  %t954 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t953
  %t956 = load ptr, ptr %lp66
  %t957 = getelementptr %"compiler/eval:Blob", ptr %t956, i32 0, i32 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t954, ptr %t957
  %t958 = load ptr, ptr %lp65
  %t959 = getelementptr %"compiler/eval:Blob", ptr %t958, i32 0, i32 1
  %t960 = load i64, ptr %t959, !tbaa !24
  %t962 = load ptr, ptr %lp66
  %t963 = getelementptr %"compiler/eval:Blob", ptr %t962, i32 0, i32 1
  store i64 %t960, ptr %t963, !tbaa !24
  %t964 = load ptr, ptr %lp65
  %t965 = getelementptr %"compiler/eval:Blob", ptr %t964, i32 0, i32 2
  %t966 = load i1, ptr %t965, !tbaa !21
  %t968 = load ptr, ptr %lp66
  %t969 = getelementptr %"compiler/eval:Blob", ptr %t968, i32 0, i32 2
  store i1 %t966, ptr %t969, !tbaa !21
  store i64 0, ptr %l67, !tbaa !24
  %t970 = load ptr, ptr %lp65
  %t971 = getelementptr %"compiler/eval:Blob", ptr %t970, i32 0, i32 3
  %t973 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t971)
  store i64 %t973, ptr %l488
  br label %bb220
bb220:
  %t974 = load i64, ptr %l488, !tbaa !24
  store i64 %t974, ptr %l68, !tbaa !24
  store i64 1, ptr %l69, !tbaa !24
  %t975 = load i64, ptr %l68, !tbaa !24
  %t976 = load i64, ptr %l67, !tbaa !24
  %t979 = icmp sgt i64 %t975, %t976
  br i1 %t979, label %bb221, label %bb222
bb221:
  %t981 = load i64, ptr %l69, !tbaa !24
  %t983 = icmp sgt i64 %t981, 0
  br i1 %t983, label %bb223, label %bb224
bb222:
  store i64 0, ptr %l492, !tbaa !24
  br label %bb226
bb223:
  %t985 = load i64, ptr %l68, !tbaa !24
  %t986 = load i64, ptr %l67, !tbaa !24
  %t989 = sub i64 %t985, %t986
  %t990 = load i64, ptr %l69, !tbaa !24
  %t993 = add i64 %t989, %t990
  %t995 = sub i64 %t993, 1
  %t996 = load i64, ptr %l69, !tbaa !24
  %t999 = sdiv i64 %t995, %t996
  store i64 %t999, ptr %l495, !tbaa !24
  br label %bb225
bb224:
  store i64 0, ptr %l495, !tbaa !24
  br label %bb225
bb225:
  %t1001 = load i64, ptr %l495, !tbaa !24
  store i64 %t1001, ptr %l492, !tbaa !24
  br label %bb226
bb226:
  %t1002 = load i64, ptr %l492, !tbaa !24
  store i64 %t1002, ptr %l70, !tbaa !24
  store i64 0, ptr %l71, !tbaa !24
  br label %bb227
bb227:
  store %olang.scope zeroinitializer, ptr %s42
  %t1003 = load i64, ptr %l71, !tbaa !24
  %t1004 = load i64, ptr %l70, !tbaa !24
  %t1007 = icmp slt i64 %t1003, %t1004
  %t1009 = xor i1 %t1007, true
  br i1 %t1009, label %bb228, label %bb229
bb228:
  call void @__olang_scope_close(ptr %s42)
  br label %bb266
bb229:
  br label %bb230
bb230:
  %t1011 = load i64, ptr %l67, !tbaa !24
  %t1012 = load i64, ptr %l71, !tbaa !24
  %t1013 = load i64, ptr %l69, !tbaa !24
  %t1016 = mul i64 %t1012, %t1013
  %t1019 = add i64 %t1011, %t1016
  store i64 %t1019, ptr %l72, !tbaa !24
  %t1021 = load ptr, ptr %lp66
  %t1022 = getelementptr %"compiler/eval:Blob", ptr %t1021, i32 0, i32 3
  store ptr %t1022, ptr %l513, !tbaa !29
  %t1023 = load ptr, ptr %lp65
  %t1024 = getelementptr %"compiler/eval:Blob", ptr %t1023, i32 0, i32 3
  %t1025 = load i64, ptr %l72, !tbaa !24
  %t1028 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1024, i64 %t1025)
  store i64 %t1028, ptr %l516
  br label %bb231
bb231:
  %t1029 = load ptr, ptr %l513, !tbaa !29
  %t1030 = load i64, ptr %l516, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1029, i64 %t1030)
  br label %bb232
bb232:
  %t1031 = load ptr, ptr %lp66
  %t1032 = getelementptr %"compiler/eval:Blob", ptr %t1031, i32 0, i32 5
  store ptr %t1032, ptr %l517, !tbaa !29
  %t1033 = load ptr, ptr %lp65
  %t1034 = getelementptr %"compiler/eval:Blob", ptr %t1033, i32 0, i32 5
  %t1035 = load i64, ptr %l72, !tbaa !24
  %t1038 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1034, i64 %t1035)
  store i64 %t1038, ptr %l520
  br label %bb233
bb233:
  %t1039 = load ptr, ptr %l517, !tbaa !29
  %t1040 = load i64, ptr %l520, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1039, i64 %t1040)
  br label %bb234
bb234:
  %t1041 = load ptr, ptr %lp65
  %t1042 = getelementptr %"compiler/eval:Blob", ptr %t1041, i32 0, i32 4
  %t1043 = load i64, ptr %l72, !tbaa !24
  %t1046 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1042, i64 %t1043)
  store i64 %t1046, ptr %l523
  br label %bb235
bb235:
  %t1047 = load i64, ptr %l523, !tbaa !24
  %t1048 = icmp slt i64 %t1047, 0
  br i1 %t1048, label %bb236, label %bb237
bb236:
  %t1050 = load ptr, ptr %lp65
  %t1051 = getelementptr %"compiler/eval:Blob", ptr %t1050, i32 0, i32 6
  %t1052 = load i64, ptr %l72, !tbaa !24
  %t1055 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1051, i64 %t1052)
  store i64 %t1055, ptr %l528
  br label %bb238
bb237:
  %t1056 = load ptr, ptr %lp38
  %t1057 = getelementptr %"compiler/eval:Image", ptr %t1056, i32 0, i32 1
  store ptr %t1057, ptr %l529, !tbaa !29
  %t1058 = load ptr, ptr %lp65
  %t1059 = getelementptr %"compiler/eval:Blob", ptr %t1058, i32 0, i32 4
  %t1060 = load i64, ptr %l72, !tbaa !24
  %t1063 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1059, i64 %t1060)
  store i64 %t1063, ptr %l532
  br label %bb239
bb238:
  %t1064 = load i64, ptr %l528, !tbaa !24
  store i64 %t1064, ptr %l525, !tbaa !24
  br label %bb241
bb239:
  %t1065 = load ptr, ptr %l529, !tbaa !29
  %t1066 = load i64, ptr %l532, !tbaa !24
  %t1067 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1065, i64 %t1066)
  store i64 %t1067, ptr %l533
  br label %bb240
bb240:
  %t1068 = load i64, ptr %l533, !tbaa !24
  store i64 %t1068, ptr %l525, !tbaa !24
  br label %bb241
bb241:
  %t1069 = load i64, ptr %l525, !tbaa !24
  store i64 %t1069, ptr %l73, !tbaa !24
  %t1070 = load ptr, ptr %lp65
  %t1071 = getelementptr %"compiler/eval:Blob", ptr %t1070, i32 0, i32 4
  %t1072 = load i64, ptr %l72, !tbaa !24
  %t1075 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1071, i64 %t1072)
  store i64 %t1075, ptr %l536
  br label %bb242
bb242:
  %t1076 = load i64, ptr %l536, !tbaa !24
  %t1077 = icmp sge i64 %t1076, 0
  br i1 %t1077, label %bb243, label %bb244
bb243:
  %t1079 = load ptr, ptr %lp65
  %t1080 = getelementptr %"compiler/eval:Blob", ptr %t1079, i32 0, i32 4
  %t1081 = load i64, ptr %l72, !tbaa !24
  %t1084 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1080, i64 %t1081)
  store i64 %t1084, ptr %l541
  br label %bb245
bb244:
  store i1 false, ptr %l538, !tbaa !21
  br label %bb246
bb245:
  %t1085 = load i64, ptr %l541, !tbaa !24
  %t1086 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t1087 = load ptr, ptr %t1086, !tbaa !27
  %t1088 = getelementptr i64, ptr %t1087, i64 %t1085
  %t1089 = load i64, ptr %t1088, !tbaa !34
  %t1091 = icmp sge i64 %t1089, 0
  store i1 %t1091, ptr %l538, !tbaa !21
  br label %bb246
bb246:
  %t1093 = load i1, ptr %l538, !tbaa !21
  br i1 %t1093, label %bb247, label %bb248
bb247:
  %t1094 = load ptr, ptr %lp66
  %t1095 = getelementptr %"compiler/eval:Blob", ptr %t1094, i32 0, i32 4
  store ptr %t1095, ptr %l544, !tbaa !29
  %t1096 = load ptr, ptr %lp65
  %t1097 = getelementptr %"compiler/eval:Blob", ptr %t1096, i32 0, i32 4
  %t1098 = load i64, ptr %l72, !tbaa !24
  %t1101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1097, i64 %t1098)
  store i64 %t1101, ptr %l547
  br label %bb249
bb248:
  br label %bb252
bb249:
  %t1102 = load i64, ptr %l547, !tbaa !24
  %t1103 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t1104 = load ptr, ptr %t1103, !tbaa !27
  %t1105 = getelementptr i64, ptr %t1104, i64 %t1102
  %t1106 = load i64, ptr %t1105, !tbaa !34
  %t1107 = load ptr, ptr %l544, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1107, i64 %t1106)
  br label %bb250
bb250:
  %t1109 = load ptr, ptr %lp66
  %t1110 = getelementptr %"compiler/eval:Blob", ptr %t1109, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1110, i64 -1)
  br label %bb251
bb251:
  call void @__olang_scope_close(ptr %s42)
  br label %bb265
bb252:
  %t1112 = load i64, ptr %l73, !tbaa !24
  %t1115 = call { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %s0, ptr %l34, i64 %t1112)
  %t1116 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t1115, 1
  %t1117 = extractvalue { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } %t1115, 0
  store i32 %t1117, ptr %l554
  %t1118 = icmp ne i32 %t1117, 0
  br i1 %t1118, label %bb254, label %ok.1119, !prof !99
ok.1119:
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1116, ptr %l553
  br label %bb253
bb253:
  %t1120 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l553
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1120, ptr %l550
  br label %bb257
bb254:
  br label %bb255
bb255:
  call void @__olang_ert_req_clear()
  %t1121 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s42, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1121, ptr %l555
  br label %bb256
bb256:
  %t1122 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l555
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1122, ptr %l550
  br label %bb257
bb257:
  %t1123 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l550
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1123, ptr %l74
  %t1124 = load ptr, ptr %l2, !tbaa !29
  %t1126 = getelementptr %"compiler/interp:Exec", ptr %t1124, i32 0, i32 1
  %t1127 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l74, i32 0, i32 0
  %t1128 = load i64, ptr %t1127, !tbaa !24
  %t1131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t1126, i64 %t1128)
  store ptr %t1131, ptr %l559
  br label %bb258
bb258:
  %t1132 = load ptr, ptr %l559, !tbaa !29
  %t1133 = call { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %t1132)
  store { i64, i32 } %t1133, ptr %l560
  br label %bb259
bb259:
  %t1134 = load { i64, i32 }, ptr %l560
  store { i64, i32 } %t1134, ptr %l75
  %t1135 = getelementptr { i64, i32 }, ptr %l75, i32 0, i32 0
  %t1136 = load i64, ptr %t1135, !tbaa !24
  store i64 %t1136, ptr %l76, !tbaa !24
  %t1138 = getelementptr { i64, i32 }, ptr %l75, i32 0, i32 1
  %t1139 = load i32, ptr %t1138, !tbaa !23
  store i32 %t1139, ptr %l77, !tbaa !23
  %t1141 = load ptr, ptr %lp66
  %t1142 = getelementptr %"compiler/eval:Blob", ptr %t1141, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1142, i64 -1)
  br label %bb260
bb260:
  %t1144 = load ptr, ptr %lp66
  %t1145 = getelementptr %"compiler/eval:Blob", ptr %t1144, i32 0, i32 6
  %t1146 = load i64, ptr %l73, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1145, i64 %t1146)
  br label %bb261
bb261:
  %t1149 = load ptr, ptr %lp66
  %t1150 = getelementptr %"compiler/eval:Blob", ptr %t1149, i32 0, i32 7
  %t1151 = load i64, ptr %l76, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1150, i64 %t1151)
  br label %bb262
bb262:
  %t1154 = load ptr, ptr %lp66
  %t1155 = getelementptr %"compiler/eval:Blob", ptr %t1154, i32 0, i32 8
  %t1156 = load i32, ptr %l77, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t1155, i32 %t1156)
  br label %bb263
bb263:
  %t1159 = load ptr, ptr %lp66
  %t1160 = getelementptr %"compiler/eval:Blob", ptr %t1159, i32 0, i32 9
  %t1161 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l74, i32 0, i32 1
  %t1162 = load i64, ptr %t1161, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1160, i64 %t1162)
  br label %bb264
bb264:
  call void @__olang_scope_close(ptr %s42)
  br label %bb265
bb265:
  %t1165 = load i64, ptr %l71, !tbaa !24
  %t1167 = add i64 %t1165, 1
  store i64 %t1167, ptr %l71, !tbaa !24
  br label %bb227
bb266:
  %t1169 = load ptr, ptr %lp58
  %t1170 = getelementptr %"compiler/eval:Image", ptr %t1169, i32 0, i32 0
  %t1171 = load ptr, ptr %lp66
  %t1172 = load %"compiler/eval:Blob", ptr %t1171
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t1170, %"compiler/eval:Blob" %t1172)
  br label %bb267
bb267:
  %t1175 = load ptr, ptr %lp58
  %t1176 = getelementptr %"compiler/eval:Image", ptr %t1175, i32 0, i32 1
  store ptr %t1176, ptr %l576, !tbaa !29
  %t1177 = load ptr, ptr %lp38
  %t1178 = getelementptr %"compiler/eval:Image", ptr %t1177, i32 0, i32 1
  %t1179 = load i64, ptr %l64, !tbaa !24
  %t1182 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1178, i64 %t1179)
  store i64 %t1182, ptr %l579
  br label %bb268
bb268:
  %t1183 = load ptr, ptr %l576, !tbaa !29
  %t1184 = load i64, ptr %l579, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t1183, i64 %t1184)
  br label %bb269
bb269:
  store ptr %l34, ptr %l580, !tbaa !29
  %t1185 = load ptr, ptr %lp38
  %t1186 = getelementptr %"compiler/eval:Image", ptr %t1185, i32 0, i32 1
  %t1187 = load i64, ptr %l64, !tbaa !24
  %t1190 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1186, i64 %t1187)
  store i64 %t1190, ptr %l583
  br label %bb270
bb270:
  %t1191 = load i64, ptr %l37, !tbaa !24
  %t1192 = load i64, ptr %l64, !tbaa !24
  %t1194 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t1195 = load ptr, ptr %t1194, !tbaa !27
  %t1196 = getelementptr i64, ptr %t1195, i64 %t1192
  %t1197 = load i64, ptr %t1196, !tbaa !34
  %t1200 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s39, i64 %t1191, i64 %t1197)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1200, ptr %l587
  br label %bb271
bb271:
  %t1201 = load ptr, ptr %l580, !tbaa !29
  %t1202 = load i64, ptr %l583, !tbaa !24
  %t1203 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l587
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_Hd47ddefe3838698aaa5711f2f63b01ed(ptr %s0, ptr %t1201, i64 %t1202, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1203)
  br label %bb272
bb272:
  call void @__olang_scope_close(ptr %s39)
  br label %bb273
bb273:
  %t1204 = load i64, ptr %l63, !tbaa !24
  %t1206 = add i64 %t1204, 1
  store i64 %t1206, ptr %l63, !tbaa !24
  br label %bb211
bb274:
  %t1208 = load ptr, ptr %lp1
  %t1209 = load i64, ptr %l37, !tbaa !24
  %t1210 = load ptr, ptr %lp58
  %t1211 = load %"compiler/eval:Image", ptr %t1210
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v1, ptr %v1, ptr %t1208, i64 %t1209, %"compiler/eval:Image" %t1211)
  br label %bb275
bb275:
  call void @__olang_scope_close(ptr %s22)
  br label %bb276
bb276:
  %t1215 = load i64, ptr %l36, !tbaa !24
  %t1217 = add i64 %t1215, 1
  store i64 %t1217, ptr %l36, !tbaa !24
  br label %bb119
bb277:
  %t1219 = load ptr, ptr %l0, !tbaa !29
  %t1221 = getelementptr %"compiler/check:Checker", ptr %t1219, i32 0, i32 108
  %t1223 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_Hbfebb6c42bc5b6ebe27287b6298add36(ptr %v0, ptr %v0, ptr %t1221)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t1223, ptr %l597
  br label %bb278
bb278:
  %t1224 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l597
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t1224, ptr %l78
  br label %bb279
bb279:
  store %olang.scope zeroinitializer, ptr %s48
  %t1226 = call { i32, %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2fsource_3aSpan__Hd38fe3b5521cd0cc33c71306d155ae89(ptr %v0, ptr %l78)
  %t1227 = extractvalue { i32, %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" } %t1226, 1
  %t1228 = extractvalue { i32, %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" } %t1226, 0
  store i32 %t1228, ptr %l601
  %t1229 = icmp ne i32 %t1228, 0
  br i1 %t1229, label %bb281, label %ok.1230, !prof !99
ok.1230:
  store %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" %t1227, ptr %l600
  br label %bb280
bb280:
  %t1231 = load %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %l600
  store %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" %t1231, ptr %l598
  br label %bb283
bb281:
  %t1232 = load i32, ptr %l601, !tbaa !23
  %t1233 = ashr i32 %t1232, 16
  %t1235 = icmp eq i32 %t1233, 1
  store i1 %t1235, ptr %l603, !tbaa !21
  br label %bb282
bb282:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s48)
  br label %bb304
bb283:
  %t1236 = load %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %l598
  store %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" %t1236, ptr %l79
  %t1237 = load ptr, ptr %lp1
  %t1238 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %l79, i32 0, i32 0
  %t1239 = load i64, ptr %t1238, !tbaa !24
  %t1242 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v1, ptr %t1237, i64 %t1239)
  store i1 %t1242, ptr %l606
  br label %bb284
bb284:
  %t1243 = load i1, ptr %l606, !tbaa !21
  br i1 %t1243, label %bb285, label %bb286
bb285:
  store i1 true, ptr %l607, !tbaa !21
  br label %bb288
bb286:
  %t1244 = load ptr, ptr %l2, !tbaa !29
  %t1246 = getelementptr %"compiler/interp:Exec", ptr %t1244, i32 0, i32 10
  %t1247 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %l79, i32 0, i32 0
  %t1248 = load i64, ptr %t1247, !tbaa !24
  %t1251 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t1246, i64 %t1248)
  store i1 %t1251, ptr %l611
  br label %bb287
bb287:
  %t1252 = load i1, ptr %l611, !tbaa !21
  store i1 %t1252, ptr %l607, !tbaa !21
  br label %bb288
bb288:
  %t1253 = load i1, ptr %l607, !tbaa !21
  br i1 %t1253, label %bb289, label %bb290
bb289:
  call void @__olang_scope_close(ptr %s48)
  br label %bb303
bb290:
  br label %bb291
bb291:
  %t1254 = load ptr, ptr %l2, !tbaa !29
  %t1256 = getelementptr %"compiler/interp:Exec", ptr %t1254, i32 0, i32 1
  %t1257 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %l79, i32 0, i32 0
  %t1258 = load i64, ptr %t1257, !tbaa !24
  %t1261 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t1256, i64 %t1258)
  store ptr %t1261, ptr %l615
  br label %bb292
bb292:
  %t1262 = load ptr, ptr %l615, !tbaa !29
  store ptr %t1262, ptr %l80, !tbaa !29
  %t1263 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %l79, i32 0, i32 0
  %t1264 = load i64, ptr %t1263, !tbaa !24
  %t1267 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %s0, ptr %s0, ptr %l5, i64 %t1264)
  %t1268 = extractvalue { i32, { i64, ptr } } %t1267, 1
  %t1269 = extractvalue { i32, { i64, ptr } } %t1267, 0
  store i32 %t1269, ptr %l620
  %t1270 = icmp ne i32 %t1269, 0
  br i1 %t1270, label %bb294, label %ok.1271, !prof !99
ok.1271:
  store { i64, ptr } %t1268, ptr %l619
  br label %bb293
bb293:
  %t1272 = load { i64, ptr }, ptr %l619, !tbaa !27
  store { i64, ptr } %t1272, ptr %l616, !tbaa !27
  br label %bb296
bb294:
  br label %bb295
bb295:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l616, !tbaa !27
  br label %bb296
bb296:
  %t1273 = load { i64, ptr }, ptr %l616, !tbaa !27
  store { i64, ptr } %t1273, ptr %l81, !tbaa !27
  %t1274 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t1276 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s48, { i64, ptr } %t1274, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t1276, ptr %l622
  br label %bb297
bb297:
  %t1277 = load i1, ptr %l622, !tbaa !21
  br i1 %t1277, label %bb298, label %bb299
bb298:
  store { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb300
bb299:
  br label %bb300
bb300:
  %t1278 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1278, ptr %l623, !tbaa !29
  %t1279 = load ptr, ptr %l80, !tbaa !29
  %t1281 = getelementptr %"compiler/typed:Body", ptr %t1279, i32 0, i32 3
  %t1282 = load i64, ptr %t1281, !tbaa !24
  %t1283 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %l79, i32 0, i32 1
  %t1284 = getelementptr %"compiler/source:Span", ptr %t1283, i32 0, i32 0
  %t1285 = load i32, ptr %t1284, !tbaa !23
  %t1287 = sext i32 %t1285 to i64
  %t1288 = getelementptr %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba", ptr %l79, i32 0, i32 1
  %t1289 = getelementptr %"compiler/source:Span", ptr %t1288, i32 0, i32 1
  %t1290 = load i32, ptr %t1289, !tbaa !23
  %t1292 = sext i32 %t1290 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t1293
  %t1294 = getelementptr { i64, [3 x i64] }, ptr %t1293, i32 0, i32 0
  store i64 3, ptr %t1294
  %t1296 = insertvalue { i64, i64, i64 } undef, i64 %t1282, 0
  %t1298 = insertvalue { i64, i64, i64 } %t1296, i64 %t1287, 1
  %t1300 = insertvalue { i64, i64, i64 } %t1298, i64 %t1292, 2
  %t1301 = getelementptr { i64, [3 x i64] }, ptr %t1293, i32 0, i32 1
  store { i64, i64, i64 } %t1300, ptr %t1301
  %t1302 = load { i64, [3 x i64] }, ptr %t1293
  store { i64, [3 x i64] } %t1302, ptr %l630
  %t1303 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t1305 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeNotBaked(ptr %s0, ptr %s48, { i64, ptr } %t1303)
  store %"compiler/msgs:Msg" %t1305, ptr %l632
  br label %bb301
bb301:
  %t1306 = load ptr, ptr %l623, !tbaa !29
  %t1307 = load { i64, [3 x i64] }, ptr %l630
  %t1308 = load %"compiler/msgs:Msg", ptr %l632
  %t1309 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s48, ptr %t1306, { i64, [3 x i64] } %t1307, %"compiler/msgs:Msg" %t1308)
  store i64 %t1309, ptr %l633
  br label %bb302
bb302:
  call void @__olang_scope_close(ptr %s48)
  br label %bb303
bb303:
  br label %bb279
bb304:
  %t1310 = load ptr, ptr %lp1
  %t1311 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1310
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1311, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:AssertAsk"
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca { i64, [5 x i64] }
  %l10 = alloca i1
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca %"compiler/source:Span"
  %l24 = alloca i64
  %l26 = alloca i1
  %l29 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i64
  %l46 = alloca %"compiler/interp:Exec"
  %l53 = alloca i64
  %l56 = alloca i64
  %l60 = alloca i64
  %l62 = alloca i64
  %l67 = alloca %"compiler/check:AssertAsk"
  %l71 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l74 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca { i64, [2 x i64] }
  %l90 = alloca { i64, [5 x i64] }
  %l98 = alloca i64
  %l108 = alloca i1
  %l117 = alloca ptr
  %l121 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca { i64, [3 x i64] }
  %l131 = alloca %"compiler/msgs:Msg"
  %l132 = alloca i64
  %l134 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i64
  %l138 = alloca { i64, [3 x i64] }
  %l139 = alloca %"compiler/msgs:Msg"
  %l142 = alloca %"compiler/msgs:Msg"
  %l150 = alloca ptr
  %l151 = alloca { i64, [3 x i64] }
  %l153 = alloca { i64, ptr }
  %l154 = alloca %"compiler/msgs:Msg"
  %l155 = alloca i64
  %l156 = alloca ptr
  %l157 = alloca i64
  %l163 = alloca { i64, [3 x i64] }
  %l164 = alloca %"compiler/msgs:Msg"
  %l172 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca { i64, [3 x i64] }
  %l178 = alloca %"compiler/msgs:Msg"
  %l179 = alloca i64
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i64
  %t47 = alloca %"compiler/interp:Exec", align 8
  %t91 = alloca %"compiler/check:AssertAsk", align 8
  %t111 = alloca { i64, [5 x i64] }, align 8
  %t125 = alloca { i64, [2 x i64] }, align 8
  %t185 = alloca { i64, [3 x i64] }, align 8
  %t319 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 82
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 102
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l29
  br label %bb4
bb3:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb5
bb4:
  %t14 = load i64, ptr %l29, !tbaa !24
  %t15 = icmp eq i64 %t14, 0
  store i1 %t15, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l26, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 83
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eL_H34364174f15757c2d142d60c88ce0944(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l34
  br label %bb8
bb7:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb9
bb8:
  %t23 = load i64, ptr %l34, !tbaa !24
  %t24 = icmp eq i64 %t23, 0
  store i1 %t24, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l31, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store i64 0, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/load:Loader", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 12
  %t46 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t45
  call void @compiler_2finterp_3aExec_2ector(ptr %t47, ptr %v0, ptr %v0, ptr %v0, ptr %t42, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t47, i64 992, i1 false)
  br label %bb13
bb13:
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %l46, i64 992, i1 false)
  store ptr %t51, ptr %l3, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 112
  %t57 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t56
  %t60 = getelementptr %"compiler/interp:Exec", ptr %t53, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %t60
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t65 = call i64 @compiler_2finterp_2edecideContracts(ptr %v0, ptr %v0, ptr %t61, ptr %t62)
  store i64 %t65, ptr %l53
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t70 = call i64 @compiler_2finterp_2edecideTopAsserts(ptr %v0, ptr %v0, ptr %t66, ptr %t67)
  store i64 %t70, ptr %l56
  br label %bb15
bb15:
  %t71 = load i64, ptr %l53, !tbaa !24
  %t72 = load i64, ptr %l56, !tbaa !24
  %t73 = add i64 %t71, %t72
  store i64 %t73, ptr %l4, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 82
  store ptr %t77, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l60, !tbaa !24
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %t80)
  store i64 %t82, ptr %l62
  br label %bb17
bb17:
  %t83 = load i64, ptr %l60, !tbaa !24
  %t84 = load i64, ptr %l62, !tbaa !24
  %t85 = icmp slt i64 %t83, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb91
bb19:
  br label %bb20
bb20:
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t90 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eAt_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %t91, ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t91, i64 152, i1 false)
  br label %bb21
bb21:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l67, i64 152, i1 false)
  %t94 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 2
  %t97 = getelementptr %"compiler/source:Span", ptr %t96, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t100 = sext i32 %t98 to i64
  %t103 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t95, i64 %t100)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t103, ptr %l71
  br label %bb22
bb22:
  %t104 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l71
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t104, ptr %l8
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t106 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t109 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v1, ptr %t105, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t106)
  store i1 %t109, ptr %l74
  br label %bb23
bb23:
  %t110 = load i1, ptr %l74, !tbaa !21
  br i1 %t110, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb90
bb25:
  br label %bb26
bb26:
  store { i64, [5 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 0
  store i64 0, ptr %t112
  %t113 = load { i64, [5 x i64] }, ptr %t111
  store { i64, [5 x i64] } %t113, ptr %l9
  store i1 false, ptr %l10, !tbaa !21
  %t115 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 4
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = icmp sge i64 %t116, 0
  br i1 %t118, label %bb27, label %bb28
bb27:
  %t120 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 4
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = trunc i64 %t121 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [2 x i64] }, ptr %t125, i32 0, i32 0
  store i64 0, ptr %t126
  %t128 = insertvalue { i32 } undef, i32 %t123, 0
  %t129 = getelementptr { i64, [2 x i64] }, ptr %t125, i32 0, i32 1
  store { i32 } %t128, ptr %t129
  %t130 = load { i64, [2 x i64] }, ptr %t125
  store { i64, [2 x i64] } %t130, ptr %l11
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t133 = load { i64, [2 x i64] }, ptr %l11
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t132, { i64, [2 x i64] } %t133)
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/interp:Exec", ptr %t136, i32 0, i32 4
  store ptr %t138, ptr %l85, !tbaa !29
  %t139 = load { i64, [2 x i64] }, ptr %l11
  store { i64, [2 x i64] } %t139, ptr %l86
  %t140 = icmp sge i64 0, 0
  br i1 %t140, label %bb30, label %bb31
bb30:
  %t142 = icmp sle i64 0, 1152921504606846975
  br i1 %t142, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_7edf3cf7ccf8e57f_276bde685bbe381b)
  unreachable
bb32:
  %t144 = mul i64 0, 8
  %t145 = insertvalue { i64, ptr } undef, i64 0, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t147 = load ptr, ptr %l85, !tbaa !29
  %t148 = load { i64, [2 x i64] }, ptr %l86
  %t150 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s3, ptr %s3, ptr %t147, { i64, [2 x i64] } %t148, { i64, ptr } %t146)
  store { i64, [5 x i64] } %t150, ptr %l90
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_7edf3cf7ccf8e57f_276bde685bbe381b)
  unreachable
bb34:
  %t151 = load { i64, [5 x i64] }, ptr %l90
  store { i64, [5 x i64] } %t151, ptr %l9
  %t152 = load { i64, [5 x i64] }, ptr %l9
  %t154 = extractvalue { i64, [5 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 0
  br i1 %t155, label %bb35, label %bb36
bb35:
  %t157 = load ptr, ptr %l3, !tbaa !29
  %t159 = getelementptr %"compiler/interp:Exec", ptr %t157, i32 0, i32 4
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr %"compiler/interp:Exec", ptr %t160, i32 0, i32 4
  %t163 = getelementptr %"compiler/eval:Machine", ptr %t162, i32 0, i32 10
  %t164 = load %"compiler/eval:Ptr", ptr %t163
  %t165 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t169 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t159, %"compiler/eval:Ptr" %t164, i32 %t165)
  store i64 %t169, ptr %l98
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t170 = load i64, ptr %l98, !tbaa !24
  %t171 = icmp ne i64 %t170, 0
  store i1 %t171, ptr %l10, !tbaa !21
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t173 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 1
  %t174 = load i64, ptr %t173, !tbaa !24
  %t175 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 3
  %t176 = getelementptr %"compiler/source:Span", ptr %t175, i32 0, i32 0
  %t177 = load i32, ptr %t176, !tbaa !23
  %t179 = sext i32 %t177 to i64
  %t180 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 3
  %t181 = getelementptr %"compiler/source:Span", ptr %t180, i32 0, i32 1
  %t182 = load i32, ptr %t181, !tbaa !23
  %t184 = sext i32 %t182 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t185
  %t186 = getelementptr { i64, [3 x i64] }, ptr %t185, i32 0, i32 0
  store i64 3, ptr %t186
  %t188 = insertvalue { i64, i64, i64 } undef, i64 %t174, 0
  %t190 = insertvalue { i64, i64, i64 } %t188, i64 %t179, 1
  %t192 = insertvalue { i64, i64, i64 } %t190, i64 %t184, 2
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t185, i32 0, i32 1
  store { i64, i64, i64 } %t192, ptr %t193
  %t194 = load { i64, [3 x i64] }, ptr %t185
  store { i64, [3 x i64] } %t194, ptr %l12
  %t196 = load { i64, [5 x i64] }, ptr %l9
  %t198 = extractvalue { i64, [5 x i64] } %t196, 0
  %t199 = icmp eq i64 %t198, 0
  br i1 %t199, label %bb40, label %bb41
bb40:
  %t201 = load i1, ptr %l10, !tbaa !21
  store i1 %t201, ptr %l108, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb42
bb42:
  %t203 = load i1, ptr %l108, !tbaa !21
  br i1 %t203, label %bb43, label %bb44
bb43:
  %t204 = load i64, ptr %l4, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l4, !tbaa !24
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t209 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v1, ptr %t208, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t209, i1 true)
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s3)
  br label %bb90
bb46:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 12
  %t215 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 0
  %t216 = load i64, ptr %t215, !tbaa !24
  %t219 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t214, i64 %t216)
  store ptr %t219, ptr %l117
  br label %bb47
bb47:
  %t220 = load ptr, ptr %l117, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Body", ptr %t220, i32 0, i32 11
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t224 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 2
  %t225 = load %"compiler/source:Span", ptr %t224
  %t228 = call i1 @compiler_2ftyped_2eAlwaysReached(ptr %v0, ptr %t223, %"compiler/source:Span" %t225)
  store i1 %t228, ptr %l121
  br label %bb48
bb48:
  %t229 = load i1, ptr %l121, !tbaa !21
  %t230 = xor i1 %t229, true
  br i1 %t230, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s3)
  br label %bb90
bb50:
  br label %bb51
bb51:
  %t232 = load { i64, [5 x i64] }, ptr %l9
  %t234 = extractvalue { i64, [5 x i64] } %t232, 0
  %t235 = icmp eq i64 %t234, 0
  br i1 %t235, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb64
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t237 = load i64, ptr %l4, !tbaa !24
  %t239 = add i64 %t237, 1
  store i64 %t239, ptr %l4, !tbaa !24
  %t241 = load ptr, ptr %l2, !tbaa !29
  store ptr %t241, ptr %l127, !tbaa !29
  %t242 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t242, ptr %l128
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t246 = call %"compiler/msgs:Msg" @compiler_2finterp_2efalseMessage(ptr %v0, ptr %s3, ptr %s9, ptr %t243, ptr %l7)
  store %"compiler/msgs:Msg" %t246, ptr %l131
  br label %bb55
bb55:
  %t247 = load ptr, ptr %l127, !tbaa !29
  %t248 = load { i64, [3 x i64] }, ptr %l128
  %t249 = load %"compiler/msgs:Msg", ptr %l131
  %t250 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t247, { i64, [3 x i64] } %t248, %"compiler/msgs:Msg" %t249)
  store i64 %t250, ptr %l132
  br label %bb56
bb56:
  %t251 = load i64, ptr %l132, !tbaa !24
  store i64 %t251, ptr %l13, !tbaa !24
  %t252 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 11
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t255 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s9, { i64, ptr } %t253, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t255, ptr %l134
  br label %bb57
bb57:
  %t256 = load i1, ptr %l134, !tbaa !21
  %t257 = xor i1 %t256, true
  br i1 %t257, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s10
  %t259 = load ptr, ptr %l2, !tbaa !29
  store ptr %t259, ptr %l136, !tbaa !29
  %t260 = load i64, ptr %l13, !tbaa !24
  store i64 %t260, ptr %l137, !tbaa !24
  %t261 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 10
  %t262 = load { i64, [3 x i64] }, ptr %t261
  store { i64, [3 x i64] } %t262, ptr %l138
  %t263 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s10)
  store %"compiler/msgs:Msg" %t263, ptr %l139
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t264 = getelementptr %"compiler/msgs:Msg", ptr %l139, i32 0, i32 0
  %t265 = load i32, ptr %t264, !range !{i32 0, i32 796}
  %t266 = getelementptr %"compiler/check:AssertAsk", ptr %l7, i32 0, i32 11
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  %t270 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s10, ptr %v0, ptr %s10, i32 %t265, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, { i64, ptr } %t267)
  store %"compiler/msgs:Msg" %t270, ptr %l142
  br label %bb61
bb61:
  %t271 = load ptr, ptr %l136, !tbaa !29
  %t272 = load i64, ptr %l137, !tbaa !24
  %t273 = load { i64, [3 x i64] }, ptr %l138
  %t274 = load %"compiler/msgs:Msg", ptr %l142
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s10, ptr %t271, i64 %t272, { i64, [3 x i64] } %t273, %"compiler/msgs:Msg" %t274)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb89
bb64:
  %t275 = load { i64, [5 x i64] }, ptr %l9
  %t277 = extractvalue { i64, [5 x i64] } %t275, 0
  %t278 = icmp eq i64 %t277, 2
  br i1 %t278, label %bb65, label %bb66
bb65:
  %t280 = getelementptr { i64, [5 x i64] }, ptr %l9, i32 0, i32 1
  %t281 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t280, i32 0, i32 0
  %t282 = load i32, ptr %t281, !range !{i32 0, i32 15}
  store i32 %t282, ptr %l14
  %t284 = getelementptr { i64, [5 x i64] }, ptr %l9, i32 0, i32 1
  %t285 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t284, i32 0, i32 1
  %t286 = load i64, ptr %t285
  store i64 %t286, ptr %l15, !tbaa !24
  %t288 = getelementptr { i64, [5 x i64] }, ptr %l9, i32 0, i32 1
  %t289 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t288, i32 0, i32 2
  %t290 = load %"compiler/source:Span", ptr %t289
  store %"compiler/source:Span" %t290, ptr %l16
  br label %bb67
bb66:
  br label %bb73
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  %t292 = load i64, ptr %l4, !tbaa !24
  %t294 = add i64 %t292, 1
  store i64 %t294, ptr %l4, !tbaa !24
  %t296 = load ptr, ptr %l2, !tbaa !29
  store ptr %t296, ptr %l150, !tbaa !29
  %t297 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t297, ptr %l151
  %t298 = load i32, ptr %l14, !range !{i32 0, i32 15}
  %t300 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s11, i32 %t298)
  store { i64, ptr } %t300, ptr %l153
  br label %bb68
bb68:
  %t301 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t302 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %s11, ptr %s11, { i64, ptr } %t301)
  store %"compiler/msgs:Msg" %t302, ptr %l154
  br label %bb69
bb69:
  %t303 = load ptr, ptr %l150, !tbaa !29
  %t304 = load { i64, [3 x i64] }, ptr %l151
  %t305 = load %"compiler/msgs:Msg", ptr %l154
  %t306 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t303, { i64, [3 x i64] } %t304, %"compiler/msgs:Msg" %t305)
  store i64 %t306, ptr %l155
  br label %bb70
bb70:
  %t307 = load i64, ptr %l155, !tbaa !24
  %t308 = load ptr, ptr %l2, !tbaa !29
  store ptr %t308, ptr %l156, !tbaa !29
  store i64 %t307, ptr %l157, !tbaa !24
  %t310 = load i64, ptr %l15, !tbaa !24
  %t311 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t312 = load i32, ptr %t311, !tbaa !23
  %t314 = sext i32 %t312 to i64
  %t315 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 1
  %t316 = load i32, ptr %t315, !tbaa !23
  %t318 = sext i32 %t316 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t319
  %t320 = getelementptr { i64, [3 x i64] }, ptr %t319, i32 0, i32 0
  store i64 3, ptr %t320
  %t322 = insertvalue { i64, i64, i64 } undef, i64 %t310, 0
  %t324 = insertvalue { i64, i64, i64 } %t322, i64 %t314, 1
  %t326 = insertvalue { i64, i64, i64 } %t324, i64 %t318, 2
  %t327 = getelementptr { i64, [3 x i64] }, ptr %t319, i32 0, i32 1
  store { i64, i64, i64 } %t326, ptr %t327
  %t328 = load { i64, [3 x i64] }, ptr %t319
  store { i64, [3 x i64] } %t328, ptr %l163
  %t329 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s11)
  store %"compiler/msgs:Msg" %t329, ptr %l164
  br label %bb71
bb71:
  %t330 = load ptr, ptr %l156, !tbaa !29
  %t331 = load i64, ptr %l157, !tbaa !24
  %t332 = load { i64, [3 x i64] }, ptr %l163
  %t333 = load %"compiler/msgs:Msg", ptr %l164
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s11, ptr %t330, i64 %t331, { i64, [3 x i64] } %t332, %"compiler/msgs:Msg" %t333)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb89
bb73:
  %t334 = load { i64, [5 x i64] }, ptr %l9
  %t336 = extractvalue { i64, [5 x i64] } %t334, 0
  %t337 = icmp eq i64 %t336, 3
  br i1 %t337, label %bb74, label %bb75
bb74:
  %t339 = getelementptr { i64, [5 x i64] }, ptr %l9, i32 0, i32 1
  %t340 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t339, i32 0, i32 0
  %t341 = load { i64, ptr }, ptr %t340
  store { i64, ptr } %t341, ptr %l18, !tbaa !27
  %t343 = getelementptr { i64, [5 x i64] }, ptr %l9, i32 0, i32 1
  %t344 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t343, i32 0, i32 1
  %t345 = load i64, ptr %t344
  store i64 %t345, ptr %l19, !tbaa !24
  %t347 = getelementptr { i64, [5 x i64] }, ptr %l9, i32 0, i32 1
  %t348 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t347, i32 0, i32 2
  %t349 = load %"compiler/source:Span", ptr %t348
  store %"compiler/source:Span" %t349, ptr %l20
  br label %bb76
bb75:
  br label %bb84
bb76:
  %t351 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t352 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t353 = load ptr, ptr @__olang_prog_scope
  %t356 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %t353, { i64, ptr } %t351, { i64, ptr } %t352)
  store i1 %t356, ptr %l172
  br label %bb77
bb77:
  %t357 = load i1, ptr %l172, !tbaa !21
  br i1 %t357, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s13
  %t358 = load i64, ptr %l4, !tbaa !24
  %t360 = add i64 %t358, 1
  store i64 %t360, ptr %l4, !tbaa !24
  %t362 = load ptr, ptr %l2, !tbaa !29
  store ptr %t362, ptr %l175, !tbaa !29
  %t363 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t363, ptr %l176
  %t364 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t366 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %s3, ptr %s13, { i64, ptr } %t364)
  store %"compiler/msgs:Msg" %t366, ptr %l178
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t367 = load ptr, ptr %l175, !tbaa !29
  %t368 = load { i64, [3 x i64] }, ptr %l176
  %t369 = load %"compiler/msgs:Msg", ptr %l178
  %t370 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s13, ptr %t367, { i64, [3 x i64] } %t368, %"compiler/msgs:Msg" %t369)
  store i64 %t370, ptr %l179
  br label %bb81
bb81:
  %t371 = load i64, ptr %l179, !tbaa !24
  %t372 = load ptr, ptr %l3, !tbaa !29
  %t373 = load ptr, ptr %l2, !tbaa !29
  %t375 = load i64, ptr %l19, !tbaa !24
  %t376 = load %"compiler/source:Span", ptr %l20
  call void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v0, ptr %t372, ptr %t373, i64 %t371, i64 %t375, %"compiler/source:Span" %t376)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s13)
  br label %bb83
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_d8df33bf7c2af1a9_d617709f0680343d)
  unreachable
bb89:
  call void @__olang_scope_close(ptr %s3)
  br label %bb90
bb90:
  %t382 = load i64, ptr %l6, !tbaa !24
  %t384 = add i64 %t382, 1
  store i64 %t384, ptr %l6, !tbaa !24
  br label %bb16
bb91:
  %t386 = load i64, ptr %l4, !tbaa !24
  store i64 %t386, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:ValueAsk"
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca { i64, [2 x i64] }
  %l11 = alloca { i64, [3 x i64] }
  %l12 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca i1
  %l18 = alloca { i64, [3 x i64] }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l21 = alloca i64
  %l24 = alloca i64
  %l36 = alloca %"compiler/interp:Exec"
  %l41 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca %"compiler/check:ValueAsk"
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l59 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca { i64, [2 x i64] }
  %l72 = alloca { i64, [5 x i64] }
  %l81 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %l88 = alloca i1
  %l93 = alloca i1
  %l96 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca { i64, [3 x i64] }
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/msgs:Msg"
  %l106 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca { i64, [3 x i64] }
  %l115 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %l126 = alloca { i64, [3 x i64] }
  %l128 = alloca { i64, [3 x i64] }
  %l130 = alloca i1
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca { i64, [3 x i64] }
  %l142 = alloca { i64, ptr }
  %l144 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l146 = alloca { i64, ptr }
  %l148 = alloca i64
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca { i64, [3 x i64] }
  %l156 = alloca { i64, ptr }
  %l159 = alloca %"compiler/msgs:Msg"
  %l160 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca i64
  %l164 = alloca { i64, [3 x i64] }
  %l165 = alloca %"compiler/msgs:Msg"
  %l169 = alloca ptr
  %l170 = alloca i64
  %l171 = alloca { i64, [3 x i64] }
  %l172 = alloca %"compiler/msgs:Msg"
  %l180 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i64
  %l184 = alloca { i64, [3 x i64] }
  %l186 = alloca %"compiler/msgs:Msg"
  %l188 = alloca ptr
  %l189 = alloca i64
  %l190 = alloca { i64, [3 x i64] }
  %l193 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l199 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i64
  %t29 = alloca %"compiler/interp:Exec", align 8
  %t89 = alloca { i64, [2 x i64] }, align 8
  %t128 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 85
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 4
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 12
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27
  call void @compiler_2finterp_3aExec_2ector(ptr %t29, ptr %v0, ptr %v0, ptr %v0, ptr %t24, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t29, i64 992, i1 false)
  br label %bb5
bb5:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l36, i64 992, i1 false)
  store ptr %t33, ptr %l2, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 112
  %t39 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t38
  %t42 = getelementptr %"compiler/interp:Exec", ptr %t35, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %t42
  %t43 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l41
  br label %bb6
bb6:
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 85
  store ptr %t47, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l44, !tbaa !24
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l46
  br label %bb8
bb8:
  %t53 = load i64, ptr %l44, !tbaa !24
  %t54 = load i64, ptr %l46, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb88
bb10:
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = call %"compiler/check:ValueAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eAt_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t59, i64 %t60)
  store %"compiler/check:ValueAsk" %t63, ptr %l51
  br label %bb12
bb12:
  %t64 = load %"compiler/check:ValueAsk", ptr %l51
  store %"compiler/check:ValueAsk" %t64, ptr %l7
  %t65 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 6
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb87
bb14:
  br label %bb15
bb15:
  %t68 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t71 = getelementptr %"compiler/source:Span", ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t77 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t69, i64 %t74)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t77, ptr %l56
  br label %bb16
bb16:
  %t78 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t78, ptr %l8
  %t79 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t82 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t79)
  store i1 %t82, ptr %l59
  br label %bb17
bb17:
  %t83 = load i1, ptr %l59, !tbaa !21
  br i1 %t83, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb87
bb19:
  br label %bb20
bb20:
  %t84 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 4
  %t85 = load i64, ptr %t84, !tbaa !24
  %t87 = trunc i64 %t85 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [2 x i64] }, ptr %t89, i32 0, i32 0
  store i64 0, ptr %t90
  %t92 = insertvalue { i32 } undef, i32 %t87, 0
  %t93 = getelementptr { i64, [2 x i64] }, ptr %t89, i32 0, i32 1
  store { i32 } %t92, ptr %t93
  %t94 = load { i64, [2 x i64] }, ptr %t89
  store { i64, [2 x i64] } %t94, ptr %l9
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t97 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t96, { i64, [2 x i64] } %t97)
  br label %bb21
bb21:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/interp:Exec", ptr %t100, i32 0, i32 4
  store ptr %t102, ptr %l67, !tbaa !29
  %t103 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t103, ptr %l68
  %t104 = icmp sge i64 0, 0
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t106 = icmp sle i64 0, 1152921504606846975
  br i1 %t106, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e1183b54591591ba_6784d54d52bb291e)
  unreachable
bb24:
  %t108 = mul i64 0, 8
  %t109 = insertvalue { i64, ptr } undef, i64 0, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t111 = load ptr, ptr %l67, !tbaa !29
  %t112 = load { i64, [2 x i64] }, ptr %l68
  %t114 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t111, { i64, [2 x i64] } %t112, { i64, ptr } %t110)
  store { i64, [5 x i64] } %t114, ptr %l72
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_e1183b54591591ba_6784d54d52bb291e)
  unreachable
bb26:
  %t115 = load { i64, [5 x i64] }, ptr %l72
  %t116 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t119 = getelementptr %"compiler/source:Span", ptr %t118, i32 0, i32 0
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t123 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t124 = getelementptr %"compiler/source:Span", ptr %t123, i32 0, i32 1
  %t125 = load i32, ptr %t124, !tbaa !23
  %t127 = sext i32 %t125 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 0
  store i64 3, ptr %t129
  %t131 = insertvalue { i64, i64, i64 } undef, i64 %t117, 0
  %t133 = insertvalue { i64, i64, i64 } %t131, i64 %t122, 1
  %t135 = insertvalue { i64, i64, i64 } %t133, i64 %t127, 2
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  store { i64, i64, i64 } %t135, ptr %t136
  %t137 = load { i64, [3 x i64] }, ptr %t128
  store { i64, [3 x i64] } %t137, ptr %l11
  %t140 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t141 = load %"compiler/source:Span", ptr %t140
  %t144 = call { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %s3, { i64, [5 x i64] } %t115, %"compiler/source:Span" %t141)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t144, ptr %l81
  br label %bb27
bb27:
  %t145 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l81
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t145, ptr %l12
  %t146 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l12, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l82, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l83, !tbaa !24
  %t150 = load i64, ptr %l83, !tbaa !24
  %t151 = mul i64 %t150, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l84, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l83, !tbaa !24
  %t160 = mul i64 %t159, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t156, ptr %t158, i64 %t160, i1 false)
  %t161 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t161, ptr %l13, !tbaa !27
  %t162 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l12, i32 0, i32 1
  %t163 = load i64, ptr %t162, !tbaa !24
  store i64 %t163, ptr %l14, !tbaa !24
  %t165 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l12, i32 0, i32 2
  %t166 = load %"compiler/source:Span", ptr %t165
  store %"compiler/source:Span" %t166, ptr %l15
  %t168 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t168, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t170, ptr %l88
  br label %bb28
bb28:
  %t171 = load i1, ptr %l88, !tbaa !21
  br i1 %t171, label %bb29, label %bb30
bb29:
  %t172 = load i64, ptr %l4, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l4, !tbaa !24
  %t176 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 0
  %t177 = load i32, ptr %t176, !range !{i32 0, i32 3}
  %t179 = trunc i64 2 to i32
  %t180 = icmp eq i32 %t177, %t179
  br i1 %t180, label %bb31, label %bb32
bb30:
  br label %bb42
bb31:
  %t182 = load ptr, ptr %l2, !tbaa !29
  %t184 = getelementptr %"compiler/interp:Exec", ptr %t182, i32 0, i32 4
  %t186 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eResultHoldsAddress(ptr %v0, ptr %t184)
  store i1 %t186, ptr %l96
  br label %bb33
bb32:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb34
bb33:
  %t187 = load i1, ptr %l96, !tbaa !21
  store i1 %t187, ptr %l93, !tbaa !21
  br label %bb34
bb34:
  %t188 = load i1, ptr %l93, !tbaa !21
  br i1 %t188, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t189 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t189, i1 true)
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t192, ptr %l99, !tbaa !29
  %t193 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t193, ptr %l100
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t196 = load i32, ptr %t195, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t194, i32 %t196)
  store { i64, ptr } %t199, ptr %l103
  br label %bb38
bb38:
  %t200 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t208 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eZeroValueShared(ptr %s7, ptr %s7, { i64, ptr } %t206)
  store %"compiler/msgs:Msg" %t208, ptr %l105
  br label %bb39
bb39:
  %t209 = load ptr, ptr %l99, !tbaa !29
  %t210 = load { i64, [3 x i64] }, ptr %l100
  %t211 = load %"compiler/msgs:Msg", ptr %l105
  %t212 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t209, { i64, [3 x i64] } %t210, %"compiler/msgs:Msg" %t211)
  store i64 %t212, ptr %l106
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb87
bb42:
  %t213 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t213, i1 true)
  br label %bb43
bb43:
  %t216 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 0
  %t217 = load i32, ptr %t216, !range !{i32 0, i32 3}
  %t219 = trunc i64 0 to i32
  %t220 = icmp eq i32 %t217, %t219
  br i1 %t220, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t222 = load ptr, ptr %l1, !tbaa !29
  store ptr %t222, ptr %l111, !tbaa !29
  %t223 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t223, ptr %l112
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t226 = load i32, ptr %t225, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s8, ptr %t224, i32 %t226)
  store { i64, ptr } %t229, ptr %l115
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t230 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t237 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t240 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralCtorFails(ptr %s8, ptr %s3, ptr %s8, { i64, ptr } %t236, { i64, ptr } %t237)
  store %"compiler/msgs:Msg" %t240, ptr %l118
  br label %bb47
bb47:
  %t241 = load ptr, ptr %l111, !tbaa !29
  %t242 = load { i64, [3 x i64] }, ptr %l112
  %t243 = load %"compiler/msgs:Msg", ptr %l118
  %t244 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t241, { i64, [3 x i64] } %t242, %"compiler/msgs:Msg" %t243)
  store i64 %t244, ptr %l119
  br label %bb48
bb48:
  %t245 = load i64, ptr %l119, !tbaa !24
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 1
  %t249 = load i64, ptr %t248, !tbaa !24
  %t250 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t251 = load %"compiler/source:Span", ptr %t250
  %t252 = load i64, ptr %l14, !tbaa !24
  %t253 = load %"compiler/source:Span", ptr %l15
  call void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %t246, i64 %t245, i64 %t249, %"compiler/source:Span" %t251, i64 %t252, %"compiler/source:Span" %t253)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  br label %bb87
bb50:
  %t260 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 5
  %t261 = load { i64, [3 x i64] }, ptr %t260
  store { i64, [3 x i64] } %t261, ptr %l126
  %t262 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t262, ptr %l128
  %t265 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %l126, ptr %l128)
  store i1 %t265, ptr %l130
  br label %bb51
bb51:
  %t266 = load i1, ptr %l130, !tbaa !21
  %t267 = xor i1 %t266, true
  store i1 %t267, ptr %l17, !tbaa !21
  %t269 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 5
  %t270 = load { i64, [3 x i64] }, ptr %t269
  store { i64, [3 x i64] } %t270, ptr %l18
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l133, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t272, ptr %l134, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  store i64 %t274, ptr %l135, !tbaa !24
  %t275 = load i64, ptr %l135, !tbaa !24
  %t276 = mul i64 %t275, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t276)
  %t278 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  store { i64, ptr } %t279, ptr %l136, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = load i64, ptr %l135, !tbaa !24
  %t285 = mul i64 %t284, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t281, ptr %t283, i64 %t285, i1 false)
  %t286 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t286, ptr %l19, !tbaa !27
  %t287 = load i1, ptr %l17, !tbaa !21
  br i1 %t287, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t289, ptr %l138, !tbaa !29
  %t290 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 5
  %t291 = load { i64, [3 x i64] }, ptr %t290
  store { i64, [3 x i64] } %t291, ptr %l139
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t294 = load i32, ptr %t293, !tbaa !23
  %t297 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s9, ptr %t292, i32 %t294)
  store { i64, ptr } %t297, ptr %l142
  br label %bb54
bb53:
  br label %bb59
bb54:
  %t298 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 0
  %t300 = extractvalue { i64, ptr } %t298, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t305 = load ptr, ptr %l138, !tbaa !29
  %t306 = load { i64, [3 x i64] }, ptr %l139
  %t308 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2finterp_2ezeroUseArg(ptr %v0, ptr %s9, ptr %s9, ptr %t305, { i64, [3 x i64] } %t306, { i64, ptr } %t304)
  store { { i64, [3 x i64] }, { i64, ptr } } %t308, ptr %l144
  br label %bb55
bb55:
  %t309 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l144
  store { { i64, [3 x i64] }, { i64, ptr } } %t309, ptr %l20
  %t310 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l20, i32 0, i32 0
  %t311 = load { i64, [3 x i64] }, ptr %t310
  store { i64, [3 x i64] } %t311, ptr %l18
  %t313 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l20, i32 0, i32 1
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  store { i64, ptr } %t314, ptr %l146, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  %t317 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  store i64 %t318, ptr %l148, !tbaa !24
  %t320 = load i64, ptr %l148, !tbaa !24
  %t321 = icmp eq i64 %t316, %t320
  br i1 %t321, label %bb56, label %bb57
bb56:
  %t323 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = load i64, ptr %l148, !tbaa !24
  %t328 = mul i64 %t327, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t324, ptr %t326, i64 %t328, i1 false)
  br label %bb58
bb57:
  %t329 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  store i64 %t330, ptr %l150, !tbaa !24
  %t331 = load i64, ptr %l150, !tbaa !24
  %t332 = mul i64 %t331, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t332)
  %t334 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l151, !tbaa !27
  %t336 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = load i64, ptr %l150, !tbaa !24
  %t341 = mul i64 %t340, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t337, ptr %t339, i64 %t341, i1 false)
  %t342 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t342, ptr %l19, !tbaa !27
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  %t343 = load ptr, ptr %l1, !tbaa !29
  store ptr %t343, ptr %l152, !tbaa !29
  %t344 = load { i64, [3 x i64] }, ptr %l18
  store { i64, [3 x i64] } %t344, ptr %l153
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t347 = load i32, ptr %t346, !tbaa !23
  %t350 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s3, ptr %t345, i32 %t347)
  store { i64, ptr } %t350, ptr %l156
  br label %bb60
bb60:
  %t351 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t351, 0
  %t353 = extractvalue { i64, ptr } %t351, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t358 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t361 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t357, { i64, ptr } %t358)
  store %"compiler/msgs:Msg" %t361, ptr %l159
  br label %bb61
bb61:
  %t362 = load ptr, ptr %l152, !tbaa !29
  %t363 = load { i64, [3 x i64] }, ptr %l153
  %t364 = load %"compiler/msgs:Msg", ptr %l159
  %t365 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t362, { i64, [3 x i64] } %t363, %"compiler/msgs:Msg" %t364)
  store i64 %t365, ptr %l160
  br label %bb62
bb62:
  %t366 = load i64, ptr %l160, !tbaa !24
  store i64 %t366, ptr %l21, !tbaa !24
  %t367 = load i1, ptr %l17, !tbaa !21
  br i1 %t367, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t369 = load ptr, ptr %l1, !tbaa !29
  store ptr %t369, ptr %l162, !tbaa !29
  %t370 = load i64, ptr %l21, !tbaa !24
  store i64 %t370, ptr %l163, !tbaa !24
  %t371 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t371, ptr %l164
  %t372 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %s10)
  store %"compiler/msgs:Msg" %t372, ptr %l165
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t373 = load ptr, ptr %l162, !tbaa !29
  %t374 = load i64, ptr %l163, !tbaa !24
  %t375 = load { i64, [3 x i64] }, ptr %l164
  %t376 = load %"compiler/msgs:Msg", ptr %l165
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s10, ptr %t373, i64 %t374, { i64, [3 x i64] } %t375, %"compiler/msgs:Msg" %t376)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb67:
  %t377 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 7
  %t378 = load { i64, [3 x i64] }, ptr %t377
  %t380 = extractvalue { i64, [3 x i64] } %t378, 0
  %t381 = icmp eq i64 %t380, 0
  %t383 = xor i1 %t381, true
  br i1 %t383, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s11
  %t385 = load ptr, ptr %l1, !tbaa !29
  store ptr %t385, ptr %l169, !tbaa !29
  %t386 = load i64, ptr %l21, !tbaa !24
  store i64 %t386, ptr %l170, !tbaa !24
  %t387 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 7
  %t388 = load { i64, [3 x i64] }, ptr %t387
  store { i64, [3 x i64] } %t388, ptr %l171
  %t389 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadUnassigned(ptr %s11)
  store %"compiler/msgs:Msg" %t389, ptr %l172
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t390 = load ptr, ptr %l169, !tbaa !29
  %t391 = load i64, ptr %l170, !tbaa !24
  %t392 = load { i64, [3 x i64] }, ptr %l171
  %t393 = load %"compiler/msgs:Msg", ptr %l172
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s11, ptr %t390, i64 %t391, { i64, [3 x i64] } %t392, %"compiler/msgs:Msg" %t393)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t395 = load i64, ptr %l21, !tbaa !24
  %t396 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 1
  %t397 = load i64, ptr %t396, !tbaa !24
  %t398 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 2
  %t399 = load %"compiler/source:Span", ptr %t398
  %t400 = load i64, ptr %l14, !tbaa !24
  %t401 = load %"compiler/source:Span", ptr %l15
  call void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %t394, i64 %t395, i64 %t397, %"compiler/source:Span" %t399, i64 %t400, %"compiler/source:Span" %t401)
  br label %bb73
bb73:
  %t408 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t410 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s3, { i64, ptr } %t408, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t410, ptr %l180
  br label %bb74
bb74:
  %t411 = load i1, ptr %l180, !tbaa !21
  %t412 = xor i1 %t411, true
  br i1 %t412, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s12
  %t414 = load ptr, ptr %l1, !tbaa !29
  store ptr %t414, ptr %l182, !tbaa !29
  %t415 = load i64, ptr %l21, !tbaa !24
  store i64 %t415, ptr %l183, !tbaa !24
  %t416 = load { i64, [3 x i64] }, ptr %l18
  store { i64, [3 x i64] } %t416, ptr %l184
  %t417 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t419 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroByReference(ptr %s3, ptr %s12, { i64, ptr } %t417)
  store %"compiler/msgs:Msg" %t419, ptr %l186
  br label %bb77
bb76:
  %t420 = load i1, ptr %l17, !tbaa !21
  br i1 %t420, label %bb79, label %bb80
bb77:
  %t422 = load ptr, ptr %l182, !tbaa !29
  %t423 = load i64, ptr %l183, !tbaa !24
  %t424 = load { i64, [3 x i64] }, ptr %l184
  %t425 = load %"compiler/msgs:Msg", ptr %l186
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s12, ptr %t422, i64 %t423, { i64, [3 x i64] } %t424, %"compiler/msgs:Msg" %t425)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb86
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t426 = load ptr, ptr %l1, !tbaa !29
  store ptr %t426, ptr %l188, !tbaa !29
  %t427 = load i64, ptr %l21, !tbaa !24
  store i64 %t427, ptr %l189, !tbaa !24
  %t428 = load { i64, [3 x i64] }, ptr %l18
  store { i64, [3 x i64] } %t428, ptr %l190
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t431 = load i32, ptr %t430, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s14, ptr %t429, i32 %t431)
  store { i64, ptr } %t434, ptr %l193
  br label %bb81
bb80:
  br label %bb85
bb81:
  %t435 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t435, 0
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = mul i64 %t436, 1
  %t439 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t438)
  call void @llvm.memcpy.p0.p0.i64(ptr %t439, ptr %t437, i64 %t438, i1 false)
  %t440 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  store { i64, ptr } %t441, ptr %l194, !tbaa !27
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/check:ValueAsk", ptr %l7, i32 0, i32 3
  %t444 = load i32, ptr %t443, !tbaa !23
  %t447 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s14, ptr %t442, i32 %t444)
  store { i64, ptr } %t447, ptr %l197
  br label %bb82
bb82:
  %t448 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t448, 0
  %t450 = extractvalue { i64, ptr } %t448, 1
  %t451 = mul i64 %t449, 1
  %t452 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t451)
  call void @llvm.memcpy.p0.p0.i64(ptr %t452, ptr %t450, i64 %t451, i1 false)
  %t453 = insertvalue { i64, ptr } undef, i64 %t449, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t452, 1
  %t455 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t457 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroReferenceHasOne(ptr %s14, ptr %s14, ptr %s14, { i64, ptr } %t455, { i64, ptr } %t454)
  store %"compiler/msgs:Msg" %t457, ptr %l199
  br label %bb83
bb83:
  %t458 = load ptr, ptr %l188, !tbaa !29
  %t459 = load i64, ptr %l189, !tbaa !24
  %t460 = load { i64, [3 x i64] }, ptr %l190
  %t461 = load %"compiler/msgs:Msg", ptr %l199
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s14, ptr %t458, i64 %t459, { i64, [3 x i64] } %t460, %"compiler/msgs:Msg" %t461)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb85:
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s3)
  br label %bb87
bb87:
  %t462 = load i64, ptr %l6, !tbaa !24
  %t464 = add i64 %t462, 1
  store i64 %t464, ptr %l6, !tbaa !24
  br label %bb7
bb88:
  %t466 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t466, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t6, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = icmp sge i64 2, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  br label %bb10
bb4:
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 2, %t22
  br i1 %t23, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_31552f310cf75527_9d9c34da119f96fb)
  unreachable
bb6:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_31552f310cf75527_9d9c34da119f96fb)
  unreachable
bb8:
  %t29 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 2
  %t33 = sub i64 %t31, 2
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t39 = extractvalue { i64, ptr } %t35, 1
  %t40 = extractvalue { i64, ptr } %t35, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t36, i64 %t37)
  %t46 = getelementptr i8, ptr %t45, i64 %t37
  call void @olang_textcopy(ptr %t46, ptr %t39, i64 %t40)
  %t47 = getelementptr i8, ptr %t46, i64 %t40
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t45, 1
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t51, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l5, !tbaa !27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_31552f310cf75527_9d9c34da119f96fb)
  unreachable
bb10:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t60, ptr %l20
  br label %bb11
bb11:
  %t61 = load i1, ptr %l20, !tbaa !21
  br i1 %t61, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb15
bb13:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t64, ptr %l23
  br label %bb14
bb14:
  %t65 = load i1, ptr %l23, !tbaa !21
  store i1 %t65, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t66 = load i1, ptr %l21, !tbaa !21
  br i1 %t66, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t67, ptr %l25, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l26, !tbaa !24
  %t70 = load i64, ptr %l26, !tbaa !24
  %t71 = mul i64 %t70, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l27, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l26, !tbaa !24
  %t80 = mul i64 %t79, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %t78, i64 %t80, i1 false)
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t82 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t82, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t85 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToC(ptr %s0, ptr %s0, { i64, ptr } %t83)
  store { i64, ptr } %t85, ptr %l29
  br label %bb19
bb19:
  %t86 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = call ptr @dlopen(ptr %t87, i32 258)
  store ptr %t89, ptr %l30
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l30, !tbaa !29
  %t91 = icmp eq ptr %t90, null
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t95, ptr %l34, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l35, !tbaa !24
  %t98 = load i64, ptr %l35, !tbaa !24
  %t99 = mul i64 %t98, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l36, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l35, !tbaa !24
  %t108 = mul i64 %t107, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t109, ptr %l34, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t110 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t111 = call ptr @dlerror()
  store ptr %t111, ptr %l37
  br label %bb24
bb24:
  %t112 = load ptr, ptr %l37, !tbaa !29
  store ptr %t112, ptr %l2, !tbaa !29
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb25, label %bb26
bb25:
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t122 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aCStr_2eStringFromC(ptr %v1, ptr %t119, i64 400)
  store { i64, ptr } %t122, ptr %l44
  br label %bb27
bb26:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t123, ptr %l41, !tbaa !27
  br label %bb28
bb27:
  %t125 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t125, ptr %l41, !tbaa !27
  br label %bb28
bb28:
  %t126 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l47, !tbaa !24
  %t128 = load i64, ptr %l47, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l48, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l47, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t139, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t140 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t140, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2eStopText(ptr %v0, ptr %v1, ptr %v2, { i64, [5 x i64] } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, [5 x i64] }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l43 = alloca i1
  %l47 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, [5 x i64] } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l14, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb4:
  %t22 = load { i64, [5 x i64] }, ptr %l0
  %t24 = extractvalue { i64, [5 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 1
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t31)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb8:
  %t43 = load { i64, [5 x i64] }, ptr %l0
  %t45 = extractvalue { i64, [5 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 2
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t49 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t48, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 15}
  store i32 %t50, ptr %l3
  %t52 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t53 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t52, i32 0, i32 1
  %t54 = load i64, ptr %t53
  store i64 %t54, ptr %l4, !tbaa !24
  %t56 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t57 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t56, i32 0, i32 2
  %t58 = load %"compiler/source:Span", ptr %t57
  store %"compiler/source:Span" %t58, ptr %l5
  %t60 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t61 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t60, i32 0, i32 3
  %t62 = load { i64, ptr }, ptr %t61
  store { i64, ptr } %t62, ptr %l6, !tbaa !27
  br label %bb11
bb10:
  br label %bb27
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i32, ptr %l3, !range !{i32 0, i32 15}
  %t66 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s4, i32 %t64)
  store { i64, ptr } %t66, ptr %l29
  br label %bb12
bb12:
  %t67 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t67, ptr %l7, !tbaa !27
  %t68 = load i32, ptr %l3, !range !{i32 0, i32 15}
  %t70 = trunc i64 13 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  %t75 = load %"compiler/source:Span", ptr %l5
  %t79 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s5, ptr %t73, i64 %t74, %"compiler/source:Span" %t75)
  store { i64, ptr } %t79, ptr %l35
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t88 = extractvalue { i64, ptr } %t80, 1
  %t89 = extractvalue { i64, ptr } %t80, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t84, i64 %t85)
  %t93 = getelementptr i8, ptr %t92, i64 %t85
  call void @olang_textcopy(ptr %t93, ptr %t88, i64 %t89)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t91, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
bb16:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t97, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t99, ptr %l39
  br label %bb17
bb17:
  %t100 = load i1, ptr %l39, !tbaa !21
  br i1 %t100, label %bb18, label %bb19
bb18:
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = extractvalue { i64, ptr } %t101, 0
  %t105 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t103, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t109, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t111, ptr %l43
  br label %bb21
bb21:
  %t112 = load i1, ptr %l43, !tbaa !21
  br i1 %t112, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s9
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load %"compiler/source:Span", ptr %l5
  %t119 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s9, ptr %t113, i64 %t114, %"compiler/source:Span" %t115)
  store { i64, ptr } %t119, ptr %l47
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = extractvalue { i64, ptr } %t120, 1
  %t129 = extractvalue { i64, ptr } %t120, 0
  %t130 = add i64 %t126, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = getelementptr i8, ptr %t131, i64 %t123
  call void @olang_textcopy(ptr %t132, ptr %t124, i64 %t125)
  %t133 = getelementptr i8, ptr %t132, i64 %t125
  call void @olang_textcopy(ptr %t133, ptr %t128, i64 %t129)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t131, 1
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t135, ptr %rv
  br label %ret
bb25:
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t138 = load i64, ptr %l4, !tbaa !24
  %t139 = load %"compiler/source:Span", ptr %l5
  %t143 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t137, i64 %t138, %"compiler/source:Span" %t139)
  store { i64, ptr } %t143, ptr %l53
  br label %bb26
bb26:
  %t144 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = extractvalue { i64, ptr } %t144, 1
  %t154 = extractvalue { i64, ptr } %t144, 0
  %t155 = add i64 %t151, %t154
  %t156 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t160 = extractvalue { i64, ptr } %t145, 1
  %t161 = extractvalue { i64, ptr } %t145, 0
  %t162 = add i64 %t158, %t161
  %t163 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t147, i64 %t148)
  %t164 = getelementptr i8, ptr %t163, i64 %t148
  call void @olang_textcopy(ptr %t164, ptr %t149, i64 %t150)
  %t165 = getelementptr i8, ptr %t164, i64 %t150
  call void @olang_textcopy(ptr %t165, ptr %t153, i64 %t154)
  %t166 = getelementptr i8, ptr %t165, i64 %t154
  call void @olang_textcopy(ptr %t166, ptr %t156, i64 %t157)
  %t167 = getelementptr i8, ptr %t166, i64 %t157
  call void @olang_textcopy(ptr %t167, ptr %t160, i64 %t161)
  %t168 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t163, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t169, ptr %rv
  br label %ret
bb27:
  %t171 = load { i64, [5 x i64] }, ptr %l0
  %t173 = extractvalue { i64, [5 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 3
  br i1 %t174, label %bb28, label %bb29
bb28:
  %t176 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t177 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t176, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177
  store { i64, ptr } %t178, ptr %l8, !tbaa !27
  %t180 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t180, i32 0, i32 1
  %t182 = load i64, ptr %t181
  store i64 %t182, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t185 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t184, i32 0, i32 2
  %t186 = load %"compiler/source:Span", ptr %t185
  store %"compiler/source:Span" %t186, ptr %l10
  br label %bb30
bb29:
  br label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s12
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t189 = load i64, ptr %l9, !tbaa !24
  %t190 = load %"compiler/source:Span", ptr %l10
  %t194 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s12, ptr %t188, i64 %t189, %"compiler/source:Span" %t190)
  store { i64, ptr } %t194, ptr %l65
  br label %bb31
bb31:
  %t195 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %t195, 1
  %t204 = extractvalue { i64, ptr } %t195, 0
  %t205 = add i64 %t201, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t197, i64 %t198)
  %t207 = getelementptr i8, ptr %t206, i64 %t198
  call void @olang_textcopy(ptr %t207, ptr %t199, i64 %t200)
  %t208 = getelementptr i8, ptr %t207, i64 %t200
  call void @olang_textcopy(ptr %t208, ptr %t203, i64 %t204)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t206, 1
  call void @__olang_scope_close(ptr %s12)
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5ef8759083cc657e_8312724bf589cc02)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/interp:chained" @compiler_2finterp_2echain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca i64
  %l11 = alloca { i64, [5 x i64] }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca i64
  %l55 = alloca i64
  %l59 = alloca %"compiler/interp:chained"
  %l62 = alloca { i64, [5 x i64] }
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l78 = alloca %"compiler/interp:chained"
  %l85 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca %"compiler/interp:chained"
  %l97 = alloca %"compiler/interp:chained"
  %l99 = alloca i1
  %l102 = alloca %"compiler/interp:chained"
  %l112 = alloca i64
  %l116 = alloca %"compiler/interp:chained"
  %l122 = alloca %"compiler/interp:chained"
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/interp:chained"
  %t64 = alloca { i64, [3 x i64] }, align 8
  %t281 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 5
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l27
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l27, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store ptr %a3, ptr %l7, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  %t37 = xor i1 %t35, true
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb55
bb4:
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopIf", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_97cc5832d0a5683f_9bb5deb899ee2c5b)
  unreachable
bb7:
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopIf", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t51)
  store %"compiler/source:Span" %t53, ptr %l41
  br label %bb9
bb9:
  %t54 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t54, ptr %l8
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t60 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t63 = sext i32 %t61 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 0
  store i64 3, ptr %t65
  %t67 = insertvalue { i64, i64, i64 } undef, i64 %t55, 0
  %t69 = insertvalue { i64, i64, i64 } %t67, i64 %t59, 1
  %t71 = insertvalue { i64, i64, i64 } %t69, i64 %t63, 2
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  store { i64, i64, i64 } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t64
  store { i64, [3 x i64] } %t73, ptr %l9
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l48, !tbaa !29
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %l49, !tbaa !24
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t79 = getelementptr %"compiler/ast:TopIf", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9c0b486f116f3620_d1f759da60f3616c)
  unreachable
bb11:
  br label %bb12
bb12:
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t86 = getelementptr %"compiler/ast:TopIf", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load i64, ptr %l49, !tbaa !24
  %t91 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v1, ptr %v2, ptr %t88, i64 %t89, ptr %t87)
  store i64 %t91, ptr %l55
  br label %bb13
bb13:
  %t92 = load i64, ptr %l55, !tbaa !24
  store i64 %t92, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = icmp slt i64 %t93, 0
  br i1 %t95, label %bb14, label %bb15
bb14:
  %t97 = load { i64, [3 x i64] }, ptr %l9
  %t99 = call %"compiler/interp:chained" @compiler_2finterp_3achained_2ector(ptr %v3, ptr %v3, i64 0, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, { i64, [3 x i64] } %t97)
  store %"compiler/interp:chained" %t99, ptr %l59
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s1)
  %t100 = load %"compiler/interp:chained", ptr %l59
  store %"compiler/interp:chained" %t100, ptr %rv
  br label %ret
bb17:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCondStop(ptr %v0, ptr %s1, ptr %t101, i64 %t102)
  store { i64, [5 x i64] } %t105, ptr %l62
  br label %bb18
bb18:
  %t106 = load { i64, [5 x i64] }, ptr %l62
  store { i64, [5 x i64] } %t106, ptr %l11
  %t107 = load { i64, [5 x i64] }, ptr %l11
  %t109 = extractvalue { i64, [5 x i64] } %t107, 0
  %t110 = icmp eq i64 %t109, 0
  br i1 %t110, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb41
bb22:
  %t112 = load { i64, [5 x i64] }, ptr %l11
  %t114 = extractvalue { i64, [5 x i64] } %t112, 0
  %t115 = icmp eq i64 %t114, 3
  br i1 %t115, label %bb23, label %bb24
bb23:
  %t117 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t118 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t117, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118
  store { i64, ptr } %t119, ptr %l12, !tbaa !27
  %t121 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t122 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t121, i32 0, i32 1
  %t123 = load i64, ptr %t122
  store i64 %t123, ptr %l13, !tbaa !24
  %t125 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t126 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t125, i32 0, i32 2
  %t127 = load %"compiler/source:Span", ptr %t126
  store %"compiler/source:Span" %t127, ptr %l14
  br label %bb25
bb24:
  br label %bb28
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t129 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t129, ptr %l70, !tbaa !27
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t131 = load i64, ptr %l13, !tbaa !24
  %t132 = load %"compiler/source:Span", ptr %l14
  %t136 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t130, i64 %t131, %"compiler/source:Span" %t132)
  store { i64, ptr } %t136, ptr %l74
  br label %bb26
bb26:
  %t137 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t138, i64 %t139)
  %t151 = getelementptr i8, ptr %t150, i64 %t139
  call void @olang_textcopy(ptr %t151, ptr %t140, i64 %t141)
  %t152 = getelementptr i8, ptr %t151, i64 %t141
  call void @olang_textcopy(ptr %t152, ptr %t144, i64 %t145)
  %t153 = getelementptr i8, ptr %t152, i64 %t145
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t150, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load { i64, [3 x i64] }, ptr %l9
  %t166 = call %"compiler/interp:chained" @compiler_2finterp_3achained_2ector(ptr %v3, ptr %v3, i64 0, i1 false, { i64, ptr } %t162, { i64, [3 x i64] } %t163)
  store %"compiler/interp:chained" %t166, ptr %l78
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  %t167 = load %"compiler/interp:chained", ptr %l78
  store %"compiler/interp:chained" %t167, ptr %rv
  br label %ret
bb28:
  %t168 = load { i64, [5 x i64] }, ptr %l11
  %t170 = extractvalue { i64, [5 x i64] } %t168, 0
  %t171 = icmp eq i64 %t170, 2
  br i1 %t171, label %bb29, label %bb30
bb29:
  %t173 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t174 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t173, i32 0, i32 0
  %t175 = load i32, ptr %t174, !range !{i32 0, i32 15}
  store i32 %t175, ptr %l15
  %t177 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t178 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t177, i32 0, i32 1
  %t179 = load i64, ptr %t178
  store i64 %t179, ptr %l16, !tbaa !24
  %t181 = getelementptr { i64, [5 x i64] }, ptr %l11, i32 0, i32 1
  %t182 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t181, i32 0, i32 2
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l17
  br label %bb31
bb30:
  br label %bb35
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t185 = load i32, ptr %l15, !range !{i32 0, i32 15}
  %t187 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s6, i32 %t185)
  store { i64, ptr } %t187, ptr %l85
  br label %bb32
bb32:
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t189 = load i64, ptr %l16, !tbaa !24
  %t190 = load %"compiler/source:Span", ptr %l17
  %t194 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s6, ptr %t188, i64 %t189, %"compiler/source:Span" %t190)
  store { i64, ptr } %t194, ptr %l89
  br label %bb33
bb33:
  %t195 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t200 = add i64 %t197, %t199
  %t201 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = add i64 %t200, %t203
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t196, i64 %t197)
  %t209 = getelementptr i8, ptr %t208, i64 %t197
  call void @olang_textcopy(ptr %t209, ptr %t198, i64 %t199)
  %t210 = getelementptr i8, ptr %t209, i64 %t199
  call void @olang_textcopy(ptr %t210, ptr %t202, i64 %t203)
  %t211 = getelementptr i8, ptr %t210, i64 %t203
  call void @olang_textcopy(ptr %t211, ptr %t205, i64 %t206)
  %t212 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t208, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  %t221 = load { i64, [3 x i64] }, ptr %l9
  %t224 = call %"compiler/interp:chained" @compiler_2finterp_3achained_2ector(ptr %v3, ptr %v3, i64 0, i1 false, { i64, ptr } %t220, { i64, [3 x i64] } %t221)
  store %"compiler/interp:chained" %t224, ptr %l93
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  %t225 = load %"compiler/interp:chained", ptr %l93
  store %"compiler/interp:chained" %t225, ptr %rv
  br label %ret
bb35:
  %t226 = load { i64, [5 x i64] }, ptr %l11
  %t228 = extractvalue { i64, [5 x i64] } %t226, 0
  %t229 = icmp eq i64 %t228, 1
  br i1 %t229, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t231 = load { i64, [3 x i64] }, ptr %l9
  %t233 = call %"compiler/interp:chained" @compiler_2finterp_3achained_2ector(ptr %v3, ptr %v3, i64 0, i1 false, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d43, i32 0, i32 1) }, { i64, [3 x i64] } %t231)
  store %"compiler/interp:chained" %t233, ptr %l97
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s1)
  %t234 = load %"compiler/interp:chained", ptr %l97
  store %"compiler/interp:chained" %t234, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b7cf027bc3b091ec_6e850e1bd8f0ff28)
  unreachable
bb41:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = call i1 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eHeld(ptr %v0, ptr %t235)
  store i1 %t237, ptr %l99
  br label %bb42
bb42:
  %t238 = load i1, ptr %l99, !tbaa !21
  br i1 %t238, label %bb43, label %bb44
bb43:
  %t239 = load i64, ptr %l6, !tbaa !24
  %t240 = load { i64, [3 x i64] }, ptr %l9
  %t243 = call %"compiler/interp:chained" @compiler_2finterp_3achained_2ector(ptr %v3, ptr %v3, i64 %t239, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) }, { i64, [3 x i64] } %t240)
  store %"compiler/interp:chained" %t243, ptr %l102
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s1)
  %t244 = load %"compiler/interp:chained", ptr %l102
  store %"compiler/interp:chained" %t244, ptr %rv
  br label %ret
bb46:
  %t245 = load i64, ptr %l6, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l6, !tbaa !24
  %t249 = load ptr, ptr %l7, !tbaa !29
  %t251 = getelementptr %"compiler/ast:TopIf", ptr %t249, i32 0, i32 2
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = icmp eq ptr %t252, null
  br i1 %t254, label %bb47, label %bb48
bb47:
  %t256 = load ptr, ptr %l7, !tbaa !29
  %t258 = getelementptr %"compiler/ast:TopIf", ptr %t256, i32 0, i32 3
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb49, label %bb50
bb48:
  br label %bb53
bb49:
  %t265 = load i64, ptr %l6, !tbaa !24
  store i64 %t265, ptr %l112, !tbaa !24
  br label %bb51
bb50:
  %t267 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store i64 %t267, ptr %l112, !tbaa !24
  br label %bb51
bb51:
  %t269 = load { i64, [3 x i64] }, ptr %l9
  %t270 = load i64, ptr %l112, !tbaa !24
  %t272 = call %"compiler/interp:chained" @compiler_2finterp_3achained_2ector(ptr %v3, ptr %v3, i64 %t270, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, [3 x i64] } %t269)
  store %"compiler/interp:chained" %t272, ptr %l116
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s1)
  %t273 = load %"compiler/interp:chained", ptr %l116
  store %"compiler/interp:chained" %t273, ptr %rv
  br label %ret
bb53:
  %t274 = load ptr, ptr %l7, !tbaa !29
  %t276 = getelementptr %"compiler/ast:TopIf", ptr %t274, i32 0, i32 2
  %t277 = load ptr, ptr %t276, !tbaa !29
  store ptr %t277, ptr %l7, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  br label %bb54
bb54:
  br label %bb2
bb55:
  %t279 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  %t280 = load i64, ptr %l5, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t281
  %t282 = getelementptr { i64, [3 x i64] }, ptr %t281, i32 0, i32 0
  store i64 3, ptr %t282
  %t284 = insertvalue { i64, i64, i64 } undef, i64 %t280, 0
  %t285 = insertvalue { i64, i64, i64 } %t284, i64 0, 1
  %t286 = insertvalue { i64, i64, i64 } %t285, i64 0, 2
  %t287 = getelementptr { i64, [3 x i64] }, ptr %t281, i32 0, i32 1
  store { i64, i64, i64 } %t286, ptr %t287
  %t288 = load { i64, [3 x i64] }, ptr %t281
  %t291 = call %"compiler/interp:chained" @compiler_2finterp_3achained_2ector(ptr %v3, ptr %v3, i64 %t279, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, { i64, [3 x i64] } %t288)
  store %"compiler/interp:chained" %t291, ptr %l122
  br label %bb56
bb56:
  %t292 = load %"compiler/interp:chained", ptr %l122
  store %"compiler/interp:chained" %t292, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/interp:chained", ptr %rv
  ret %"compiler/interp:chained" %rr
}

define dso_local { i32, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, [5 x i64] }
  %l14 = alloca i64
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2erun(ptr %v0, ptr %v0, ptr %t1, i64 %a1)
  store { i64, [5 x i64] } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, [5 x i64] }, ptr %l4
  %t8 = extractvalue { i64, [5 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t14 = insertvalue { i32, i1 } zeroinitializer, i32 65536, 0
  store { i32, i1 } %t14, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/interp:Exec", ptr %t15, i32 0, i32 4
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/interp:Exec", ptr %t18, i32 0, i32 4
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 10
  %t22 = load %"compiler/eval:Ptr", ptr %t21
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t17, %"compiler/eval:Ptr" %t22, i32 %t23)
  store i64 %t27, ptr %l14
  br label %bb5
bb5:
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = icmp ne i64 %t28, 0
  %t31 = insertvalue { i32, i1 } zeroinitializer, i1 %t29, 1
  store { i32, i1 } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCondStop(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, [5 x i64] }
  %rv = alloca { i64, [5 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2erun(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  store { i64, [5 x i64] } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, [5 x i64] }, ptr %l4
  store { i64, [5 x i64] } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca ptr
  %l54 = alloca ptr
  %l66 = alloca i64
  %l69 = alloca i64
  %l74 = alloca i1
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l83 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store i64 -1, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/interp:Exec", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/interp:Exec", ptr %t10, i32 0, i32 1
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l18
  br label %bb2
bb2:
  %t15 = load i64, ptr %l18, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l22, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb44
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/interp:Exec", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %l9, !tbaa !24
  %t68 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t64, i64 %t65)
  store ptr %t68, ptr %l46
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l46, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 1
  %t72 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t72, ptr %l10
  %t74 = load { i64, [2 x i64] }, ptr %l10
  %t76 = extractvalue { i64, [2 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 5
  br i1 %t77, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/interp:Exec", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l54
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l54, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Body", ptr %t86, i32 0, i32 11
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t95 = load ptr, ptr %lp1
  %t96 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t95, i64 %t96)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb42
bb22:
  %t99 = load { i64, [2 x i64] }, ptr %l10
  %t101 = extractvalue { i64, [2 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 0
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t104 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t105 = getelementptr { i64 }, ptr %t104, i32 0, i32 0
  %t106 = load i64, ptr %t105
  store i64 %t106, ptr %l11, !tbaa !24
  br label %bb25
bb24:
  br label %bb37
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t108, i64 %t109)
  store i64 %t112, ptr %l66
  br label %bb26
bb26:
  %t113 = load i64, ptr %l66, !tbaa !24
  store i64 %t113, ptr %l12, !tbaa !24
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t114, i64 %t115)
  store i64 %t118, ptr %l69
  br label %bb27
bb27:
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 0
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/load:Loader", ptr %t122, i32 0, i32 7
  %t125 = load i64, ptr %t124, !tbaa !24
  %t126 = load i64, ptr %l69, !tbaa !24
  %t128 = icmp eq i64 %t126, %t125
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = getelementptr %"compiler/types:Table", ptr %t132, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l76, !tbaa !29
  %t135 = load ptr, ptr %l3, !tbaa !29
  %t136 = load i64, ptr %l12, !tbaa !24
  %t139 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t135, i64 %t136)
  store ptr %t139, ptr %l79
  br label %bb30
bb29:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb33
bb30:
  %t140 = load ptr, ptr %l79, !tbaa !29
  %t142 = getelementptr %"compiler/ast:Func", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %t142, !tbaa !23
  %t144 = load ptr, ptr %l76, !tbaa !29
  %t146 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t144, i32 %t143)
  store { i64, ptr } %t146, ptr %l82
  br label %bb31
bb31:
  %t147 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t147, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t148, ptr %l83
  br label %bb32
bb32:
  %t149 = load i1, ptr %l83, !tbaa !21
  store i1 %t149, ptr %l74, !tbaa !21
  br label %bb33
bb33:
  %t150 = load i1, ptr %l74, !tbaa !21
  br i1 %t150, label %bb34, label %bb35
bb34:
  %t151 = load i64, ptr %l9, !tbaa !24
  store i64 %t151, ptr %l2, !tbaa !24
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_5b75817b97c7703f_a9caa4d803bddbab)
  unreachable
bb42:
  br label %bb43
bb43:
  %t153 = load i64, ptr %l8, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l8, !tbaa !24
  br label %bb9
bb44:
  %t157 = load ptr, ptr %lp1
  %t158 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t157
  %t159 = load i64, ptr %l2, !tbaa !24
  %t161 = insertvalue { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } undef, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, 0
  %t163 = insertvalue { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t161, i64 %t159, 1
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t163, ptr %rv
  br label %ret
ret:
  %rr = load { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %rv
  ret { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %rr
}

define dso_local i1 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 4
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/interp:Exec", ptr %t4, i32 0, i32 4
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 10
  %t8 = load %"compiler/eval:Ptr", ptr %t7
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t3, %"compiler/eval:Ptr" %t8, i32 %t9)
  store i64 %t13, ptr %l6
  br label %bb1
bb1:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp ne i64 %t14, 0
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, [5 x i64] }
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l35 = alloca { i64, [5 x i64] }
  %l39 = alloca i1
  %rv = alloca { i64, [5 x i64] }
  %t3 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store { i64, [5 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load { i64, [5 x i64] }, ptr %t3
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t6, ptr %lp1
  %t8 = load ptr, ptr %lp1
  store { i64, [5 x i64] } %t5, ptr %t8
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/interp:Exec", ptr %t9, i32 0, i32 9
  store ptr %t11, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l13, !tbaa !24
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l15
  br label %bb3
bb3:
  %t17 = load i64, ptr %l13, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb26
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l20
  br label %bb7
bb7:
  %t28 = load i64, ptr %l20, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/interp:Exec", ptr %t29, i32 0, i32 1
  %t35 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t31, i64 %t28)
  store ptr %t35, ptr %l24
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 1
  %t39 = load { i64, [2 x i64] }, ptr %t38
  store { i64, [2 x i64] } %t39, ptr %l5
  %t41 = load { i64, [2 x i64] }, ptr %l5
  %t43 = extractvalue { i64, [2 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 6
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t47 = getelementptr { i64, i32 }, ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47
  store i64 %t48, ptr %l6, !tbaa !24
  %t50 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t51 = getelementptr { i64, i32 }, ptr %t50, i32 0, i32 1
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l7, !tbaa !23
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 4
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load i32, ptr %l7, !tbaa !23
  %t62 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v0, ptr %t56, i64 %t57, i32 %t58)
  store { i64, [5 x i64] } %t62, ptr %l35
  br label %bb12
bb12:
  %t63 = load { i64, [5 x i64] }, ptr %l35
  store { i64, [5 x i64] } %t63, ptr %l8
  %t64 = load { i64, [5 x i64] }, ptr %l8
  %t66 = extractvalue { i64, [5 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 0
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load ptr, ptr %lp1
  %t72 = load { i64, [5 x i64] }, ptr %t71
  %t74 = extractvalue { i64, [5 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 0
  store i1 %t75, ptr %l39, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l39, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t78 = load { i64, [5 x i64] }, ptr %l8
  %t80 = load ptr, ptr %lp1
  store { i64, [5 x i64] } %t78, ptr %t80
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fce8d31b7e62f371_71870e12b086bddd)
  unreachable
bb24:
  br label %bb25
bb25:
  %t81 = load i64, ptr %l3, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l3, !tbaa !24
  br label %bb2
bb26:
  %t85 = load ptr, ptr %lp1
  %t86 = load { i64, [5 x i64] }, ptr %t85
  store { i64, [5 x i64] } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { i32, i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInt(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, [5 x i64] }
  %l15 = alloca i64
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2erun(ptr %v0, ptr %v0, ptr %t1, i64 %a1)
  store { i64, [5 x i64] } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, [5 x i64] }, ptr %l5
  %t8 = extractvalue { i64, [5 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t14 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t14, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/interp:Exec", ptr %t15, i32 0, i32 4
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/interp:Exec", ptr %t18, i32 0, i32 4
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 10
  %t22 = load %"compiler/eval:Ptr", ptr %t21
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t17, %"compiler/eval:Ptr" %t22, i32 %a2)
  store i64 %t27, ptr %l15
  br label %bb5
bb5:
  %t28 = load i64, ptr %l15, !tbaa !24
  %t29 = insertvalue { i32, i64 } zeroinitializer, i64 %t28, 1
  store { i32, i64 } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca %"compiler/mir:Fn"
  %l6 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, [2 x i64] }
  %l18 = alloca i32
  %l22 = alloca i1
  %l36 = alloca i1
  %l43 = alloca %"compiler/mir:Fn"
  %l56 = alloca i1
  %s0 = alloca %olang.scope
  %t74 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l8
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2, { i64, [2 x i64] } %a1)
  br label %bb3
bb3:
  br label %bb4
bb4:
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2)
  store i64 %t9, ptr %l12
  br label %bb5
bb5:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb57
bb7:
  br label %bb8
bb8:
  %t16 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePop_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %l2)
  %t17 = extractvalue { i32, { i64, [2 x i64] } } %t16, 1
  %t18 = extractvalue { i32, { i64, [2 x i64] } } %t16, 0
  store i32 %t18, ptr %l18
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb10, label %ok.20, !prof !99
ok.20:
  store { i64, [2 x i64] } %t17, ptr %l17
  br label %bb9
bb9:
  %t21 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t21, ptr %l15
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  br label %bb57
bb12:
  %t22 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t22, ptr %l3
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/interp:Exec", ptr %t23, i32 0, i32 6
  %t26 = load { i64, [2 x i64] }, ptr %l3
  %t29 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t25, { i64, [2 x i64] } %t26)
  store i1 %t29, ptr %l22
  br label %bb13
bb13:
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb14, label %bb15
bb14:
  br label %bb56
bb15:
  br label %bb16
bb16:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/interp:Exec", ptr %t31, i32 0, i32 6
  %t34 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t33, { i64, [2 x i64] } %t34, i1 true)
  br label %bb17
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/interp:Exec", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %t39, !range !{i32 0, i32 2}
  %t42 = trunc i64 0 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb18, label %bb19
bb18:
  %t45 = load { i64, [2 x i64] }, ptr %l3
  %t47 = extractvalue { i64, [2 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 0
  br i1 %t48, label %bb20, label %bb21
bb19:
  br label %bb34
bb20:
  %t50 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t51 = getelementptr { i32 }, ptr %t50, i32 0, i32 0
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l4, !tbaa !23
  br label %bb22
bb21:
  br label %bb28
bb22:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 10
  %t57 = load i32, ptr %l4, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t62 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t56, i64 %t59)
  store i1 %t62, ptr %l36
  br label %bb23
bb23:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb24, label %bb25
bb24:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/interp:Exec", ptr %t64, i32 0, i32 5
  %t67 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t66, { i64, [2 x i64] } %t67)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb56
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_26fab0deca850fb9_a904bdf0227cd14d)
  unreachable
bb33:
  br label %bb34
bb34:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/interp:Exec", ptr %t70, i32 0, i32 3
  %t73 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t74, ptr %v0, ptr %v0, ptr %t72, { i64, [2 x i64] } %t73)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t74, i64 248, i1 false)
  br label %bb35
bb35:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l43, i64 248, i1 false)
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/interp:Exec", ptr %t77, i32 0, i32 3
  %t80 = getelementptr %"compiler/lower:Lowerer", ptr %t79, i32 0, i32 5
  %t81 = load i1, ptr %t80, !tbaa !21
  br i1 %t81, label %bb36, label %bb37
bb36:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/interp:Exec", ptr %t83, i32 0, i32 5
  %t86 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t85, { i64, [2 x i64] } %t86)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb56
bb39:
  %t89 = load { i64, [2 x i64] }, ptr %l3
  %t91 = extractvalue { i64, [2 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 0
  br i1 %t92, label %bb40, label %bb41
bb40:
  %t94 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t95 = getelementptr { i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l6, !tbaa !23
  br label %bb42
bb41:
  br label %bb48
bb42:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/interp:Exec", ptr %t98, i32 0, i32 11
  %t101 = load i32, ptr %l6, !tbaa !23
  %t103 = sext i32 %t101 to i64
  %t106 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t100, i64 %t103)
  store i1 %t106, ptr %l56
  br label %bb43
bb43:
  %t107 = load i1, ptr %l56, !tbaa !21
  br i1 %t107, label %bb44, label %bb45
bb44:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/interp:Exec", ptr %t108, i32 0, i32 4
  %t111 = getelementptr %"compiler/eval:Machine", ptr %t110, i32 0, i32 15
  %t112 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t111, { i64, [2 x i64] } %t112, i1 true)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_f78c9384d4051fe8_f87279dcad65e91c)
  unreachable
bb53:
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ereach(ptr %v0, ptr %v0, ptr %s0, ptr %t115, ptr %l5, ptr %l2)
  br label %bb54
bb54:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/interp:Exec", ptr %t119, i32 0, i32 4
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v0, ptr %t121, ptr %l5)
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb4
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca { i64, [5 x i64] }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, %"compiler/source:Span" }
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l24 = alloca { i64, [5 x i64] }
  %l28 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %l33 = alloca { i64, [5 x i64] }
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l63 = alloca i1
  %l66 = alloca { i64, %"compiler/source:Span" }
  %l74 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  %t17 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %s0, ptr %t1)
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l12
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t4, ptr %l2
  %t5 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l2, i32 0, i32 1
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @compiler_2finterp_2esayErr(ptr %s1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb5:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = trunc i64 %t13 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [2 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t20 = insertvalue { i32 } undef, i32 %t15, 0
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t17, i32 0, i32 1
  store { i32 } %t20, ptr %t21
  %t22 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t22, ptr %l4
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, [2 x i64] }, ptr %l4
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t24, { i64, [2 x i64] } %t25)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %s0, ptr %t28)
  store { i64, [5 x i64] } %t30, ptr %l24
  br label %bb7
bb7:
  %t31 = load { i64, [5 x i64] }, ptr %l24
  store { i64, [5 x i64] } %t31, ptr %l5
  %t32 = load { i64, [5 x i64] }, ptr %l5
  %t34 = extractvalue { i64, [5 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/interp:Exec", ptr %t37, i32 0, i32 4
  store ptr %t39, ptr %l28, !tbaa !29
  %t40 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t40, ptr %l29
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb10, label %bb11
bb9:
  br label %bb15
bb10:
  %t43 = icmp sle i64 0, 1152921504606846975
  br i1 %t43, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c21b7649f9083df0_c859438e5e055394)
  unreachable
bb12:
  %t45 = mul i64 0, 8
  %t46 = insertvalue { i64, ptr } undef, i64 0, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t49 = load { i64, [2 x i64] }, ptr %l29
  %t51 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %s0, ptr %t48, { i64, [2 x i64] } %t49, { i64, ptr } %t47)
  store { i64, [5 x i64] } %t51, ptr %l33
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c21b7649f9083df0_c859438e5e055394)
  unreachable
bb14:
  %t52 = load { i64, [5 x i64] }, ptr %l33
  store { i64, [5 x i64] } %t52, ptr %l5
  br label %bb15
bb15:
  %t53 = load { i64, [5 x i64] }, ptr %l5
  %t55 = extractvalue { i64, [5 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 0
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb19:
  %t59 = load { i64, [5 x i64] }, ptr %l5
  %t61 = extractvalue { i64, [5 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 1
  br i1 %t62, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb27
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load { i64, [5 x i64] }, ptr %l5
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t72 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s4, ptr %t64, { i64, [5 x i64] } %t65, i64 %t66, ptr %t67)
  store { i64, ptr } %t72, ptr %l43
  br label %bb23
bb23:
  %t73 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t74, i64 %t75)
  %t80 = getelementptr i8, ptr %t79, i64 %t75
  call void @olang_textcopy(ptr %t80, ptr %t76, i64 %t77)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  call void @compiler_2finterp_2esayErr(ptr %s4, { i64, ptr } %t89)
  br label %bb24
bb24:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t95 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %s4, ptr %t91, ptr %t92)
  store { i64, ptr } %t95, ptr %l48
  br label %bb25
bb25:
  %t96 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  call void @compiler_2finterp_2esayErr(ptr %s4, { i64, ptr } %t102)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb27:
  %t105 = load { i64, [5 x i64] }, ptr %l5
  %t107 = extractvalue { i64, [5 x i64] } %t105, 0
  %t108 = icmp eq i64 %t107, 3
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t110 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t111 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t110, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111
  store { i64, ptr } %t112, ptr %l6, !tbaa !27
  br label %bb30
bb29:
  br label %bb43
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, [5 x i64] }, ptr %l5
  %t116 = load i64, ptr %l3, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t122 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s6, ptr %t114, { i64, [5 x i64] } %t115, i64 %t116, ptr %t117)
  store { i64, ptr } %t122, ptr %l58
  br label %bb31
bb31:
  %t123 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t125 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = add i64 %t124, %t127
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t131 = add i64 %t128, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t123, i64 %t124)
  %t133 = getelementptr i8, ptr %t132, i64 %t124
  call void @olang_textcopy(ptr %t133, ptr %t126, i64 %t127)
  %t134 = getelementptr i8, ptr %t133, i64 %t127
  call void @olang_textcopy(ptr %t134, ptr %t129, i64 %t130)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } %t136, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  call void @compiler_2finterp_2esayErr(ptr %s6, { i64, ptr } %t143)
  br label %bb32
bb32:
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t146 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t147 = load ptr, ptr @__olang_prog_scope
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %t147, { i64, ptr } %t145, { i64, ptr } %t146)
  store i1 %t150, ptr %l63
  br label %bb33
bb33:
  %t151 = load i1, ptr %l63, !tbaa !21
  br i1 %t151, label %bb34, label %bb35
bb34:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/interp:Exec", ptr %t152, i32 0, i32 4
  %t156 = call { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %t154)
  store { i64, %"compiler/source:Span" } %t156, ptr %l66
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t157 = load { i64, %"compiler/source:Span" }, ptr %l66
  store { i64, %"compiler/source:Span" } %t157, ptr %l7
  %t158 = getelementptr { i64, %"compiler/source:Span" }, ptr %l7, i32 0, i32 0
  %t159 = load i64, ptr %t158, !tbaa !24
  store i64 %t159, ptr %l8, !tbaa !24
  %t161 = getelementptr { i64, %"compiler/source:Span" }, ptr %l7, i32 0, i32 1
  %t162 = load %"compiler/source:Span", ptr %t161
  store %"compiler/source:Span" %t162, ptr %l9
  %t164 = load i64, ptr %l8, !tbaa !24
  %t166 = icmp sge i64 %t164, 0
  br i1 %t166, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t169 = load i64, ptr %l8, !tbaa !24
  %t170 = load %"compiler/source:Span", ptr %l9
  %t174 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s9, ptr %t168, i64 %t169, %"compiler/source:Span" %t170)
  store { i64, ptr } %t174, ptr %l74
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t175 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t177 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t183 = add i64 %t180, %t182
  %t184 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t183)
  call void @olang_textcopy(ptr %t184, ptr %t175, i64 %t176)
  %t185 = getelementptr i8, ptr %t184, i64 %t176
  call void @olang_textcopy(ptr %t185, ptr %t178, i64 %t179)
  %t186 = getelementptr i8, ptr %t185, i64 %t179
  call void @olang_textcopy(ptr %t186, ptr %t181, i64 %t182)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t184, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = extractvalue { i64, ptr } %t188, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  call void @compiler_2finterp_2esayErr(ptr %s9, { i64, ptr } %t195)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb43:
  %t198 = load { i64, [5 x i64] }, ptr %l5
  %t200 = extractvalue { i64, [5 x i64] } %t198, 0
  %t201 = icmp eq i64 %t200, 2
  br i1 %t201, label %bb44, label %bb45
bb44:
  %t203 = getelementptr { i64, [5 x i64] }, ptr %l5, i32 0, i32 1
  %t204 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t203, i32 0, i32 0
  %t205 = load i32, ptr %t204, !range !{i32 0, i32 15}
  store i32 %t205, ptr %l10
  br label %bb46
bb45:
  br label %bb54
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load { i64, [5 x i64] }, ptr %l5
  %t209 = load i64, ptr %l3, !tbaa !24
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t215 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s11, ptr %t207, { i64, [5 x i64] } %t208, i64 %t209, ptr %t210)
  store { i64, ptr } %t215, ptr %l85
  br label %bb47
bb47:
  %t216 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t217, i64 %t218)
  %t223 = getelementptr i8, ptr %t222, i64 %t218
  call void @olang_textcopy(ptr %t223, ptr %t219, i64 %t220)
  %t224 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t222, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } %t225, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  call void @compiler_2finterp_2esayErr(ptr %s11, { i64, ptr } %t232)
  br label %bb48
bb48:
  %t234 = load i32, ptr %l10, !range !{i32 0, i32 15}
  %t236 = trunc i64 13 to i32
  %t237 = icmp eq i32 %t234, %t236
  br i1 %t237, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s13
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t243 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %s13, ptr %t239, ptr %t240)
  store { i64, ptr } %t243, ptr %l92
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t244 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  call void @compiler_2finterp_2esayErr(ptr %s13, { i64, ptr } %t250)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s13)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 134, ptr %rv
  br label %ret
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb60
bb57:
  store %olang.scope zeroinitializer, ptr %s14
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load { i64, [5 x i64] }, ptr %l5
  %t255 = load i64, ptr %l3, !tbaa !24
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t261 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %s0, ptr %v1, ptr %s14, ptr %t253, { i64, [5 x i64] } %t254, i64 %t255, ptr %t256)
  store { i64, ptr } %t261, ptr %l99
  br label %bb58
bb58:
  %t262 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t267 = add i64 %t264, %t266
  %t268 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t263, i64 %t264)
  %t269 = getelementptr i8, ptr %t268, i64 %t264
  call void @olang_textcopy(ptr %t269, ptr %t265, i64 %t266)
  %t270 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t268, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = extractvalue { i64, ptr } %t271, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  call void @compiler_2finterp_2esayErr(ptr %s14, { i64, ptr } %t278)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  store i32 134, ptr %rv
  br label %ret
bb60:
  call void @__olang_check_failed(ptr @olang_loc_736b533d144489ee_c645810c81b1a7fa)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunTests(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca [0 x i64]
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, [5 x i64] }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l36 = alloca { i64, [5 x i64] }
  %l39 = alloca i64
  %l41 = alloca i64
  %l46 = alloca i64
  %l49 = alloca { i64, ptr }
  %l58 = alloca { i64, [5 x i64] }
  %l72 = alloca { i64, ptr }
  %l74 = alloca i1
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  %t30 = alloca { i64, [2 x i64] }, align 8
  %t76 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eEntries(ptr %v0, ptr %s0, ptr %t1)
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l17
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 } %t4, ptr %l2
  %t5 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }, ptr %l2, i32 0, i32 0
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t5
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %l20, !tbaa !24
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t10)
  store i64 %t12, ptr %l22
  br label %bb3
bb3:
  %t13 = load i64, ptr %l20, !tbaa !24
  %t14 = load i64, ptr %l22, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l27
  br label %bb7
bb7:
  %t24 = load i64, ptr %l27, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = trunc i64 %t24 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 0
  store i64 0, ptr %t31
  %t33 = insertvalue { i32 } undef, i32 %t28, 0
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 1
  store { i32 } %t33, ptr %t34
  %t35 = load { i64, [2 x i64] }, ptr %t30
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t25, { i64, [2 x i64] } %t35)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l5, !tbaa !24
  br label %bb2
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %s0, ptr %t42)
  store { i64, [5 x i64] } %t44, ptr %l36
  br label %bb11
bb11:
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  store [0 x i64] zeroinitializer, ptr %l9
  store ptr %l3, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l11, !tbaa !24
  store i64 %t47, ptr %l39, !tbaa !24
  %t48 = load ptr, ptr %l10, !tbaa !29
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t48)
  store i64 %t50, ptr %l41
  br label %bb13
bb13:
  %t51 = load i64, ptr %l39, !tbaa !24
  %t52 = load i64, ptr %l41, !tbaa !24
  %t53 = icmp slt i64 %t51, %t52
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l10, !tbaa !29
  %t58 = load i64, ptr %l11, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l46
  br label %bb17
bb17:
  %t62 = load i64, ptr %l46, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i64, ptr %l12, !tbaa !24
  %t67 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTestName(ptr %v0, ptr %s5, ptr %t63, i64 %t64)
  store { i64, ptr } %t67, ptr %l49
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t68, ptr %l13, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t69, i32 0, i32 4
  %t72 = load i64, ptr %l12, !tbaa !24
  %t74 = trunc i64 %t72 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t76, i32 0, i32 0
  store i64 0, ptr %t77
  %t79 = insertvalue { i32 } undef, i32 %t74, 0
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t76, i32 0, i32 1
  store { i32 } %t79, ptr %t80
  %t81 = load { i64, [2 x i64] }, ptr %t76
  %t83 = insertvalue { i64, ptr } undef, i64 0, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %l9, 1
  %t88 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %v0, ptr %t71, { i64, [2 x i64] } %t81, { i64, ptr } %t84)
  store { i64, [5 x i64] } %t88, ptr %l58
  br label %bb19
bb19:
  %t89 = load { i64, [5 x i64] }, ptr %l58
  store { i64, [5 x i64] } %t89, ptr %l14
  %t90 = load { i64, [5 x i64] }, ptr %l14
  %t92 = extractvalue { i64, [5 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t100 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t103 = extractvalue { i64, ptr } %t99, 1
  %t104 = extractvalue { i64, ptr } %t99, 0
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t100, i64 %t101)
  %t110 = getelementptr i8, ptr %t109, i64 %t101
  call void @olang_textcopy(ptr %t110, ptr %t103, i64 %t104)
  %t111 = getelementptr i8, ptr %t110, i64 %t104
  call void @olang_textcopy(ptr %t111, ptr %t106, i64 %t107)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t109, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } %t113, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  call void @compiler_2finterp_2esay(ptr %s6, { i64, ptr } %t120)
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l8, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, [5 x i64] }, ptr %l14
  %t128 = load i64, ptr %l12, !tbaa !24
  %t134 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %v0, ptr %v1, ptr %s8, ptr %t126, { i64, [5 x i64] } %t127, i64 %t128, ptr %a1)
  store { i64, ptr } %t134, ptr %l72
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb23:
  %t135 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t135, ptr %l15, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s8, { i64, ptr } %t136, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t138, ptr %l74
  br label %bb24
bb24:
  %t139 = load i1, ptr %l74, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t142 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t144, i64 %t145)
  %t150 = getelementptr i8, ptr %t149, i64 %t145
  call void @olang_textcopy(ptr %t150, ptr %t146, i64 %t147)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t149, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  call void @compiler_2finterp_2esay(ptr %s9, { i64, ptr } %t159)
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  %t161 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t162 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t165 = extractvalue { i64, ptr } %t161, 1
  %t166 = extractvalue { i64, ptr } %t161, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t162, i64 %t163)
  %t172 = getelementptr i8, ptr %t171, i64 %t163
  call void @olang_textcopy(ptr %t172, ptr %t165, i64 %t166)
  %t173 = getelementptr i8, ptr %t172, i64 %t166
  call void @olang_textcopy(ptr %t173, ptr %t168, i64 %t169)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t171, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @compiler_2finterp_2esay(ptr %s8, { i64, ptr } %t182)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t184 = load i64, ptr %l11, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l11, !tbaa !24
  br label %bb12
bb32:
  %t188 = load i64, ptr %l7, !tbaa !24
  %t189 = load i64, ptr %l8, !tbaa !24
  %t191 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t192 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t196 = call i64 @__olang_fmt_i64(ptr null, i64 %t189)
  %t197 = add i64 %t194, %t196
  %t198 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t200 = add i64 %t197, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t200)
  %t202 = call i64 @__olang_fmt_i64(ptr %t201, i64 %t188)
  %t203 = getelementptr i8, ptr %t201, i64 %t191
  call void @olang_textcopy(ptr %t203, ptr %t192, i64 %t193)
  %t204 = getelementptr i8, ptr %t203, i64 %t193
  %t205 = call i64 @__olang_fmt_i64(ptr %t204, i64 %t189)
  %t206 = getelementptr i8, ptr %t204, i64 %t196
  call void @olang_textcopy(ptr %t206, ptr %t198, i64 %t199)
  %t207 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t201, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = extractvalue { i64, ptr } %t208, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  call void @compiler_2finterp_2esay(ptr %s0, { i64, ptr } %t215)
  br label %bb33
bb33:
  %t217 = load i64, ptr %l8, !tbaa !24
  %t219 = icmp sgt i64 %t217, 0
  br i1 %t219, label %bb34, label %bb35
bb34:
  store i32 1, ptr %l90, !tbaa !23
  br label %bb36
bb35:
  store i32 0, ptr %l90, !tbaa !23
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t221 = load i32, ptr %l90, !tbaa !23
  store i32 %t221, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [5 x i64] } %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [5 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l31 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [5 x i64] } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb6
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/interp:Exec", ptr %t12, i32 0, i32 1
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t14, i64 %a2)
  store ptr %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t23 = load ptr, ptr %l9, !tbaa !29
  %t24 = load i64, ptr %l10, !tbaa !24
  %t26 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eerrorName(ptr %v0, ptr %s1, ptr %t23, i64 %t24, i32 %t22)
  store { i64, ptr } %t26, ptr %l17
  br label %bb5
bb5:
  %t27 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t27, i64 %t28)
  %t34 = getelementptr i8, ptr %t33, i64 %t28
  call void @olang_textcopy(ptr %t34, ptr %t30, i64 %t31)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb6:
  %t38 = load { i64, [5 x i64] }, ptr %l1
  %t40 = extractvalue { i64, [5 x i64] } %t38, 0
  %t41 = icmp eq i64 %t40, 3
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = getelementptr { i64, [5 x i64] }, ptr %l1, i32 0, i32 1
  %t44 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t43, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  br label %bb9
bb8:
  br label %bb20
bb9:
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWaits, !tbaa !27
  %t49 = load ptr, ptr @__olang_prog_scope
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %t49, { i64, ptr } %t47, { i64, ptr } %t48)
  store i1 %t52, ptr %l24
  br label %bb10
bb10:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/interp:Exec", ptr %t54, i32 0, i32 4
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 79
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = icmp sge i64 %t58, 0
  store i1 %t60, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l25, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load { i64, [5 x i64] }, ptr %l1
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %s4, { i64, [5 x i64] } %t63, ptr %t64)
  store { i64, ptr } %t67, ptr %l31
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t69, i32 0, i32 4
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 79
  %t73 = load i64, ptr %t72, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/interp:Exec", ptr %t74, i32 0, i32 4
  %t77 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 80
  %t78 = load %"compiler/source:Span", ptr %t77
  %t82 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v2, ptr %s4, ptr %t68, i64 %t73, %"compiler/source:Span" %t78)
  store { i64, ptr } %t82, ptr %l37
  br label %bb17
bb17:
  %t83 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t84, i64 %t85)
  %t94 = getelementptr i8, ptr %t93, i64 %t85
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = getelementptr i8, ptr %t94, i64 %t87
  call void @olang_textcopy(ptr %t95, ptr %t90, i64 %t91)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb18:
  %t99 = load { i64, [5 x i64] }, ptr %l1
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t103 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %v3, { i64, [5 x i64] } %t99, ptr %t100)
  store { i64, ptr } %t103, ptr %l41
  br label %bb19
bb19:
  %t104 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t105 = load { i64, [5 x i64] }, ptr %l1
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t109 = call { i64, ptr } @compiler_2finterp_2eStopText(ptr %v1, ptr %v2, ptr %v3, { i64, [5 x i64] } %t105, ptr %t106)
  store { i64, ptr } %t109, ptr %l44
  br label %bb24
bb24:
  %t110 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_177aae49e1a91f38_175ec48f508568b4)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTestName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l40 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/interp:Exec", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %t19)
  store ptr %t22, ptr %l12
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l12, !tbaa !29
  store ptr %t23, ptr %l2, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 8
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l14, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/interp:Exec", ptr %t28, i32 0, i32 1
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %a1)
  store ptr %t34, ptr %l18
  br label %bb2
bb2:
  %t35 = load ptr, ptr %l18, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 4
  %t38 = load %"compiler/source:Span", ptr %t37
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t41 = call ptr @compiler_2fast_2eFindTest(ptr %v0, { i64, ptr } %t39, %"compiler/source:Span" %t38)
  store ptr %t41, ptr %l21
  br label %bb3
bb3:
  %t42 = load ptr, ptr %l21, !tbaa !29
  store ptr %t42, ptr %l3, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l26, !tbaa !24
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l26, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t61, ptr %l25, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l3, !tbaa !29
  store ptr %t63, ptr %l28, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 6
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_eb59e3d17e209b69_67e25fc5a7a9951d)
  unreachable
bb8:
  br label %bb9
bb9:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 6
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = getelementptr %"compiler/source:Source", ptr %t74, i32 0, i32 1
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/interp:Exec", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/load:Loader", ptr %t85, i32 0, i32 3
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load ptr, ptr %l28, !tbaa !29
  %t92 = call { i64, ptr } @compiler_2fast_2eTestLabel(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %t89, { i64, ptr } %t78, ptr %t88)
  store { i64, ptr } %t92, ptr %l40
  br label %bb10
bb10:
  %t93 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca { i64, [5 x i64] }
  %l18 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t6 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t6, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2erun(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store { i64, [5 x i64] } %t11, ptr %l7
  br label %bb4
bb4:
  %t12 = load { i64, [5 x i64] }, ptr %l7
  %t14 = extractvalue { i64, [5 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 0
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/interp:Exec", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/interp:Exec", ptr %t24, i32 0, i32 4
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 10
  %t28 = load %"compiler/eval:Ptr", ptr %t27
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/interp:Exec", ptr %t29, i32 0, i32 4
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 11
  %t33 = load i32, ptr %t32, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %t23, %"compiler/eval:Ptr" %t28, i32 %t33)
  store { i64, ptr } %t37, ptr %l18
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t38, 1
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i64
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/interp:Exec", ptr %t3, i32 0, i32 4
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 77
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/interp:Exec", ptr %t11, i32 0, i32 4
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 77
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %t15)
  %t20 = add i64 %t17, %t19
  %t21 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t16, i64 %t17)
  %t25 = getelementptr i8, ptr %t24, i64 %t17
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %t15)
  %t27 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } %t36)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  store i64 0, ptr %l3, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/interp:Exec", ptr %t39, i32 0, i32 4
  %t43 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l25
  br label %bb6
bb6:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb12
bb9:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l32, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t71 = load i64, ptr %l32, !tbaa !24
  store i64 %t71, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t72 = load i64, ptr %l29, !tbaa !24
  store i64 %t72, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb15:
  br label %bb16
bb16:
  %t81 = load i64, ptr %l3, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l8, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/interp:Exec", ptr %t91, i32 0, i32 4
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = call { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %t93, i64 %t94)
  store { i64, i64, i64 } %t97, ptr %l53
  br label %bb17
bb17:
  %t98 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t98, ptr %l9
  %t99 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 0
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l10, !tbaa !24
  %t102 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l11, !tbaa !24
  %t105 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 2
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp eq i64 %t108, 0
  br i1 %t110, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb23
bb19:
  %t112 = load i64, ptr %l12, !tbaa !24
  %t114 = icmp eq i64 %t112, 1
  br i1 %t114, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb22
bb22:
  %t116 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t116, ptr %l59, !tbaa !27
  br label %bb23
bb23:
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t117, ptr %l13, !tbaa !27
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/interp:Exec", ptr %t118, i32 0, i32 4
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceWhat(ptr %v0, ptr %t120, i64 %t121)
  store { i64, ptr } %t124, ptr %l66
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb25, label %bb26
bb25:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/interp:Exec", ptr %t130, i32 0, i32 4
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceWhat(ptr %v0, ptr %t132, i64 %t133)
  store { i64, ptr } %t136, ptr %l72
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t137 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = load ptr, ptr @__olang_prog_scope
  %t141 = call ptr @__olang_scope_alloc(ptr %t140, i64 %t139)
  call void @olang_textcopy(ptr %t141, ptr %t138, i64 %t139)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = load ptr, ptr @__olang_prog_scope
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = extractvalue { i64, ptr } %t143, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %t145, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l13, !tbaa !27
  br label %bb28
bb28:
  store ptr %l2, ptr %l75, !tbaa !29
  store ptr %a1, ptr %l76, !tbaa !29
  %t154 = load i64, ptr %l10, !tbaa !24
  store i64 %t154, ptr %l77, !tbaa !24
  %t155 = load i64, ptr %l11, !tbaa !24
  %t157 = trunc i64 %t155 to i32
  %t158 = load i64, ptr %l11, !tbaa !24
  %t160 = trunc i64 %t158 to i32
  %t163 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t157, i32 %t160)
  store %"compiler/source:Span" %t163, ptr %l82
  br label %bb29
bb29:
  %t164 = load ptr, ptr %l76, !tbaa !29
  %t165 = load i64, ptr %l77, !tbaa !24
  %t166 = load %"compiler/source:Span", ptr %l82
  %t167 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v1, ptr %s4, ptr %t164, i64 %t165, %"compiler/source:Span" %t166)
  store { i64, ptr } %t167, ptr %l83
  br label %bb30
bb30:
  %t168 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t176 = extractvalue { i64, ptr } %t168, 1
  %t177 = extractvalue { i64, ptr } %t168, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t170, i64 %t171)
  %t183 = getelementptr i8, ptr %t182, i64 %t171
  call void @olang_textcopy(ptr %t183, ptr %t172, i64 %t173)
  %t184 = getelementptr i8, ptr %t183, i64 %t173
  call void @olang_textcopy(ptr %t184, ptr %t176, i64 %t177)
  %t185 = getelementptr i8, ptr %t184, i64 %t177
  call void @olang_textcopy(ptr %t185, ptr %t179, i64 %t180)
  %t186 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t182, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = extractvalue { i64, ptr } %t187, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t195 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t195, { i64, ptr } %t194)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t197 = load i64, ptr %l7, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l7, !tbaa !24
  br label %bb13
bb33:
  %t202 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t202, ptr %l90
  br label %bb34
bb34:
  %t203 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t203, ptr %l91, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  store i64 %t205, ptr %l92, !tbaa !24
  %t206 = load i64, ptr %l92, !tbaa !24
  %t207 = mul i64 %t206, 1
  %t208 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  store { i64, ptr } %t210, ptr %l93, !tbaa !27
  %t211 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = load i64, ptr %l92, !tbaa !24
  %t216 = mul i64 %t215, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t212, ptr %t214, i64 %t216, i1 false)
  %t217 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t217, ptr %l91, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t218 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t218, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"compiler/eval:Image" } @compiler_2finterp_2ecompiler_2finterp_3aExec_2ebakeMutable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %lp3 = alloca ptr
  %l4 = alloca %"compiler/eval:Image"
  %l9 = alloca %"compiler/eval:Image"
  %l10 = alloca i32
  %l13 = alloca i64
  %l15 = alloca i1
  %l17 = alloca %"compiler/eval:Blob"
  %l19 = alloca i64
  %rv = alloca { i32, %"compiler/eval:Image" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/interp:Exec", ptr %a0, i32 0, i32 4
  %t9 = call { i32, %"compiler/eval:Image" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eImage(ptr %v0, ptr %v1, ptr %t3, i64 %a1, i32 %a2, i1 true)
  %t10 = extractvalue { i32, %"compiler/eval:Image" } %t9, 1
  %t11 = extractvalue { i32, %"compiler/eval:Image" } %t9, 0
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13, !prof !99
ok.13:
  store %"compiler/eval:Image" %t10, ptr %l9
  br label %bb1
bb1:
  %t14 = load %"compiler/eval:Image", ptr %l9
  store %"compiler/eval:Image" %t14, ptr %l4
  br label %bb3
bb2:
  %t15 = load i32, ptr %l10, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, i32 %t23, 0
  store { i32, %"compiler/eval:Image" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store ptr %t26, ptr %lp3
  %t27 = load %"compiler/eval:Image", ptr %l4
  %t28 = load ptr, ptr %lp3
  store %"compiler/eval:Image" %t27, ptr %t28
  %t29 = load ptr, ptr %lp3
  %t30 = getelementptr %"compiler/eval:Image", ptr %t29, i32 0, i32 0
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %t30)
  store i64 %t32, ptr %l13
  br label %bb4
bb4:
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = icmp ne i64 %t33, 1
  br i1 %t34, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb9
bb6:
  %t36 = load ptr, ptr %lp3
  %t37 = getelementptr %"compiler/eval:Image", ptr %t36, i32 0, i32 0
  %t39 = call %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t37, i64 0)
  store %"compiler/eval:Blob" %t39, ptr %l17
  br label %bb7
bb7:
  %t40 = getelementptr %"compiler/eval:Blob", ptr %l17, i32 0, i32 3
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t40)
  store i64 %t42, ptr %l19
  br label %bb8
bb8:
  %t43 = load i64, ptr %l19, !tbaa !24
  %t44 = icmp ne i64 %t43, 0
  store i1 %t44, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l15, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/eval:Image" } %t48, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t49 = load ptr, ptr %lp3
  %t50 = getelementptr %"compiler/eval:Image", ptr %t49, i32 0, i32 2
  store i1 true, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %lp3
  %t52 = load %"compiler/eval:Image", ptr %t51
  %t54 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, %"compiler/eval:Image" %t52, 1
  store { i32, %"compiler/eval:Image" } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/eval:Image" }, ptr %rv
  ret { i32, %"compiler/eval:Image" } %rr
}

define dso_local i1 @compiler_2finterp_2ecompiler_2finterp_3aExec_2ebuildDefault(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca i1
  %l35 = alloca i32
  %l40 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/interp:Exec", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 5
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t12, i64 %a1)
  store ptr %t16, ptr %l16
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = getelementptr %"compiler/load:Module", ptr %t18, i32 0, i32 3
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t28, ptr %l22
  br label %bb7
bb7:
  %t29 = load i1, ptr %l22, !tbaa !21
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t33 = insertvalue [5 x { i64, ptr }] %t32, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t34 = insertvalue [5 x { i64, ptr }] %t33, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d77, i32 0, i32 1) }, 2
  %t35 = insertvalue [5 x { i64, ptr }] %t34, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d78, i32 0, i32 1) }, 3
  %t36 = insertvalue [5 x { i64, ptr }] %t35, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d79, i32 0, i32 1) }, 4
  %t38 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 80, i64 8)
  store [5 x { i64, ptr }] %t36, ptr %t38
  store ptr %t38, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t40 = load ptr, ptr %l5
  store i64 5, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l5
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr [5 x { i64, ptr }], ptr %t51, i64 0, i64 %t52
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !37
  %t58 = load i32, ptr %l2, !tbaa !23
  store i32 %t58, ptr %l35, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/interp:Exec", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t66 = load ptr, ptr @__olang_prog_scope
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %t66, ptr %t64, { i64, ptr } %t56)
  store i32 %t69, ptr %l40
  br label %bb16
bb16:
  %t70 = load i32, ptr %l35, !tbaa !23
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = icmp eq i32 %t70, %t71
  br i1 %t72, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb12
bb21:
  call void @__olang_scope_close(ptr %s3)
  %t79 = load i32, ptr %l2, !tbaa !23
  store i32 %t79, ptr %l45, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/interp:Exec", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t83, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d80, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i32 %t85, ptr %l48
  br label %bb22
bb22:
  %t86 = load i32, ptr %l45, !tbaa !23
  %t87 = load i32, ptr %l48, !tbaa !23
  %t88 = icmp eq i32 %t86, %t87
  call void @__olang_scope_close(ptr %s0)
  store i1 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v1, ptr %a0, { i64, [7 x i64] } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  store { i64, [2 x i64] } %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load { i64, [2 x i64] }, ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v1, ptr %a2, { i64, [2 x i64] } %t11)
  br label %bb4
bb4:
  br label %bb27
bb5:
  %t14 = load { i64, [7 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [7 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i64, i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb8
bb7:
  br label %bb20
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/interp:Exec", ptr %t23, i32 0, i32 8
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t25, i64 %t26)
  store i1 %t29, ptr %l17
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/interp:Exec", ptr %t33, i32 0, i32 8
  %t36 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t35, i64 %t36, i1 true)
  br label %bb12
bb11:
  br label %bb19
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/interp:Exec", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t42, i64 %t43)
  store ptr %t46, ptr %l25
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l25, !tbaa !29
  store ptr %t47, ptr %l5, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/interp:Exec", ptr %t48, i32 0, i32 4
  store ptr %t50, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l28, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/interp:Exec", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExternSymbol(ptr %v0, ptr %s3, ptr %t55, i64 %t56)
  store { i64, ptr } %t59, ptr %l32
  br label %bb14
bb14:
  %t60 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l33, !tbaa !27
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Func", ptr %t67, i32 0, i32 3
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Sig", ptr %t70, i32 0, i32 7
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Func", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Sig", ptr %t78, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l37, !tbaa !24
  br label %bb17
bb16:
  store i64 -1, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t85 = load ptr, ptr %l27, !tbaa !29
  %t86 = load i64, ptr %l28, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t88 = load i64, ptr %l37, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %s3, ptr %t85, i64 %t86, { i64, ptr } %t87, i64 %t88)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t89 = load { i64, [7 x i64] }, ptr %l1
  %t91 = extractvalue { i64, [7 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 2
  br i1 %t92, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  %t94 = load { i64, [7 x i64] }, ptr %l1
  %t96 = extractvalue { i64, [7 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 3
  br i1 %t97, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_6b327bc23f54125b_df118949941dcc1f)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eerrorName(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l10 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l22 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca i32
  %l40 = alloca i32
  %l45 = alloca i64
  %l51 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/interp:Exec", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t12, i32 %a2)
  store i32 %t16, ptr %l15
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l16
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = ashr i64 %t21, 16
  %t25 = sub i64 %t23, 1
  store i64 %t25, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb5
bb4:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp sge i64 %t31, %t34
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb5
bb5:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t40)
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = getelementptr i8, ptr %t46, i64 %t42
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t40)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/interp:Exec", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t57, i32 %t64)
  store i32 %t67, ptr %l35
  br label %bb9
bb9:
  %t68 = load i32, ptr %l35, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t74, i32 %t68)
  store i32 %t78, ptr %l40
  br label %bb10
bb10:
  %t79 = load i32, ptr %l40, !tbaa !23
  store i32 %t79, ptr %l6, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/interp:Exec", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l6, !tbaa !23
  %t89 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t85, i32 %t86)
  store i64 %t89, ptr %l45
  br label %bb11
bb11:
  %t90 = load i64, ptr %l45, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/interp:Exec", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 0
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/load:Loader", ptr %t97, i32 0, i32 5
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t99, i64 %t100)
  store ptr %t103, ptr %l51
  br label %bb12
bb12:
  %t104 = load ptr, ptr %l51, !tbaa !29
  %t106 = getelementptr %"compiler/load:Module", ptr %t104, i32 0, i32 2
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l7, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/interp:Exec", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 7
  %t118 = load i64, ptr %t117, !tbaa !24
  %t121 = icmp eq i64 %t108, %t118
  %t124 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s0, { i64, ptr } %t107, i1 %t121)
  store { i64, ptr } %t124, ptr %l60
  br label %bb13
bb13:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/interp:Exec", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t129 = load i32, ptr %l6, !tbaa !23
  %t130 = load i64, ptr %l1, !tbaa !24
  %t132 = and i64 %t130, 65535
  %t136 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %s0, ptr %t128, i32 %t129, i64 %t132)
  store { i64, ptr } %t136, ptr %l66
  br label %bb14
bb14:
  %t137 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t138, i64 %t139)
  %t145 = getelementptr i8, ptr %t144, i64 %t139
  call void @olang_textcopy(ptr %t145, ptr %t141, i64 %t142)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t147, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eintOf(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l11 = alloca ptr
  %l12 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [5 x i64] }
  %l26 = alloca i64
  %rv = alloca { i32, i64 }
  %t5 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a1 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t10, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 4
  store ptr %t18, ptr %l11, !tbaa !29
  %t19 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t19, ptr %l12
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_4dbbfc1aefa6e21c_e99ccf60d5e11690)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t27 = load ptr, ptr %l11, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l12
  %t30 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t27, { i64, [2 x i64] } %t28, { i64, ptr } %t26)
  store { i64, [5 x i64] } %t30, ptr %l16
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4dbbfc1aefa6e21c_e99ccf60d5e11690)
  unreachable
bb6:
  %t31 = load { i64, [5 x i64] }, ptr %l16
  %t33 = extractvalue { i64, [5 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 0
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t39 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t39, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/interp:Exec", ptr %t40, i32 0, i32 4
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/interp:Exec", ptr %t43, i32 0, i32 4
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 10
  %t47 = load %"compiler/eval:Ptr", ptr %t46
  %t52 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %t42, %"compiler/eval:Ptr" %t47, i32 %a2)
  store i64 %t52, ptr %l26
  br label %bb10
bb10:
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = insertvalue { i32, i64 } zeroinitializer, i64 %t53, 1
  store { i32, i64 } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:Call"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/mir:Task"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/mir:BasicBlock"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, [21 x i64] }
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca %"compiler/mir:Range"
  %l17 = alloca { i64, [4 x i64] }
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca { i64, [2 x i64] }
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca %"compiler/mir:Call"
  %l39 = alloca i64
  %l41 = alloca i64
  %l46 = alloca %"compiler/mir:Task"
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/mir:BasicBlock"
  %l63 = alloca i64
  %l65 = alloca i64
  %l70 = alloca { i64, [21 x i64] }
  %l71 = alloca { i64, [21 x i64] }
  %l73 = alloca i1
  %l79 = alloca { i64, [21 x i64] }
  %l81 = alloca i1
  %l84 = alloca i1
  %l93 = alloca { i64, [4 x i64] }
  %l100 = alloca { i64, [21 x i64] }
  %l103 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %t207 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 14
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l24, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l26
  br label %bb2
bb2:
  %t9 = load i64, ptr %l24, !tbaa !24
  %t10 = load i64, ptr %l26, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/mir:Call" %t19, ptr %l31
  br label %bb6
bb6:
  %t20 = load %"compiler/mir:Call", ptr %l31
  store %"compiler/mir:Call" %t20, ptr %l5
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/mir:Call", ptr %l5, i32 0, i32 0
  %t23 = load { i64, [7 x i64] }, ptr %t22
  %t24 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v2, ptr %t21, { i64, [7 x i64] } %t23, ptr %t24)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb1
bb9:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/mir:Fn", ptr %t32, i32 0, i32 16
  store ptr %t34, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l7, !tbaa !24
  store i64 %t36, ptr %l39, !tbaa !24
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v1, ptr %t37)
  store i64 %t39, ptr %l41
  br label %bb11
bb11:
  %t40 = load i64, ptr %l39, !tbaa !24
  %t41 = load i64, ptr %l41, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v1, ptr %t46, i64 %t47)
  store %"compiler/mir:Task" %t50, ptr %l46
  br label %bb15
bb15:
  %t51 = load %"compiler/mir:Task", ptr %l46
  store %"compiler/mir:Task" %t51, ptr %l8
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/mir:Task", ptr %l8, i32 0, i32 0
  %t54 = load { i64, [7 x i64] }, ptr %t53
  %t55 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ecallee(ptr %v0, ptr %v2, ptr %t52, { i64, [7 x i64] } %t54, ptr %t55)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l7, !tbaa !24
  br label %bb10
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/mir:Fn", ptr %t63, i32 0, i32 9
  store ptr %t65, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t67 = load i64, ptr %l10, !tbaa !24
  store i64 %t67, ptr %l54, !tbaa !24
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v1, ptr %t68)
  store i64 %t70, ptr %l56
  br label %bb20
bb20:
  %t71 = load i64, ptr %l54, !tbaa !24
  %t72 = load i64, ptr %l56, !tbaa !24
  %t73 = icmp slt i64 %t71, %t72
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb21, label %bb22
bb21:
  br label %bb81
bb22:
  br label %bb23
bb23:
  %t77 = load ptr, ptr %l9, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v1, ptr %v1, ptr %t77, i64 %t78)
  store %"compiler/mir:BasicBlock" %t81, ptr %l61
  br label %bb24
bb24:
  %t82 = load %"compiler/mir:BasicBlock", ptr %l61
  store %"compiler/mir:BasicBlock" %t82, ptr %l11
  %t83 = getelementptr %"compiler/mir:BasicBlock", ptr %l11, i32 0, i32 0
  store ptr %t83, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t85 = load i64, ptr %l13, !tbaa !24
  store i64 %t85, ptr %l63, !tbaa !24
  %t86 = load ptr, ptr %l12, !tbaa !29
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t86)
  store i64 %t88, ptr %l65
  br label %bb26
bb26:
  %t89 = load i64, ptr %l63, !tbaa !24
  %t90 = load i64, ptr %l65, !tbaa !24
  %t91 = icmp slt i64 %t89, %t90
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb27, label %bb28
bb27:
  br label %bb79
bb28:
  br label %bb29
bb29:
  %t95 = load ptr, ptr %l12, !tbaa !29
  %t96 = load i64, ptr %l13, !tbaa !24
  %t99 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t95, i64 %t96)
  store { i64, [21 x i64] } %t99, ptr %l70
  br label %bb30
bb30:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l70, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %l14, i64 176, i1 false)
  %t100 = load { i64, [21 x i64] }, ptr %l71
  %t101 = extractvalue { i64, [21 x i64] } %t100, 0
  %t102 = icmp eq i64 %t101, 0
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t104, i32 0, i32 2
  %t106 = load { i64, [15 x i64] }, ptr %t105
  %t108 = extractvalue { i64, [15 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 10
  store i1 %t109, ptr %l73, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t111 = load i1, ptr %l73, !tbaa !21
  br i1 %t111, label %bb34, label %bb35
bb34:
  %t112 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t112, i32 0, i32 2
  %t114 = getelementptr { i64, [15 x i64] }, ptr %t113, i32 0, i32 1
  %t115 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t114, i32 0, i32 0
  %t116 = load { i64, [2 x i64] }, ptr %t115
  store { i64, [2 x i64] } %t116, ptr %l15
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t119 = load { i64, [2 x i64] }, ptr %l15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v2, ptr %t118, { i64, [2 x i64] } %t119)
  br label %bb37
bb37:
  br label %bb77
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %l14, i64 176, i1 false)
  %t122 = load { i64, [21 x i64] }, ptr %l79
  %t123 = extractvalue { i64, [21 x i64] } %t122, 0
  %t124 = icmp eq i64 %t123, 0
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t126 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t126, i32 0, i32 2
  %t128 = load { i64, [15 x i64] }, ptr %t127
  %t130 = extractvalue { i64, [15 x i64] } %t128, 0
  %t131 = icmp eq i64 %t130, 3
  br i1 %t131, label %bb41, label %bb42
bb40:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb44
bb41:
  %t133 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t133, i32 0, i32 2
  %t135 = getelementptr { i64, [15 x i64] }, ptr %t134, i32 0, i32 1
  %t136 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t135, i32 0, i32 0
  %t137 = load i32, ptr %t136, !range !{i32 0, i32 43}
  %t139 = trunc i64 40 to i32
  %t140 = icmp eq i32 %t137, %t139
  store i1 %t140, ptr %l84, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb43
bb43:
  %t142 = load i1, ptr %l84, !tbaa !21
  store i1 %t142, ptr %l81, !tbaa !21
  br label %bb44
bb44:
  %t143 = load i1, ptr %l81, !tbaa !21
  br i1 %t143, label %bb45, label %bb46
bb45:
  %t144 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t144, i32 0, i32 2
  %t146 = getelementptr { i64, [15 x i64] }, ptr %t145, i32 0, i32 1
  %t147 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t146, i32 0, i32 2
  %t148 = load %"compiler/mir:Range", ptr %t147
  store %"compiler/mir:Range" %t148, ptr %l16
  br label %bb47
bb46:
  br label %bb59
bb47:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/mir:Fn", ptr %t150, i32 0, i32 11
  %t153 = getelementptr %"compiler/mir:Range", ptr %l16, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sext i32 %t154 to i64
  %t158 = add i64 %t156, 1
  %t161 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %t152, i64 %t158)
  store { i64, [4 x i64] } %t161, ptr %l93
  br label %bb48
bb48:
  %t162 = load { i64, [4 x i64] }, ptr %l93
  store { i64, [4 x i64] } %t162, ptr %l17
  %t163 = load { i64, [4 x i64] }, ptr %l17
  %t165 = extractvalue { i64, [4 x i64] } %t163, 0
  %t166 = icmp eq i64 %t165, 2
  br i1 %t166, label %bb49, label %bb50
bb49:
  %t168 = getelementptr { i64, [4 x i64] }, ptr %l17, i32 0, i32 1
  %t169 = getelementptr { i32, i64 }, ptr %t168, i32 0, i32 1
  %t170 = load i64, ptr %t169
  store i64 %t170, ptr %l18, !tbaa !24
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i64, ptr %l18, !tbaa !24
  %t174 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2etable(ptr %v0, ptr %v2, ptr %t172, i64 %t173, ptr %t174)
  br label %bb52
bb52:
  br label %bb58
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_cc02f93ad90a889a_227f669eebce755e)
  unreachable
bb58:
  br label %bb77
bb59:
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %l14, i64 176, i1 false)
  %t178 = load { i64, [21 x i64] }, ptr %l100
  %t179 = extractvalue { i64, [21 x i64] } %t178, 0
  %t180 = icmp eq i64 %t179, 6
  br i1 %t180, label %bb60, label %bb61
bb60:
  %t182 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t182, i32 0, i32 2
  %t184 = load i32, ptr %t183
  store i32 %t184, ptr %l19, !tbaa !23
  br label %bb62
bb61:
  br label %bb72
bb62:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/interp:Exec", ptr %t186, i32 0, i32 7
  %t189 = load i32, ptr %l19, !tbaa !23
  %t192 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t188, i32 %t189)
  %t193 = extractvalue { i32, i64 } %t192, 1
  %t194 = extractvalue { i32, i64 } %t192, 0
  store i32 %t194, ptr %l108
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb64, label %ok.196, !prof !99
ok.196:
  store i64 %t193, ptr %l107
  br label %bb63
bb63:
  %t197 = load i64, ptr %l107, !tbaa !24
  store i64 %t197, ptr %l103, !tbaa !24
  br label %bb66
bb64:
  br label %bb65
bb65:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l103, !tbaa !24
  br label %bb66
bb66:
  %t198 = load i64, ptr %l103, !tbaa !24
  store i64 %t198, ptr %l20, !tbaa !24
  %t199 = load i64, ptr %l20, !tbaa !24
  %t201 = icmp sge i64 %t199, 0
  br i1 %t201, label %bb67, label %bb68
bb67:
  %t203 = load i64, ptr %l20, !tbaa !24
  %t205 = trunc i64 %t203 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [2 x i64] }, ptr %t207, i32 0, i32 0
  store i64 0, ptr %t208
  %t210 = insertvalue { i32 } undef, i32 %t205, 0
  %t211 = getelementptr { i64, [2 x i64] }, ptr %t207, i32 0, i32 1
  store { i32 } %t210, ptr %t211
  %t212 = load { i64, [2 x i64] }, ptr %t207
  store { i64, [2 x i64] } %t212, ptr %l21
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/interp:Exec", ptr %t214, i32 0, i32 4
  %t217 = load i32, ptr %l19, !tbaa !23
  %t218 = load { i64, [2 x i64] }, ptr %l21
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %t216, i32 %t217, { i64, [2 x i64] } %t218)
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t222 = load ptr, ptr %l2, !tbaa !29
  %t223 = load { i64, [2 x i64] }, ptr %l21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v2, ptr %t222, { i64, [2 x i64] } %t223)
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_8861c203007a29b_3eff7fe7d80c41df)
  unreachable
bb77:
  br label %bb78
bb78:
  %t226 = load i64, ptr %l13, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l13, !tbaa !24
  br label %bb25
bb79:
  br label %bb80
bb80:
  %t230 = load i64, ptr %l10, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l10, !tbaa !24
  br label %bb19
bb81:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2erun(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l10 = alloca ptr
  %l11 = alloca { i64, [2 x i64] }
  %l15 = alloca { i64, [5 x i64] }
  %rv = alloca { i64, [5 x i64] }
  %t5 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a1 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t10, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/interp:Exec", ptr %t16, i32 0, i32 4
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t19, ptr %l11
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = icmp sle i64 0, 1152921504606846975
  br i1 %t22, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_8c9ae6434c5565e7_656708b088a82c0b)
  unreachable
bb4:
  %t24 = mul i64 0, 8
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l11
  %t30 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v1, ptr %t27, { i64, [2 x i64] } %t28, { i64, ptr } %t26)
  store { i64, [5 x i64] } %t30, ptr %l15
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8c9ae6434c5565e7_656708b088a82c0b)
  unreachable
bb6:
  %t31 = load { i64, [5 x i64] }, ptr %l15
  store { i64, [5 x i64] } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2estart(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca i1
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca ptr
  %l106 = alloca i32
  %l115 = alloca ptr
  %l116 = alloca i64
  %l117 = alloca i32
  %l118 = alloca i32
  %l123 = alloca ptr
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i64
  %l128 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca i1
  %l135 = alloca i1
  %l145 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l149 = alloca i64
  %l151 = alloca i64
  %l156 = alloca i64
  %l161 = alloca i1
  %l168 = alloca i64
  %l170 = alloca i64
  %l175 = alloca i64
  %l179 = alloca i1
  %l188 = alloca i64
  %l190 = alloca i64
  %l195 = alloca i64
  %l203 = alloca i64
  %l205 = alloca i64
  %l210 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t176 = alloca { i64, [2 x i64] }, align 8
  %t381 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 12
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/interp:Exec", ptr %t6, i32 0, i32 12
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/interp:Exec", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 5
  store ptr %t17, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l39, !tbaa !24
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l41
  br label %bb5
bb5:
  %t23 = load i64, ptr %l39, !tbaa !24
  %t24 = load i64, ptr %l41, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t29, i64 %t30)
  store ptr %t33, ptr %l46
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l46, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/load:Module", ptr %t35, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t38, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t40, ptr %l49
  br label %bb10
bb10:
  %t41 = load i1, ptr %l49, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/interp:Exec", ptr %t42, i32 0, i32 4
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 73
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/load:Module", ptr %t46, i32 0, i32 4
  %t49 = load i64, ptr %t48, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t45, i64 %t49, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l2, !tbaa !24
  br label %bb4
bb16:
  store i64 0, ptr %l4, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/interp:Exec", ptr %t56, i32 0, i32 1
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l58
  br label %bb17
bb17:
  %t61 = load i64, ptr %l58, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb23
bb20:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l4, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l65, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb22
bb22:
  %t88 = load i64, ptr %l65, !tbaa !24
  store i64 %t88, ptr %l62, !tbaa !24
  br label %bb23
bb23:
  %t89 = load i64, ptr %l62, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb25, label %bb26
bb25:
  br label %bb62
bb26:
  br label %bb27
bb27:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l9, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/interp:Exec", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t110, i64 %t111)
  store ptr %t114, ptr %l86
  br label %bb28
bb28:
  %t115 = load ptr, ptr %l86, !tbaa !29
  store ptr %t115, ptr %l10, !tbaa !29
  %t116 = load ptr, ptr %l10, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Body", ptr %t116, i32 0, i32 1
  %t119 = load { i64, [2 x i64] }, ptr %t118
  store { i64, [2 x i64] } %t119, ptr %l11
  %t121 = load { i64, [2 x i64] }, ptr %l11
  %t123 = extractvalue { i64, [2 x i64] } %t121, 0
  %t124 = icmp eq i64 %t123, 3
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t126 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t127 = getelementptr { i32 }, ptr %t126, i32 0, i32 0
  %t128 = load i32, ptr %t127
  store i32 %t128, ptr %l12, !tbaa !23
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/interp:Exec", ptr %t130, i32 0, i32 7
  %t133 = load i32, ptr %l12, !tbaa !23
  %t134 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t132, i32 %t133, i64 %t134)
  br label %bb32
bb32:
  br label %bb60
bb33:
  %t138 = load { i64, [2 x i64] }, ptr %l11
  %t140 = extractvalue { i64, [2 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 6
  br i1 %t141, label %bb34, label %bb35
bb34:
  %t143 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t144 = getelementptr { i64, i32 }, ptr %t143, i32 0, i32 0
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l13, !tbaa !24
  %t147 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t148 = getelementptr { i64, i32 }, ptr %t147, i32 0, i32 1
  %t149 = load i32, ptr %t148
  store i32 %t149, ptr %l14, !tbaa !23
  br label %bb36
bb35:
  br label %bb55
bb36:
  %t151 = load ptr, ptr %l10, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Body", ptr %t151, i32 0, i32 11
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb37, label %bb38
bb37:
  br label %bb61
bb38:
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t159 = load i64, ptr %l13, !tbaa !24
  %t160 = load i32, ptr %l14, !tbaa !23
  %t164 = call i32 @compiler_2finterp_2eglobalType(ptr %v0, ptr %t158, i64 %t159, i32 %t160)
  store i32 %t164, ptr %l106
  br label %bb40
bb40:
  %t165 = load i32, ptr %l106, !tbaa !23
  store i32 %t165, ptr %l15, !tbaa !23
  %t166 = load i32, ptr %l15, !tbaa !23
  %t167 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t170 = icmp eq i32 %t166, %t167
  br i1 %t170, label %bb41, label %bb42
bb41:
  br label %bb61
bb42:
  br label %bb43
bb43:
  %t172 = load i64, ptr %l9, !tbaa !24
  %t174 = trunc i64 %t172 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t179 = insertvalue { i32 } undef, i32 %t174, 0
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 1
  store { i32 } %t179, ptr %t180
  %t181 = load { i64, [2 x i64] }, ptr %t176
  store { i64, [2 x i64] } %t181, ptr %l16
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/interp:Exec", ptr %t183, i32 0, i32 4
  store ptr %t185, ptr %l115, !tbaa !29
  %t186 = load i64, ptr %l13, !tbaa !24
  store i64 %t186, ptr %l116, !tbaa !24
  %t187 = load i32, ptr %l14, !tbaa !23
  store i32 %t187, ptr %l117, !tbaa !23
  %t188 = load i32, ptr %l15, !tbaa !23
  store i32 %t188, ptr %l118, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/interp:Exec", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t193 = load i64, ptr %l13, !tbaa !24
  %t194 = load i32, ptr %l14, !tbaa !23
  %t198 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t192, i64 %t193, i32 %t194)
  store ptr %t198, ptr %l123
  br label %bb44
bb44:
  %t199 = load ptr, ptr %l123, !tbaa !29
  %t200 = call i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %t199)
  store i1 %t200, ptr %l124
  br label %bb45
bb45:
  %t201 = load { i64, [2 x i64] }, ptr %l16
  %t202 = load ptr, ptr %l115, !tbaa !29
  %t203 = load i64, ptr %l116, !tbaa !24
  %t204 = load i32, ptr %l117, !tbaa !23
  %t205 = load i32, ptr %l118, !tbaa !23
  %t206 = load i1, ptr %l124, !tbaa !21
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %t202, i64 %t203, i32 %t204, i32 %t205, i1 %t206, { i64, [2 x i64] } %t201)
  br label %bb46
bb46:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l126, !tbaa !29
  %t209 = load i64, ptr %l13, !tbaa !24
  store i64 %t209, ptr %l127, !tbaa !24
  %t210 = load i32, ptr %l15, !tbaa !23
  store i32 %t210, ptr %l128, !tbaa !23
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/interp:Exec", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load i64, ptr %l13, !tbaa !24
  %t216 = load i32, ptr %l14, !tbaa !23
  %t220 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t214, i64 %t215, i32 %t216)
  store ptr %t220, ptr %l133
  br label %bb47
bb47:
  %t221 = load ptr, ptr %l133, !tbaa !29
  %t222 = call i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %t221)
  store i1 %t222, ptr %l134
  br label %bb48
bb48:
  %t223 = load ptr, ptr %l126, !tbaa !29
  %t224 = load i64, ptr %l127, !tbaa !24
  %t225 = load i32, ptr %l128, !tbaa !23
  %t226 = load i1, ptr %l134, !tbaa !21
  %t227 = call i1 @compiler_2finterp_2ecompiler_2finterp_3aExec_2ebuildDefault(ptr %v0, ptr %t223, i64 %t224, i32 %t225, i1 %t226)
  store i1 %t227, ptr %l135
  br label %bb49
bb49:
  %t228 = load i1, ptr %l135, !tbaa !21
  br i1 %t228, label %bb50, label %bb51
bb50:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/interp:Exec", ptr %t229, i32 0, i32 4
  %t232 = load i64, ptr %l13, !tbaa !24
  %t233 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eBuildGlobal(ptr %v0, ptr %t231, i64 %t232, i32 %t233)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/interp:Exec", ptr %t237, i32 0, i32 9
  %t240 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t239, i64 %t240)
  br label %bb54
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_5218513f7b2d35ff_8134a4fdf2d394bb)
  unreachable
bb60:
  br label %bb61
bb61:
  %t243 = load i64, ptr %l8, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l8, !tbaa !24
  br label %bb24
bb62:
  %t247 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t247, ptr %l145
  br label %bb63
bb63:
  %t248 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l145
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %l17
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/interp:Exec", ptr %t249, i32 0, i32 0
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/generic:Program", ptr %t252, i32 0, i32 46
  store ptr %t254, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb64
bb64:
  %t256 = load i64, ptr %l19, !tbaa !24
  store i64 %t256, ptr %l149, !tbaa !24
  %t257 = load ptr, ptr %l18, !tbaa !29
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t257)
  store i64 %t259, ptr %l151
  br label %bb65
bb65:
  %t260 = load i64, ptr %l149, !tbaa !24
  %t261 = load i64, ptr %l151, !tbaa !24
  %t262 = icmp slt i64 %t260, %t261
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb66, label %bb67
bb66:
  br label %bb76
bb67:
  br label %bb68
bb68:
  %t266 = load ptr, ptr %l18, !tbaa !29
  %t267 = load i64, ptr %l19, !tbaa !24
  %t270 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t266, i64 %t267)
  store i64 %t270, ptr %l156
  br label %bb69
bb69:
  %t271 = load i64, ptr %l156, !tbaa !24
  store i64 %t271, ptr %l20, !tbaa !24
  %t272 = load i64, ptr %l20, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/interp:Exec", ptr %t274, i32 0, i32 9
  %t280 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t276, i64 %t272)
  store i1 %t280, ptr %l161
  br label %bb70
bb70:
  %t281 = load i1, ptr %l161, !tbaa !21
  br i1 %t281, label %bb71, label %bb72
bb71:
  %t282 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l17, i64 %t282)
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t285 = load i64, ptr %l19, !tbaa !24
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l19, !tbaa !24
  br label %bb64
bb76:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/interp:Exec", ptr %t289, i32 0, i32 9
  store ptr %t291, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb77
bb77:
  %t293 = load i64, ptr %l23, !tbaa !24
  store i64 %t293, ptr %l168, !tbaa !24
  %t294 = load ptr, ptr %l22, !tbaa !29
  %t296 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t294)
  store i64 %t296, ptr %l170
  br label %bb78
bb78:
  %t297 = load i64, ptr %l168, !tbaa !24
  %t298 = load i64, ptr %l170, !tbaa !24
  %t299 = icmp slt i64 %t297, %t298
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb79, label %bb80
bb79:
  br label %bb89
bb80:
  br label %bb81
bb81:
  %t303 = load ptr, ptr %l22, !tbaa !29
  %t304 = load i64, ptr %l23, !tbaa !24
  %t307 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t303, i64 %t304)
  store i64 %t307, ptr %l175
  br label %bb82
bb82:
  %t308 = load i64, ptr %l175, !tbaa !24
  store i64 %t308, ptr %l24, !tbaa !24
  %t309 = load i64, ptr %l24, !tbaa !24
  %t314 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l17, i64 %t309)
  store i1 %t314, ptr %l179
  br label %bb83
bb83:
  %t315 = load i1, ptr %l179, !tbaa !21
  %t316 = xor i1 %t315, true
  br i1 %t316, label %bb84, label %bb85
bb84:
  %t318 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l17, i64 %t318)
  br label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t321 = load i64, ptr %l23, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l23, !tbaa !24
  br label %bb77
bb89:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/interp:Exec", ptr %t325, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t327)
  br label %bb90
bb90:
  store ptr %l17, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb91
bb91:
  %t330 = load i64, ptr %l27, !tbaa !24
  store i64 %t330, ptr %l188, !tbaa !24
  %t331 = load ptr, ptr %l26, !tbaa !29
  %t333 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t331)
  store i64 %t333, ptr %l190
  br label %bb92
bb92:
  %t334 = load i64, ptr %l188, !tbaa !24
  %t335 = load i64, ptr %l190, !tbaa !24
  %t336 = icmp slt i64 %t334, %t335
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb93, label %bb94
bb93:
  br label %bb99
bb94:
  br label %bb95
bb95:
  %t340 = load ptr, ptr %l26, !tbaa !29
  %t341 = load i64, ptr %l27, !tbaa !24
  %t344 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t340, i64 %t341)
  store i64 %t344, ptr %l195
  br label %bb96
bb96:
  %t345 = load i64, ptr %l195, !tbaa !24
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/interp:Exec", ptr %t346, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t348, i64 %t345)
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t352 = load i64, ptr %l27, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l27, !tbaa !24
  br label %bb91
bb99:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/interp:Exec", ptr %t356, i32 0, i32 9
  store ptr %t358, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb100
bb100:
  %t360 = load i64, ptr %l30, !tbaa !24
  store i64 %t360, ptr %l203, !tbaa !24
  %t361 = load ptr, ptr %l29, !tbaa !29
  %t363 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t361)
  store i64 %t363, ptr %l205
  br label %bb101
bb101:
  %t364 = load i64, ptr %l203, !tbaa !24
  %t365 = load i64, ptr %l205, !tbaa !24
  %t366 = icmp slt i64 %t364, %t365
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb102, label %bb103
bb102:
  br label %bb108
bb103:
  br label %bb104
bb104:
  %t370 = load ptr, ptr %l29, !tbaa !29
  %t371 = load i64, ptr %l30, !tbaa !24
  %t374 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t370, i64 %t371)
  store i64 %t374, ptr %l210
  br label %bb105
bb105:
  %t375 = load i64, ptr %l210, !tbaa !24
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t379 = trunc i64 %t375 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t381
  %t382 = getelementptr { i64, [2 x i64] }, ptr %t381, i32 0, i32 0
  store i64 0, ptr %t382
  %t384 = insertvalue { i32 } undef, i32 %t379, 0
  %t385 = getelementptr { i64, [2 x i64] }, ptr %t381, i32 0, i32 1
  store { i32 } %t384, ptr %t385
  %t386 = load { i64, [2 x i64] }, ptr %t381
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t376, { i64, [2 x i64] } %t386)
  br label %bb106
bb106:
  br label %bb107
bb107:
  %t389 = load i64, ptr %l30, !tbaa !24
  %t391 = add i64 %t389, 1
  store i64 %t391, ptr %l30, !tbaa !24
  br label %bb100
bb108:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2ecompiler_2finterp_3aExec_2etable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/generic:AnyTable"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l19 = alloca %"compiler/generic:AnyTable"
  %l21 = alloca i64
  %l24 = alloca i64
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l78 = alloca { i64, ptr }
  %t35 = alloca { i64, [2 x i64] }, align 8
  %t48 = alloca { i64, [2 x i64] }, align 8
  %t121 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 47
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/generic:AnyTable" %t10, ptr %l19
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:AnyTable", ptr %l19
  store %"compiler/generic:AnyTable" %t11, ptr %l3
  %t12 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l21
  br label %bb2
bb2:
  %t15 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t16 = load i64, ptr %l21, !tbaa !24
  %t18 = add i64 %t16, %t15
  %t20 = sub i64 %t18, 1
  store i64 %t20, ptr %l24, !tbaa !24
  %t21 = load i64, ptr %l24, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load i64, ptr %l24, !tbaa !24
  %t25 = icmp sle i64 %t24, 384307168202282325
  br i1 %t25, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6661ff5fcd5a0e74_cadc672e97162150)
  unreachable
bb5:
  %t27 = load i64, ptr %l24, !tbaa !24
  %t28 = mul i64 %t27, 24
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l28, !tbaa !27
  %t34 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 0
  store i64 4, ptr %t36
  %t38 = insertvalue { i64, i1 } undef, i64 %t34, 0
  %t39 = insertvalue { i64, i1 } %t38, i1 false, 1
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  store { i64, i1 } %t39, ptr %t40
  %t41 = load { i64, [2 x i64] }, ptr %t35
  %t43 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t44, i64 0
  store { i64, [2 x i64] } %t41, ptr %t45
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l31, !tbaa !27
  %t47 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 0
  store i64 4, ptr %t49
  %t51 = insertvalue { i64, i1 } undef, i64 %t47, 0
  %t52 = insertvalue { i64, i1 } %t51, i1 true, 1
  %t53 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  store { i64, i1 } %t52, ptr %t53
  %t54 = load { i64, [2 x i64] }, ptr %t48
  %t56 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i64 1
  store { i64, [2 x i64] } %t54, ptr %t58
  store i64 0, ptr %l5, !tbaa !24
  %t59 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l35
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6661ff5fcd5a0e74_cadc672e97162150)
  unreachable
bb7:
  %t62 = load i64, ptr %l35, !tbaa !24
  store i64 %t62, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb8, label %bb9
bb8:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb13
bb10:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l42, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb12
bb12:
  %t89 = load i64, ptr %l42, !tbaa !24
  store i64 %t89, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t90 = load i64, ptr %l39, !tbaa !24
  store i64 %t90, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t99 = load i64, ptr %l5, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l10, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t109, ptr %l60, !tbaa !27
  %t110 = load i64, ptr %l10, !tbaa !24
  %t112 = add i64 %t110, 2
  store i64 %t112, ptr %l62, !tbaa !24
  %t113 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t114 = load i64, ptr %l10, !tbaa !24
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t113, i64 %t114)
  store i64 %t117, ptr %l65
  br label %bb18
bb18:
  %t118 = load i64, ptr %l65, !tbaa !24
  %t119 = trunc i64 %t118 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [2 x i64] }, ptr %t121, i32 0, i32 0
  store i64 0, ptr %t122
  %t124 = insertvalue { i32 } undef, i32 %t119, 0
  %t125 = getelementptr { i64, [2 x i64] }, ptr %t121, i32 0, i32 1
  store { i32 } %t124, ptr %t125
  %t126 = load { i64, [2 x i64] }, ptr %t121
  %t128 = load i64, ptr %l62, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, [2 x i64] }, ptr %t130, i64 %t128
  store { i64, [2 x i64] } %t126, ptr %t131
  br label %bb19
bb19:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l9, !tbaa !24
  br label %bb14
bb20:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t136, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t150 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t150, ptr %l78, !tbaa !27
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr { i64, [2 x i64] }, ptr %t154, i64 %t151
  %t156 = load { i64, [2 x i64] }, ptr %t155
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v1, ptr %a2, { i64, [2 x i64] } %t156)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t162 = load i64, ptr %l12, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l12, !tbaa !24
  br label %bb21
bb27:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/interp:Exec", ptr %t166, i32 0, i32 4
  %t169 = load i64, ptr %l1, !tbaa !24
  %t170 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t171 = load i32, ptr %t170, !tbaa !23
  %t172 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineTable(ptr %v0, ptr %v0, ptr %t168, i64 %t169, i32 %t171, { i64, ptr } %t172)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eunrolled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca [3 x i64]
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [5 x i64] }
  %l22 = alloca i32
  %l36 = alloca { i64, ptr }
  %l39 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l46 = alloca i1
  %l49 = alloca { i64, ptr }
  %l67 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i64
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca { i64, [2 x i64] }
  %l131 = alloca { i64, [5 x i64] }
  %l136 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t79 = alloca { i64, [2 x i64] }, align 8
  %t113 = alloca { i64, [2 x i64] }, align 8
  %t174 = alloca { i64, [2 x i64] }, align 8
  %t257 = alloca { i64, [2 x i64] }, align 8
  %t271 = alloca { i64, [2 x i64] }, align 8
  %t315 = alloca { i64, [2 x i64] }, align 8
  %t351 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i32 %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load i32, ptr %l22, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/check:UnrollAsk", ptr %t10, i32 0, i32 2
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = insertvalue [3 x i64] undef, i64 0, 0
  %t18 = insertvalue [3 x i64] %t17, i64 0, 1
  %t19 = insertvalue [3 x i64] %t18, i64 0, 2
  store [3 x i64] %t19, ptr %l3
  %t21 = getelementptr [3 x i64], ptr %l3, i64 0, i64 2
  store i64 1, ptr %t21, !tbaa !34
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/check:UnrollAsk", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l6, !tbaa !24
  br label %bb4
bb3:
  br label %bb39
bb4:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t39 = load i64, ptr %l5, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t41, ptr %l36, !tbaa !27
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i64, ptr %t45, i64 %t42
  %t47 = load i64, ptr %t46, !tbaa !34
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  %t55 = call { i32, i64 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eintOf(ptr %v0, ptr %t49, i64 %t47, i32 %t51)
  %t56 = extractvalue { i32, i64 } %t55, 1
  %t57 = extractvalue { i32, i64 } %t55, 0
  store i32 %t57, ptr %l44
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb9, label %ok.59, !prof !99
ok.59:
  store i64 %t56, ptr %l43
  br label %bb8
bb8:
  %t60 = load i64, ptr %l43, !tbaa !24
  store i64 %t60, ptr %l39, !tbaa !24
  br label %bb12
bb9:
  %t61 = load i32, ptr %l44, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  store i1 %t64, ptr %l46, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/interp:Exec", ptr %t65, i32 0, i32 4
  %t68 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 12
  %t69 = load { i64, [5 x i64] }, ptr %t68
  %t71 = call { i64, ptr } @compiler_2finterp_2estopWhy(ptr %v0, ptr %v2, { i64, [5 x i64] } %t69)
  store { i64, ptr } %t71, ptr %l49
  br label %bb11
bb11:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 0
  store i64 1, ptr %t80
  %t82 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t78, 0
  %t83 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 1
  store { { i64, ptr } } %t82, ptr %t83
  %t84 = load { i64, [2 x i64] }, ptr %t79
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t84, ptr %rv
  br label %ret
bb12:
  %t86 = load i64, ptr %l39, !tbaa !24
  store i64 %t86, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/check:UnrollAsk", ptr %t87, i32 0, i32 1
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t94 = icmp eq i64 %t92, 1
  br i1 %t94, label %bb13, label %bb14
bb13:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = getelementptr [3 x i64], ptr %l3, i64 0, i64 1
  store i64 %t96, ptr %t98, !tbaa !34
  br label %bb15
bb14:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = getelementptr [3 x i64], ptr %l3, i64 0, i64 %t99
  store i64 %t100, ptr %t103, !tbaa !34
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t104 = load i64, ptr %l5, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l5, !tbaa !24
  br label %bb4
bb17:
  %t108 = getelementptr [3 x i64], ptr %l3, i64 0, i64 2
  %t109 = load i64, ptr %t108, !tbaa !34
  %t111 = icmp sle i64 %t109, 0
  br i1 %t111, label %bb18, label %bb19
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t113
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t113, i32 0, i32 0
  store i64 1, ptr %t114
  %t115 = insertvalue { { i64, ptr } } undef, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t116 = getelementptr { i64, [2 x i64] }, ptr %t113, i32 0, i32 1
  store { { i64, ptr } } %t115, ptr %t116
  %t117 = load { i64, [2 x i64] }, ptr %t113
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t117, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t119 = getelementptr [3 x i64], ptr %l3, i64 0, i64 1
  %t120 = load i64, ptr %t119, !tbaa !34
  %t121 = getelementptr [3 x i64], ptr %l3, i64 0, i64 0
  %t122 = load i64, ptr %t121, !tbaa !34
  %t125 = icmp sgt i64 %t120, %t122
  br i1 %t125, label %bb21, label %bb22
bb21:
  %t127 = getelementptr [3 x i64], ptr %l3, i64 0, i64 1
  %t128 = load i64, ptr %t127, !tbaa !34
  %t129 = getelementptr [3 x i64], ptr %l3, i64 0, i64 0
  %t130 = load i64, ptr %t129, !tbaa !34
  %t133 = sub i64 %t128, %t130
  %t134 = getelementptr [3 x i64], ptr %l3, i64 0, i64 2
  %t135 = load i64, ptr %t134, !tbaa !34
  %t138 = add i64 %t133, %t135
  %t140 = sub i64 %t138, 1
  %t141 = getelementptr [3 x i64], ptr %l3, i64 0, i64 2
  %t142 = load i64, ptr %t141, !tbaa !34
  %t145 = sdiv i64 %t140, %t142
  store i64 %t145, ptr %l67, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb23
bb23:
  %t147 = load i64, ptr %l67, !tbaa !24
  store i64 %t147, ptr %l10, !tbaa !24
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = icmp sgt i64 %t148, 1048576
  br i1 %t150, label %bb24, label %bb25
bb24:
  %t152 = load i64, ptr %l10, !tbaa !24
  %t153 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t156 = call i64 @__olang_fmt_i64(ptr null, i64 %t152)
  %t157 = add i64 %t154, %t156
  %t158 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t153, i64 %t154)
  %t162 = getelementptr i8, ptr %t161, i64 %t154
  %t163 = call i64 @__olang_fmt_i64(ptr %t162, i64 %t152)
  %t164 = getelementptr i8, ptr %t162, i64 %t156
  call void @olang_textcopy(ptr %t164, ptr %t158, i64 %t159)
  %t165 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t161, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = extractvalue { i64, ptr } %t166, 1
  %t170 = mul i64 %t168, 1
  %t171 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t170)
  call void @llvm.memcpy.p0.p0.i64(ptr %t171, ptr %t169, i64 %t170, i1 false)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t174
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 0
  store i64 1, ptr %t175
  %t177 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t173, 0
  %t178 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 1
  store { { i64, ptr } } %t177, ptr %t178
  %t179 = load { i64, [2 x i64] }, ptr %t174
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t179, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  store i64 0, ptr %l11, !tbaa !24
  %t181 = load i64, ptr %l10, !tbaa !24
  store i64 %t181, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t183 = load i64, ptr %l12, !tbaa !24
  %t184 = load i64, ptr %l11, !tbaa !24
  %t187 = icmp sgt i64 %t183, %t184
  br i1 %t187, label %bb27, label %bb28
bb27:
  %t189 = load i64, ptr %l13, !tbaa !24
  %t191 = icmp sgt i64 %t189, 0
  br i1 %t191, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb32
bb29:
  %t193 = load i64, ptr %l12, !tbaa !24
  %t194 = load i64, ptr %l11, !tbaa !24
  %t197 = sub i64 %t193, %t194
  %t198 = load i64, ptr %l13, !tbaa !24
  %t201 = add i64 %t197, %t198
  %t203 = sub i64 %t201, 1
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = sdiv i64 %t203, %t204
  store i64 %t207, ptr %l89, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb31
bb31:
  %t209 = load i64, ptr %l89, !tbaa !24
  store i64 %t209, ptr %l86, !tbaa !24
  br label %bb32
bb32:
  %t210 = load i64, ptr %l86, !tbaa !24
  store i64 %t210, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t211 = load i64, ptr %l14, !tbaa !24
  %t213 = mul i64 %t211, 8
  %t214 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t213)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l99, !tbaa !27
  store i64 0, ptr %l100, !tbaa !24
  br label %bb33
bb33:
  %t217 = load i64, ptr %l15, !tbaa !24
  %t218 = load i64, ptr %l14, !tbaa !24
  %t221 = icmp slt i64 %t217, %t218
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t225 = load i64, ptr %l11, !tbaa !24
  %t226 = load i64, ptr %l15, !tbaa !24
  %t227 = load i64, ptr %l13, !tbaa !24
  %t230 = mul i64 %t226, %t227
  %t233 = add i64 %t225, %t230
  %t235 = getelementptr [3 x i64], ptr %l3, i64 0, i64 0
  %t236 = load i64, ptr %t235, !tbaa !34
  %t238 = getelementptr [3 x i64], ptr %l3, i64 0, i64 2
  %t239 = load i64, ptr %t238, !tbaa !34
  %t242 = mul i64 %t233, %t239
  %t245 = add i64 %t236, %t242
  %t247 = load i64, ptr %l100, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i64, ptr %t249, i64 %t247
  store i64 %t245, ptr %t250, !tbaa !34
  %t251 = load i64, ptr %l100, !tbaa !24
  %t252 = add i64 %t251, 1
  store i64 %t252, ptr %l100, !tbaa !24
  br label %bb37
bb37:
  %t253 = load i64, ptr %l15, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l15, !tbaa !24
  br label %bb33
bb38:
  store { i64, [2 x i64] } zeroinitializer, ptr %t257
  %t258 = getelementptr { i64, [2 x i64] }, ptr %t257, i32 0, i32 0
  store i64 0, ptr %t258
  %t259 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t260 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t259, 0
  %t261 = getelementptr { i64, [2 x i64] }, ptr %t257, i32 0, i32 1
  store { { i64, ptr } } %t260, ptr %t261
  %t262 = load { i64, [2 x i64] }, ptr %t257
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t262, ptr %rv
  br label %ret
bb39:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr %"compiler/check:UnrollAsk", ptr %t264, i32 0, i32 2
  %t267 = load i64, ptr %t266, !tbaa !24
  %t269 = trunc i64 %t267 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [2 x i64] }, ptr %t271, i32 0, i32 0
  store i64 0, ptr %t272
  %t274 = insertvalue { i32 } undef, i32 %t269, 0
  %t275 = getelementptr { i64, [2 x i64] }, ptr %t271, i32 0, i32 1
  store { i32 } %t274, ptr %t275
  %t276 = load { i64, [2 x i64] }, ptr %t271
  store { i64, [2 x i64] } %t276, ptr %l17
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load { i64, [2 x i64] }, ptr %l17
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t278, { i64, [2 x i64] } %t279)
  br label %bb40
bb40:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/interp:Exec", ptr %t282, i32 0, i32 4
  store ptr %t284, ptr %l126, !tbaa !29
  %t285 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t285, ptr %l127
  %t286 = icmp sge i64 0, 0
  br i1 %t286, label %bb41, label %bb42
bb41:
  %t288 = icmp sle i64 0, 1152921504606846975
  br i1 %t288, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8aa385fac4707635_8a0feffc81f8cb59)
  unreachable
bb43:
  %t290 = mul i64 0, 8
  %t291 = insertvalue { i64, ptr } undef, i64 0, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t293 = load ptr, ptr %l126, !tbaa !29
  %t294 = load { i64, [2 x i64] }, ptr %l127
  %t296 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v0, ptr %v0, ptr %t293, { i64, [2 x i64] } %t294, { i64, ptr } %t292)
  store { i64, [5 x i64] } %t296, ptr %l131
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_8aa385fac4707635_8a0feffc81f8cb59)
  unreachable
bb45:
  %t297 = load { i64, [5 x i64] }, ptr %l131
  store { i64, [5 x i64] } %t297, ptr %l18
  %t298 = load { i64, [5 x i64] }, ptr %l18
  %t300 = extractvalue { i64, [5 x i64] } %t298, 0
  %t301 = icmp eq i64 %t300, 0
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb46, label %bb47
bb46:
  %t305 = load { i64, [5 x i64] }, ptr %l18
  %t307 = call { i64, ptr } @compiler_2finterp_2estopWhy(ptr %v0, ptr %v2, { i64, [5 x i64] } %t305)
  store { i64, ptr } %t307, ptr %l136
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t308 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  %t310 = extractvalue { i64, ptr } %t308, 1
  %t311 = mul i64 %t309, 1
  %t312 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t312, ptr %t310, i64 %t311, i1 false)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t315
  %t316 = getelementptr { i64, [2 x i64] }, ptr %t315, i32 0, i32 0
  store i64 1, ptr %t316
  %t318 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t314, 0
  %t319 = getelementptr { i64, [2 x i64] }, ptr %t315, i32 0, i32 1
  store { { i64, ptr } } %t318, ptr %t319
  %t320 = load { i64, [2 x i64] }, ptr %t315
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t320, ptr %rv
  br label %ret
bb49:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/interp:Exec", ptr %t322, i32 0, i32 4
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/interp:Exec", ptr %t325, i32 0, i32 4
  %t328 = getelementptr %"compiler/eval:Machine", ptr %t327, i32 0, i32 10
  %t329 = load %"compiler/eval:Ptr", ptr %t328
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/interp:Exec", ptr %t330, i32 0, i32 4
  %t333 = getelementptr %"compiler/eval:Machine", ptr %t332, i32 0, i32 11
  %t334 = load i32, ptr %t333, !tbaa !23
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr %"compiler/check:UnrollAsk", ptr %t335, i32 0, i32 3
  %t338 = load i32, ptr %t337, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eElems(ptr %v0, ptr %v2, ptr %t324, %"compiler/eval:Ptr" %t329, i32 %t334, i32 %t338)
  store { i64, ptr } %t343, ptr %l147
  br label %bb50
bb50:
  %t344 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = extractvalue { i64, ptr } %t344, 1
  %t347 = mul i64 %t345, 8
  %t348 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t351
  %t352 = getelementptr { i64, [2 x i64] }, ptr %t351, i32 0, i32 0
  store i64 0, ptr %t352
  %t354 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t350, 0
  %t355 = getelementptr { i64, [2 x i64] }, ptr %t351, i32 0, i32 1
  store { { i64, ptr } } %t354, ptr %t355
  %t356 = load { i64, [2 x i64] }, ptr %t351
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t356, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2finterp_2econdSaid(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [3 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [3 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l3, !tbaa !24
  %t14 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t15 = getelementptr { i64, i64, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l15
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l10, !tbaa !29
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = load i64, ptr %l15, !tbaa !24
  %t30 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %t25, i64 %t26, i64 %t27, i64 %t28, i64 %t29)
  store i1 %t30, ptr %l16
  br label %bb5
bb5:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6556c5b27a8f2520_6c50e0cecbbb5fdc)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2finterp_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, ptr %v8, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7, ptr %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/check:EmbedAsk"
  %l15 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/check:UnrollAsk"
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca %"compiler/check:Ask"
  %l31 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca %"compiler/generic:ConstAsk"
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, [2 x i64] }
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l43 = alloca ptr
  %l44 = alloca %"compiler/interp:chained"
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, [3 x i64] }
  %l49 = alloca ptr
  %l50 = alloca i64
  %l53 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca i64
  %l57 = alloca i1
  %l60 = alloca i64
  %l62 = alloca i1
  %l66 = alloca i64
  %l68 = alloca i1
  %l71 = alloca i64
  %l73 = alloca i1
  %l76 = alloca i64
  %l84 = alloca %"compiler/interp:Exec"
  %l94 = alloca i64
  %l96 = alloca i64
  %l101 = alloca %"compiler/check:EmbedAsk"
  %l105 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l108 = alloca i1
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l130 = alloca i64
  %l132 = alloca i64
  %l137 = alloca %"compiler/check:UnrollAsk"
  %l140 = alloca i1
  %l141 = alloca i1
  %l144 = alloca i1
  %l149 = alloca { i64, [2 x i64] }
  %l153 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l162 = alloca i64
  %l167 = alloca { i64, ptr }
  %l185 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l188 = alloca i64
  %l190 = alloca i64
  %l195 = alloca %"compiler/check:Ask"
  %l199 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l202 = alloca i1
  %l203 = alloca i1
  %l206 = alloca i1
  %l207 = alloca i1
  %l210 = alloca i1
  %l211 = alloca i32
  %l229 = alloca i64
  %l231 = alloca i64
  %l236 = alloca %"compiler/generic:ConstAsk"
  %l240 = alloca i1
  %l250 = alloca i64
  %l265 = alloca ptr
  %l266 = alloca { i64, [2 x i64] }
  %l270 = alloca { i64, [5 x i64] }
  %l273 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l282 = alloca i64
  %l291 = alloca i64
  %l293 = alloca i64
  %l298 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l302 = alloca ptr
  %l306 = alloca ptr
  %l313 = alloca %"compiler/interp:chained"
  %l320 = alloca i1
  %l322 = alloca i1
  %l323 = alloca i1
  %l327 = alloca i1
  %l330 = alloca i1
  %l332 = alloca i1
  %l333 = alloca i1
  %l338 = alloca ptr
  %l339 = alloca { i64, [3 x i64] }
  %l341 = alloca i1
  %l342 = alloca %"compiler/msgs:Msg"
  %l343 = alloca %"compiler/msgs:Msg"
  %l345 = alloca %"compiler/msgs:Msg"
  %l346 = alloca %"compiler/interp:CondErr"
  %l359 = alloca i64
  %l361 = alloca i64
  %l366 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %rv = alloca i64
  %t58 = alloca %"compiler/interp:Exec", align 8
  %t493 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  store ptr %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %s0, ptr %t1)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l53
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l9
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H8bd9ddbe6d7efc10dd35c4d42ad9dacf(ptr %s0, ptr %l9)
  store i64 %t6, ptr %l55
  br label %bb2
bb2:
  %t7 = load i64, ptr %l55, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 80
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l60
  br label %bb5
bb4:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb6
bb5:
  %t15 = load i64, ptr %l60, !tbaa !24
  %t16 = icmp eq i64 %t15, 0
  store i1 %t16, ptr %l57, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l57, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 41
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v1, ptr %t24)
  store i64 %t26, ptr %l66
  br label %bb9
bb8:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb10
bb9:
  %t27 = load i64, ptr %l66, !tbaa !24
  %t28 = icmp eq i64 %t27, 0
  store i1 %t28, ptr %l62, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l62, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 81
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eLen_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v1, ptr %t33)
  store i64 %t35, ptr %l71
  br label %bb13
bb12:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb14
bb13:
  %t36 = load i64, ptr %l71, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l68, !tbaa !21
  br label %bb14
bb14:
  %t39 = load i1, ptr %l68, !tbaa !21
  br i1 %t39, label %bb15, label %bb16
bb15:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 109
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2eLen__H3e1caeca23cca4e886f5085abf2ba261(ptr %v1, ptr %t42)
  store i64 %t44, ptr %l76
  br label %bb17
bb16:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb18
bb17:
  %t45 = load i64, ptr %l76, !tbaa !24
  %t46 = icmp eq i64 %t45, 0
  store i1 %t46, ptr %l73, !tbaa !21
  br label %bb18
bb18:
  %t48 = load i1, ptr %l73, !tbaa !21
  br i1 %t48, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 12
  %t57 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t56
  call void @compiler_2finterp_3aExec_2ector(ptr %t58, ptr %v1, ptr %v1, ptr %v1, ptr %t53, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l84, ptr %t58, i64 992, i1 false)
  br label %bb22
bb22:
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %l84, i64 992, i1 false)
  store ptr %t62, ptr %l10, !tbaa !29
  %t64 = load ptr, ptr %l10, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 112
  %t68 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t67
  %t71 = getelementptr %"compiler/interp:Exec", ptr %t64, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %t71
  %t72 = load ptr, ptr %l10, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 116
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t75
  %t79 = getelementptr %"compiler/interp:Exec", ptr %t72, i32 0, i32 11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t79
  store i64 0, ptr %l11, !tbaa !24
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 81
  store ptr %t82, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load i64, ptr %l13, !tbaa !24
  store i64 %t84, ptr %l94, !tbaa !24
  %t85 = load ptr, ptr %l12, !tbaa !29
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eLen_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v1, ptr %t85)
  store i64 %t87, ptr %l96
  br label %bb24
bb24:
  %t88 = load i64, ptr %l94, !tbaa !24
  %t89 = load i64, ptr %l96, !tbaa !24
  %t90 = icmp slt i64 %t88, %t89
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t94 = load ptr, ptr %l12, !tbaa !29
  %t95 = load i64, ptr %l13, !tbaa !24
  %t98 = call %"compiler/check:EmbedAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eAt_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v1, ptr %t94, i64 %t95)
  store %"compiler/check:EmbedAsk" %t98, ptr %l101
  br label %bb28
bb28:
  %t99 = load %"compiler/check:EmbedAsk", ptr %l101
  store %"compiler/check:EmbedAsk" %t99, ptr %l14
  %t100 = getelementptr %"compiler/check:EmbedAsk", ptr %l14, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = getelementptr %"compiler/check:EmbedAsk", ptr %l14, i32 0, i32 2
  %t103 = load i32, ptr %t102, !tbaa !23
  %t105 = sext i32 %t103 to i64
  %t108 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t101, i64 %t105)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t108, ptr %l105
  br label %bb29
bb29:
  %t109 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l105
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109, ptr %l15
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t111 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l15
  %t114 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4b90e82c7a9c5937397e46eef988cfe3(ptr %v5, ptr %t110, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t111)
  store i1 %t114, ptr %l108
  br label %bb30
bb30:
  %t115 = load i1, ptr %l108, !tbaa !21
  br i1 %t115, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb32:
  br label %bb33
bb33:
  %t116 = load i64, ptr %l11, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l11, !tbaa !24
  %t120 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/check:EmbedAsk", ptr %l14, i32 0, i32 0
  %t122 = load i64, ptr %t121, !tbaa !24
  %t125 = call { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s3, ptr %t120, i64 %t122)
  %t126 = extractvalue { i32, { i64, ptr } } %t125, 1
  %t127 = extractvalue { i32, { i64, ptr } } %t125, 0
  store i32 %t127, ptr %l115
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb35, label %ok.129, !prof !99
ok.129:
  store { i64, ptr } %t126, ptr %l114
  br label %bb34
bb34:
  %t130 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t130, ptr %l111, !tbaa !27
  br label %bb37
bb35:
  br label %bb36
bb36:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l116, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t131, ptr %l111, !tbaa !27
  br label %bb37
bb37:
  %t133 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t134 = load ptr, ptr %l5, !tbaa !29
  %t135 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l15
  %t138 = extractvalue { i64, ptr } %t133, 1
  %t139 = extractvalue { i64, ptr } %t133, 0
  %t140 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t138, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94076cc109da9d789864820ff05c3ac1(ptr %v5, ptr %v5, ptr %t134, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t135, { i64, ptr } %t149)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  %t153 = load i64, ptr %l13, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l13, !tbaa !24
  br label %bb23
bb40:
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = icmp sgt i64 %t157, 0
  br i1 %t159, label %bb41, label %bb42
bb41:
  %t161 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t161, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 109
  store ptr %t165, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t167 = load i64, ptr %l18, !tbaa !24
  store i64 %t167, ptr %l130, !tbaa !24
  %t168 = load ptr, ptr %l17, !tbaa !29
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2eLen__H3e1caeca23cca4e886f5085abf2ba261(ptr %v1, ptr %t168)
  store i64 %t170, ptr %l132
  br label %bb45
bb45:
  %t171 = load i64, ptr %l130, !tbaa !24
  %t172 = load i64, ptr %l132, !tbaa !24
  %t173 = icmp slt i64 %t171, %t172
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb77
bb47:
  br label %bb48
bb48:
  %t177 = load ptr, ptr %l17, !tbaa !29
  %t178 = load i64, ptr %l18, !tbaa !24
  %t181 = call %"compiler/check:UnrollAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2eAt_3ccompiler_2fcheck_3aUnrollAsk_3e(ptr %v1, ptr %v1, ptr %t177, i64 %t178)
  store %"compiler/check:UnrollAsk" %t181, ptr %l137
  br label %bb49
bb49:
  %t182 = load %"compiler/check:UnrollAsk", ptr %l137
  store %"compiler/check:UnrollAsk" %t182, ptr %l19
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t184 = getelementptr %"compiler/check:UnrollAsk", ptr %l19, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t188 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H227dc11a6a27d53bbdf34efa35d45ee3(ptr %v6, ptr %v1, ptr %t183, { i64, ptr } %t185)
  store i1 %t188, ptr %l140
  br label %bb50
bb50:
  %t189 = load i1, ptr %l140, !tbaa !21
  br i1 %t189, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb54
bb52:
  %t190 = load ptr, ptr %l7, !tbaa !29
  %t191 = getelementptr %"compiler/check:UnrollAsk", ptr %l19, i32 0, i32 0
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  %t195 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v7, ptr %v1, ptr %t190, { i64, ptr } %t192)
  store i1 %t195, ptr %l144
  br label %bb53
bb53:
  %t196 = load i1, ptr %l144, !tbaa !21
  store i1 %t196, ptr %l141, !tbaa !21
  br label %bb54
bb54:
  %t197 = load i1, ptr %l141, !tbaa !21
  br i1 %t197, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb76
bb56:
  br label %bb57
bb57:
  %t198 = load i64, ptr %l11, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l11, !tbaa !24
  %t202 = load ptr, ptr %l10, !tbaa !29
  %t205 = call { i64, [2 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eunrolled(ptr %v1, ptr %s9, ptr %s9, ptr %t202, ptr %l19)
  store { i64, [2 x i64] } %t205, ptr %l149
  br label %bb58
bb58:
  %t206 = load { i64, [2 x i64] }, ptr %l149
  store { i64, [2 x i64] } %t206, ptr %l20
  %t207 = load { i64, [2 x i64] }, ptr %l20
  %t209 = extractvalue { i64, [2 x i64] } %t207, 0
  %t210 = icmp eq i64 %t209, 0
  br i1 %t210, label %bb59, label %bb60
bb59:
  %t212 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t213 = getelementptr { { i64, ptr } }, ptr %t212, i32 0, i32 0
  %t214 = load { i64, ptr }, ptr %t213
  store { i64, ptr } %t214, ptr %l21, !tbaa !27
  br label %bb61
bb60:
  br label %bb69
bb61:
  %t216 = load ptr, ptr %l6, !tbaa !29
  store ptr %t216, ptr %l153, !tbaa !29
  %t217 = getelementptr %"compiler/check:UnrollAsk", ptr %l19, i32 0, i32 0
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 1
  %t221 = extractvalue { i64, ptr } %t218, 0
  %t222 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t220, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = extractvalue { i64, ptr } %t224, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l156, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t232, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  store i64 %t236, ptr %l24, !tbaa !24
  %t238 = load i64, ptr %l24, !tbaa !24
  %t240 = mul i64 %t238, 8
  %t241 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l161, !tbaa !27
  store i64 0, ptr %l162, !tbaa !24
  br label %bb62
bb62:
  %t244 = load i64, ptr %l23, !tbaa !24
  %t245 = load i64, ptr %l24, !tbaa !24
  %t248 = icmp slt i64 %t244, %t245
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  %t252 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t252, ptr %l167, !tbaa !27
  %t253 = load i64, ptr %l23, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i64, ptr %t256, i64 %t253
  %t258 = load i64, ptr %t257, !tbaa !34
  %t262 = load i64, ptr %l162, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i64, ptr %t264, i64 %t262
  store i64 %t258, ptr %t265, !tbaa !34
  %t266 = load i64, ptr %l162, !tbaa !24
  %t267 = add i64 %t266, 1
  store i64 %t267, ptr %l162, !tbaa !24
  br label %bb66
bb66:
  %t268 = load i64, ptr %l23, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l23, !tbaa !24
  br label %bb62
bb67:
  %t272 = load ptr, ptr %l153, !tbaa !29
  %t273 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l161, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H0a119a96f6a24054f8ced6f159e533e6(ptr %v6, ptr %v6, ptr %v6, ptr %t272, { i64, ptr } %t273, { i64, ptr } %t274)
  br label %bb68
bb68:
  br label %bb75
bb69:
  %t275 = load { i64, [2 x i64] }, ptr %l20
  %t277 = extractvalue { i64, [2 x i64] } %t275, 0
  %t278 = icmp eq i64 %t277, 1
  br i1 %t278, label %bb70, label %bb71
bb70:
  %t280 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t281 = getelementptr { { i64, ptr } }, ptr %t280, i32 0, i32 0
  %t282 = load { i64, ptr }, ptr %t281
  store { i64, ptr } %t282, ptr %l26, !tbaa !27
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t284 = load ptr, ptr %l7, !tbaa !29
  %t285 = getelementptr %"compiler/check:UnrollAsk", ptr %l19, i32 0, i32 0
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t286, 1
  %t289 = extractvalue { i64, ptr } %t286, 0
  %t290 = call ptr @__olang_scope_alloc(ptr %v7, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t288, i64 %t289)
  %t291 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %v7, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  %t300 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 1
  %t303 = extractvalue { i64, ptr } %t300, 0
  %t304 = call ptr @__olang_scope_alloc(ptr %v7, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t302, i64 %t303)
  %t305 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = extractvalue { i64, ptr } %t306, 1
  %t310 = mul i64 %t308, 1
  %t311 = call ptr @__olang_scope_alloc(ptr %v7, i64 %t310)
  call void @llvm.memcpy.p0.p0.i64(ptr %t311, ptr %t309, i64 %t310, i1 false)
  %t312 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t311, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v7, ptr %v7, ptr %v7, ptr %t284, { i64, ptr } %t299, { i64, ptr } %t313)
  br label %bb73
bb73:
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_b2316244e9af307f_bcf0fdc57d0f0f9b)
  unreachable
bb75:
  call void @__olang_scope_close(ptr %s9)
  br label %bb76
bb76:
  %t317 = load i64, ptr %l18, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l18, !tbaa !24
  br label %bb44
bb77:
  %t321 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t321, ptr %l185
  br label %bb78
bb78:
  %t322 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l185
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t322, ptr %l27
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 80
  store ptr %t325, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s21
  %t327 = load i64, ptr %l29, !tbaa !24
  store i64 %t327, ptr %l188, !tbaa !24
  %t328 = load ptr, ptr %l28, !tbaa !29
  %t330 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %t328)
  store i64 %t330, ptr %l190
  br label %bb80
bb80:
  %t331 = load i64, ptr %l188, !tbaa !24
  %t332 = load i64, ptr %l190, !tbaa !24
  %t333 = icmp slt i64 %t331, %t332
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s21)
  br label %bb105
bb82:
  br label %bb83
bb83:
  %t337 = load ptr, ptr %l28, !tbaa !29
  %t338 = load i64, ptr %l29, !tbaa !24
  %t341 = call %"compiler/check:Ask" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v1, ptr %v1, ptr %t337, i64 %t338)
  store %"compiler/check:Ask" %t341, ptr %l195
  br label %bb84
bb84:
  %t342 = load %"compiler/check:Ask", ptr %l195
  store %"compiler/check:Ask" %t342, ptr %l30
  %t343 = getelementptr %"compiler/check:Ask", ptr %l30, i32 0, i32 1
  %t344 = load i64, ptr %t343, !tbaa !24
  %t345 = getelementptr %"compiler/check:Ask", ptr %l30, i32 0, i32 2
  %t346 = load i32, ptr %t345, !tbaa !23
  %t348 = sext i32 %t346 to i64
  %t351 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s21, i64 %t344, i64 %t348)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t351, ptr %l199
  br label %bb85
bb85:
  %t352 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l199
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t352, ptr %l31
  %t353 = load ptr, ptr %l2, !tbaa !29
  %t354 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  %t357 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v2, ptr %t353, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t354)
  store i1 %t357, ptr %l202
  br label %bb86
bb86:
  %t358 = load i1, ptr %l202, !tbaa !21
  br i1 %t358, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l203, !tbaa !21
  br label %bb90
bb88:
  %t359 = load ptr, ptr %l3, !tbaa !29
  %t360 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  %t363 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v3, ptr %t359, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t360)
  store i1 %t363, ptr %l206
  br label %bb89
bb89:
  %t364 = load i1, ptr %l206, !tbaa !21
  store i1 %t364, ptr %l203, !tbaa !21
  br label %bb90
bb90:
  %t365 = load i1, ptr %l203, !tbaa !21
  br i1 %t365, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s21)
  br label %bb104
bb92:
  br label %bb93
bb93:
  %t366 = load ptr, ptr %l10, !tbaa !29
  %t367 = getelementptr %"compiler/check:Ask", ptr %l30, i32 0, i32 0
  %t368 = load i64, ptr %t367, !tbaa !24
  %t371 = call { i32, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eCond(ptr %v1, ptr %t366, i64 %t368)
  %t372 = extractvalue { i32, i1 } %t371, 1
  %t373 = extractvalue { i32, i1 } %t371, 0
  store i32 %t373, ptr %l211
  %t374 = icmp ne i32 %t373, 0
  br i1 %t374, label %bb95, label %ok.375, !prof !99
ok.375:
  store i1 %t372, ptr %l210
  br label %bb94
bb94:
  %t376 = load i1, ptr %l210, !tbaa !21
  store i1 %t376, ptr %l207, !tbaa !21
  br label %bb98
bb95:
  br label %bb96
bb96:
  call void @__olang_ert_req_clear()
  %t377 = getelementptr %"compiler/check:Ask", ptr %l30, i32 0, i32 3
  %t378 = load ptr, ptr %t377, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2ePush_3ccompiler_2fast_3aIf_26_3e(ptr %s0, ptr %v1, ptr %l27, ptr %t378)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb104
bb98:
  %t381 = load i1, ptr %l207, !tbaa !21
  store i1 %t381, ptr %l32, !tbaa !21
  %t382 = load i64, ptr %l11, !tbaa !24
  %t384 = add i64 %t382, 1
  store i64 %t384, ptr %l11, !tbaa !24
  %t386 = load ptr, ptr %l10, !tbaa !29
  %t388 = getelementptr %"compiler/interp:Exec", ptr %t386, i32 0, i32 4
  %t389 = getelementptr %"compiler/eval:Machine", ptr %t388, i32 0, i32 14
  %t390 = load i1, ptr %t389, !tbaa !21
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb99, label %bb100
bb99:
  %t394 = load ptr, ptr %l3, !tbaa !29
  %t395 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v3, ptr %t394, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t395, i1 true)
  br label %bb101
bb100:
  %t398 = load ptr, ptr %l2, !tbaa !29
  %t399 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  %t400 = load i1, ptr %l32, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v2, ptr %t398, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t399, i1 %t400)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s21)
  br label %bb104
bb104:
  %t404 = load i64, ptr %l29, !tbaa !24
  %t406 = add i64 %t404, 1
  store i64 %t406, ptr %l29, !tbaa !24
  br label %bb79
bb105:
  %t408 = load ptr, ptr %l1, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Program", ptr %t411, i32 0, i32 41
  store ptr %t413, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb106
bb106:
  store %olang.scope zeroinitializer, ptr %s28
  %t415 = load i64, ptr %l34, !tbaa !24
  store i64 %t415, ptr %l229, !tbaa !24
  %t416 = load ptr, ptr %l33, !tbaa !29
  %t418 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v1, ptr %t416)
  store i64 %t418, ptr %l231
  br label %bb107
bb107:
  %t419 = load i64, ptr %l229, !tbaa !24
  %t420 = load i64, ptr %l231, !tbaa !24
  %t421 = icmp slt i64 %t419, %t420
  %t423 = xor i1 %t421, true
  br i1 %t423, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s28)
  br label %bb140
bb109:
  br label %bb110
bb110:
  %t425 = load ptr, ptr %l33, !tbaa !29
  %t426 = load i64, ptr %l34, !tbaa !24
  %t429 = call %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v1, ptr %v1, ptr %t425, i64 %t426)
  store %"compiler/generic:ConstAsk" %t429, ptr %l236
  br label %bb111
bb111:
  %t430 = load %"compiler/generic:ConstAsk", ptr %l236
  store %"compiler/generic:ConstAsk" %t430, ptr %l35
  %t431 = getelementptr %"compiler/generic:ConstAsk", ptr %l35, i32 0, i32 6
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  store { i64, ptr } %t432, ptr %l36, !tbaa !27
  %t434 = load ptr, ptr %l4, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t438 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v4, ptr %v1, ptr %t434, { i64, ptr } %t435)
  store i1 %t438, ptr %l240
  br label %bb112
bb112:
  %t439 = load i1, ptr %l240, !tbaa !21
  br i1 %t439, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s28)
  br label %bb139
bb114:
  br label %bb115
bb115:
  %t440 = load i64, ptr %l11, !tbaa !24
  %t442 = add i64 %t440, 1
  store i64 %t442, ptr %l11, !tbaa !24
  %t444 = load ptr, ptr %l1, !tbaa !29
  %t445 = getelementptr %"compiler/generic:ConstAsk", ptr %l35, i32 0, i32 0
  %t446 = load i64, ptr %t445, !tbaa !24
  %t447 = getelementptr %"compiler/generic:ConstAsk", ptr %l35, i32 0, i32 3
  %t448 = load i64, ptr %t447, !tbaa !24
  %t449 = getelementptr %"compiler/generic:ConstAsk", ptr %l35, i32 0, i32 4
  %t450 = load { i64, ptr }, ptr %t449, !tbaa !27
  %t451 = getelementptr %"compiler/generic:ConstAsk", ptr %l35, i32 0, i32 5
  %t452 = load { i64, ptr }, ptr %t451, !tbaa !27
  %t453 = getelementptr %"compiler/generic:ConstAsk", ptr %l35, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t455 = getelementptr %"compiler/generic:ConstAsk", ptr %l35, i32 0, i32 2
  %t456 = load i32, ptr %t455, !tbaa !23
  %t464 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t444, i64 %t446, i64 %t448, { i64, ptr } %t450, { i64, ptr } %t452, ptr %t454, i32 %t456)
  store i64 %t464, ptr %l250
  br label %bb116
bb116:
  %t465 = load i64, ptr %l250, !tbaa !24
  store i64 %t465, ptr %l37, !tbaa !24
  %t466 = load i64, ptr %l37, !tbaa !24
  %t468 = icmp slt i64 %t466, 0
  br i1 %t468, label %bb117, label %bb118
bb117:
  %t470 = load ptr, ptr %l4, !tbaa !29
  %t471 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t471, 1
  %t474 = extractvalue { i64, ptr } %t471, 0
  %t475 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t474)
  call void @olang_textcopy(ptr %t475, ptr %t473, i64 %t474)
  %t476 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t479 = extractvalue { i64, ptr } %t477, 0
  %t480 = extractvalue { i64, ptr } %t477, 1
  %t481 = mul i64 %t479, 1
  %t482 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t481)
  call void @llvm.memcpy.p0.p0.i64(ptr %t482, ptr %t480, i64 %t481, i1 false)
  %t483 = insertvalue { i64, ptr } undef, i64 %t479, 0
  %t484 = insertvalue { i64, ptr } %t483, ptr %t482, 1
  %t485 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t470, { i64, ptr } %t484, i64 %t485)
  br label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_scope_close(ptr %s28)
  br label %bb139
bb120:
  %t489 = load i64, ptr %l37, !tbaa !24
  %t491 = trunc i64 %t489 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t493
  %t494 = getelementptr { i64, [2 x i64] }, ptr %t493, i32 0, i32 0
  store i64 0, ptr %t494
  %t496 = insertvalue { i32 } undef, i32 %t491, 0
  %t497 = getelementptr { i64, [2 x i64] }, ptr %t493, i32 0, i32 1
  store { i32 } %t496, ptr %t497
  %t498 = load { i64, [2 x i64] }, ptr %t493
  store { i64, [2 x i64] } %t498, ptr %l38
  %t500 = load ptr, ptr %l10, !tbaa !29
  %t501 = load { i64, [2 x i64] }, ptr %l38
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v1, ptr %t500, { i64, [2 x i64] } %t501)
  br label %bb121
bb121:
  %t504 = load ptr, ptr %l10, !tbaa !29
  %t506 = getelementptr %"compiler/interp:Exec", ptr %t504, i32 0, i32 4
  store ptr %t506, ptr %l265, !tbaa !29
  %t507 = load { i64, [2 x i64] }, ptr %l38
  store { i64, [2 x i64] } %t507, ptr %l266
  %t508 = icmp sge i64 0, 0
  br i1 %t508, label %bb122, label %bb123
bb122:
  %t510 = icmp sle i64 0, 1152921504606846975
  br i1 %t510, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @olang_loc_b43ed542b52bdb2d_e8039c8a87e26b41)
  unreachable
bb124:
  %t512 = mul i64 0, 8
  %t513 = insertvalue { i64, ptr } undef, i64 0, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t515 = load ptr, ptr %l265, !tbaa !29
  %t516 = load { i64, [2 x i64] }, ptr %l266
  %t518 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v1, ptr %s28, ptr %s28, ptr %t515, { i64, [2 x i64] } %t516, { i64, ptr } %t514)
  store { i64, [5 x i64] } %t518, ptr %l270
  br label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_b43ed542b52bdb2d_e8039c8a87e26b41)
  unreachable
bb126:
  %t519 = load { i64, [5 x i64] }, ptr %l270
  %t522 = extractvalue { i64, [5 x i64] } %t519, 0
  %t523 = icmp eq i64 %t522, 0
  br i1 %t523, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb132
bb129:
  %t525 = load ptr, ptr %l4, !tbaa !29
  store ptr %t525, ptr %l273, !tbaa !29
  %t526 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t526, 1
  %t529 = extractvalue { i64, ptr } %t526, 0
  %t530 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t529)
  call void @olang_textcopy(ptr %t530, ptr %t528, i64 %t529)
  %t531 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t532 = insertvalue { i64, ptr } %t531, ptr %t530, 1
  %t534 = extractvalue { i64, ptr } %t532, 0
  %t535 = extractvalue { i64, ptr } %t532, 1
  %t536 = mul i64 %t534, 1
  %t537 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t536)
  call void @llvm.memcpy.p0.p0.i64(ptr %t537, ptr %t535, i64 %t536, i1 false)
  %t538 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t537, 1
  store { i64, ptr } %t539, ptr %l276, !tbaa !27
  %t540 = load ptr, ptr %l10, !tbaa !29
  %t542 = getelementptr %"compiler/interp:Exec", ptr %t540, i32 0, i32 4
  %t543 = load ptr, ptr %l10, !tbaa !29
  %t545 = getelementptr %"compiler/interp:Exec", ptr %t543, i32 0, i32 4
  %t546 = getelementptr %"compiler/eval:Machine", ptr %t545, i32 0, i32 10
  %t547 = load %"compiler/eval:Ptr", ptr %t546
  %t548 = getelementptr %"compiler/generic:ConstAsk", ptr %l35, i32 0, i32 2
  %t549 = load i32, ptr %t548, !tbaa !23
  %t553 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v1, ptr %t542, %"compiler/eval:Ptr" %t547, i32 %t549)
  store i64 %t553, ptr %l282
  br label %bb130
bb130:
  %t554 = load ptr, ptr %l273, !tbaa !29
  %t555 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t556 = load i64, ptr %l282, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t554, { i64, ptr } %t555, i64 %t556)
  br label %bb131
bb131:
  br label %bb138
bb132:
  br i1 true, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb137
bb135:
  %t557 = load ptr, ptr %l4, !tbaa !29
  %t558 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t560 = extractvalue { i64, ptr } %t558, 1
  %t561 = extractvalue { i64, ptr } %t558, 0
  %t562 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t561)
  call void @olang_textcopy(ptr %t562, ptr %t560, i64 %t561)
  %t563 = insertvalue { i64, ptr } undef, i64 %t561, 0
  %t564 = insertvalue { i64, ptr } %t563, ptr %t562, 1
  %t566 = extractvalue { i64, ptr } %t564, 0
  %t567 = extractvalue { i64, ptr } %t564, 1
  %t568 = mul i64 %t566, 1
  %t569 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t568)
  call void @llvm.memcpy.p0.p0.i64(ptr %t569, ptr %t567, i64 %t568, i1 false)
  %t570 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  %t572 = load i64, ptr @G_2ecompiler_2fgeneric_2eRunTimeLength, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v4, ptr %v4, ptr %t557, { i64, ptr } %t571, i64 %t572)
  br label %bb136
bb136:
  br label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_f84cb7d5463d9835_35d9cf4f803d5b1)
  unreachable
bb138:
  call void @__olang_scope_close(ptr %s28)
  br label %bb139
bb139:
  %t576 = load i64, ptr %l34, !tbaa !24
  %t578 = add i64 %t576, 1
  store i64 %t578, ptr %l34, !tbaa !24
  br label %bb106
bb140:
  store ptr %l9, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb141
bb141:
  store %olang.scope zeroinitializer, ptr %s38
  %t581 = load i64, ptr %l41, !tbaa !24
  store i64 %t581, ptr %l291, !tbaa !24
  %t582 = load ptr, ptr %l40, !tbaa !29
  %t584 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H8bd9ddbe6d7efc10dd35c4d42ad9dacf(ptr %s0, ptr %t582)
  store i64 %t584, ptr %l293
  br label %bb142
bb142:
  %t585 = load i64, ptr %l291, !tbaa !24
  %t586 = load i64, ptr %l293, !tbaa !24
  %t587 = icmp slt i64 %t585, %t586
  %t589 = xor i1 %t587, true
  br i1 %t589, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s38)
  br label %bb187
bb144:
  br label %bb145
bb145:
  %t591 = load ptr, ptr %l40, !tbaa !29
  %t592 = load i64, ptr %l41, !tbaa !24
  %t595 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H7486c711b8ab0d124cd9b327dc5d14f9(ptr %s0, ptr %t591, i64 %t592)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t595, ptr %l298
  br label %bb146
bb146:
  %t596 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l298
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t596, ptr %l42
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = getelementptr %"compiler/load:Loader", ptr %t597, i32 0, i32 5
  %t600 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l42, i32 0, i32 0
  %t601 = load i64, ptr %t600, !tbaa !24
  %t604 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t599, i64 %t601)
  store ptr %t604, ptr %l302
  br label %bb147
bb147:
  %t605 = load ptr, ptr %l302, !tbaa !29
  %t607 = getelementptr %"compiler/load:Module", ptr %t605, i32 0, i32 8
  %t608 = load { i64, ptr }, ptr %t607, !tbaa !27
  %t609 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l42, i32 0, i32 1
  %t610 = load i32, ptr %t609, !tbaa !23
  %t613 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t608, i32 %t610)
  store ptr %t613, ptr %l306
  br label %bb148
bb148:
  %t614 = load ptr, ptr %l306, !tbaa !29
  store ptr %t614, ptr %l43, !tbaa !29
  %t615 = load ptr, ptr %l43, !tbaa !29
  %t617 = icmp eq ptr %t615, null
  br i1 %t617, label %bb149, label %bb150
bb149:
  call void @__olang_scope_close(ptr %s38)
  br label %bb186
bb150:
  br label %bb151
bb151:
  %t619 = load ptr, ptr %l10, !tbaa !29
  %t620 = load ptr, ptr %l1, !tbaa !29
  %t621 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l42, i32 0, i32 0
  %t622 = load i64, ptr %t621, !tbaa !24
  %t623 = load ptr, ptr %l43, !tbaa !29
  %t628 = call %"compiler/interp:chained" @compiler_2finterp_2echain(ptr %v1, ptr %v1, ptr %v0, ptr %s38, ptr %t619, ptr %t620, i64 %t622, ptr %t623)
  store %"compiler/interp:chained" %t628, ptr %l313
  br label %bb152
bb152:
  %t629 = load %"compiler/interp:chained", ptr %l313
  store %"compiler/interp:chained" %t629, ptr %l44
  %t630 = getelementptr %"compiler/interp:chained", ptr %l44, i32 0, i32 0
  %t631 = load i64, ptr %t630, !tbaa !24
  store i64 %t631, ptr %l45, !tbaa !24
  %t633 = getelementptr %"compiler/interp:chained", ptr %l44, i32 0, i32 1
  %t634 = load i1, ptr %t633, !tbaa !21
  store i1 %t634, ptr %l46, !tbaa !21
  %t636 = getelementptr %"compiler/interp:chained", ptr %l44, i32 0, i32 2
  %t637 = load { i64, ptr }, ptr %t636, !tbaa !27
  store { i64, ptr } %t637, ptr %l47, !tbaa !27
  %t639 = getelementptr %"compiler/interp:chained", ptr %l44, i32 0, i32 3
  %t640 = load { i64, [3 x i64] }, ptr %t639
  store { i64, [3 x i64] } %t640, ptr %l48
  %t642 = load i1, ptr %l46, !tbaa !21
  %t644 = xor i1 %t642, true
  br i1 %t644, label %bb153, label %bb154
bb153:
  %t646 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t648 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s38, ptr %s38, { i64, ptr } %t646, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t648, ptr %l322
  br label %bb155
bb154:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb156
bb155:
  %t649 = load i1, ptr %l322, !tbaa !21
  store i1 %t649, ptr %l320, !tbaa !21
  br label %bb156
bb156:
  %t650 = load i1, ptr %l320, !tbaa !21
  br i1 %t650, label %bb157, label %bb158
bb157:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/load:Loader", ptr %t651, i32 0, i32 4
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t655 = load { i64, [3 x i64] }, ptr %l48
  %t658 = call i1 @compiler_2finterp_2econdSaid(ptr %v0, ptr %t654, { i64, [3 x i64] } %t655)
  store i1 %t658, ptr %l327
  br label %bb159
bb158:
  store i1 false, ptr %l323, !tbaa !21
  br label %bb160
bb159:
  %t659 = load i1, ptr %l327, !tbaa !21
  store i1 %t659, ptr %l323, !tbaa !21
  br label %bb160
bb160:
  %t660 = load i1, ptr %l323, !tbaa !21
  br i1 %t660, label %bb161, label %bb162
bb161:
  call void @__olang_scope_close(ptr %s38)
  br label %bb186
bb162:
  br label %bb163
bb163:
  %t661 = load i1, ptr %l46, !tbaa !21
  %t663 = xor i1 %t661, true
  br i1 %t663, label %bb164, label %bb165
bb164:
  %t665 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t667 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s38, ptr %s38, { i64, ptr } %t665, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store i1 %t667, ptr %l332
  br label %bb166
bb165:
  store i1 false, ptr %l330, !tbaa !21
  br label %bb167
bb166:
  %t668 = load i1, ptr %l332, !tbaa !21
  store i1 %t668, ptr %l330, !tbaa !21
  br label %bb167
bb167:
  %t669 = load i1, ptr %l330, !tbaa !21
  br i1 %t669, label %bb168, label %bb169
bb168:
  %t670 = load ptr, ptr %l1, !tbaa !29
  %t672 = getelementptr %"compiler/check:Checker", ptr %t670, i32 0, i32 111
  %t673 = load i1, ptr %t672, !tbaa !21
  store i1 %t673, ptr %l333, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l333, !tbaa !21
  br label %bb170
bb170:
  %t675 = load i1, ptr %l333, !tbaa !21
  br i1 %t675, label %bb171, label %bb172
bb171:
  call void @__olang_scope_close(ptr %s38)
  br label %bb186
bb172:
  br label %bb173
bb173:
  %t676 = load i1, ptr %l46, !tbaa !21
  %t678 = xor i1 %t676, true
  br i1 %t678, label %bb174, label %bb175
bb174:
  store %olang.scope zeroinitializer, ptr %s42
  store ptr %a8, ptr %l338, !tbaa !29
  %t681 = load { i64, [3 x i64] }, ptr %l48
  store { i64, [3 x i64] } %t681, ptr %l339
  %t682 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t684 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s38, ptr %s42, { i64, ptr } %t682, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t684, ptr %l341
  br label %bb176
bb175:
  br label %bb184
bb176:
  %t685 = load i1, ptr %l341, !tbaa !21
  br i1 %t685, label %bb177, label %bb178
bb177:
  %t686 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnseen(ptr %v8)
  store %"compiler/msgs:Msg" %t686, ptr %l343
  br label %bb179
bb178:
  %t687 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t689 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUndecidable(ptr %s38, ptr %v8, { i64, ptr } %t687)
  store %"compiler/msgs:Msg" %t689, ptr %l345
  br label %bb180
bb179:
  %t690 = load %"compiler/msgs:Msg", ptr %l343
  store %"compiler/msgs:Msg" %t690, ptr %l342
  br label %bb181
bb180:
  %t691 = load %"compiler/msgs:Msg", ptr %l345
  store %"compiler/msgs:Msg" %t691, ptr %l342
  br label %bb181
bb181:
  %t692 = load { i64, [3 x i64] }, ptr %l339
  %t693 = load %"compiler/msgs:Msg", ptr %l342
  %t694 = call %"compiler/interp:CondErr" @compiler_2finterp_3aCondErr_2ector(ptr %v8, ptr %v8, { i64, [3 x i64] } %t692, %"compiler/msgs:Msg" %t693)
  store %"compiler/interp:CondErr" %t694, ptr %l346
  br label %bb182
bb182:
  %t695 = load ptr, ptr %l338, !tbaa !29
  %t696 = load %"compiler/interp:CondErr", ptr %l346
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2ePush_3ccompiler_2finterp_3aCondErr_3e(ptr %v8, ptr %v8, ptr %t695, %"compiler/interp:CondErr" %t696)
  br label %bb183
bb183:
  %t697 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store i64 %t697, ptr %l45, !tbaa !24
  call void @__olang_scope_close(ptr %s42)
  br label %bb184
bb184:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t700 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l42, i32 0, i32 0
  %t701 = load i64, ptr %t700, !tbaa !24
  %t702 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l42, i32 0, i32 1
  %t703 = load i32, ptr %t702, !tbaa !23
  %t704 = load i64, ptr %l45, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %t699, i64 %t701, i32 %t703, i64 %t704)
  br label %bb185
bb185:
  %t709 = load i64, ptr %l11, !tbaa !24
  %t711 = add i64 %t709, 1
  store i64 %t711, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s38)
  br label %bb186
bb186:
  %t713 = load i64, ptr %l41, !tbaa !24
  %t715 = add i64 %t713, 1
  store i64 %t715, ptr %l41, !tbaa !24
  br label %bb141
bb187:
  %t717 = load i64, ptr %l11, !tbaa !24
  %t719 = icmp eq i64 %t717, 0
  br i1 %t719, label %bb188, label %bb189
bb188:
  store ptr %l27, ptr %l49, !tbaa !29
  store i64 0, ptr %l50, !tbaa !24
  br label %bb190
bb189:
  br label %bb199
bb190:
  %t722 = load i64, ptr %l50, !tbaa !24
  store i64 %t722, ptr %l359, !tbaa !24
  %t723 = load ptr, ptr %l49, !tbaa !29
  %t725 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2eLen_3ccompiler_2fast_3aIf_26_3e(ptr %s0, ptr %t723)
  store i64 %t725, ptr %l361
  br label %bb191
bb191:
  %t726 = load i64, ptr %l359, !tbaa !24
  %t727 = load i64, ptr %l361, !tbaa !24
  %t728 = icmp slt i64 %t726, %t727
  %t730 = xor i1 %t728, true
  br i1 %t730, label %bb192, label %bb193
bb192:
  br label %bb198
bb193:
  br label %bb194
bb194:
  %t732 = load ptr, ptr %l49, !tbaa !29
  %t733 = load i64, ptr %l50, !tbaa !24
  %t736 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2eAt_3ccompiler_2fast_3aIf_26_3e(ptr %s0, ptr %s0, ptr %t732, i64 %t733)
  store ptr %t736, ptr %l366
  br label %bb195
bb195:
  %t737 = load ptr, ptr %l366, !tbaa !29
  %t738 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v1, ptr %s0, ptr %t738, ptr %t737)
  br label %bb196
bb196:
  br label %bb197
bb197:
  %t742 = load i64, ptr %l50, !tbaa !24
  %t744 = add i64 %t742, 1
  store i64 %t744, ptr %l50, !tbaa !24
  br label %bb190
bb198:
  br label %bb199
bb199:
  %t746 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t746, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2finterp_2edecideContracts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/check:ContractAsk"
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l13 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [3 x i64] }
  %l17 = alloca i64
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca %"compiler/check:ContractAsk"
  %l57 = alloca i1
  %l65 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l70 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l73 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca { i64, [2 x i64] }
  %l94 = alloca { i64, [5 x i64] }
  %l104 = alloca i64
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca { i64, [3 x i64] }
  %l120 = alloca %"compiler/msgs:Msg"
  %l121 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca { i64, [3 x i64] }
  %l128 = alloca %"compiler/msgs:Msg"
  %l129 = alloca i64
  %l130 = alloca ptr
  %l131 = alloca i64
  %l137 = alloca { i64, [3 x i64] }
  %l138 = alloca %"compiler/msgs:Msg"
  %l140 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i64
  %l144 = alloca { i64, [3 x i64] }
  %l145 = alloca %"compiler/msgs:Msg"
  %l148 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  %t70 = alloca %"compiler/check:ContractAsk", align 8
  %t139 = alloca { i64, [2 x i64] }, align 8
  %t206 = alloca { i64, [3 x i64] }, align 8
  %t266 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l22
  br label %bb1
bb1:
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 102
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l25
  br label %bb2
bb2:
  %t19 = load i64, ptr %l25, !tbaa !24
  store i64 %t19, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb8
bb5:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l32, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l32, !tbaa !24
  store i64 %t46, ptr %l29, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l29, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 102
  %t69 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eAt_H56c1cddaee4bc4aa5c09605de1331e44(ptr %t70, ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  call void @llvm.memmove.p0.p0.i64(ptr %l53, ptr %t70, i64 136, i1 false)
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l53, i64 136, i1 false)
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 104
  %t76 = load i64, ptr %l10, !tbaa !24
  %t79 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t75, i64 %t76)
  store i1 %t79, ptr %l57
  br label %bb14
bb14:
  %t80 = load i1, ptr %l57, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb16:
  br label %bb17
bb17:
  %t81 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 2
  %t84 = getelementptr %"compiler/source:Span", ptr %t83, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t89 = shl i64 %t87, 32
  %t90 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 4
  %t91 = getelementptr %"compiler/source:Span", ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = sext i32 %t92 to i64
  %t97 = or i64 %t89, %t94
  %t100 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t82, i64 %t97)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t100, ptr %l65
  br label %bb18
bb18:
  %t101 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l65
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t101, ptr %l12
  %t102 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 2
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t110 = shl i64 %t108, 32
  %t113 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t103, i64 %t110)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t113, ptr %l70
  br label %bb19
bb19:
  %t114 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l70
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l13
  %t115 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  %t118 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t115)
  store i1 %t118, ptr %l73
  br label %bb20
bb20:
  %t119 = load i1, ptr %l73, !tbaa !21
  br i1 %t119, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb28
bb22:
  %t120 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 5
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t121, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t123, ptr %l76
  br label %bb23
bb23:
  %t124 = load i1, ptr %l76, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  %t127 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  %t130 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t127)
  store i1 %t130, ptr %l81
  br label %bb26
bb25:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb27
bb26:
  %t131 = load i1, ptr %l81, !tbaa !21
  store i1 %t131, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t132 = load i1, ptr %l78, !tbaa !21
  store i1 %t132, ptr %l74, !tbaa !21
  br label %bb28
bb28:
  %t133 = load i1, ptr %l74, !tbaa !21
  br i1 %t133, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb30:
  br label %bb31
bb31:
  %t134 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 0
  %t135 = load i64, ptr %t134, !tbaa !24
  %t137 = trunc i64 %t135 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [2 x i64] }, ptr %t139, i32 0, i32 0
  store i64 0, ptr %t140
  %t142 = insertvalue { i32 } undef, i32 %t137, 0
  %t143 = getelementptr { i64, [2 x i64] }, ptr %t139, i32 0, i32 1
  store { i32 } %t142, ptr %t143
  %t144 = load { i64, [2 x i64] }, ptr %t139
  store { i64, [2 x i64] } %t144, ptr %l14
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t147 = load { i64, [2 x i64] }, ptr %l14
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v1, ptr %t146, { i64, [2 x i64] } %t147)
  br label %bb32
bb32:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/interp:Exec", ptr %t150, i32 0, i32 4
  store ptr %t152, ptr %l89, !tbaa !29
  %t153 = load { i64, [2 x i64] }, ptr %l14
  store { i64, [2 x i64] } %t153, ptr %l90
  %t154 = icmp sge i64 0, 0
  br i1 %t154, label %bb33, label %bb34
bb33:
  %t156 = icmp sle i64 0, 1152921504606846975
  br i1 %t156, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d213ae2acd73c837_819e6544d8b9fb33)
  unreachable
bb35:
  %t158 = mul i64 0, 8
  %t159 = insertvalue { i64, ptr } undef, i64 0, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t161 = load ptr, ptr %l89, !tbaa !29
  %t162 = load { i64, [2 x i64] }, ptr %l90
  %t164 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v1, ptr %v1, ptr %v1, ptr %t161, { i64, [2 x i64] } %t162, { i64, ptr } %t160)
  store { i64, [5 x i64] } %t164, ptr %l94
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d213ae2acd73c837_819e6544d8b9fb33)
  unreachable
bb37:
  %t165 = load { i64, [5 x i64] }, ptr %l94
  %t168 = extractvalue { i64, [5 x i64] } %t165, 0
  %t169 = icmp eq i64 %t168, 0
  br i1 %t169, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb64
bb40:
  store %olang.scope zeroinitializer, ptr %s5
  %t171 = load i64, ptr %l4, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l4, !tbaa !24
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/interp:Exec", ptr %t175, i32 0, i32 4
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr %"compiler/interp:Exec", ptr %t178, i32 0, i32 4
  %t181 = getelementptr %"compiler/eval:Machine", ptr %t180, i32 0, i32 10
  %t182 = load %"compiler/eval:Ptr", ptr %t181
  %t183 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t187 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v1, ptr %t177, %"compiler/eval:Ptr" %t182, i32 %t183)
  store i64 %t187, ptr %l104
  br label %bb41
bb41:
  %t188 = load i64, ptr %l104, !tbaa !24
  %t189 = icmp ne i64 %t188, 0
  br i1 %t189, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb43:
  br label %bb44
bb44:
  %t191 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t191, i1 true)
  br label %bb45
bb45:
  %t194 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 1
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 2
  %t197 = getelementptr %"compiler/source:Span", ptr %t196, i32 0, i32 0
  %t198 = load i32, ptr %t197, !tbaa !23
  %t200 = sext i32 %t198 to i64
  %t201 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 2
  %t202 = getelementptr %"compiler/source:Span", ptr %t201, i32 0, i32 1
  %t203 = load i32, ptr %t202, !tbaa !23
  %t205 = sext i32 %t203 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t206
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t206, i32 0, i32 0
  store i64 3, ptr %t207
  %t209 = insertvalue { i64, i64, i64 } undef, i64 %t195, 0
  %t211 = insertvalue { i64, i64, i64 } %t209, i64 %t200, 1
  %t213 = insertvalue { i64, i64, i64 } %t211, i64 %t205, 2
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t206, i32 0, i32 1
  store { i64, i64, i64 } %t213, ptr %t214
  %t215 = load { i64, [3 x i64] }, ptr %t206
  store { i64, [3 x i64] } %t215, ptr %l16
  %t217 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 5
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t218, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t220, ptr %l115
  br label %bb46
bb46:
  %t221 = load i1, ptr %l115, !tbaa !21
  br i1 %t221, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t222 = load ptr, ptr %l2, !tbaa !29
  store ptr %t222, ptr %l116, !tbaa !29
  %t223 = load { i64, [3 x i64] }, ptr %l16
  store { i64, [3 x i64] } %t223, ptr %l117
  %t224 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 6
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  %t226 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 9
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t230 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConversionDoesNotFit(ptr %v0, ptr %v0, ptr %s7, { i64, ptr } %t225, { i64, ptr } %t227)
  store %"compiler/msgs:Msg" %t230, ptr %l120
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t231 = load ptr, ptr %l116, !tbaa !29
  %t232 = load { i64, [3 x i64] }, ptr %l117
  %t233 = load %"compiler/msgs:Msg", ptr %l120
  %t234 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t231, { i64, [3 x i64] } %t232, %"compiler/msgs:Msg" %t233)
  store i64 %t234, ptr %l121
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb51:
  %t235 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %s0, ptr %l3, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t235, i1 true)
  br label %bb52
bb52:
  %t238 = load ptr, ptr %l2, !tbaa !29
  store ptr %t238, ptr %l124, !tbaa !29
  %t239 = load { i64, [3 x i64] }, ptr %l16
  store { i64, [3 x i64] } %t239, ptr %l125
  %t240 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 6
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t242 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 5
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !27
  %t246 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractFalse(ptr %v0, ptr %v0, ptr %s5, { i64, ptr } %t241, { i64, ptr } %t243)
  store %"compiler/msgs:Msg" %t246, ptr %l128
  br label %bb53
bb53:
  %t247 = load ptr, ptr %l124, !tbaa !29
  %t248 = load { i64, [3 x i64] }, ptr %l125
  %t249 = load %"compiler/msgs:Msg", ptr %l128
  %t250 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t247, { i64, [3 x i64] } %t248, %"compiler/msgs:Msg" %t249)
  store i64 %t250, ptr %l129
  br label %bb54
bb54:
  %t251 = load i64, ptr %l129, !tbaa !24
  store i64 %t251, ptr %l17, !tbaa !24
  %t252 = load ptr, ptr %l2, !tbaa !29
  store ptr %t252, ptr %l130, !tbaa !29
  %t253 = load i64, ptr %l17, !tbaa !24
  store i64 %t253, ptr %l131, !tbaa !24
  %t254 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 3
  %t255 = load i64, ptr %t254, !tbaa !24
  %t256 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 4
  %t257 = getelementptr %"compiler/source:Span", ptr %t256, i32 0, i32 0
  %t258 = load i32, ptr %t257, !tbaa !23
  %t260 = sext i32 %t258 to i64
  %t261 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 4
  %t262 = getelementptr %"compiler/source:Span", ptr %t261, i32 0, i32 1
  %t263 = load i32, ptr %t262, !tbaa !23
  %t265 = sext i32 %t263 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [3 x i64] }, ptr %t266, i32 0, i32 0
  store i64 3, ptr %t267
  %t269 = insertvalue { i64, i64, i64 } undef, i64 %t255, 0
  %t271 = insertvalue { i64, i64, i64 } %t269, i64 %t260, 1
  %t273 = insertvalue { i64, i64, i64 } %t271, i64 %t265, 2
  %t274 = getelementptr { i64, [3 x i64] }, ptr %t266, i32 0, i32 1
  store { i64, i64, i64 } %t273, ptr %t274
  %t275 = load { i64, [3 x i64] }, ptr %t266
  store { i64, [3 x i64] } %t275, ptr %l137
  %t276 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteContractCondition(ptr %s5)
  store %"compiler/msgs:Msg" %t276, ptr %l138
  br label %bb55
bb55:
  %t277 = load ptr, ptr %l130, !tbaa !29
  %t278 = load i64, ptr %l131, !tbaa !24
  %t279 = load { i64, [3 x i64] }, ptr %l137
  %t280 = load %"compiler/msgs:Msg", ptr %l138
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s5, ptr %t277, i64 %t278, { i64, [3 x i64] } %t279, %"compiler/msgs:Msg" %t280)
  br label %bb56
bb56:
  %t281 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 8
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  %t284 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t282, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t284, ptr %l140
  br label %bb57
bb57:
  %t285 = load i1, ptr %l140, !tbaa !21
  %t286 = xor i1 %t285, true
  br i1 %t286, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t288 = load ptr, ptr %l2, !tbaa !29
  store ptr %t288, ptr %l142, !tbaa !29
  %t289 = load i64, ptr %l17, !tbaa !24
  store i64 %t289, ptr %l143, !tbaa !24
  %t290 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 7
  %t291 = load { i64, [3 x i64] }, ptr %t290
  store { i64, [3 x i64] } %t291, ptr %l144
  %t292 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s8)
  store %"compiler/msgs:Msg" %t292, ptr %l145
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t293 = getelementptr %"compiler/msgs:Msg", ptr %l145, i32 0, i32 0
  %t294 = load i32, ptr %t293, !range !{i32 0, i32 796}
  %t295 = getelementptr %"compiler/check:ContractAsk", ptr %l11, i32 0, i32 8
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  %t299 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s8, ptr %v0, ptr %s8, i32 %t294, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, { i64, ptr } %t296)
  store %"compiler/msgs:Msg" %t299, ptr %l148
  br label %bb61
bb61:
  %t300 = load ptr, ptr %l142, !tbaa !29
  %t301 = load i64, ptr %l143, !tbaa !24
  %t302 = load { i64, [3 x i64] }, ptr %l144
  %t303 = load %"compiler/msgs:Msg", ptr %l148
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t300, i64 %t301, { i64, [3 x i64] } %t302, %"compiler/msgs:Msg" %t303)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s8)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s5)
  br label %bb69
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_3238838aabc16991_ed85858096edfcc5)
  unreachable
bb69:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb70:
  %t304 = load i64, ptr %l9, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l9, !tbaa !24
  br label %bb9
bb71:
  %t308 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t308, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2finterp_2edecideTopAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/check:TopAssertAsk"
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca { i64, [5 x i64] }
  %l9 = alloca { i64, [3 x i64] }
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/check:TopAssertAsk"
  %l40 = alloca ptr
  %l41 = alloca { i64, [2 x i64] }
  %l45 = alloca { i64, [5 x i64] }
  %l61 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i32
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca { i64, [3 x i64] }
  %l72 = alloca %"compiler/msgs:Msg"
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca { i64, [3 x i64] }
  %l77 = alloca %"compiler/msgs:Msg"
  %l78 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca { i64, [3 x i64] }
  %l87 = alloca { i64, ptr }
  %l88 = alloca %"compiler/msgs:Msg"
  %l89 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca i64
  %l97 = alloca { i64, [3 x i64] }
  %l98 = alloca %"compiler/msgs:Msg"
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca { i64, [3 x i64] }
  %l110 = alloca %"compiler/msgs:Msg"
  %l111 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca { i64, [3 x i64] }
  %l119 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l126 = alloca %"compiler/msgs:Msg"
  %l127 = alloca i64
  %l130 = alloca ptr
  %l131 = alloca { i64, [3 x i64] }
  %l132 = alloca %"compiler/msgs:Msg"
  %l133 = alloca i64
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i64
  %t37 = alloca { i64, [2 x i64] }, align 8
  %t76 = alloca { i64, [3 x i64] }, align 8
  %t184 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 83
  store ptr %t14, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t16 = load i64, ptr %l5, !tbaa !24
  store i64 %t16, ptr %l25, !tbaa !24
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eL_H34364174f15757c2d142d60c88ce0944(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l27
  br label %bb2
bb2:
  %t20 = load i64, ptr %l25, !tbaa !24
  %t21 = load i64, ptr %l27, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb60
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call %"compiler/check:TopAssertAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eA_H4ee666e103d2e1a6dd21794f4936298a(ptr %v0, ptr %t26, i64 %t27)
  store %"compiler/check:TopAssertAsk" %t30, ptr %l32
  br label %bb6
bb6:
  %t31 = load %"compiler/check:TopAssertAsk", ptr %l32
  store %"compiler/check:TopAssertAsk" %t31, ptr %l6
  %t32 = getelementptr %"compiler/check:TopAssertAsk", ptr %l6, i32 0, i32 3
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = trunc i64 %t33 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 0, ptr %t38
  %t40 = insertvalue { i32 } undef, i32 %t35, 0
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  store { i32 } %t40, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t37
  store { i64, [2 x i64] } %t42, ptr %l7
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load { i64, [2 x i64] }, ptr %l7
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v1, ptr %t44, { i64, [2 x i64] } %t45)
  br label %bb7
bb7:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/interp:Exec", ptr %t48, i32 0, i32 4
  store ptr %t50, ptr %l40, !tbaa !29
  %t51 = load { i64, [2 x i64] }, ptr %l7
  store { i64, [2 x i64] } %t51, ptr %l41
  %t52 = icmp sge i64 0, 0
  br i1 %t52, label %bb8, label %bb9
bb8:
  %t54 = icmp sle i64 0, 1152921504606846975
  br i1 %t54, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c1dbe1436b3e45a6_af45377485db5b6a)
  unreachable
bb10:
  %t56 = mul i64 0, 8
  %t57 = insertvalue { i64, ptr } undef, i64 0, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t59 = load ptr, ptr %l40, !tbaa !29
  %t60 = load { i64, [2 x i64] }, ptr %l41
  %t62 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v1, ptr %v1, ptr %v1, ptr %t59, { i64, [2 x i64] } %t60, { i64, ptr } %t58)
  store { i64, [5 x i64] } %t62, ptr %l45
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c1dbe1436b3e45a6_af45377485db5b6a)
  unreachable
bb12:
  %t63 = load { i64, [5 x i64] }, ptr %l45
  store { i64, [5 x i64] } %t63, ptr %l8
  %t64 = getelementptr %"compiler/check:TopAssertAsk", ptr %l6, i32 0, i32 0
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = getelementptr %"compiler/check:TopAssertAsk", ptr %l6, i32 0, i32 2
  %t67 = getelementptr %"compiler/source:Span", ptr %t66, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  %t70 = sext i32 %t68 to i64
  %t71 = getelementptr %"compiler/check:TopAssertAsk", ptr %l6, i32 0, i32 2
  %t72 = getelementptr %"compiler/source:Span", ptr %t71, i32 0, i32 1
  %t73 = load i32, ptr %t72, !tbaa !23
  %t75 = sext i32 %t73 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t76, i32 0, i32 0
  store i64 3, ptr %t77
  %t79 = insertvalue { i64, i64, i64 } undef, i64 %t65, 0
  %t81 = insertvalue { i64, i64, i64 } %t79, i64 %t70, 1
  %t83 = insertvalue { i64, i64, i64 } %t81, i64 %t75, 2
  %t84 = getelementptr { i64, [3 x i64] }, ptr %t76, i32 0, i32 1
  store { i64, i64, i64 } %t83, ptr %t84
  %t85 = load { i64, [3 x i64] }, ptr %t76
  store { i64, [3 x i64] } %t85, ptr %l9
  %t87 = load i64, ptr %l3, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l3, !tbaa !24
  %t91 = load { i64, [5 x i64] }, ptr %l8
  %t93 = extractvalue { i64, [5 x i64] } %t91, 0
  %t94 = icmp eq i64 %t93, 0
  br i1 %t94, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb28
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/interp:Exec", ptr %t96, i32 0, i32 4
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/interp:Exec", ptr %t99, i32 0, i32 4
  %t102 = getelementptr %"compiler/eval:Machine", ptr %t101, i32 0, i32 10
  %t103 = load %"compiler/eval:Ptr", ptr %t102
  %t104 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t108 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v1, ptr %t98, %"compiler/eval:Ptr" %t103, i32 %t104)
  store i64 %t108, ptr %l61
  br label %bb16
bb16:
  %t109 = load i64, ptr %l61, !tbaa !24
  %t110 = icmp ne i64 %t109, 0
  br i1 %t110, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb18:
  br label %bb19
bb19:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/check:TopAssertAsk", ptr %l6, i32 0, i32 4
  %t114 = load i64, ptr %t113, !tbaa !24
  %t117 = call { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s3, ptr %t112, i64 %t114)
  %t118 = extractvalue { i32, { i64, ptr } } %t117, 1
  %t119 = extractvalue { i32, { i64, ptr } } %t117, 0
  store i32 %t119, ptr %l67
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb21, label %ok.121, !prof !99
ok.121:
  store { i64, ptr } %t118, ptr %l66
  br label %bb20
bb20:
  %t122 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t122, ptr %l63, !tbaa !27
  br label %bb25
bb21:
  %t123 = load i32, ptr %l67, !tbaa !23
  %t124 = ashr i32 %t123, 16
  %t126 = icmp eq i32 %t124, 1
  store i1 %t126, ptr %l69, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s5
  %t127 = load ptr, ptr %l2, !tbaa !29
  store ptr %t127, ptr %l70, !tbaa !29
  %t128 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t128, ptr %l71
  %t129 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopAssertFalse(ptr %s5)
  store %"compiler/msgs:Msg" %t129, ptr %l72
  br label %bb23
bb23:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load { i64, [3 x i64] }, ptr %l71
  %t132 = load %"compiler/msgs:Msg", ptr %l72
  %t133 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t130, { i64, [3 x i64] } %t131, %"compiler/msgs:Msg" %t132)
  store i64 %t133, ptr %l73
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb25:
  %t134 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t135 = load ptr, ptr %l2, !tbaa !29
  store ptr %t135, ptr %l74, !tbaa !29
  %t136 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t136, ptr %l75
  %t139 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopAssertFalseMessage(ptr %s3, ptr %s3, { i64, ptr } %t134)
  store %"compiler/msgs:Msg" %t139, ptr %l77
  br label %bb26
bb26:
  %t140 = load ptr, ptr %l74, !tbaa !29
  %t141 = load { i64, [3 x i64] }, ptr %l75
  %t142 = load %"compiler/msgs:Msg", ptr %l77
  %t143 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t140, { i64, [3 x i64] } %t141, %"compiler/msgs:Msg" %t142)
  store i64 %t143, ptr %l78
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb58
bb28:
  %t144 = load { i64, [5 x i64] }, ptr %l8
  %t146 = extractvalue { i64, [5 x i64] } %t144, 0
  %t147 = icmp eq i64 %t146, 2
  br i1 %t147, label %bb29, label %bb30
bb29:
  %t149 = getelementptr { i64, [5 x i64] }, ptr %l8, i32 0, i32 1
  %t150 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t149, i32 0, i32 0
  %t151 = load i32, ptr %t150, !range !{i32 0, i32 15}
  store i32 %t151, ptr %l11
  %t153 = getelementptr { i64, [5 x i64] }, ptr %l8, i32 0, i32 1
  %t154 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t153, i32 0, i32 1
  %t155 = load i64, ptr %t154
  store i64 %t155, ptr %l12, !tbaa !24
  %t157 = getelementptr { i64, [5 x i64] }, ptr %l8, i32 0, i32 1
  %t158 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t157, i32 0, i32 2
  %t159 = load %"compiler/source:Span", ptr %t158
  store %"compiler/source:Span" %t159, ptr %l13
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t161 = load ptr, ptr %l2, !tbaa !29
  store ptr %t161, ptr %l84, !tbaa !29
  %t162 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t162, ptr %l85
  %t163 = load i32, ptr %l11, !range !{i32 0, i32 15}
  %t165 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s6, i32 %t163)
  store { i64, ptr } %t165, ptr %l87
  br label %bb32
bb32:
  %t166 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t167 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %s6, ptr %s6, { i64, ptr } %t166)
  store %"compiler/msgs:Msg" %t167, ptr %l88
  br label %bb33
bb33:
  %t168 = load ptr, ptr %l84, !tbaa !29
  %t169 = load { i64, [3 x i64] }, ptr %l85
  %t170 = load %"compiler/msgs:Msg", ptr %l88
  %t171 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t168, { i64, [3 x i64] } %t169, %"compiler/msgs:Msg" %t170)
  store i64 %t171, ptr %l89
  br label %bb34
bb34:
  %t172 = load i64, ptr %l89, !tbaa !24
  %t173 = load ptr, ptr %l2, !tbaa !29
  store ptr %t173, ptr %l90, !tbaa !29
  store i64 %t172, ptr %l91, !tbaa !24
  %t175 = load i64, ptr %l12, !tbaa !24
  %t176 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t177 = load i32, ptr %t176, !tbaa !23
  %t179 = sext i32 %t177 to i64
  %t180 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t181 = load i32, ptr %t180, !tbaa !23
  %t183 = sext i32 %t181 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t184, i32 0, i32 0
  store i64 3, ptr %t185
  %t187 = insertvalue { i64, i64, i64 } undef, i64 %t175, 0
  %t189 = insertvalue { i64, i64, i64 } %t187, i64 %t179, 1
  %t191 = insertvalue { i64, i64, i64 } %t189, i64 %t183, 2
  %t192 = getelementptr { i64, [3 x i64] }, ptr %t184, i32 0, i32 1
  store { i64, i64, i64 } %t191, ptr %t192
  %t193 = load { i64, [3 x i64] }, ptr %t184
  store { i64, [3 x i64] } %t193, ptr %l97
  %t194 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s6)
  store %"compiler/msgs:Msg" %t194, ptr %l98
  br label %bb35
bb35:
  %t195 = load ptr, ptr %l90, !tbaa !29
  %t196 = load i64, ptr %l91, !tbaa !24
  %t197 = load { i64, [3 x i64] }, ptr %l97
  %t198 = load %"compiler/msgs:Msg", ptr %l98
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s6, ptr %t195, i64 %t196, { i64, [3 x i64] } %t197, %"compiler/msgs:Msg" %t198)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb37:
  %t199 = load { i64, [5 x i64] }, ptr %l8
  %t201 = extractvalue { i64, [5 x i64] } %t199, 0
  %t202 = icmp eq i64 %t201, 3
  br i1 %t202, label %bb38, label %bb39
bb38:
  %t204 = getelementptr { i64, [5 x i64] }, ptr %l8, i32 0, i32 1
  %t205 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t204, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205
  store { i64, ptr } %t206, ptr %l15, !tbaa !27
  %t208 = getelementptr { i64, [5 x i64] }, ptr %l8, i32 0, i32 1
  %t209 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t208, i32 0, i32 1
  %t210 = load i64, ptr %t209
  store i64 %t210, ptr %l16, !tbaa !24
  %t212 = getelementptr { i64, [5 x i64] }, ptr %l8, i32 0, i32 1
  %t213 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t212, i32 0, i32 2
  %t214 = load %"compiler/source:Span", ptr %t213
  store %"compiler/source:Span" %t214, ptr %l17
  br label %bb40
bb39:
  br label %bb51
bb40:
  %t216 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t217 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  %t218 = load ptr, ptr @__olang_prog_scope
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %t218, { i64, ptr } %t216, { i64, ptr } %t217)
  store i1 %t221, ptr %l106
  br label %bb41
bb41:
  %t222 = load i1, ptr %l106, !tbaa !21
  br i1 %t222, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t223 = load ptr, ptr %l2, !tbaa !29
  store ptr %t223, ptr %l107, !tbaa !29
  %t224 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t224, ptr %l108
  %t225 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t227 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %v1, ptr %s8, { i64, ptr } %t225)
  store %"compiler/msgs:Msg" %t227, ptr %l110
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t228 = load ptr, ptr %l2, !tbaa !29
  store ptr %t228, ptr %l117, !tbaa !29
  %t229 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t229, ptr %l118
  %t230 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t230, ptr %l119, !tbaa !27
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t232 = load i64, ptr %l16, !tbaa !24
  %t233 = load %"compiler/source:Span", ptr %l17
  %t237 = call { i64, ptr } @compiler_2finterp_2eline(ptr %v0, ptr %s9, ptr %t231, i64 %t232, %"compiler/source:Span" %t233)
  store { i64, ptr } %t237, ptr %l123
  br label %bb47
bb44:
  %t238 = load ptr, ptr %l107, !tbaa !29
  %t239 = load { i64, [3 x i64] }, ptr %l108
  %t240 = load %"compiler/msgs:Msg", ptr %l110
  %t241 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t238, { i64, [3 x i64] } %t239, %"compiler/msgs:Msg" %t240)
  store i64 %t241, ptr %l111
  br label %bb45
bb45:
  %t242 = load i64, ptr %l111, !tbaa !24
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = load i64, ptr %l16, !tbaa !24
  %t247 = load %"compiler/source:Span", ptr %l17
  call void @compiler_2finterp_2estaleNotes(ptr %v1, ptr %v0, ptr %t243, ptr %t244, i64 %t242, i64 %t246, %"compiler/source:Span" %t247)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb47:
  %t253 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t258 = add i64 %t255, %t257
  %t259 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = add i64 %t258, %t261
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t266 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t265)
  call void @olang_textcopy(ptr %t266, ptr %t254, i64 %t255)
  %t267 = getelementptr i8, ptr %t266, i64 %t255
  call void @olang_textcopy(ptr %t267, ptr %t256, i64 %t257)
  %t268 = getelementptr i8, ptr %t267, i64 %t257
  call void @olang_textcopy(ptr %t268, ptr %t260, i64 %t261)
  %t269 = getelementptr i8, ptr %t268, i64 %t261
  call void @olang_textcopy(ptr %t269, ptr %t263, i64 %t264)
  %t270 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t266, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = extractvalue { i64, ptr } %t271, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  %t280 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopAssertUndecidable(ptr %s9, ptr %s9, { i64, ptr } %t278)
  store %"compiler/msgs:Msg" %t280, ptr %l126
  br label %bb48
bb48:
  %t281 = load ptr, ptr %l117, !tbaa !29
  %t282 = load { i64, [3 x i64] }, ptr %l118
  %t283 = load %"compiler/msgs:Msg", ptr %l126
  %t284 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t281, { i64, [3 x i64] } %t282, %"compiler/msgs:Msg" %t283)
  store i64 %t284, ptr %l127
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  br label %bb58
bb51:
  %t285 = load { i64, [5 x i64] }, ptr %l8
  %t287 = extractvalue { i64, [5 x i64] } %t285, 0
  %t288 = icmp eq i64 %t287, 1
  br i1 %t288, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb57
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t290 = load ptr, ptr %l2, !tbaa !29
  store ptr %t290, ptr %l130, !tbaa !29
  %t291 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t291, ptr %l131
  %t292 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopAssertUndecidable(ptr %s11, ptr %s11, { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t292, ptr %l132
  br label %bb55
bb55:
  %t293 = load ptr, ptr %l130, !tbaa !29
  %t294 = load { i64, [3 x i64] }, ptr %l131
  %t295 = load %"compiler/msgs:Msg", ptr %l132
  %t296 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t293, { i64, [3 x i64] } %t294, %"compiler/msgs:Msg" %t295)
  store i64 %t296, ptr %l133
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_5ce1b8d60352552c_3e5898832c479718)
  unreachable
bb58:
  br label %bb59
bb59:
  %t297 = load i64, ptr %l5, !tbaa !24
  %t299 = add i64 %t297, 1
  store i64 %t299, ptr %l5, !tbaa !24
  br label %bb1
bb60:
  %t301 = load i64, ptr %l3, !tbaa !24
  store i64 %t301, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2finterp_2efalseMessage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l7 = alloca %"compiler/msgs:Msg"
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l20 = alloca %"compiler/msgs:Msg"
  %l22 = alloca %"compiler/msgs:Msg"
  %l24 = alloca %"compiler/msgs:Msg"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:AssertAsk", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:AssertAsk", ptr %t6, i32 0, i32 7
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %v1, ptr %v2, { i64, ptr } %t9)
  store %"compiler/msgs:Msg" %t11, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t12 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t12, ptr %rv
  br label %ret
bb4:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/check:AssertAsk", ptr %t13, i32 0, i32 5
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp sge i64 %t16, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/check:AssertAsk", ptr %t21, i32 0, i32 5
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = call { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %s2, ptr %a0, i64 %t24)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l16
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb8, label %ok.31, !prof !99
ok.31:
  store { i64, ptr } %t28, ptr %l15
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t32 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t32, ptr %l11, !tbaa !27
  br label %bb11
bb8:
  %t33 = load i32, ptr %l16, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call %"compiler/msgs:Msg" @compiler_2finterp_2ewrittenMessage(ptr %v1, ptr %v2, ptr %t37)
  store %"compiler/msgs:Msg" %t39, ptr %l20
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  %t40 = load %"compiler/msgs:Msg", ptr %l20
  store %"compiler/msgs:Msg" %t40, ptr %rv
  br label %ret
bb11:
  %t41 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t44 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %s2, ptr %v2, { i64, ptr } %t41)
  store %"compiler/msgs:Msg" %t44, ptr %l22
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  %t45 = load %"compiler/msgs:Msg", ptr %l22
  store %"compiler/msgs:Msg" %t45, ptr %rv
  br label %ret
bb13:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = call %"compiler/msgs:Msg" @compiler_2finterp_2ewrittenMessage(ptr %v1, ptr %v2, ptr %t46)
  store %"compiler/msgs:Msg" %t48, ptr %l24
  br label %bb14
bb14:
  %t49 = load %"compiler/msgs:Msg", ptr %l24
  store %"compiler/msgs:Msg" %t49, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i1
  %l38 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb34
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l19, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 11}
  %t37 = icmp eq i64 %t35, 7
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [6 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb27
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TopIf", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TopIf", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_ef1298413c90a2dc_ba44d1693e670768)
  unreachable
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l6, !tbaa !29
  %t63 = getelementptr %"compiler/ast:TopIf", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t64)
  store %"compiler/source:Span" %t66, ptr %l38
  br label %bb18
bb18:
  %t67 = getelementptr %"compiler/source:Span", ptr %l38, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = icmp eq i32 %t68, %t69
  store i1 %t72, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t74 = load i1, ptr %l32, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t75 = load ptr, ptr %l6, !tbaa !29
  store ptr %t75, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t78 = load ptr, ptr %l6, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %t78, i32 %t80)
  store ptr %t83, ptr %l47
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l47, !tbaa !29
  store ptr %t84, ptr %l7, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l7, !tbaa !29
  store ptr %t91, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2f4ce1a9e181e1f2_bd4ae6421df971e)
  unreachable
bb32:
  br label %bb33
bb33:
  %t94 = load i64, ptr %l3, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l3, !tbaa !24
  br label %bb4
bb34:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l19 = alloca ptr
  %l37 = alloca ptr
  %l46 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/ast:TopIf", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/ast:TopIf", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb6, label %bb7
bb5:
  br label %bb13
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6beaad51a5cbbd4f_ba25a08250cd8123)
  unreachable
bb7:
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/ast:TopIf", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/ast:TopBranch", ptr %t25, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t29, i32 %t30)
  store ptr %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l19, !tbaa !29
  store ptr %t34, ptr %l2, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TopIf", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/ast:TopIf", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb16, label %bb17
bb15:
  br label %bb23
bb16:
  call void @__olang_check_failed(ptr @olang_loc_337e2febbb969070_fe2fc98a6d253614)
  unreachable
bb17:
  br label %bb18
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t66 = getelementptr %"compiler/ast:TopBranch", ptr %t63, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call ptr @compiler_2finterp_2efindIf(ptr %v0, { i64, ptr } %t67, i32 %t68)
  store ptr %t71, ptr %l37
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l37, !tbaa !29
  store ptr %t72, ptr %l3, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l3, !tbaa !29
  store ptr %t79, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/ast:TopIf", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call ptr @compiler_2finterp_2efindInIf(ptr %v0, ptr %t85, i32 %t86)
  store ptr %t89, ptr %l46
  br label %bb24
bb24:
  %t90 = load ptr, ptr %l46, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2finterp_2eglobalModule(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, i32 }
  %l4 = alloca { i64, i32 }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %a0)
  store { i64, i32 } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, i32 }, ptr %l4
  store { i64, i32 } %t4, ptr %l1
  %t5 = getelementptr { i64, i32 }, ptr %l1, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i32 } @compiler_2finterp_2eglobalName(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i32
  %rv = alloca { i64, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l1
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64, i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l2, !tbaa !24
  %t15 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i32, ptr %l3, !tbaa !23
  %t22 = insertvalue { i64, i32 } undef, i64 %t19, 0
  %t24 = insertvalue { i64, i32 } %t22, i32 %t20, 1
  store { i64, i32 } %t24, ptr %rv
  br label %ret
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t26 = insertvalue { i64, i32 } undef, i64 -1, 0
  %t27 = insertvalue { i64, i32 } %t26, i32 0, 1
  store { i64, i32 } %t27, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c5607a0551bceea3_a83aa459e58f2847)
  unreachable
ret:
  %rr = load { i64, i32 }, ptr %rv
  ret { i64, i32 } %rr
}

define dso_local i32 @compiler_2finterp_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l23 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l48 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_4efe4c4a78894057_5e75e4c074554d53)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 11
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Block", ptr %t11, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 %t30
  %t35 = load ptr, ptr %t34, !tbaa !39
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 17}
  %t44 = icmp eq i64 %t42, 1
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t48, i32 0, i32 1
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t51 = load ptr, ptr %l32, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb12:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 1
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l30, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t66, i32 0, i32 1
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l7, !tbaa !23
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i64, ptr %t77
  store i64 %t78, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l6, !tbaa !29
  %t82 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t82, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t86, i32 0, i32 3
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l9, !tbaa !23
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp eq i64 %t90, %a1
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load i32, ptr %l9, !tbaa !23
  %t100 = icmp eq i32 %t96, %a2
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t102 = load i1, ptr %l48, !tbaa !21
  br i1 %t102, label %bb21, label %bb22
bb21:
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_1ec4d19c7606c42f_38a78c76cd6682ab)
  unreachable
bb29:
  br label %bb30
bb30:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l4, !tbaa !24
  br label %bb4
bb31:
  %t109 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2finterp_2ejudgeViews(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca %"compiler/views:Viewer"
  %t9 = alloca %"compiler/views:Viewer", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 12
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7
  call void @compiler_2fviews_3aViewer_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v0, ptr %t4, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t9, i64 216, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 216, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l6, i64 216, i1 false)
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %t12)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t10 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %a0, i64 %a1, i64 %t6)
  store { i64, ptr } %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l13
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18, !prof !99
ok.18:
  store i64 %t15, ptr %l12
  br label %bb2
bb2:
  %t19 = load i64, ptr %l12, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l10, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %l17, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = icmp sge i64 0, 0
  br i1 %t28, label %bb8, label %bb9
bb7:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = extractvalue { i64, ptr } %t30, 0
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t32, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l16, !tbaa !27
  br label %bb14
bb8:
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sle i64 0, %t38
  br i1 %t39, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_33cf42576bc92052_8a57929dd960fbd6)
  unreachable
bb10:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = load i64, ptr %l18, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_33cf42576bc92052_8a57929dd960fbd6)
  unreachable
bb12:
  %t45 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l17, !tbaa !24
  %t48 = getelementptr i8, ptr %t46, i64 0
  %t49 = sub i64 %t47, 0
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l16, !tbaa !27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_33cf42576bc92052_8a57929dd960fbd6)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2finterp_2enoteWhy(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l11 = alloca i1
  %l16 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l30 = alloca { i64, [3 x i64] }
  %l31 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %t47 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i64 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t5, %t6
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t20 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t11, i64 %t12, i64 %t16)
  store i64 %t20, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t21, i64 %t22, i64 %t26)
  store i64 %t30, ptr %l21
  br label %bb7
bb7:
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = icmp eq i64 %t31, %t32
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i64 %a1, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t40 = load i32, ptr %t39, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = sext i32 %t44 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 0
  store i64 3, ptr %t48
  %t50 = insertvalue { i64, i64, i64 } undef, i64 %t38, 0
  %t52 = insertvalue { i64, i64, i64 } %t50, i64 %t42, 1
  %t54 = insertvalue { i64, i64, i64 } %t52, i64 %t46, 2
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  store { i64, i64, i64 } %t54, ptr %t55
  %t56 = load { i64, [3 x i64] }, ptr %t47
  store { i64, [3 x i64] } %t56, ptr %l30
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s0)
  store %"compiler/msgs:Msg" %t57, ptr %l31
  br label %bb12
bb12:
  %t58 = load ptr, ptr %l23, !tbaa !29
  %t59 = load i64, ptr %l24, !tbaa !24
  %t60 = load { i64, [3 x i64] }, ptr %l30
  %t61 = load %"compiler/msgs:Msg", ptr %l31
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t58, i64 %t59, { i64, [3 x i64] } %t60, %"compiler/msgs:Msg" %t61)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2finterp_2estaleNotes(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, %"compiler/source:Span" }
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l15 = alloca { i64, [3 x i64] }
  %l16 = alloca %"compiler/msgs:Msg"
  %l19 = alloca { i64, %"compiler/source:Span" }
  %l24 = alloca ptr
  %l25 = alloca i64
  %l31 = alloca { i64, [3 x i64] }
  %l32 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t12 = alloca { i64, [3 x i64] }, align 8
  %t54 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  store i64 %t2, ptr %l9, !tbaa !24
  %t4 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t8 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t15 = insertvalue { i64, i64, i64 } undef, i64 %a3, 0
  %t17 = insertvalue { i64, i64, i64 } %t15, i64 %t7, 1
  %t19 = insertvalue { i64, i64, i64 } %t17, i64 %t11, 2
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t12, i32 0, i32 1
  store { i64, i64, i64 } %t19, ptr %t20
  %t21 = load { i64, [3 x i64] }, ptr %t12
  store { i64, [3 x i64] } %t21, ptr %l15
  %t22 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s0)
  store %"compiler/msgs:Msg" %t22, ptr %l16
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l8, !tbaa !29
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = load { i64, [3 x i64] }, ptr %l15
  %t26 = load %"compiler/msgs:Msg", ptr %l16
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v1, ptr %s0, ptr %t23, i64 %t24, { i64, [3 x i64] } %t25, %"compiler/msgs:Msg" %t26)
  br label %bb2
bb2:
  %t29 = getelementptr %"compiler/interp:Exec", ptr %a0, i32 0, i32 4
  %t31 = call { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %t29)
  store { i64, %"compiler/source:Span" } %t31, ptr %l19
  br label %bb3
bb3:
  %t32 = load { i64, %"compiler/source:Span" }, ptr %l19
  store { i64, %"compiler/source:Span" } %t32, ptr %l5
  %t33 = getelementptr { i64, %"compiler/source:Span" }, ptr %l5, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, %"compiler/source:Span" }, ptr %l5, i32 0, i32 1
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l7
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l25, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t50 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = sext i32 %t51 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 0
  store i64 3, ptr %t55
  %t57 = insertvalue { i64, i64, i64 } undef, i64 %t45, 0
  %t59 = insertvalue { i64, i64, i64 } %t57, i64 %t49, 1
  %t61 = insertvalue { i64, i64, i64 } %t59, i64 %t53, 2
  %t62 = getelementptr { i64, [3 x i64] }, ptr %t54, i32 0, i32 1
  store { i64, i64, i64 } %t61, ptr %t62
  %t63 = load { i64, [3 x i64] }, ptr %t54
  store { i64, [3 x i64] } %t63, ptr %l31
  %t64 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrewHere(ptr %s1)
  store %"compiler/msgs:Msg" %t64, ptr %l32
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t65 = load ptr, ptr %l24, !tbaa !29
  %t66 = load i64, ptr %l25, !tbaa !24
  %t67 = load { i64, [3 x i64] }, ptr %l31
  %t68 = load %"compiler/msgs:Msg", ptr %l32
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v1, ptr %s1, ptr %t65, i64 %t66, { i64, [3 x i64] } %t67, %"compiler/msgs:Msg" %t68)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2finterp_2estopWhy(ptr %v0, ptr %v1, { i64, [5 x i64] } %a0) #0 {
entry:
  %l1 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l3 = alloca { i64, [5 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [5 x i64] } %a0, ptr %l3
  %t2 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t2, ptr %l4
  br label %bb1
bb1:
  %t3 = load { i64, [5 x i64] }, ptr %l3
  %t4 = load %"compiler/source:Span", ptr %l4
  %t5 = call { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %s0, { i64, [5 x i64] } %t3, %"compiler/source:Span" %t4)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t5, ptr %l5
  br label %bb2
bb2:
  %t6 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l5
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t6, ptr %l1
  %t7 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l1, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = extractvalue { i64, ptr } %t22, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2finterp_2evalueWhy(ptr %v0, ptr %v1, { i64, [5 x i64] } %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca { i64, [5 x i64] }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, ptr }
  %l13 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l34 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  store { i64, [5 x i64] } %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t7 = load %"compiler/source:Span", ptr %l1
  %t9 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t6, 0
  %t10 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t9, i64 -1, 1
  %t12 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t10, %"compiler/source:Span" %t7, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t12, ptr %l13
  %t13 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l14, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13, i32 0, i32 0
  store { i64, ptr } %t28, ptr %t29, !tbaa !27
  %t30 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l13
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t30, ptr %rv
  br label %ret
bb4:
  %t31 = load { i64, [5 x i64] }, ptr %l0
  %t33 = extractvalue { i64, [5 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 3
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t36 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t37 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t36, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37
  store { i64, ptr } %t38, ptr %l2, !tbaa !27
  %t40 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t41 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t40, i32 0, i32 1
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t44, i32 0, i32 2
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l4
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = extractvalue { i64, ptr } %t48, 0
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t50, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load %"compiler/source:Span", ptr %l4
  %t58 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t54, 0
  %t60 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t58, i64 %t55, 1
  %t62 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t60, %"compiler/source:Span" %t56, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t62, ptr %rv
  br label %ret
bb8:
  %t64 = load { i64, [5 x i64] }, ptr %l0
  %t66 = extractvalue { i64, [5 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 2
  br i1 %t67, label %bb9, label %bb10
bb9:
  %t69 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t70 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70, !range !{i32 0, i32 15}
  store i32 %t71, ptr %l5
  %t73 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t74 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t73, i32 0, i32 1
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t78 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t77, i32 0, i32 2
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l7
  br label %bb11
bb10:
  br label %bb19
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load i32, ptr %l5, !range !{i32 0, i32 15}
  %t83 = trunc i64 3 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb12, label %bb13
bb12:
  %t86 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t92 = icmp eq i32 %t87, %t89
  store i1 %t92, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t94 = load i1, ptr %l34, !tbaa !21
  br i1 %t94, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t96 = load %"compiler/source:Span", ptr %l1
  %t98 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t95, 0
  %t99 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t98, i64 -1, 1
  %t101 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t99, %"compiler/source:Span" %t96, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t101, ptr %l41
  %t102 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l41, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l42, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l43, !tbaa !24
  %t106 = load i64, ptr %l43, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l44, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l43, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t118 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l41, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  %t119 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l41
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t119, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t120 = load i32, ptr %l5, !range !{i32 0, i32 15}
  %t122 = call { i64, ptr } @compiler_2finterp_2eAbortWhy(ptr %s4, i32 %t120)
  store { i64, ptr } %t122, ptr %l46
  br label %bb18
bb18:
  %t123 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t129 = load i64, ptr %l6, !tbaa !24
  %t130 = load %"compiler/source:Span", ptr %l7
  %t132 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t128, 0
  %t134 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t132, i64 %t129, 1
  %t136 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t134, %"compiler/source:Span" %t130, 2
  call void @__olang_scope_close(ptr %s4)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t136, ptr %rv
  br label %ret
bb19:
  %t138 = load { i64, [5 x i64] }, ptr %l0
  %t140 = extractvalue { i64, [5 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 1
  br i1 %t141, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d102, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t144 = load %"compiler/source:Span", ptr %l1
  %t146 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t143, 0
  %t147 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t146, i64 -1, 1
  %t149 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t147, %"compiler/source:Span" %t144, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t149, ptr %l56
  %t150 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l56, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  store { i64, ptr } %t151, ptr %l57, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  store i64 %t153, ptr %l58, !tbaa !24
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = mul i64 %t154, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t155)
  %t157 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l59, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = load i64, ptr %l58, !tbaa !24
  %t164 = mul i64 %t163, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t160, ptr %t162, i64 %t164, i1 false)
  %t165 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t166 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l56, i32 0, i32 0
  store { i64, ptr } %t165, ptr %t166, !tbaa !27
  %t167 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l56
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t167, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9aa13344fea3f6d8_5ff568fedc30749c)
  unreachable
ret:
  %rr = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %rv
  ret { { i64, ptr }, i64, %"compiler/source:Span" } %rr
}

define dso_local %"compiler/msgs:Msg" @compiler_2finterp_2ewrittenMessage(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l7 = alloca %"compiler/msgs:Msg"
  %l8 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:AssertAsk", ptr %t1, i32 0, i32 8
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load i1, ptr %l3, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:AssertAsk", ptr %t10, i32 0, i32 8
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseWritten(ptr %v0, ptr %v1, { i64, ptr } %t13)
  store %"compiler/msgs:Msg" %t15, ptr %l7
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load %"compiler/msgs:Msg", ptr %l7
  store %"compiler/msgs:Msg" %t16, ptr %rv
  br label %ret
bb5:
  %t17 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %v1)
  store %"compiler/msgs:Msg" %t17, ptr %l8
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"compiler/msgs:Msg", ptr %l8
  store %"compiler/msgs:Msg" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local i1 @compiler_2finterp_2ewrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:VarDecl", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:VarDecl", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l1, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t30, i32 0, i32 2
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load i1, ptr %l2, !tbaa !21
  store i1 %t34, ptr %l12, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a437b17fd6ef2726_85fb06efd955f512)
  unreachable
bb17:
  %t36 = load i1, ptr %l12, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, [3 x i64] }, { i64, ptr } } @compiler_2finterp_2ezeroUseArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i8
  %l9 = alloca i8
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %lp13 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l29 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l74 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i1
  %l83 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l131 = alloca i1
  %l132 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l143 = alloca i1
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l163 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i64
  %l184 = alloca { i64, ptr }
  %l186 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l193 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %rv = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %t377 = alloca { i64, [3 x i64] }, align 8
  store { i64, [3 x i64] } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [3 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [3 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t15 = getelementptr { i64, i64, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  br label %bb98
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %t19)
  store { i64, ptr } %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = add i64 %t26, %t29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sle i64 %t32, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = add i64 %t38, %t41
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t50 = icmp sle i64 %t44, %t47
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l29, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb9, label %bb10
bb9:
  br label %bb97
bb10:
  br label %bb11
bb11:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l39, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = add i64 %t57, %t60
  store i64 %t63, ptr %l43, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l44, !tbaa !24
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = load i64, ptr %l39, !tbaa !24
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_69f8faa22d82cef9_e064f09003af3e5d)
  unreachable
bb14:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_69f8faa22d82cef9_e064f09003af3e5d)
  unreachable
bb16:
  %t77 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = load i64, ptr %l43, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t84, { i64, ptr } %t85)
  store i1 %t88, ptr %l50
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_69f8faa22d82cef9_e064f09003af3e5d)
  unreachable
bb18:
  %t89 = load i1, ptr %l50, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  store i1 %t92, ptr %l51, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = add i64 %t95, %t98
  %t102 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t107 = icmp slt i64 %t101, %t104
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l54, !tbaa !21
  br i1 %t109, label %bb25, label %bb26
bb25:
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = sub i64 %t111, 1
  %t115 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i8, ptr %t116, i64 %t113
  %t118 = load i8, ptr %t117, !tbaa !32
  store i8 %t118, ptr %l8, !tbaa !22
  %t120 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t120, ptr %l66, !tbaa !27
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t127 = add i64 %t121, %t124
  %t129 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 %t127
  %t132 = load i8, ptr %t131, !tbaa !32
  store i8 %t132, ptr %l9, !tbaa !22
  %t134 = load i8, ptr %l8, !tbaa !22
  %t136 = icmp eq i8 %t134, 60
  br i1 %t136, label %bb27, label %bb28
bb26:
  br label %bb95
bb27:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb29
bb28:
  %t138 = load i8, ptr %l8, !tbaa !22
  %t140 = icmp eq i8 %t138, 32
  store i1 %t140, ptr %l74, !tbaa !21
  br label %bb29
bb29:
  %t142 = load i1, ptr %l74, !tbaa !21
  br i1 %t142, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb32
bb31:
  %t143 = load i8, ptr %l8, !tbaa !22
  %t145 = icmp eq i8 %t143, 44
  store i1 %t145, ptr %l77, !tbaa !21
  br label %bb32
bb32:
  %t147 = load i1, ptr %l77, !tbaa !21
  br i1 %t147, label %bb33, label %bb34
bb33:
  %t148 = load i8, ptr %l9, !tbaa !22
  %t150 = icmp eq i8 %t148, 62
  br i1 %t150, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb38
bb35:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb37
bb36:
  %t152 = load i8, ptr %l9, !tbaa !22
  %t154 = icmp eq i8 %t152, 44
  store i1 %t154, ptr %l83, !tbaa !21
  br label %bb37
bb37:
  %t156 = load i1, ptr %l83, !tbaa !21
  store i1 %t156, ptr %l80, !tbaa !21
  br label %bb38
bb38:
  %t157 = load i1, ptr %l80, !tbaa !21
  br i1 %t157, label %bb39, label %bb40
bb39:
  %t158 = load i64, ptr %l7, !tbaa !24
  %t160 = sub i64 %t158, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb41
bb40:
  br label %bb94
bb41:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t163 = load i64, ptr %l4, !tbaa !24
  %t166 = icmp sgt i64 %t162, %t163
  br i1 %t166, label %bb42, label %bb43
bb42:
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t168, ptr %l92, !tbaa !27
  %t169 = load i64, ptr %l10, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i8, ptr %t172, i64 %t169
  %t174 = load i8, ptr %t173, !tbaa !32
  %t176 = icmp ne i8 %t174, 60
  store i1 %t176, ptr %l91, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb44
bb44:
  %t178 = load i1, ptr %l91, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t183 = sub i64 %t181, 1
  store i64 %t183, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  br label %bb41
bb49:
  %t185 = load i64, ptr %l10, !tbaa !24
  store i64 %t185, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i64, ptr %l4, !tbaa !24
  %t191 = icmp sgt i64 %t187, %t188
  br i1 %t191, label %bb51, label %bb52
bb51:
  %t193 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t193, ptr %l104, !tbaa !27
  %t194 = load i64, ptr %l11, !tbaa !24
  %t196 = sub i64 %t194, 1
  %t198 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i8, ptr %t199, i64 %t196
  %t201 = load i8, ptr %t200, !tbaa !32
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t201)
  store i1 %t203, ptr %l108
  br label %bb53
bb52:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb61
bb53:
  %t204 = load i1, ptr %l108, !tbaa !21
  br i1 %t204, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb57
bb55:
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t205, ptr %l110, !tbaa !27
  %t206 = load i64, ptr %l11, !tbaa !24
  %t208 = sub i64 %t206, 1
  %t210 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i8, ptr %t211, i64 %t208
  %t213 = load i8, ptr %t212, !tbaa !32
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t213)
  store i1 %t215, ptr %l114
  br label %bb56
bb56:
  %t216 = load i1, ptr %l114, !tbaa !21
  store i1 %t216, ptr %l109, !tbaa !21
  br label %bb57
bb57:
  %t217 = load i1, ptr %l109, !tbaa !21
  br i1 %t217, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb60
bb59:
  %t218 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t218, ptr %l116, !tbaa !27
  %t219 = load i64, ptr %l11, !tbaa !24
  %t221 = sub i64 %t219, 1
  %t223 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i8, ptr %t224, i64 %t221
  %t226 = load i8, ptr %t225, !tbaa !32
  %t228 = icmp eq i8 %t226, 95
  store i1 %t228, ptr %l115, !tbaa !21
  br label %bb60
bb60:
  %t230 = load i1, ptr %l115, !tbaa !21
  store i1 %t230, ptr %l103, !tbaa !21
  br label %bb61
bb61:
  %t231 = load i1, ptr %l103, !tbaa !21
  %t232 = xor i1 %t231, true
  br i1 %t232, label %bb62, label %bb63
bb62:
  br label %bb66
bb63:
  br label %bb64
bb64:
  %t234 = load i64, ptr %l11, !tbaa !24
  %t236 = sub i64 %t234, 1
  store i64 %t236, ptr %l11, !tbaa !24
  br label %bb65
bb65:
  br label %bb50
bb66:
  %t238 = load i64, ptr %l7, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t244 = add i64 %t238, %t241
  store i64 %t244, ptr %l12, !tbaa !24
  br label %bb67
bb67:
  %t246 = load i64, ptr %l12, !tbaa !24
  %t247 = load i64, ptr %l5, !tbaa !24
  %t250 = icmp slt i64 %t246, %t247
  br i1 %t250, label %bb68, label %bb69
bb68:
  %t252 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t252, ptr %l132, !tbaa !27
  %t253 = load i64, ptr %l12, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i8, ptr %t256, i64 %t253
  %t258 = load i8, ptr %t257, !tbaa !32
  %t260 = icmp ne i8 %t258, 62
  store i1 %t260, ptr %l131, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb70
bb70:
  %t262 = load i1, ptr %l131, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb71, label %bb72
bb71:
  br label %bb75
bb72:
  br label %bb73
bb73:
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l12, !tbaa !24
  br label %bb74
bb74:
  br label %bb67
bb75:
  %t269 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t269, ptr %l139, !tbaa !27
  %t270 = load i64, ptr %l10, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i8, ptr %t273, i64 %t270
  %t275 = load i8, ptr %t274, !tbaa !32
  %t277 = icmp eq i8 %t275, 60
  br i1 %t277, label %bb76, label %bb77
bb76:
  %t279 = load i64, ptr %l12, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t285 = icmp slt i64 %t279, %t282
  store i1 %t285, ptr %l143, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb78
bb78:
  %t287 = load i1, ptr %l143, !tbaa !21
  br i1 %t287, label %bb79, label %bb80
bb79:
  %t288 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t288, ptr %l148, !tbaa !27
  %t289 = load i64, ptr %l11, !tbaa !24
  store i64 %t289, ptr %l149, !tbaa !24
  %t290 = load i64, ptr %l7, !tbaa !24
  %t291 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t291, 0
  %t296 = add i64 %t290, %t293
  store i64 %t296, ptr %l153, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  store i64 %t298, ptr %l154, !tbaa !24
  %t299 = load i64, ptr %l149, !tbaa !24
  %t300 = icmp sge i64 %t299, 0
  br i1 %t300, label %bb81, label %bb82
bb80:
  br label %bb93
bb81:
  %t302 = load i64, ptr %l149, !tbaa !24
  %t303 = load i64, ptr %l153, !tbaa !24
  %t304 = icmp sle i64 %t302, %t303
  br i1 %t304, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb83:
  %t306 = load i64, ptr %l153, !tbaa !24
  %t307 = load i64, ptr %l154, !tbaa !24
  %t308 = icmp sle i64 %t306, %t307
  br i1 %t308, label %bb85, label %bb86
bb84:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb85:
  %t310 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = load i64, ptr %l149, !tbaa !24
  %t313 = load i64, ptr %l153, !tbaa !24
  %t314 = getelementptr i8, ptr %t311, i64 %t312
  %t315 = sub i64 %t313, %t312
  %t316 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t314, 1
  store { i64, ptr } %t317, ptr %l158, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t318, ptr %l159, !tbaa !27
  %t319 = load i64, ptr %l7, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t325 = add i64 %t319, %t322
  store i64 %t325, ptr %l163, !tbaa !24
  %t326 = load i64, ptr %l12, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l165, !tbaa !24
  %t329 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  store i64 %t330, ptr %l166, !tbaa !24
  %t331 = load i64, ptr %l163, !tbaa !24
  %t332 = icmp sge i64 %t331, 0
  br i1 %t332, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb87:
  %t334 = load i64, ptr %l163, !tbaa !24
  %t335 = load i64, ptr %l165, !tbaa !24
  %t336 = icmp sle i64 %t334, %t335
  br i1 %t336, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb89:
  %t338 = load i64, ptr %l165, !tbaa !24
  %t339 = load i64, ptr %l166, !tbaa !24
  %t340 = icmp sle i64 %t338, %t339
  br i1 %t340, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb91:
  %t342 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = load i64, ptr %l163, !tbaa !24
  %t345 = load i64, ptr %l165, !tbaa !24
  %t346 = getelementptr i8, ptr %t343, i64 %t344
  %t347 = sub i64 %t345, %t344
  %t348 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t346, 1
  %t350 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t354 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t355 = add i64 %t352, %t354
  %t357 = extractvalue { i64, ptr } %t349, 1
  %t358 = extractvalue { i64, ptr } %t349, 0
  %t359 = add i64 %t355, %t358
  %t360 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t359)
  call void @olang_textcopy(ptr %t360, ptr %t351, i64 %t352)
  %t361 = getelementptr i8, ptr %t360, i64 %t352
  call void @olang_textcopy(ptr %t361, ptr %t353, i64 %t354)
  %t362 = getelementptr i8, ptr %t361, i64 %t354
  call void @olang_textcopy(ptr %t362, ptr %t357, i64 %t358)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t360, 1
  %t365 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t365, ptr %lp13
  %t367 = load ptr, ptr %lp13
  store { i64, ptr } %t364, ptr %t367, !tbaa !27
  %t368 = load i64, ptr %l3, !tbaa !24
  %t369 = load i64, ptr %l7, !tbaa !24
  %t370 = load i64, ptr %l7, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t371, 0
  %t376 = add i64 %t370, %t373
  store { i64, [3 x i64] } zeroinitializer, ptr %t377
  %t378 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 0
  store i64 3, ptr %t378
  %t380 = insertvalue { i64, i64, i64 } undef, i64 %t368, 0
  %t382 = insertvalue { i64, i64, i64 } %t380, i64 %t369, 1
  %t384 = insertvalue { i64, i64, i64 } %t382, i64 %t376, 2
  %t385 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 1
  store { i64, i64, i64 } %t384, ptr %t385
  %t386 = load { i64, [3 x i64] }, ptr %t377
  %t387 = load ptr, ptr %lp13
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  %t390 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t386, 0
  %t392 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t390, { i64, ptr } %t388, 1
  store { { i64, [3 x i64] }, { i64, ptr } } %t392, ptr %rv
  br label %ret
bb92:
  call void @__olang_check_failed(ptr @olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800)
  unreachable
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t394 = load i64, ptr %l7, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l7, !tbaa !24
  br label %bb96
bb96:
  br label %bb5
bb97:
  %t398 = load { i64, [3 x i64] }, ptr %l1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d105, i32 0, i32 1) }, ptr %l184, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t401 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t398, 0
  %t403 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t401, { i64, ptr } %t399, 1
  store { { i64, [3 x i64] }, { i64, ptr } } %t403, ptr %l186
  %t404 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186, i32 0, i32 1
  %t405 = load { i64, ptr }, ptr %t404, !tbaa !27
  store { i64, ptr } %t405, ptr %l187, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  store i64 %t407, ptr %l188, !tbaa !24
  %t408 = load i64, ptr %l188, !tbaa !24
  %t409 = mul i64 %t408, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t409)
  %t411 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  store { i64, ptr } %t412, ptr %l189, !tbaa !27
  %t413 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = load i64, ptr %l188, !tbaa !24
  %t418 = mul i64 %t417, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t414, ptr %t416, i64 %t418, i1 false)
  %t419 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t420 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186, i32 0, i32 1
  store { i64, ptr } %t419, ptr %t420, !tbaa !27
  %t421 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l186
  store { { i64, [3 x i64] }, { i64, ptr } } %t421, ptr %rv
  br label %ret
bb98:
  br i1 true, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  %t422 = load { i64, [3 x i64] }, ptr %l1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d106, i32 0, i32 1) }, ptr %l191, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t425 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } undef, { i64, [3 x i64] } %t422, 0
  %t427 = insertvalue { { i64, [3 x i64] }, { i64, ptr } } %t425, { i64, ptr } %t423, 1
  store { { i64, [3 x i64] }, { i64, ptr } } %t427, ptr %l193
  %t428 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193, i32 0, i32 1
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  store { i64, ptr } %t429, ptr %l194, !tbaa !27
  %t430 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t430, 0
  store i64 %t431, ptr %l195, !tbaa !24
  %t432 = load i64, ptr %l195, !tbaa !24
  %t433 = mul i64 %t432, 1
  %t434 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t433)
  %t435 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t436 = insertvalue { i64, ptr } %t435, ptr %t434, 1
  store { i64, ptr } %t436, ptr %l196, !tbaa !27
  %t437 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = load i64, ptr %l195, !tbaa !24
  %t442 = mul i64 %t441, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t438, ptr %t440, i64 %t442, i1 false)
  %t443 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t444 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193, i32 0, i32 1
  store { i64, ptr } %t443, ptr %t444, !tbaa !27
  %t445 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l193
  store { { i64, [3 x i64] }, { i64, ptr } } %t445, ptr %rv
  br label %ret
bb102:
  call void @__olang_check_failed(ptr @olang_loc_196dd61ce96ecec0_7e4a472be9bda874)
  unreachable
ret:
  %rr = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %rv
  ret { { i64, [3 x i64] }, { i64, ptr } } %rr
}

define dso_local %"compiler/interp:CondErr" @compiler_2finterp_3aCondErr_2ector(ptr %v0, ptr %v1, { i64, [3 x i64] } %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %rv = alloca %"compiler/interp:CondErr"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/interp:CondErr" undef, { i64, [3 x i64] } %a0, 0
  %t8 = insertvalue %"compiler/interp:CondErr" %t6, %"compiler/msgs:Msg" %a1, 1
  store %"compiler/interp:CondErr" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/interp:CondErr", ptr %rv
  ret %"compiler/interp:CondErr" %rr
}

define dso_local void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i32
  %l6 = alloca %"compiler/lower:Lowerer"
  %l7 = alloca %"compiler/eval:Machine"
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"compiler/lower:Lowerer"
  %l25 = alloca %"compiler/eval:Machine"
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"compiler/interp:Exec"
  %t17 = alloca %"compiler/eval:Machine", align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  %t5 = load i32, ptr %l2, !range !{i32 0, i32 2}
  store i32 %t5, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t11 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %t7, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  store %"compiler/lower:Lowerer" %t11, ptr %l21
  br label %bb1
bb1:
  %t12 = load %"compiler/lower:Lowerer", ptr %l21
  store %"compiler/lower:Lowerer" %t12, ptr %l6
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l2, !range !{i32 0, i32 2}
  call void @compiler_2feval_2eNewMachine(ptr %t17, ptr %v0, ptr %v2, ptr %t15, i32 %t16)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t17, i64 784, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l25, i64 784, i1 false)
  %t20 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l26
  br label %bb3
bb3:
  %t21 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l8
  %t22 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l27
  br label %bb4
bb4:
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l9
  %t24 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l28
  br label %bb5
bb5:
  %t25 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l10
  %t26 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l29
  br label %bb6
bb6:
  %t27 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l11
  %t28 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l30
  br label %bb7
bb7:
  %t29 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l12
  %t30 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l31
  br label %bb8
bb8:
  %t31 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l13
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l32
  br label %bb9
bb9:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  %t34 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 0
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %t34, !tbaa !29
  %t36 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 1
  %t37 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %t36
  %t38 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 2
  %t39 = load i32, ptr %l5, !range !{i32 0, i32 2}
  store i32 %t39, ptr %t38
  %t40 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 3
  %t41 = load %"compiler/lower:Lowerer", ptr %l6
  store %"compiler/lower:Lowerer" %t41, ptr %t40
  %t42 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %l7, i64 784, i1 false)
  %t43 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 5
  %t44 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %t43
  %t45 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 6
  %t46 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t45
  %t47 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 7
  %t48 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %t47
  %t49 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 8
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %t49
  %t51 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 9
  %t52 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %t51
  %t53 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 10
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t53
  %t55 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t55
  %t57 = getelementptr %"compiler/interp:Exec", ptr %l33, i32 0, i32 12
  store i1 false, ptr %t57, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l33, i64 992, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/interp:chained" @compiler_2finterp_3achained_2ector(ptr %v0, ptr %v1, i64 %a0, i1 %a1, { i64, ptr } %a2, { i64, [3 x i64] } %a3) #0 {
entry:
  %rv = alloca %"compiler/interp:chained"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/interp:chained" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/interp:chained" %t10, i1 %a1, 1
  %t14 = insertvalue %"compiler/interp:chained" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/interp:chained" %t14, { i64, [3 x i64] } %a3, 3
  store %"compiler/interp:chained" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/interp:chained", ptr %rv
  ret %"compiler/interp:chained" %rr
}

@.d0 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"it reaches unreachable code, which aborts the program" }>, align 8
@.d1 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"a '!' in it meets a null, which aborts the program" }>, align 8
@.d2 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"it raises a null error, which aborts the program" }>, align 8
@.d3 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"an assertion in it fails, which aborts the program" }>, align 8
@.d4 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"it slices out of range, which aborts the program" }>, align 8
@.d5 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"it makes an array of a length out of range, which aborts the program" }>, align 8
@.d6 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c"it copies an array of another length into fixed storage, which aborts the program" }>, align 8
@.d7 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"a lane operation in it meets arrays of different lengths, which aborts the program" }>, align 8
@.d8 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"an 'as' that does not hold aborts the program" }>, align 8
@.d9 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"it asks a generator for its next value from inside the generator's own walk, which aborts the program" }>, align 8
@.d10 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"an error reaches '!', which ends the program" }>, align 8
@.d11 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"an error leaves the test, which ends it" }>, align 8
@.d12 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"it ends the test or the process" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_Hfa18c4028fc14c940207bea2352eb53b(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cI64_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"its value is no data the program can hold - it reaches storage made elsewhere, or a destructor" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 4}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 4}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  br label %bb3
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i64 }, ptr %t47, i32 0, i32 1
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i64 }, ptr %t51, i32 0, i32 1
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64, i64 }, ptr %t71, i32 0, i32 2
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb12, label %bb1
bb12:
  br label %bb3
bb13:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-l" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"lib" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".a" }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".o" }>, align 8
@.d27 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"a static library or an object, which only a link takes" }>, align 8
declare ptr @dlopen(ptr, i32)
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @dlerror()
@.d29 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"dlopen failed" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"an error escapes, code " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d41 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d43 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"it fails with an error no clause handles" }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d48 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no main\0A" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d50 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang interpret: " }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d52 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang interpret: " }>, align 8
@.d53 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": the Vec grew here\0A" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d56 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ok - " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d60 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"FAIL - " }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d62 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" passed, " }>, align 8
@.d63 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" failed\0A" }>, align 8
@.d64 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unhandled error: " }>, align 8
@.d65 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" - here in the task spawned at " }>, align 8
@.d66 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d68 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" earlier places not kept)\0A" }>, align 8
@.d69 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"raised here" }>, align 8
@.d70 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"try passed it on" }>, align 8
@.d71 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a task failed, and its join passed it on" }>, align 8
@.d72 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d74 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d75 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d77 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d78 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d79 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d80 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d81 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d82 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error " }>, align 8
@.d83 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d84 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d85 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"its range's step is not positive" }>, align 8
@.d86 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"its range holds " }>, align 8
@.d87 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" elements" }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d98 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"it fails with an error no clause handles" }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"it fails with an error no clause handles" }>, align 8
@.d102 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"it fails with an error no clause handles" }>, align 8
@.d103 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d104 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d105 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d106 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@olang_loc_eb3df5da8012cb63_283e587d4f698dd7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare void @compiler_2fnames_3aResolver_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_3aProgram_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_3aChecker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2eLen_3ccompiler_2finterp_3aCondErr_3e(ptr %v0, ptr %a0)
declare %"compiler/interp:CondErr" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2eAt_3ccompiler_2finterp_3aCondErr_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hb8bfbe57c0e5b70e405cb38b3b12641e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/eval:Image" %a2)
declare { i32, %"compiler/eval:Image" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eImage(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i1 %a3)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_Hcc4dae5da0ed3c5355f9c78c0e71655b(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAttrNotBuilt(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2feval_2eWhyStale = external constant <{ [8 x i8], ptr }>
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalStale(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalAborts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
@olang_loc_23ba8871310952f4_ff8b68d1da902468 = external constant [0 x i8]
@olang_loc_1c176b23f7e86d25_2ef9862bd1101439 = external constant [0 x i8]
declare { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0)
@olang_loc_743f77b054333c1d_15e2e891552f92b9 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H3ccda5e77fabf86fda89ecfc77eff03d(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_H1ffd47e550cf52833705251cc4e5cd8d(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H8e3ab02101333f4dae95aad48f2e722e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
declare %"compiler/eval:Blob" @compiler_2feval_3aBlob_2ector(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Blob" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20_Hd47ddefe3838698aaa5711f2f63b01ed(ptr %v0, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2)
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_Hbfebb6c42bc5b6ebe27287b6298add36(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.9f40551e0d6019a8e678d8f53048b6ba" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2fsource_3aSpan__Hd38fe3b5521cd0cc33c71306d155ae89(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeNotBaked(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eL_H34364174f15757c2d142d60c88ce0944(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eAt_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7edf3cf7ccf8e57f_276bde685bbe381b = external constant [0 x i8]
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare i1 @compiler_2ftyped_2eAlwaysReached(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertAborts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertStale(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d8df33bf7c2af1a9_d617709f0680343d = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0)
declare %"compiler/check:ValueAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eAt_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e1183b54591591ba_6784d54d52bb291e = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eResultHoldsAddress(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eZeroValueShared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralCtorFails(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadUnassigned(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroByReference(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteZeroReferenceHasOne(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_31552f310cf75527_9d9c34da119f96fb = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToC(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aCStr_2eStringFromC(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0)
@olang_loc_5ef8759083cc657e_8312724bf589cc02 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_97cc5832d0a5683f_9bb5deb899ee2c5b = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_9c0b486f116f3620_d1f759da60f3616c = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_b7cf027bc3b091ec_6e850e1bd8f0ff28 = external constant [0 x i8]
@G_2ecompiler_2fload_2eNoBranch = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5b75817b97c7703f_a9caa4d803bddbab = external constant [0 x i8]
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_fce8d31b7e62f371_71870e12b086bddd = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePop_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
@olang_loc_26fab0deca850fb9_a904bdf0227cd14d = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_f78c9384d4051fe8_f87279dcad65e91c = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c21b7649f9083df0_c859438e5e055394 = external constant [0 x i8]
declare { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %a0)
@olang_loc_736b533d144489ee_c645810c81b1a7fa = external constant [0 x i8]
@G_2ecompiler_2feval_2eWhyWaits = external constant <{ [8 x i8], ptr }>
@olang_loc_177aae49e1a91f38_175ec48f508568b4 = external constant [0 x i8]
declare ptr @compiler_2fast_2eFindTest(ptr %v0, { i64, ptr } %a0, %"compiler/source:Span" %a1)
@olang_loc_eb59e3d17e209b69_67e25fc5a7a9951d = external constant [0 x i8]
declare { i64, ptr } @compiler_2fast_2eTestLabel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceWhat(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExternSymbol(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_6b327bc23f54125b_df118949941dcc1f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_4dbbfc1aefa6e21c_e99ccf60d5e11690 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eLen_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eLen_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cc02f93ad90a889a_227f669eebce755e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2)
@olang_loc_8861c203007a29b_3eff7fe7d80c41df = external constant [0 x i8]
@olang_loc_8c9ae6434c5565e7_656708b088a82c0b = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i1 %a4, { i64, [2 x i64] } %a5)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eBuildGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_5218513f7b2d35ff_8134a4fdf2d394bb = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6661ff5fcd5a0e74_cadc672e97162150 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_8aa385fac4707635_8a0feffc81f8cb59 = external constant [0 x i8]
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eElems(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i32 %a3)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
@olang_loc_6556c5b27a8f2520_6c50e0cecbbb5fdc = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H8bd9ddbe6d7efc10dd35c4d42ad9dacf(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eLen_H192b02349624a37821a23e7def80c714(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eLen_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2eLen__H3e1caeca23cca4e886f5085abf2ba261(ptr %v0, ptr %a0)
declare %"compiler/check:EmbedAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2eAt_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4b90e82c7a9c5937397e46eef988cfe3(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94076cc109da9d789864820ff05c3ac1(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, { i64, ptr } %a2)
declare %"compiler/check:UnrollAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2eAt_3ccompiler_2fcheck_3aUnrollAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H227dc11a6a27d53bbdf34efa35d45ee3(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H0a119a96f6a24054f8ced6f159e533e6(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_b2316244e9af307f_bcf0fdc57d0f0f9b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/check:Ask" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2ePush_3ccompiler_2fast_3aIf_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:ConstAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2eAt__H3f4459851a287fa27378a94ef8fff763(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
@G_2ecompiler_2fgeneric_2eRunTimeLength = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\80" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_b43ed542b52bdb2d_e8039c8a87e26b41 = external constant [0 x i8]
@olang_loc_f84cb7d5463d9835_35d9cf4f803d5b1 = external constant [0 x i8]
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_H7486c711b8ab0d124cd9b327dc5d14f9(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUnseen(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondUndecidable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2finterp_3aCondErr_3e_2ePush_3ccompiler_2finterp_3aCondErr_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/interp:CondErr" %a1)
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2eLen_3ccompiler_2fast_3aIf_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aIf_26_3e_2eAt_3ccompiler_2fast_3aIf_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eAt_H56c1cddaee4bc4aa5c09605de1331e44(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_d213ae2acd73c837_819e6544d8b9fb33 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eConversionDoesNotFit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eContractFalse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteContractCondition(ptr %v0)
@olang_loc_3238838aabc16991_ed85858096edfcc5 = external constant [0 x i8]
declare %"compiler/check:TopAssertAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eA_H4ee666e103d2e1a6dd21794f4936298a(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c1dbe1436b3e45a6_af45377485db5b6a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopAssertFalse(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopAssertFalseMessage(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopAssertUndecidable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5ce1b8d60352552c_3e5898832c479718 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseMessage(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_ef1298413c90a2dc_ba44d1693e670768 = external constant [0 x i8]
@olang_loc_2f4ce1a9e181e1f2_bd4ae6421df971e = external constant [0 x i8]
@olang_loc_6beaad51a5cbbd4f_ba25a08250cd8123 = external constant [0 x i8]
@olang_loc_337e2febbb969070_fe2fc98a6d253614 = external constant [0 x i8]
@olang_loc_c5607a0551bceea3_a83aa459e58f2847 = external constant [0 x i8]
@olang_loc_4efe4c4a78894057_5e75e4c074554d53 = external constant [0 x i8]
@olang_loc_1ec4d19c7606c42f_38a78c76cd6682ab = external constant [0 x i8]
declare void @compiler_2fviews_3aViewer_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_33cf42576bc92052_8a57929dd960fbd6 = external constant [0 x i8]
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrewHere(ptr %v0)
@olang_loc_9aa13344fea3f6d8_5ff568fedc30749c = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalseWritten(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertFalse(ptr %v0)
@olang_loc_a437b17fd6ef2726_85fb06efd955f512 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_69f8faa22d82cef9_e064f09003af3e5d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_bd2a2cd0640a3acc_9bed5ea297d8f800 = external constant [0 x i8]
@olang_loc_196dd61ce96ecec0_7e4a472be9bda874 = external constant [0 x i8]
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2feval_2eNewMachine(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Array_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
