; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_109c59c57186f76e_74ee5f33f64158ea = weak_odr constant [41 x i8] c"std/list.olang:567: unreachable reached\0A\00"
@olang_loc_4ea7c8517125b8f4_bcbf77ca51f4e170 = weak_odr constant [41 x i8] c"std/list.olang:571: unreachable reached\0A\00"
@olang_loc_648910b0b3039f70_320e98db692837c4 = weak_odr constant [47 x i8] c"std/list.olang:569: array length out of range\0A\00"
