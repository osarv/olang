; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_a154b35e9769f21d_ef2f4c83f49165d1 = weak_odr constant [47 x i8] c"std/list.olang:557: array length out of range\0A\00"
